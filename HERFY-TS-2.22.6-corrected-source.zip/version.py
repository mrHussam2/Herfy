from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any


@lru_cache(maxsize=1)
def _metadata() -> dict[str, Any]:
    path = Path(__file__).resolve().parent / "version.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    required = {
        "product",
        "client",
        "server",
        "version",
        "release_generation",
        "api_base_url",
        "update_origin",
        "api_contract_sha256",
        "update_key_id",
        "update_public_key_sha256",
    }
    if set(data) != required:
        raise RuntimeError("version.json schema mismatch")
    return data


def get_version() -> str:
    return str(_metadata()["version"])


def get_product_name() -> str:
    return str(_metadata()["client"])


def get_build_info() -> dict[str, str]:
    data = _metadata()
    return {
        key: str(data[key])
        for key in ("product", "client", "server", "version", "release_generation")
    }


def get_release_identity() -> dict[str, str]:
    data = _metadata()
    return {
        key: str(data[key])
        for key in (
            "version",
            "api_base_url",
            "update_origin",
            "api_contract_sha256",
            "update_key_id",
            "update_public_key_sha256",
        )
    }


__version__ = get_version()
