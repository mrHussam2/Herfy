from __future__ import annotations

import hashlib
from collections.abc import Mapping
from dataclasses import dataclass
from threading import RLock
from typing import Any
from urllib.parse import urlparse

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.i18n import normalize_language_code
from core.models import parse_bool
from core.presentation import SettingsState
from core.settings import normalize_api_base_url
from services.settings_schema import (
    CANONICAL_EXPIRY_RUNTIME_SETTING_KEYS,
    CANONICAL_SETTINGS_DEFAULTS,
    IGNORED_LEGACY_SETTINGS,
    LEGACY_VALUE_MIGRATIONS,
    SETTINGS_MIGRATION_ALIASES,
    validate_canonical_settings,
)
from services.sync import (
    apply_startup_preferences,
    current_api_base_url,
    normalize_startup_preferences,
)

_PRESENTATION_DEFAULTS: dict[str, str] = {
    **CANONICAL_SETTINGS_DEFAULTS,
    "ui_scale_percent": "100",
    "usage_hide_total_zero": "False",
    "tray_show_message_on_minimize": "False",
    "check_updates_on_startup": "True",
    "start_with_windows": "True",
    "reveal_login_after_tray_startup": "False",
}

# These values are preferences of the signed-in user on this device. Machine startup/update
# controls stay global because Windows runs one application instance regardless of account.
SETTINGS_SCHEMA_REVISION_KEY = "settings_schema_revision"
SETTINGS_SCHEMA_REVISION = "8"
LEGACY_SETTINGS_SCHEMA_REVISION_KEY = "alert_settings_schema_revision"

USER_LOCAL_SETTING_KEYS = frozenset(
    {
        *CANONICAL_SETTINGS_DEFAULTS.keys(),
        SETTINGS_SCHEMA_REVISION_KEY,
        "ui_scale_percent",
        "usage_hide_total_zero",
        "tray_show_message_on_minimize",
        "notification_history_v1",
    }
)


def active_username(source: Any) -> str:
    """Resolve the authenticated username without creating a second session authority."""
    state = getattr(source, "app_state", None)
    if state is None:
        state = getattr(getattr(source, "state", None), "app_state", None)
    if state is None:
        state = getattr(source, "main_window", None)
        state = getattr(state, "app_state", None) if state is not None else None
    if state is None:
        return ""
    profile = getattr(state, "current_user", None)
    username = str(getattr(profile, "username", "") or "").strip()
    if username:
        return username
    session = getattr(state, "session", None)
    return str(getattr(session, "username", "") or "").strip()


def user_scope_id(username: str) -> str:
    normalized = str(username or "").strip().casefold()
    if not normalized:
        return ""
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:24]


def scoped_setting_key(username: str, key: str) -> str:
    scope = user_scope_id(username)
    setting = str(key or "").strip()
    return f"user.{scope}.{setting}" if scope and setting else setting


def is_user_local_setting(key: str) -> bool:
    return str(key or "").strip() in USER_LOCAL_SETTING_KEYS


def get_local_setting(
    settings_store: Any, key: str, default: Any = None, *, username: str = ""
) -> Any:
    setting = str(key or "").strip()
    if not setting:
        return default
    resolved_user = str(username or active_username(settings_store) or "").strip()
    try:
        if resolved_user and is_user_local_setting(setting):
            sentinel = "__HERFY_TS_MISSING_SETTING__"
            scoped_key = scoped_setting_key(resolved_user, setting)
            value = settings_store.get_setting(scoped_key, sentinel)
            if value != sentinel:
                return value
            inherited = settings_store.get_setting(setting, sentinel)
            if inherited != sentinel:
                settings_store.set_setting(scoped_key, str(inherited))
                deleter = getattr(settings_store, "delete_setting", None)
                if callable(deleter):
                    deleter(setting)
                return inherited
            return default
        return settings_store.get_setting(setting, default)
    except SERVICE_OPERATION_EXCEPTIONS:
        return default


class PresentationPreferencesService:
    """Own the in-memory preferences cache consumed by presentation code."""

    def __init__(self, settings_source: Any) -> None:
        self._settings_source = settings_source
        self._lock = RLock()
        self._values: dict[str, str] = dict(_PRESENTATION_DEFAULTS)
        self.refresh()

    def refresh(self) -> dict[str, str]:
        values = {
            key: str(get_local_setting(self._settings_source, key, default) or default)
            for key, default in _PRESENTATION_DEFAULTS.items()
        }
        with self._lock:
            self._values = values
            return dict(values)

    def snapshot(self) -> dict[str, str]:
        with self._lock:
            return dict(self._values)

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._values.get(str(key or ""), default)

    def set_cached(self, key: str, value: Any) -> None:
        clean_key = str(key or "").strip()
        if clean_key:
            with self._lock:
                self._values[clean_key] = str(value if value is not None else "")

    def get_bool(self, key: str, default: bool = False) -> bool:
        return parse_bool(self.get(key, "True" if default else "False"), bool(default))

    def get_int(
        self, key: str, default: int = 0, *, minimum: int | None = None, maximum: int | None = None
    ) -> int:
        try:
            value = int(self.get(key, str(default)) or default)
        except (TypeError, ValueError):
            value = int(default)
        if minimum is not None:
            value = max(int(minimum), value)
        if maximum is not None:
            value = min(int(maximum), value)
        return value

    def language(self) -> str:
        return normalize_language_code(str(self.get("language", "en") or "en"))


def set_local_setting(settings_store: Any, key: str, value: Any, *, username: str = "") -> None:
    setting = str(key or "").strip()
    if not setting:
        return
    resolved_user = str(username or active_username(settings_store) or "").strip()
    target = (
        scoped_setting_key(resolved_user, setting)
        if resolved_user and is_user_local_setting(setting)
        else setting
    )
    settings_store.set_setting(target, str(value if value is not None else ""))
    if resolved_user and is_user_local_setting(setting):
        deleter = getattr(settings_store, "delete_setting", None)
        if callable(deleter):
            deleter(setting)


def scoped_alert_key(username: str, alert_key: str) -> str:
    scope = user_scope_id(username)
    key = str(alert_key or "").strip()
    return f"user.{scope}.alert.{key}" if scope and key else key


def _converted_migration_value(source_key: str, target_key: str, value: Any) -> str:
    del source_key, target_key
    return str(value)


def _migrate_legacy_aliases(settings_store: Any, *, username: str = "") -> bool:
    """Promote legacy aliases through the single canonical settings boundary."""
    getter = getattr(settings_store, "get_setting", None)
    deleter = getattr(settings_store, "delete_setting", None)
    if not callable(getter):
        return False
    resolved_user = str(username or "").strip()
    sentinel = "__HERFY_TS_MISSING_SETTING__"
    changed = False
    for source_key, target_key in SETTINGS_MIGRATION_ALIASES.items():
        source_storage_key = (
            scoped_setting_key(resolved_user, source_key) if resolved_user else source_key
        )
        legacy = getter(source_storage_key, sentinel)
        if legacy == sentinel and resolved_user:
            legacy = getter(source_key, sentinel)
            source_storage_key = source_key
        if legacy == sentinel:
            continue
        current = (
            getter(scoped_setting_key(resolved_user, target_key), sentinel)
            if resolved_user
            else get_local_setting(settings_store, target_key, sentinel)
        )
        if current == sentinel:
            set_local_setting(
                settings_store,
                target_key,
                _converted_migration_value(source_key, target_key, legacy),
                username=resolved_user,
            )
            changed = True
        if callable(deleter):
            deleter(source_storage_key)
            changed = True
    for source_key, target_key in LEGACY_VALUE_MIGRATIONS.items():
        source_storage_key = (
            scoped_setting_key(resolved_user, source_key) if resolved_user else source_key
        )
        legacy = getter(source_storage_key, sentinel)
        if legacy == sentinel and resolved_user:
            legacy = getter(source_key, sentinel)
            source_storage_key = source_key
        if legacy == sentinel:
            continue
        target_storage_key = (
            scoped_setting_key(resolved_user, target_key) if resolved_user else target_key
        )
        current = getter(target_storage_key, sentinel)
        if current == sentinel:
            set_local_setting(settings_store, target_key, str(legacy), username=resolved_user)
            changed = True
        if callable(deleter):
            deleter(source_storage_key)
            changed = True

    for legacy_key in IGNORED_LEGACY_SETTINGS:
        legacy_storage_key = (
            scoped_setting_key(resolved_user, legacy_key) if resolved_user else legacy_key
        )
        if getter(legacy_storage_key, sentinel) != sentinel and callable(deleter):
            deleter(legacy_storage_key)
            changed = True
        if resolved_user and getter(legacy_key, sentinel) != sentinel and callable(deleter):
            deleter(legacy_key)
            changed = True
    return changed


def migrate_active_user_settings(settings_store: Any, *, username: str = "") -> bool:
    """Normalize legacy local preferences into the current per-user contract.

    This migration is client-local, data-preserving and idempotent. Runtime
    behavior reads canonical settings only after this function completes.
    """
    resolved_user = str(username or active_username(settings_store) or "").strip()
    if not resolved_user:
        return False

    current_revision = str(
        get_local_setting(
            settings_store,
            SETTINGS_SCHEMA_REVISION_KEY,
            "",
            username=resolved_user,
        )
        or ""
    ).strip()

    deleter = getattr(settings_store, "delete_setting", None)
    legacy_scoped_key = scoped_setting_key(resolved_user, LEGACY_SETTINGS_SCHEMA_REVISION_KEY)
    if current_revision == SETTINGS_SCHEMA_REVISION:
        cleaned = False
        if callable(deleter):
            getter = getattr(settings_store, "get_setting", None)
            sentinel = "__HERFY_TS_MISSING_SETTING__"
            if callable(getter) and getter(legacy_scoped_key, sentinel) != sentinel:
                deleter(legacy_scoped_key)
                cleaned = True
            if (
                callable(getter)
                and getter(LEGACY_SETTINGS_SCHEMA_REVISION_KEY, sentinel) != sentinel
            ):
                deleter(LEGACY_SETTINGS_SCHEMA_REVISION_KEY)
                cleaned = True
        return cleaned

    # Promote known legacy values only when a canonical scoped value is absent,
    # then delete the old storage keys.
    _migrate_legacy_aliases(settings_store, username=resolved_user)

    raw = {
        key: get_local_setting(settings_store, key, default, username=resolved_user)
        for key, default in CANONICAL_SETTINGS_DEFAULTS.items()
    }
    validated = validate_canonical_settings(raw)
    for key, value in validated.values.items():
        set_local_setting(settings_store, key, value, username=resolved_user)
    set_local_setting(
        settings_store,
        SETTINGS_SCHEMA_REVISION_KEY,
        SETTINGS_SCHEMA_REVISION,
        username=resolved_user,
    )
    if callable(deleter):
        deleter(legacy_scoped_key)
        deleter(LEGACY_SETTINGS_SCHEMA_REVISION_KEY)
    return True


def _bool_text(value: bool) -> str:
    return "True" if bool(value) else "False"


@dataclass(frozen=True, slots=True)
class SettingsSaveResult:
    normalized_server_url: str
    expiry_runtime_settings_changed: bool
    errors: dict[str, str] | None = None


class SettingsService:
    def __init__(self, settings_store: Any):
        self.settings_store = settings_store
        self._migrate_settings_to_canonical()

    def _raw_value(self, key: str, default: str = "") -> str:
        try:
            return str(get_local_setting(self.settings_store, key, default) or default)
        except SERVICE_OPERATION_EXCEPTIONS:
            return str(default or "")

    def _value(self, key: str, default: str = "") -> str:
        canonical_default = CANONICAL_SETTINGS_DEFAULTS.get(key, default)
        value = self._raw_value(key, "")
        return str(value) if value not in (None, "") else str(canonical_default)

    def _migrate_settings_to_canonical(self) -> None:
        _migrate_legacy_aliases(self.settings_store)

    def current_language(self) -> str:
        return normalize_language_code(self._value("language", "en"))

    def canonical_snapshot(self) -> dict[str, str]:
        return {
            key: self._value(key, default) for key, default in CANONICAL_SETTINGS_DEFAULTS.items()
        }

    def expiry_runtime_snapshot(self) -> dict[str, str]:
        canonical = validate_canonical_settings(self.canonical_snapshot()).values
        return {key: canonical[key] for key in CANONICAL_EXPIRY_RUNTIME_SETTING_KEYS}

    @staticmethod
    def normalize_server_url(value: str) -> str:
        raw = str(value or "").strip()
        if not raw:
            return ""
        normalized = normalize_api_base_url(raw)
        parsed = urlparse(normalized)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError("Invalid server URL.")
        return normalized

    def current_server_url(self) -> str:
        try:
            return self.normalize_server_url(current_api_base_url())
        except SERVICE_OPERATION_EXCEPTIONS:
            return str(current_api_base_url() or "").strip()

    def load(self) -> SettingsState:
        validation = validate_canonical_settings(self.canonical_snapshot())
        v = validation.values
        return SettingsState(
            language=v["language"],
            monitoring_enabled=parse_bool(v["monitoring_enabled"], True),
            enable_tray_background=parse_bool(v["enable_tray_background"], True),
            enable_desktop_notifications=parse_bool(v["enable_desktop_notifications"], True),
            enable_sounds=parse_bool(v["enable_sounds"], True),
            expiry_enable_status_colors=parse_bool(v["expiry_enable_status_colors"], True),
            expiry_enable_status_icons=parse_bool(v["expiry_enable_status_icons"], True),
            notification_sound_default=v["notification_sound_default"],
            notification_sound_soon=v["notification_sound_soon"],
            notification_sound_approaching=v["notification_sound_approaching"],
            notification_sound_near=v["notification_sound_near"],
            notification_sound_tomorrow=v["notification_sound_tomorrow"],
            notification_sound_today=v["notification_sound_today"],
            ui_scale_percent=max(
                90, min(125, int(self._raw_value("ui_scale_percent", "100") or 100))
            ),
            usage_hide_total_zero=parse_bool(
                self._raw_value("usage_hide_total_zero", "False"), False
            ),
            start_with_windows=parse_bool(self._raw_value("start_with_windows", "True"), True),
            tray_show_message_on_minimize=parse_bool(
                self._raw_value("tray_show_message_on_minimize", "False"), False
            ),
            server_url=self.current_server_url(),
            check_updates_on_startup=parse_bool(
                self._raw_value("check_updates_on_startup", "True"), True
            ),
            expiry_runtime_snapshot={key: v[key] for key in CANONICAL_EXPIRY_RUNTIME_SETTING_KEYS},
        )

    def save(
        self,
        values: Mapping[str, Any],
        *,
        original_expiry_runtime_snapshot: Mapping[str, str] | None = None,
    ) -> SettingsSaveResult:
        original = dict(original_expiry_runtime_snapshot or self.expiry_runtime_snapshot())
        canonical_values = {
            key: values.get(key, self._value(key, default))
            for key, default in CANONICAL_SETTINGS_DEFAULTS.items()
        }
        validation = validate_canonical_settings(canonical_values)
        for key, value in validation.values.items():
            set_local_setting(self.settings_store, key, value)
        side_keys = {
            "ui_scale_percent": values.get(
                "ui_scale_percent", self._raw_value("ui_scale_percent", "100")
            ),
            "usage_hide_total_zero": values.get(
                "usage_hide_total_zero",
                self._raw_value("usage_hide_total_zero", "False"),
            ),
            "start_with_windows": values.get(
                "start_with_windows", self._raw_value("start_with_windows", "True")
            ),
            "tray_show_message_on_minimize": values.get(
                "tray_show_message_on_minimize",
                self._raw_value("tray_show_message_on_minimize", "False"),
            ),
            "check_updates_on_startup": values.get(
                "check_updates_on_startup",
                self._raw_value("check_updates_on_startup", "True"),
            ),
        }
        for key, value in side_keys.items():
            set_local_setting(
                self.settings_store,
                key,
                _bool_text(value) if isinstance(value, bool) else str(value),
            )
        server_url = self.current_server_url()
        normalize_startup_preferences(self.settings_store, persist=True)
        apply_startup_preferences(self.settings_store)
        current_expiry_runtime = {
            key: validation.values[key] for key in CANONICAL_EXPIRY_RUNTIME_SETTING_KEYS
        }
        return SettingsSaveResult(
            normalized_server_url=server_url,
            expiry_runtime_settings_changed=current_expiry_runtime != original,
            errors=validation.errors,
        )

    def set_runtime_value(self, key: str, value: Any) -> None:
        clean_key = str(key or "").strip()
        if not clean_key:
            raise ValueError("setting key is required")
        set_local_setting(self.settings_store, clean_key, str(value))

    def reset_defaults(self) -> SettingsSaveResult:
        return self.save(
            dict(CANONICAL_SETTINGS_DEFAULTS),
            original_expiry_runtime_snapshot=self.expiry_runtime_snapshot(),
        )
