from __future__ import annotations

import calendar
import copy
import io
import re
import tempfile
from collections.abc import Iterable
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from xml.etree import ElementTree
from zipfile import ZIP_DEFLATED, ZipFile

from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell
from openpyxl.formula.translate import Translator
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.workbook.workbook import Workbook
from openpyxl.worksheet.worksheet import Worksheet

from services.kpi_channels import (
    COMPARISON_CHANNELS,
    DASHBOARD_CHANNEL_COLUMNS,
    DASHBOARD_OTHER_APP_CATEGORIES,
    SOURCEWISE_AGGREGATOR_ROWS,
    TABWISE_CHANNEL_ROWS,
    comparison_channel_values,
)
from services.kpi_channels import (
    normalize_category as _normalize_category,
)
from services.kpi_channels import (
    sum_pair as _sum_pair,
)
from services.kpi_totals import (
    report_net_total_value,
    sum_report_net_totals,
)
from services.kpi_validation import (
    SalesAndBills,
    ValidationReport,
)

MONTH_ROW_START = 2
MONTH_ROW_SPACING = 17
MONTH_COUNT = 12
INPUT_COLUMNS = (3, 4, 7, 8)
KPI_MONTH_ROW_START = 5
KPI_MONTH_ROW_SPACING = 5
KPI_DATA_ORDER_TYPES = 15
KPI_DATA_ROWS_PER_BRANCH = 12 * 2 * KPI_DATA_ORDER_TYPES
ExcelCellValue = str | int | float | Decimal | bool | date | datetime | None


def export_comparison_workbook(
    report: ValidationReport,
    template_path: str | Path,
    output_path: str | Path,
) -> Path:
    template = Path(template_path)
    output = Path(output_path)
    if not template.is_file():
        raise ValueError(f"Excel template does not exist: {template}")
    if template.resolve() == output.resolve():
        raise ValueError("Choose a new output file; the Excel template will not be overwritten.")
    if not report.files:
        raise ValueError("Analyze at least one sales CSV before exporting an Excel report.")
    years = sorted(report.years, reverse=True)
    if len(years) > 2:
        raise ValueError("The comparison workbook supports at most two reporting years.")
    if not years:
        raise ValueError("No valid reporting dates were found in the selected CSV files.")

    outlets_by_sheet: dict[str, str] = {}
    for outlet in report.outlets:
        sheet_name = _workbook_sheet_for_outlet(outlet)
        if sheet_name is None:
            raise ValueError(f"Could not identify a HERFY branch number in outlet name {outlet!r}.")
        if sheet_name in outlets_by_sheet and outlets_by_sheet[sheet_name] != outlet:
            raise ValueError(f"Multiple outlets map to the same template tab {sheet_name}.")
        outlets_by_sheet[sheet_name] = outlet

    workbook = load_workbook(template)
    if not workbook.worksheets:
        raise ValueError("The Excel template does not contain a worksheet to use as a layout.")
    if {"_KPI_DATA", "_KPI_LISTS", "Management Dashboard"} <= set(workbook.sheetnames):
        return _export_kpi_dashboard_workbook(report, template, output, workbook)
    _set_reporting_years(workbook, years)

    existing_order = [sheet.title for sheet in workbook.worksheets]
    missing_sheets = set(outlets_by_sheet) - set(existing_order)
    reference_sheet = workbook[existing_order[0]]
    for sheet_name in sorted(missing_sheets, key=_sheet_number):
        copied_sheet = workbook.copy_worksheet(reference_sheet)
        copied_sheet.title = sheet_name

    desired_order = [
        sheet_name for sheet_name in existing_order if sheet_name in outlets_by_sheet
    ] + sorted(missing_sheets, key=_sheet_number)
    for sheet in list(workbook.worksheets):
        if sheet.title not in outlets_by_sheet:
            workbook.remove(sheet)
    for index, sheet_name in enumerate(desired_order):
        current_index = workbook.sheetnames.index(sheet_name)
        if current_index != index:
            workbook.move_sheet(workbook[sheet_name], offset=index - current_index)
    for sheet_name, outlet in outlets_by_sheet.items():
        _fill_outlet_sheet(workbook[sheet_name], outlet, years, report)

    if "Data Quality" in workbook.sheetnames:
        del workbook["Data Quality"]
    quality_sheet = workbook.create_sheet("Data Quality")
    _write_data_quality_sheet(quality_sheet, report)
    _write_channel_analysis_sheets(workbook, report, years)
    calculation = workbook.calculation
    calculation.calcMode = "auto"
    calculation.fullCalcOnLoad = True
    calculation.forceFullCalc = True

    try:
        workbook.save(output)
    except OSError as exc:
        raise ValueError(f"Could not save Excel report to {output}: {exc}") from exc
    return output


def export_branch_workbook(report: ValidationReport, output_path: str | Path) -> Path:
    """Export local branch KPI data without a template or an external package."""
    output = Path(output_path)
    if not report.files:
        raise ValueError("Analyze at least one sales CSV before exporting an Excel report.")
    years = sorted(report.years, reverse=True)
    if not years:
        raise ValueError("No valid reporting dates were found in the selected CSV files.")
    if not report.outlets:
        raise ValueError("No branches with valid dates were found in the selected CSV files.")

    workbook = Workbook()
    workbook.remove(workbook.active)
    current_year = years[0]
    compare_year = years[1] if len(years) > 1 else None
    used_titles: set[str] = set()
    for outlet in sorted(report.outlets):
        sheet = workbook.create_sheet(_branch_export_sheet_name(outlet, used_titles))
        _write_branch_export_sheet(sheet, report, outlet, current_year, compare_year)
    quality_sheet = workbook.create_sheet("Data Quality")
    _write_data_quality_sheet(quality_sheet, report)
    _write_channel_analysis_sheets(workbook, report, years)
    workbook.calculation.calcMode = "auto"
    workbook.calculation.fullCalcOnLoad = True
    workbook.calculation.forceFullCalc = True
    try:
        workbook.save(output)
    except OSError as exc:
        raise ValueError(f"Could not save Excel report to {output}: {exc}") from exc
    return output


def _branch_export_sheet_name(outlet: str, used_titles: set[str]) -> str:
    base = re.sub(r"[\[\]:*?/\\\\]", "-", outlet).strip(" '") or "Branch"
    candidate = base[:31]
    index = 2
    while candidate.casefold() in used_titles or candidate.casefold() == "data quality":
        suffix = f" ({index})"
        candidate = f"{base[: 31 - len(suffix)]}{suffix}"
        index += 1
    used_titles.add(candidate.casefold())
    return candidate


def _write_branch_export_sheet(
    sheet: Worksheet,
    report: ValidationReport,
    outlet: str,
    current_year: int,
    compare_year: int | None,
) -> None:
    sheet.append([f"{outlet} Sales KPI"])
    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=17)
    sheet.append(
        [
            "Month",
            "Branch",
            "Channel",
            f"Sales {current_year}",
            f"Sales {compare_year or 'N/A'}",
            "Sales change",
            "Sales change %",
            f"GC {current_year}",
            f"GC {compare_year or 'N/A'}",
            "GC change",
            "GC change %",
            f"APC {current_year}",
            f"APC {compare_year or 'N/A'}",
            f"Discount {current_year}",
            f"Discount {compare_year or 'N/A'}",
            f"Total including discount {current_year}",
            f"Total including discount {compare_year or 'N/A'}",
        ]
    )
    months = {
        month
        for report_kind in ("Tabwise", "Sourcewise")
        for branch, year, month in report.monthly_totals[report_kind]
        if branch == outlet and year in {current_year, compare_year}
    }
    for month in sorted(months):
        current_values = comparison_channel_values(report, outlet, current_year, month)
        compare_values = (
            comparison_channel_values(report, outlet, compare_year, month)
            if compare_year is not None
            else {}
        )
        for channel_row, channel_name in COMPARISON_CHANNELS:
            current = current_values.get(channel_row)
            compare = compare_values.get(channel_row)
            sheet.append(
                _channel_export_row(
                    calendar.month_name[month], outlet, channel_name, current, compare
                )
            )
    sheet.freeze_panes = "A3"
    sheet.column_dimensions["A"].width = 15
    sheet.column_dimensions["B"].width = 24
    for column in range(3, sheet.max_column + 1):
        sheet.column_dimensions[get_column_letter(column)].width = 16
    for cell in sheet[1]:
        cell.font = Font(bold=True, color="FFFFFF", size=14)
        cell.fill = PatternFill("solid", fgColor="174D73")
    for cell in sheet[2]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1D5C85")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _export_kpi_dashboard_workbook(
    report: ValidationReport,
    template: Path,
    output: Path,
    workbook: Workbook,
) -> Path:
    years = sorted(report.years, reverse=True)
    if not years:
        raise ValueError("No valid reporting dates were found in the selected CSV files.")
    if len(years) > 2:
        raise ValueError("The KPI dashboard supports at most two reporting years.")
    if not report.outlets:
        raise ValueError("No branches with valid dates were found in the selected CSV files.")

    reference_sheet = next(
        (sheet for sheet in workbook.worksheets if re.fullmatch(r"Herfy \d+", sheet.title)),
        None,
    )
    if reference_sheet is None:
        raise ValueError("The KPI dashboard template does not contain a Herfy branch worksheet.")
    branch_sheets: dict[str, str] = {}
    for outlet in report.outlets:
        sheet_name = _dashboard_sheet_for_outlet(outlet)
        if sheet_name in branch_sheets and branch_sheets[sheet_name] != outlet:
            raise ValueError(f"Multiple outlets map to the same dashboard tab {sheet_name}.")
        branch_sheets[sheet_name] = outlet

    if "Data Quality" in workbook.sheetnames:
        del workbook["Data Quality"]
    for sheet_name in branch_sheets.keys() - set(workbook.sheetnames):
        copied = workbook.copy_worksheet(reference_sheet)
        copied.title = sheet_name

    for sheet in list(workbook.worksheets):
        if re.fullmatch(r"Herfy \d+", sheet.title) and sheet.title not in branch_sheets:
            workbook.remove(sheet)
    for name in sorted(branch_sheets, key=_dashboard_branch_number):
        sheet = workbook[name]
        outlet = branch_sheets[name]
        _write_dashboard_branch_sheet(sheet, outlet, years, report)

    ordered_tabs = sorted(branch_sheets, key=_dashboard_branch_number)
    for offset, name in enumerate(ordered_tabs, start=4):
        position = workbook.sheetnames.index(name)
        target = min(offset, len(workbook.worksheets) - 1)
        if position != target:
            workbook.move_sheet(name, offset=target - position)

    _set_dashboard_filters(workbook, ordered_tabs, years, report)
    _rebuild_kpi_data_sheet(workbook, reference_sheet.title, ordered_tabs)
    _expand_dashboard_formula_ranges(workbook, len(ordered_tabs))
    quality_sheet = workbook.create_sheet("Data Quality")
    _write_data_quality_sheet(quality_sheet, report, layout="dashboard")
    _write_channel_analysis_sheets(workbook, report, years)

    calculation = workbook.calculation
    calculation.calcMode = "auto"
    calculation.fullCalcOnLoad = True
    calculation.forceFullCalc = True

    with tempfile.TemporaryDirectory(
        prefix=f".{output.stem}-",
        dir=output.parent,
    ) as temp_directory:
        temp_path = Path(temp_directory) / "edited.xlsx"
        workbook.save(temp_path)
        _restore_template_extensions(template, temp_path, output, len(ordered_tabs))
    return output


def _write_channel_analysis_sheets(
    workbook: Workbook,
    report: ValidationReport,
    years: list[int],
) -> None:
    monthly_title = "Monthly Channels"
    annual_title = "Annual Channels"
    for title in (monthly_title, annual_title):
        if title in workbook.sheetnames:
            del workbook[title]

    current_year = years[0] if years else None
    compare_year = years[1] if len(years) > 1 else None
    headers = (
        "Month",
        "Branch",
        "Channel",
        f"Sales {current_year or 'Current'}",
        f"Sales {compare_year or 'Compare'}",
        "Sales Difference",
        "Sales Change %",
        f"GC {current_year or 'Current'}",
        f"GC {compare_year or 'Compare'}",
        "GC Difference",
        "GC Change %",
        f"APC {current_year or 'Current'}",
        f"APC {compare_year or 'Compare'}",
        f"Discount {current_year or 'Current'}",
        f"Discount {compare_year or 'Compare'}",
        f"Total incl. Discount {current_year or 'Current'}",
        f"Total incl. Discount {compare_year or 'Compare'}",
    )
    monthly_sheet = workbook.create_sheet(monthly_title)
    monthly_sheet.append(["Monthly channel comparison"])
    monthly_sheet.append(
        [
            "Current year",
            current_year,
            "Compare year",
            compare_year,
            "Branches",
            len(report.outlets),
        ]
    )
    monthly_sheet.append([])
    monthly_sheet.append(headers)

    annual_values: dict[tuple[str, int], dict[int, SalesAndBills]] = {}
    annual_net_values: dict[tuple[str, int], SalesAndBills] = {}
    annual_discount_values: dict[tuple[str, int], Decimal] = {}
    for outlet in sorted(report.outlets):
        outlet_months = {
            month
            for kind in ("Tabwise", "Sourcewise")
            for branch, year, month in report.monthly_totals[kind]
            if branch == outlet and year in years
        }
        for month in sorted(outlet_months):
            year_values: dict[int, dict[int, SalesAndBills]] = {}
            for year in years:
                branch_month = (outlet, year, month)
                if not any(
                    branch_month in report.monthly_totals[kind]
                    for kind in ("Tabwise", "Sourcewise")
                ):
                    continue
                net_total = _report_net_total_value(report, outlet, year, month)
                if net_total is not None:
                    key = (outlet, year)
                    previous_total = annual_net_values.get(key, (Decimal(0), 0))
                    annual_net_values[key] = (
                        previous_total[0] + net_total[0],
                        previous_total[1] + net_total[1],
                    )
                discount_total = _report_discount_total_value(report, outlet, year, month)
                if discount_total is not None:
                    key = (outlet, year)
                    annual_discount_values[key] = (
                        annual_discount_values.get(key, Decimal(0)) + discount_total
                    )
                values = comparison_channel_values(report, outlet, year, month)
                channel_values: dict[int, SalesAndBills] = {}
                for channel_row, _ in COMPARISON_CHANNELS:
                    pair = _report_channel_value(report, outlet, year, month, channel_row, values)
                    if pair is not None:
                        channel_values[channel_row] = pair
                        key = (outlet, year)
                        annual_channel_values = annual_values.setdefault(key, {})
                        previous = annual_channel_values.get(channel_row, (Decimal(0), 0))
                        annual_channel_values[channel_row] = (
                            previous[0] + pair[0],
                            previous[1] + pair[1],
                        )
                year_values[year] = channel_values

            current = year_values.get(current_year, {}) if current_year is not None else {}
            compare = year_values.get(compare_year, {}) if compare_year is not None else {}
            for channel_row, channel_name in COMPARISON_CHANNELS:
                monthly_sheet.append(
                    _channel_export_row(
                        calendar.month_name[month],
                        outlet,
                        channel_name,
                        current.get(channel_row),
                        compare.get(channel_row),
                    )
                )
            monthly_sheet.append(
                _channel_export_row(
                    calendar.month_name[month],
                    outlet,
                    "Grand Total",
                    _sum_channel_values(current.values()),
                    _sum_channel_values(compare.values()),
                )
            )
            monthly_sheet.append(
                _channel_export_row(
                    calendar.month_name[month],
                    outlet,
                    "Total Net sale & GCs",
                    (
                        _report_net_total_value(report, outlet, current_year, month)
                        if current_year is not None
                        else None
                    ),
                    (
                        _report_net_total_value(report, outlet, compare_year, month)
                        if compare_year is not None
                        else None
                    ),
                    (
                        _report_discount_total_value(report, outlet, current_year, month)
                        if current_year is not None
                        else None
                    ),
                    (
                        _report_discount_total_value(report, outlet, compare_year, month)
                        if compare_year is not None
                        else None
                    ),
                    (
                        _report_total_with_discount_value(report, outlet, current_year, month)
                        if current_year is not None
                        else None
                    ),
                    (
                        _report_total_with_discount_value(report, outlet, compare_year, month)
                        if compare_year is not None
                        else None
                    ),
                )
            )

    annual_sheet = workbook.create_sheet(annual_title)
    annual_headers = headers[1:]
    annual_sheet.append(["Annual channel comparison"])
    annual_sheet.append(
        [
            "Current year",
            current_year,
            "Compare year",
            compare_year,
            "Branches",
            len(report.outlets),
        ]
    )
    annual_sheet.append([])
    annual_sheet.append(annual_headers)
    annual_groups: list[tuple[str, dict[int, SalesAndBills], dict[int, SalesAndBills]]] = []
    all_current = _aggregate_branch_channel_values(annual_values, current_year)
    all_compare = _aggregate_branch_channel_values(annual_values, compare_year)
    annual_groups.append(("All branches", all_current, all_compare))
    annual_groups.extend(
        (
            outlet,
            annual_values.get((outlet, current_year), {}) if current_year else {},
            annual_values.get((outlet, compare_year), {}) if compare_year else {},
        )
        for outlet in sorted(report.outlets)
    )
    for outlet, current, compare in annual_groups:
        for channel_row, channel_name in COMPARISON_CHANNELS:
            annual_sheet.append(
                _channel_export_row(
                    "",
                    outlet,
                    channel_name,
                    current.get(channel_row),
                    compare.get(channel_row),
                )[1:]
            )
        annual_sheet.append(
            _channel_export_row(
                "",
                outlet,
                "Grand Total",
                _sum_channel_values(current.values()),
                _sum_channel_values(compare.values()),
            )[1:]
        )
        current_net = (
            _aggregate_branch_net_totals(annual_net_values, current_year)
            if outlet == "All branches"
            else annual_net_values.get((outlet, current_year)) if current_year is not None else None
        )
        compare_net = (
            _aggregate_branch_net_totals(annual_net_values, compare_year)
            if outlet == "All branches"
            else annual_net_values.get((outlet, compare_year)) if compare_year is not None else None
        )
        current_discount = (
            sum(
                (
                    amount
                    for (_, data_year), amount in annual_discount_values.items()
                    if data_year == current_year
                ),
                Decimal(0),
            )
            if outlet == "All branches"
            else (
                annual_discount_values.get((outlet, current_year))
                if current_year is not None
                else None
            )
        )
        compare_discount = (
            sum(
                (
                    amount
                    for (_, data_year), amount in annual_discount_values.items()
                    if data_year == compare_year
                ),
                Decimal(0),
            )
            if outlet == "All branches"
            else (
                annual_discount_values.get((outlet, compare_year))
                if compare_year is not None
                else None
            )
        )
        current_total_with_discount = (
            current_net[0] + (current_discount or Decimal(0)) if current_net is not None else None
        )
        compare_total_with_discount = (
            compare_net[0] + (compare_discount or Decimal(0)) if compare_net is not None else None
        )
        annual_sheet.append(
            _channel_export_row(
                "",
                outlet,
                "Total Net sale & GCs",
                current_net,
                compare_net,
                current_discount,
                compare_discount,
                current_total_with_discount,
                compare_total_with_discount,
            )[1:]
        )

    _format_channel_export_sheet(monthly_sheet, monthly=True)
    _format_channel_export_sheet(annual_sheet, monthly=False)


def _aggregate_branch_channel_values(
    annual_values: dict[tuple[str, int], dict[int, SalesAndBills]],
    year: int | None,
) -> dict[int, SalesAndBills]:
    if year is None:
        return {}
    totals: dict[int, SalesAndBills] = {}
    for (_, data_year), channels in annual_values.items():
        if data_year != year:
            continue
        for channel_row, pair in channels.items():
            previous = totals.get(channel_row, (Decimal(0), 0))
            totals[channel_row] = (previous[0] + pair[0], previous[1] + pair[1])
    return totals


def _aggregate_branch_net_totals(
    annual_values: dict[tuple[str, int], SalesAndBills],
    year: int | None,
) -> SalesAndBills | None:
    if year is None:
        return None
    values = [pair for (_, data_year), pair in annual_values.items() if data_year == year]
    if not values:
        return None
    return (
        sum((pair[0] for pair in values), Decimal(0)),
        sum(pair[1] for pair in values),
    )


def _report_net_total_value(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
) -> SalesAndBills | None:
    return report_net_total_value(report, outlet, year, month)


def _report_discount_total_value(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
) -> Decimal | None:
    branch_month = (outlet, year, month)
    if branch_month in report.monthly_discounts.get("Sourcewise", {}):
        return report.monthly_discounts["Sourcewise"][branch_month]
    if branch_month in report.monthly_discounts.get("Tabwise", {}):
        return report.monthly_discounts["Tabwise"][branch_month]
    return None


def _report_total_with_discount_value(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
) -> Decimal | None:
    net_total = _report_net_total_value(report, outlet, year, month)
    if net_total is None:
        return None
    discount = _report_discount_total_value(report, outlet, year, month) or Decimal(0)
    return net_total[0] + discount


def _report_channel_value(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
    channel_row: int,
    values: dict[int, SalesAndBills],
) -> SalesAndBills | None:
    branch_month = (outlet, year, month)
    tabwise_exists = branch_month in report.monthly_totals["Tabwise"]
    sourcewise_exists = branch_month in report.monthly_totals["Sourcewise"]
    if 3 <= channel_row <= 7 and not tabwise_exists:
        return None
    if channel_row == 9 and not (tabwise_exists or sourcewise_exists):
        return None
    if channel_row == 17 and not tabwise_exists:
        return None
    if 10 <= channel_row <= 16 and not sourcewise_exists:
        return None
    return values.get(channel_row, (Decimal(0), 0))


def _sum_channel_values(values: Iterable[SalesAndBills]) -> SalesAndBills | None:
    pairs = list(values)
    if not pairs:
        return None
    return (
        sum((pair[0] for pair in pairs), Decimal(0)),
        sum(pair[1] for pair in pairs),
    )


def _channel_export_row(
    month: str,
    outlet: str,
    channel_name: str,
    current: SalesAndBills | None,
    compare: SalesAndBills | None,
    current_discount: Decimal | None = None,
    compare_discount: Decimal | None = None,
    current_total_with_discount: Decimal | None = None,
    compare_total_with_discount: Decimal | None = None,
) -> tuple[ExcelCellValue, ...]:
    current_sales = current[0] if current is not None else None
    compare_sales = compare[0] if compare is not None else None
    current_gc = current[1] if current is not None else None
    compare_gc = compare[1] if compare is not None else None
    sales_difference = (
        current_sales - compare_sales
        if current_sales is not None and compare_sales is not None
        else None
    )
    gc_difference = (
        current_gc - compare_gc if current_gc is not None and compare_gc is not None else None
    )
    sales_percent = (
        float(sales_difference / compare_sales)
        if sales_difference is not None and compare_sales
        else None
    )
    gc_percent = (
        float(gc_difference / compare_gc) if gc_difference is not None and compare_gc else None
    )
    current_apc = current_sales / current_gc if current_sales is not None and current_gc else None
    compare_apc = compare_sales / compare_gc if compare_sales is not None and compare_gc else None
    return (
        month,
        outlet,
        channel_name,
        current_sales,
        compare_sales,
        sales_difference,
        sales_percent,
        current_gc,
        compare_gc,
        gc_difference,
        gc_percent,
        current_apc,
        compare_apc,
        current_discount,
        compare_discount,
        current_total_with_discount,
        compare_total_with_discount,
    )


def _format_channel_export_sheet(sheet: Worksheet, *, monthly: bool) -> None:
    header_row = 4
    last_column = 17 if monthly else 16
    sheet.freeze_panes = "D5" if monthly else "C5"
    sheet.auto_filter.ref = f"A{header_row}:{get_column_letter(last_column)}{sheet.max_row}"
    sheet.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_column)
    sheet["A1"].font = Font(name="Aptos Display", size=16, bold=True, color="FFFFFF")
    sheet["A1"].fill = PatternFill("solid", fgColor="174D73")
    sheet["A1"].alignment = Alignment(vertical="center")
    sheet.row_dimensions[1].height = 30
    for cell in sheet[header_row]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1D5C85")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    sheet.row_dimensions[header_row].height = 32
    widths = (
        [14, 18, 20, 16, 16, 16, 14, 13, 13, 13, 12, 15, 15, 16, 16, 18, 18]
        if monthly
        else [18, 20, 16, 16, 16, 14, 13, 13, 13, 12, 15, 15, 16, 16, 18, 18]
    )
    for column, width in enumerate(widths, start=1):
        sheet.column_dimensions[get_column_letter(column)].width = width
    for row in range(header_row + 1, sheet.max_row + 1):
        row_label = sheet.cell(row, 3 if monthly else 2).value
        if row_label in {"Grand Total", "Total Net sale & GCs"}:
            color = "FFF2B3" if row_label == "Grand Total" else "DCEFE7"
            for cell in sheet[row]:
                cell.fill = PatternFill("solid", fgColor=color)
                cell.font = Font(bold=True, color="183A56")
        for column in range(4 if monthly else 3, last_column + 1):
            cell = sheet.cell(row, column)
            if column in ((7, 11) if monthly else (6, 10)):
                cell.number_format = "0.0%;[Red]-0.0%"
            elif column in ((8, 9, 10) if monthly else (7, 8, 9)):
                cell.number_format = "#,##0;[Red]-#,##0"
            else:
                cell.number_format = "#,##0.00;[Red]-#,##0.00"
            cell.alignment = Alignment(horizontal="right")
        if (
            row > header_row
            and row_label not in {"Grand Total", "Total Net sale & GCs"}
            and row % 2
        ):
            for cell in sheet[row]:
                cell.fill = PatternFill("solid", fgColor="F4F7FA")
    for cell in sheet[2]:
        cell.font = Font(color="53647A", italic=True)


def _dashboard_sheet_for_outlet(outlet: str) -> str:
    match = re.search(r"(\d+)\s*$", outlet)
    if match is None:
        raise ValueError(f"Could not identify a HERFY branch number in outlet name {outlet!r}.")
    return f"Herfy {int(match.group(1))}"


def _dashboard_branch_number(sheet_name: str) -> int:
    return int(sheet_name.removeprefix("Herfy "))


def _write_dashboard_branch_sheet(
    sheet: Worksheet,
    outlet: str,
    years: list[int],
    report: ValidationReport,
) -> None:
    branch_number = _dashboard_branch_number(_dashboard_sheet_for_outlet(outlet))
    sheet["A1"] = f"H-{branch_number}"
    sheet["H2"] = f"H-{branch_number}"
    channel_sales_columns = (3, 5, 7, 9, 11, 13, 15, 17, 19, 23, 33)
    for month in range(1, MONTH_COUNT + 1):
        first_row = KPI_MONTH_ROW_START + (month - 1) * KPI_MONTH_ROW_SPACING
        _set_cell_value(sheet, first_row, 1, calendar.month_name[month])
        for year_index in range(2):
            row = first_row + year_index
            year = years[year_index] if year_index < len(years) else None
            _set_cell_value(sheet, row, 2, year)
            for sales_column in channel_sales_columns:
                _set_cell_value(sheet, row, sales_column, None)
                _set_cell_value(sheet, row, sales_column + 1, None)
            if year is None:
                continue

            branch_month = (outlet, year, month)
            tabwise_present = branch_month in report.monthly_totals["Tabwise"]
            sourcewise_present = branch_month in report.monthly_totals["Sourcewise"]
            values = _dashboard_monthly_channels(report, outlet, year, month)
            for sales_column in (3, 5, 7, 9, 11, 21, 23):
                if tabwise_present:
                    sales, bills = values.get(sales_column, (Decimal(0), 0))
                    _set_cell_value(sheet, row, sales_column, sales)
                    _set_cell_value(sheet, row, sales_column + 1, bills)
            if tabwise_present or sourcewise_present:
                sales, bills = values.get(13, (Decimal(0), 0))
                _set_cell_value(sheet, row, 13, sales)
                _set_cell_value(sheet, row, 14, bills)
            if sourcewise_present:
                for sales_column in (15, 17, 19, 33):
                    sales, bills = values.get(sales_column, (Decimal(0), 0))
                    _set_cell_value(sheet, row, sales_column, sales)
                    _set_cell_value(sheet, row, sales_column + 1, bills)


def _dashboard_monthly_channels(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
) -> dict[int, SalesAndBills]:
    branch_month = (outlet, year, month)
    visible: dict[int, SalesAndBills] = {}
    tabwise_categories = report.monthly_categories["Tabwise"]
    tabwise_has_hs = any(
        key[:3] == branch_month and _normalize_category(key[3]) == "hs"
        for key in tabwise_categories
    )
    for (branch, data_year, data_month, category), value in tabwise_categories.items():
        if (branch, data_year, data_month) != branch_month:
            continue
        column = DASHBOARD_CHANNEL_COLUMNS.get(_normalize_category(category))
        if column is not None:
            visible[column] = _sum_pair(visible.get(column), value)

    for (branch, data_year, data_month, category), value in report.monthly_categories[
        "Sourcewise"
    ].items():
        if (branch, data_year, data_month) != branch_month:
            continue
        normalized = _normalize_category(category)
        if normalized == "hungerstation":
            if not tabwise_has_hs:
                visible[13] = _sum_pair(visible.get(13), value)
            continue
        if normalized in {"jahez", "posccjahez"}:
            column = 15
        elif normalized == "keeta":
            column = 17
        elif normalized == "toyou":
            column = 19
        elif normalized in DASHBOARD_OTHER_APP_CATEGORIES:
            column = 33
        else:
            continue
        visible[column] = _sum_pair(visible.get(column), value)
    return visible


def _set_dashboard_filters(
    workbook: Workbook,
    branch_sheets: list[str],
    years: list[int],
    report: ValidationReport,
) -> None:
    dashboard = workbook["Management Dashboard"]
    dashboard["B3"] = "All Branches"
    dashboard["B4"] = "TOTAL"
    dashboard["B5"] = years[0]
    dashboard["B6"] = years[1] if len(years) > 1 else None
    all_months = [month for months in report.months_by_year.values() for month in months]
    if all_months:
        dashboard["B7"] = calendar.month_name[min(all_months)]
        dashboard["B8"] = calendar.month_name[max(all_months)]

    lists_sheet = workbook["_KPI_LISTS"]
    for row in range(2, lists_sheet.max_row + 1):
        _set_cell_value(lists_sheet, row, 1, None)
    for row, value in enumerate(["All Branches", *branch_sheets], start=2):
        _set_cell_value(lists_sheet, row, 1, value)


def _rebuild_kpi_data_sheet(
    workbook: Workbook,
    source_sheet_name: str,
    branch_sheets: list[str],
) -> None:
    data_sheet = workbook["_KPI_DATA"]
    source_rows = [
        [(cell.value, cell._style, cell.number_format) for cell in row]
        for row in data_sheet.iter_rows(
            min_row=2,
            max_row=data_sheet.max_row,
            min_col=1,
            max_col=12,
        )
        if row[0].value == source_sheet_name
    ]
    if len(source_rows) != KPI_DATA_ROWS_PER_BRANCH:
        raise ValueError(
            f"Dashboard template has {len(source_rows)} KPI rows for {source_sheet_name}; "
            f"expected {KPI_DATA_ROWS_PER_BRANCH}."
        )

    data_sheet.delete_rows(2, data_sheet.max_row - 1)
    for branch_sheet_name in branch_sheets:
        branch_number = _dashboard_branch_number(branch_sheet_name)
        for source_index, source_row in enumerate(source_rows):
            target_row = data_sheet.max_row + 1
            for column, (value, style, number_format) in enumerate(source_row, start=1):
                cell = data_sheet.cell(target_row, column)
                if isinstance(cell, MergedCell):
                    raise TypeError(
                        f"Cannot populate merged KPI data cell {data_sheet.title}!{cell.coordinate}."
                    )
                if column == 1:
                    cell.value = branch_sheet_name
                elif column == 2:
                    cell.value = branch_number
                elif isinstance(value, str) and value.startswith("="):
                    if column in (10, 12):
                        origin = data_sheet.cell(source_index + 2, column).coordinate
                        value = Translator(value, origin=origin).translate_formula(cell.coordinate)
                    value = value.replace(
                        f"'{source_sheet_name}'!",
                        f"'{branch_sheet_name}'!",
                    )
                    cell.value = value
                else:
                    cell.value = value
                if style:
                    cell._style = copy.copy(style)
                cell.number_format = number_format


def _expand_dashboard_formula_ranges(workbook: Workbook, branch_count: int) -> None:
    data_last_row = 1 + branch_count * KPI_DATA_ROWS_PER_BRANCH
    list_last_row = branch_count + 2
    for sheet in workbook.worksheets:
        for row in sheet.iter_rows():
            for cell in row:
                if isinstance(cell, MergedCell):
                    continue
                value = cell.value
                if isinstance(value, str) and value.startswith("=") and "5041" in value:
                    cell.value = value.replace("5041", str(data_last_row))
    for defined_name in workbook.defined_names.values():
        if "5041" in defined_name.attr_text:
            defined_name.attr_text = defined_name.attr_text.replace("5041", str(data_last_row))
        if "_KPI_LISTS!$A$1:$E$16" in defined_name.attr_text:
            defined_name.attr_text = defined_name.attr_text.replace(
                "$E$16", f"$E${max(16, list_last_row)}"
            )


def _restore_template_extensions(
    template: Path,
    edited: Path,
    output: Path,
    branch_count: int,
) -> None:
    branch_list_last_row = branch_count + 2
    with ZipFile(template) as original, ZipFile(edited) as changed:
        original_names = set(original.namelist())
        updated_parts: dict[str, bytes] = {}
        for name in original_names & set(changed.namelist()):
            if not name.endswith(".xml"):
                continue
            original_xml = original.read(name)
            if b"<extLst" not in original_xml:
                continue
            changed_xml = changed.read(name)
            original_root = _parse_excel_xml(original_xml)
            changed_root = _parse_excel_xml(changed_xml)
            original_extensions = next(
                (child for child in original_root if child.tag.endswith("extLst")),
                None,
            )
            if original_extensions is None:
                continue
            replacement = ElementTree.fromstring(ElementTree.tostring(original_extensions))
            for formula in replacement.iter():
                if formula.tag.endswith("formula1") and formula.text:
                    formula.text = formula.text.replace(
                        "_KPI_LISTS!$A$2:$A$16",
                        f"_KPI_LISTS!$A$2:$A${branch_list_last_row}",
                    )
            for child in list(changed_root):
                if child.tag.endswith("extLst"):
                    changed_root.remove(child)
            changed_root.append(replacement)
            updated_parts[name] = ElementTree.tostring(
                changed_root,
                encoding="utf-8",
                xml_declaration=True,
            )

        with ZipFile(output, "w", ZIP_DEFLATED) as result:
            for item in changed.infolist():
                content = updated_parts.get(item.filename)
                if content is None:
                    content = changed.read(item.filename)
                result.writestr(item, content)


def _parse_excel_xml(content: bytes) -> ElementTree.Element:
    for _, namespace in ElementTree.iterparse(io.BytesIO(content), events=("start-ns",)):
        prefix, uri = namespace
        ElementTree.register_namespace(prefix or "", uri)
    return ElementTree.fromstring(content)


def _fill_outlet_sheet(
    sheet: Worksheet,
    outlet: str,
    years: list[int],
    report: ValidationReport,
) -> None:
    data_sheet = sheet
    _clear_copied_analysis(data_sheet, outlet, years, report)
    for month in range(1, MONTH_COUNT + 1):
        header_row = MONTH_ROW_START + (month - 1) * MONTH_ROW_SPACING
        _set_year_headers(data_sheet, header_row, years)
        for year_index, year in enumerate(years):
            sales_column, prior_sales_column, current_gc_column, prior_gc_column = INPUT_COLUMNS
            sales_columns = [sales_column, prior_sales_column]
            gc_columns = [current_gc_column, prior_gc_column]
            value_column = sales_columns[year_index]
            gc_column = gc_columns[year_index]
            _write_month_values(data_sheet, outlet, year, month, value_column, gc_column, report)

        absent_year_columns = [4, 8] if len(years) == 1 else []
        for row in [
            *range(header_row + 1, header_row + 7),
            *range(header_row + 7, header_row + 15),
        ]:
            for column in absent_year_columns:
                _set_cell_value(data_sheet, row, column, None)
        total_row = header_row + 16
        for row in (header_row + 15, total_row):
            for column in absent_year_columns:
                _set_cell_value(data_sheet, row, column, None)

    ytd_row = MONTH_ROW_START + MONTH_COUNT * MONTH_ROW_SPACING
    _set_year_headers(data_sheet, ytd_row, years)
    if len(years) == 1:
        for row in range(ytd_row + 1, ytd_row + 17):
            for column in (4, 8):
                _set_cell_value(data_sheet, row, column, None)
    _write_ytd_channel_totals(data_sheet, outlet, years, report)

    if outlet:
        _set_cell_value(data_sheet, 1, 1, outlet)


def _write_month_values(
    sheet: Worksheet,
    outlet: str,
    year: int,
    month: int,
    sales_column: int,
    bills_column: int,
    report: ValidationReport,
) -> None:
    header_row = MONTH_ROW_START + (month - 1) * MONTH_ROW_SPACING
    branch_month = (outlet, year, month)
    tabwise_present = branch_month in report.monthly_totals["Tabwise"]
    sourcewise_present = branch_month in report.monthly_totals["Sourcewise"]
    visible = comparison_channel_values(report, outlet, year, month)

    for row in [
        *range(header_row + 1, header_row + 7),
        *range(header_row + 7, header_row + 15),
    ]:
        template_row = row - header_row + MONTH_ROW_START
        channel_row = 17 if template_row == 8 else template_row
        has_category_source = (
            (template_row == 8 and tabwise_present)
            or (template_row == 9 and tabwise_present)
            or (3 <= template_row <= 7 and tabwise_present)
            or (10 <= template_row <= 16 and sourcewise_present)
        )
        sales, bills = visible.get(channel_row, (Decimal(0), 0))
        _set_cell_value(sheet, row, sales_column, sales if has_category_source else None)
        _set_cell_value(sheet, row, bills_column, bills if has_category_source else None)

    channel_total = _sum_channel_values(
        pair
        for channel_row, _ in COMPARISON_CHANNELS
        if (
            pair := _report_channel_value(
                report,
                outlet,
                year,
                month,
                channel_row,
                visible,
            )
        )
        is not None
    )
    grand_total_row = header_row + 15
    _set_cell_value(
        sheet,
        grand_total_row,
        sales_column,
        channel_total[0] if channel_total is not None else None,
    )
    _set_cell_value(
        sheet,
        grand_total_row,
        bills_column,
        channel_total[1] if channel_total is not None else None,
    )
    total = report_net_total_value(report, outlet, year, month)
    total_row = header_row + 16
    _set_cell_value(
        sheet,
        total_row,
        sales_column,
        total[0] if total is not None else None,
    )
    _set_cell_value(sheet, total_row, bills_column, total[1] if total is not None else None)


def _write_ytd_channel_totals(
    sheet: Worksheet,
    outlet: str,
    years: list[int],
    report: ValidationReport,
) -> None:
    ytd_row = MONTH_ROW_START + MONTH_COUNT * MONTH_ROW_SPACING
    for year_index, year in enumerate(years):
        sales_column, prior_sales_column, current_gc_column, prior_gc_column = INPUT_COLUMNS
        sales_column = (sales_column, prior_sales_column)[year_index]
        bills_column = (current_gc_column, prior_gc_column)[year_index]
        channels: dict[int, SalesAndBills] = {}
        for month in range(1, MONTH_COUNT + 1):
            values = comparison_channel_values(report, outlet, year, month)
            for channel_row, _ in COMPARISON_CHANNELS:
                pair = _report_channel_value(
                    report,
                    outlet,
                    year,
                    month,
                    channel_row,
                    values,
                )
                if pair is not None:
                    channels[channel_row] = _sum_pair(channels.get(channel_row), pair)
        mb_total = channels.get(17)
        _set_cell_value(
            sheet,
            ytd_row + 6,
            sales_column,
            mb_total[0] if mb_total is not None else None,
        )
        _set_cell_value(
            sheet,
            ytd_row + 6,
            bills_column,
            mb_total[1] if mb_total is not None else None,
        )
        grand_total = _sum_channel_values(channels.values())
        _set_cell_value(
            sheet,
            ytd_row + 15,
            sales_column,
            grand_total[0] if grand_total is not None else None,
        )
        _set_cell_value(
            sheet,
            ytd_row + 15,
            bills_column,
            grand_total[1] if grand_total is not None else None,
        )
        report_total = sum_report_net_totals(report, [outlet], year)
        _set_cell_value(
            sheet,
            ytd_row + 16,
            sales_column,
            report_total[0] if report_total is not None else None,
        )
        _set_cell_value(
            sheet,
            ytd_row + 16,
            bills_column,
            report_total[1] if report_total is not None else None,
        )


def _is_mapped_category(report_kind: str, category: str, layout: str) -> bool:
    represented_elsewhere = {
        "Tabwise": {"aggregators"},
        "Sourcewise": {"pos", "poscc", "herfymobileapp", "herfywebapp", "herfykiosk"},
    }
    tabwise_mapped = (
        set(DASHBOARD_CHANNEL_COLUMNS) if layout == "dashboard" else set(TABWISE_CHANNEL_ROWS)
    )
    mapped_categories = {
        "Tabwise": tabwise_mapped,
        "Sourcewise": set(SOURCEWISE_AGGREGATOR_ROWS)
        | (DASHBOARD_OTHER_APP_CATEGORIES if layout == "dashboard" else set()),
    }
    normalized = _normalize_category(category)
    return (
        normalized in mapped_categories[report_kind]
        or normalized in represented_elsewhere[report_kind]
    )


def _unmapped_category_totals(
    report: ValidationReport,
    layout: str = "comparison",
) -> list[tuple[str, str, Decimal, int]]:
    totals: dict[tuple[str, str], SalesAndBills] = {}
    for report_kind, categories in report.monthly_categories.items():
        for (_, _, _, category), value in categories.items():
            if _is_mapped_category(report_kind, category, layout):
                continue
            key = (report_kind, category)
            totals[key] = _sum_pair(totals.get(key), value)
    return [
        (report_kind, category, amount[0], amount[1])
        for (report_kind, category), amount in sorted(totals.items())
        if amount[0] != 0 or amount[1] != 0
    ]


def _channel_total_mismatches(
    report: ValidationReport,
    layout: str = "comparison",
) -> list[tuple[str, int, int, Decimal, Decimal, Decimal, str]]:
    mismatches: list[tuple[str, int, int, Decimal, Decimal, Decimal, str]] = []
    tabwise_categories = report.monthly_categories["Tabwise"]
    for outlet, year, month in sorted(
        set(report.monthly_totals["Tabwise"]) & set(report.monthly_totals["Sourcewise"])
    ):
        if layout == "dashboard":
            channels = _dashboard_monthly_channels(report, outlet, year, month)
            channel_total = sum((value[0] for value in channels.values()), Decimal(0))
        else:
            channels = comparison_channel_values(report, outlet, year, month)
            channel_total = sum((value[0] for value in channels.values()), Decimal(0))
        net_total = report.monthly_totals["Sourcewise"][(outlet, year, month)][0]
        difference = channel_total - net_total
        if difference == 0:
            continue
        unmapped = sorted(
            {
                category
                for (branch, data_year, data_month, category), value in tabwise_categories.items()
                if (branch, data_year, data_month) == (outlet, year, month)
                and not _is_mapped_category("Tabwise", category, layout)
                and (value[0] != 0 or value[1] != 0)
            }
        )
        mismatches.append(
            (outlet, year, month, channel_total, net_total, difference, ", ".join(unmapped))
        )
    return mismatches


def _set_reporting_years(workbook: Workbook, years: list[int]) -> None:
    current, previous = years[0], years[1] if len(years) > 1 else None
    for sheet in workbook.worksheets:
        for month in range(MONTH_COUNT + 1):
            row = MONTH_ROW_START + month * MONTH_ROW_SPACING
            _set_year_headers(sheet, row, years)
    workbook.properties.title = (
        f"Sale Comparison by Channel {current} vs {previous or 'No Prior Year'}"
    )


def _set_year_headers(sheet: Worksheet, header_row: int, years: list[int]) -> None:
    current, previous = years[0], years[1] if len(years) > 1 else None
    for column, year in ((3, current), (4, previous), (7, current), (8, previous)):
        if year is None:
            label = "No Prior Year"
        elif column in (3, 4):
            label = f"{year} Sales"
        else:
            label = f"Total GC {year}"
        _set_cell_value(sheet, header_row, column, label)


def _workbook_sheet_for_outlet(outlet: str) -> str | None:
    match = re.search(r"(\d+)\s*$", outlet)
    if match is None:
        return None
    branch_number = int(match.group(1))
    if branch_number < 1000:
        return None
    return f"H-{branch_number - 1000}"


def _sheet_number(sheet_name: str) -> int:
    return int(sheet_name.removeprefix("H-"))


def _clear_copied_analysis(
    sheet: Worksheet,
    outlet: str,
    years: list[int],
    report: ValidationReport,
) -> None:
    for row in range(225, 237):
        _set_cell_value(sheet, row, 1, None)
        _set_cell_value(sheet, row, 2, None)
    for row in range(240, 245):
        _set_cell_value(sheet, row, 1, None)
        _set_cell_value(sheet, row, 2, None)
    _set_cell_value(sheet, 224, 1, "Sales movement summary")
    current_year = years[0]
    prior_year = years[1] if len(years) > 1 else None
    for month in range(1, 13):
        row = 224 + month
        current = report.monthly_totals["Sourcewise"].get((outlet, current_year, month))
        previous = (
            report.monthly_totals["Sourcewise"].get((outlet, prior_year, month))
            if prior_year is not None
            else None
        )
        if current is None and previous is None:
            continue
        _set_cell_value(sheet, row, 1, calendar.month_name[month])
        if current is None or previous is None:
            _set_cell_value(
                sheet,
                row,
                2,
                "Comparison unavailable: one year of outlet data is missing.",
            )
            continue
        difference = current[0] - previous[0]
        if previous[0] == 0:
            percentage = "N/A (no prior-year sales)"
        else:
            percentage = f"{difference / previous[0]:+.1%}"
        _set_cell_value(
            sheet,
            row,
            2,
            f"Net sales {percentage} ({difference:,.2f}) compared with {prior_year}.",
        )
    _set_cell_value(sheet, 245, 1, "Data note")
    _set_cell_value(
        sheet,
        245,
        2,
        "Values and movement summary generated from the imported CSV files. "
        "Sales and bill values are extracted from the imported CSV reports.",
    )


def _write_data_quality_sheet(
    sheet: Worksheet,
    report: ValidationReport,
    layout: str = "comparison",
) -> None:
    sheet.title = "Data Quality"
    _set_cell_value(sheet, 1, 1, "HERFY Sales Report — Import Validation")
    sheet["A1"].font = Font(size=16, bold=True, color="FFFFFF")
    sheet["A1"].fill = PatternFill("solid", fgColor="17365D")
    sheet.merge_cells("A1:H1")
    summary = [
        ("Source files", len(report.files)),
        ("Branches discovered", len(report.outlets)),
        ("Outlet-days extracted", report.branch_days_extracted),
        ("Reconciliation available", "Yes" if report.comparison_available else "No"),
        ("Branch-days checked", report.branch_days_checked),
        ("Reconciled", report.branch_days_reconciled),
        ("Issues surfaced", len(report.issues)),
        (
            "Data quality",
            f"{report.data_quality_score}/100" if report.data_quality_score is not None else "N/A",
        ),
        ("Rows skipped (missing/invalid outlet or date)", report.skipped_rows),
        ("Recovered blank Net Sale values", report.recovered_net_sales),
        ("Months missing a report type", ", ".join(report.unpaired_months) or "None"),
        ("Overlapping alternatives not selected", len(report.excluded_files)),
        ("Unmapped sales categories", len(_unmapped_category_totals(report, layout))),
        (
            "Monthly channel-total differences",
            len(_channel_total_mismatches(report, layout)),
        ),
    ]
    for row, (label, value) in enumerate(summary, start=3):
        _set_cell_value(sheet, row, 1, label)
        sheet.cell(row, 1).font = Font(bold=True)
        _set_cell_value(sheet, row, 2, value)

    source_row = max(16, 3 + len(summary) + 2)
    _set_cell_value(sheet, source_row, 1, "Input files")
    sheet.cell(source_row, 1).font = Font(bold=True, color="FFFFFF")
    for column in range(1, 5):
        sheet.cell(source_row, column).fill = PatternFill("solid", fgColor="17365D")
    for offset, file in enumerate(report.files, start=source_row + 1):
        values = [
            file.report_kind,
            file.path.name,
            file.rows_read,
            _date_range(file.dates),
        ]
        for column, value in enumerate(values, start=1):
            _set_cell_value(sheet, offset, column, value)

    excluded_row = source_row + len(report.files) + 2
    if report.excluded_files:
        _set_cell_value(sheet, excluded_row, 1, "Overlapping alternate files not selected")
        sheet.cell(excluded_row, 1).font = Font(bold=True, color="FFFFFF")
        for column in range(1, 5):
            sheet.cell(excluded_row, column).fill = PatternFill("solid", fgColor="7F6000")
        for offset, file in enumerate(report.excluded_files, start=excluded_row + 1):
            values = [
                f"{file.report_kind} — excluded alternate",
                file.path.name,
                file.rows_read,
                _date_range(file.dates),
            ]
            for column, value in enumerate(values, start=1):
                _set_cell_value(sheet, offset, column, value)

    unmapped = _unmapped_category_totals(report, layout)
    unmapped_header_row = excluded_row + len(report.excluded_files) + 2
    if unmapped:
        _set_cell_value(sheet, unmapped_header_row, 1, "Unmapped sales categories")
        sheet.cell(unmapped_header_row, 1).font = Font(bold=True, color="FFFFFF")
        for column in range(1, 5):
            sheet.cell(unmapped_header_row, column).fill = PatternFill("solid", fgColor="9C0006")
        for row, (kind, category, sales, bills) in enumerate(
            unmapped, start=unmapped_header_row + 1
        ):
            for column, value in enumerate((kind, category, sales, bills), start=1):
                _set_cell_value(sheet, row, column, value)
            sheet.cell(row, 3).number_format = "#,##0.00"
    next_section_row = unmapped_header_row + len(unmapped) + 2

    channel_mismatches = _channel_total_mismatches(report, layout)
    if channel_mismatches:
        _set_cell_value(sheet, next_section_row, 1, "Monthly channel totals vs Total Net Sale")
        sheet.cell(next_section_row, 1).font = Font(bold=True, color="FFFFFF")
        for column in range(1, 8):
            sheet.cell(next_section_row, column).fill = PatternFill("solid", fgColor="9C0006")
        channel_headers = [
            "Outlet",
            "Year",
            "Month",
            "Channel total",
            "Total Net Sale",
            "Difference",
            "Unmapped Tabwise categories",
        ]
        for column, label in enumerate(channel_headers, start=1):
            _set_cell_value(sheet, next_section_row + 1, column, label)
            sheet.cell(next_section_row + 1, column).font = Font(bold=True)
            sheet.cell(next_section_row + 1, column).alignment = Alignment(wrap_text=True)
        for row, values in enumerate(channel_mismatches, start=next_section_row + 2):
            for column, value in enumerate(values, start=1):
                _set_cell_value(sheet, row, column, value)
            for column in (4, 5, 6):
                sheet.cell(row, column).number_format = "#,##0.00"
    next_section_row += len(channel_mismatches) + (2 if channel_mismatches else 0)

    issue_header_row = max(
        source_row + len(report.files) + 3,
        excluded_row + len(report.excluded_files) + 2,
        next_section_row + 1,
    )
    headers = [
        "Date",
        "Outlet",
        "Issue",
        "Tabwise Net Sale",
        "Sourcewise Net Sale",
        "Difference",
        "Tabwise Bills",
        "Sourcewise Bills",
    ]
    for column, label in enumerate(headers, start=1):
        cell = sheet.cell(issue_header_row, column, label)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="17365D")
        cell.alignment = Alignment(wrap_text=True)
    for row_number, issue in enumerate(report.issues, start=issue_header_row + 1):
        values = [
            issue.business_date,
            issue.outlet,
            "; ".join(issue.reasons),
            issue.tabwise_sales,
            issue.sourcewise_sales,
            issue.sales_difference,
            issue.tabwise_bills,
            issue.sourcewise_bills,
        ]
        for column, value in enumerate(values, start=1):
            sheet.cell(row_number, column, value)
        for column in (4, 5, 6):
            sheet.cell(row_number, column).number_format = "#,##0.00"
        sheet.cell(row_number, 1).number_format = "yyyy-mm-dd"

    widths = [16, 24, 42, 20, 22, 18, 18, 20]
    for index, width in enumerate(widths, start=1):
        sheet.column_dimensions[get_column_letter(index)].width = width
    sheet.freeze_panes = f"A{issue_header_row + 1}"
    sheet.auto_filter.ref = f"A{issue_header_row}:H{issue_header_row + len(report.issues)}"


def _date_range(values: set) -> str:
    if not values:
        return "No valid dates"
    return f"{min(values).isoformat()} to {max(values).isoformat()}"


def _set_cell_value(
    sheet: Worksheet,
    row: int,
    column: int,
    value: ExcelCellValue,
) -> None:
    cell = sheet.cell(row=row, column=column)
    if isinstance(cell, MergedCell):
        raise TypeError(f"Cannot populate merged template cell {sheet.title}!{cell.coordinate}.")
    cell.value = value
