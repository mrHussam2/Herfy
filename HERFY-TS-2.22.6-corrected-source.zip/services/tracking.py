from __future__ import annotations

import logging
from collections import deque
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import date, datetime, timezone
from threading import RLock
from typing import Any

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import (
    CommitResult,
    RemoteTrackingId,
    TrackingBaseline,
    TrackingDelta,
    TrackingKey,
    TrackingRecord,
    TrackingScope,
    TrackingSnapshot,
    TrackingStoreEvent,
    deduplicate_tracking_records,
    looks_like_material_code,
    normalize_int,
    normalize_remote_id,
    tracking_record_from_row,
    tracking_record_identity_keys,
    tracking_row_text,
)
from core.models import (
    clean_text as _text,
)
from core.presentation import (
    build_branch_filter_state,
    project_tracking_rows,
    resolve_view_branch_selection,
)
from core.runtime_ports import emit_deleted, emit_updated
from core.settings import _


@dataclass(frozen=True, slots=True)
class CatalogProduct:
    material_number: str
    name: str

    @property
    def display_text(self) -> str:
        if self.material_number and self.name and self.name != self.material_number:
            return f"{self.material_number} - {self.name}"
        return self.material_number or self.name

    def as_dict(self) -> dict[str, str]:
        return {"material_number": self.material_number, "name": self.name}


def _better_product_name(candidate: Any, material: str, fallback: Any = "") -> str:
    candidate_text = str(candidate or "").strip()
    fallback_text = str(fallback or "").strip()
    if candidate_text and not looks_like_material_code(candidate_text, material):
        return candidate_text
    if fallback_text and not looks_like_material_code(fallback_text, material):
        return fallback_text
    return candidate_text or fallback_text or str(material or "").strip()


def _normalize_catalog_rows(
    rows: Iterable[Mapping[str, Any]] | None,
) -> list[dict[str, str]]:
    """Normalize the canonical stored-products projection only."""
    normalized: dict[str, dict[str, str]] = {}
    for row in rows or ():
        if not isinstance(row, Mapping):
            continue
        material = tracking_row_text(row, "material_number")
        if not material:
            continue
        name = tracking_row_text(row, "name") or material
        normalized[material.casefold()] = {"material_number": material, "name": name}
    return sorted(
        normalized.values(),
        key=lambda item: (item["name"].casefold(), item["material_number"].casefold()),
    )


def canonical_tracking_row(row: Mapping[str, Any] | None) -> dict[str, Any]:
    """Project one canonical internal tracking row without legacy field aliases."""
    source = dict(row or {})
    material = tracking_row_text(source, "material_number")
    name = _better_product_name(tracking_row_text(source, "name"), material, material)
    branch = tracking_row_text(source, "branch")
    doc_id = tracking_row_text(source, "doc_id")
    row_id = tracking_row_text(source, "id")
    if not doc_id and "::" in row_id:
        id_branch, bare_id = row_id.split("::", 1)
        branch = branch or id_branch.strip()
        doc_id = bare_id.strip()
    elif not doc_id:
        doc_id = row_id
    try:
        quantity = int(source.get("quantity") or 0)
    except (TypeError, ValueError):
        quantity = 0
    projected = dict(source)
    projected.update(
        {
            "id": f"{branch}::{doc_id}" if branch and doc_id else row_id or doc_id,
            "doc_id": doc_id,
            "material_number": material,
            "name": name,
            "branch": branch,
            "quantity": quantity,
            "production_date": tracking_row_text(source, "production_date"),
            "expiry_date": tracking_row_text(source, "expiry_date"),
        }
    )
    return projected


def normalize_tracking_catalog(
    rows: Iterable[Mapping[str, Any]] | None,
) -> list[CatalogProduct]:
    unique: dict[str, CatalogProduct] = {}
    for row in _normalize_catalog_rows(rows):
        material = row["material_number"]
        unique[material.casefold()] = CatalogProduct(material, row["name"] or material)
    return sorted(
        unique.values(),
        key=lambda product: (product.name.casefold(), product.material_number.casefold()),
    )


def build_tracking_completer_suggestions(
    rows: Iterable[Mapping[str, Any]] | None,
) -> list[str]:
    return [product.display_text for product in normalize_tracking_catalog(rows)]


def resolve_tracking_catalog_selection(
    text: str, rows: Iterable[Mapping[str, Any]] | None
) -> CatalogProduct | None:
    requested = str(text or "").strip()
    if " - " in requested:
        requested = requested.split(" - ", 1)[0].strip()
    needle = requested.casefold()
    if not needle:
        return None
    products = normalize_tracking_catalog(rows)
    exact = [p for p in products if needle in {p.material_number.casefold(), p.name.casefold()}]
    if exact:
        return exact[0]
    partial = [
        p for p in products if needle in p.material_number.casefold() or needle in p.name.casefold()
    ]
    return partial[0] if len(partial) == 1 else None


def enrich_tracking_rows_for_display(
    rows: Iterable[Mapping[str, Any]] | None,
    catalog_rows: Iterable[Mapping[str, Any]] | None,
) -> list[dict[str, Any]]:
    catalog = normalize_tracking_catalog(catalog_rows)
    by_material = {p.material_number.casefold(): p.name for p in catalog}
    enriched: list[dict[str, Any]] = []
    for row in deduplicate_tracking_records(rows):
        projected = canonical_tracking_row(row)
        material = projected["material_number"]
        name = projected["name"]
        if material and (not name or looks_like_material_code(name, material)):
            name = by_material.get(material.casefold(), material)
        projected["name"] = _better_product_name(
            name, material, by_material.get(material.casefold(), "")
        )
        enriched.append(projected)
    return enriched


def row_identity_keys(row: Mapping[str, Any] | None) -> tuple[str, ...]:
    return tracking_record_identity_keys(canonical_tracking_row(row))


def merge_tracking_delta_rows(
    current_rows: Iterable[Mapping[str, Any]] | None,
    delta: Mapping[str, Any] | None,
    *,
    catalog_rows: Iterable[Mapping[str, Any]] | None,
    branch_filter: Callable[[list[dict[str, Any]]], list[dict[str, Any]]],
) -> list[dict[str, Any]]:
    rows = enrich_tracking_rows_for_display(current_rows, catalog_rows)
    deletes = {
        str(x or "").strip() for x in (delta or {}).get("deletes") or () if str(x or "").strip()
    }
    if deletes:
        rows = [row for row in rows if not deletes.intersection(row_identity_keys(row))]
    index = {key: i for i, row in enumerate(rows) for key in row_identity_keys(row)}
    for incoming in (delta or {}).get("upserts") or ():
        if not isinstance(incoming, Mapping):
            continue
        filtered = branch_filter([dict(incoming)])
        candidate = enrich_tracking_rows_for_display(filtered or [dict(incoming)], catalog_rows)[0]
        position = next((index[k] for k in row_identity_keys(candidate) if k in index), None)
        if not filtered:
            if position is not None:
                rows.pop(position)
        elif position is None:
            rows.append(candidate)
        else:
            rows[position] = candidate
        index = {key: i for i, row in enumerate(rows) for key in row_identity_keys(row)}
    return rows


INVALID_DATE_MESSAGE = _("Invalid date format!")
INVALID_QUANTITY_MESSAGE = _("Quantity must be a positive integer.")
CREATE_REQUIRED_MESSAGE = _("Please select a product and enter quantity.")


@dataclass(frozen=True)
class TrackingCreateInput:
    material_number: str
    quantity: int
    production_date: str
    expiry_date: str


@dataclass(frozen=True)
class TrackingUpdateInput:
    quantity: int
    production_date: str
    expiry_date: str


class TrackingFormService:
    @staticmethod
    def extract_material_number(value: str) -> str:
        text = _text(value)
        return text.split(" - ", 1)[0].strip() if " - " in text else text

    @staticmethod
    def _parse_iso_date(value: str) -> date:
        return datetime.strptime(_text(value), "%Y-%m-%d").date()

    def validate_date_order(self, production_date: str, expiry_date: str) -> str:
        try:
            prod = self._parse_iso_date(production_date)
            exp = self._parse_iso_date(expiry_date)
        except (TypeError, ValueError):
            return INVALID_DATE_MESSAGE
        return _("Production date cannot be after expiry date.") if prod > exp else ""

    @staticmethod
    def parse_positive_quantity(value: str) -> tuple[int | None, str]:
        try:
            quantity = int(_text(value))
        except (TypeError, ValueError):
            return (None, INVALID_QUANTITY_MESSAGE)
        return (quantity, "") if quantity > 0 else (None, INVALID_QUANTITY_MESSAGE)

    def _validated_quantity_and_dates(
        self, *, quantity_text: str, production_date: str, expiry_date: str
    ) -> tuple[int | None, str]:
        quantity, error_message = self.parse_positive_quantity(quantity_text)
        if error_message:
            return (None, error_message)
        error_message = self.validate_date_order(production_date, expiry_date)
        return (None, error_message) if error_message else (quantity, "")

    def prepare_create(
        self,
        *,
        product_text: str,
        quantity_text: str,
        production_date: str,
        expiry_date: str,
    ) -> tuple[TrackingCreateInput | None, str]:
        if not _text(product_text) or not _text(quantity_text):
            return (None, CREATE_REQUIRED_MESSAGE)
        material_number = self.extract_material_number(product_text)
        if not material_number:
            return (None, CREATE_REQUIRED_MESSAGE)
        quantity, error_message = self._validated_quantity_and_dates(
            quantity_text=quantity_text,
            production_date=production_date,
            expiry_date=expiry_date,
        )
        if error_message:
            return (None, error_message)
        return (
            TrackingCreateInput(
                material_number=material_number,
                quantity=int(quantity or 0),
                production_date=_text(production_date),
                expiry_date=_text(expiry_date),
            ),
            "",
        )

    def prepare_update(
        self, *, quantity_text: str, production_date: str, expiry_date: str
    ) -> tuple[TrackingUpdateInput | None, str]:
        quantity, error_message = self._validated_quantity_and_dates(
            quantity_text=quantity_text,
            production_date=production_date,
            expiry_date=expiry_date,
        )
        if error_message:
            return (None, error_message)
        return (
            TrackingUpdateInput(
                quantity=int(quantity or 0),
                production_date=_text(production_date),
                expiry_date=_text(expiry_date),
            ),
            "",
        )


@dataclass(frozen=True, slots=True)
class RefreshToken:
    session_id: str
    scope_hash: str
    generation: int


class TrackingStore:
    def __init__(self) -> None:
        self._lock = RLock()
        self._records: dict[TrackingKey, TrackingRecord] = {}
        self._remote_index: dict[RemoteTrackingId, TrackingKey] = {}
        self._generation = 0
        self._revision: int | None = None
        self._scope: TrackingScope | None = None
        self._session_id = ""
        self._baseline_ready = False
        self._pending_deltas: deque[TrackingDelta] = deque()
        self._subscribers: set[Callable[[TrackingStoreEvent], None]] = set()

    def begin_refresh(self, scope: Any, session_id: str = "") -> RefreshToken:
        resolved = TrackingScope.from_value(scope)
        with self._lock:
            if self._scope != resolved or self._session_id != str(session_id or ""):
                self._generation += 1
                self._scope = resolved
                self._session_id = str(session_id or "")
            return RefreshToken(
                session_id=self._session_id,
                scope_hash=resolved.hash,
                generation=self._generation,
            )

    def commit_baseline(self, token: RefreshToken, baseline: TrackingBaseline) -> CommitResult:
        with self._lock:
            rejection = self._token_rejection(token)
            if rejection:
                return CommitResult(False, rejection)
            records = self._deduplicate_records(baseline.records)
            new_records = {record.key: record for record in records}
            inserted, updated, deleted = self._baseline_diff_unlocked(new_records)
            self._records = new_records
            self._remote_index = {
                record.remote_id: record.key for record in records if record.remote_id.value
            }
            self._revision = int(baseline.revision)
            self._baseline_ready = True
            self._generation += 1
            self._drain_pending_deltas_unlocked()
            event = TrackingStoreEvent(
                "baseline_committed",
                self._snapshot_unlocked(),
                inserted=inserted,
                updated=updated,
                deleted=deleted,
            )
        self._publish(event)
        return CommitResult(True, "committed", event)

    def snapshot(self) -> TrackingSnapshot:
        with self._lock:
            return self._snapshot_unlocked()

    def reset(self, session_id: str = "") -> None:
        with self._lock:
            self._records = {}
            self._remote_index = {}
            self._generation += 1
            self._revision = None
            self._scope = None
            self._session_id = str(session_id or "")
            self._baseline_ready = False
            self._pending_deltas.clear()
            event = TrackingStoreEvent("reset", self._snapshot_unlocked())
        self._publish(event)

    def _token_rejection(self, token: RefreshToken) -> str:
        if token.session_id != self._session_id:
            return "rejected_session_changed"
        if self._scope is None or token.scope_hash != self._scope.hash:
            return "rejected_scope_changed"
        if token.generation != self._generation:
            return "rejected_stale_generation"
        return ""

    def _apply_delta_unlocked(self, delta: TrackingDelta) -> TrackingStoreEvent:
        records = dict(self._records)
        for key in delta.deleted:
            records.pop(key, None)
        for record in (*delta.inserted, *delta.updated):
            records[record.key] = record
        self._records = records
        self._remote_index = {
            record.remote_id: record.key for record in records.values() if record.remote_id.value
        }
        self._revision = int(delta.to_revision)
        self._generation += 1
        return TrackingStoreEvent(
            "delta_applied",
            self._snapshot_unlocked(),
            inserted=delta.inserted,
            updated=delta.updated,
            deleted=delta.deleted,
        )

    def _drain_pending_deltas_unlocked(self) -> None:
        pending = tuple(sorted(self._pending_deltas, key=lambda item: item.from_revision))
        self._pending_deltas.clear()
        for delta in pending:
            if delta.from_revision != self._revision:
                self._pending_deltas.clear()
                break
            self._apply_delta_unlocked(delta)

    def _snapshot_unlocked(self) -> TrackingSnapshot:
        scope_hash = self._scope.hash if self._scope is not None else ""
        return TrackingSnapshot(
            generation=self._generation,
            revision=self._revision,
            scope_hash=scope_hash,
            baseline_ready=self._baseline_ready,
            records=tuple(
                self._records[key] for key in sorted(self._records, key=self._key_sort_value)
            ),
        )

    def _baseline_diff_unlocked(
        self, new_records: dict[TrackingKey, TrackingRecord]
    ) -> tuple[tuple[TrackingRecord, ...], tuple[TrackingRecord, ...], tuple[TrackingKey, ...]]:
        old_records = self._records
        inserted = tuple(record for key, record in new_records.items() if key not in old_records)
        updated = tuple(
            record
            for key, record in new_records.items()
            if key in old_records and old_records[key] != record
        )
        deleted = tuple(key for key in old_records if key not in new_records)
        return (inserted, updated, deleted)

    @staticmethod
    def _deduplicate_records(
        records: Iterable[TrackingRecord],
    ) -> tuple[TrackingRecord, ...]:
        by_key = {record.key: record for record in records}
        return tuple(by_key[key] for key in sorted(by_key, key=TrackingStore._key_sort_value))

    @staticmethod
    def _key_sort_value(key: TrackingKey) -> tuple[str, str, str, str]:
        return (
            key.branch_id.casefold(),
            key.material_number.casefold(),
            key.production_date.isoformat() if key.production_date else "",
            key.expiry_date.isoformat(),
        )

    def _publish(self, event: TrackingStoreEvent) -> None:
        with self._lock:
            subscribers = tuple(self._subscribers)
        for callback in subscribers:
            callback(event)


tracking_store = TrackingStore()


logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class TrackingBaselineSnapshot:
    generation: int
    rows: tuple[dict[str, Any], ...]
    source: str
    priority: int
    ready: bool


class TrackingBaselineCoordinator:
    """Single in-process authority for tracking baseline publication."""

    def __init__(self) -> None:
        self._lock = RLock()
        self._generation = 0
        self._rows: list[dict[str, Any]] = []
        self._source = ""
        self._priority = 0
        self._ready = False

    def reset(self) -> None:
        with self._lock:
            self._generation += 1
            self._rows = []
            self._source = ""
            self._priority = 0
            self._ready = False
        tracking_store.reset(session_id="")

    @staticmethod
    def _source_priority(source: str) -> int:
        return {
            "mutation": 60,
            "sync": 55,
            "network": 50,
            "initial_hydrate": 45,
            "app_state": 40,
            "realtime": 40,
            "monitor": 25,
            "cache": 20,
            "monitor_preload": 15,
            "page_preload": 10,
        }.get(str(source or "").strip().lower(), 5)

    def publish(self, rows, *, source: str, force: bool = False) -> TrackingBaselineSnapshot:
        normalized = deduplicate_tracking_records(rows)
        wanted_priority = self._source_priority(source)
        with self._lock:
            if self._ready and not force and wanted_priority < self._priority:
                return self._snapshot_unlocked()
            self._generation += 1
            self._rows = [dict(row) for row in normalized]
            self._source = str(source or "unknown")
            self._priority = wanted_priority
            self._ready = True
            snapshot = self._snapshot_unlocked()
        self._publish_to_store(snapshot)
        return snapshot

    def snapshot(self) -> TrackingBaselineSnapshot:
        with self._lock:
            return self._snapshot_unlocked()

    def _snapshot_unlocked(self) -> TrackingBaselineSnapshot:
        return TrackingBaselineSnapshot(
            generation=self._generation,
            rows=tuple(dict(row) for row in self._rows),
            source=self._source,
            priority=self._priority,
            ready=self._ready,
        )

    @staticmethod
    def _publish_to_store(snapshot: TrackingBaselineSnapshot) -> None:
        records = tuple(
            record
            for row in snapshot.rows
            for record in (tracking_record_from_row(row),)
            if record is not None
        )
        scope = TrackingScope.from_value(
            tuple(dict.fromkeys(record.key.branch_id for record in records))
        )
        token = tracking_store.begin_refresh(scope, session_id="")
        result = tracking_store.commit_baseline(
            token,
            TrackingBaseline(
                revision=snapshot.generation,
                scope=scope,
                records=records,
                generated_at=datetime.now(timezone.utc),
            ),
        )
        if not result.accepted:
            logger.info(
                "tracking.baseline.rejected_generation",
                extra={"reason": result.reason, "generation": snapshot.generation},
            )


tracking_baseline = TrackingBaselineCoordinator()


logger = logging.getLogger(__name__)
ACTION_CREATE = "create"
ACTION_UPDATE = "update"
ACTION_DELETE = "delete"
NOT_FOUND_MESSAGE = "Food item was not found."
MISSING_SERVER_ID_MESSAGE = "Server record id is missing. Refresh shelf-life data and try again."
CATALOG_MESSAGE = "This food item was not found in the product catalog."
_REMOTE_ERRORS = (PermissionError, *SERVICE_OPERATION_EXCEPTIONS)


def _lower(value: Any = "") -> str:
    return _text(value).casefold()


@dataclass(frozen=True)
class TrackingRecordSelection:
    record: dict[str, Any] | None
    message: str = ""
    requires_refresh: bool = False


class TrackingBranchAccessService:
    """Application owner for tracking branch authorization and scoped views."""

    def __init__(self, context):
        self._context = context

    def resolve_write_branch(self) -> tuple[str, str]:
        if self._context.api_client is None:
            return ("", "")
        try:
            return (_text(self._context.pick_branch_for_write()), "")
        except _REMOTE_ERRORS as exc:
            return ("", _text(exc) or "Please select a branch to add/update.")

    def validate_action(self, branch: str, *, action: str) -> str:
        if self._context.api_client is None:
            return ""
        branch = _text(branch)
        action = _lower(action)
        if action == ACTION_CREATE and not branch:
            return "Choose an authorized branch before adding a tracked item."
        if action == ACTION_CREATE and branch and not self._context.can_create_tracking(branch):
            return "You don't have permission to add items in this branch."
        if action == ACTION_UPDATE and not self._context.can_update_tracking(branch):
            return "You don't have permission to edit items in this branch."
        if action == ACTION_DELETE and not self._context.can_delete_tracking(branch):
            return "You don't have permission to delete items in this branch."
        return ""

    def allowed_branches(self) -> list[str]:
        return [_text(value) for value in self._context.allowed_branches() if _text(value)]

    def writable_branches(self) -> list[str]:
        """Return server-authorized branches where tracking create is allowed."""
        seen: set[str] = set()
        result: list[str] = []
        for branch in self.allowed_branches():
            key = branch.casefold()
            if key and key not in seen and self._context.can_create_tracking(branch):
                seen.add(key)
                result.append(branch)
        return result

    def resolve_writable_branch(self, branch: str) -> str:
        """Return the canonical authorized branch spelling, or an empty value."""
        requested = _text(branch)
        if not requested:
            return ""
        key = requested.casefold()
        for candidate in self.writable_branches():
            if candidate.casefold() == key:
                return candidate
        return ""

    def can_view_all_branches(self) -> bool:
        return bool(self._context.can_view_all_branches())

    def get_filter_state(self) -> dict[str, Any]:
        state = build_branch_filter_state(
            branches=self.allowed_branches(),
            can_view_all=self.can_view_all_branches(),
            saved_view="",
        )
        return {
            "branches": state.branches,
            "can_view_all": state.can_view_all,
            "allow_scope_aggregate": state.allow_scope_aggregate,
            "show_row": state.show_row,
            "items": state.items,
            "selected_data": state.selected_data,
            "disable_selector": state.disable_selector,
        }

    def apply_view_selection(self, value: str) -> str:
        raw = _text(value)
        active = resolve_view_branch_selection(
            raw,
            can_view_all=self.can_view_all_branches(),
            allow_scope_aggregate=len(self.allowed_branches()) > 1,
        )
        self._context.set_active_branch(active)
        return active

    def filter_rows(self, rows: list | None) -> list:
        view = _lower(self._context.active_branch())
        if view and view != "all":
            return deduplicate_tracking_records(
                row for row in rows or [] if _lower((row or {}).get("branch")) == view
            )
        return deduplicate_tracking_records(rows)

    def snapshot_rows(self) -> list:
        snapshot = tracking_baseline.snapshot()
        return self.filter_rows(list(snapshot.rows)) if snapshot.ready else []

    def items_truncated(self) -> bool:
        return bool(getattr(self._context.api_client, "_items_truncated", False))


class TrackingCatalogService:
    """Tracking catalog read model backed only by stored_products."""

    def __init__(self, stored_catalog, *, remote_provider):
        self._stored_catalog = stored_catalog
        self._remote_provider = remote_provider

    def baseline_snapshot(self):
        return tracking_baseline.snapshot()

    def reset_baseline(self) -> None:
        tracking_baseline.reset()

    @staticmethod
    def completer_suggestions(rows) -> list[str]:
        return build_tracking_completer_suggestions(rows)

    def catalog_products(self, *, force_network: bool = False) -> list[dict[str, str]]:
        local_rows = list(self._stored_catalog.list_local() or [])
        local_catalog = _normalize_catalog_rows(local_rows)
        if self._remote_provider() is None or (local_catalog and not force_network):
            return local_catalog
        try:
            remote_rows = list(self._stored_catalog.refresh_from_server() or [])
            return _normalize_catalog_rows(remote_rows) or local_catalog
        except _REMOTE_ERRORS:
            logger.warning("Unable to refresh stored tracking catalogue", exc_info=True)
            return local_catalog

    def resolve_product(
        self, product_text: str, *, force_network: bool = False
    ) -> dict[str, str] | None:
        product = resolve_tracking_catalog_selection(
            product_text, self.catalog_products(force_network=force_network)
        )
        return product.as_dict() if product is not None else None

    def stored_product_exists(self, material_number: str) -> bool:
        return self.resolve_product(material_number, force_network=False) is not None


class TrackingService:
    """Single application owner for tracking mutations and tracking read projection."""

    def __init__(self, repository, context, settings, stored_catalog):
        self._repository = repository
        self._context = context
        self._settings = settings
        self.branch_access = TrackingBranchAccessService(context)
        self.catalog = TrackingCatalogService(
            stored_catalog,
            remote_provider=lambda: self._context.api_client,
        )

    def _api_client(self):
        return self._context.api_client

    @staticmethod
    def _failure(message: str) -> tuple[bool, str, str]:
        return (False, "", _text(message))

    @staticmethod
    def _success(message: str) -> tuple[bool, str, str]:
        return (True, _text(message), "")

    def _resolve_write_branch(self) -> tuple[str, str]:
        return self.branch_access.resolve_write_branch()

    def _validate_branch_action(self, branch: str, *, action: str) -> str:
        return self.branch_access.validate_action(branch, action=action)

    def record_action_error(self, record: dict | None, *, action: str) -> str:
        """Return the current actor's actionable permission result for one row."""
        row = dict(record or {})
        if not row:
            return NOT_FOUND_MESSAGE
        if self._api_client() is not None and not self._resolve_record_id(row):
            return MISSING_SERVER_ID_MESSAGE
        return self._validate_branch_action(_text(row.get("branch")), action=action)

    @staticmethod
    def _resolve_record_id(row: dict) -> str:
        return _text(row.get("doc_id") or normalize_remote_id(row) or row.get("id"))

    def _prepare_record_action(self, record: dict | None, *, action: str) -> tuple[dict, str]:
        row = dict(record or {})
        error = self.record_action_error(row, action=action)
        return ({}, error) if error else (row, "")

    @staticmethod
    def _find_row_by_product_id(rows: list | None, product_id: Any) -> dict | None:
        needle = _text(product_id)
        for row in rows or []:
            if _text((row or {}).get("id")) == needle or _text((row or {}).get("doc_id")) == needle:
                return dict(row)
        return None

    def select_record_for_action(
        self, *, product_id: Any, rows: list | None, action: str
    ) -> TrackingRecordSelection:
        row = self._find_row_by_product_id(rows, product_id)
        if not row:
            return TrackingRecordSelection(None, NOT_FOUND_MESSAGE)
        prepared, message = self._prepare_record_action(row, action=action)
        if message:
            return TrackingRecordSelection(
                None,
                message,
                requires_refresh=message == MISSING_SERVER_ID_MESSAGE,
            )
        return TrackingRecordSelection(prepared)

    @staticmethod
    def _tracking_payload(
        *, branch: str = "", material_number: str = "", expiry_date: str = ""
    ) -> dict[str, str]:
        return {
            "branch": _text(branch),
            "material_number": _text(material_number),
            "expiry_date": _text(expiry_date),
        }

    def _emit_row_change(self, action: str, row: dict | None) -> None:
        payload = self._tracking_payload(
            branch=(row or {}).get("branch", ""),
            material_number=(row or {}).get("material_number", ""),
            expiry_date=(row or {}).get("expiry_date", ""),
        )
        payload["action"] = action
        if action == ACTION_DELETE:
            emit_deleted("tracking", payload)
        else:
            emit_updated("tracking", payload)

    def _find_existing_row(
        self, rows: list | None, *, material_number: str, expiry_date: str, branch: str
    ) -> dict | None:
        for row in rows or []:
            if _text(row.get("material_number")) != _text(material_number):
                continue
            if _text(row.get("expiry_date")) != _text(expiry_date):
                continue
            if self._api_client() is not None and _text(row.get("branch")) != _text(branch):
                continue
            return dict(row)
        return None

    def _publish_cached_tracking_projection(self, *, source: str) -> list[dict]:
        """Publish the complete authorized local tracking projection.

        The baseline/monitoring store is scoped by the authenticated server
        projection, not by the currently selected UI branch.  Keeping that
        invariant prevents a branch refresh from replacing the baseline with
        only one visible branch and makes successful mutations immediately
        observable by the page and expiry monitor.
        """
        rows = list(self._repository.fetch_cached_tracked_products() or [])
        snapshot = tracking_baseline.publish(rows, source=source)
        return [dict(row) for row in snapshot.rows]

    def _project_remote_upsert(self, item: dict) -> None:
        self._repository.upsert_cached_cloud_tracking_product(dict(item or {}))
        self._publish_cached_tracking_projection(source="mutation")

    def _project_remote_delete(self, row: dict, result: dict | None = None) -> None:
        self._repository.delete_cached_cloud_tracking_product(
            doc_id=self._resolve_record_id(row),
            branch=_text(row.get("branch")),
            revision=normalize_int(
                (result or {}).get("revision"),
                normalize_int(row.get("revision"), 0) + 1,
            ),
        )
        self._publish_cached_tracking_projection(source="mutation")

    def fetch_rows(self, *, cloud: bool, force_network: bool = False) -> list:
        if cloud and self._api_client() is not None:
            rows = (
                []
                if force_network
                else list(self._repository.fetch_cached_tracked_products() or [])
            )
            if force_network or not rows:
                # Fetch the complete effective server scope.  The active branch is
                # presentation state only; using it here and then replacing the
                # authoritative cache would silently discard other authorized
                # branches from realtime/expiry monitoring.
                remote_rows = list(self._api_client().list_items(branch_filter=None) or [])
                if not self._repository.replace_cached_cloud_tracking_products(remote_rows):
                    raise RuntimeError("Unable to replace authoritative tracking projection")
                rows = list(self._repository.fetch_cached_tracked_products() or [])
        else:
            # Offline/no-session view is a read-only replica/cache.
            rows = list(self._repository.fetch_cached_tracked_products() or [])

        snapshot = tracking_baseline.publish(rows, source="network" if force_network else "cache")
        return deduplicate_tracking_records(snapshot.rows)

    def baseline_snapshot(self):
        return tracking_baseline.snapshot()

    def publish_baseline(self, rows, *, source: str, force: bool = False):
        return tracking_baseline.publish(rows, source=source, force=force)

    def reset_baseline(self) -> None:
        tracking_baseline.reset()

    def name_cache_size(self) -> int:
        return int(getattr(self._repository, "stored_name_cache_size", 0) or 0)

    def invalidate_cache(self, branch: str | None = None) -> None:
        self._repository.invalidate_cloud_cache(branch)

    @staticmethod
    def completer_suggestions(rows) -> list[str]:
        return build_tracking_completer_suggestions(rows)

    def catalog_products(self, *, force_network: bool = False) -> list[dict[str, str]]:
        return self.catalog.catalog_products(force_network=force_network)

    def resolve_catalog_product(
        self, product_text: str, *, force_network: bool = False
    ) -> dict[str, str] | None:
        return self.catalog.resolve_product(product_text, force_network=force_network)

    def enrich_rows_for_display(
        self, rows: list | None, catalog_rows: list | None
    ) -> list[dict[str, Any]]:
        enriched = enrich_tracking_rows_for_display(rows, catalog_rows)
        return project_tracking_rows(enriched)

    def merge_visible_delta_rows(
        self,
        current_rows: list[dict] | None,
        delta: dict | None,
        *,
        catalog_rows: list[dict] | None,
    ) -> list[dict[str, Any]]:
        merged = merge_tracking_delta_rows(
            current_rows,
            delta,
            catalog_rows=catalog_rows,
            branch_filter=self.rows_for_tracking_view,
        )
        return project_tracking_rows(merged)

    def stored_product_exists(self, material_number: str) -> bool:
        return self.catalog.stored_product_exists(material_number)

    def create_or_merge_item(
        self,
        *,
        material_number: str,
        quantity: int,
        production_date: str,
        expiry_date: str,
        branch: str = "",
        current_rows: list | None = None,
    ) -> tuple[bool, str, str]:
        # A chosen suggestion already came from the authenticated stored
        # catalogue projection.  Re-fetching that catalogue on the save path
        # made a valid Add click depend on an unrelated second HTTP request;
        # on a slow or briefly interrupted connection this looked like an
        # inert button even though the actual tracking endpoint was available.
        #
        # The catalogue service will still fetch if there is no local
        # projection at all, and the server remains the final authority for
        # the create request.  A normal mutation therefore has one essential
        # network operation (the create), not a catalogue refresh plus create.
        product = self.resolve_catalog_product(material_number, force_network=False)
        if product is None:
            return self._failure(_(CATALOG_MESSAGE))
        material = _text(product.get("material_number"))
        name = _text(product.get("name") or material)
        qty = max(0, normalize_int(quantity, 0))
        requested_branch = _text(branch)
        if requested_branch:
            # The selector is populated from the authenticated authority, but
            # do not turn its cached snapshot into a second authorization
            # boundary.  Scope may change between selection and save; the
            # remote sync transaction owns the final permission + branch check.
            write_branch = requested_branch
            branch_error = ""
        else:
            write_branch, branch_error = self._resolve_write_branch()
        if branch_error:
            return self._failure(branch_error)
        if self._api_client() is None:
            permission_error = self._validate_branch_action(write_branch, action=ACTION_CREATE)
            if permission_error:
                return self._failure(permission_error)
        existing = self._find_existing_row(
            current_rows,
            material_number=material,
            expiry_date=expiry_date,
            branch=write_branch,
        )
        if existing:
            return self.update_item(
                existing,
                quantity=max(0, normalize_int(existing.get("quantity"), 0) + qty),
                production_date=production_date,
                expiry_date=expiry_date,
            )
        try:
            if self._api_client() is not None:
                logger.info(
                    "TRACKING_CREATE_REMOTE branch=%s material=%s quantity=%s",
                    write_branch,
                    material,
                    qty,
                )
                item = self._api_client().add_item(
                    branch=write_branch,
                    material_number=material,
                    material_name=name,
                    quantity=qty,
                    production_date=production_date,
                    expiry_date=expiry_date,
                )
                self._project_remote_upsert(item)
                self._emit_row_change(ACTION_CREATE, item)
            else:
                return self._failure("Server connection is required for tracking changes.")
            logger.info("TRACKING_CREATE_SUCCESS branch=%s material=%s", write_branch, material)
            return self._success("Food item added.")
        except _REMOTE_ERRORS as exc:
            logger.warning(
                "TRACKING_CREATE_FAILED branch=%s material=%s error=%s",
                write_branch,
                material,
                exc,
            )
            return self._failure(str(exc))

    def update_item(
        self, record: dict | None, *, quantity: int, production_date: str, expiry_date: str
    ) -> tuple[bool, str, str]:
        row, error = self._prepare_record_action(record, action=ACTION_UPDATE)
        if error:
            return self._failure(error)
        try:
            if self._api_client() is not None:
                item = self._api_client().update_item(
                    branch=_text(row.get("branch")),
                    doc_id=self._resolve_record_id(row),
                    material_number=_text(row.get("material_number")),
                    quantity=max(0, normalize_int(quantity, 0)),
                    production_date=production_date,
                    expiry_date=expiry_date,
                    revision=normalize_int(row.get("revision"), 0),
                )
                self._project_remote_upsert(item)
                self._emit_row_change(ACTION_UPDATE, item)
            else:
                return self._failure("Server connection is required for tracking changes.")
            return self._success("Food item updated.")
        except _REMOTE_ERRORS as exc:
            return self._failure(str(exc))

    def delete_item(self, record: dict | None) -> tuple[bool, str, str]:
        row, error = self._prepare_record_action(record, action=ACTION_DELETE)
        if error:
            return self._failure(error)
        try:
            if self._api_client() is not None:
                result = self._api_client().delete_item(
                    branch=_text(row.get("branch")),
                    doc_id=self._resolve_record_id(row),
                    revision=normalize_int(row.get("revision"), 0),
                )
                self._project_remote_delete(row, result)
            else:
                return self._failure("Server connection is required for tracking changes.")
            self._emit_row_change(ACTION_DELETE, row)
            return self._success("Food item deleted.")
        except _REMOTE_ERRORS as exc:
            return self._failure(str(exc))

    def allowed_branches(self) -> list[str]:
        return self.branch_access.allowed_branches()

    def can_view_all_branches(self) -> bool:
        return self.branch_access.can_view_all_branches()

    def is_cloud_mode(self) -> bool:
        return self._api_client() is not None

    def get_branch_filter_state(self) -> dict[str, Any]:
        return self.branch_access.get_filter_state()

    def apply_view_branch_selection(self, value: str) -> str:
        return self.branch_access.apply_view_selection(value)

    def create_branch_options(self) -> list[str]:
        return self.branch_access.writable_branches()

    def can_manage_tracking_catalog(self) -> bool:
        return bool(self._context.can_manage_catalog())

    def has_tracking_create_permission(self) -> bool:
        return bool(self._context.has_permission("tracking.create"))

    @staticmethod
    def rows_for_tracking_view(rows: list | None) -> list:
        """Tracking Products shows the complete server-authorized branch scope."""
        return deduplicate_tracking_records(rows)

    def snapshot_rows(self) -> list:
        return self.branch_access.snapshot_rows()

    def items_truncated(self) -> bool:
        return self.branch_access.items_truncated()


class TrackingPageController:
    """Application-facing Tracking operations with no Qt dependency.

    The controller is the only bridge between the Tracking page and the
    domain service.  It returns plain data/commands so widgets can focus on
    input, view state, and accessibility while workers execute the expensive
    operations away from the GUI thread.
    """

    def __init__(
        self, tracking_service: TrackingService, tracking_form_service: TrackingFormService
    ):
        if tracking_service is None or tracking_form_service is None:
            raise ValueError("TrackingPageController requires tracking services")
        self._tracking_service = tracking_service
        self._tracking_form_service = tracking_form_service

    def branch_options(self) -> list[str]:
        return [
            _text(branch)
            for branch in self._tracking_service.create_branch_options()
            if _text(branch)
        ]

    def can_manage_catalog(self) -> bool:
        return bool(self._tracking_service.can_manage_tracking_catalog())

    def has_create_permission(self) -> bool:
        return bool(self._tracking_service.has_tracking_create_permission())

    def is_cloud_mode(self) -> bool:
        return bool(self._tracking_service.is_cloud_mode())

    def baseline_rows(self) -> list[dict[str, Any]]:
        snapshot = self._tracking_service.baseline_snapshot()
        if not bool(getattr(snapshot, "ready", False)):
            return []
        return [dict(row) for row in getattr(snapshot, "rows", ()) if isinstance(row, Mapping)]

    def baseline_ready(self) -> bool:
        return bool(getattr(self._tracking_service.baseline_snapshot(), "ready", False))

    def publish_baseline(self, rows, *, source: str) -> None:
        self._tracking_service.publish_baseline(rows, source=source)

    def load_payload(self, *, force_network: bool) -> dict[str, list[dict[str, Any]]]:
        rows = self._tracking_service.fetch_rows(
            cloud=self.is_cloud_mode(), force_network=bool(force_network)
        )
        catalog = self._tracking_service.catalog_products(force_network=bool(force_network))
        return {
            "rows": self._tracking_service.enrich_rows_for_display(rows, catalog),
            "catalog": [dict(row) for row in catalog if isinstance(row, Mapping)],
        }

    def catalog_products(self, *, force_network: bool) -> list[dict[str, Any]]:
        rows = self._tracking_service.catalog_products(force_network=bool(force_network))
        return [dict(row) for row in rows if isinstance(row, Mapping)]

    def project_cached_rows(self, rows, catalog_rows) -> list[dict[str, Any]]:
        visible = self._tracking_service.rows_for_tracking_view(list(rows or []))
        return self._tracking_service.enrich_rows_for_display(visible, list(catalog_rows or []))

    def project_delta_rows(self, current_rows, delta, catalog_rows) -> list[dict[str, Any]]:
        return self._tracking_service.merge_visible_delta_rows(
            list(current_rows or []),
            dict(delta or {}),
            catalog_rows=list(catalog_rows or []),
        )

    def enrich_rows_for_display(self, rows, catalog_rows) -> list[dict[str, Any]]:
        return self._tracking_service.enrich_rows_for_display(
            list(rows or []), list(catalog_rows or [])
        )

    def completer_suggestions(self, rows) -> list[str]:
        return self._tracking_service.completer_suggestions(list(rows or []))

    def name_cache_size(self) -> int:
        return int(self._tracking_service.name_cache_size())

    def items_truncated(self) -> bool:
        return bool(self._tracking_service.items_truncated())

    def select_record(self, *, product_id: Any, rows, action: str) -> TrackingRecordSelection:
        return self._tracking_service.select_record_for_action(
            product_id=product_id,
            rows=list(rows or []),
            action=action,
        )

    def record_action_error(self, record: dict | None, *, action: str) -> str:
        return self._tracking_service.record_action_error(record, action=action)

    def prepare_create(self, **kwargs) -> tuple[TrackingCreateInput | None, str]:
        return self._tracking_form_service.prepare_create(**kwargs)

    def prepare_update(self, **kwargs) -> tuple[TrackingUpdateInput | None, str]:
        return self._tracking_form_service.prepare_update(**kwargs)

    def create_item(
        self,
        prepared: TrackingCreateInput | None,
        *,
        branch: str,
        current_rows,
    ) -> tuple[bool, str, str]:
        if prepared is None:
            return self._tracking_service._failure(CREATE_REQUIRED_MESSAGE)
        return self._tracking_service.create_or_merge_item(
            material_number=prepared.material_number,
            quantity=prepared.quantity,
            production_date=prepared.production_date,
            expiry_date=prepared.expiry_date,
            branch=_text(branch),
            current_rows=list(current_rows or []),
        )

    def update_item(
        self, record: dict | None, prepared: TrackingUpdateInput | None
    ) -> tuple[bool, str, str]:
        if prepared is None:
            return self._tracking_service._failure(INVALID_QUANTITY_MESSAGE)
        return self._tracking_service.update_item(
            record,
            quantity=prepared.quantity,
            production_date=prepared.production_date,
            expiry_date=prepared.expiry_date,
        )

    def delete_item(self, record: dict | None) -> tuple[bool, str, str]:
        return self._tracking_service.delete_item(record)
