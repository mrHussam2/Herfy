from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.i18n import normalize_language_code
from core.models import normalize_bool
from core.settings_contract import CANONICAL_SETTINGS_DEFAULTS

# Historical filenames below were byte-identical. Keep only one physical asset and
# normalize persisted values during schema migration to avoid duplicate package files.
_SOUND_FILENAME_ALIASES: dict[str, str] = {
    "expiry_approaching.wav": "expiry_near.wav",
    "expires_tomorrow.wav": "expiry_near.wav",
}


def canonical_sound_filename(value: Any, default: str) -> str:
    selected = str(value or default).strip() or default
    return _SOUND_FILENAME_ALIASES.get(selected.casefold(), selected)


SETTINGS_MIGRATION_ALIASES: dict[str, str] = {
    "notification_sound": "notification_sound_default",
}

# Migrations where an old preference remains useful but its old semantic key is
# no longer legal. The old critical sound is preserved as the new Near sound.
LEGACY_VALUE_MIGRATIONS: dict[str, str] = {
    "notification_sound_critical": "notification_sound_near",
}

# Removed settings are deleted during the local schema migration. They no longer
# participate in runtime behavior and are not preserved as compatibility knobs.
IGNORED_LEGACY_SETTINGS: tuple[str, ...] = (
    "enable_alerts",
    "enable_smart_notifications",
    "notify_expiry",
    "notification_once_per_day",
    "notification_repeat_interval_minutes",
    "notification_repeat_interval",
    "notification_duration_seconds",
    "notification_duration",
    "notification_max_per_cycle",
    "max_notifications_per_cycle",
    "notification_summary_threshold",
    "summary_notification_threshold",
    "expiry_critical_threshold_days",
    "critical_threshold",
    "monitoring_duration_days",
    "notification_duration_expired_seconds",
    "notification_duration_today_seconds",
    "notification_duration_critical_seconds",
    "notification_duration_soon_seconds",
    "notification_sound_critical",
    "expiry_soon_threshold_days",
    "expiry_expiring_soon_threshold_days",
    "expiring_soon_threshold",
    "date_format",
)
CANONICAL_EXPIRY_RUNTIME_SETTING_KEYS: tuple[str, ...] = tuple(
    key for key in CANONICAL_SETTINGS_DEFAULTS if key != "language"
)


def canonical_default(key: str, default: str = "") -> str:
    return CANONICAL_SETTINGS_DEFAULTS.get(str(key or ""), str(default or ""))


@dataclass(frozen=True)
class SettingsValidationResult:
    values: dict[str, str]
    errors: dict[str, str]

    @property
    def ok(self) -> bool:
        return not self.errors


def validate_canonical_settings(values: dict[str, Any]) -> SettingsValidationResult:
    merged = {**CANONICAL_SETTINGS_DEFAULTS, **{str(k): v for k, v in values.items()}}
    result: dict[str, str] = {}
    result["language"] = normalize_language_code(str(merged.get("language") or "en"))
    # Background monitoring remains available while the process/session is alive.
    result["enable_tray_background"] = "True"
    for key in (
        "monitoring_enabled",
        "enable_desktop_notifications",
        "enable_sounds",
        "expiry_enable_status_colors",
        "expiry_enable_status_icons",
    ):
        result[key] = (
            "True"
            if normalize_bool(
                merged.get(key), normalize_bool(CANONICAL_SETTINGS_DEFAULTS[key], True)
            )
            else "False"
        )
    for key in (
        "notification_sound_default",
        "notification_sound_expired",
        "notification_sound_soon",
        "notification_sound_approaching",
        "notification_sound_near",
        "notification_sound_tomorrow",
        "notification_sound_today",
    ):
        result[key] = canonical_sound_filename(
            merged.get(key),
            CANONICAL_SETTINGS_DEFAULTS[key],
        )
    return SettingsValidationResult(values=result, errors={})
