from __future__ import annotations

from typing import Any

from core.models import deduplicate_tracking_records


class DesktopApplication:
    """Explicit UI-facing application boundary. No UI code reaches infrastructure directly."""

    def __init__(
        self,
        *,
        state,
        repositories,
        context,
        tracking_service,
        stored_catalog,
        usage_catalog,
        sync_coordinator,
        admin_service,
        account_security,
        cloud_runtime,
    ):
        self.state = state
        self._repositories = repositories
        self._settings = repositories.settings
        self._tracking_repository = repositories.tracking
        self._context = context
        self.tracking = tracking_service
        self.stored_catalog = stored_catalog
        self.usage_catalog = usage_catalog
        self.sync = sync_coordinator
        self.admin = admin_service
        self.account_security = account_security
        self.cloud = cloud_runtime

    def server_connected(self) -> bool:
        return bool(self.cloud.connected())

    # Preferences / notification state
    def get_setting(self, key: str, default: Any = None):
        return self._settings.get_setting(key, default)

    def set_setting(self, key: str, value: Any) -> None:
        self._settings.set_setting(key, str(value))

    def delete_setting(self, key: str) -> None:
        self._settings.delete_setting(key)

    def get_alert_state(self, key: str) -> dict:
        return self._settings.get_alert_state(key)

    def set_alert_state(self, key: str, **kwargs) -> None:
        self._settings.set_alert_state(key, **kwargs)

    def get_notification_ledger(self, key: str) -> dict:
        return self._settings.get_notification_ledger(key)

    def record_notification_ledger(self, *args, **kwargs) -> None:
        self._settings.record_notification_ledger(*args, **kwargs)

    def acknowledge_notification_ledger(self, *args, **kwargs) -> None:
        self._settings.acknowledge_notification_ledger(*args, **kwargs)

    def clear_alert_states(self) -> None:
        self._settings.clear_alert_states()

    # Authenticated context
    def permission_context(self):
        return self._context.permission_context()

    def allowed_branches(self) -> list[str]:
        return self._context.allowed_branches()

    def set_allowed_branches(self, branches) -> None:
        self._context.set_allowed_branches(branches)

    def active_branch(self) -> str:
        return self._context.active_branch()

    def set_active_branch(self, branch: str) -> None:
        self._context.set_active_branch(branch)

    def set_cloud_context(self, service, profile) -> None:
        self._context.set_cloud_context(service, profile)
        self.sync.restore_remote_cursor()

    def has_permission(self, permission: str) -> bool:
        return self._context.has_permission(permission)

    def can_manage_catalog(self) -> bool:
        return self._context.can_manage_catalog()

    def can_manage_usage(self) -> bool:
        return self._context.can_manage_usage()

    def can_manage_org(self) -> bool:
        return self._context.can_manage_org()

    def local_stored_products(self) -> list[dict]:
        return self.stored_catalog.list_local()

    def local_usage_products(self) -> list[dict]:
        return self.usage_catalog.list_local()

    def refresh_stored_products(self) -> list[dict]:
        return self.stored_catalog.refresh_from_server()

    def refresh_usage_products(self, *, force: bool = True) -> list[dict]:
        return self.usage_catalog.refresh_from_server(force=force)

    def apply_remote_changes(self, changes: list[dict] | None, *, next_cursor=None) -> dict:
        return self.sync.apply_changes(changes, next_cursor=next_cursor)

    # Local projections exposed to presenters/UI through the application boundary.
    def cached_tracking_rows(self, branch: str | None = None) -> list[dict]:
        return list(self._tracking_repository.fetch_cached_tracked_products(branch) or [])

    def authorized_tracking_snapshot(self) -> list[dict]:
        """Return only the authenticated server-authorized local tracking projection."""
        if not self.sync.context_attached():
            return []
        ctx = self.permission_context()
        if not bool(getattr(ctx, "is_active", False)):
            return []
        rows = list(self._tracking_repository.fetch_cached_tracked_products("all") or [])
        allowed = {str(v).strip().casefold() for v in self.allowed_branches() if str(v).strip()}
        all_branches = bool(ctx.can_view_all_branches())
        filtered = []
        for row in rows:
            if not isinstance(row, dict) or bool(row.get("is_deleted")):
                continue
            branch = str(row.get("branch") or row.get("branch_id") or "").strip()
            if all_branches or branch.casefold() in allowed:
                filtered.append(dict(row))
        return deduplicate_tracking_records(filtered)

    def tracking_name_cache_size(self) -> int:
        return self._tracking_repository.stored_name_cache_size

    def invalidate_tracking_cache(self, branch: str | None = None) -> None:
        self._tracking_repository.invalidate_cloud_cache(branch)

    def clear_session_scoped_local_data(self, *, clear_catalog: bool = True) -> None:
        self._repositories.clear_session_scoped_data(clear_catalog=clear_catalog)

    def close(self) -> None:
        self._repositories.close()
