from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class UiRuntimeDependencies:
    """Application-facing dependency bundle consumed by the Qt shell.

    It deliberately contains no infrastructure or Qt types. The composition
    root builds this bundle once; views/controllers consume already-composed
    application services instead of reaching back into the dependency container.
    """

    app_state: Any
    application_resource_service: Any
    lifecycle: Any
    session_scope: Any
    session_persistence: Any
    authentication_service: Any
    account_security_service: Any
    session_runtime_service: Any
    cloud_sync_runtime_service: Any
    monitoring_service: Any
    notification_runtime_service: Any
    settings_service: Any
    catalog_management_service: Any
    admin_service: Any
    tracking_service: Any
    usage_service: Any
    usage_workspace_service: Any
    usage_row_presenter: Any
    home_dashboard_service: Any
    tracking_form_service: Any
    page_visible_state_service: Any
    presentation_preferences: Any
    server_runtime_service: Any
    update_runtime_service: Any
    realtime_pull_scheduler: Any
    startup_preferences_service: Any
    update_manager_factory: Callable[[str], Any]
