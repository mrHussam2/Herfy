from __future__ import annotations

import threading


class SessionScope:
    """Single owner of session generation and runtime lifecycle state."""

    _ALLOWED_STATES = frozenset(
        {
            "DISCONNECTED",
            "AUTHENTICATED",
            "AUTHORITY_READY",
            "INITIAL_SYNC",
            "BASELINE_READY",
            "REALTIME_READY",
            "MONITORING_READY",
        }
    )

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._generation = 0
        self._state = "DISCONNECTED"

    def generation(self) -> int:
        with self._lock:
            return self._generation

    def advance(self) -> int:
        with self._lock:
            self._generation += 1
            return self._generation

    def is_current(self, generation: int) -> bool:
        with self._lock:
            return self._generation == int(generation)

    def set_state(self, state: str) -> str:
        value = str(state or "").strip().upper()
        if value not in self._ALLOWED_STATES:
            raise ValueError(f"Invalid runtime lifecycle state: {state}")
        with self._lock:
            self._state = value
            return value

    def is_state(self, *states: str) -> bool:
        requested = {str(item or "").strip().upper() for item in states}
        with self._lock:
            return self._state in requested
