from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from contracts.routes import Routes
from core.errors import SERVICE_OPERATION_EXCEPTIONS, RemoteRequestError, SessionExpiredError
from core.permissions import PermissionContext, validate_server_authority
from core.runtime_ports import api_request
from core.settings import (
    canonical_error_message,
    get_http_timeout_seconds,
    get_request_verify_ssl,
    user_error_message,
)
from core.state import AuthSession, UserProfile

logger = logging.getLogger(__name__)


class AuthError(RuntimeError):
    """Authentication response or transport failure."""


@dataclass(frozen=True)
class SessionRestoreCandidate:
    refresh_token: str = ""
    username: str = ""


_TOKEN_KEYS = {
    "access_token",
    "refresh_token",
    "token_type",
    "expires_in",
    "user",
}
_AUTHORITY_KEYS = {
    "user_id",
    "username",
    "display_name",
    "role",
    "account_type",
    "permissions",
    "capabilities",
    "direct_scope",
    "scope",
    "active_branch",
    "is_active",
    "must_change_password",
    "permission_source",
    "scope_source",
    "authority_revision",
}
_SCOPE_KEYS = {
    "organizations",
    "regions",
    "areas",
    "branches",
    "all_organizations",
    "all_regions",
    "all_areas",
    "all_branches",
}


def _require_exact_keys(
    payload: dict[str, Any],
    *,
    allowed: set[str],
    required: set[str],
    label: str,
) -> None:
    unknown = sorted(set(payload) - allowed)
    missing = sorted(required - set(payload))
    if unknown or missing:
        logger.error(
            "Rejected %s contract: missing=%s unknown=%s",
            label,
            missing,
            unknown,
        )
        raise AuthError(canonical_error_message("invalid_response"))


def _parse_json_response(response: Any) -> dict[str, Any]:
    try:
        payload = response.json()
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        raise AuthError(canonical_error_message("malformed_response")) from exc
    if not isinstance(payload, dict):
        raise AuthError(canonical_error_message("invalid_response"))
    return payload


def _validate_authority(payload: Any) -> dict[str, Any]:
    try:
        return validate_server_authority(payload)
    except ValueError as exc:
        logger.error("Rejected server authority payload: %s", exc)
        raise AuthError(canonical_error_message("invalid_response")) from exc


def _validate_token_response(payload: dict[str, Any]) -> dict[str, Any]:
    data = dict(payload)
    _require_exact_keys(
        data,
        allowed=_TOKEN_KEYS,
        required=_TOKEN_KEYS,
        label="token response",
    )
    if data.get("token_type") != "bearer":
        raise AuthError(canonical_error_message("invalid_response"))
    if not isinstance(data.get("access_token"), str) or not data["access_token"].strip():
        raise AuthError(canonical_error_message("invalid_response"))
    if not isinstance(data.get("refresh_token"), str) or not data["refresh_token"].strip():
        raise AuthError(canonical_error_message("invalid_response"))
    if not isinstance(data.get("expires_in"), int) or data["expires_in"] <= 0:
        raise AuthError(canonical_error_message("invalid_response"))
    data["user"] = _validate_authority(data.get("user"))
    return data


def _request_token(path: str, payload: dict[str, Any], *, context: str) -> dict[str, Any]:
    try:
        response = api_request(
            "POST",
            path,
            json=payload,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Cache-Control": "no-store",
            },
            timeout=get_http_timeout_seconds(),
            verify=get_request_verify_ssl(),
            max_retries=0,
        )
        try:
            return _validate_token_response(_parse_json_response(response))
        finally:
            response.close()
    except SessionExpiredError as exc:
        raise AuthError(canonical_error_message("invalid_credentials")) from exc
    except RemoteRequestError as exc:
        status_code = int(getattr(exc, "status_code", 0) or 0)
        error_code = str(getattr(exc, "error_code", "") or "").strip().upper()
        if error_code == "SERVER_VERSION_MISMATCH":
            raise AuthError(canonical_error_message("server_release_mismatch")) from exc
        if error_code == "API_CONTRACT_MISMATCH":
            raise AuthError(canonical_error_message("api_contract_mismatch")) from exc
        if error_code == "CLIENT_VERSION_UNAPPROVED":
            raise AuthError(canonical_error_message("client_version_unapproved")) from exc
        if error_code == "CLIENT_VERSION_TOO_OLD":
            raise AuthError(canonical_error_message("client_version_too_old")) from exc
        if status_code == 401:
            raise AuthError(canonical_error_message("invalid_credentials")) from exc
        if status_code == 403:
            raise AuthError(canonical_error_message("account_inactive")) from exc
        raise AuthError(user_error_message(exc, context=context)) from exc
    except AuthError:
        raise
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        raise AuthError(user_error_message(exc, context=context)) from exc


def _parse_auth_session(data: dict[str, Any]) -> AuthSession:
    payload = _validate_token_response(data)
    authority = payload["user"]
    permission_context = PermissionContext.from_payload(
        authority,
        active_branch=str(authority.get("active_branch") or ""),
    )
    if not permission_context.authority_source:
        raise AuthError(canonical_error_message("profile_missing"))
    if not permission_context.is_active:
        raise AuthError(canonical_error_message("account_inactive"))

    branches = list(permission_context.scope.branches)
    active_branch = str(permission_context.active_branch or "").strip()
    return AuthSession(
        id_token=payload["access_token"],
        user_id=permission_context.user_id,
        role=permission_context.role,
        branches=branches,
        active_branch=active_branch,
        refresh_token=payload["refresh_token"],
        token_type="bearer",
        expires_in=int(payload["expires_in"]),
        permission_context=permission_context,
    )


def build_restore_candidate(snapshot: Any | None) -> SessionRestoreCandidate | None:
    """Cached authority never restores a session; only a server refresh can."""
    if snapshot is None or not bool(getattr(snapshot, "remember", False)):
        return None
    refresh_token = str(getattr(snapshot, "refresh_token", "") or "").strip()
    if not refresh_token:
        return None
    return SessionRestoreCandidate(
        refresh_token=refresh_token,
        username=str(getattr(snapshot, "username", "") or "").strip(),
    )


def load_user_profile_from_session(session: AuthSession) -> UserProfile:
    context = getattr(session, "permission_context", None)
    if not isinstance(context, PermissionContext):
        raise AuthError(canonical_error_message("profile_missing"))
    if context.authority_source != "postgresql.role_permissions":
        raise AuthError(canonical_error_message("profile_missing"))
    if not (context.user_id or context.username):
        raise AuthError(canonical_error_message("profile_missing"))
    if not context.is_active:
        raise AuthError(canonical_error_message("account_inactive"))
    return UserProfile.from_permission_context(context)


def sign_in_with_identifier_password(
    identifier: str,
    password: str,
) -> AuthSession:
    username = str(identifier or "").strip()
    secret = str(password or "")
    if not username or not secret:
        raise AuthError(canonical_error_message("invalid_credentials"))
    logger.info("Attempting server login")
    payload = _request_token(
        Routes.AUTH_LOGIN,
        {
            "username": username,
            "password": secret,
        },
        context="login",
    )
    return _parse_auth_session(payload)


def refresh_session(
    refresh_token: str,
) -> AuthSession:
    token = str(refresh_token or "").strip()
    if not token:
        raise AuthError(canonical_error_message("invalid_response"))
    payload = _request_token(
        Routes.AUTH_REFRESH,
        {
            "refresh_token": token,
        },
        context="auth",
    )
    return _parse_auth_session(payload)


def change_own_password(
    api_client: Any,
    current_password: str,
    new_password: str,
) -> dict[str, Any]:
    if api_client is None:
        raise AuthError("Cloud service is not available.")
    try:
        result = api_client.change_own_password(current_password, new_password)
    except SessionExpiredError as exc:
        raise AuthError(user_error_message(exc, context="auth")) from exc
    except RemoteRequestError as exc:
        raise AuthError(user_error_message(exc, context="auth")) from exc
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        raise AuthError(user_error_message(exc, context="auth")) from exc
    return dict(result or {})


class AccountSecurityService:
    """Server-authoritative password/security operations behind an app boundary."""

    def __init__(self, cloud_provider: Callable[[], Any]) -> None:
        self._cloud_provider = cloud_provider

    def _cloud(self) -> Any:
        cloud = self._cloud_provider()
        if cloud is None:
            raise RuntimeError("Server connection is required for account security.")
        return cloud

    def online(self) -> bool:
        return self._cloud_provider() is not None

    def password_policy(self) -> dict[str, Any]:
        return dict(self._cloud().password_policy() or {})

    def change_password(self, current_password: str | None, new_password: str) -> dict[str, Any]:
        return dict(
            self._cloud().change_own_password(
                None if current_password is None else str(current_password or ""),
                str(new_password or ""),
            )
            or {}
        )


class SessionPersistenceService:
    """Application boundary for remembered-session and login-form persistence.

    UI code may schedule these methods on a worker, but it never receives the
    underlying persistence repository/secure-store adapter.
    """

    def __init__(self, store: Any) -> None:
        if store is None:
            raise ValueError("SessionPersistenceService requires a persistence adapter")
        self._store = store

    def save_session(
        self,
        *,
        session: Any,
        profile: Any,
        remember: bool,
        saved_at: int = 0,
    ) -> None:
        self._store.save(
            session=session,
            profile=profile,
            remember=bool(remember),
            saved_at=max(0, int(saved_at or 0)),
        )

    def clear_session(self) -> None:
        self._store.clear()

    def load_session_snapshot(self):
        return self._store.load_snapshot()

    def save_login_form_state(self, *, username: str, remember: bool) -> None:
        self._store.save_login_form_state(
            username=str(username or "").strip(),
            remember=bool(remember),
        )

    def load_login_form_state(self):
        return self._store.load_login_form_state()


logger = logging.getLogger(__name__)


class SessionRuntimeService:
    """Application orchestration for remembered-session restore/persistence."""

    def __init__(
        self, session_persistence: Any, authentication_service: Any, cloud_runtime: Any
    ) -> None:
        if session_persistence is None or authentication_service is None or cloud_runtime is None:
            raise ValueError(
                "SessionRuntimeService requires persistence, authentication and cloud runtime"
            )
        self._persistence = session_persistence
        self._authentication = authentication_service
        self._cloud = cloud_runtime

    def restore_remembered_session(self) -> dict[str, Any]:
        try:
            snapshot = self._persistence.load_session_snapshot()
            candidate = self._authentication.restore_candidate(snapshot)
            if candidate is None:
                return {"noop": True}
            session, profile = self._authentication.refresh(candidate.refresh_token)
            permission_context = getattr(profile, "permission_context", None)
            if permission_context is not None and permission_context.has_permission("sync.pull"):
                self._cloud.temporary_pull(id_token=session.id_token, profile=profile)
            return {"session": session, "profile": profile}
        except (AuthenticationServiceError, *SERVICE_OPERATION_EXCEPTIONS) as exc:
            logger.warning("Server-authoritative session restore failed: %s", exc)
            return {"clear": True}

    def save_session(self, **kwargs) -> None:
        self._persistence.save_session(**kwargs)

    def clear_session(self) -> None:
        self._persistence.clear_session()


AuthenticationServiceError = AuthError


class AuthenticationService:
    """UI-facing authentication boundary.

    Presentation code never calls the low-level authentication use-case
    functions directly.  The service returns a fully validated session/profile
    pair so Qt controllers only coordinate workers and transitions.
    """

    @staticmethod
    def restore_candidate(snapshot: Any):
        return build_restore_candidate(snapshot)

    @staticmethod
    def sign_in(identifier: str, password: str):
        session = sign_in_with_identifier_password(identifier, password)
        profile = load_user_profile_from_session(session)
        if profile is None:
            raise AuthError(canonical_error_message("profile_missing"))
        return session, profile

    @staticmethod
    def refresh(refresh_token: str):
        session = refresh_session(refresh_token)
        profile = load_user_profile_from_session(session)
        if profile is None:
            raise AuthError(canonical_error_message("profile_missing"))
        return session, profile
