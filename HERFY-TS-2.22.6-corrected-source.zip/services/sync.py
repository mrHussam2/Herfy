from __future__ import annotations

import hashlib
import logging
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from contracts.binding import policy_allows
from contracts.bootstrap import validate_client_bootstrap
from core.concurrency import wait_for_inflight_event
from core.errors import SERVICE_OPERATION_EXCEPTIONS, is_transient_remote_error
from core.models import normalize_int, parse_bool
from core.runtime_ports import (
    close_all_thread_sessions,
    emit_data_changed,
    get_server_base_url,
    sync_startup_from_preferences,
)
from core.settings import DEFAULT_SERVER_BASE_URL, runtime_cache_path
from infra.files import read_json_dict, write_json_dict
from services.tracking import tracking_baseline


@dataclass(frozen=True)
class RealtimePullScheduleDecision:
    schedule: bool
    delay_ms: int


class RealtimePullScheduler:
    """Pure scheduling policy for the single change-driven sync pull.

    Qt owns the actual timer and worker.  This class only decides whether the
    timer should be started/restarted and whether one follow-up pull is needed
    after events arrive while a pull is already running.
    """

    def __init__(self, *, min_gap_ms: int = 450) -> None:
        self.min_gap_ms = max(0, int(min_gap_ms))
        self.pending_domains: set[str] = set()
        self.running = False
        self.rerun_requested = False
        self.last_pull_ms = 0

    def reset(self) -> None:
        self.pending_domains.clear()
        self.running = False
        self.rerun_requested = False
        self.last_pull_ms = 0

    def offer(
        self,
        domain: str,
        *,
        now_ms: int,
        requested_delay_ms: int,
        timer_active: bool,
        timer_remaining_ms: int,
    ) -> RealtimePullScheduleDecision:
        clean_domain = str(domain or "").strip().lower()
        if clean_domain:
            self.pending_domains.add(clean_domain)

        if self.running:
            self.rerun_requested = True
            return RealtimePullScheduleDecision(False, 0)

        now = max(0, int(now_ms))
        requested = max(0, int(requested_delay_ms))
        gap_remaining = 0
        if self.last_pull_ms > 0:
            gap_remaining = max(0, self.min_gap_ms - max(0, now - self.last_pull_ms))
        delay = max(requested, gap_remaining)

        if not bool(timer_active):
            return RealtimePullScheduleDecision(True, delay)

        remaining = int(timer_remaining_ms)
        if remaining < 0:
            return RealtimePullScheduleDecision(True, delay)
        if delay < remaining:
            return RealtimePullScheduleDecision(True, delay)
        return RealtimePullScheduleDecision(False, remaining)

    def begin(self, now_ms: int) -> bool:
        if self.running:
            self.rerun_requested = True
            return False
        self.running = True
        self.last_pull_ms = max(0, int(now_ms))
        # Everything pending before the request starts is covered by this pull.
        # New events arriving after begin() repopulate the set and request replay.
        self.pending_domains.clear()
        self.rerun_requested = False
        return True

    def finish(self) -> bool:
        if not self.running:
            return False
        self.running = False
        replay = bool(self.rerun_requested or self.pending_domains)
        self.rerun_requested = False
        self.pending_domains.clear()
        return replay


__all__ = ["RealtimePullScheduleDecision", "RealtimePullScheduler"]


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CloudReconnectFlowDecision:
    should_invalidate_cache: bool
    should_emit_data_refresh: bool


class CloudReconnectFlowService:
    @staticmethod
    def evaluate(
        *,
        online: bool,
        previous_online: bool,
        session_active: bool,
        login_hydrate_pending: bool = False,
    ) -> CloudReconnectFlowDecision:
        reconnect = bool(online) and (not bool(previous_online)) and bool(session_active)
        hydrate_in_progress = bool(login_hydrate_pending)
        return CloudReconnectFlowDecision(
            should_invalidate_cache=reconnect,
            should_emit_data_refresh=reconnect and not hydrate_in_progress,
        )


_BOOTSTRAP_CACHE: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}
_BOOTSTRAP_FETCH_EVENTS: dict[tuple[str, str], threading.Event] = {}
_BOOTSTRAP_FETCH_ERRORS: dict[tuple[str, str], BaseException] = {}
_BOOTSTRAP_CACHE_LOCK = threading.RLock()
_BOOTSTRAP_CACHE_TTL_SECONDS = 60.0
_BOOTSTRAP_WAIT_TIMEOUT_SECONDS = 35.0


def _fetch_cached_bootstrap(cloud_service: Any, client_version: str) -> dict[str, Any]:
    """Fetch the authenticated bootstrap once per API client/version.

    The server bootstrap is protected by JWT.  This function therefore accepts
    the active ``ApiClient`` instance and never performs an anonymous request or
    retries against an alternative endpoint.
    """
    fetch = getattr(cloud_service, "client_bootstrap", None)
    if not callable(fetch):
        raise RuntimeError("An authenticated API client is required for client bootstrap")
    base_url = str(getattr(cloud_service, "base_url", "") or "").rstrip("/")
    version = str(client_version or "").strip()
    if not base_url:
        raise RuntimeError("Authenticated API client has no base URL")
    if not version:
        raise ValueError("client_version is required")

    key = (base_url, version)
    now = time.monotonic()
    owner = False
    with _BOOTSTRAP_CACHE_LOCK:
        cached = _BOOTSTRAP_CACHE.get(key)
        if cached is not None:
            ts, payload = cached
            if now - float(ts) <= _BOOTSTRAP_CACHE_TTL_SECONDS and isinstance(payload, dict):
                return dict(payload)
        event = _BOOTSTRAP_FETCH_EVENTS.get(key)
        if event is None:
            event = threading.Event()
            _BOOTSTRAP_FETCH_EVENTS[key] = event
            _BOOTSTRAP_FETCH_ERRORS.pop(key, None)
            owner = True

    if not owner:
        if not wait_for_inflight_event(
            event,
            timeout_seconds=_BOOTSTRAP_WAIT_TIMEOUT_SECONDS,
            logger_=logger,
            context="client bootstrap coalescing",
        ):
            raise TimeoutError("Timed out waiting for the client bootstrap request")
        with _BOOTSTRAP_CACHE_LOCK:
            cached = _BOOTSTRAP_CACHE.get(key)
            if cached is not None and isinstance(cached[1], dict):
                return dict(cached[1])
            error = _BOOTSTRAP_FETCH_ERRORS.get(key)
        if error is not None:
            raise RuntimeError("Client bootstrap request failed") from error
        raise RuntimeError("Client bootstrap completed without a payload")

    try:
        payload = fetch(version)
        if not isinstance(payload, dict) or not payload:
            raise RuntimeError("Client bootstrap returned an empty or invalid response")
        result = dict(payload)
        with _BOOTSTRAP_CACHE_LOCK:
            _BOOTSTRAP_CACHE[key] = (time.monotonic(), dict(result))
        return dict(result)
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        with _BOOTSTRAP_CACHE_LOCK:
            _BOOTSTRAP_FETCH_ERRORS[key] = exc
        raise
    finally:
        with _BOOTSTRAP_CACHE_LOCK:
            completed = _BOOTSTRAP_FETCH_EVENTS.pop(key, None)
            if completed is not None:
                completed.set()


def current_api_base_url() -> str:
    try:
        return str(get_server_base_url(DEFAULT_SERVER_BASE_URL) or DEFAULT_SERVER_BASE_URL).strip()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("Falling back to default API base URL", exc_info=True)
        return DEFAULT_SERVER_BASE_URL


def profile_to_cloud_user_payload(profile) -> dict[str, Any]:
    if profile is None:
        return {}
    converter = getattr(profile, "to_cloud_user_payload", None)
    if not callable(converter):
        raise TypeError("Authenticated profile must expose the canonical authority payload")
    payload = converter()
    if not isinstance(payload, dict):
        raise TypeError("Authenticated profile authority payload must be a dict")
    return payload


def prepare_update_check(
    settings_store, *, force: bool, now_ts: int | None = None
) -> tuple[str, bool]:
    """Resolve the update-check policy from the canonical application settings owner."""
    store = settings_store
    if store is None:
        return ("", False)
    getter = getattr(store, "get_setting", None)
    setter = getattr(store, "set_setting", None)
    if not callable(getter) or not callable(setter):
        raise TypeError("Update settings owner must provide get_setting/set_setting")
    current_ts = int(time.time()) if now_ts is None else int(now_ts)
    enabled = parse_bool(getter("check_updates_on_startup", "True"), True)
    if not force and not enabled:
        return ("", False)
    try:
        last_check = int(getter("updates/last_success", 0) or 0)
    except (TypeError, ValueError):
        last_check = 0
    skipped = str(getter("updates/skipped_version", "") or "")
    if not force and last_check and (current_ts - last_check < 12 * 3600):
        return (skipped, False)
    setter("updates/last_attempt", str(current_ts))
    return (skipped, True)


def _read_bool_setting(settings: Any, key: str, default: bool = False) -> bool:
    if settings is None:
        return bool(default)
    try:
        value = settings.get_setting(key, "True" if default else "False")
        return parse_bool(value, default)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to read startup setting: %s", key)
        return bool(default)


def normalize_startup_preferences(settings: Any, *, persist: bool = False) -> dict[str, bool]:
    start_with_windows = _read_bool_setting(settings, "start_with_windows", True)
    tray_hint = _read_bool_setting(settings, "tray_show_message_on_minimize", False)
    normalized = {
        "enable_tray_background": True,
        "start_with_windows": start_with_windows,
        "tray_show_message_on_minimize": tray_hint,
    }
    if persist and settings is not None:
        try:
            for key, value in normalized.items():
                settings.set_setting(key, "True" if value else "False")
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to persist normalized startup preferences")
    return normalized


def sync_startup_from_settings(settings: Any) -> bool:
    if settings is None:
        return False
    try:
        preferences = normalize_startup_preferences(settings, persist=True)
        return sync_startup_from_preferences(preferences)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to sync startup settings")
        return False


def apply_startup_preferences(settings: Any) -> bool:
    return sync_startup_from_settings(settings)


class StartupRuntimeSnapshot:
    """Normalized view of the exact ``ClientBootstrapResponse`` contract."""

    def __init__(
        self,
        startup_config: dict | None = None,
        compatibility_policy: dict | None = None,
        integrity: dict | None = None,
        server_time: str = "",
        rules: dict[str, Any] | None = None,
    ) -> None:
        self.startup_config = dict(startup_config or {})
        self.compatibility_policy = dict(compatibility_policy or {})
        self.integrity = dict(integrity or {})
        self.server_time = str(server_time or "")
        self.rules = dict(rules or {})


class ServerRuntimeService:
    """Apply runtime data returned by the matched authenticated server."""

    def __init__(self, base_url: str | None = None):
        # ``base_url`` remains only for cache identity/backward construction.
        # Network requests always use the authenticated ApiClient passed to fetch.
        try:
            resolved_base_url = base_url or get_server_base_url(DEFAULT_SERVER_BASE_URL)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Using release API base URL for server runtime cache", exc_info=True)
            resolved_base_url = DEFAULT_SERVER_BASE_URL
        self.base_url = str(resolved_base_url or DEFAULT_SERVER_BASE_URL).rstrip("/")
        self.cache_file = Path(runtime_cache_path("remote_state/startup_client_bootstrap.json"))
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _snapshot_from_payload(
        payload: dict[str, Any] | None,
    ) -> StartupRuntimeSnapshot | None:
        if not isinstance(payload, dict) or not payload:
            return None

        data = validate_client_bootstrap(payload)
        minimum = str(data["minimum_client_version"] or "").strip()
        server_version = str(data["server_version"] or "").strip()
        contract_version = str(data["contract_version"] or "").strip()

        startup_config = {
            "backend_version": server_version,
            "server_version": server_version,
            "api_version": contract_version,
            "contract_version": contract_version,
            "min_supported_client_version": minimum,
            "client_runtime": {
                "force_logout_below_version": minimum,
            },
        }
        compatibility_policy = {
            "server_version": server_version,
            "contract_version": contract_version,
            "minimum_supported_version": minimum,
        }
        integrity = {
            "contract_version": contract_version,
            "authority_revision": int(data["authority_revision"]),
        }
        return StartupRuntimeSnapshot(
            startup_config=startup_config,
            compatibility_policy=compatibility_policy,
            integrity=integrity,
            server_time=str(data["server_time"]),
            rules={},
        )

    def _save_cache(self, payload: dict[str, Any]) -> None:
        # Save only a payload that satisfies the locked OpenAPI response model.
        validated = validate_client_bootstrap(payload)
        validated.pop("authority", None)
        write_json_dict(self.cache_file, validated, ensure_ascii=False)

    def load_cached(self) -> StartupRuntimeSnapshot | None:
        try:
            if not self.cache_file.exists():
                return None
            return self._snapshot_from_payload(read_json_dict(self.cache_file))
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to load cached client bootstrap")
            return None

    def fetch_client_bootstrap(
        self,
        client_version: str,
        cloud_service: Any,
    ) -> StartupRuntimeSnapshot:
        payload = _fetch_cached_bootstrap(cloud_service, client_version)
        self._save_cache(payload)
        snapshot = self._snapshot_from_payload(payload)
        if snapshot is None:
            raise RuntimeError("Matched server returned no client bootstrap")
        return snapshot

    def apply_startup_config(
        self, settings, snapshot: StartupRuntimeSnapshot | None
    ) -> dict[str, Any]:
        snap = snapshot or self.load_cached()
        if snap is None:
            return {}

        config = dict(snap.startup_config)
        client_runtime = dict(config.get("client_runtime") or {})
        pairs = {
            "remote_backend_version": str(config["backend_version"]),
            "remote_api_version": str(config["api_version"]),
            "remote_min_supported_client_version": str(config["min_supported_client_version"]),
            "remote_authority_revision": str(snap.integrity.get("authority_revision", "")),
            "remote_force_logout_below_version": str(
                client_runtime.get("force_logout_below_version") or ""
            ),
        }
        for key, value in pairs.items():
            try:
                settings.set_setting(key, value)
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Failed to persist client bootstrap setting: %s", key)

        return {
            "startup_config": config,
            "compatibility_policy": dict(snap.compatibility_policy),
            "integrity": dict(snap.integrity),
            "server_time": snap.server_time,
            "rules": dict(snap.rules),
        }

    def fetch_and_apply(
        self,
        settings,
        client_version: str,
        cloud_service: Any,
    ) -> dict[str, Any]:
        snapshot = self.fetch_client_bootstrap(client_version, cloud_service)
        return self.apply_startup_config(settings, snapshot)


logger = logging.getLogger(__name__)


class CloudSyncRuntimeService:
    """Application boundary for shell-facing cloud/sync orchestration.

    Qt presentation code coordinates timers and visual state only.  It does not
    import sync policy helpers or manipulate the synchronization coordinator
    directly through the desktop application facade.
    """

    def __init__(self, application: Any) -> None:
        if application is None:
            raise ValueError("CloudSyncRuntimeService requires an application")
        self._application = application

    def connected(self) -> bool:
        return bool(self._application.server_connected())

    def permission_context(self):
        return self._application.permission_context()

    def attach_session(self, *, id_token: str, profile: Any) -> None:
        self._application.cloud.attach(id_token=id_token, profile=profile)

    def close_current(self, *, clear_reference: bool = True) -> None:
        self._application.cloud.close_current(clear_reference=bool(clear_reference))

    def disconnect_session(self, *, clear_catalog: bool = True) -> None:
        self._application.cloud.close_current(clear_reference=False)
        try:
            self._application.sync.reset_cursor()
            clear_scoped = getattr(self._application, "clear_session_scoped_local_data", None)
            if callable(clear_scoped):
                clear_scoped(clear_catalog=bool(clear_catalog))
        finally:
            set_context = getattr(self._application, "set_cloud_context", None)
            if callable(set_context):
                set_context(None, None)

    def temporary_pull(self, *, id_token: str, profile: Any):
        return self._application.cloud.temporary_pull(id_token=id_token, profile=profile)

    @staticmethod
    def profile_payload(profile: Any) -> dict[str, Any]:
        return profile_to_cloud_user_payload(profile)

    def set_identity_profile(self, profile: Any) -> None:
        self._application.cloud.set_identity_payload(self.profile_payload(profile))

    def set_id_token(self, id_token: str) -> None:
        self._application.cloud.set_id_token(str(id_token or ""))

    def refresh_profile(self, profile: Any) -> None:
        self._application.cloud.refresh_profile(profile)

    def allowed_branches(self) -> list[str]:
        return list(self._application.allowed_branches() or [])

    def active_branch(self) -> str:
        return str(self._application.active_branch() or "").strip()

    def set_allowed_branches(self, branches: list[str]) -> None:
        self._application.set_allowed_branches(branches)

    def meta_branches(self) -> list[str]:
        return list(self._application.cloud.meta_branches() or [])

    def sync_cursor(self) -> int:
        return int(self._application.cloud.sync_cursor())

    def reset_cursor(self) -> None:
        self._application.sync.reset_cursor()

    def has_tracking_baseline(self) -> bool:
        return bool(self._application.sync.has_tracking_baseline())

    def baseline_required(self) -> bool:
        return bool(self._application.sync.baseline_required())

    def apply_catalog_snapshot(self, snapshot: dict | None) -> None:
        if isinstance(snapshot, dict) and snapshot:
            self._application.sync.apply_catalog_snapshot(snapshot)

    def context_attached(self) -> bool:
        return bool(self._application.sync.context_attached())

    def sync_identity_metadata(self) -> dict[str, str]:
        return dict(self._application.sync.sync_identity_metadata() or {})

    def authority_revision(self) -> int:
        return int(self._application.sync.authority_revision())

    def load_initial_payload(self) -> dict[str, Any]:
        """Hydrate durable sync state plus ephemeral server-authoritative catalogs.

        The sync cursor/tracking baseline are durable, while stored/usage catalog
        projections are intentionally ephemeral.  Therefore a non-zero cursor
        after process restart must not suppress catalog hydration.
        """
        payload = self.load_change_payload()
        if not self.connected():
            return payload

        ctx = self.permission_context()
        stored_rows: list[dict] = []
        usage_rows: list[dict] = []

        if policy_allows("catalog.stored.view", ctx.permissions):
            stored_rows = list(self._application.refresh_stored_products() or [])
        else:
            self._application.stored_catalog.replace_authoritative([])

        if policy_allows("catalog.usage.view", ctx.permissions):
            usage_rows = list(self._application.refresh_usage_products(force=True) or [])
        else:
            self._application.usage_catalog.replace_authoritative([])

        payload = dict(payload or {})
        payload["stored_catalog_delta"] = {
            "applied": True,
            "full_recovery": True,
            "count": len(stored_rows),
            "source": "authenticated-startup",
        }
        payload["usage_delta"] = {
            "applied": True,
            "full_recovery": True,
            "count": len(usage_rows),
            "source": "authenticated-startup",
        }
        payload["catalogs_hydrated"] = True
        return payload

    def load_change_payload(self) -> dict[str, Any]:
        try:
            ctx = self.permission_context()
            if self.connected() and not ctx.has_permission("sync.pull"):
                return {
                    "preloaded": None,
                    "online": True,
                    "sync_authorized": False,
                    "rows": [],
                    "events": [],
                    "changes": [],
                    "next_cursor": int(getattr(self._application.sync, "cursor", lambda: 0)()),
                    "has_more": False,
                    "baseline_loaded": bool(
                        getattr(self._application.sync, "has_tracking_baseline", lambda: False)()
                    ),
                    "baseline_required": False,
                    "delta_applied": False,
                }

            payload = dict(self._application.sync.pull_and_apply() or {})
            payload.setdefault("sync_authorized", True)
            if not bool(payload.get("online")):
                return payload

            # Catalog deltas have already been validated and applied to their
            # local projections by SyncCoordinator.  A pull is the sole source
            # of reconciliation: never turn its wake-up into a second full
            # catalog request, otherwise every SSE event causes redundant I/O
            # and can race the cursor-committed projection.
            return payload
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            logger.exception("Authenticated cloud pull failed")
            transport_offline = is_transient_remote_error(exc)
            return {
                "preloaded": None,
                "online": not transport_offline,
                "sync_error": type(exc).__name__,
                "rows": [],
                "events": [],
                "changes": [],
                "next_cursor": int(getattr(self._application.sync, "cursor", lambda: 0)()),
                "has_more": False,
                "baseline_loaded": bool(
                    getattr(self._application.sync, "has_tracking_baseline", lambda: False)()
                ),
                "baseline_required": bool(
                    getattr(self._application.sync, "baseline_required", lambda: True)()
                ),
                "delta_applied": False,
            }

    def start_realtime(self, *, on_changed, on_state) -> None:
        self._application.cloud.start_realtime(on_changed, on_state=on_state)

    def restore_cursor(self) -> None:
        """Reattach the durable cursor before opening/reopening the SSE stream."""
        self._application.sync.restore_remote_cursor()

    def ensure_realtime(self, *, hydrate_pending: bool, on_changed, on_state) -> bool:
        """Start the sole SSE transport only after the authoritative baseline exists."""
        if hydrate_pending or not self.connected():
            return False
        # The API client can be refreshed while the user session remains active.
        # Reapply the persisted per-user cursor immediately before connection so
        # reconnects never depend on visiting a page or pressing Refresh.
        self.restore_cursor()
        self._application.cloud.start_realtime(on_changed, on_state=on_state)
        return True

    def stop_realtime(self) -> None:
        self._application.cloud.stop_realtime()

    def shutdown_transports(self) -> None:
        try:
            self._application.cloud.close_current(clear_reference=True)
        finally:
            close_all_thread_sessions()

    @staticmethod
    def reconnect_flow(
        *,
        online: bool,
        previous_online: bool,
        session_active: bool,
        login_hydrate_pending: bool = False,
    ):
        return CloudReconnectFlowService.evaluate(
            online=online,
            previous_online=previous_online,
            session_active=session_active,
            login_hydrate_pending=login_hydrate_pending,
        )


logger = logging.getLogger(__name__)


class SyncCoordinator:
    """The only application owner of server cursor and durable remote-delta apply."""

    CURSOR_PREFIX = "sync"

    def __init__(self, settings, tracking_repository, stored_catalog, usage_catalog, context):
        self._settings = settings
        self._tracking = tracking_repository
        self._stored = stored_catalog
        self._usage = usage_catalog
        self._context = context

    @staticmethod
    def _normalize_server_identity(value: str) -> str:
        return str(value or "").strip().rstrip("/").casefold()

    def _context_identity(self) -> tuple[str, str]:
        remote = self._context.api_client
        profile = self._context.current_user
        server_url = self._normalize_server_identity(getattr(remote, "base_url", ""))
        user_identity = (
            str(getattr(profile, "user_id", "") or getattr(profile, "username", "") or "")
            .strip()
            .casefold()
        )
        return server_url, user_identity

    def context_attached(self) -> bool:
        server_url, user_identity = self._context_identity()
        return bool(server_url and user_identity)

    def sync_identity_metadata(self) -> dict[str, str]:
        server_url, user_identity = self._context_identity()
        if not server_url or not user_identity:
            return {"server_identity": "", "user_identity": ""}
        return {
            "server_identity": hashlib.sha256(server_url.encode("utf-8")).hexdigest(),
            "user_identity": user_identity,
        }

    def _scope_digest(self) -> str:
        server_url, user_identity = self._context_identity()
        if not server_url or not user_identity:
            raise RuntimeError("Authenticated server/user sync context is not attached")
        server_identity = hashlib.sha256(server_url.encode("utf-8")).hexdigest()
        sync_identity = f"{server_identity}:{user_identity}"
        return hashlib.sha256(sync_identity.encode("utf-8")).hexdigest()

    def _scoped_key(self, suffix: str) -> str:
        return f"{self.CURSOR_PREFIX}.{self._scope_digest()}.{suffix}"

    def _projection_context_key(self) -> str:
        return self._scope_digest()

    def cursor(self) -> int:
        if not self.context_attached():
            return 0
        return max(0, normalize_int(self._settings.get_setting(self._scoped_key("cursor"), "0"), 0))

    def authority_revision(self) -> int:
        if not self.context_attached():
            return 0
        return max(
            0,
            normalize_int(
                self._settings.get_setting(self._scoped_key("authority_revision"), "0"), 0
            ),
        )

    def commit_authority_revision(self, revision: int | str | None) -> None:
        if revision is None or not self.context_attached():
            return
        value = max(0, normalize_int(revision, 0))
        self._settings.set_setting(self._scoped_key("authority_revision"), str(value))
        remote = self._context.api_client
        if remote is not None and hasattr(remote, "set_sync_authority_revision"):
            remote.set_sync_authority_revision(value)

    def commit_cursor(self, cursor: int | str | None) -> bool:
        if cursor is None:
            return False
        value = max(0, normalize_int(cursor, 0))
        current = self.cursor()
        if value < current:
            raise RuntimeError("Sync cursor cannot move backwards")
        self._settings.set_setting(self._scoped_key("cursor"), str(value))
        remote = self._context.api_client
        if remote is not None and hasattr(remote, "set_sync_cursor"):
            remote.set_sync_cursor(value)
        return True

    def restore_remote_cursor(self) -> None:
        remote = self._context.api_client
        if remote is not None and hasattr(remote, "set_sync_cursor"):
            remote.set_sync_cursor(self.cursor())
        if remote is not None and hasattr(remote, "set_sync_authority_revision"):
            remote.set_sync_authority_revision(self.authority_revision())

    def reset_cursor(self) -> None:
        if self.context_attached():
            self._settings.clear_server_projection(self._projection_context_key())
            self._settings.set_setting(self._scoped_key("cursor"), "0")
            self._settings.set_setting(self._scoped_key("baseline_loaded"), "0")
            self._settings.set_setting(self._scoped_key("authority_revision"), "0")
        remote = self._context.api_client
        if remote is not None and hasattr(remote, "set_sync_cursor"):
            remote.set_sync_cursor(0)
        if remote is not None and hasattr(remote, "set_sync_authority_revision"):
            remote.set_sync_authority_revision(0)

    def mark_baseline_loaded(self) -> None:
        self._settings.set_setting(self._scoped_key("baseline_loaded"), "1")

    def has_tracking_baseline(self) -> bool:
        if not self.context_attached():
            return False
        return bool(
            normalize_int(self._settings.get_setting(self._scoped_key("baseline_loaded"), "0"), 0)
        )

    def baseline_required(self) -> bool:
        return self.cursor() <= 0 or not self.has_tracking_baseline()

    def apply_catalog_snapshot(self, snapshot: dict | None) -> dict[str, str]:
        return self._stored.apply_snapshot(snapshot)

    def _publish_tracking_projection(self, *, source: str) -> None:
        rows = list(self._tracking.fetch_cached_tracked_products() or [])
        tracking_baseline.publish(rows, source=source)

    def apply_tracking_baseline(self, rows: list[dict] | None, *, publish: bool = True) -> bool:
        ok = bool(self._tracking.replace_cached_cloud_tracking_products(list(rows or [])))
        if ok and publish:
            self._settings.set_setting(self._scoped_key("baseline_loaded"), "1")
            self._publish_tracking_projection(source="sync")
        return ok

    def apply_full_recovery(
        self,
        *,
        tracking_rows: list[dict] | None,
        stored_products: list[dict] | None,
        usage_products: list[dict] | None,
        organizations: list[dict] | None,
        regions: list[dict] | None,
        areas: list[dict] | None,
        branches: list[dict] | None,
        next_cursor: int | str | None,
        recovery_reason: str,
        authority_revision: int | str | None,
        authority: dict[str, Any],
    ) -> dict[str, Any]:
        if recovery_reason not in {"initial", "authority_changed"}:
            raise RuntimeError("Invalid full recovery reason")
        # Authority is applied first. If it cannot be validated/persisted, the
        # authoritative cursor must remain unchanged.
        self._context.apply_server_authority(dict(authority or {}))
        if not self.apply_tracking_baseline(list(tracking_rows or []), publish=False):
            raise RuntimeError("Unable to persist authoritative tracking recovery snapshot")
        projection_snapshots = {
            "organization": list(organizations or []),
            "region": list(regions or []),
            "area": list(areas or []),
            "branch": list(branches or []),
            "stored_product": list(stored_products or []),
            "usage_product": list(usage_products or []),
        }
        self._settings.replace_server_projection(
            self._projection_context_key(),
            projection_snapshots,
        )
        stored_rows = self._stored.replace_authoritative(
            list(stored_products or []), emit_event=False
        )
        usage_rows = self._usage.replace_authoritative(list(usage_products or []), emit_event=False)
        committed = self.commit_cursor(next_cursor) if next_cursor is not None else False
        self.commit_authority_revision(authority_revision)
        if next_cursor is not None and not committed:
            raise RuntimeError("Unable to commit full recovery cursor")
        self._settings.set_setting(self._scoped_key("baseline_loaded"), "1")
        self._publish_tracking_projection(source="sync")
        remote = self._context.api_client
        if committed and remote is not None:
            invalidate = getattr(remote, "invalidate_after_sync_apply", None)
            if callable(invalidate):
                invalidate([{"entity_type": "authorization"}])
        emit_data_changed(
            "sync",
            {
                "full_recovery": True,
                "recovery_reason": recovery_reason,
                "stored_count": len(stored_rows),
                "usage_count": len(usage_rows),
            },
        )
        return {
            "stored_catalog_delta": {
                "applied": True,
                "full_recovery": True,
                "count": len(stored_rows),
            },
            "tracking_delta": {
                "applied": True,
                "full_recovery": True,
                "count": len(list(tracking_rows or [])),
            },
            "usage_delta": {"applied": True, "full_recovery": True, "count": len(usage_rows)},
            "server_projection_delta": {
                "applied": True,
                "full_recovery": True,
                "count": sum(len(rows) for rows in projection_snapshots.values()),
            },
            "cursor_committed": committed,
            "delta_applied": True,
            "delta_apply_failed": False,
            "full_recovery": True,
            "recovery_reason": recovery_reason,
            "authority_revision": normalize_int(authority_revision, 0),
            "authority_reconcile_required": recovery_reason == "authority_changed",
        }

    @staticmethod
    def _change_cursor(event: dict) -> int:
        if not isinstance(event, dict):
            raise RuntimeError("Sync change must be an object")
        raw = event.get("cursor", event.get("change_id"))
        value = normalize_int(raw, -1)
        if value < 0:
            raise RuntimeError("Sync change is missing a valid cursor/change_id")
        return value

    def _ordered_changes(self, changes: list[dict] | None) -> list[dict]:
        committed_cursor = self.cursor()
        ordered = sorted(
            (dict(event) for event in list(changes or [])),
            key=self._change_cursor,
        )
        result: list[dict] = []
        seen: set[int] = set()
        for event in ordered:
            cursor = self._change_cursor(event)
            if cursor <= committed_cursor or cursor in seen:
                continue
            seen.add(cursor)
            result.append(event)
        return result

    def apply_changes(
        self, changes: list[dict] | None, *, next_cursor: int | str | None = None
    ) -> dict[str, Any]:
        events = self._ordered_changes(changes)
        highest_event_cursor = max(
            (self._change_cursor(event) for event in events), default=self.cursor()
        )
        candidate_cursor = (
            self.cursor() if next_cursor is None else max(0, normalize_int(next_cursor, -1))
        )
        if next_cursor is not None and candidate_cursor < highest_event_cursor:
            raise RuntimeError("Sync next_cursor is behind the applied change batch")

        # Repository/service projections must all succeed before the durable cursor
        # advances. A failure leaves the committed cursor untouched so the same
        # idempotent batch is retried on the next reconciliation.
        projection_count = self._settings.apply_server_projection_changes(
            self._projection_context_key(),
            events,
        )
        stored = self._stored.apply_remote_changes(events, emit_event=False)
        tracking = self._tracking.apply_remote_tracking_changes(events)
        usage = self._usage.apply_remote_changes(events, emit_event=False)
        committed = False
        if next_cursor is not None:
            committed = self.commit_cursor(candidate_cursor)
        remote = self._context.api_client
        if committed and events and remote is not None:
            invalidate = getattr(remote, "invalidate_after_sync_apply", None)
            if callable(invalidate):
                invalidate(events)
        if bool((tracking or {}).get("applied")):
            self._publish_tracking_projection(source="sync")
        if any(bool((part or {}).get("applied")) for part in (stored, tracking, usage)):
            emit_data_changed("sync", {"stored": stored, "tracking": tracking, "usage": usage})
        return {
            "stored_catalog_delta": stored,
            "tracking_delta": tracking,
            "usage_delta": usage,
            "server_projection_delta": {"applied": True, "count": projection_count},
            "cursor_committed": committed,
            "delta_applied": True,
            "delta_apply_failed": False,
        }

    def apply_pull_payload(
        self, payload: dict | None, *, baseline_rows: list[dict] | None = None
    ) -> dict[str, Any]:
        data = dict(payload or {})
        authority = data.get("authority")
        if not isinstance(authority, dict):
            raise RuntimeError("Sync payload is missing canonical server authority")
        self._context.apply_server_authority(authority)
        baseline_loaded = baseline_rows is not None
        if baseline_loaded:
            if not self.apply_tracking_baseline(baseline_rows, publish=False):
                raise RuntimeError("Unable to persist authoritative tracking baseline")
        changes = (
            data.get("changes") if isinstance(data.get("changes"), list) else data.get("events")
        )
        candidate_cursor = data["next_cursor"] if "next_cursor" in data else data.get("cursor")
        result = self.apply_changes(
            list(changes or []),
            next_cursor=candidate_cursor,
        )
        if baseline_loaded:
            if not result["cursor_committed"]:
                raise RuntimeError("Unable to commit tracking baseline cursor")
            self._settings.set_setting(self._scoped_key("baseline_loaded"), "1")
            if not bool((result.get("tracking_delta") or {}).get("applied")):
                self._publish_tracking_projection(source="sync")
        self.commit_authority_revision(data.get("authority_revision"))
        data.update(result)
        return data

    def pull_and_apply(self) -> dict[str, Any]:
        remote = self._context.api_client
        if remote is None:
            return {"online": False, "events": [], "next_cursor": self.cursor()}
        self.restore_remote_cursor()
        result = dict(remote.pull_now() or {})
        expected = {
            "rows",
            "events",
            "next_cursor",
            "has_more",
            "mode",
            "recovery_reason",
            "stored_products",
            "usage_products",
            "organizations",
            "regions",
            "areas",
            "branches",
            "authority_revision",
            "authority",
        }
        if set(result) != expected:
            raise RuntimeError("Remote sync result violates canonical contract")

        mode = str(result["mode"] or "").strip().lower()
        if mode == "full":
            tracking_rows = list(result["rows"] or [])
            recovery_reason = str(result["recovery_reason"] or "")
            payload = {
                "online": True,
                "rows": tracking_rows,
                "events": list(result["events"] or []),
                "changes": list(result["events"] or []),
                "next_cursor": normalize_int(result["next_cursor"], self.cursor()),
                "has_more": False,
                "mode": "full",
                "recovery_reason": recovery_reason,
                "authority_revision": normalize_int(result["authority_revision"], 0),
                "authority": dict(result["authority"]),
                "preloaded": tracking_rows,
            }
            payload.update(
                self.apply_full_recovery(
                    tracking_rows=tracking_rows,
                    stored_products=list(result["stored_products"] or []),
                    usage_products=list(result["usage_products"] or []),
                    organizations=list(result["organizations"] or []),
                    regions=list(result["regions"] or []),
                    areas=list(result["areas"] or []),
                    branches=list(result["branches"] or []),
                    next_cursor=result["next_cursor"],
                    recovery_reason=recovery_reason,
                    authority_revision=result["authority_revision"],
                    authority=dict(result["authority"]),
                )
            )
            payload["baseline_loaded"] = self.has_tracking_baseline()
            payload["baseline_required"] = not payload["baseline_loaded"]
            return payload

        if mode != "incremental":
            raise RuntimeError("Remote sync mode is invalid")

        baseline_rows: list[dict] | None = None
        if self.baseline_required():
            snapshot_items = getattr(remote, "snapshot_items", None)
            if not callable(snapshot_items):
                raise RuntimeError(
                    "Authenticated remote cannot restore a missing tracking baseline"
                )
            # A non-zero cursor with a lost local baseline must recover from one
            # authoritative, scope-filtered server snapshot before applying deltas.
            baseline_rows = list(snapshot_items() or [])

        payload = {
            "online": True,
            "rows": list(result.get("rows") or []),
            "events": list(result.get("events") or []),
            "changes": list(result.get("events") or []),
            "next_cursor": normalize_int(result.get("next_cursor"), self.cursor()),
            "has_more": bool(result.get("has_more")),
            "mode": "incremental",
            "recovery_reason": "",
            "authority_revision": normalize_int(result.get("authority_revision"), 0),
            "authority": dict(result.get("authority") or {}),
            "preloaded": baseline_rows,
        }
        applied = self.apply_pull_payload(payload, baseline_rows=baseline_rows)
        applied["baseline_loaded"] = self.has_tracking_baseline()
        applied["baseline_required"] = not applied["baseline_loaded"]
        return applied
