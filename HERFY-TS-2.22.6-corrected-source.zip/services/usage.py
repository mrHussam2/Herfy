from __future__ import annotations

import logging
import os
import threading
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from typing import Any

from core.concurrency import wait_for_inflight_event
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import best_product_name, parse_plain_number
from core.runtime_ports import TabularInputReader, emit_updated
from core.settings import _, resource_path
from infra.excel import normalize_material_match_key, parse_beginning, parse_receipts
from services.catalog_changes import apply_remote_catalog_changes
from services.preferences import active_username

logger = logging.getLogger(__name__)


class UsageCatalogService:
    """Server-authoritative usage catalog with an ephemeral read projection."""

    def __init__(self, repository: Any, *, remote_provider: Callable[[], Any]):
        self._repository = repository
        self._remote_provider = remote_provider
        self._refresh_lock = threading.RLock()
        self._refresh_event: threading.Event | None = None
        self._refresh_result: list[dict] = []
        self.last_refresh_source = ""
        self.last_refresh_error = ""

    @property
    def remote_available(self) -> bool:
        return self._remote_provider() is not None

    def list_local(self) -> list[dict]:
        return list(self._repository.fetch_usage_products() or [])

    def refresh_from_server(self, *, force: bool = True) -> list[dict]:
        remote = self._remote_provider()
        if remote is None:
            self.last_refresh_source = "local-no-remote"
            return self.list_local()
        if not force:
            local = self.list_local()
            if local:
                self.last_refresh_source = "local-cache"
                return local

        with self._refresh_lock:
            if self._refresh_event is None:
                event = threading.Event()
                self._refresh_event = event
                owner = True
            else:
                event = self._refresh_event
                owner = False

        if not owner:
            if not wait_for_inflight_event(
                event,
                timeout_seconds=10.0,
                logger_=logger,
                context="UsageCatalogService.refresh_from_server",
            ):
                return self.list_local()
            with self._refresh_lock:
                return list(self._refresh_result)

        try:
            try:
                # /catalog/usage-products is the read authority. A successful
                # empty response is authoritative and must remain empty.
                rows = list(remote.list_usage_products(force_refresh=force) or [])
                source = "catalog.usage.view"
                self._repository.replace_usage_products(rows)
                result = self.list_local()
                self.last_refresh_source = source
                self.last_refresh_error = ""
            except (
                AttributeError,
                LookupError,
                OSError,
                RuntimeError,
                TypeError,
                ValueError,
            ) as exc:
                self.last_refresh_source = "catalog.usage.view"
                self.last_refresh_error = str(exc)
                logger.warning("Usage catalog refresh failed: %s", exc)
                raise

            with self._refresh_lock:
                self._refresh_result = list(result)
            logger.info(
                "USAGE_CATALOG_REFRESH source=%s count=%d fallback_error=%s",
                self.last_refresh_source or "server",
                len(result),
                bool(self.last_refresh_error),
            )
            emit_updated(
                "usage",
                {
                    "action": "refresh",
                    "count": len(result),
                    "source": self.last_refresh_source or "server",
                },
            )
            return result
        finally:
            with self._refresh_lock:
                current = self._refresh_event
                self._refresh_event = None
                if current is not None:
                    current.set()

    def replace_authoritative(
        self, rows: list[dict] | None, *, emit_event: bool = True
    ) -> list[dict]:
        self._repository.replace_usage_products(list(rows or []))
        replaced = self.list_local()
        if emit_event:
            emit_updated("usage", {"action": "full_recovery", "count": len(replaced)})
        return replaced

    def apply_remote_changes(self, changes: list[dict] | None, *, emit_event: bool = True) -> dict:
        return apply_remote_catalog_changes(
            self._repository.apply_remote_usage_changes,
            changes,
            entity_type="usage",
            event_extras={"source": "server"},
            emit_event=emit_event,
        )


@dataclass(frozen=True)
class UsageWorkspaceDecision:
    allowed: bool
    message: str = ""


@dataclass(frozen=True)
class UsageFilePresentation:
    display_name: str
    tooltip: str


class UsageWorkspaceService:
    def __init__(self, *, presentation_preferences, settings_service, app_state) -> None:
        if presentation_preferences is None or settings_service is None:
            raise ValueError(
                "UsageWorkspaceService requires composed preferences/settings services"
            )
        self._preferences = presentation_preferences
        self._settings_service = settings_service
        self._app_state = app_state

    def format_selected_file(self, path: str) -> UsageFilePresentation:
        clean_path = str(path or "").strip()
        if not clean_path:
            return UsageFilePresentation(display_name=_("No file selected"), tooltip="")
        return UsageFilePresentation(display_name=os.path.basename(clean_path), tooltip=clean_path)

    def auto_compute_ready(self, receipts_path: str, beginning_path: str) -> bool:
        return bool(str(receipts_path or "").strip() and str(beginning_path or "").strip())

    def evaluate_compute_request(
        self,
        *,
        access_allowed: bool,
        access_reason: str,
        usage_service: Any,
        receipts_path: str,
        beginning_path: str,
    ) -> UsageWorkspaceDecision:
        if not access_allowed:
            return UsageWorkspaceDecision(
                False,
                access_reason or _("Usage is not available for the current account."),
            )
        if usage_service is None:
            return UsageWorkspaceDecision(False, _("Usage service is unavailable."))
        receipts_path = str(receipts_path or "").strip()
        beginning_path = str(beginning_path or "").strip()
        if not (
            receipts_path
            and beginning_path
            and os.path.exists(receipts_path)
            and os.path.exists(beginning_path)
        ):
            return UsageWorkspaceDecision(False, _("Select both input files first."))
        return UsageWorkspaceDecision(True, "")

    def build_result_status(self, rows: Sequence[dict] | None, usage_service: Any) -> str:
        rows = list(rows or [])
        info = getattr(usage_service, "last_compute_info", {}) if usage_service is not None else {}
        status = str(info.get("status") or "")
        if rows:
            matched = int(info.get("matched_count") or 0)
            catalog_count = int(info.get("catalog_count") or len(rows))
            if status == "no_catalog_matches":
                return _(
                    "Loaded {count} server-selected products; no imported material numbers matched."
                ).format(count=catalog_count)
            if catalog_count > 0:
                return _(
                    "Loaded {count} server-selected products • {matched} matched imported rows"
                ).format(count=catalog_count, matched=matched)
            return _("Done ({count} rows)").format(count=len(rows))
        if status == "empty_catalog":
            source = str(info.get("catalog_source") or "").strip()
            if source:
                return _(
                    "The server returned no active usage_products for this account "
                    "(source: {source})."
                ).format(source=source)
            return _("The server returned no active usage_products for this account.")
        if status == "no_catalog_matches":
            return _(
                "Imported files were read, but no food items matched the shared daily consumption catalog."
            )
        if status == "empty_import":
            return _("Imported files contain no usable rows.")
        return _("No rows matched.")

    def hide_total_zero_enabled(self) -> bool:
        return bool(self._preferences.get_bool("usage_hide_total_zero", False))

    def persist_hide_total_zero_enabled(self, enabled: bool) -> None:
        text = "True" if bool(enabled) else "False"
        self._settings_service.set_runtime_value("usage_hide_total_zero", text)
        self._preferences.set_cached("usage_hide_total_zero", text)

    def evaluate_preview_request(
        self, *, access_allowed: bool, access_reason: str, row_count: int
    ) -> UsageWorkspaceDecision:
        if not access_allowed:
            return UsageWorkspaceDecision(
                False,
                access_reason or _("Usage is not available for the current account."),
            )
        if int(row_count or 0) <= 0:
            return UsageWorkspaceDecision(False, _("No usage rows to preview."))
        return UsageWorkspaceDecision(True, "")

    def build_print_context(
        self,
        *,
        usage_print_service,
        model,
        headers: Sequence[str],
        numeric_columns: Iterable[int],
        column_ratios: Sequence[int],
    ):
        profile = getattr(self._app_state, "current_user", None)
        permission_context = (
            getattr(profile, "permission_context", None) if profile is not None else None
        )
        display_name = str(
            getattr(profile, "display_name", "")
            or getattr(permission_context, "display_name", "")
            or active_username(self._app_state)
            or ""
        ).strip()

        # The print identity follows the authenticated person, not the selected
        # restaurant branch. This matches the same display_name shown in the
        # application shell (for example "Hussam Alfaifi").
        return usage_print_service.build_context(
            model=model,
            headers=headers,
            numeric_columns=numeric_columns,
            column_ratios=column_ratios,
            title="MONTHLY USAGE COUNT TOOLS",
            branch_text="",
            logo_path=resource_path("resources", "images", "logo.png"),
            prepared_by_text=display_name,
        )


logger = logging.getLogger(__name__)


def _best_product_name(material: str, *candidates: object) -> str:
    return best_product_name(material, *candidates)


def _normalize_material_key(value: object) -> str:
    return normalize_material_match_key(value)


def _catalog_material(row: dict | None) -> str:
    source = row if isinstance(row, dict) else {}
    return str(source.get("material") or source.get("material_number") or "").strip()


def _catalog_name(row: dict | None, material: str = "") -> str:
    source = row if isinstance(row, dict) else {}
    return _best_product_name(material, source.get("name"))


class UsageService:
    def __init__(
        self, usage_catalog: Any, usage_repository: Any, tabular_reader: TabularInputReader
    ):
        self.catalog = usage_catalog
        self.repository = usage_repository
        self._tabular_reader = tabular_reader
        self.last_compute_info: dict = {}

    def load_catalog_products(self) -> list[dict]:
        try:
            server_rows = list(self.catalog.refresh_from_server(force=True) or [])
            if server_rows:
                return server_rows
            # An authoritative successful empty response is a real empty
            # catalogue; do not manufacture rows from the imported workbooks.
            return []
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            local_rows = list(self.catalog.list_local() or [])
            if local_rows:
                logger.warning(
                    "Usage catalog refresh failed; using the current server projection",
                    exc_info=True,
                )
                return local_rows
            raise RuntimeError(f"Unable to load server-selected usage products: {exc}") from exc

    def _catalog_index(self, products: list[dict]) -> tuple[set[str], dict[str, dict]]:
        product_map: dict[str, dict] = {}
        canonical_codes: set[str] = set()
        for product in products or []:
            if not isinstance(product, dict):
                continue
            material = _catalog_material(product)
            if not material:
                continue
            normalized = _normalize_material_key(material)
            if not normalized:
                continue
            name = _catalog_name(product, material)
            merged = dict(product)
            merged["material"] = material
            merged["name"] = _best_product_name(material, name, product.get("name"))
            product_map[material] = merged
            product_map[normalized] = merged
            canonical_codes.add(material)
        return (canonical_codes, product_map)

    @staticmethod
    def _normalized_input_index(rows: dict | None) -> dict[str, dict]:
        indexed: dict[str, dict] = {}
        for code, row in dict(rows or {}).items():
            key = _normalize_material_key(code)
            if key and isinstance(row, dict):
                indexed[key] = row
        return indexed

    def _parse_input_sources(
        self, receipts_path: str, begin_path: str, progress
    ) -> tuple[dict, dict]:
        progress("Parsing receipts…")
        receipts = parse_receipts(receipts_path, self._tabular_reader)
        progress("Parsing beginning/count file…")
        beginning = parse_beginning(begin_path, self._tabular_reader)
        return (receipts, beginning)

    def _build_row(
        self,
        *,
        code: str,
        product_map: dict[str, dict],
        receipt_row: dict | None,
        beginning_row: dict | None,
    ) -> dict:
        receipts_value = parse_plain_number(receipt_row.get("receipts")) if receipt_row else 0.0
        beginning_value = parse_plain_number(beginning_row.get("qty")) if beginning_row else 0.0
        total_value = receipts_value + beginning_value
        product_row = product_map.get(code) or product_map.get(_normalize_material_key(code)) or {}
        name = _best_product_name(
            code,
            product_row.get("name"),
            receipt_row.get("name") if receipt_row else "",
            beginning_row.get("name") if beginning_row else "",
        )
        # Server authority selects the Usage material numbers. Operational UOM
        # comes exclusively from the imported Receipts workbook.
        uom = str(receipt_row.get("uom") if receipt_row else "").strip()
        return {
            "material": code,
            "name": name,
            "uom": uom,
            "receipts": receipts_value,
            "begin": beginning_value,
            "total": total_value,
            "onhand": 0.0,
            "usage": 0.0,
            "user_set": False,
        }

    def compute_rows(
        self, receipts_path: str, begin_path: str, progress_callback=None
    ) -> list[dict]:
        progress = progress_callback or (lambda *_args, **_kwargs: None)
        receipts, beginning = self._parse_input_sources(receipts_path, begin_path, progress)
        prods = self.load_catalog_products()
        codes, product_map = self._catalog_index(prods)
        rows: list[dict] = []
        imported_codes = set(receipts.keys()) | set(beginning.keys())
        if not codes:
            self.last_compute_info = {
                "status": "empty_catalog",
                "catalog_count": 0,
                "imported_count": len(imported_codes),
                "matched_count": 0,
                "catalog_source": str(getattr(self.catalog, "last_refresh_source", "") or ""),
                "catalog_error": str(getattr(self.catalog, "last_refresh_error", "") or ""),
            }
            return []

        receipt_index = self._normalized_input_index(receipts)
        beginning_index = self._normalized_input_index(beginning)
        matched_count = 0

        progress("Matching server-selected products…")
        for code in sorted(codes):
            normalized = _normalize_material_key(code)
            receipt_row = receipts.get(code) or receipt_index.get(normalized)
            beginning_row = beginning.get(code) or beginning_index.get(normalized)
            if receipt_row or beginning_row:
                matched_count += 1

            # The server usage catalogue is authoritative. Every product chosen
            # by the server remains visible even when one of the imported files
            # has no row for it; missing quantities are represented as zero.
            rows.append(
                self._build_row(
                    code=code,
                    product_map=product_map,
                    receipt_row=receipt_row,
                    beginning_row=beginning_row,
                )
            )

        status = "ok"
        if imported_codes and matched_count == 0:
            status = "no_catalog_matches"
        elif not imported_codes:
            status = "empty_import"
        self.last_compute_info = {
            "status": status,
            "catalog_count": len(codes),
            "imported_count": len(imported_codes),
            "matched_count": matched_count,
            "visible_count": len(rows),
            "catalog_source": str(getattr(self.catalog, "last_refresh_source", "") or ""),
            "catalog_error": str(getattr(self.catalog, "last_refresh_error", "") or ""),
        }
        logger.info(
            "USAGE_COMPUTE_RESULT catalog=%d imported=%d matched=%d visible=%d source=%s",
            len(codes),
            len(imported_codes),
            matched_count,
            len(rows),
            self.last_compute_info["catalog_source"] or "unknown",
        )
        progress("Done")
        return rows
