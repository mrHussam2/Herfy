from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any, Iterable

from core.models import clean_string_list

_COLLECTION_BY_KIND = {
    "organization": "organizations",
    "region": "regions",
    "area": "areas",
    "branch": "branches",
}
_ID_BY_KIND = {
    "organization": "organization_id",
    "region": "region_id",
    "area": "area_id",
    "branch": "branch_id",
}


def apply_structure_result(
    snapshot: dict[str, Any],
    kind: str,
    result: dict[str, Any] | None,
) -> bool:
    """Apply a server-returned structure mutation to the in-memory projection.

    The server response remains authoritative: this helper never invents fields or
    revisions. It only merges/removes the exact ``entity`` returned by the API so
    the Administration tree reflects a successful mutation immediately while the
    normal bootstrap reconciliation still runs afterward.
    """

    entity_kind = str(kind or "").strip().lower()
    collection = _COLLECTION_BY_KIND.get(entity_kind)
    id_key = _ID_BY_KIND.get(entity_kind)
    if not collection or not id_key or not isinstance(snapshot, dict):
        return False

    payload = dict(result or {}) if isinstance(result, dict) else {}
    entity = payload.get("entity")
    if not isinstance(entity, dict):
        return False
    ident = str(entity.get(id_key) or "").strip()
    if not ident:
        return False

    current = [dict(row) for row in snapshot.get(collection) or [] if isinstance(row, dict)]
    before = current

    if bool(payload.get("deleted")):
        updated = [row for row in current if str(row.get(id_key) or "").strip() != ident]
    else:
        updated: list[dict[str, Any]] = []
        replaced = False
        for row in current:
            if str(row.get(id_key) or "").strip() == ident:
                updated.append(dict(entity))
                replaced = True
            else:
                updated.append(row)
        if not replaced:
            updated.append(dict(entity))
        updated.sort(key=lambda row: str(row.get(id_key) or "").strip())

    changed = updated != before
    snapshot[collection] = updated
    return changed


logger = logging.getLogger(__name__)


def _emit_admin_event(state: Any, action: str, payload: dict[str, Any] | None = None) -> None:
    if state is None:
        return
    data = dict(payload or {})
    data.setdefault("action", str(action or "").strip().lower())
    try:
        state.emit_item_updated("admin", data)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        logger.debug("Admin state projection notification failed", exc_info=True)


class _Base:
    def __init__(self, cloud_provider: Callable[[], Any] | Any, app_state: Any = None) -> None:
        self._cloud_provider = (
            cloud_provider if callable(cloud_provider) else (lambda cloud=cloud_provider: cloud)
        )
        self.app_state = app_state

    def _require_cloud(self) -> Any:
        cloud = self._cloud_provider()
        if cloud is None:
            raise RuntimeError("Administration requires a server connection.")
        return cloud

    def _changed(self, action: str, payload: dict[str, Any] | None = None) -> None:
        _emit_admin_event(self.app_state, action, payload)


class AdminPermissionsService(_Base):
    def list(self) -> dict[str, Any]:
        return dict(self._require_cloud().admin_list_permissions() or {})

    def set_role_permissions(
        self, role_key: str, *, base_revision: int, permissions: Iterable[str]
    ) -> dict[str, Any]:
        result = dict(
            self._require_cloud().admin_set_role_permissions(
                str(role_key or "").strip(),
                base_revision=int(base_revision),
                permissions=clean_string_list(permissions),
            )
            or {}
        )
        self._changed("permissions", {"role": role_key})
        return result


class AdminUserService(_Base):
    def list(self, **filters: Any) -> dict[str, Any]:
        return dict(self._require_cloud().admin_list_users(**filters) or {})

    def list_all(self, **filters: Any) -> dict[str, Any]:
        """Read the complete visible user projection through the server cursor."""
        params = dict(filters or {})
        page_limit = max(1, min(250, int(params.pop("limit", 250) or 250)))
        cursor = params.pop("cursor", None)
        rows: list[dict[str, Any]] = []
        seen_users: set[str] = set()
        seen_cursors: set[str] = set()

        while True:
            page_params = dict(params)
            page_params["limit"] = page_limit
            if cursor:
                page_params["cursor"] = cursor
            page = self.list(**page_params)
            for item in page.get("items") or []:
                if not isinstance(item, dict):
                    continue
                key = str(item.get("user_id") or item.get("username") or "").strip()
                if key and key in seen_users:
                    continue
                if key:
                    seen_users.add(key)
                rows.append(dict(item))

            next_cursor = str(page.get("next_cursor") or "").strip()
            if not next_cursor:
                break
            if next_cursor in seen_cursors or next_cursor == str(cursor or ""):
                raise RuntimeError("Administration user pagination returned a repeated cursor")
            seen_cursors.add(next_cursor)
            cursor = next_cursor

        return {"items": rows, "next_cursor": None}

    def save(self, payload: dict[str, Any]) -> dict[str, Any]:
        data = dict(payload or {})
        user_id = str(data.pop("user_id", "") or "").strip()
        base_revision = data.pop("base_authority_revision", None)
        if user_id:
            if base_revision is None:
                raise ValueError("base_authority_revision is required")
            data["base_authority_revision"] = int(base_revision)
            # username is immutable login identity and is not part of PATCH.
            data.pop("username", None)
            data.pop("assignments", None)
            result = dict(self._require_cloud().admin_update_user(user_id, data) or {})
        else:
            result = dict(self._require_cloud().admin_create_user(data) or {})
        self._changed("user", {"user_id": user_id or (result.get("user") or {}).get("user_id")})
        return result

    def set_active(
        self, user_id: str, *, active: bool, base_authority_revision: int
    ) -> dict[str, Any]:
        result = dict(
            self._require_cloud().admin_set_user_active(
                user_id, active=bool(active), base_authority_revision=int(base_authority_revision)
            )
            or {}
        )
        self._changed("user", {"user_id": user_id, "is_active": bool(active)})
        return result

    def reset_password(
        self, user_id: str, *, base_authority_revision: int, password: str | None = None
    ) -> dict[str, Any]:
        result = dict(
            self._require_cloud().admin_reset_password(
                user_id, base_authority_revision=int(base_authority_revision), password=password
            )
            or {}
        )
        self._changed("user", {"user_id": user_id, "action": "password_reset"})
        return result

    def replace_scopes(
        self, user_id: str, *, base_authority_revision: int, assignments: list[dict[str, str]]
    ) -> dict[str, Any]:
        result = dict(
            self._require_cloud().admin_replace_user_scopes(
                user_id,
                base_authority_revision=int(base_authority_revision),
                assignments=assignments,
            )
            or {}
        )
        self._changed("authority", {"user_id": user_id})
        return result


class AdminStructureService(_Base):
    def list(self) -> dict[str, Any]:
        return dict(self._require_cloud().admin_structure() or {})

    def save(self, kind: str, values: dict[str, Any], *, existing: bool = False) -> dict[str, Any]:
        """Persist one canonical structure entity.

        The editor uses a generic ``parent`` field for presentation.  Convert it
        here to the exact server contract field rather than dropping it.  Losing
        that parent produced malformed Region/Area/Branch creates and is exactly
        the kind of client/server contract mismatch this service boundary must
        prevent.
        """
        kind = str(kind or "").strip().lower()
        if kind not in {"region", "area", "branch"}:
            raise ValueError(
                "Only region, area and branch are mutable from the client structure workspace"
            )

        data = dict(values or {})
        ident_key = f"{kind}_id"
        parent_key = {
            "region": "",
            "area": "region_id",
            "branch": "area_id",
        }[kind]
        ident = str(data.pop(ident_key, None) or data.pop("code", None) or "").strip()
        parent = str(data.pop("parent", None) or "").strip()
        original_parent = str(data.pop("original_parent", None) or "").strip()
        cloud = self._require_cloud()

        if not ident:
            raise ValueError(f"{ident_key} is required")

        if existing:
            # Every server update schema is revision guarded.  Enforce that at
            # the use-case boundary too so a malformed editor/caller cannot fall
            # back to a last-write-wins mutation.
            if data.get("base_revision") is None:
                raise ValueError("base_revision is required for structure updates")
            try:
                data["base_revision"] = int(data["base_revision"])
            except (TypeError, ValueError) as exc:
                raise ValueError("base_revision must be an integer") from exc

            # Parent movement is not an incidental edit.  This client release has
            # no canonical Region/Area transfer contract, while Branch movement
            # has its own explicit route.  Refuse every generic parent change
            # instead of silently turning an edit into a structural move.
            if parent and original_parent and parent != original_parent:
                if kind == "branch":
                    raise ValueError("Branch parent changes must use the branch transfer operation")
                raise ValueError(
                    f"{kind.title()} parent changes are not supported by the client contract"
                )
            data.pop(ident_key, None)
            method = getattr(cloud, f"admin_update_{kind}")
            result = dict(method(ident, data) or {})
        else:
            data[ident_key] = ident
            if kind != "region":
                if not parent:
                    raise ValueError(f"{parent_key} is required")
                data[parent_key] = parent
            method = getattr(cloud, f"admin_create_{kind}")
            result = dict(method(data) or {})

        self._changed("structure", {"kind": kind, "scope_id": ident})
        return result

    def remove(self, kind: str, ident: str, *, base_revision: int) -> dict[str, Any]:
        """Invoke the canonical safe-remove route for one hierarchy item.

        The server owns removal semantics. Unreferenced items may be deleted
        permanently; rows required by operational history or authority are
        disabled and preserved instead.
        """
        kind = str(kind or "").strip().lower()
        if kind not in {"region", "area", "branch"}:
            raise ValueError(
                "Only region, area and branch can be removed from the client structure workspace"
            )
        method = getattr(self._require_cloud(), f"admin_delete_{kind}")
        result = dict(method(str(ident), int(base_revision)) or {})
        if bool(result.get("deleted")):
            action = "delete"
        elif bool(result.get("disabled")):
            action = "disable"
        else:
            action = "update"
        self._changed("structure", {"kind": kind, "scope_id": ident, "action": action})
        return result

    # Compatibility alias for older presenters; new administration code uses remove().
    def disable(self, kind: str, ident: str, *, base_revision: int) -> dict[str, Any]:
        return self.remove(kind, ident, base_revision=base_revision)

    def transfer_branch(
        self, branch_id: str, *, area_id: str, base_revision: int
    ) -> dict[str, Any]:
        result = dict(
            self._require_cloud().admin_transfer_branch(
                branch_id, area_id=area_id, base_revision=int(base_revision)
            )
            or {}
        )
        self._changed("structure", {"kind": "branch", "scope_id": branch_id, "action": "transfer"})
        return result

    def create_branches_batch(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        result = dict(self._require_cloud().admin_create_branches_batch(items) or {})
        self._changed("structure", {"kind": "branch", "action": "batch_create"})
        return result


class AdminAuditService(_Base):
    def list(self, **filters: Any) -> dict[str, Any]:
        return dict(self._require_cloud().admin_list_audit_events(**filters) or {})


class AdminCatalogService(_Base):
    def _publish_catalog_change(
        self,
        kind: str,
        *,
        material_number: str = "",
        action: str = "update",
    ) -> None:
        clean_kind = str(kind or "").strip().lower()
        payload = {
            "catalog_changed": True,
            "catalog_kind": clean_kind,
            "material_number": str(material_number or "").strip(),
            "action": str(action or "").strip().lower(),
        }
        self._changed("catalog", payload)
        state = self.app_state
        if state is None:
            return
        domain = "tracking" if clean_kind == "stored" else "usage"
        try:
            state.emit_data_changed(domain, dict(payload))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Catalog domain refresh notification failed", exc_info=True)

    def list(self, kind: str, *, include_inactive: bool = True) -> list[dict[str, Any]]:
        method = getattr(self._require_cloud(), f"admin_list_{kind}_products")
        return [dict(row) for row in (method(include_inactive=include_inactive) or [])]

    def create(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        method = getattr(self._require_cloud(), f"admin_create_{kind}_product")
        result = dict(method(dict(payload)) or {})
        self._publish_catalog_change(
            kind,
            material_number=str(result.get("material_number") or ""),
            action="create",
        )
        return result

    def update(self, kind: str, material_number: str, payload: dict[str, Any]) -> dict[str, Any]:
        method = getattr(self._require_cloud(), f"admin_update_{kind}_product")
        result = dict(method(str(material_number), dict(payload)) or {})
        self._publish_catalog_change(
            kind,
            material_number=str(material_number or ""),
            action="update",
        )
        return result

    def delete(self, kind: str, material_number: str, *, base_revision: int) -> dict[str, Any]:
        method = getattr(self._require_cloud(), f"admin_delete_{kind}_product")
        result = dict(method(str(material_number), int(base_revision)) or {})
        self._publish_catalog_change(
            kind,
            material_number=str(material_number or ""),
            action="delete",
        )
        return result


class AdminService(_Base):
    """Thin facade over server-authoritative administration use cases.

    The provider is resolved at call time so UI code never owns a raw API
    client and the service follows the currently authenticated server session.
    """

    def __init__(self, cloud_provider: Callable[[], Any] | Any, app_state: Any = None) -> None:
        super().__init__(cloud_provider, app_state)
        provider = self._cloud_provider
        self.users = AdminUserService(provider, app_state)
        self.structure = AdminStructureService(provider, app_state)
        self.permissions = AdminPermissionsService(provider, app_state)
        self.audit = AdminAuditService(provider, app_state)
        self.catalogs = AdminCatalogService(provider, app_state)

    def online(self) -> bool:
        return self._cloud_provider() is not None

    @staticmethod
    def apply_structure_result(
        snapshot: dict[str, Any], kind: str, payload: dict[str, Any]
    ) -> bool:
        return bool(apply_structure_result(snapshot, kind, payload))

    def bootstrap(self) -> dict[str, Any]:
        return dict(self._require_cloud().admin_bootstrap() or {})

    def password_policy(self) -> dict[str, Any]:
        return dict(self._require_cloud().password_policy() or {})


class CatalogManagementRuntimeService:
    """Application boundary for catalog-management presentation."""

    def __init__(self, application: Any, admin_service: Any) -> None:
        if application is None or admin_service is None:
            raise ValueError(
                "CatalogManagementRuntimeService requires application and admin service"
            )
        self._application = application
        self._admin = admin_service

    def online(self) -> bool:
        return bool(self._admin.online())

    def permissions(self) -> dict[str, bool]:
        return {
            "stored": bool(self._application.can_manage_catalog()),
            "usage": bool(self._application.can_manage_usage()),
        }

    def list(self, kind: str) -> list[dict[str, Any]]:
        clean = str(kind or "").strip().lower()
        if self.online():
            return list(self._admin.catalogs.list(clean, include_inactive=True) or [])
        if clean == "stored":
            return list(self._application.local_stored_products() or [])
        return list(self._application.local_usage_products() or [])

    def create(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        return dict(self._admin.catalogs.create(kind, payload) or {})

    def update(self, kind: str, material: str, payload: dict[str, Any]) -> dict[str, Any]:
        return dict(self._admin.catalogs.update(kind, material, payload) or {})

    def delete(self, kind: str, material: str, revision: int) -> dict[str, Any]:
        return dict(self._admin.catalogs.delete(kind, material, base_revision=int(revision)) or {})
