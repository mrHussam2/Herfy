from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


class CloudRuntimeService:
    """Own the raw API client lifecycle outside the presentation layer.

    Qt controllers can ask for explicit server operations, but they never retain
    or mutate the transport client itself. The current client follows the active
    authenticated session and remains server-authoritative.
    """

    def __init__(
        self,
        *,
        state: Any,
        client_factory: Callable[..., Any],
        context: Any,
        sync_coordinator: Any,
    ) -> None:
        self._state = state
        self._client_factory = client_factory
        self._context = context
        self._sync = sync_coordinator

    def _current(self) -> Any:
        return getattr(self._state, "api_client", None)

    def client_for_application(self) -> Any:
        """Application-service provider only; presentation code must not use it."""
        return self._current()

    def connected(self) -> bool:
        return self._current() is not None

    @property
    def base_url(self) -> str:
        client = self._current()
        return str(getattr(client, "base_url", "") or "").rstrip("/")

    @staticmethod
    def _close_client(client: Any) -> None:
        if client is None:
            return
        close_client = getattr(client, "close", None)
        if callable(close_client):
            close_client()
            return
        stop_realtime = getattr(client, "stop_realtime", None)
        if callable(stop_realtime):
            stop_realtime()

    def close_current(self, *, clear_reference: bool = False) -> None:
        client = self._current()
        self._close_client(client)
        if clear_reference:
            self._state.set_api_client(None)

    def attach(self, *, id_token: str, profile: Any) -> None:
        self.close_current(clear_reference=False)
        client = self._client_factory(id_token=str(id_token or ""), user=profile)
        self._state.set_api_client(client)
        self._context.set_cloud_context(client, profile)
        self._sync.restore_remote_cursor()

    def temporary_pull(self, *, id_token: str, profile: Any) -> None:
        client = self._client_factory(id_token=str(id_token or ""), user=profile)
        try:
            client.pull_now()
        finally:
            self._close_client(client)

    def set_identity_payload(self, payload: dict[str, Any]) -> None:
        client = self._require_current()
        client.user = dict(payload or {})

    def set_id_token(self, id_token: str) -> None:
        self._require_current().id_token = str(id_token or "")

    def refresh_profile(self, profile: Any) -> None:
        client = self._require_current()
        self._context.set_cloud_context(client, profile)
        self._sync.restore_remote_cursor()

    def client_bootstrap(self, client_version: str) -> dict[str, Any]:
        return dict(self._require_current().client_bootstrap(str(client_version or "")) or {})

    def meta_branches(self) -> list[str]:
        return list(self._require_current().meta_branches() or [])

    def start_realtime(self, on_change, *, on_state=None) -> None:
        self._require_current().start_realtime(on_change, on_state=on_state)

    def stop_realtime(self) -> None:
        client = self._current()
        if client is not None:
            client.stop_realtime()

    def sync_cursor(self) -> int:
        client = self._current()
        if client is None or not hasattr(client, "sync_cursor"):
            return 0
        return int(client.sync_cursor())

    def call(self, method_name: str, *args, **kwargs):
        method = getattr(self._require_current(), str(method_name))
        return method(*args, **kwargs)

    def _require_current(self) -> Any:
        client = self._current()
        if client is None:
            raise RuntimeError("Server connection is required.")
        return client
