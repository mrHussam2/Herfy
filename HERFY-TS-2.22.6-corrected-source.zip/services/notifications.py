"""Local, durable expiry-alert lifecycle policy.

This module deliberately has no Qt or persistence dependency.  The notification
runtime owns storage and calls these pure helpers from its worker boundary.
"""

from __future__ import annotations

import json
import threading
import time
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
from typing import Any

from core.i18n import format_days_text, tr
from core.models import (
    ExpiryStatusKind,
    business_datetime_from_timestamp,
    business_now,
    normalize_int,
    parse_bool,
    parse_plain_number,
)
from core.settings import _
from services.preferences import (
    active_username,
    get_local_setting,
    scoped_alert_key,
    set_local_setting,
)

SCHEDULE_VERSION = 1
REMINDER_SECONDS = {
    # An expired food item is the most urgent state.  It remains visible and
    # retries at a measured cadence until acknowledged; it must never be
    # silently discarded by the monitoring policy.
    "expired": 4 * 60 * 60,
    "expiring_soon": 24 * 60 * 60,
    "expiring_approaching": 12 * 60 * 60,
    "expiring_near": 8 * 60 * 60,
    "expires_tomorrow": 4 * 60 * 60,
    "expires_today": 2 * 60 * 60,
}


def reminder_interval_seconds(status_kind: str | None) -> int | None:
    """Return the configured local reminder interval, or ``None`` when silent."""
    return REMINDER_SECONDS.get(str(status_kind or "").strip().lower())


def lifecycle_key(branch: str, item: str, status_kind: str) -> str:
    """Create a stable local identity for one branch/item/state lifecycle."""
    return "|".join(
        (
            str(branch or "").strip().casefold(),
            str(item or "").strip().casefold(),
            str(status_kind or "").strip().casefold(),
        )
    )


def _parse_timestamp(value: Any) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None


def _status_kind(entry: dict[str, Any]) -> str:
    return str(entry.get("status_kind") or entry.get("state") or "").strip().lower()


def due_at(entry: dict[str, Any]) -> datetime | None:
    """Return the next reminder moment for an unacknowledged lifecycle."""
    if str(entry.get("acknowledged_at") or "").strip():
        return None
    interval = reminder_interval_seconds(_status_kind(entry))
    if interval is None:
        return None
    previous = _parse_timestamp(entry.get("last_delivered_at"))
    if previous is None:
        previous = _parse_timestamp(entry.get("first_detected_at"))
    if previous is None:
        return None
    return previous + timedelta(seconds=interval)


def reminder_is_due(entry: dict[str, Any], now: datetime) -> bool:
    target = due_at(entry)
    return bool(target is not None and target <= now)


def migrate_history(items: list[dict] | tuple[dict, ...] | None, *, now: datetime) -> list[dict]:
    """Fill local lifecycle fields without changing an already migrated entry."""
    stamp = now.isoformat(timespec="seconds")
    migrated: list[dict] = []
    for raw in list(items or []):
        if not isinstance(raw, dict):
            continue
        entry = dict(raw)
        status = _status_kind(entry)
        branch = str(entry.get("branch") or entry.get("branch_id") or "").strip()
        item = str(
            entry.get("tracking_item_identity")
            or entry.get("material_number")
            or entry.get("product")
            or ""
        ).strip()
        entry.setdefault("status_kind", status)
        entry.setdefault("lifecycle_key", lifecycle_key(branch, item, status))
        entry.setdefault("first_detected_at", str(entry.get("detected_at") or stamp))
        entry.setdefault("last_delivered_at", str(entry.get("desktop_delivered_at") or ""))
        entry.setdefault("acknowledged_at", "")
        entry.setdefault("acknowledged_by", "")
        entry.setdefault("acknowledged_branch", branch)
        entry.setdefault("schedule_version", SCHEDULE_VERSION)
        migrated.append(entry)
    return migrated


_URGENT_ORDER = {
    ExpiryStatusKind.EXPIRED.value: 6,
    ExpiryStatusKind.EXPIRES_TODAY.value: 5,
    ExpiryStatusKind.EXPIRES_TOMORROW.value: 4,
    ExpiryStatusKind.EXPIRING_NEAR.value: 3,
    ExpiryStatusKind.EXPIRING_APPROACHING.value: 2,
    ExpiryStatusKind.EXPIRING_SOON.value: 1,
    ExpiryStatusKind.UNKNOWN.value: 0,
    ExpiryStatusKind.VALID.value: 1,
}
_ALLOWED_SOURCES = {
    "local",
    "server",
    "monitor",
    "monitoring",
    "background",
    "scheduled",
}
_REJECTED_SOURCES = {"", "manual", "crud", "add", "edit", "update", "delete", "user"}


@dataclass(frozen=True, slots=True)
class NotificationEvent:
    user_identity: str
    server_identity: str
    authority_revision: int
    runtime_generation: int
    branch_id: str
    branch_name: str
    tracking_item_identity: str
    material_number: str
    product_name: str
    quantity: int
    production_date: str
    expiry_date: str
    status_kind: str
    days_left: int
    severity_rank: int
    notification_key: str
    title: str
    message: str
    detail_text: str
    source: str
    store: str = ""
    store_name: str = ""
    branch_label: str = ""
    region: str = ""
    area: str = ""

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        # Preserve the public event vocabulary expected by UI/history while the
        # canonical identity/state is carried by typed fields above.
        data.update(
            {
                "branch": self.branch_id,
                "status": self.status_kind,
                "severity": self.status_kind,
                "days_remaining": self.days_left,
                "days_expired": abs(self.days_left) if self.days_left < 0 else 0,
                "display_product": (
                    f"[{self.branch_id}] {self.product_name}"
                    if self.branch_id
                    else self.product_name
                ),
                "source_category": self.source,
            }
        )
        return data


class NotificationEngine:
    """Smart notification policy and event normalization service."""

    @staticmethod
    def normalized_kind(event: dict | None) -> str:
        data = event if isinstance(event, dict) else {}
        # Status is a domain value. Never infer it from localized UI text.
        kind = (
            str(data.get("status_kind") or data.get("kind") or data.get("severity") or "")
            .strip()
            .lower()
        )
        allowed = {item.value for item in ExpiryStatusKind}
        return kind if kind in allowed else ExpiryStatusKind.UNKNOWN.value

    @classmethod
    def severity_rank(cls, event: dict) -> int:
        explicit = event.get("severity_rank")
        try:
            if explicit is not None:
                return int(explicit)
        except (TypeError, ValueError):
            return int(_URGENT_ORDER.get(cls.normalized_kind(event), 0))
        return int(_URGENT_ORDER.get(cls.normalized_kind(event), 0))

    @classmethod
    def alert_key(cls, event: dict) -> str:
        data = event if isinstance(event, dict) else {}
        tracking_identity = str(data.get("tracking_item_identity") or "").strip()
        if not tracking_identity:
            tracking_identity = str(data.get("material_number") or "").strip()
        parts = [
            str(data.get("server_identity") or "").strip(),
            str(data.get("user_identity") or "").strip(),
            str(data.get("branch_id") or data.get("branch") or "").strip(),
            tracking_identity,
            str(data.get("production_date") or "").strip(),
            str(data.get("expiry_date") or "").strip(),
            cls.normalized_kind(data),
        ]
        return "::".join(parts).lower()

    @classmethod
    def fingerprint(cls, event: dict) -> str:
        data = event if isinstance(event, dict) else {}
        return "|".join(
            [
                str(data.get("server_identity") or "").strip().lower(),
                str(data.get("user_identity") or "").strip().lower(),
                str(data.get("branch_id") or data.get("branch") or "").strip().lower(),
                str(data.get("tracking_item_identity") or data.get("material_number") or "")
                .strip()
                .lower(),
                str(data.get("product_name") or "").strip().lower(),
                str(data.get("production_date") or "").strip().lower(),
                str(data.get("expiry_date") or "").strip().lower(),
                cls.normalized_kind(data),
                str(cls.severity_rank(data)),
                str(data.get("days_remaining") or ""),
                str(data.get("days_expired") or ""),
            ]
        )

    @staticmethod
    def days_remaining_text(days_remaining: int) -> str:
        try:
            days = int(days_remaining)
        except (TypeError, ValueError):
            days = 0
        if days < 0:
            return format_days_text(abs(days), expired=True)
        return format_days_text(days, expired=False)

    @staticmethod
    def is_notifiable_source(event: dict | None) -> bool:
        if not isinstance(event, dict):
            return False
        source = str(event.get("source") or "").strip().lower()
        if source in _ALLOWED_SOURCES:
            return True
        if source in _REJECTED_SOURCES:
            return False
        return False

    @classmethod
    def is_notifiable_status(cls, event: dict | None) -> bool:
        kind = cls.normalized_kind(event)
        return kind in {
            ExpiryStatusKind.EXPIRED.value,
            ExpiryStatusKind.EXPIRING_SOON.value,
            ExpiryStatusKind.EXPIRING_APPROACHING.value,
            ExpiryStatusKind.EXPIRING_NEAR.value,
            ExpiryStatusKind.EXPIRES_TOMORROW.value,
            ExpiryStatusKind.EXPIRES_TODAY.value,
        }

    @classmethod
    def is_summary_preferred(cls, event: dict | None) -> bool:
        """Return True only for low-priority soon alerts that may be grouped.

        Urgent expiry states must remain visible as individual Windows/tray
        notifications.  This prevents a large batch of soon alerts from hiding
        expired/today/tomorrow items inside a summary.
        """
        return cls.normalized_kind(event) == ExpiryStatusKind.EXPIRING_SOON.value

    @classmethod
    def sort_key(cls, event: dict | None) -> tuple[int, int, str]:
        data = event if isinstance(event, dict) else {}
        return (
            cls.severity_rank(data),
            _URGENT_ORDER.get(cls.normalized_kind(data), 0),
            str(data.get("expiry_date") or ""),
        )

    @classmethod
    def sound_setting_key(cls, event_or_status: dict | str | None) -> str:
        data = (
            event_or_status
            if isinstance(event_or_status, dict)
            else {"status_kind": event_or_status or ""}
        )
        kind = cls.normalized_kind(data)
        return {
            ExpiryStatusKind.EXPIRED.value: "notification_sound_expired",
            ExpiryStatusKind.EXPIRING_SOON.value: "notification_sound_soon",
            ExpiryStatusKind.EXPIRING_APPROACHING.value: "notification_sound_approaching",
            ExpiryStatusKind.EXPIRING_NEAR.value: "notification_sound_near",
            ExpiryStatusKind.EXPIRES_TOMORROW.value: "notification_sound_tomorrow",
            ExpiryStatusKind.EXPIRES_TODAY.value: "notification_sound_today",
        }.get(kind, "notification_sound_default")

    @classmethod
    def history_entry(cls, event: dict) -> dict:
        rd_ = event.get("days_remaining")
        try:
            rd_int = int(rd_ or 0)
        except (TypeError, ValueError):
            rd_int = 0
        return {
            "title": str(event.get("title") or tr("notification.expiry.item_title")),
            "message": str(event.get("message") or ""),
            "product": str(event.get("product_name") or event.get("display_product") or ""),
            "status": str(event.get("status") or ""),
            "status_label": str(event.get("status") or ""),
            "status_kind": cls.normalized_kind(event),
            "severity_rank": cls.severity_rank(event),
            "days_remaining": normalize_int(event.get("days_remaining"), rd_int),
            "days_expired": normalize_int(
                event.get("days_expired"), abs(rd_int) if rd_int < 0 else 0
            ),
            "days_text": str(event.get("detail_text") or cls.days_remaining_text(rd_int)),
            "branch": str(event.get("branch") or ""),
            "branch_name": str(event.get("branch_name") or ""),
            "branch_label": str(event.get("branch_label") or ""),
            "store": str(event.get("store") or ""),
            "store_name": str(event.get("store_name") or ""),
            "region": str(event.get("region") or ""),
            "area": str(event.get("area") or ""),
            "material_number": str(event.get("material_number") or ""),
            "quantity": normalize_int(event.get("quantity"), 0),
            "production_date": str(event.get("production_date") or ""),
            "expiry_date": str(event.get("expiry_date") or ""),
            "timestamp": business_now().isoformat(timespec="seconds"),
            "read": False,
        }

    @classmethod
    def history_key(cls, entry: dict | None) -> str:
        data = entry if isinstance(entry, dict) else {}
        notification_key = str(data.get("notification_key") or "").strip()
        if notification_key:
            return notification_key
        return "|".join(
            [
                str(data.get("title") or "").strip().lower(),
                str(data.get("product") or "").strip().lower(),
                str(data.get("branch") or "").strip().lower(),
                str(data.get("material_number") or "").strip().lower(),
                str(data.get("production_date") or "").strip().lower(),
                str(data.get("expiry_date") or "").strip().lower(),
                str(data.get("status") or "").strip().lower(),
                str(data.get("days_text") or "").strip().lower(),
            ]
        )

    @classmethod
    def build_event(
        cls,
        product_name: str,
        qty: int,
        st_text: str,
        rd_: int,
        branch: str = "",
        material_number: str = "",
        production_date: str = "",
        expiry_date: str = "",
        severity: str | None = None,
        source: str = "local",
        severity_rank: int | None = None,
        store: str = "",
        store_name: str = "",
        branch_name: str = "",
        branch_label: str = "",
        region: str = "",
        area: str = "",
        *,
        user_identity: str = "",
        server_identity: str = "",
        authority_revision: int = 0,
        runtime_generation: int = 0,
        tracking_item_identity: str = "",
    ) -> dict:
        branch = str(branch or "").strip()
        product_name = str(product_name or "").strip()
        kind = cls.normalized_kind({"status_kind": severity})
        if kind == ExpiryStatusKind.UNKNOWN.value:
            raise ValueError("Notification event requires canonical expiry status_kind")
        days_value = normalize_int(rd_, 0)
        days_text = cls.days_remaining_text(days_value)
        status_text = str(st_text or "").strip()
        title_key = (
            "notification.expiry.urgent_title"
            if _URGENT_ORDER.get(kind, 0) >= 5
            else "notification.expiry.item_title"
        )
        body_key = (
            "notification.expiry.urgent_body"
            if _URGENT_ORDER.get(kind, 0) >= 5
            else "notification.expiry.item_body"
        )
        display_product = f"[{branch}] {product_name}" if branch else product_name
        message = tr(
            body_key,
            product=display_product or product_name,
            status=status_text,
            detail=days_text,
        )
        detail_parts = []
        if material_number:
            detail_parts.append(f"{tr('notification.field.material')}: {material_number}")
        if qty is not None:
            detail_parts.append(f"{tr('notification.field.quantity')}: {normalize_int(qty, 0)}")
        if production_date:
            detail_parts.append(f"{tr('notification.field.production_date')}: {production_date}")
        if expiry_date:
            detail_parts.append(f"{tr('notification.field.expiry_date')}: {expiry_date}")
        location = str(branch_label or branch_name or store_name or store or branch or "").strip()
        if location:
            detail_parts.append(f"{tr('notification.field.branch')}: {location}")
        if region:
            detail_parts.append(f"{tr('notification.field.region')}: {region}")
        if area:
            detail_parts.append(f"{tr('notification.field.area')}: {area}")
        if detail_parts:
            message = message + "\n" + " | ".join(detail_parts)
        rank = int(severity_rank) if severity_rank is not None else int(_URGENT_ORDER.get(kind, 0))
        provisional = {
            "server_identity": str(server_identity or "").strip(),
            "user_identity": str(user_identity or "").strip(),
            "branch_id": branch,
            "tracking_item_identity": str(
                tracking_item_identity or material_number or product_name
            ).strip(),
            "material_number": str(material_number or product_name or "").strip(),
            "production_date": str(production_date or "").strip(),
            "expiry_date": str(expiry_date or "").strip(),
            "status_kind": kind,
        }
        notification_key = cls.alert_key(provisional)
        event = NotificationEvent(
            user_identity=provisional["user_identity"],
            server_identity=provisional["server_identity"],
            authority_revision=max(0, normalize_int(authority_revision, 0)),
            runtime_generation=max(0, normalize_int(runtime_generation, 0)),
            branch_id=branch,
            branch_name=str(branch_name or "").strip(),
            tracking_item_identity=provisional["tracking_item_identity"],
            material_number=provisional["material_number"],
            product_name=product_name,
            quantity=normalize_int(qty, 0),
            production_date=provisional["production_date"],
            expiry_date=provisional["expiry_date"],
            status_kind=kind,
            days_left=days_value,
            severity_rank=rank,
            notification_key=notification_key,
            title=tr(title_key),
            message=message,
            detail_text=days_text,
            source=str(source or "local").strip().lower(),
            store=str(store or "").strip(),
            store_name=str(store_name or store or "").strip(),
            branch_label=str(branch_label or "").strip(),
            region=str(region or "").strip(),
            area=str(area or "").strip(),
        )
        data = event.to_dict()
        # Keep localized text solely as presentation metadata.
        data["status"] = status_text
        return data


__all__ = ["NotificationEngine", "NotificationEvent"]


class NotificationsStateService:
    @staticmethod
    def normalize(items: list[Any] | tuple[Any, ...] | None) -> list[dict]:
        normalized: list[dict] = []
        for item in list(items or []):
            if isinstance(item, dict):
                normalized.append(deepcopy(item))
            else:
                normalized.append({"message": str(item)})
        return normalized

    @classmethod
    def unread_count(cls, items: list[Any] | tuple[Any, ...] | None) -> int:
        return sum((1 for item in cls.normalize(items) if not parse_bool(item.get("read"), False)))

    @classmethod
    def mark_one_read(
        cls, items: list[Any] | tuple[Any, ...] | None, index: int
    ) -> tuple[list[dict], bool]:
        normalized = cls.normalize(items)
        if index < 0 or index >= len(normalized):
            return (normalized, False)
        if parse_bool(normalized[index].get("read"), False):
            return (normalized, False)
        normalized[index]["read"] = True
        return (normalized, True)

    @classmethod
    def mark_all_read(cls, items: list[Any] | tuple[Any, ...] | None) -> tuple[list[dict], bool]:
        normalized = cls.normalize(items)
        changed = False
        for item in normalized:
            if not parse_bool(item.get("read"), False):
                item["read"] = True
                changed = True
        return (normalized, changed)

    @staticmethod
    def clear() -> list[dict]:
        return []


DETAIL_NOTIFICATION_BUDGET = 5
SUMMARY_NOTIFICATION_THRESHOLD = 3


class NotificationRuntimeService:
    """Application owner for notification identity, policy, history and persistence.

    Qt presentation receives already-composed methods and immutable results. Any
    method that touches persisted settings/ledger is intended to run through the
    worker boundary owned by the UI adapter.
    """

    def __init__(
        self, application: Any, presentation_preferences: Any, *, max_history: int = 500
    ) -> None:
        self._application = application
        self._preferences = presentation_preferences
        self._engine = NotificationEngine()
        self._max_history = max(1, int(max_history))
        self._recent_messages: dict[str, float] = {}
        self._recent_lock = threading.RLock()

    # ---------------------------------------------------------------- policy facade
    def active_username(self) -> str:
        return active_username(self._application)

    def get_setting(self, key: str, default: Any = None) -> Any:
        return self._preferences.get(key, default)

    def get_bool(self, key: str, default: bool = False) -> bool:
        return self._preferences.get_bool(key, default)

    def alert_key(self, event: dict) -> str:
        return self._engine.alert_key(event)

    def scoped_alert_key(self, alert_key: str, *, username: str = "") -> str:
        return scoped_alert_key(username or self.active_username(), alert_key)

    def fingerprint(self, event: dict) -> str:
        return self._engine.fingerprint(event)

    def normalized_kind(self, event: dict | None) -> str:
        return self._engine.normalized_kind(event)

    def is_notifiable_source(self, event: dict | None) -> bool:
        return self._engine.is_notifiable_source(event)

    def is_notifiable_status(self, event: dict | None) -> bool:
        return self._engine.is_notifiable_status(event)

    def is_summary_preferred(self, event: dict | None) -> bool:
        return self._engine.is_summary_preferred(event)

    def sort_key(self, event: dict | None):
        return self._engine.sort_key(event)

    def sound_setting_key(self, event_or_status: dict | str | None) -> str:
        return self._engine.sound_setting_key(event_or_status)

    def history_entry(self, event: dict) -> dict:
        return self._engine.history_entry(event)

    def history_key(self, entry: dict | None) -> str:
        return self._engine.history_key(entry)

    def build_event(self, *args, **kwargs) -> dict:
        return self._engine.build_event(*args, **kwargs)

    def _delivery_record(self, event: dict, *, username: str) -> dict:
        return {
            "key": self.scoped_alert_key(self.alert_key(event), username=username),
            "fingerprint": self.fingerprint(event),
            "severity_rank": normalize_int(event.get("severity_rank"), 0),
            "status_text": str(event.get("status") or ""),
            "state": self.normalized_kind(event),
        }

    def _detail_dispatch_item(self, event: dict, *, username: str) -> dict:
        title = _("Products expiration tracking")
        short_msg = f"{event.get('product_name') or event.get('display_product') or ''} - {event.get('status') or ''}".strip(
            " -"
        )
        return {
            "title": title,
            "short_msg": short_msg,
            "full_msg": str(event.get("message") or short_msg),
            "status": str(event.get("status") or ""),
            "dedupe_key": self.alert_key(event),
            "entry": self.history_entry(event),
            "delivery_records": [self._delivery_record(event, username=username)],
        }

    def _summary_dispatch_item(
        self,
        events: list[dict],
        *,
        username: str,
        title_override: str | None = None,
    ) -> dict | None:
        if not events:
            return None
        critical = sum(1 for event in events if normalize_int(event.get("severity_rank"), 0) >= 4)
        warning = sum(1 for event in events if normalize_int(event.get("severity_rank"), 0) == 3)
        total = len(events)
        title = str(title_override or _("Products expiration tracking"))
        parts = [
            (
                f"{total} {_('food items need attention')}"
                if total != 1
                else f"1 {_('food item needs attention')}"
            )
        ]
        if critical:
            parts.append(f"{_('Critical')}: {critical}")
        if warning:
            parts.append(f"{_('Expiring Soon')}: {warning}")
        lead_names = [
            str(event.get("display_product") or event.get("product_name") or "").strip()
            for event in events[:3]
            if str(event.get("display_product") or event.get("product_name") or "").strip()
        ]
        summary = " | ".join(parts)
        branches = [
            str(event.get("branch") or "").strip()
            for event in events
            if str(event.get("branch") or "").strip()
        ]
        if branches:
            unique_branches = list(dict.fromkeys(branches))[:6]
            stores = [
                (
                    branch
                    if branch.upper().startswith("H")
                    else f"H{branch}" if branch.isdigit() else branch
                )
                for branch in unique_branches
            ]
            summary += "\n" + f"{_('Stores')}: " + ", ".join(stores)
        if lead_names:
            summary += "\n" + ", ".join(lead_names)
        return {
            "title": title,
            "short_msg": summary.split("\n", 1)[0],
            "full_msg": summary,
            "status": "warning",
            "dedupe_key": f"summary|{','.join(lead_names)}|{total}",
            "entry": {
                "status_label": _("Summary"),
                "days_text": str(total),
                "message": summary,
            },
            "delivery_records": [
                self._delivery_record(event, username=username) for event in events
            ],
        }

    def build_presentation_plan(
        self,
        events: list[dict],
        *,
        username: str,
        recorded_at: str | None = None,
    ) -> dict[str, list[dict]]:
        """Build history and desktop-delivery presentation policy outside Qt.

        The returned structure contains immutable-style dictionaries only. Qt is
        responsible for rendering/enqueueing the prepared items, not choosing
        which alerts are detailed vs summarized.
        """
        resolved_user = str(username or "").strip()
        candidates = [dict(event) for event in list(events or []) if isinstance(event, dict)]
        if not candidates or not resolved_user:
            return {"history_entries": [], "dispatch_items": []}

        detected_at = str(recorded_at or business_now().isoformat(timespec="seconds"))
        history_entries: list[dict] = []
        for event in candidates:
            history_entry = self.history_entry(event)
            history_entry["notification_key"] = self.scoped_alert_key(
                self.alert_key(event), username=resolved_user
            )
            history_entry["fingerprint"] = self.fingerprint(event)
            history_entry["lifecycle"] = "IN_APP_RECORDED"
            history_entry["detected_at"] = detected_at
            history_entry["in_app_recorded"] = True
            history_entry["in_app_recorded_at"] = detected_at
            history_entry["desktop_delivered"] = False
            history_entry["desktop_backend"] = ""
            history_entries.extend(migrate_history([history_entry], now=business_now()))

        candidates.sort(key=self.sort_key, reverse=True)
        urgent_events = [event for event in candidates if not self.is_summary_preferred(event)]
        soon_events = [event for event in candidates if self.is_summary_preferred(event)]
        dispatch_items: list[dict] = []
        remaining: list[dict] = []
        detail_budget = DETAIL_NOTIFICATION_BUDGET

        urgent_details = urgent_events[:detail_budget]
        dispatch_items.extend(
            self._detail_dispatch_item(event, username=resolved_user) for event in urgent_details
        )
        detail_budget -= len(urgent_details)
        remaining.extend(urgent_events[len(urgent_details) :])

        if soon_events:
            if len(soon_events) >= SUMMARY_NOTIFICATION_THRESHOLD:
                remaining.extend(soon_events)
            else:
                soon_details = soon_events[:detail_budget]
                dispatch_items.extend(
                    self._detail_dispatch_item(event, username=resolved_user)
                    for event in soon_details
                )
                remaining.extend(soon_events[len(soon_details) :])

        if remaining:
            has_urgent = any(not self.is_summary_preferred(event) for event in remaining)
            summary_item = self._summary_dispatch_item(
                remaining,
                username=resolved_user,
                title_override=_("More urgent alerts") if has_urgent else _("More alerts"),
            )
            if summary_item is not None:
                dispatch_items.append(summary_item)

        return {"history_entries": history_entries, "dispatch_items": dispatch_items}

    # ---------------------------------------------------------------- in-memory state
    def mark_recent(
        self, key: str, *, ttl_seconds: float = 60.0, stale_after_seconds: float = 900.0
    ) -> bool:
        normalized = str(key or "").strip().lower()
        if not normalized:
            return True
        now = time.monotonic()
        cutoff = now - max(1.0, float(stale_after_seconds))
        with self._recent_lock:
            stale = [item for item, stamp in self._recent_messages.items() if stamp < cutoff]
            for item in stale:
                self._recent_messages.pop(item, None)
            last = self._recent_messages.get(normalized, 0.0)
            if now - last < max(1.0, float(ttl_seconds)):
                return False
            self._recent_messages[normalized] = now
        return True

    def clear_recent(self) -> None:
        with self._recent_lock:
            self._recent_messages.clear()

    def unread_count(self, items) -> int:
        return NotificationsStateService.unread_count(items)

    def mark_one_read(self, items, index: int):
        return NotificationsStateService.mark_one_read(items, index)

    def mark_all_read(self, items):
        return NotificationsStateService.mark_all_read(items)

    def mark_one_seen(self, items, index: int) -> tuple[list[dict], bool]:
        updated, changed = NotificationsStateService.mark_one_read(items, index)
        if changed:
            idx = int(index)
            updated[idx]["lifecycle"] = (
                "ACKNOWLEDGED" if updated[idx].get("acknowledged_at") else "SEEN"
            )
            updated[idx]["seen_at"] = business_now().isoformat(timespec="seconds")
        return updated, changed

    def mark_all_seen(self, items) -> tuple[list[dict], bool]:
        updated, changed = NotificationsStateService.mark_all_read(items)
        if changed:
            seen_at = business_now().isoformat(timespec="seconds")
            for item in updated:
                if not item.get("acknowledged_at"):
                    item["lifecycle"] = "SEEN"
                    item.setdefault("seen_at", seen_at)
        return updated, changed

    def acknowledge_history_item(
        self, items, index: int, *, username: str = ""
    ) -> tuple[list[dict], dict | None, bool]:
        snapshot = [dict(item) for item in list(items or []) if isinstance(item, dict)]
        idx = int(index)
        if idx < 0 or idx >= len(snapshot):
            return snapshot, None, False
        entry = dict(snapshot[idx])
        if entry.get("acknowledged_at"):
            return snapshot, None, False
        now = business_now().isoformat(timespec="seconds")
        resolved_user = str(username or self.active_username() or "").strip()
        entry["read"] = True
        entry["lifecycle"] = "ACKNOWLEDGED"
        entry["seen_at"] = str(entry.get("seen_at") or now)
        entry["acknowledged_at"] = now
        entry["acknowledged_by"] = resolved_user
        entry["acknowledged_branch"] = str(entry.get("branch") or "").strip()
        snapshot[idx] = entry
        key = str(entry.get("notification_key") or "").strip()
        ack = None
        if key:
            ack = {
                "notification_key": key,
                "acknowledged_at": now,
                "acknowledged_by": resolved_user,
                "expected_payload_hash": str(entry.get("fingerprint") or ""),
            }
        return snapshot, ack, True

    def retain_unacknowledged(self, items) -> list[dict]:
        return [
            dict(item)
            for item in list(items or [])
            if isinstance(item, dict) and not item.get("acknowledged_at")
        ]

    def apply_delivery_lifecycle(
        self,
        items,
        records: list[dict],
        lifecycle: str,
        *,
        now_ts: float | None = None,
        desktop_backend: str = "",
        desktop_delivered: bool | None = None,
    ) -> tuple[list[dict], bool]:
        snapshot = [dict(item) for item in list(items or []) if isinstance(item, dict)]
        keys = {str(record.get("key") or "") for record in records if str(record.get("key") or "")}
        if not keys:
            return snapshot, False
        timestamp = business_datetime_from_timestamp(now_ts or time.time()).isoformat(
            timespec="seconds"
        )
        changed = False
        by_key = {}
        for record in records:
            key = str(record.get("key") or "")
            if key:
                by_key.setdefault(key, []).append(record)
        for item in snapshot:
            item_key = str(item.get("notification_key") or "")
            if item_key not in keys:
                continue
            matching = next(
                (
                    record
                    for record in by_key.get(item_key, [])
                    if str(record.get("fingerprint") or "") == str(item.get("fingerprint") or "")
                ),
                None,
            )
            if matching is None:
                continue
            item["lifecycle"] = str(lifecycle or "")
            if lifecycle == "PRESENTED":
                item["presented_at"] = timestamp
            if desktop_delivered is not None:
                item["desktop_delivered"] = bool(desktop_delivered)
                if desktop_delivered:
                    item["desktop_delivered_at"] = timestamp
            if desktop_backend:
                item["desktop_backend"] = str(desktop_backend)
            changed = True
        return snapshot, changed

    # ---------------------------------------------------------------- history persistence
    def load_history(self, username: str) -> list[dict]:
        resolved = str(username or "").strip()
        if not resolved:
            return []
        raw = get_local_setting(
            self._application,
            "notification_history_v1",
            "[]",
            username=resolved,
        )
        try:
            data = json.loads(str(raw or "[]"))
        except (TypeError, ValueError, json.JSONDecodeError):
            return []
        return migrate_history(data, now=business_now())[: self._max_history]

    def persist_history(self, username: str, items: list[dict]) -> None:
        resolved = str(username or "").strip()
        if not resolved:
            return
        snapshot = migrate_history(list(items or []), now=business_now())
        set_local_setting(
            self._application,
            "notification_history_v1",
            json.dumps(snapshot[: self._max_history], ensure_ascii=False, separators=(",", ":")),
            username=resolved,
        )

    def merge_history(
        self, existing: list[dict] | None, entries: list[dict] | None
    ) -> tuple[list[dict], bool]:
        merged = migrate_history(list(existing or []), now=business_now())
        incoming = migrate_history(list(entries or []), now=business_now())
        if not incoming:
            return merged[: self._max_history], False
        existing_keys = {self.history_key(item) for item in merged}
        changed = False
        for entry in reversed(incoming):
            entry_key = self.history_key(entry)
            if entry_key and entry_key in existing_keys:
                continue
            merged.insert(0, entry)
            changed = True
            if entry_key:
                existing_keys.add(entry_key)
        if len(merged) > self._max_history:
            del merged[self._max_history :]
        return merged, changed

    # ---------------------------------------------------------------- worker-side persistence decisions
    def evaluate_event(
        self,
        event: dict,
        *,
        username: str,
        pending_delivery: dict[str, tuple[str, int]],
    ) -> bool:
        key = self.scoped_alert_key(self.alert_key(event), username=username)
        now_ts = time.time()
        state = self._application.get_alert_state(key) or {}
        ledger = self._application.get_notification_ledger(key) or {}
        fp = self.fingerprint(event)
        rank = normalize_int(event.get("severity_rank"), 0)
        last_notified_at = parse_plain_number(state.get("last_notified_at"))
        notify_count = normalize_int(state.get("notify_count"), 0)
        interval = reminder_interval_seconds(self.normalized_kind(event))
        acknowledged = bool(ledger.get("acknowledged_at"))
        due = not last_notified_at or (
            interval is not None and now_ts - last_notified_at >= interval
        )
        should_notify = bool(
            interval is not None and due and not acknowledged and key not in pending_delivery
        )
        # Selection is not delivery. Keep the previous delivered timestamp until
        # DesktopNotificationQueue reports an actual Windows/tray presentation.
        # This lets a failed backend be retried on the next monitoring recheck
        # instead of suppressing the alert for an entire reminder interval.
        self._application.set_alert_state(
            key,
            last_date=str(state.get("last_date") or ""),
            last_notified_at=last_notified_at,
            last_seen_at=now_ts,
            fingerprint=fp,
            severity_rank=rank,
            status_text=str(event.get("status") or ""),
            notify_count=notify_count,
        )
        return should_notify

    def evaluate_events(
        self,
        events: list[dict],
        *,
        username: str,
        pending_delivery: dict[str, tuple[str, int]],
        cancel_callback=None,
    ) -> list[dict]:
        selected: list[dict] = []
        for raw in list(events or []):
            if callable(cancel_callback) and cancel_callback():
                return []
            event = dict(raw) if isinstance(raw, dict) else {}
            if not event:
                continue
            if not self.is_notifiable_source(event):
                continue
            if not self.is_notifiable_status(event):
                continue
            if not self.alert_key(event):
                continue
            if self.evaluate_event(
                event,
                username=username,
                pending_delivery=pending_delivery,
            ):
                selected.append(event)
        return selected

    def event_is_current_runtime(self, event: dict, *, runtime_generation: int) -> bool:
        sync = self._application.sync
        if not sync.context_attached():
            return False
        identity = sync.sync_identity_metadata()
        if (
            str(event.get("user_identity") or "").casefold()
            != str(identity.get("user_identity") or "").casefold()
        ):
            return False
        if (
            str(event.get("server_identity") or "").casefold()
            != str(identity.get("server_identity") or "").casefold()
        ):
            return False
        if normalize_int(event.get("authority_revision"), -1) != int(sync.authority_revision()):
            return False
        return normalize_int(event.get("runtime_generation"), -1) == int(runtime_generation)

    def commit_delivery_records(
        self, records: list[dict], *, now_ts: float | None = None, cancel_callback=None
    ) -> None:
        default_stamp = float(now_ts or time.time())
        for raw in list(records or []):
            if callable(cancel_callback) and cancel_callback():
                return
            record = dict(raw) if isinstance(raw, dict) else {}
            key = str(record.get("key") or "")
            if not key:
                continue
            record_ts = float(record.get("_commit_ts") or default_stamp)
            today = business_datetime_from_timestamp(record_ts).date().isoformat()
            state = self._application.get_alert_state(key) or {}
            self._application.set_alert_state(
                key,
                last_date=today,
                last_notified_at=max(record_ts, parse_plain_number(state.get("last_notified_at"))),
                last_seen_at=max(record_ts, parse_plain_number(state.get("last_seen_at"))),
                fingerprint=str(state.get("fingerprint") or record.get("fingerprint") or ""),
                severity_rank=max(
                    normalize_int(state.get("severity_rank"), 0),
                    normalize_int(record.get("severity_rank"), 0),
                ),
                status_text=str(state.get("status_text") or record.get("status_text") or ""),
                notify_count=normalize_int(state.get("notify_count"), 0) + 1,
            )
            self._application.record_notification_ledger(
                key,
                state=str(record.get("state") or ""),
                severity=normalize_int(record.get("severity_rank"), 0),
                payload_hash=str(record.get("fingerprint") or ""),
            )

    def acknowledge_ledger(self, ack: dict) -> None:
        key = str((ack or {}).get("notification_key") or "").strip()
        if not key:
            return
        self._application.acknowledge_notification_ledger(
            key,
            acknowledged_at=str(ack.get("acknowledged_at") or ""),
            acknowledged_by=str(ack.get("acknowledged_by") or ""),
            expected_payload_hash=str(ack.get("expected_payload_hash") or ""),
        )
