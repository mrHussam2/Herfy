from __future__ import annotations

import logging
from typing import Any

from core.permissions import PermissionContext, PermissionService, validate_server_authority
from core.state import UserProfile, normalize_branch, normalize_branch_list

logger = logging.getLogger(__name__)


class RuntimeContextService:
    """Application owner for authenticated identity, permissions, and branch selection.

    The backing state may be a pure RuntimeStateCore or a UI signal adapter. This
    service has no Qt or infrastructure imports.
    """

    def __init__(self, state: Any, settings: Any, *, invalidate_tracking_cache=None):
        self._state = state
        self._settings = settings
        self._invalidate_tracking_cache = (
            invalidate_tracking_cache
            if callable(invalidate_tracking_cache)
            else lambda _branch=None: None
        )

    @property
    def api_client(self) -> Any:
        return getattr(self._state, "api_client", None)

    @property
    def current_user(self) -> Any:
        return getattr(self._state, "current_user", None)

    def permission_context(self) -> PermissionContext:
        ctx = getattr(self._state, "permissions", None)
        if not isinstance(ctx, PermissionContext):
            return PermissionContext()
        active = normalize_branch(getattr(self._state, "current_branch", "")) or ctx.active_branch
        return PermissionContext.from_payload(ctx.to_payload(), active_branch=active)

    def allowed_branches(self) -> list[str]:
        state_branches = normalize_branch_list(getattr(self._state, "allowed_branches", []) or [])
        if state_branches:
            return state_branches
        return normalize_branch_list(self.permission_context().scope.branches)

    def set_allowed_branches(self, branches) -> None:
        self._state.set_allowed_branches(normalize_branch_list(branches))

    def active_branch(self) -> str:
        return normalize_branch(getattr(self._state, "current_branch", ""))

    def _resolve_branch_case(self, branch: str) -> str:
        value = normalize_branch(branch)
        if not value:
            return ""
        lowered = value.casefold()
        for candidate in self.allowed_branches():
            if candidate.casefold() == lowered:
                return candidate
        return value

    def set_active_branch(self, branch: str) -> None:
        old = self.active_branch()
        value = normalize_branch(branch)
        if value and value.casefold() != "all":
            value = self._resolve_branch_case(value)
        self._state.set_current_branch(value)
        if old.casefold() != value.casefold():
            self._invalidate_tracking_cache(old or None)
            self._invalidate_tracking_cache(value or None)

    def set_cloud_context(self, service: Any, profile: Any) -> None:
        if service is None or profile is None:
            self._state.set_api_client(None)
            self._state.set_current_user(None)
            self._state.set_permissions(PermissionContext())
            self._state.set_allowed_branches([])
            self.set_active_branch("")
            self._invalidate_tracking_cache(None)
            return

        self._state.set_api_client(service)
        self._state.set_current_user(profile)

        profile_context = getattr(profile, "permission_context", None)
        ctx = (
            profile_context
            if isinstance(profile_context, PermissionContext)
            else PermissionContext()
        )
        self._state.set_permissions(ctx)
        # A global branch scope deliberately contains no explicit branch ids.
        # Clear any previous user's resolved list here; it is populated
        # asynchronously from the server's authorized branch catalogue below.
        self.set_allowed_branches(ctx.scope.branches)
        self._invalidate_tracking_cache(None)
        active = normalize_branch(getattr(profile, "active_branch", "") or ctx.active_branch)
        if not active:
            active = PermissionService.default_branch(permission_context=ctx)
        self.set_active_branch(active)

    def apply_server_authority(self, payload: dict[str, Any]) -> PermissionContext:
        """Replace local authority only from a validated server snapshot."""
        data = validate_server_authority(payload)
        ctx = PermissionContext.from_payload(
            data, active_branch=str(data.get("active_branch") or "")
        )
        if not ctx.authority_source or not ctx.is_active:
            raise RuntimeError("Server authority snapshot is inactive or invalid")

        current = self.current_user
        current_user_id = str(getattr(current, "user_id", "") or "").strip()
        if current_user_id and current_user_id != ctx.user_id:
            raise RuntimeError("Server authority identity changed inside an authenticated session")

        self._state.set_current_user(UserProfile.from_permission_context(ctx))
        self._state.set_permissions(ctx)
        if ctx.scope.branches:
            self.set_allowed_branches(ctx.scope.branches)
        elif not ctx.scope.all_branches:
            self.set_allowed_branches([])
        # For an all-branches authority snapshot, retain the already fetched
        # server-authorized branch list.  Replacing it with an empty token
        # scope caused the Tracking form to lose its branch selector after a
        # successful login/refresh.

        client = self.api_client
        if client is not None and hasattr(client, "user"):
            client.user = dict(data)

        active = self.active_branch()
        if active and not ctx.can_access_branch(active):
            active = ""
        if not active:
            active = str(ctx.active_branch or "").strip()
        if not active:
            active = PermissionService.default_branch(permission_context=ctx)
        self.set_active_branch(active)
        return ctx

    def pick_branch_for_write(self) -> str:
        ctx = self.permission_context()
        active = self.active_branch()
        if active and active.casefold() != "all":
            candidate = self._resolve_branch_case(active)
            if ctx.can_access_branch(candidate):
                return candidate
            raise RuntimeError("You don't have permission for this branch.")
        branches = self.allowed_branches()
        if len(branches) == 1 and ctx.can_access_branch(branches[0]):
            return branches[0]
        raise RuntimeError("Branch is required. Choose a branch first.")

    def has_permission(self, permission: str) -> bool:
        return self.permission_context().has_permission(permission)

    def can_view_all_branches(self) -> bool:
        return self.permission_context().can_view_all_branches()

    def can_access_branch(self, branch: str | None) -> bool:
        return self.permission_context().can_access_branch(branch)

    def can_view_branch(self, branch: str | None) -> bool:
        return self.permission_context().can_view_branch(branch)

    def can_create_tracking(self, branch: str | None) -> bool:
        return self.permission_context().can_create_tracking(branch)

    def can_update_tracking(self, branch: str | None) -> bool:
        return self.permission_context().can_update_tracking(branch)

    def can_delete_tracking(self, branch: str | None) -> bool:
        return self.permission_context().can_delete_tracking(branch)

    def can_manage_catalog(self) -> bool:
        return self.permission_context().can_manage_catalog()

    def can_manage_usage(self) -> bool:
        return self.permission_context().can_manage_usage()

    def can_manage_org(self) -> bool:
        return self.permission_context().can_manage_org()
