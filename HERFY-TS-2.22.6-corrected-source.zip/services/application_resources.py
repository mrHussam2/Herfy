from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from core.processes import launch_detached


class ApplicationResourceService:
    """Application boundary for persistent resource teardown.

    Presentation decides *when* a bounded shutdown has drained workers; this
    service owns the actual storage close so Qt never reaches DesktopApplication
    persistence methods directly.
    """

    def __init__(self, application: Any) -> None:
        if application is None:
            raise ValueError("ApplicationResourceService requires an application")
        self._application = application

    def close_storage(self) -> None:
        self._application.close()

    def restart_current_process(self) -> None:
        """Launch the canonical current application process.

        Process/path resolution is an application lifecycle side effect rather
        than presentation logic.  Callers run this method through WorkerRegistry
        and close the current Qt process only after launch succeeds.
        """
        executable = Path(sys.executable).resolve()
        if bool(getattr(sys, "frozen", False)):
            command = [executable]
            cwd = executable.parent
        else:
            entry = Path(sys.argv[0]).expanduser().resolve()
            command = [executable, entry]
            cwd = entry.parent
        launch_detached(command, cwd=cwd)
