from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from services.kpi_channels import (
    COMPARISON_CHANNELS,
    comparison_channel_values,
)
from services.kpi_totals import (
    report_net_total_value,
    sum_month_report_net_totals,
    sum_report_net_totals,
)
from services.kpi_validation import SalesAndBills, ValidationReport

_ZERO = Decimal(0)


@dataclass(frozen=True, slots=True)
class ChannelMetric:
    channel: str
    current_sales: Decimal | None
    compare_sales: Decimal | None
    current_gc: int | None
    compare_gc: int | None

    @property
    def sales_difference(self) -> Decimal | None:
        if self.current_sales is None or self.compare_sales is None:
            return None
        return self.current_sales - self.compare_sales

    @property
    def sales_growth(self) -> Decimal | None:
        difference = self.sales_difference
        if difference is None or not self.compare_sales:
            return None
        return difference / self.compare_sales

    @property
    def current_apc(self) -> Decimal | None:
        if self.current_sales is None or not self.current_gc:
            return None
        return self.current_sales / self.current_gc

    @property
    def compare_apc(self) -> Decimal | None:
        if self.compare_sales is None or not self.compare_gc:
            return None
        return self.compare_sales / self.compare_gc


@dataclass(frozen=True, slots=True)
class MonthlySales:
    month: int
    current_sales: Decimal | None
    compare_sales: Decimal | None


@dataclass(frozen=True, slots=True)
class DashboardSnapshot:
    branch: str
    current_year: int
    compare_year: int | None
    channels: tuple[ChannelMetric, ...]
    report_total: ChannelMetric
    monthly_sales: tuple[MonthlySales, ...]

    @property
    def current_net_sales(self) -> Decimal | None:
        return self.report_total.current_sales

    @property
    def compare_net_sales(self) -> Decimal | None:
        return self.report_total.compare_sales

    @property
    def current_gc(self) -> int | None:
        return self.report_total.current_gc

    @property
    def compare_gc(self) -> int | None:
        return self.report_total.compare_gc

    @property
    def sales_difference(self) -> Decimal | None:
        if self.current_net_sales is None or self.compare_net_sales is None:
            return None
        return self.current_net_sales - self.compare_net_sales

    @property
    def sales_growth(self) -> Decimal | None:
        difference = self.sales_difference
        if difference is None or not self.compare_net_sales:
            return None
        return difference / self.compare_net_sales

    @property
    def current_apc(self) -> Decimal | None:
        if self.current_net_sales is None or not self.current_gc:
            return None
        return self.current_net_sales / self.current_gc


class SalesAnalyticsModel:
    """Read-only analytics over a validated local sales report."""

    def __init__(self, report: ValidationReport) -> None:
        self._report = report

    def available_channels(self) -> tuple[str, ...]:
        return tuple(channel for _, channel in COMPARISON_CHANNELS)

    def snapshot(
        self,
        *,
        branch: str | None,
        current_year: int,
        compare_year: int | None,
    ) -> DashboardSnapshot:
        outlets = sorted([branch] if branch is not None else self._report.outlets)
        current_channels = self._sum_channels(outlets, current_year)
        compare_channels = self._sum_channels(outlets, compare_year)
        channel_metrics = tuple(
            self._channel_metric(row, channel, current_channels, compare_channels)
            for row, channel in COMPARISON_CHANNELS
        )

        current_net = self._sum_net_totals(outlets, current_year)
        compare_net = self._sum_net_totals(outlets, compare_year)
        report_total = ChannelMetric(
            channel="Total Net sale & GCs",
            current_sales=current_net[0] if current_net is not None else None,
            compare_sales=compare_net[0] if compare_net is not None else None,
            current_gc=current_net[1] if current_net is not None else None,
            compare_gc=compare_net[1] if compare_net is not None else None,
        )
        monthly_sales = self._monthly_sales(outlets, current_year, compare_year)

        return DashboardSnapshot(
            branch=branch or "All branches",
            current_year=current_year,
            compare_year=compare_year,
            channels=channel_metrics,
            report_total=report_total,
            monthly_sales=monthly_sales,
        )

    def _sum_channels(
        self,
        outlets: list[str],
        year: int | None,
    ) -> dict[int, SalesAndBills]:
        totals: dict[int, SalesAndBills] = {}
        if year is None:
            return {}
        months = self._branch_months(outlets, year)
        for outlet in outlets:
            for month in months.get(outlet, set()):
                branch_month = (outlet, year, month)
                values = comparison_channel_values(self._report, outlet, year, month)
                for row, _ in COMPARISON_CHANNELS:
                    pair = self._available_channel(branch_month, row, values)
                    if pair is None:
                        continue
                    previous = totals.get(row, (_ZERO, 0))
                    totals[row] = (previous[0] + pair[0], previous[1] + pair[1])
        return totals

    @staticmethod
    def _channel_metric(
        row: int,
        channel: str,
        current: dict[int, SalesAndBills],
        compare: dict[int, SalesAndBills],
    ) -> ChannelMetric:
        current_pair = current.get(row)
        compare_pair = compare.get(row)
        return ChannelMetric(
            channel=channel,
            current_sales=current_pair[0] if current_pair is not None else None,
            compare_sales=compare_pair[0] if compare_pair is not None else None,
            current_gc=current_pair[1] if current_pair is not None else None,
            compare_gc=compare_pair[1] if compare_pair is not None else None,
        )

    def _available_channel(
        self,
        branch_month: tuple[str, int, int],
        row: int,
        values: dict[int, SalesAndBills],
    ) -> SalesAndBills | None:
        tabwise_exists = branch_month in self._report.monthly_totals["Tabwise"]
        sourcewise_exists = branch_month in self._report.monthly_totals["Sourcewise"]
        if 3 <= row <= 7 and not tabwise_exists:
            return None
        if row == 9 and not (tabwise_exists or sourcewise_exists):
            return None
        if row == 17 and not tabwise_exists:
            return None
        if 10 <= row <= 16 and not sourcewise_exists:
            return None
        return values.get(row, (_ZERO, 0))

    def _sum_net_totals(
        self,
        outlets: list[str],
        year: int | None,
    ) -> SalesAndBills | None:
        return sum_report_net_totals(self._report, outlets, year)

    def _net_total(self, outlet: str, year: int, month: int) -> SalesAndBills | None:
        return report_net_total_value(self._report, outlet, year, month)

    def _monthly_sales(
        self,
        outlets: list[str],
        current_year: int,
        compare_year: int | None,
    ) -> tuple[MonthlySales, ...]:
        current_months = self._branch_months(outlets, current_year)
        compare_months = self._branch_months(outlets, compare_year)
        months = sorted(
            set().union(*current_months.values(), *compare_months.values())
            if current_months or compare_months
            else set()
        )
        current_values = {
            month: self._sum_month_net_sales(outlets, current_year, month) for month in months
        }
        compare_values = {
            month: self._sum_month_net_sales(outlets, compare_year, month) for month in months
        }
        return tuple(
            MonthlySales(month, current_values[month], compare_values[month]) for month in months
        )

    def _sum_month_net_sales(
        self,
        outlets: list[str],
        year: int | None,
        month: int,
    ) -> Decimal | None:
        if year is None:
            return None
        total = sum_month_report_net_totals(self._report, outlets, year, month)
        return total[0] if total is not None else None

    def _branch_months(self, outlets: list[str], year: int | None) -> dict[str, set[int]]:
        if year is None:
            return {}
        months: dict[str, set[int]] = {outlet: set() for outlet in outlets}
        for kind in ("Tabwise", "Sourcewise"):
            for outlet, data_year, month in self._report.monthly_totals[kind]:
                if outlet in months and data_year == year:
                    months[outlet].add(month)
        return months


def export_interactive_dashboard(snapshot: DashboardSnapshot, output_path: str | Path) -> Path:
    """Export a self-contained, offline interactive *channel* comparison.

    The source snapshot represents one selected branch or its authorized rollup;
    it cannot truthfully provide a drill-down into branches that were not read.
    Deliberately omit the unwanted monthly sales trend.
    """
    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
    except ImportError as exc:  # pragma: no cover - guarded by requirements
        raise RuntimeError("Interactive dashboard export requires Plotly.") from exc

    destination = Path(output_path).expanduser()
    if destination.suffix.lower() != ".html":
        destination = destination.with_suffix(".html")
    destination.parent.mkdir(parents=True, exist_ok=True)

    current = [m for m in snapshot.channels if m.current_sales is not None]
    comparable = [m for m in snapshot.channels if m.sales_difference is not None]
    figure = make_subplots(
        rows=1, cols=2,
        specs=[[{"type": "domain"}, {"type": "xy"}]],
        column_widths=[0.4, 0.6],
        horizontal_spacing=0.12,
        subplot_titles=("Sales channel share", "Channel comparison"),
    )
    figure.add_trace(
        go.Pie(
            labels=[m.channel for m in current],
            values=[float(m.current_sales) for m in current],
            hole=0.56,
            name="Current mix",
            textinfo="percent",
            hovertemplate="%{label}<br>Sales: SAR %{value:,.2f}<br>Share: %{percent}<extra></extra>",
        ), row=1, col=1,
    )
    difference = [m.sales_difference for m in comparable]
    compare_hover = []
    for m in comparable:
        growth = m.sales_growth
        growth_display = f"{growth * 100:+,.2f}%" if growth is not None else "N/A"
        compare_hover.append(
            [f"SAR {m.current_sales:,.2f}", f"SAR {m.compare_sales:,.2f}", growth_display]
        )
    figure.add_trace(
        go.Bar(
            x=[m.channel for m in comparable],
            y=[float(value) for value in difference],
            name="Absolute change",
            marker_color=["#188466" if value >= 0 else "#bf453b" for value in difference],
            customdata=compare_hover,
            hovertemplate=(
                "%{x}<br>Current: %{customdata[0]}<br>Previous: %{customdata[1]}"
                "<br>Difference: SAR %{y:+,.2f}<br>Growth: %{customdata[2]}<extra></extra>"
            ),
        ), row=1, col=2,
    )
    figure.add_trace(
        go.Bar(
            x=[m.channel for m in snapshot.channels],
            y=[float(m.current_sales) if m.current_sales is not None else None for m in snapshot.channels],
            name=str(snapshot.current_year),
            marker_color="#246b91",
            hovertemplate="%{x}<br>Sales: SAR %{y:,.2f}<extra></extra>",
            visible=False,
        ), row=1, col=2,
    )
    has_compare = snapshot.compare_year is not None
    figure.add_trace(
        go.Bar(
            x=[m.channel for m in snapshot.channels],
            y=[float(m.compare_sales) if m.compare_sales is not None else None for m in snapshot.channels],
            name=str(snapshot.compare_year) if has_compare else "Previous year",
            marker_color="#7a8ba2",
            hovertemplate="%{x}<br>Sales: SAR %{y:,.2f}<extra></extra>",
            visible=False,
        ), row=1, col=2,
    )
    views = [
        dict(label="Absolute change (SAR)", method="update", args=[{"visible": [True, True, False, False]}]),
        dict(label="Sales by year (SAR)", method="update", args=[{"visible": [True, False, True, has_compare]}]),
    ]
    figure.update_layout(
        template="plotly_white",
        title={"text": f"HERFY Sales KPI · {snapshot.branch} · {snapshot.current_year}", "x": 0.02},
        margin={"l": 48, "r": 32, "t": 116, "b": 95},
        height=610,
        barmode="group",
        hoverlabel={"bgcolor": "#ffffff", "font": {"color": "#172033"}},
        legend={"orientation": "h", "y": -0.23},
        updatemenus=[dict(buttons=views, direction="down", showactive=True, x=0.95, y=1.26, xanchor="right")],
    )
    figure.update_xaxes(tickangle=-24, automargin=True, row=1, col=2)
    figure.update_yaxes(tickformat=",.2f", zeroline=True, zerolinecolor="#9aa7b5", title_text="SAR")
    if not current:
        figure.add_annotation(text="No channel sales data", x=0.2, y=0.5, xref="paper", yref="paper", showarrow=False)
    figure.write_html(
        str(destination), include_plotlyjs="inline", full_html=True,
        config={
            "displaylogo": False, "responsive": True, "scrollZoom": True,
            "modeBarButtonsToAdd": ["select2d", "lasso2d", "drawline", "eraseshape"],
            "toImageButtonOptions": {"format": "png", "scale": 2},
        },
    )
    return destination
