from __future__ import annotations

import time
from typing import Any

from core.models import business_now, parse_bool
from services.monitoring_engine import MonitoringEngine
from services.notifications import NotificationEngine, reminder_interval_seconds
from services.preferences import (
    active_username,
    get_local_setting,
    migrate_active_user_settings,
    scoped_alert_key,
)
from services.tracking import tracking_store

INITIAL_DELIVERY_RECHECK_SECONDS = 60.0


class MonitoringRuntimeService:
    """Application owner for expiry-monitoring policy and local runtime state.

    Qt owns only timers and presentation. Calls that can touch settings, cached
    projections, sync metadata, or expiry policy are intended to run through the
    UI worker boundary before their result is presented.
    """

    def __init__(self, application: Any, tracking_service: Any) -> None:
        self._application = application
        self._tracking_service = tracking_service
        self._engine = MonitoringEngine()

    def _enabled(self) -> bool:
        return parse_bool(
            get_local_setting(self._application, "monitoring_enabled", "True"),
            True,
        )

    def prepare_schedule(self) -> dict[str, Any]:
        enabled = self._enabled()
        username = active_username(self._application)
        migrated = bool(
            username and migrate_active_user_settings(self._application, username=username)
        )
        snapshot = tracking_store.snapshot()
        records = tuple(getattr(snapshot, "records", ()) or ())
        delay_s = None
        if enabled and records:
            delay_s = MonitoringEngine.next_wake_delay_seconds(
                records=records,
                now=business_now(),
            )
        return {
            "enabled": bool(enabled),
            "migrated": bool(migrated),
            "has_records": bool(records),
            "baseline_ready": bool(getattr(snapshot, "baseline_ready", False)),
            "delay_s": delay_s,
        }

    def preload_rows(self) -> list[dict[str, Any]]:
        snapshot = tracking_store.snapshot()
        if tuple(getattr(snapshot, "records", ()) or ()):
            return []
        if not self._application.sync.context_attached():
            return []
        context = self._application.permission_context()
        if not bool(getattr(context, "is_active", False)):
            return []
        return [
            dict(row)
            for row in (self._application.authorized_tracking_snapshot() or [])
            if isinstance(row, dict)
        ]

    def publish_preloaded_rows(self, rows: list[dict[str, Any]]) -> bool:
        prepared = [dict(row) for row in rows or [] if isinstance(row, dict)]
        if not prepared:
            return False
        snapshot = tracking_store.snapshot()
        if tuple(getattr(snapshot, "records", ()) or ()):
            return False
        self._tracking_service.publish_baseline(prepared, source="monitor_preload")
        return True

    def next_wake_delay_seconds(self) -> float | None:
        if not self._enabled():
            return None
        snapshot = tracking_store.snapshot()
        records = tuple(getattr(snapshot, "records", ()) or ())
        if not records:
            return None
        return MonitoringEngine.next_wake_delay_seconds(
            records=records,
            now=business_now(),
        )

    def evaluate(self, *, runtime_generation: int) -> dict[str, Any]:
        enabled = self._enabled()
        snapshot = tracking_store.snapshot()
        baseline_ready = bool(getattr(snapshot, "baseline_ready", False))
        username = active_username(self._application)
        if not enabled or not baseline_ready or not username:
            return {
                "enabled": bool(enabled),
                "baseline_ready": baseline_ready,
                "active_user": bool(username),
                "events": [],
                "record_count": 0,
                "transition_count": 0,
                "delay_s": None,
                "policy": "fixed_30_day_expiry",
            }

        records = tuple(getattr(snapshot, "records", ()) or ())
        now = business_now()
        if not MonitoringEngine.is_monitoring_allowed(now):
            return {
                "enabled": True,
                "baseline_ready": True,
                "active_user": True,
                "events": [],
                "record_count": len(records),
                "transition_count": 0,
                "delay_s": MonitoringEngine.next_wake_delay_seconds(records=records, now=now),
                "policy": "fixed_30_day_expiry",
            }
        transitions = self._engine.evaluate(records=records, now=now)
        sync_identity = self._application.sync.sync_identity_metadata()
        authority_revision = self._application.sync.authority_revision()
        events: list[dict[str, Any]] = []
        for alert in self._engine.active_alerts(records=records, now=now):
            record = alert.record
            key = alert.key
            events.append(
                NotificationEngine.build_event(
                    product_name=record.product_name,
                    qty=record.quantity,
                    st_text=alert.display_text,
                    rd_=int(alert.days_left),
                    branch=key.branch_id,
                    material_number=key.material_number,
                    production_date=(
                        key.production_date.isoformat() if key.production_date else ""
                    ),
                    expiry_date=key.expiry_date.isoformat(),
                    severity=str(alert.state.value),
                    source="local",
                    severity_rank=alert.severity,
                    branch_name=record.branch_name,
                    user_identity=sync_identity["user_identity"],
                    server_identity=sync_identity["server_identity"],
                    authority_revision=authority_revision,
                    runtime_generation=int(runtime_generation),
                    tracking_item_identity=str(record.remote_id or key.material_number),
                )
            )
        delay_s = MonitoringEngine.next_wake_delay_seconds(
            records=records,
            now=now,
        )
        reminder_delays: list[float] = []
        for event in events:
            alert_key = NotificationEngine.alert_key(event)
            local_key = scoped_alert_key(username, alert_key)
            state = self._application.get_alert_state(local_key) or {}
            ledger = self._application.get_notification_ledger(local_key) or {}
            interval = reminder_interval_seconds(event.get("status_kind"))
            last = float(state.get("last_notified_at") or 0)
            if interval is None or ledger.get("acknowledged_at"):
                continue
            reminder_delays.append(
                max(1.0, interval - max(0.0, time.time() - last))
                if last
                else INITIAL_DELIVERY_RECHECK_SECONDS
            )
        if reminder_delays:
            delay_s = (
                min([delay_s] + reminder_delays) if delay_s is not None else min(reminder_delays)
            )
        return {
            "enabled": True,
            "baseline_ready": True,
            "active_user": True,
            "events": events,
            "record_count": len(records),
            "transition_count": len(transitions),
            "delay_s": delay_s,
            "policy": "fixed_30_day_expiry",
        }
