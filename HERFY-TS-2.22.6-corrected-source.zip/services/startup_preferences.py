from __future__ import annotations

from typing import Any

from services.sync import apply_startup_preferences


class StartupPreferencesService:
    """Application boundary for applying persisted startup integration policy."""

    def __init__(self, settings_source: Any) -> None:
        self._settings_source = settings_source

    def apply(self) -> bool:
        return bool(apply_startup_preferences(self._settings_source))
