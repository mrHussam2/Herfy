from __future__ import annotations

from collections.abc import Callable
from typing import Any

from core.runtime_ports import emit_updated
from services.catalog_changes import apply_remote_catalog_changes


class StoredCatalogService:
    """Server-authoritative stored-product catalog with a local read projection."""

    def __init__(self, repository: Any, *, remote_provider: Callable[[], Any]):
        self._repository = repository
        self._remote_provider = remote_provider

    @property
    def remote_available(self) -> bool:
        return self._remote_provider() is not None

    def list_local(self) -> list[dict]:
        return list(self._repository.fetch_stored_products() or [])

    def refresh_from_server(self) -> list[dict]:
        remote = self._remote_provider()
        if remote is None:
            return self.list_local()
        rows = list(remote.list_stored_products() or [])
        self._repository.replace_stored_products(rows)
        return self.list_local()

    def replace_authoritative(
        self, rows: list[dict] | None, *, emit_event: bool = True
    ) -> list[dict]:
        replaced = list(self._repository.replace_stored_products(list(rows or [])) or [])
        if emit_event:
            emit_updated("stored_product", {"action": "full_recovery", "count": len(replaced)})
        return replaced

    def apply_remote_changes(self, changes: list[dict] | None, *, emit_event: bool = True) -> dict:
        return apply_remote_catalog_changes(
            self._repository.apply_remote_stored_product_changes,
            changes,
            entity_type="stored_product",
            emit_event=emit_event,
        )
