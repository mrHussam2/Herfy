from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, time, timedelta
from typing import Iterable

from core.models import (
    ExpiryStatusKind,
    TrackingKey,
    TrackingRecord,
    business_now,
    classify_expiry_date,
)
from core.presentation import expiry_display_text


@dataclass(frozen=True, slots=True)
class ExpiryAlert:
    key: TrackingKey
    record: TrackingRecord
    state: ExpiryStatusKind
    severity: int
    days_left: int | None
    display_text: str


@dataclass(frozen=True, slots=True)
class ExpiryTransition:
    key: TrackingKey
    previous: ExpiryStatusKind | None
    current: ExpiryStatusKind
    alert: ExpiryAlert | None = None


class MonitoringEngine:
    def __init__(self) -> None:
        self._states: dict[TrackingKey, ExpiryStatusKind] = {}

    def evaluate(
        self,
        *,
        records: Iterable[TrackingRecord],
        now: datetime,
    ) -> tuple[ExpiryTransition, ...]:
        today = now.date() if isinstance(now, datetime) else business_now().date()
        transitions: list[ExpiryTransition] = []
        next_states: dict[TrackingKey, ExpiryStatusKind] = {}
        for record in records:
            status = classify_expiry_date(
                record.key.expiry_date,
                today=today,
            )
            current = status.kind
            next_states[record.key] = current
            previous = self._states.get(record.key)
            alert = None
            if status.should_notify_default and status.days_remaining is not None:
                alert = ExpiryAlert(
                    key=record.key,
                    record=record,
                    state=current,
                    severity=status.severity_rank,
                    days_left=status.days_remaining,
                    display_text=expiry_display_text(status),
                )
            # Notification work is transition-driven. Unchanged expiry states do
            # not emit a second alert; quantity/text changes are presentation data,
            # not expiry triggers. A changed expiry date changes TrackingKey and is
            # therefore evaluated as a new lifecycle.
            if previous != current:
                transitions.append(
                    ExpiryTransition(
                        key=record.key,
                        previous=previous,
                        current=current,
                        alert=alert,
                    )
                )
        self._states = next_states
        return tuple(transitions)

    @staticmethod
    def active_alerts(
        *, records: Iterable[TrackingRecord], now: datetime
    ) -> tuple[ExpiryAlert, ...]:
        """Return all currently warning records; delivery remains runtime-policy driven."""
        today = now.date() if isinstance(now, datetime) else business_now().date()
        alerts: list[ExpiryAlert] = []
        for record in records:
            status = classify_expiry_date(record.key.expiry_date, today=today)
            if not status.should_notify_default or status.days_remaining is None:
                continue
            alerts.append(
                ExpiryAlert(
                    key=record.key,
                    record=record,
                    state=status.kind,
                    severity=status.severity_rank,
                    days_left=status.days_remaining,
                    display_text=expiry_display_text(status),
                )
            )
        return tuple(alerts)

    @staticmethod
    def is_monitoring_allowed(now: datetime) -> bool:
        """Expiry monitoring is continuous for an authenticated local session.

        Shelf-life alerts are a food-safety control, not an office-hours task.
        The former 05:00--09:00 Riyadh pause could defer an already-due alert for
        four hours after a workstation resumed.  Keep this small predicate for
        callers and tests, but make the policy explicitly 24/7.
        """
        del now
        return True

    @staticmethod
    def next_wake_delay_seconds(
        *,
        records: Iterable[TrackingRecord],
        now: datetime,
    ) -> float | None:
        """Return the exact delay until the next expiry-state boundary.

        The planner is purely date-driven and owns expiry-state boundaries only.
        Delivery timing is layered by MonitoringRuntimeService. Expired inventory
        stays visible in Tracking but never becomes a notification lifecycle.
        """
        current = now if isinstance(now, datetime) else business_now()
        candidates: list[datetime] = []
        first_expiry_alert_days = 29

        for record in tuple(records or ()):
            expiry = record.key.expiry_date
            if expiry is None:
                continue
            transition_dates = {
                expiry - timedelta(days=first_expiry_alert_days),
                expiry - timedelta(days=15),
                expiry - timedelta(days=7),
                expiry - timedelta(days=1),
                expiry,
                expiry + timedelta(days=1),
            }
            for transition_date in transition_dates:
                at_midnight = datetime.combine(transition_date, time.min, tzinfo=current.tzinfo)
                if at_midnight > current:
                    candidates.append(at_midnight)

        if not candidates:
            return None
        target = min(candidates)
        return max(1.0, (target - current).total_seconds())
