from __future__ import annotations

import csv
import logging
import re
from collections.abc import Collection, Sequence
from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, InvalidOperation
from fractions import Fraction
from itertools import product
from pathlib import Path
from typing import Literal

ReportKind = Literal["Tabwise", "Sourcewise"]
BranchDay = tuple[str, date]
BranchMonth = tuple[str, int, int]
BranchMonthCategory = tuple[str, int, int, str]
SalesAndBills = tuple[Decimal, int]
logger = logging.getLogger(__name__)

_HEADER_ALIASES = {
    "businessdate": "date",
    "netsales": "netsale",
    "numberofbills": "noofbills",
    "outlet": "outletname",
    "salesource": "source",
}


def detect_report_kind(path: str | Path) -> ReportKind:
    csv_path = Path(path)
    if not csv_path.is_file():
        raise ValueError(f"File does not exist: {csv_path}")
    try:
        with csv_path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.reader(stream)
            headers = {_normalize_header(header) for header in next(reader, [])}
    except (OSError, UnicodeDecodeError, csv.Error) as exc:
        raise ValueError(f"Could not read CSV headers from {csv_path.name}: {exc}") from exc

    has_tabs = "tabs" in headers
    has_source = "source" in headers
    if has_tabs and has_source:
        raise ValueError(
            f"{csv_path.name} contains both Tabs and Source columns; report type is ambiguous."
        )
    if has_tabs:
        return "Tabwise"
    if has_source:
        return "Sourcewise"
    raise ValueError(f"{csv_path.name} is not a recognized Tabwise or Sourcewise sales CSV.")


@dataclass(slots=True)
class FileSummary:
    path: Path
    report_kind: ReportKind
    rows_read: int
    branch_count: int
    categories: set[str] = field(default_factory=set)
    dates: set[date] = field(default_factory=set)
    recovered_net_sales: int = 0
    skipped_rows: int = 0


@dataclass(slots=True)
class SkippedFile:
    path: Path
    reason: str


@dataclass(slots=True)
class ReconciliationIssue:
    outlet: str
    business_date: date
    reasons: list[str]
    tabwise_sales: Decimal | None
    sourcewise_sales: Decimal | None
    tabwise_bills: int | None
    sourcewise_bills: int | None

    @property
    def sales_difference(self) -> Decimal | None:
        if self.tabwise_sales is None or self.sourcewise_sales is None:
            return None
        return self.tabwise_sales - self.sourcewise_sales


@dataclass(slots=True)
class ValidationReport:
    files: list[FileSummary]
    issues: list[ReconciliationIssue]
    branch_days_extracted: int
    branch_days_checked: int
    branch_days_reconciled: int
    comparison_available: bool
    outlets: set[str]
    years: set[int]
    months_by_year: dict[int, set[int]]
    tabwise_categories: set[str]
    sourcewise_categories: set[str]
    monthly_totals: dict[ReportKind, dict[BranchMonth, SalesAndBills]]
    monthly_categories: dict[ReportKind, dict[BranchMonthCategory, SalesAndBills]]
    skipped_rows: int
    unpaired_months: list[str]
    monthly_charges: dict[ReportKind, dict[BranchMonth, Decimal]] = field(default_factory=dict)
    monthly_discounts: dict[ReportKind, dict[BranchMonth, Decimal]] = field(default_factory=dict)
    excluded_files: list[FileSummary] = field(default_factory=list)
    daily_totals: dict[ReportKind, dict[BranchDay, SalesAndBills]] = field(default_factory=dict)
    daily_charges: dict[ReportKind, dict[BranchDay, Decimal]] = field(default_factory=dict)
    skipped_files: list[SkippedFile] = field(default_factory=list)

    @property
    def data_quality_score(self) -> int | None:
        if not self.comparison_available:
            return None
        if not self.branch_days_checked:
            return 0
        return int(100 * self.branch_days_reconciled / self.branch_days_checked)

    @property
    def recovered_net_sales(self) -> int:
        return sum(file.recovered_net_sales for file in self.files)

    def to_markdown(self) -> str:
        lines = [
            "# HERFY Local Sales Validation",
            "",
            "## Dynamic discovery",
            f"- Source files used: {len(self.files)}",
            f"- Branches discovered from CSV: {len(self.outlets)}",
            f"- Outlet-days extracted: {self.branch_days_extracted:,}",
            "- XLSX template is not loaded during CSV analysis; use **Export Excel report** to export.",
            f"- Years detected: {', '.join(map(str, sorted(self.years))) or 'None'}",
        ]
        if self.excluded_files:
            lines.extend(
                [
                    (
                        "- Overlapping alternatives were automatically compared; the selected "
                        "files maximize compared branch-days, then the reconciliation rate."
                    ),
                    "- Excluded alternatives: "
                    + "; ".join(
                        f"{file.report_kind}: `{file.path.name}`" for file in self.excluded_files
                    ),
                ]
            )
        for year in sorted(self.months_by_year):
            month_names = ", ".join(
                date(year, month, 1).strftime("%B") for month in sorted(self.months_by_year[year])
            )
            lines.append(f"- {year} months detected: {month_names}")
        lines.extend(
            [
                f"- Tabwise categories detected: {', '.join(sorted(self.tabwise_categories)) or 'None'}",
                f"- Sourcewise sources detected: {', '.join(sorted(self.sourcewise_categories)) or 'None'}",
                "",
            ]
        )
        if self.comparison_available:
            lines.extend(
                [
                    "## Reconciliation",
                    f"- Branch-days checked: {self.branch_days_checked:,}",
                    f"- Reconciled: {self.branch_days_reconciled:,}",
                    f"- Issues surfaced: {len(self.issues):,}",
                    f"- Data Quality: {self.data_quality_score}/100",
                ]
            )
        else:
            available_type = self.files[0].report_kind if self.files else "sales"
            missing_type = "Sourcewise" if available_type == "Tabwise" else "Tabwise"
            lines.extend(
                [
                    "",
                    "## Reconciliation",
                    f"- Not run: import a {missing_type} report to compare daily totals.",
                ]
            )
        lines.append(
            f"- Rows skipped because outlet/date was blank or invalid: {self.skipped_rows:,}"
        )
        if self.unpaired_months:
            lines.append(f"- Months missing one report type: {', '.join(self.unpaired_months)}")
        lines.extend(
            [
                "",
                (
                    "Issues are surfaced rather than hidden. This report compares daily totals; "
                    "it does not infer channel-level causes."
                    if self.comparison_available
                    else "This is an extraction-only result; reconciliation is unavailable until "
                    "the matching report type is imported."
                ),
                "",
                "## Explicit source recovery",
            ]
        )
        recoveries = [
            (file.path.name, file.recovered_net_sales)
            for file in self.files
            if file.recovered_net_sales
        ]
        if recoveries:
            for filename, count in recoveries:
                lines.append(
                    f"- `{filename}`: Recovered {count} blank Net Sale value(s) as Sale - Discount"
                )
        else:
            lines.append("- No blank Net Sale values required recovery.")
        lines.extend(["", "## Source files"])
        for file in self.files:
            date_range = _format_date_range(file.dates)
            lines.append(
                f"- {file.report_kind}: `{file.path.name}` — {file.rows_read:,} rows, "
                f"{file.branch_count} branches, {date_range}"
            )
        if self.skipped_files:
            lines.extend(["", "## Skipped files"])
            lines.extend(
                f"- `{item.path.name}`: {_escape_table(item.reason)}"
                for item in self.skipped_files
            )
        lines.extend(["", "## Reconciliation issues", ""])
        if not self.comparison_available:
            lines.append("Reconciliation was not run because only one report type was imported.")
        elif not self.issues:
            lines.append("No branch-day issues were found.")
        else:
            lines.extend(
                [
                    "| Date | Outlet | Issue | Tabwise Net Sale | Sourcewise Net Sale | Difference | Tabwise Bills | Sourcewise Bills |",
                    "|---|---|---|---:|---:|---:|---:|---:|",
                ]
            )
            for issue in self.issues:
                lines.append(
                    "| "
                    + " | ".join(
                        [
                            issue.business_date.isoformat(),
                            _escape_table(issue.outlet),
                            _escape_table("; ".join(issue.reasons)),
                            format_money(issue.tabwise_sales),
                            format_money(issue.sourcewise_sales),
                            format_money(issue.sales_difference),
                            format_integer(issue.tabwise_bills),
                            format_integer(issue.sourcewise_bills),
                        ]
                    )
                    + " |"
                )
        return "\n".join(lines) + "\n"


@dataclass(slots=True)
class _LoadedFile:
    summary: FileSummary
    totals: dict[BranchDay, SalesAndBills]
    monthly_totals: dict[BranchMonth, SalesAndBills]
    monthly_categories: dict[BranchMonthCategory, SalesAndBills]
    monthly_charges: dict[BranchMonth, Decimal]
    monthly_discounts: dict[BranchMonth, Decimal]
    daily_charges: dict[BranchDay, Decimal]


def _select_report_versions(
    files: list[_LoadedFile],
) -> tuple[list[_LoadedFile], list[_LoadedFile]]:
    versions: dict[tuple[ReportKind, date, date, str], list[_LoadedFile]] = {}
    for file in files:
        dates = file.summary.dates
        start_date = min(dates) if dates else date.min
        end_date = max(dates) if dates else date.min
        unique_path = "" if dates else str(file.summary.path)
        period = (file.summary.report_kind, start_date, end_date, unique_path)
        versions.setdefault(period, []).append(file)

    groups: list[list[_LoadedFile]] = []
    for group in versions.values():
        ordered = sorted(group, key=lambda item: item.summary.path.name.lower())
        if len(ordered) > 1:
            coverage_by_file = {id(file): set(file.totals) for file in ordered}
            full_coverage = set().union(*coverage_by_file.values())
            ordered = [file for file in ordered if coverage_by_file[id(file)] == full_coverage]
            if not ordered:
                names = ", ".join(file.summary.path.name for file in group)
                raise ValueError(
                    "Overlapping report versions have different outlet-day coverage, so "
                    "choosing one would omit data. Select a corrected report set manually: "
                    f"{names}"
                )
        groups.append(ordered)
    groups.sort(
        key=lambda group: (
            group[0].summary.report_kind,
            min(group[0].summary.dates) if group[0].summary.dates else date.min,
            max(group[0].summary.dates) if group[0].summary.dates else date.min,
            group[0].summary.path.name.lower(),
        )
    )
    candidate_count = 1
    for group in groups:
        candidate_count *= len(group)
    if candidate_count > 4096:
        raise ValueError(
            f"{candidate_count:,} report combinations would need comparison. "
            "Import fewer files, keeping only one report of each type for each date range."
        )

    best_selection: list[_LoadedFile] | None = None
    best_key: tuple[int, Fraction, int, int, int] | None = None
    for choices in product(*groups):
        selection = list(choices)
        report = _build_validation_report(selection)
        reconciliation_rate = Fraction(
            report.branch_days_reconciled,
            max(report.branch_days_checked, 1),
        )
        key = (
            report.branch_days_checked,
            reconciliation_rate,
            report.branch_days_reconciled,
            report.branch_days_extracted,
            sum(file.summary.recovered_net_sales for file in selection),
        )
        if best_key is None or key > best_key:
            best_selection = selection
            best_key = key

    if best_selection is None:
        return [], []
    selected_ids = {id(file) for file in best_selection}
    excluded = [file for file in files if id(file) not in selected_ids]

    first_sources: dict[tuple[ReportKind, BranchDay], Path] = {}
    overlaps: dict[tuple[ReportKind, Path, Path], int] = {}
    for file in best_selection:
        report_kind = file.summary.report_kind
        for branch_day in file.totals:
            key = (report_kind, branch_day)
            first_path = first_sources.get(key)
            if first_path is None:
                first_sources[key] = file.summary.path
                continue
            overlap = (report_kind, first_path, file.summary.path)
            overlaps[overlap] = overlaps.get(overlap, 0) + 1

    if overlaps:
        details = [
            f"{kind}: {first.name} and {second.name} overlap on {count:,} outlet-day(s)"
            for (kind, first, second), count in sorted(
                overlaps.items(),
                key=lambda item: (item[0][0], item[0][1].name, item[0][2].name),
            )
        ]
        raise ValueError(
            "Report files with different date ranges still overlap. Keep one report per "
            "overlapping period and try again:\n- "
            + "\n- ".join(details[:8])
            + (f"\n- ... and {len(details) - 8} more overlap(s)" if len(details) > 8 else "")
        )
    return best_selection, excluded


def analyze_csv_files(
    paths: Sequence[str | Path], *, allowed_outlets: Collection[str] | None = None
) -> ValidationReport:
    if not paths:
        raise ValueError("Select at least one Tabwise or Sourcewise CSV file.")

    allowed = (
        {str(outlet).strip().casefold() for outlet in allowed_outlets if str(outlet).strip()}
        if allowed_outlets is not None
        else None
    )
    loaded: list[_LoadedFile] = []
    skipped: list[SkippedFile] = []
    for path in paths:
        csv_path = Path(path)
        try:
            loaded.append(_read_sales_file(csv_path, allowed_outlets=allowed))
        except (ValueError, csv.Error, OSError, UnicodeDecodeError) as exc:
            reason = str(exc)
            logger.info("Skipping unsupported sales report %s: %s", csv_path.name, reason)
            skipped.append(SkippedFile(csv_path, reason))
    selected, excluded = _select_report_versions(loaded) if loaded else ([], [])
    report = _build_validation_report(selected)
    report.excluded_files = [file.summary for file in excluded]
    report.skipped_files = skipped
    return report


def _build_validation_report(loaded: list[_LoadedFile]) -> ValidationReport:
    tabwise = [file for file in loaded if file.summary.report_kind == "Tabwise"]
    sourcewise = [file for file in loaded if file.summary.report_kind == "Sourcewise"]
    comparison_available = bool(tabwise and sourcewise)

    totals_by_kind: dict[ReportKind, dict[BranchDay, tuple[Decimal, int]]] = {
        "Tabwise": {},
        "Sourcewise": {},
    }
    monthly_totals_by_kind: dict[ReportKind, dict[BranchMonth, SalesAndBills]] = {
        "Tabwise": {},
        "Sourcewise": {},
    }
    monthly_categories_by_kind: dict[ReportKind, dict[BranchMonthCategory, SalesAndBills]] = {
        "Tabwise": {},
        "Sourcewise": {},
    }
    monthly_charges_by_kind: dict[ReportKind, dict[BranchMonth, Decimal]] = {
        "Tabwise": {},
        "Sourcewise": {},
    }
    monthly_discounts_by_kind: dict[ReportKind, dict[BranchMonth, Decimal]] = {
        "Tabwise": {},
        "Sourcewise": {},
    }
    daily_charges_by_kind: dict[ReportKind, dict[BranchDay, Decimal]] = {
        "Tabwise": {},
        "Sourcewise": {},
    }
    for file in loaded:
        totals = totals_by_kind[file.summary.report_kind]
        for key, value in file.totals.items():
            previous_sales, previous_bills = totals.get(key, (Decimal(0), 0))
            totals[key] = previous_sales + value[0], previous_bills + value[1]
        monthly_totals = monthly_totals_by_kind[file.summary.report_kind]
        for key, value in file.monthly_totals.items():
            previous_sales, previous_bills = monthly_totals.get(key, (Decimal(0), 0))
            monthly_totals[key] = previous_sales + value[0], previous_bills + value[1]
        monthly_categories = monthly_categories_by_kind[file.summary.report_kind]
        for key, value in file.monthly_categories.items():
            previous_sales, previous_bills = monthly_categories.get(key, (Decimal(0), 0))
            monthly_categories[key] = previous_sales + value[0], previous_bills + value[1]
        monthly_charges = monthly_charges_by_kind[file.summary.report_kind]
        for key, value in file.monthly_charges.items():
            monthly_charges[key] = monthly_charges.get(key, Decimal(0)) + value
        monthly_discounts = monthly_discounts_by_kind[file.summary.report_kind]
        for key, value in file.monthly_discounts.items():
            monthly_discounts[key] = monthly_discounts.get(key, Decimal(0)) + value
        daily_charges = daily_charges_by_kind[file.summary.report_kind]
        for key, value in file.daily_charges.items():
            daily_charges[key] = daily_charges.get(key, Decimal(0)) + value

    tabwise_totals = totals_by_kind["Tabwise"]
    sourcewise_totals = totals_by_kind["Sourcewise"]
    all_keys = set(tabwise_totals) | set(sourcewise_totals)
    issues: list[ReconciliationIssue] = []
    for outlet, business_date in sorted(all_keys, key=lambda item: (item[1], item[0])):
        if not comparison_available:
            continue
        tabwise_value = tabwise_totals.get((outlet, business_date))
        sourcewise_value = sourcewise_totals.get((outlet, business_date))
        reasons: list[str] = []
        if tabwise_value is None:
            reasons.append("Missing Tabwise branch-day")
        if sourcewise_value is None:
            reasons.append("Missing Sourcewise branch-day")
        if tabwise_value is not None and sourcewise_value is not None:
            if tabwise_value[0] != sourcewise_value[0]:
                reasons.append("Net Sale mismatch")
            if tabwise_value[1] != sourcewise_value[1]:
                reasons.append("No Of Bills mismatch")
        if reasons:
            issues.append(
                ReconciliationIssue(
                    outlet=outlet,
                    business_date=business_date,
                    reasons=reasons,
                    tabwise_sales=tabwise_value[0] if tabwise_value else None,
                    sourcewise_sales=sourcewise_value[0] if sourcewise_value else None,
                    tabwise_bills=tabwise_value[1] if tabwise_value else None,
                    sourcewise_bills=sourcewise_value[1] if sourcewise_value else None,
                )
            )

    months_by_year: dict[int, set[int]] = {}
    for _, business_date in all_keys:
        months_by_year.setdefault(business_date.year, set()).add(business_date.month)
    tabwise_months = {
        (business_date.year, business_date.month) for _, business_date in tabwise_totals
    }
    sourcewise_months = {
        (business_date.year, business_date.month) for _, business_date in sourcewise_totals
    }
    unpaired_months = [
        f"{year}-{month:02d}"
        for year, month in sorted(tabwise_months | sourcewise_months)
        if (year, month) not in tabwise_months or (year, month) not in sourcewise_months
    ]
    branch_days_extracted = len(all_keys)
    branch_days_checked = branch_days_extracted if comparison_available else 0
    return ValidationReport(
        files=[file.summary for file in loaded],
        issues=issues,
        branch_days_extracted=branch_days_extracted,
        branch_days_checked=branch_days_checked,
        branch_days_reconciled=branch_days_checked - len(issues),
        comparison_available=comparison_available,
        outlets={outlet for outlet, _ in all_keys},
        years=set(months_by_year),
        months_by_year=months_by_year,
        tabwise_categories=set().union(*(file.summary.categories for file in tabwise)),
        sourcewise_categories=set().union(*(file.summary.categories for file in sourcewise)),
        monthly_totals=monthly_totals_by_kind,
        monthly_categories=monthly_categories_by_kind,
        skipped_rows=sum(file.summary.skipped_rows for file in loaded),
        unpaired_months=unpaired_months,
        monthly_charges=monthly_charges_by_kind,
        monthly_discounts=monthly_discounts_by_kind,
        daily_totals=totals_by_kind,
        daily_charges=daily_charges_by_kind,
    )


def _read_sales_file(path: Path, *, allowed_outlets: set[str] | None = None) -> _LoadedFile:
    report_kind = detect_report_kind(path)
    try:
        return _read_sales_file_contents(path, report_kind, allowed_outlets=allowed_outlets)
    except UnicodeDecodeError as exc:
        raise ValueError(
            f"{path.name} is not valid UTF-8 CSV; save or export it as UTF-8 and try again."
        ) from exc


def _read_sales_file_contents(
    path: Path, report_kind: ReportKind, *, allowed_outlets: set[str] | None = None
) -> _LoadedFile:
    try:
        stream = path.open("r", encoding="utf-8-sig", newline="")
    except OSError as exc:
        raise ValueError(f"Could not open {path.name}: {exc}") from exc

    with stream:
        reader = csv.DictReader(stream)
        headers = {
            _normalize_header(header): header
            for header in (reader.fieldnames or [])
            if header and header.strip()
        }
        if "tabs" in headers:
            category_column = headers["tabs"]
        elif "source" in headers:
            category_column = headers["source"]
        else:
            raise ValueError(
                f"{path.name} is not a recognized sales CSV: expected a Tabs or Source column."
            )

        required = {"outletname", "date", "noofbills"}
        missing = required - headers.keys()
        if missing:
            expected = ", ".join(sorted(missing))
            raise ValueError(
                f"{path.name} is not a supported {report_kind} channel-sales report; "
                f"missing required columns: {expected}."
            )
        if "netsale" not in headers and not {"sale", "discount"} <= headers.keys():
            raise ValueError(f"{path.name} needs Net Sale or both Sale and Discount columns.")
        charges_column = (
            headers.get("charges") or headers.get("charge") or headers.get("totalcharges")
        )
        discount_column = headers.get("discount")

        totals: dict[BranchDay, SalesAndBills] = {}
        monthly_totals: dict[BranchMonth, SalesAndBills] = {}
        monthly_categories: dict[BranchMonthCategory, SalesAndBills] = {}
        monthly_charges: dict[BranchMonth, Decimal] = {}
        monthly_discounts: dict[BranchMonth, Decimal] = {}
        daily_charges: dict[BranchDay, Decimal] = {}
        outlets: set[str] = set()
        dates: set[date] = set()
        categories: set[str] = set()
        rows_read = recovered = skipped = 0
        for line_number, row in enumerate(reader, start=2):
            rows_read += 1
            outlet = (row.get(headers["outletname"]) or "").strip()
            date_value = (row.get(headers["date"]) or "").strip()
            business_date = _parse_date(date_value)
            if not outlet or business_date is None:
                skipped += 1
                continue
            if allowed_outlets is not None and outlet.casefold() not in allowed_outlets:
                continue

            net_sale_value = row.get(headers["netsale"]) if "netsale" in headers else None
            net_sale_text = (net_sale_value or "").strip()
            if net_sale_text:
                net_sale = _parse_decimal(net_sale_text, path, line_number, "Net Sale")
            else:
                if "sale" not in headers or "discount" not in headers:
                    raise ValueError(
                        f"{path.name}:{line_number} has blank Net Sale and no Sale/Discount "
                        "columns for recovery."
                    )
                sale = _parse_decimal(row.get(headers["sale"]) or "", path, line_number, "Sale")
                discount = _parse_decimal(
                    row.get(headers["discount"]) or "",
                    path,
                    line_number,
                    "Discount",
                )
                net_sale = sale - discount
                recovered += 1

            bills_value = (row.get(headers["noofbills"]) or "").strip()
            if not bills_value:
                raise ValueError(
                    f"{path.name}:{line_number} has no No Of Bills value; "
                    "guest count cannot be inferred from sales rows."
                )
            bills_decimal = _parse_decimal(bills_value, path, line_number, "No Of Bills")
            if bills_decimal != bills_decimal.to_integral_value():
                raise ValueError(f"{path.name}:{line_number} has a non-integer No Of Bills value.")
            key = (outlet, business_date)
            previous_sales, previous_bills = totals.get(key, (Decimal(0), 0))
            totals[key] = previous_sales + net_sale, previous_bills + int(bills_decimal)
            month_key = (outlet, business_date.year, business_date.month)
            if discount_column is not None:
                discount_text = (row.get(discount_column) or "").strip()
                discount = (
                    _parse_decimal(discount_text, path, line_number, "Discount")
                    if discount_text
                    else Decimal(0)
                )
                monthly_discounts[month_key] = (
                    monthly_discounts.get(month_key, Decimal(0)) + discount
                )
            if charges_column is not None:
                charges_text = (row.get(charges_column) or "").strip()
                if charges_text:
                    charges = _parse_decimal(charges_text, path, line_number, "Charges")
                    monthly_charges[month_key] = (
                        monthly_charges.get(month_key, Decimal(0)) + charges
                    )
                    daily_charges[key] = daily_charges.get(key, Decimal(0)) + charges
            previous_month_sales, previous_month_bills = monthly_totals.get(
                month_key, (Decimal(0), 0)
            )
            monthly_totals[month_key] = (
                previous_month_sales + net_sale,
                previous_month_bills + int(bills_decimal),
            )
            outlets.add(outlet)
            dates.add(business_date)
            category = (row.get(category_column) or "").strip()
            if category:
                categories.add(category)
                category_key = (
                    outlet,
                    business_date.year,
                    business_date.month,
                    category,
                )
                previous_category_sales, previous_category_bills = monthly_categories.get(
                    category_key, (Decimal(0), 0)
                )
                monthly_categories[category_key] = (
                    previous_category_sales + net_sale,
                    previous_category_bills + int(bills_decimal),
                )

    return _LoadedFile(
        summary=FileSummary(
            path=path,
            report_kind=report_kind,
            rows_read=rows_read,
            branch_count=len(outlets),
            categories=categories,
            dates=dates,
            recovered_net_sales=recovered,
            skipped_rows=skipped,
        ),
        totals=totals,
        monthly_totals=monthly_totals,
        monthly_categories=monthly_categories,
        monthly_charges=monthly_charges,
        monthly_discounts=monthly_discounts,
        daily_charges=daily_charges,
    )


def _normalize_header(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]", "", value.lstrip("\ufeff").strip().lower())
    return _HEADER_ALIASES.get(normalized, normalized)


def _parse_decimal(value: str, path: Path, line_number: int, column: str) -> Decimal:
    normalized = value.strip().replace(",", "")
    try:
        parsed = Decimal(normalized)
    except InvalidOperation as exc:
        raise ValueError(
            f"{path.name}:{line_number} has an invalid {column} value: {value!r}."
        ) from exc
    if not parsed.is_finite():
        raise ValueError(f"{path.name}:{line_number} has a non-finite {column} value: {value!r}.")
    return parsed


def _parse_date(value: str) -> date | None:
    if not value:
        return None
    try:
        return date.fromisoformat(value)
    except ValueError:
        try:
            month, day_value, year = (int(part) for part in value.split("/"))
            return date(year, month, day_value)
        except (TypeError, ValueError):
            pass
    return None


def _format_date_range(values: set[date]) -> str:
    if not values:
        return "no valid dates"
    return f"{min(values).isoformat()} to {max(values).isoformat()}"


def format_money(value: Decimal | None) -> str:
    return "—" if value is None else f"{value:,.2f}"


def format_integer(value: int | None) -> str:
    return "—" if value is None else f"{value:,}"


def _escape_table(value: str) -> str:
    return value.replace("|", "\\|").replace("\n", " ")
