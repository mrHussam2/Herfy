"""Shared, server-authoritative catalog delta application contract."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from core.runtime_ports import emit_updated


def apply_remote_catalog_changes(
    apply_changes: Callable[[list[dict] | None], dict[str, Any] | None],
    changes: list[dict] | None,
    *,
    entity_type: str,
    event_extras: dict[str, Any] | None = None,
    emit_event: bool = True,
) -> dict[str, Any]:
    """Apply a remote catalog delta and emit only when it changed local state."""
    result = dict(apply_changes(changes) or {})
    if emit_event and result.get("applied"):
        emit_updated(entity_type, {"action": "delta", **result, **(event_extras or {})})
    return result
