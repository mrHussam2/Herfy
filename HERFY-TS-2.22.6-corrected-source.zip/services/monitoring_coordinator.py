from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QObject, QTimer

from core.models import normalize_int
from services.notifications import NotificationEngine

logger = logging.getLogger(__name__)


class MonitoringCoordinator(QObject):
    """Own the background expiry lifecycle independently from pages and shell UI.

    The coordinator owns the wake timer, deduplicates evaluation work and
    invalidates outstanding callbacks whenever its session generation changes.
    Presentation supplies only a worker executor and delivery callbacks.
    """

    ERROR_RETRY_SECONDS = 60.0

    def __init__(
        self,
        monitoring_service: Any,
        *,
        start_worker: Callable[..., Any],
        publish_events: Callable[[list[dict]], None],
        reconcile_delivery: Callable[[], None],
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        self._service = monitoring_service
        self._start_worker = start_worker
        self._publish_events = publish_events
        self._reconcile_delivery = reconcile_delivery
        self._active = False
        self._generation = 0
        self._evaluation_token = 0
        self._evaluating = False
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.check_now)

    def ensure_started(self, generation: int) -> None:
        """Keep the current evaluation and timer intact on visibility changes."""
        if self._active and self._generation == int(generation):
            return
        self.start(generation)

    def start(self, generation: int, *, restart: bool = True) -> None:
        generation = int(generation)
        if generation != self._generation:
            self._evaluation_token += 1
            self._evaluating = False
        self._generation = generation
        self._active = bool(restart)
        if not self._active:
            self.stop()
            return
        self._prepare_schedule()

    def stop(self) -> None:
        self._active = False
        self._evaluation_token += 1
        self._evaluating = False
        self._timer.stop()

    def shutdown(self) -> None:
        self.stop()
        self._timer.deleteLater()

    def retry(self, delay_s: float | None = None) -> None:
        self._retry(delay_s)

    def _current(self, generation: int) -> bool:
        return self._active and int(generation) == self._generation

    def _arm(self, delay_s: float | None) -> None:
        if not self._active or delay_s is None:
            self._timer.stop()
            return
        self._timer.start(min(2_000_000_000, max(1000, int(float(delay_s) * 1000))))

    def _retry(self, delay_s: float | None = None) -> None:
        if self._active:
            self._arm(max(5.0, min(900.0, delay_s or self.ERROR_RETRY_SECONDS)))

    def _prepare_schedule(self) -> None:
        generation = self._generation

        def apply(payload: Any) -> None:
            if not self._current(generation):
                return
            data = payload if isinstance(payload, dict) else {}
            if not bool(data.get("enabled")):
                self.stop()
                return
            self._arm(data.get("delay_s"))
            if not bool(data.get("has_records")) and not bool(data.get("baseline_ready")):
                self._prime_baseline(generation)
            else:
                self.check_now()

        self._submit(
            self._service.prepare_schedule,
            on_result=apply,
            on_error=lambda message: self._on_error(generation, "schedule", message),
            operation_key="monitoring:schedule-prepare",
        )

    def _prime_baseline(self, generation: int) -> None:
        def apply(rows: Any) -> None:
            if not self._current(generation):
                return
            if not self._service.publish_preloaded_rows(list(rows or [])):
                self._retry()
                return
            self.check_now()

        self._submit(
            self._service.preload_rows,
            on_result=apply,
            on_error=lambda message: self._on_error(generation, "baseline", message),
            operation_key="monitoring:baseline-cache",
        )

    def check_now(self) -> None:
        if not self._active or self._evaluating:
            return
        self._evaluating = True
        self._evaluation_token += 1
        token = self._evaluation_token
        generation = self._generation
        worker = self._submit(
            lambda progress_callback=None: self._service.evaluate(runtime_generation=generation),
            on_result=lambda payload: self._apply_evaluation(token, generation, payload),
            on_finished=lambda: self._finish_evaluation(token),
            on_error=lambda message: self._on_error(generation, "evaluation", message),
            operation_key="expiry_check",
        )
        if worker is None:
            self._evaluating = False
            self._retry()

    def _apply_evaluation(self, token: int, generation: int, payload: Any) -> None:
        if token != self._evaluation_token or not self._current(generation):
            return
        data = payload if isinstance(payload, dict) else {}
        if not bool(data.get("enabled", True)):
            self.stop()
            return
        if not bool(data.get("baseline_ready", True)):
            self._reconcile_delivery()
            self._prime_baseline(generation)
            return
        if not bool(data.get("active_user", True)):
            self._retry()
            return
        combined: dict[str, dict] = {}
        for event in list(data.get("events") or []):
            key = str(event.get("alert_key") or NotificationEngine.alert_key(event))
            current = combined.get(key)
            if current is None or normalize_int(event.get("severity_rank"), 0) > normalize_int(
                current.get("severity_rank"), 0
            ):
                combined[key] = event
        self._publish_events(list(combined.values()))
        self._reconcile_delivery()
        self._arm(data.get("delay_s"))

    def _finish_evaluation(self, token: int) -> None:
        if token == self._evaluation_token:
            self._evaluating = False

    def _on_error(self, generation: int, stage: str, message: str) -> None:
        if self._current(generation):
            logger.error("EXPIRY_MONITOR_ERROR stage=%s detail=%s", stage, message)
            self._evaluating = False
            self._retry()

    def _submit(self, work: Callable[..., Any], **kwargs: Any) -> Any:
        return self._start_worker(work, **kwargs)
