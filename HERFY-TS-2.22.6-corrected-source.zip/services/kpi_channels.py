from __future__ import annotations

import re

from services.kpi_validation import SalesAndBills, ValidationReport

TABWISE_CHANNEL_ROWS = {
    "dinein": 3,
    "specialitemsdinein": 3,
    "takeout": 4,
    "drivethru": 5,
    "pickup": 6,
    "hspickup": 6,
    "delivery": 7,
    "hs": 9,
    "mb": 17,
}
SOURCEWISE_AGGREGATOR_ROWS = {
    "hungerstation": 9,
    "hs": 9,
    "keeta": 10,
    "jahez": 11,
    "posccjahez": 11,
    "ninja": 12,
    "ananinja": 12,
    "noon": 13,
    "noonfood": 13,
    "mrsool": 14,
    "toyou": 15,
    "chefz": 16,
}
COMPARISON_CHANNELS = (
    (3, "Dine in"),
    (4, "Take Out"),
    (5, "Drive Thru"),
    (6, "Pickup"),
    (7, "Delivery"),
    (9, "HS"),
    (10, "Keeta"),
    (11, "Jahez"),
    (12, "Ninja"),
    (13, "Noon"),
    (14, "Mrsool"),
    (15, "Toyou"),
    (16, "Chefz"),
    (17, "MB"),
)
DASHBOARD_OTHER_APP_CATEGORIES = {
    "ninja",
    "ananinja",
    "noon",
    "noonfood",
    "mrsool",
    "chefz",
}
DASHBOARD_CHANNEL_COLUMNS = {
    "drivethru": 3,
    "takeout": 5,
    "pickup": 7,
    "hspickup": 7,
    "dinein": 9,
    "specialitemsdinein": 9,
    "delivery": 11,
    "hs": 13,
    "hungerstation": 13,
    "jahez": 15,
    "posccjahez": 15,
    "keeta": 17,
    "toyou": 19,
    "mb": 21,
    "coupon": 23,
}


def normalize_category(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", value.lower())


def sum_pair(current: SalesAndBills | None, incoming: SalesAndBills) -> SalesAndBills:
    if current is None:
        return incoming
    return current[0] + incoming[0], current[1] + incoming[1]


def comparison_channel_values(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
) -> dict[int, SalesAndBills]:
    tab_values = report.monthly_categories["Tabwise"]
    branch_month = (outlet, year, month)
    tabwise_has_hs = any(
        key[:3] == branch_month and normalize_category(key[3]) == "hs" for key in tab_values
    )
    visible: dict[int, SalesAndBills] = {}

    for (branch, data_year, data_month, category), value in tab_values.items():
        if (branch, data_year, data_month) != branch_month:
            continue
        row = TABWISE_CHANNEL_ROWS.get(normalize_category(category))
        if row is not None:
            visible[row] = sum_pair(visible.get(row), value)

    for (branch, data_year, data_month, category), value in report.monthly_categories[
        "Sourcewise"
    ].items():
        if (branch, data_year, data_month) != branch_month:
            continue
        row = SOURCEWISE_AGGREGATOR_ROWS.get(normalize_category(category))
        if row is None or (row == 9 and tabwise_has_hs):
            continue
        visible[row] = sum_pair(visible.get(row), value)
    return visible
