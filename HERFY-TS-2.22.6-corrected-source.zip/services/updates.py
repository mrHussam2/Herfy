from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import sys
import tempfile
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlparse

from contracts.binding import get_server_binding, get_update_trust
from contracts.routes import Routes
from core.errors import SERVICE_OPERATION_EXCEPTIONS, RemoteRequestError
from core.models import (
    compare_versions,
    parse_bool,
    parse_semver,
    resolve_download_url,
    safe_update_filename,
    should_require_update_sha256,
    should_update,
)
from core.processes import launch_elevated_detached
from core.runtime_ports import (
    api_request,
    get_updates_base_url,
    verify_signed_update_manifest_response,
    verify_update_manifest,
)
from core.settings import (
    APP_EXE,
    get_http_timeout_seconds,
    get_request_verify_ssl,
    runtime_cache_path,
)
from services.sync import prepare_update_check

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class UpdateTransportConfig:
    current_version: str
    updates_base_url: str
    http_timeout: float
    verify_ssl: bool


def build_update_transport_config(
    current_version: str, updates_base_url: str | None
) -> UpdateTransportConfig:
    return UpdateTransportConfig(
        current_version=str(current_version or "0.0.0"),
        updates_base_url=(updates_base_url or get_updates_base_url()).rstrip("/"),
        http_timeout=float(get_http_timeout_seconds()),
        verify_ssl=bool(get_request_verify_ssl()),
    )


class UpdateTransportConfigured:
    def __init__(
        self,
        current_version: str,
        updates_base_url: str | None = None,
    ) -> None:
        transport = build_update_transport_config(current_version, updates_base_url)
        self.current_version = transport.current_version
        self.updates_base_url = transport.updates_base_url
        self.http_timeout = transport.http_timeout
        self.verify_ssl = transport.verify_ssl


_MAX_UPDATE_DOWNLOAD_BYTES = 2 * 1024 * 1024 * 1024


def emit_progress_event(
    progress_callback: Callable[[object], None] | None, *, label: str, **payload: Any
) -> None:
    if progress_callback is None:
        return
    try:
        progress_callback(payload)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.exception("%s progress callback raised an exception", label)


def validate_sha256_checksum(value: str, *, package_label: str) -> str:
    normalized = str(value or "").strip().lower()
    if normalized and (not re.fullmatch("[0-9a-f]{64}", normalized)):
        raise RuntimeError(f"Invalid SHA256 checksum format for {package_label}")
    return normalized


def download_response_to_target(
    *,
    response,
    target: Path,
    temp_dir: Path,
    temp_prefix: str,
    expected_sha: str,
    expected_size: int,
    progress_callback: Callable[[object], None] | None,
    package_label: str,
    chunk_size: int,
    validate_temp: Callable[[Path], None] | None = None,
    cancel_callback: Callable[[], bool] | None = None,
) -> Path:
    try:
        declared_size = int(response.headers.get("content-length") or 0)
    except (TypeError, ValueError) as exc:
        response.close()
        raise RuntimeError(f"Invalid Content-Length for {package_label}") from exc
    expected_size = int(expected_size or 0)
    if declared_size < 0 or expected_size < 0:
        response.close()
        raise RuntimeError(f"Invalid declared size for {package_label}")
    if declared_size and expected_size and declared_size != expected_size:
        response.close()
        raise RuntimeError(
            f"{package_label.title()} metadata size mismatch. "
            f"content_length={declared_size} expected={expected_size}"
        )
    total = expected_size or declared_size
    if total > _MAX_UPDATE_DOWNLOAD_BYTES:
        response.close()
        raise RuntimeError(f"{package_label.title()} exceeds the maximum allowed size")
    emit_progress_event(
        progress_callback,
        label=package_label,
        stage="download",
        downloaded=0,
        total=total,
        percent=0 if total > 0 else None,
    )
    digest = hashlib.sha256()
    downloaded = 0
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            prefix=temp_prefix,
            suffix=".part",
            dir=temp_dir,
            delete=False,
        ) as handle:
            temp_path = Path(handle.name)
            for chunk in response.iter_content(chunk_size=chunk_size):
                if cancel_callback is not None and cancel_callback():
                    raise RuntimeError("Update download cancelled")
                if not chunk:
                    continue
                downloaded += len(chunk)
                if downloaded > _MAX_UPDATE_DOWNLOAD_BYTES:
                    raise RuntimeError(f"{package_label.title()} exceeds the maximum allowed size")
                if expected_size and downloaded > expected_size:
                    raise RuntimeError(f"{package_label.title()} exceeded the signed expected size")
                digest.update(chunk)
                handle.write(chunk)
                percent = int(downloaded / total * 100) if total > 0 else None
                emit_progress_event(
                    progress_callback,
                    label=package_label,
                    stage="download",
                    downloaded=downloaded,
                    total=total,
                    percent=percent,
                )
            handle.flush()
            os.fsync(handle.fileno())
        emit_progress_event(
            progress_callback,
            label=package_label,
            stage="download",
            downloaded=downloaded,
            total=total,
            percent=100 if total > 0 else None,
        )
        if expected_size and downloaded != expected_size:
            raise RuntimeError(
                f"{package_label.title()} size mismatch: expected={expected_size} actual={downloaded}"
            )
        actual_sha = digest.hexdigest()
        if expected_sha and actual_sha != expected_sha:
            raise RuntimeError(
                f"{package_label.title()} SHA256 mismatch: expected={expected_sha} actual={actual_sha}"
            )
        emit_progress_event(
            progress_callback,
            label=package_label,
            stage="verifying",
            downloaded=downloaded,
            total=total,
            percent=100 if total > 0 else None,
        )
        if validate_temp is not None:
            validate_temp(temp_path)
        if cancel_callback is not None and cancel_callback():
            raise RuntimeError("Update download cancelled")
        os.replace(temp_path, target)
        temp_path = None
        return target
    finally:
        try:
            response.close()
        finally:
            if temp_path is not None:
                try:
                    temp_path.unlink(missing_ok=True)
                except OSError:
                    logger.debug(
                        "Unable to remove temporary update file %s", temp_path, exc_info=True
                    )


def normalize_update_payload(payload: Any) -> tuple[str, Any]:
    if isinstance(payload, tuple) and len(payload) == 2:
        return (payload[0], payload[1])
    return ("installer", payload)


@dataclass(frozen=True)
class StartupContractDecision:
    clear_cached_session: bool
    show_banner_message: str
    force_logout: bool
    schedule_update_check: bool


class StartupContractService:
    @staticmethod
    def _normalized_roles(values: Iterable[Any] | None) -> set[str]:
        return {str(value).strip() for value in values or [] if str(value).strip()}

    @staticmethod
    def evaluate(
        *,
        startup_config: dict[str, Any] | None,
        compatibility_policy: dict[str, Any] | None,
        session_active: bool,
        role: str = "",
        current_version: str = "0.0.0",
    ) -> StartupContractDecision:
        startup = dict(startup_config or {})
        policy = dict(compatibility_policy or {})
        banner = dict(startup.get("startup_banner") or {})
        maintenance = dict(startup.get("maintenance_mode") or {})
        client_runtime = dict(startup.get("client_runtime") or {})
        clear_cached_session = bool(
            not parse_bool(client_runtime.get("allow_cached_login"), True) and (not session_active)
        )
        banner_message = ""
        if session_active and parse_bool(banner.get("enabled"), False):
            banner_message = str(banner.get("message") or "").strip()
        force_logout = False
        if session_active and parse_bool(maintenance.get("enabled"), False):
            allowed_roles = StartupContractService._normalized_roles(maintenance.get("allow_roles"))
            current_role = str(role or "").strip()
            force_logout = not allowed_roles or current_role not in allowed_roles
        minimum_client = str(client_runtime.get("force_logout_below_version") or "").strip()
        if (
            session_active
            and minimum_client
            and (parse_semver(current_version) < parse_semver(minimum_client))
        ):
            force_logout = True
        server_version = str(policy.get("server_version") or "").strip()
        minimum_supported = str(policy.get("minimum_supported_version") or "").strip()
        contract_version = str(policy.get("contract_version") or "").strip()
        if not server_version:
            raise RuntimeError("Server release identity is missing server_version")
        if not minimum_supported:
            raise RuntimeError("Server compatibility policy is missing minimum_supported_version")
        if not contract_version:
            raise RuntimeError("Server bootstrap contract_version is missing")
        below_minimum = parse_semver(current_version) < parse_semver(minimum_supported)
        if session_active and below_minimum:
            force_logout = True
            banner_message = (
                "This HERFY-TS version is below the minimum version accepted by the server. "
                "Install a signed supported update before continuing."
            )
        # Package/version discovery is intentionally delegated to the signed
        # update manifest. The API contributes only minimum compatibility policy.
        schedule_update_check = bool(below_minimum)
        return StartupContractDecision(
            clear_cached_session=clear_cached_session,
            show_banner_message=banner_message,
            force_logout=force_logout,
            schedule_update_check=schedule_update_check,
        )


@dataclass(frozen=True)
class RuntimeUpdateFlowDecision:
    clear_pending_optional_check: bool
    schedule_optional_check: bool
    schedule_mandatory_check: bool


class RuntimeUpdateFlowService:
    @staticmethod
    def after_startup_contract(
        *,
        session_active: bool,
        pending_optional_login_check: bool,
        force_logout: bool,
        mandatory_update_required: bool,
    ) -> RuntimeUpdateFlowDecision:
        if mandatory_update_required:
            return RuntimeUpdateFlowDecision(
                clear_pending_optional_check=bool(pending_optional_login_check),
                schedule_optional_check=False,
                schedule_mandatory_check=True,
            )
        if not session_active or force_logout:
            return RuntimeUpdateFlowDecision(
                clear_pending_optional_check=bool(pending_optional_login_check),
                schedule_optional_check=False,
                schedule_mandatory_check=False,
            )
        if pending_optional_login_check:
            return RuntimeUpdateFlowDecision(
                clear_pending_optional_check=True,
                schedule_optional_check=True,
                schedule_mandatory_check=False,
            )
        return RuntimeUpdateFlowDecision(
            clear_pending_optional_check=False,
            schedule_optional_check=False,
            schedule_mandatory_check=False,
        )


logger = logging.getLogger(__name__)


def _is_windows_runtime() -> bool:
    return os.name == "nt"


def _resolve_current_install_root() -> Path:
    """Return the real installed application directory for remote updates.

    Remote updates must replace the directory that contains the currently
    running frozen HERFY-TS.exe.  Never derive this from cwd, _MEIPASS, a default
    Program Files path, or an installer default, because users may install into a
    custom directory and PyInstaller extracts bundled files elsewhere.
    """
    executable = Path(sys.executable).resolve()
    if executable.name.casefold() != APP_EXE.casefold():
        raise RuntimeError(
            f"Remote update must be launched from the installed {APP_EXE} executable"
        )
    install_root = executable.parent.resolve()
    installed_exe = (install_root / APP_EXE).resolve()
    if installed_exe != executable or not installed_exe.is_file():
        raise RuntimeError("Unable to verify the current HERFY-TS installation directory")
    return install_root


def _verify_update_manifest(manifest: dict[str, Any]) -> None:
    verify_update_manifest(manifest)


def _fetch_public_client_policy() -> tuple[str | None, str]:
    """Read the optional minimum-version policy and release identity.

    This endpoint is intentionally unauthenticated so a client that is already
    below the server minimum can discover that the signed update is mandatory
    *before* login.  Contract identity is still pinned and validated by the
    normal HTTP transport.
    """
    binding = get_server_binding()
    response = api_request(
        "GET",
        Routes.META_VERSION,
        base_url=binding.api_base_url,
        headers={"Accept": "application/json", "Cache-Control": "no-store"},
        max_retries=1,
    )
    try:
        payload = response.json()
    finally:
        response.close()
    if not isinstance(payload, dict):
        raise RuntimeError("Public client release policy returned invalid data")
    contract = str(payload.get("api_contract_sha256") or "").strip().lower()
    if contract != binding.api_contract_sha256.lower():
        raise RuntimeError("Public client release policy contract does not match this client")
    # ``/api/meta/version`` formally guarantees only the pinned contract identity
    # and ``server_version``.  Some deployments may additionally expose a
    # minimum client version, but treating that extension as mandatory made the
    # background update check log a false error for the canonical endpoint.
    # The signed update manifest remains the authoritative package/version
    # source; this endpoint only contributes a mandatory-update floor when it
    # explicitly supplies one.
    minimum_value = str(payload.get("minimum_supported_client_version") or "").strip()
    minimum = minimum_value or None
    latest = str(
        payload.get("latest_client_version") or payload.get("server_version") or ""
    ).strip()
    version_pattern = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+$")
    if minimum is not None and not version_pattern.fullmatch(minimum):
        raise RuntimeError("Public minimum client version is invalid")
    if not version_pattern.fullmatch(latest):
        raise RuntimeError("Public latest client version is invalid")
    if minimum is not None and compare_versions(minimum, latest) > 0:
        raise RuntimeError("Public client release policy is inconsistent")
    return minimum, latest


def _fetch_signed_manifest(updates_base_url: str, current_version: str) -> dict[str, Any]:
    """Fetch the public signed update manifest without depending on login state.

    The update origin and manifest URL are pinned by the packaged update trust
    contract. A caller-supplied base URL may only reaffirm that same origin; it
    cannot redirect update discovery to a different host.
    """
    trust = get_update_trust()
    configured_origin = str(updates_base_url or trust.origin).rstrip("/")
    if configured_origin != trust.origin:
        raise RuntimeError(
            "Configured update origin does not match the packaged update trust contract"
        )
    try:
        response = api_request(
            "GET",
            trust.manifest_url,
            params={"client_version": current_version},
            headers={"Accept": "application/json", "Cache-Control": "no-store"},
            optional_statuses={404},
        )
    except RemoteRequestError as exc:
        if int(getattr(exc, "status_code", 0) or 0) == 404:
            return {"publication_status": "not_published"}
        raise
    try:
        manifest = verify_signed_update_manifest_response(response)
    finally:
        response.close()
    _verify_update_manifest(manifest)
    return manifest


@dataclass(frozen=True)
class UpdateInfo:
    available: bool
    latest: str
    url: str
    sha256: str = ""
    size: int = 0
    mandatory: bool = False


class UpdateManager(UpdateTransportConfigured):
    """Canonical production remote-update path: signed Inno installer only.

    Runtime ZIPs remain publication artifacts for offline/recovery validation,
    but the installed application never chooses an in-place ZIP patch. Running
    the stable-AppId installer is what keeps Windows Installed Apps identity,
    uninstall metadata, registry version, runtime files and restart semantics in
    one atomic release boundary.
    """

    def __init__(
        self,
        current_version: str,
        updates_base_url: str | None = None,
    ):
        super().__init__(current_version, updates_base_url)

    def fetch_manifest(self) -> dict[str, Any]:
        return _fetch_signed_manifest(self.updates_base_url, self.current_version)

    def fetch(
        self, skipped_version: str = "", *, manifest: dict[str, Any] | None = None
    ) -> UpdateInfo:
        if manifest is None:
            manifest = self.fetch_manifest()
        if not isinstance(manifest, dict):
            raise RuntimeError("Update manifest returned invalid data")
        if manifest.get("publication_status") == "not_published":
            return UpdateInfo(
                available=False,
                latest=self.current_version,
                url="",
            )
        _verify_update_manifest(manifest)
        latest = str(manifest["version"])
        available = should_update(self.current_version, latest)
        mandatory = False
        try:
            minimum_supported, _approved_latest = _fetch_public_client_policy()
            mandatory = bool(minimum_supported) and (
                compare_versions(self.current_version, minimum_supported) < 0
            )
        except SERVICE_OPERATION_EXCEPTIONS:
            # Update discovery must remain available when the API is temporarily
            # unreachable: the Ed25519-signed manifest is independently trusted.
            # Mandatory status will be recovered on the next public-policy check.
            logger.warning("Public client release policy check failed", exc_info=True)
        skipped = bool(
            available and skipped_version and skipped_version == latest and not mandatory
        )
        return UpdateInfo(
            available=available and not skipped,
            latest=latest,
            url=str(manifest["installer_url"]),
            sha256=str(manifest["installer_sha256"]),
            size=int(manifest["installer_size"]),
            mandatory=mandatory,
        )

    @staticmethod
    def _download_dir() -> Path:
        target = Path(runtime_cache_path("updates"))
        target.mkdir(parents=True, exist_ok=True)
        return target

    @staticmethod
    def _filename_from_headers(url: str, headers: dict | None = None) -> str:
        headers = headers or {}
        cd = str(headers.get("content-disposition") or headers.get("Content-Disposition") or "")
        m = re.search('filename\\*?=(?:UTF-8\\\'\\\')?"?([^";]+)"?', cd)
        if m:
            return safe_update_filename(
                m.group(1), "HERFY-TS-Setup.exe", allowed_suffixes=(".exe",)
            )
        path_name = Path(unquote(urlparse(url).path)).name
        return safe_update_filename(
            path_name or "HERFY-TS-Setup.exe",
            "HERFY-TS-Setup.exe",
            allowed_suffixes=(".exe",),
        )

    @classmethod
    def _cleanup_stale_installers(cls, keep: Path) -> None:
        download_dir = cls._download_dir().resolve()
        keep = Path(keep).resolve()
        for candidate in download_dir.glob("*.exe"):
            try:
                resolved = candidate.resolve()
                if resolved != keep and resolved.parent == download_dir:
                    resolved.unlink(missing_ok=True)
            except OSError:
                logger.debug("Unable to remove stale update installer %s", candidate, exc_info=True)

    def download_installer(
        self,
        info_or_url: UpdateInfo | str,
        progress_callback: Callable[[object], None] | None = None,
        cancel_callback: Callable[[], bool] | None = None,
    ) -> Path:
        if isinstance(info_or_url, UpdateInfo):
            url = str(info_or_url.url or "").strip()
            expected_sha = validate_sha256_checksum(
                info_or_url.sha256, package_label="installer package"
            )
            expected_size = int(info_or_url.size or 0)
        else:
            url = str(info_or_url or "").strip()
            expected_sha = ""
            expected_size = 0
        if should_require_update_sha256() and (not expected_sha):
            raise RuntimeError(
                "Update server did not provide the required SHA256 checksum for the installer"
            )
        url = resolve_download_url(url, self.updates_base_url)
        if not url:
            raise RuntimeError("No safe installer URL was provided by the update server")
        response = api_request(
            "GET",
            url,
            timeout=max(self.http_timeout, 90),
            verify=self.verify_ssl,
            stream=True,
        )
        filename = self._filename_from_headers(url, dict(response.headers))
        download_dir = self._download_dir()
        target = (download_dir / filename).resolve()
        if target.parent != download_dir.resolve():
            raise RuntimeError("Unsafe installer filename was rejected")
        installed = download_response_to_target(
            response=response,
            target=target,
            temp_dir=download_dir,
            temp_prefix="installer_",
            cancel_callback=cancel_callback,
            expected_sha=expected_sha,
            expected_size=expected_size,
            progress_callback=progress_callback,
            package_label="installer package",
            chunk_size=1024 * 512,
        )
        self._cleanup_stale_installers(installed)
        return installed

    @classmethod
    def launch_installer(
        cls,
        path: Path,
        *,
        expected_sha256: str = "",
        expected_size: int = 0,
    ) -> bool:
        """Hand off to the verified stable-AppId installer and return immediately.

        `/REMOTEUPDATE=1` is an explicit installer contract. In very-silent
        remote mode the installer never exposes its own wizard: the HERFY
        update surface owns all user-facing download and verification feedback.
        The installer removes the stale success marker, replaces the
        runtime, updates Windows uninstall/version metadata, runs installed
        self-check, writes a new success marker, and starts the new application
        as the original interactive user.
        """
        try:
            path = Path(path).resolve()
            trusted_download_dir = cls._download_dir().resolve()
            if path.parent != trusted_download_dir or not path.is_file():
                raise RuntimeError(
                    "Installer must be a verified file in the application update directory"
                )
            if path.suffix.lower() != ".exe":
                raise RuntimeError("HERFY-TS automatic updates require the verified Setup EXE")
            expected_sha = validate_sha256_checksum(
                expected_sha256, package_label="installer package"
            )
            actual_size = path.stat().st_size
            if int(expected_size or 0) > 0 and actual_size != int(expected_size):
                raise RuntimeError("Installer size changed after verification")
            if expected_sha:
                digest = hashlib.sha256()
                with path.open("rb") as handle:
                    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                        digest.update(chunk)
                if digest.hexdigest().casefold() != expected_sha.casefold():
                    raise RuntimeError("Installer changed after verification")
            if not _is_windows_runtime():
                raise RuntimeError("Automatic installer launch is supported on Windows only")
            if not bool(getattr(sys, "frozen", False)):
                raise RuntimeError(
                    "Automatic remote installation is allowed only from the installed HERFY-TS.exe runtime"
                )
            install_root = _resolve_current_install_root()
            remote_log = trusted_download_dir / "HERFY-TS-remote-update.log"
            launch_elevated_detached(
                [
                    path,
                    # The HERFY update surface is the only progress UI.  Inno
                    # performs the privileged file transaction without showing
                    # its legacy wizard after the client hands off and exits.
                    "/VERYSILENT",
                    "/SP-",
                    "/SUPPRESSMSGBOXES",
                    "/NOCANCEL",
                    "/NORESTART",
                    "/CLOSEAPPLICATIONS",
                    "/REMOTEUPDATE=1",
                    f"/DIR={install_root}",
                    f"/LOG={remote_log}",
                ],
                cwd=path.parent,
                show_window=False,
            )
            return True
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to launch installer: %s", path)
            return False


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StartupRuntimeEvaluation:
    contract: Any
    flow: Any


class UpdateRuntimeService:
    """Application boundary for update/startup policy used by the Qt shell."""

    def __init__(self, application: Any, server_runtime_service: Any) -> None:
        if application is None or server_runtime_service is None:
            raise ValueError("UpdateRuntimeService requires application and server runtime service")
        self._application = application
        self._server_runtime = server_runtime_service

    def consume_update_success_marker(self, current_version: str) -> str:
        """Consume the packaged updater success marker away from the Qt thread.

        Returns the installed version to present, or an empty string when no
        marker exists.  Marker parsing/removal is deliberately application-side
        file I/O and is expected to run through the worker boundary.
        """
        if not bool(getattr(sys, "frozen", False)):
            return ""
        marker = Path(sys.executable).resolve().parent / ".update_success.json"
        if not marker.is_file():
            return ""
        fallback = str(current_version or "").strip()
        try:
            payload = json.loads(marker.read_text(encoding="utf-8-sig"))
            version = str(payload.get("version") or fallback).strip() or fallback
            marker.unlink(missing_ok=True)
            return version
        except (OSError, ValueError, json.JSONDecodeError):
            logger.warning("Unable to consume update success marker", exc_info=True)
            return ""

    def resolve_check(self, *, force: bool = False) -> tuple[str, bool]:
        return prepare_update_check(self._application, force=bool(force))

    def mark_check_success(self, *, now_ts: int | None = None) -> None:
        import time

        current_ts = int(time.time()) if now_ts is None else int(now_ts)
        self._application.set_setting("updates/last_success", str(current_ts))

    def save_skipped_version(self, version: str) -> None:
        clean = str(version or "").strip()
        if clean:
            self._application.set_setting("updates/skipped_version", clean)

    @staticmethod
    def normalize_payload(payload: Any):
        return normalize_update_payload(payload)

    def apply_cached_startup_contract(self) -> dict[str, Any]:
        snapshot = self._server_runtime.load_cached()
        return self._server_runtime.apply_startup_config(self._application, snapshot)

    def fetch_startup_contract(self, client_version: str) -> dict[str, Any]:
        return self._server_runtime.fetch_and_apply(
            self._application,
            str(client_version or ""),
            self._application.cloud,
        )

    def evaluate_startup_contract(
        self,
        payload: dict[str, Any] | None,
        *,
        session_active: bool,
        pending_optional_login_check: bool,
        current_version: str,
    ) -> StartupRuntimeEvaluation:
        data = dict(payload or {})
        startup = data.get("startup_config") if isinstance(data.get("startup_config"), dict) else {}
        compatibility = (
            data.get("compatibility_policy")
            if isinstance(data.get("compatibility_policy"), dict)
            else {}
        )
        ctx = self._application.permission_context()
        decision = StartupContractService.evaluate(
            startup_config=startup,
            compatibility_policy=compatibility,
            session_active=bool(session_active),
            role=str(getattr(ctx, "role", "") or "").strip(),
            current_version=str(current_version or "0.0.0"),
        )
        flow = RuntimeUpdateFlowService.after_startup_contract(
            session_active=bool(session_active),
            pending_optional_login_check=bool(pending_optional_login_check),
            force_logout=decision.force_logout,
            mandatory_update_required=decision.schedule_update_check,
        )
        return StartupRuntimeEvaluation(contract=decision, flow=flow)

    @staticmethod
    def after_startup_contract(
        *,
        session_active: bool,
        pending_optional_login_check: bool,
        force_logout: bool,
        mandatory_update_required: bool,
    ):
        return RuntimeUpdateFlowService.after_startup_contract(
            session_active=bool(session_active),
            pending_optional_login_check=bool(pending_optional_login_check),
            force_logout=bool(force_logout),
            mandatory_update_required=bool(mandatory_update_required),
        )
