from __future__ import annotations

from decimal import Decimal

from services.kpi_validation import SalesAndBills, ValidationReport


def report_net_total_value(
    report: ValidationReport,
    outlet: str,
    year: int,
    month: int,
) -> SalesAndBills | None:
    branch_month = (outlet, year, month)
    daily_keys = {
        key
        for kind in ("Tabwise", "Sourcewise")
        for key in report.daily_totals.get(kind, {})
        if key[0] == outlet and key[1].year == year and key[1].month == month
    }
    if daily_keys:
        sales = Decimal(0)
        bills = 0
        charges = Decimal(0)
        for key in daily_keys:
            sourcewise_total = report.daily_totals.get("Sourcewise", {}).get(key)
            if sourcewise_total is not None:
                total = sourcewise_total
                day_charges = report.daily_charges.get("Sourcewise", {}).get(key)
                if day_charges is None:
                    day_charges = report.daily_charges.get("Tabwise", {}).get(key, Decimal(0))
            else:
                total = report.daily_totals.get("Tabwise", {}).get(key)
                if total is None:
                    continue
                day_charges = report.daily_charges.get("Tabwise", {}).get(key, Decimal(0))
            sales += total[0] + day_charges
            bills += total[1]
        return sales, bills

    sourcewise_total = report.monthly_totals["Sourcewise"].get(branch_month)
    if sourcewise_total is not None:
        total = sourcewise_total
        charges = report.monthly_charges.get("Sourcewise", {}).get(branch_month)
        if charges is None:
            charges = report.monthly_charges.get("Tabwise", {}).get(branch_month, Decimal(0))
    else:
        total = report.monthly_totals["Tabwise"].get(branch_month)
        charges = report.monthly_charges.get("Tabwise", {}).get(branch_month, Decimal(0))
    if total is None:
        return None
    return total[0] + charges, total[1]


def sum_report_net_totals(
    report: ValidationReport,
    outlets: list[str],
    year: int | None,
) -> SalesAndBills | None:
    if year is None:
        return None
    months = {
        (outlet, month)
        for kind in ("Tabwise", "Sourcewise")
        for outlet, data_year, month in report.monthly_totals[kind]
        if outlet in outlets and data_year == year
    }
    totals = [report_net_total_value(report, outlet, year, month) for outlet, month in months]
    available = [total for total in totals if total is not None]
    if not available:
        return None
    return (
        sum((total[0] for total in available), Decimal(0)),
        sum(total[1] for total in available),
    )


def sum_month_report_net_totals(
    report: ValidationReport,
    outlets: list[str],
    year: int | None,
    month: int,
) -> SalesAndBills | None:
    if year is None:
        return None
    totals = [report_net_total_value(report, outlet, year, month) for outlet in outlets]
    available = [total for total in totals if total is not None]
    if not available:
        return None
    return (
        sum((total[0] for total in available), Decimal(0)),
        sum(total[1] for total in available),
    )
