from __future__ import annotations

import logging
from collections.abc import Callable

from PySide6.QtCore import QObject, QTimer
from PySide6.QtWidgets import QApplication

from core.signals import safe_disconnect

logger = logging.getLogger(__name__)


class RuntimeTimerScheduler(QObject):
    """Application-owned, keyed single-shot timer scheduler.

    This is deliberately independent of widgets: callers can provide a Qt
    parent only for lifetime integration, while the scheduler owns callbacks,
    cancellation, and shutdown semantics.
    """

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._timers: dict[str, QTimer] = {}

    def _timer_parent(self) -> QObject:
        application = QApplication.instance()
        parent = self.parent()
        if (
            application is not None
            and isinstance(parent, QObject)
            and parent.thread() == application.thread()
        ):
            return parent
        return self

    def schedule(self, key: str, callback: Callable[[], None] | None, delay_ms: int = 350) -> None:
        if not callable(callback):
            return
        timer = self._timers.get(key)
        if timer is None:
            timer = QTimer(self._timer_parent())
            timer.setSingleShot(True)
            self._timers[key] = timer
        else:
            safe_disconnect(
                timer.timeout, logger_=logger, context="timer disconnect during reschedule"
            )
        timer.timeout.connect(callback)
        timer.start(max(50, int(delay_ms)))

    def cancel(self, key: str) -> None:
        timer = self._timers.get(key)
        if timer is not None:
            timer.stop()

    def shutdown(self) -> None:
        for key, timer in list(self._timers.items()):
            try:
                timer.stop()
                safe_disconnect(
                    timer.timeout, logger_=logger, context=f"timer scheduler shutdown: {key}"
                )
                timer.deleteLater()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("Timer scheduler shutdown failed for %s", key, exc_info=True)
        self._timers.clear()
