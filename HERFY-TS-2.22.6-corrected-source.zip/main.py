from __future__ import annotations

import importlib.util
import os
import sys
from pathlib import Path

# Keep source runs clean.  This must happen before importing any application
# package; otherwise Python creates __pycache__ beside the delivered files.
sys.dont_write_bytecode = True


_REQUIRED_RUNTIME_IMPORTS: tuple[tuple[str, str], ...] = (
    ("PySide6", "PySide6"),
    ("requests", "requests"),
    ("packaging", "packaging"),
    ("cryptography", "cryptography"),
    ("openpyxl", "openpyxl"),
    ("xlrd", "xlrd"),
)

# Keep the handles alive for the life of the process.  On Windows an
# add_dll_directory handle removes its directory when it is garbage collected.
_QT_DLL_DIRECTORIES: list[object] = []


def _prepare_packaged_qt_runtime() -> None:
    """Prioritize this executable's Qt DLLs before importing PySide6.

    A frozen client can be started from Explorer, a shortcut, or an updater
    process whose PATH contains an unrelated Qt installation.  QtCore.pyd is
    imported before the normal application bootstrap, so the packaged binding
    directory must be registered here rather than after QApplication exists.
    Source runs deliberately retain their normal Python environment.
    """
    if not bool(getattr(sys, "frozen", False)) or os.name != "nt":
        return

    runtime_root = Path(getattr(sys, "_MEIPASS", "") or sys.executable).resolve()
    if runtime_root.is_file():
        runtime_root = runtime_root.parent
    candidates = (runtime_root / "PySide6", runtime_root / "PySide6" / "Qt" / "bin")
    valid_directories = [path for path in candidates if path.is_dir()]
    if not valid_directories:
        return

    inherited = [entry for entry in os.environ.get("PATH", "").split(os.pathsep) if entry]
    ordered = [str(path) for path in valid_directories]
    normalized = {entry.casefold() for entry in ordered}
    ordered.extend(entry for entry in inherited if entry.casefold() not in normalized)
    os.environ["PATH"] = os.pathsep.join(ordered)

    add_dll_directory = getattr(os, "add_dll_directory", None)
    if callable(add_dll_directory):
        for path in valid_directories:
            try:
                _QT_DLL_DIRECTORIES.append(add_dll_directory(str(path)))
            except OSError:
                # PATH still provides the compatibility fallback on old or
                # restricted Windows environments.
                continue


def _missing_runtime_requirements() -> list[str]:
    missing: list[str] = []
    for import_name, project_name in _REQUIRED_RUNTIME_IMPORTS:
        try:
            available = importlib.util.find_spec(import_name) is not None
        except (ImportError, AttributeError, ValueError):
            available = False
        if not available:
            missing.append(project_name)
    return missing


def main() -> int:
    """Start HERFY-TS from source or from the packaged runtime."""
    sys.dont_write_bytecode = True
    _prepare_packaged_qt_runtime()

    # Self-check must run inside the current executable.  It must not prepare or
    # relaunch the source runtime, otherwise the build can exit successfully
    # without creating HERFY_SELF_CHECK_FILE.
    if "--self-check" in sys.argv[1:]:
        from core.bootstrap import run_self_check

        return run_self_check()

    if "--windows-notification-check" in sys.argv[1:]:
        import json
        from pathlib import Path

        from infra.windows import (
            send_windows_toast,
            verify_windows_toast_registration,
            windows_notification_capability,
        )

        target = ""
        args = list(sys.argv[1:])
        for index, arg in enumerate(args):
            if arg == "--windows-notification-check-file" and index + 1 < len(args):
                target = str(args[index + 1]).strip().strip('"')
            elif arg.startswith("--windows-notification-check-file="):
                target = arg.split("=", 1)[1].strip().strip('"')
        registered = bool(verify_windows_toast_registration())
        capability = windows_notification_capability()
        # Always exercise the canonical backend chain. A failed WinRT shortcut
        # registration may use the optional legacy backend; the GUI owns the
        # final Qt tray fallback.
        from core.notifications import build_notification_activation_uri

        result = send_windows_toast(
            title="HERFY-TS",
            message="Windows notification delivery verification",
            activation_uri=build_notification_activation_uri({}),
        )
        payload = {
            "status": "ok" if bool(result and result.delivered) else "fail",
            "registered": registered,
            "capability": capability,
            "delivered": bool(result and result.delivered),
            "backend": str(getattr(result, "backend", "windows_notification")),
            "detail": str(getattr(result, "detail", "delivery_failed")),
        }
        if target:
            path = Path(target)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(
                json.dumps(payload, ensure_ascii=False, sort_keys=True), encoding="utf-8"
            )
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return 0 if payload["status"] == "ok" else 3

    missing = _missing_runtime_requirements()
    if missing:
        print(
            "HERFY-TS runtime requirements are missing. "
            f"Install requirements.txt first. Missing: {', '.join(missing)}",
            file=sys.stderr,
        )
        return 2

    # Configure the native Qt style once for the whole application before the
    # bootstrap creates the single QApplication instance.  Page widgets must
    # not override this through per-control style sheets.
    from PySide6.QtWidgets import QApplication

    QApplication.setStyle("Fusion")
    import infra.bootstrap  # noqa: F401 - installs Qt runtime safeguards after dependency check
    from core.bootstrap import build_application

    return int(build_application(sys.argv[1:]).run())


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (
        AttributeError,
        ImportError,
        ModuleNotFoundError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        try:
            from core.settings import (
                install_exception_hooks,
                setup_crash_logging,
            )

            setup_crash_logging()
            install_exception_hooks()
            sys.excepthook(*sys.exc_info())
        finally:
            raise SystemExit(1) from exc
