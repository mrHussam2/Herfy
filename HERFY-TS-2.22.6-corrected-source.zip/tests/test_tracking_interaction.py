from types import SimpleNamespace

from PySide6.QtCore import QDate, QTimer
from PySide6.QtWidgets import QCompleter, QLineEdit, QVBoxLayout, QWidget

from services.tracking import (
    TrackingBranchAccessService,
    TrackingService,
    build_tracking_completer_suggestions,
)
from ui.administration_components import SplitWorkspace
from ui.tracking import TrackingPage
from ui.tracking_data import TrackingDataControllerMixin
from ui.tracking_form_controller import TrackingFormControllerMixin
from ui.tracking_dialogs import EditTrackedProductDialog


class CatalogForm(QWidget):
    update_completer = TrackingPage.update_completer
    _on_product_entry_edited = TrackingPage._on_product_entry_edited
    _show_product_suggestions = TrackingPage._show_product_suggestions
    _on_product_suggestion_selected = TrackingPage._on_product_suggestion_selected

    def __init__(self):
        super().__init__()
        self.product_entry = QLineEdit(self)
        self.qty_entry = QLineEdit(self)
        layout = QVBoxLayout(self)
        layout.addWidget(self.product_entry)
        layout.addWidget(self.qty_entry)
        self._catalog_loading = False
        self._product_catalog_rows = []
        self.requests = []
        self._tracking_controller = SimpleNamespace(
            completer_suggestions=build_tracking_completer_suggestions
        )

    def _selected_create_branch(self):
        return "H1008"

    def load_product_catalog(self, *, force_network):
        self.requests.append(force_network)
        self._catalog_loading = True

    def _reconcile_visible_rows_with_catalog(self, rows):
        pass


def test_typing_while_catalog_loads_does_not_queue_duplicate_requests(qapp):
    form = CatalogForm()
    for text in ("", " ", "1", "10", "100"):
        form._on_product_entry_edited(text)
    assert form.requests == [True]
    form.close()


class TrackingSaveForm(TrackingFormControllerMixin, QWidget):
    """Small host proving that a catalogue refresh never blocks a save."""

    def __init__(self):
        super().__init__()
        self.product_entry = QLineEdit("1020000003 - ITALIAN DRESSING", self)
        self.qty_entry = QLineEdit("4", self)
        self.prod_edit = SimpleNamespace(date=lambda: QDate(2026, 10, 19))
        self.exp_edit = SimpleNamespace(date=lambda: QDate(2026, 10, 20))
        self._catalog_loading = True
        self._product_catalog_rows = []
        self.tracked_products = []
        self.requests = []
        self._tracking_controller = SimpleNamespace(
            prepare_create=lambda **_kwargs: (
                SimpleNamespace(material_number="1020000003", quantity=4),
                "",
            )
        )

    def _selected_create_branch(self):
        return "H1004"

    def _run_tracking_action(self, **kwargs):
        self.requests.append(kwargs)


def test_tracking_save_starts_while_catalog_refreshes(qapp):
    form = TrackingSaveForm()
    form.add_product()
    assert len(form.requests) == 1
    request = form.requests[0]
    assert request["label"] == "Saving..."
    assert request["worker_fn"] is not None
    form.close()


def test_tracking_edit_dialog_loads_designer_fields_and_returns_mutable_values(qapp):
    dialog = EditTrackedProductDialog(
        {
            "branch": "H1008",
            "material_number": "1020000003",
            "name": "ITALIAN DRESSING",
            "quantity": 4,
            "production_date": "2026-10-19",
            "expiry_date": "2026-10-20",
        }
    )
    dialog.findChild(QLineEdit, "tracking_edit_quantity").setText("7")
    values = dialog.values()
    assert values == {
        "quantity_text": "7",
        "production_date": "2026-10-19",
        "expiry_date": "2026-10-20",
    }
    dialog.close()


def test_catalog_refresh_reuses_completer_and_updates_number_and_name_matches(qapp):
    form = CatalogForm()
    form.update_completer([{"material_number": "100", "name": "Chicken"}])
    completer = form.product_entry.completer()
    for _ in range(10):
        form.update_completer([{"material_number": "200", "name": "Beef Burger"}])
    assert form.product_entry.completer() is completer
    assert len(form.product_entry.findChildren(QCompleter)) == 1
    for prefix in ("200", "bUrGeR"):
        completer.setCompletionPrefix(prefix)
        assert completer.completionCount() == 1
        assert "Beef Burger" in completer.currentCompletion()
    completer.setCompletionPrefix("Chicken")
    assert completer.completionCount() == 0
    form.close()


def test_server_catalog_delta_refreshes_suggestions_without_dropping_tracking_delta(qapp):
    class RefreshHarness(TrackingDataControllerMixin, QWidget):
        def __init__(self):
            super().__init__()
            self._suppress_state_refresh_until = 0.0
            self._state_refresh_timer = QTimer(self)
            self._state_refresh_timer.setSingleShot(True)
            self.catalog_requests = []

        def _is_alive(self):
            return True

        def load_product_catalog(self, *, force_network):
            self.catalog_requests.append(bool(force_network))

    form = RefreshHarness()
    form.show()
    qapp.processEvents()
    form._on_app_state_tracking_changed(
        "tracking",
        {
            "stored_catalog_delta": {"applied": True, "count": 1},
            "tracking_delta": {"applied": True, "count": 1},
        },
    )
    assert form.catalog_requests == [False]
    assert form._state_refresh_timer.isActive()
    form.close()


def test_deferred_suggestions_do_not_open_after_page_is_hidden(qapp):
    form = CatalogForm()
    form.update_completer([{"material_number": "100", "name": "Chicken"}])
    form.product_entry.setText("100")
    form._show_product_suggestions()
    assert not form.product_entry.completer().popup().isVisible()
    form.close()


def test_admin_panes_keep_user_split_and_allow_access_to_narrow_content(qapp):
    workspace = SplitWorkspace(QWidget(), QWidget())
    workspace.resize(1100, 600)
    workspace.show()
    qapp.processEvents()
    workspace.set_compact(False)
    workspace.splitter.setSizes([700, 380])
    before = workspace.splitter.sizes()
    workspace.set_compact(False)
    assert workspace.splitter.sizes() == before
    workspace.resize(520, 600)
    qapp.processEvents()
    assert workspace.collection_host.horizontalScrollBar().maximum() > 0
    workspace.close()


class _BranchPermissionContext:
    def __init__(self, branches, writable, editable=None, deletable=None):
        self.api_client = object()
        self._branches = list(branches)
        self._writable = {str(branch).casefold() for branch in writable}
        self._editable = {
            str(branch).casefold() for branch in (editable if editable is not None else writable)
        }
        self._deletable = {
            str(branch).casefold() for branch in (deletable if deletable is not None else writable)
        }

    def allowed_branches(self):
        return list(self._branches)

    def can_create_tracking(self, branch):
        return str(branch or "").casefold() in self._writable

    def can_update_tracking(self, branch):
        return str(branch or "").casefold() in self._editable

    def can_delete_tracking(self, branch):
        return str(branch or "").casefold() in self._deletable

    def can_view_all_branches(self):
        return False


def test_tracking_branch_options_are_deduplicated_and_scope_limited():
    access = TrackingBranchAccessService(
        _BranchPermissionContext(["H1008", "h1008", "H1019"], ["H1008"])
    )
    assert access.writable_branches() == ["H1008"]
    # Input is canonicalised before it reaches the mutation API.  This avoids
    # a false rejection when server branch identifiers use a different case.
    assert access.resolve_writable_branch("h1008") == "H1008"
    assert access.resolve_writable_branch("H1019") == ""


def test_tracking_create_requires_a_branch_before_calling_the_api():
    access = TrackingBranchAccessService(_BranchPermissionContext(["H1008"], ["H1008"]))
    assert "Choose an authorized branch" in access.validate_action("", action="create")
    assert access.validate_action("H1008", action="create") == ""


def test_tracking_row_actions_are_limited_to_each_authorized_branch():
    access = TrackingBranchAccessService(
        _BranchPermissionContext(["H1004", "H1008"], ["H1004", "H1008"], ["H1004"], ["H1008"])
    )
    assert access.validate_action("H1004", action="update") == ""
    assert "permission" in access.validate_action("H1008", action="update").lower()
    assert access.validate_action("H1008", action="delete") == ""
    assert "permission" in access.validate_action("H1004", action="delete").lower()


class _SavedCatalog:
    def __init__(self):
        self.refresh_calls = 0

    def list_local(self):
        return [{"material_number": "1020000003", "name": "ITALIAN DRESSING"}]

    def refresh_from_server(self):
        self.refresh_calls += 1
        raise AssertionError("A selected local catalogue product must not refresh before save")


class _TrackingMutationApi:
    def __init__(self):
        self.created = []

    def add_item(self, **payload):
        self.created.append(dict(payload))
        return {"id": "tracking-1", "doc_id": "tracking-1", "revision": 1, **payload}


class _TrackingMutationRepository:
    def __init__(self):
        self.rows = []

    def upsert_cached_cloud_tracking_product(self, row):
        self.rows = [dict(row)]

    def fetch_cached_tracked_products(self):
        return list(self.rows)


class _TrackingMutationContext(_BranchPermissionContext):
    def __init__(self, api):
        super().__init__(["H1004"], ["H1004"])
        self.api_client = api


def test_tracking_create_uses_selected_local_catalog_before_network_refresh():
    api = _TrackingMutationApi()
    catalog = _SavedCatalog()
    service = TrackingService(
        _TrackingMutationRepository(), _TrackingMutationContext(api), object(), catalog
    )

    result = service.create_or_merge_item(
        material_number="1020000003 - ITALIAN DRESSING",
        quantity=4,
        production_date="2026-10-19",
        expiry_date="2026-10-20",
        branch="H1004",
        current_rows=[],
    )

    assert result[0] is True
    assert catalog.refresh_calls == 0
    assert api.created == [
        {
            "branch": "H1004",
            "material_number": "1020000003",
            "material_name": "ITALIAN DRESSING",
            "quantity": 4,
            "production_date": "2026-10-19",
            "expiry_date": "2026-10-20",
        }
    ]
