import threading
import time
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QProgressBar, QVBoxLayout, QWidget

from core.app_state import AppState
from core.state import SyncState
from services.monitoring_coordinator import MonitoringCoordinator
from services.updates import download_response_to_target
from ui.app_updates import UpdateDialog, UpdateState
from ui.main_window_cloud import CloudSnapshotControllerMixin
from ui.main_window_shell import MainWindowShellLayoutMixin
from ui.runtime import WorkerRegistry


def test_visibility_transition_keeps_monitoring_timer_and_evaluation(qapp):
    coordinator = MonitoringCoordinator(
        Mock(), start_worker=Mock(), publish_events=Mock(), reconcile_delivery=Mock()
    )
    coordinator._active = True
    coordinator._generation = 7
    coordinator._evaluating = True
    coordinator._timer.start(30000)
    token = coordinator._evaluation_token
    coordinator.ensure_started(7)
    assert coordinator._active and coordinator._evaluating
    assert coordinator._timer.isActive()
    assert coordinator._evaluation_token == token
    coordinator.shutdown()


def test_workspace_viewport_preserves_the_desktop_canvas(qapp):
    class Shell(MainWindowShellLayoutMixin, QWidget):
        pass

    shell = Shell()
    shell._build_content_shell(QVBoxLayout(shell))
    shell.resize(1500, 800)
    shell.show()
    qapp.processEvents()
    shell.resize(600, 400)
    qapp.processEvents()
    assert shell.width() == 600
    assert shell.content_stack.width() >= 1100
    assert shell.workspace_viewport.horizontalScrollBarPolicy() == Qt.ScrollBarAlwaysOff
    assert shell.workspace_viewport.verticalScrollBarPolicy() == Qt.ScrollBarAlwaysOff
    shell.close()


@pytest.mark.parametrize("state", [UpdateState.DOWNLOADING, UpdateState.VERIFYING, UpdateState.HANDOFF_TO_INSTALLER])
def test_closing_update_presentation_does_not_cancel_worker(qapp, state):
    workers = Mock()
    dialog = UpdateDialog(Mock(), "2.21.17", workers)
    dialog.set_state(state)
    dialog.show()
    dialog.close()
    assert not dialog.isVisible()
    workers.close.assert_not_called()
    assert not dialog._closed
    dialog.show()
    dialog.reject()
    workers.close.assert_not_called()
    assert not dialog.isVisible()
    dialog.set_state(UpdateState.UP_TO_DATE)
    dialog.close()


def test_cancelled_download_cleans_partial_and_preserves_target(tmp_path):
    response = SimpleNamespace(headers={}, iter_content=lambda **kwargs: iter([b"abc"]), close=Mock())
    target = tmp_path / "setup.exe"
    with pytest.raises(RuntimeError, match="cancelled"):
        download_response_to_target(
            response=response, target=target, temp_dir=tmp_path, temp_prefix="update-",
            expected_sha="", expected_size=0, progress_callback=None,
            package_label="installer", chunk_size=1024, cancel_callback=lambda: True,
        )
    response.close.assert_called_once()
    assert not target.exists()
    assert not list(tmp_path.glob("*.part"))


def test_worker_runs_off_gui_and_delivers_on_gui_without_duplicate_job(qapp):
    registry = WorkerRegistry()
    release = threading.Event()
    entered = threading.Event()
    gui_thread = threading.get_ident()
    result_threads = []

    def work():
        assert threading.get_ident() != gui_thread
        entered.set()
        assert release.wait(3)
        return True

    try:
        worker = registry.start(work, on_result=lambda value: result_threads.append(threading.get_ident()), operation_key="tracking:action")
        assert worker is not None
        assert entered.wait(1)
        assert registry.start(work, operation_key="tracking:action") is None
        # Qt remains available while the worker is waiting for I/O.
        widget = QWidget()
        widget.show()
        qapp.processEvents()
        assert widget.isVisible()
        release.set()
        deadline = time.monotonic() + 3
        while (not result_threads or registry.has_active_key("tracking:action")) and time.monotonic() < deadline:
            qapp.processEvents()
            time.sleep(0.005)
        assert result_threads == [gui_thread]
        assert not registry.has_active_key("tracking:action")
        widget.close()
    finally:
        release.set()
        registry.close()


def test_background_sync_feedback_is_non_blocking_and_recovers_after_retry(qapp):
    class SyncHarness(CloudSnapshotControllerMixin):
        def __init__(self):
            self.app_state = AppState()
            self.transition_progress = QProgressBar()
            self._ui_transition_depth = 0
            self.messages = []

        def _show_runtime_status_message(self, message, timeout_ms=0):
            self.messages.append((message, timeout_ms))

    harness = SyncHarness()
    harness._set_automatic_sync_feedback("starting", operation_key="cloud_snapshot:pull")
    assert harness.app_state.sync_state is SyncState.SYNCING
    assert harness.transition_progress.value() == 12
    assert harness.transition_progress.isVisible()

    harness._set_automatic_sync_feedback("error", operation_key="cloud_snapshot:pull")
    assert harness.app_state.sync_state is SyncState.ERROR
    assert harness.messages[-1][1] == 5000
    harness._set_automatic_sync_feedback("complete", operation_key="cloud_snapshot:pull")
    assert harness.app_state.sync_state is SyncState.ERROR
    assert "retry" in harness.app_state.sync_message.lower()

    # A scheduled retry starts a new truthful cycle and clears stale failure UI.
    harness._set_automatic_sync_feedback("receiving", operation_key="cloud_snapshot:pull")
    assert harness.app_state.sync_state is SyncState.SYNCING
    assert harness.transition_progress.value() == 42

    harness._set_automatic_sync_feedback("complete", operation_key="cloud_snapshot:pull")
    assert harness.app_state.sync_state is SyncState.IDLE
    assert not harness.transition_progress.isVisible()


def test_idle_automatic_reconciliation_is_quiet_until_a_server_change_arrives(qapp):
    class SyncHarness(CloudSnapshotControllerMixin):
        def __init__(self):
            self.app_state = AppState()
            self.transition_progress = QProgressBar()
            self._ui_transition_depth = 0
            self.messages = []

        def _show_runtime_status_message(self, message, timeout_ms=0):
            self.messages.append((message, timeout_ms))

    harness = SyncHarness()
    operation_key = "cloud_snapshot:pull"
    harness._set_automatic_sync_feedback("starting", operation_key=operation_key, present=False)
    harness._set_automatic_sync_feedback("receiving", operation_key=operation_key, present=False)
    harness._set_automatic_sync_feedback("complete", operation_key=operation_key, present=False)
    assert harness.app_state.sync_state is SyncState.IDLE
    assert not harness.transition_progress.isVisible()
    assert not harness.messages

    # Once the payload contains a durable change, the same background worker
    # becomes visible without stealing focus or blocking the current page.
    harness._set_automatic_sync_feedback("starting", operation_key=operation_key, present=False)
    harness._set_automatic_sync_feedback("applying", operation_key=operation_key, present=True)
    assert harness.app_state.sync_state is SyncState.SYNCING
    assert harness.transition_progress.isVisible()
    assert harness.messages[-1][0]
