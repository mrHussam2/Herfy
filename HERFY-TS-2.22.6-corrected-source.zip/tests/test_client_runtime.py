from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from core.state import AuthSession, UserProfile, normalize_branch_list
from infra.realtime import RemoteRealtimeMixin
from services.auth import AuthenticationService, SessionPersistenceService, SessionRuntimeService
from services.settings_schema import canonical_sound_filename, validate_canonical_settings
from services.sync import RealtimePullScheduler
from ui.runtime import WorkerRegistry


class _Store:
    def __init__(self) -> None:
        self.saved: dict[str, object] | None = None
        self.cleared = False
        self.login_form: dict[str, object] | None = None

    def save(self, **kwargs) -> None:
        self.saved = kwargs

    def clear(self) -> None:
        self.cleared = True

    def load_snapshot(self):
        return None

    def save_login_form_state(self, **kwargs) -> None:
        self.login_form = kwargs

    def load_login_form_state(self):
        return self.login_form


def test_branch_scope_normalization_preserves_first_authorized_value() -> None:
    assert normalize_branch_list([" 18016 ", "18016", "", "North", "north"]) == [
        "18016",
        "North",
    ]


def test_session_persistence_supports_remembered_login_and_logout() -> None:
    store = _Store()
    persistence = SessionPersistenceService(store)
    persistence.save_login_form_state(username=" 18016 ", remember=True)
    persistence.save_session(session="session", profile="profile", remember=True, saved_at=-1)
    persistence.clear_session()

    assert store.login_form == {"username": "18016", "remember": True}
    assert store.saved == {
        "session": "session",
        "profile": "profile",
        "remember": True,
        "saved_at": 0,
    }
    assert store.cleared is True


def test_authentication_service_returns_the_authoritative_profile(monkeypatch) -> None:
    session = AuthSession(id_token="test-token", user_id="18016", role="system")
    profile = UserProfile(user_id="18016", username="18016", display_name="System", role="system")
    monkeypatch.setattr("services.auth.sign_in_with_identifier_password", lambda *_: session)
    monkeypatch.setattr("services.auth.load_user_profile_from_session", lambda _: profile)

    result_session, result_profile = AuthenticationService.sign_in("18016", "not-a-real-password")

    assert result_session is session
    assert result_profile is profile


def test_session_restore_without_candidate_never_calls_the_network() -> None:
    @dataclass
    class _Auth:
        called: bool = False

        def restore_candidate(self, _snapshot):
            return None

        def refresh(self, _token):
            self.called = True
            raise AssertionError("refresh must not run without a candidate")

    class _Cloud:
        def temporary_pull(self, **_kwargs):
            raise AssertionError("pull must not run without a session")

    auth = _Auth()
    runtime = SessionRuntimeService(SessionPersistenceService(_Store()), auth, _Cloud())

    assert runtime.restore_remembered_session() == {"noop": True}
    assert auth.called is False


def test_settings_normalization_and_realtime_reconnect_are_bounded() -> None:
    result = validate_canonical_settings(
        {"language": "AR", "enable_sounds": False, "notification_sound_near": "expires_tomorrow.wav"}
    )
    realtime = RemoteRealtimeMixin()

    assert result.ok
    assert result.values["language"] == "ar"
    assert result.values["enable_sounds"] == "False"
    assert result.values["notification_sound_near"] == "expiry_near.wav"
    assert canonical_sound_filename("expiry_approaching.wav", "default.wav") == "expiry_near.wav"
    assert 1.0 <= realtime._next_reconnect_delay(0) <= 1.2
    assert 30.0 == realtime._next_reconnect_delay(99)


def test_realtime_cursor_parser_rejects_malformed_event_data() -> None:
    assert RemoteRealtimeMixin._cursor_from_realtime_payload('{"event_id": 42}') == 42
    assert RemoteRealtimeMixin._cursor_from_realtime_payload("not-json") == 0
    assert RemoteRealtimeMixin._cursor_from_realtime_payload("[42]") == 0


def test_realtime_changes_are_debounced_then_replayed_without_manual_refresh() -> None:
    scheduler = RealtimePullScheduler(min_gap_ms=450)
    initial = scheduler.offer(
        "realtime", now_ms=1_000, requested_delay_ms=120, timer_active=False, timer_remaining_ms=-1
    )
    assert initial.schedule is True
    assert initial.delay_ms == 120
    assert scheduler.begin(1_120) is True

    during_pull = scheduler.offer(
        "admin", now_ms=1_130, requested_delay_ms=120, timer_active=False, timer_remaining_ms=-1
    )
    assert during_pull.schedule is False
    assert scheduler.finish() is True


def test_realtime_reconnect_restores_cursor_and_retries_incomplete_pull_automatically() -> None:
    sync_source = (Path(__file__).resolve().parents[1] / "services" / "sync.py").read_text(
        encoding="utf-8"
    )
    cloud_source = (
        Path(__file__).resolve().parents[1] / "ui" / "main_window_cloud.py"
    ).read_text(encoding="utf-8")

    assert "self.restore_cursor()" in sync_source
    assert '"realtime_retry", delay_ms=5_000' in cloud_source
    assert "SYNC_AUTOMATIC_PULL=PASS" in cloud_source


def test_packaged_runtime_prepares_qt_dlls_before_pyside_import() -> None:
    source = (Path(__file__).resolve().parents[1] / "main.py").read_text(encoding="utf-8")

    assert "def _prepare_packaged_qt_runtime" in source
    assert "_prepare_packaged_qt_runtime()" in source
    assert source.index("    _prepare_packaged_qt_runtime()") < source.index(
        "from PySide6.QtWidgets import QApplication"
    )


def test_worker_pool_prioritizes_operator_actions_over_background_maintenance() -> None:
    assert WorkerRegistry._operation_priority("tracking:action") > 0
    assert WorkerRegistry._operation_priority("administration:save-user") > 0
    assert WorkerRegistry._operation_priority("monitoring:schedule-prepare") < 0
    assert WorkerRegistry._operation_priority("cloud_snapshot:pull") < 0
    assert WorkerRegistry._operation_priority("unclassified-work") == 0

    source = (Path(__file__).resolve().parents[1] / "ui" / "runtime.py").read_text(
        encoding="utf-8"
    )
    assert "_WORKER_PROGRESS_INTERVAL_SECONDS = 0.15" in source
    assert "max_threads = max(2, min(4, max(2, cpu_count - 1)))" in source
