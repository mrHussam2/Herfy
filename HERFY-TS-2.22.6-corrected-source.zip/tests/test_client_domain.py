from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from core.models import ExpiryStatusKind, business_timezone, classify_expiry_days
from services.kpi_totals import sum_report_net_totals
from services.kpi_analytics import (
    ChannelMetric,
    DashboardSnapshot,
    MonthlySales,
    export_interactive_dashboard,
)
from services.monitoring_engine import MonitoringEngine
from services.notifications import NotificationEngine, reminder_interval_seconds
from services.tracking import resolve_tracking_catalog_selection


def test_kpi_total_requires_a_real_selected_year() -> None:
    assert sum_report_net_totals(object(), ["H1004"], None) is None


def test_offline_error_boundary_is_explicit() -> None:
    from core.errors import RemoteRequestError

    error = RemoteRequestError("offline")
    assert "offline" in str(error).lower()


def test_expiry_monitoring_is_continuous_in_the_early_morning_window() -> None:
    before_opening = datetime(2026, 10, 18, 6, 30, tzinfo=business_timezone())

    assert MonitoringEngine.is_monitoring_allowed(before_opening) is True


def test_tracking_catalog_resolves_exact_code_and_unique_name() -> None:
    catalog = [
        {"material_number": "100", "name": "Chicken Burger"},
        {"material_number": "200", "name": "Beef Burger"},
    ]

    assert resolve_tracking_catalog_selection("100 - Chicken Burger", catalog).as_dict() == {
        "material_number": "100",
        "name": "Chicken Burger",
    }
    assert resolve_tracking_catalog_selection("Beef Burger", catalog).as_dict() == {
        "material_number": "200",
        "name": "Beef Burger",
    }


def test_expired_product_is_a_critical_monitored_alert() -> None:
    result = classify_expiry_days(-1)

    assert result.kind is ExpiryStatusKind.EXPIRED
    assert result.should_notify_default is True
    assert result.notification_priority == "urgent"
    assert NotificationEngine.is_notifiable_status({"status_kind": "expired"}) is True
    assert reminder_interval_seconds("expired") == 4 * 60 * 60


def test_interactive_kpi_export_is_a_self_contained_html_file(tmp_path) -> None:
    snapshot = DashboardSnapshot(
        branch="H1004",
        current_year=2026,
        compare_year=2025,
        channels=(ChannelMetric("Dine-in", Decimal("1250.50"), Decimal("1000"), 12, 10),),
        report_total=ChannelMetric(
            "Total Net sale & GCs", Decimal("1250.50"), Decimal("1000"), 12, 10
        ),
        monthly_sales=(MonthlySales(1, Decimal("1250.50"), Decimal("1000")),),
    )

    output = export_interactive_dashboard(snapshot, tmp_path / "dashboard")

    assert output.suffix == ".html"
    content = output.read_text(encoding="utf-8")
    assert "HERFY Sales KPI" in content
    assert "plotly.js" in content
