from __future__ import annotations

from types import SimpleNamespace

from services import updates
from ui.administration_controller import AdministrationController, AdministrationPresenter


def test_administration_capabilities_accept_only_allowed_map_entries() -> None:
    snapshot = {"allowed_actions": {"users.view": True, "users.edit": False}}
    assert AdministrationPresenter.capabilities(snapshot) == {"users.view"}


def test_administration_capabilities_reject_legacy_list_shape() -> None:
    assert AdministrationPresenter.capabilities({"allowed_actions": ["users.view"]}) == set()


def test_administration_modules_require_recognized_permissions() -> None:
    snapshot = {
        "available_modules": ["users", "permissions"],
        "allowed_actions": {"users.view": True, "permissions.view": False},
    }
    assert AdministrationPresenter.modules(snapshot) == ["overview", "employees", "branch_accounts"]


def test_public_policy_validates_contract_and_optional_floor(monkeypatch) -> None:
    class Response:
        def json(self):
            return {
                "server_version": "2.21.12",
                "latest_client_version": "2.21.12",
                "minimum_supported_client_version": "2.21.12",
                "api_contract_sha256": "a" * 64,
            }

        def close(self):
            return None

    monkeypatch.setattr(
        updates,
        "get_server_binding",
        lambda: SimpleNamespace(api_base_url="https://api.example.test", api_contract_sha256="a" * 64),
    )
    monkeypatch.setattr(updates, "api_request", lambda *_args, **_kwargs: Response())
    assert updates._fetch_public_client_policy() == ("2.21.12", "2.21.12")


def test_external_admin_change_replaces_same_revision_projection() -> None:
    class Workers:
        def close(self):
            return None

        def has_active_key(self, _key):
            return False

    controller = AdministrationController(SimpleNamespace(), worker_registry=Workers())
    controller.state.snapshot = {
        "authority_revision": 4,
        "users": [{"user_id": "stale"}],
    }
    controller._external_projection_refresh = True

    controller._apply_bootstrap(
        {
            "authority_revision": 4,
            "available_modules": ["users"],
            "allowed_actions": {},
            "users": [{"user_id": "fresh"}],
        }
    )

    assert controller.state.snapshot["users"] == [{"user_id": "fresh"}]
    assert controller._external_projection_refresh is False
