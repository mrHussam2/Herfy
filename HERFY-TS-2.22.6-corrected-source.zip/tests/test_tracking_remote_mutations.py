from __future__ import annotations

from infra.api import RemoteTrackingItemsMixin, RemoteTrackingMetadataMixin


class _MutationClient(RemoteTrackingMetadataMixin, RemoteTrackingItemsMixin):
    """Minimal remote client proving tracking permissions reach sync/push."""

    def __init__(self):
        self.user = {
            "permission_source": "postgresql.role_permissions",
            "permissions": ["tracking.create"],
            "scope": {"all_branches": False, "branches": ["H1004"]},
        }
        self.request = None

    def _req(self, method, route, **kwargs):
        self.request = (method, route, kwargs)
        return object()

    def _safe_json(self, _response):
        operation = self.request[2]["json"]["operations"][0]
        item = dict(operation["item"])
        item.pop("base_revision", None)
        item.update(
            {
                "revision": 1,
                "created_at": None,
                "updated_at": None,
                "deleted_at": None,
                "deleted_by": None,
                "created_by": "actor",
                "updated_by": "actor",
            }
        )
        return {
            "ok": True,
            "operation_id": self.request[2]["json"]["operation_id"],
            "accepted": [{"operation": operation["operation"], "item": item}],
            "conflicts": [],
            "rejected": [],
            "server_cursor": 1,
            "server_time": "2026-10-22T00:00:00+00:00",
        }

    def invalidate_tracking_cache(self, _branch):
        pass


def test_tracking_create_uses_authenticated_sync_transport_without_sync_push_permission():
    client = _MutationClient()

    item = client.add_item(
        branch="H1004",
        material_number="1020000003",
        material_name="ITALIAN DRESSING",
        quantity=4,
        production_date="2026-10-19",
        expiry_date="2026-10-20",
    )

    assert item["doc_id"]
    assert client.request[0:2] == ("POST", "/sync/push")


def test_tracking_create_defers_branch_authorization_to_the_server_transaction():
    client = _MutationClient()
    # A cached client authority can lag a server-side branch assignment.  The
    # mutation must still reach /sync/push, where the database transaction
    # authorizes the destination branch authoritatively.
    client.user["scope"]["branches"] = []

    client.add_item(
        branch="H1004",
        material_number="1020000003",
        material_name="ITALIAN DRESSING",
        quantity=1,
        production_date="2026-10-19",
        expiry_date="2026-10-20",
    )

    assert client.request[0:2] == ("POST", "/sync/push")
