"""Focused core regressions runnable without the Windows/Qt UI environment.

Use ``pytest --noconftest tests/test_portable_regression.py`` in a headless
workspace. GUI acceptance still requires PySide6 and Windows device testing.
"""

from __future__ import annotations

import hashlib
import threading
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace
from xml.etree import ElementTree

from core.presentation import HomeDashboardService
from infra.realtime import CoalescedCursorSignal, RemoteRealtimeMixin
from infra.windows import _toast_script
from services.kpi_analytics import (
    ChannelMetric,
    DashboardSnapshot,
    MonthlySales,
    export_interactive_dashboard,
)
from services.updates import download_response_to_target


ROOT = Path(__file__).resolve().parents[1]


def test_home_tracking_counts_respect_branch_scope_even_for_unlabeled_rows():
    class Runtime:
        def cached_tracking_rows(self, branch_hint):
            assert branch_hint == 'all'
            return [
                {'branch': 'H1004', 'expiry_date': '2026-11-01'},
                {'branch': 'H1008', 'expiry_date': '2026-11-01'},
                {'branch': '', 'expiry_date': '2026-11-01'},
            ]

    service = HomeDashboardService(Runtime())
    limited = SimpleNamespace(scope=SimpleNamespace(all_branches=False), active_branch='')
    assert len(service._safe_fetch_tracking_rows(limited, ['H1004', 'H1019'])) == 1
    assert service._safe_fetch_tracking_rows(limited, []) == []


def test_offline_plotly_export_has_no_monthly_trend_and_preserves_signed_difference(tmp_path):
    channels = (
        ChannelMetric('Dine-in', Decimal('1200.25'), Decimal('1000.25'), 30, 29),
        ChannelMetric('Drive-Thru', Decimal('200.50'), Decimal('300.50'), 8, 10),
    )
    snapshot = DashboardSnapshot(
        branch='H1004', current_year=2026, compare_year=2025,
        channels=channels, report_total=channels[0],
        monthly_sales=(MonthlySales(1, Decimal('100'), Decimal('200')),),
    )
    html = export_interactive_dashboard(snapshot, tmp_path / 'verified_dashboard').read_text('utf-8')
    assert 'plotly.js' in html
    assert 'Monthly net sales' not in html
    assert 'Absolute change (SAR)' in html
    assert 'Sales by year (SAR)' in html
    assert 'H1004' in html
    assert channels[0].sales_difference == Decimal('200.00')
    assert channels[1].sales_difference == Decimal('-100.00')


def test_sse_events_keep_latest_id_and_ignore_keepalive():
    class FakeResponse:
        def iter_lines(self, **kwargs):
            yield from [
                ': heartbeat', 'id: 27', 'event: changed', 'data: {"cursor": 27}', '',
                'id: 28', 'event: changed', 'data: {"cursor":28}',
            ]

    events = list(RemoteRealtimeMixin()._iter_sse_events(FakeResponse(), threading.Event()))
    assert events == [
        ('changed', '{"cursor": 27}', '27'),
        ('changed', '{"cursor":28}', '28'),
    ]


def test_cursor_signal_deduplicates_and_keeps_monotonic_order():
    signal = CoalescedCursorSignal(min_interval_seconds=0)
    seen = []
    signal.connect(seen.append)
    for cursor in (2, 2, 1, 4, 3, 8):
        signal.emit(cursor)
    assert seen == [2, 4, 8]
    signal.cancel_pending(reset_delivery=True)


def test_winrt_fallback_toast_has_no_duplicate_system_sound():
    script = _toast_script(title='Test', message='A&B', app_id='HERFY-TS')
    assert '<audio silent="true" />' in script
    assert 'ms-winsoundevent:Notification.Default' not in script
    assert 'A&amp;B' in script


def test_unknown_size_download_never_emits_invented_percentage(tmp_path):
    payload = b'test-package-payload'

    class FakeResponse:
        headers = {}
        closed = False

        def iter_content(self, chunk_size):
            assert chunk_size >= 1
            yield payload[:8]
            yield payload[8:]

        def close(self):
            self.closed = True

    source = FakeResponse()
    progress = []
    dest = tmp_path / 'installer.exe'
    result = download_response_to_target(
        response=source, target=dest, temp_dir=tmp_path,
        temp_prefix='download_', expected_sha=hashlib.sha256(payload).hexdigest(),
        expected_size=0, progress_callback=progress.append,
        package_label='test installer', chunk_size=1024,
    )
    assert result.read_bytes() == payload
    assert source.closed
    assert progress
    assert all(p['percent'] is None for p in progress)
    assert progress[-1]['stage'] == 'verifying'


def test_qt_designer_home_is_valid_and_keeps_all_runtime_object_names():
    tree = ElementTree.parse(ROOT / 'resources/ui/dashboard_page.ui')
    names = [w.get('name') for w in tree.iter('widget')]
    for key in (
        'HomeWelcomeTitle', 'HomeProductIntro', 'dashboard_stats_host',
        'dashboard_track_action', 'dashboard_usage_action', 'ContentHost',
    ):
        assert names.count(key) == 1
    assert not tree.findall('.//property[@name="geometry"]')
