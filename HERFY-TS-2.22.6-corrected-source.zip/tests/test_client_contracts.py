from __future__ import annotations

import json
from pathlib import Path
from xml.etree import ElementTree

from services.updates import compare_versions, should_update

ROOT = Path(__file__).resolve().parents[1]


def test_version_identity_is_consistent() -> None:
    version = json.loads((ROOT / "version.json").read_text(encoding="utf-8"))
    contract = json.loads((ROOT / "contracts" / "version.json").read_text(encoding="utf-8"))
    # The client release number is carried by the version contract.  The test
    # guards consistency between the three release identities rather than
    # pinning an obsolete build number after every production release.
    assert version["version"] == contract["client_version"] == contract["published_version"]


def test_update_version_comparison_prevents_downgrade() -> None:
    assert should_update("2.21.15", "2.21.16")
    assert not should_update("2.21.16", "2.21.16")
    assert not should_update("2.21.16", "2.21.15")
    assert compare_versions("2.21.16", "2.21.15") > 0


def test_update_contract_has_pinned_public_key() -> None:
    update = json.loads((ROOT / "contracts" / "update.json").read_text(encoding="utf-8"))
    assert update["manifest_url"].startswith("https://updates.herfy.online/")
    assert len(update["public_key_pem_sha256"]) == 64


def test_remote_update_keeps_progress_in_herfy_and_hides_installer_wizard() -> None:
    """Automatic updates must not fall back to the legacy Inno progress UI."""
    update_service = (ROOT / "services" / "updates.py").read_text(encoding="utf-8")
    update_dialog = (ROOT / "ui" / "app_updates.py").read_text(encoding="utf-8")
    logo_progress = (ROOT / "ui" / "logo_progress.py").read_text(encoding="utf-8")

    assert '"/VERYSILENT"' in update_service
    assert '"/SP-"' in update_service
    assert "show_window=False" in update_service
    assert '"/SILENT"' not in update_service
    assert "UpdateProgressBar" in update_dialog
    assert 'f"{int(round(self._progress))}%"' not in logo_progress


def test_workspace_designer_forms_are_valid_xml() -> None:
    names = ("tracking_page.ui", "usage_page.ui", "kpi_page.ui", "administration_page.ui")
    for name in names:
        root = ElementTree.parse(ROOT / "resources" / "ui" / name).getroot()
        assert root.tag == "ui"


def test_workspace_forms_keep_expanding_content_hosts() -> None:
    tracking = (ROOT / "resources" / "ui" / "tracking_page.ui").read_text(encoding="utf-8")
    usage = (ROOT / "resources" / "ui" / "usage_page.ui").read_text(encoding="utf-8")
    assert "TrackingProductsTable" in tracking and "tracking_table_host_layout" in tracking
    assert "UsageTable" in usage and "usage_table_host_layout" in usage
    assert "TrackingFormHeading" not in tracking
    assert "Add item to monitoring" not in tracking
    assert tracking.count("<property name=\"calendarPopup\">") == 2
    assert tracking.count("QAbstractSpinBox::NoButtons") == 2
