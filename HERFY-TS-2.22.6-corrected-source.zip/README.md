# HERFY-TS Developer Source

HERFY-TS is the Windows desktop client for food-safety tracking, expiry monitoring,
usage analysis, administration, notifications, and server-backed synchronization.

## Source layout

- `main.py` is the source entry point.
- `core/` contains shared models, permissions, runtime ports, settings, state, and presentation rules.
- `services/` contains application services and runtime orchestration.
- `infra/` contains HTTP, local persistence, Excel, Windows, realtime, update, and device adapters.
- `ui/` contains PySide6 presentation/controller code.
- `resources/ui/` contains the Qt Designer `.ui` sources loaded at runtime; no generated Python form classes are used.
- `resources/style.qss` is the single packaged QSS stylesheet applied through the central theme layer.
- `resources/images/`, `resources/sounds/`, and `resources/i18n/` contain packaged assets and translations.
- `contracts/` contains the client contract bindings and contract data used by the current runtime.
- `tests/` contains regression and source/UI contract tests.
- `ops/audit.py` contains the source/release quality gates.
- `ops/packaging/` contains the current PyInstaller and installer inputs.
- `ops/build.ps1`, `ops/release.ps1`, and `ops/publish.ps1` are the Windows build/release boundaries.

## Runtime rules

All packaged resource access must go through `core.settings.bundled_or_source_path()`
or `resource_path()`. These helpers resolve source and frozen paths without relying on
the current working directory.

`ui.runtime.AppState` is the Qt-facing runtime state object. Session, user, permissions,
branch, connection, synchronization, update, notification, and data-change signals are
centralized there. UI pages must use the composed runtime/services instead of creating
independent HTTP clients or transport polling loops.

Qt Designer forms are loaded through `ui.designer.load_ui()`. Required `objectName`
contracts must remain synchronized with their Python consumer. See `resources/ui/README.md`
for the editing rules that apply to Designer files.

Closing the main window with the native `X` routes the running application to its
single tray/background runtime. Explicit Exit performs the full lifecycle shutdown.
Starting the application again activates the existing instance instead of creating a
second independent runtime.

## Local verification

The current Windows build script resolves Python 3.11 x64. The source also remains
parse-compatible with Python 3.11 while the configured static-analysis targets are
kept in `pyproject.toml`.

Before source verification, prevent Python from leaving cache files in the canonical
source tree:

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:QT_QPA_PLATFORM = 'offscreen'
py -3.11 -m pip install -r requirements.txt
py -3.11 -m pytest -q -p no:cacheprovider
```

Run the source quality gates from the project root as needed:

```powershell
py -3.11 .\ops\audit.py source-quality
py -3.11 .\ops\audit.py deep-clean-gate
py -3.11 .\ops\audit.py runtime-regression-gate
py -3.11 .\ops\audit.py responsive-release-gate
py -3.11 .\ops\audit.py audited-release-gate
```

Build, installer generation, signing, publication, and server-contract changes are
separate release operations and must not be inferred from a successful source audit.
