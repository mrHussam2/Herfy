param([string]$Python = "python")
$env:QT_QPA_PLATFORM = "offscreen"
& $Python -m pytest tests/test_client_contracts.py tests/test_client_permissions.py -q -p no:cacheprovider
exit $LASTEXITCODE
