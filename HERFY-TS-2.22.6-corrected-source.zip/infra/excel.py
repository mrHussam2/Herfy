from __future__ import annotations

import csv
import logging
import math
import re
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import parse_excel_number


class FileTabularInputReader:
    """Filesystem adapter for CSV/XLS/XLSX tabular input files."""

    _CSV_ENCODINGS = ("utf-8-sig", "utf-8", "cp1256", "cp1252")

    def _read_csv_rows(self, path: Path) -> list[list[Any]]:
        last_error: Exception | None = None
        for encoding in self._CSV_ENCODINGS:
            try:
                with path.open(encoding=encoding, newline="") as handle:
                    sample = handle.read(4096)
                    handle.seek(0)
                    try:
                        dialect = csv.Sniffer().sniff(sample or ",")
                    except SERVICE_OPERATION_EXCEPTIONS:
                        dialect = csv.excel
                    return [list(row) for row in csv.reader(handle, dialect)]
            except SERVICE_OPERATION_EXCEPTIONS as exc:
                last_error = exc
        if last_error is not None:
            raise last_error
        return []

    @staticmethod
    def _read_xlsx_rows(path: Path) -> list[list[Any]]:
        from openpyxl import load_workbook

        workbook = load_workbook(filename=str(path), read_only=True, data_only=True)
        try:
            sheet = workbook.active
            return [list(row) for row in sheet.iter_rows(values_only=True)]
        finally:
            workbook.close()

    @staticmethod
    def _read_xls_rows(path: Path) -> list[list[Any]]:
        import xlrd

        book = xlrd.open_workbook(str(path))
        sheet = book.sheet_by_index(0)
        return [sheet.row_values(index) for index in range(sheet.nrows)]

    def read_rows(self, path: str | Path) -> list[list[Any]]:
        file_path = Path(path)
        suffix = file_path.suffix.lower()
        if suffix in {".xlsx", ".xlsm", ".xltx", ".xltm"}:
            return self._read_xlsx_rows(file_path)
        if suffix == ".xls":
            return self._read_xls_rows(file_path)
        if suffix in {".csv", ".txt", ".tsv"}:
            return self._read_csv_rows(file_path)

        readers = (self._read_xlsx_rows, self._read_xls_rows, self._read_csv_rows)
        last_error: Exception | None = None
        for reader in readers:
            try:
                return reader(file_path)
            except SERVICE_OPERATION_EXCEPTIONS as exc:
                last_error = exc
        if last_error is not None:
            raise last_error
        return []


logger = logging.getLogger(__name__)


def normalize_material_code(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return str(value).strip()
    if isinstance(value, int):
        return str(value).strip()
    if isinstance(value, float):
        if math.isnan(value):
            return ""
        if value.is_integer():
            return str(int(value))
        return f"{value:f}".rstrip("0").rstrip(".").strip()
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return ""
    text = text.replace(",", "")
    if re.fullmatch(r"\d+\.0+", text):
        return text.split(".", 1)[0]
    return text


def normalize_material_match_key(value: Any) -> str:
    """Canonical comparison key for server/Excel material numbers."""
    code = normalize_material_code(value)
    if not code:
        return ""
    return re.sub(r"[\s\-_]+", "", code).upper()


_SKIP_CODES = {"total", "grand total", "subtotal", "المجموع", "اجمالي", "الإجمالي"}
_LABEL_ALIASES = {
    "material": {
        "material",
        "material code",
        "material number",
        "material no",
        "رمز الصنف",
        "رقم الصنف",
        "رقم المادة",
    },
    "item": {"item", "code", "item code", "item no", "المادة", "الصنف"},
    "name": {
        "description",
        "material description",
        "item description",
        "name",
        "material name",
        "اسم الصنف",
        "اسم المادة",
        "الوصف",
        "وصف الصنف",
    },
    "receipts": {
        "receipts",
        "rec qty",
        "rec. qty",
        "qty received",
        "received",
        "receipt qty",
        "receipt quantity",
        "quantity received",
        "receipt",
        "الاستلام",
        "المستلم",
        "كمية الاستلام",
        "الكمية المستلمة",
    },
    "begining": {
        "begining",
        "beginning",
        "begin",
        "opening",
        "opening qty",
        "qty counted",
        "counted qty",
        "counted",
        "opening balance",
        "الرصيد الافتتاحي",
        "الافتتاحي",
        "الجرد",
        "كمية الجرد",
        "الكمية المعدودة",
    },
    "uom": {"uom", "unit", "unit of measure", "u/m", "الوحدة"},
    "qty": {"qty", "quantity", "الكمية"},
}


@dataclass
class SimpleTable:
    columns: list[Any]
    rows: list[dict[Any, Any]]

    @property
    def shape(self) -> tuple[int, int]:
        return (len(self.rows), len(self.columns))

    def iterrows(self):
        yield from enumerate(self.rows)


def _normalize_label(value) -> str:
    s = str(value or "").strip().lower()
    s = re.sub("\\s+", " ", s)
    s = s.replace("_", " ").replace("-", " ")
    s = s.replace(".", "").replace(":", "")
    for canonical, aliases in _LABEL_ALIASES.items():
        if s == canonical or s in aliases:
            return canonical
    return s


def _cell(row, col):
    try:
        if row is None or col is None:
            return None
        if isinstance(row, dict):
            return row.get(col)
        if isinstance(row, list | tuple) and isinstance(col, int):
            return row[col] if 0 <= col < len(row) else None
        return row[col]
    except SERVICE_OPERATION_EXCEPTIONS:
        return None


def _unique_columns(values: Iterable[Any]) -> list[Any]:
    result: list[Any] = []
    seen: dict[str, int] = {}
    for idx, raw in enumerate(values):
        base = str(raw).strip() if raw not in (None, "") else f"column_{idx + 1}"
        count = seen.get(base, 0) + 1
        seen[base] = count
        result.append(base if count == 1 else f"{base}_{count}")
    return result


def read_smart_excel_en(path: str, reader):
    raw_rows = reader.read_rows(path)
    if not raw_rows:
        return SimpleTable(columns=[], rows=[])
    header_row = -1
    keys = [
        "material",
        "item",
        "code",
        "uom",
        "unit",
        "description",
        "name",
        "qty",
        "receipts",
        "qty counted",
        "counted qty",
        "begin",
        "begining",
    ]
    limit = min(80, len(raw_rows))
    for i in range(limit):
        row_text = " | ".join([_normalize_label(x) for x in raw_rows[i]])
        if any((k in row_text for k in keys)):
            header_row = i
            break
    if header_row >= 0:
        columns = _unique_columns(raw_rows[header_row])
        body_rows = raw_rows[header_row + 1 :]
    else:
        width = max((len(r) for r in raw_rows), default=0)
        columns = list(range(width))
        body_rows = raw_rows
    normalized_rows: list[dict[Any, Any]] = []
    for raw in body_rows:
        row_values = list(raw)
        if len(row_values) < len(columns):
            row_values.extend([None] * (len(columns) - len(row_values)))
        elif len(row_values) > len(columns):
            row_values = row_values[: len(columns)]
        normalized_rows.append({col: row_values[idx] for idx, col in enumerate(columns)})
    return SimpleTable(columns=list(columns), rows=normalized_rows)


def _norm(df):
    return {c: _normalize_label(c) for c in df.columns}


def _first_matching_label(normalized_cols, labels):
    for want in labels:
        for column, label in normalized_cols.items():
            if label == want:
                return column
    return None


def _pick(colsmap, *names):
    return _first_matching_label(colsmap, names)


def _pick_preferred(colsmap, preferred_labels, fallback_labels=()):
    normalized = {c: str(lbl).strip().lower() for c, lbl in colsmap.items()}
    return _first_matching_label(normalized, preferred_labels) or _first_matching_label(
        normalized, fallback_labels
    )


def _pick_column_or_position(
    colsmap, df, *, preferred_labels, fallback_labels=(), default_index: int = 0
):
    col = _pick_preferred(
        colsmap, preferred_labels=preferred_labels, fallback_labels=fallback_labels
    )
    if col is not None:
        return col
    return df.columns[default_index] if df.shape[1] > default_index else None


def _pick_material_col(colsmap, df):
    return _pick_column_or_position(
        colsmap,
        df,
        preferred_labels=(
            "material",
            "material number",
            "material no",
            "material code",
            "رقم المادة",
            "رقم الصنف",
            "رمز الصنف",
        ),
        fallback_labels=("item code", "item no", "code", "item", "المادة", "الصنف"),
        default_index=0,
    )


def _iter_valid_material_rows(df, material_col):
    for _, row in df.iterrows():
        code = normalize_material_code(_cell(row, material_col))
        if not code or code.strip().lower() in _SKIP_CODES:
            continue
        yield (row, code)


def _pick_name_col(colsmap, df):
    return _pick_column_or_position(
        colsmap,
        df,
        preferred_labels=(
            "material description",
            "description",
            "material name",
            "item description",
            "name",
            "اسم المادة",
            "اسم الصنف",
            "الوصف",
        ),
        default_index=1,
    )


def _pick_begin_col(colsmap, df):
    return _pick_column_or_position(
        colsmap,
        df,
        preferred_labels=(
            "begining",
            "beginning",
            "qty counted",
            "counted qty",
            "counted",
            "opening qty",
            "opening balance",
            "الجرد",
            "كمية الجرد",
            "الكمية المعدودة",
        ),
        fallback_labels=("qty", "quantity", "الكمية"),
        default_index=2,
    )


def _pick_receipts_col(colsmap, df):
    return _pick_column_or_position(
        colsmap,
        df,
        preferred_labels=(
            "receipts",
            "rec qty",
            "rec. qty",
            "qty received",
            "quantity received",
            "receipt qty",
            "received",
            "receipt",
            "الاستلام",
            "كمية الاستلام",
            "الكمية المستلمة",
        ),
        fallback_labels=("qty", "quantity", "الكمية"),
        default_index=2,
    )


def parse_receipts(path: str, reader):
    df = read_smart_excel_en(path, reader)
    cols = _norm(df)
    mat_col = _pick_material_col(cols, df)
    name_col = _pick_name_col(cols, df)
    rec_col = _pick_receipts_col(cols, df)
    uom_col = _pick(cols, "uom") or (df.columns[3] if df.shape[1] >= 4 else None)
    out = {}
    for row, code in _iter_valid_material_rows(df, mat_col):
        name = str(_cell(row, name_col) or "").strip()
        rec = parse_excel_number(_cell(row, rec_col))
        uom = str(_cell(row, uom_col) or "").strip()
        bucket = out.setdefault(code, {"material": code, "name": name, "uom": uom, "receipts": 0.0})
        bucket.update(receipts=float(bucket.get("receipts", 0.0)) + rec)
        if uom and (not bucket.get("uom")):
            bucket.update(uom=uom)
        if name and (not bucket.get("name")):
            bucket.update(name=name)
    return out


def parse_beginning(path: str, reader):
    df = read_smart_excel_en(path, reader)
    cols = _norm(df)
    c_mat = _pick_material_col(cols, df)
    c_qty = _pick_begin_col(cols, df)
    c_name = _pick_name_col(cols, df)
    tmp = {}
    for row, code in _iter_valid_material_rows(df, c_mat):
        q = parse_excel_number(_cell(row, c_qty))
        name = str(_cell(row, c_name) or "").strip()
        tmp.setdefault(code, []).append({"qty": q, "name": name})
    return {k: arr[-1] for k, arr in tmp.items()}
