from __future__ import annotations

import json
import logging
import random
import threading
import time
import uuid
from contextlib import suppress
from dataclasses import asdict, is_dataclass
from typing import Any
from urllib.parse import urljoin, urlsplit, urlunsplit
from uuid import uuid4

import requests
from requests.adapters import HTTPAdapter

from contracts.binding import get_server_binding, policy_allows
from contracts.bootstrap import validate_client_bootstrap
from contracts.routes import Routes
from contracts.update_routes import package_path
from core.concurrency import wait_for_inflight_event
from core.errors import SERVICE_OPERATION_EXCEPTIONS, RemoteRequestError, SessionExpiredError
from core.models import (
    clean_string_list,
    normalize_branch_payload,
    normalize_int,
    normalize_remote_id,
    normalize_stored_product,
    normalize_text,
    normalize_tracking_item,
    normalize_usage_product,
    parse_bool,
    safe_get,
)
from core.permissions import validate_server_authority
from core.settings import (
    DEFAULT_SERVER_BASE_URL,
    canonical_error_message,
    get_cache_ttl,
    get_http_timeout_seconds,
    get_request_verify_ssl,
    normalize_api_base_url,
)
from core.settings import (
    get_server_base_url as resolve_configured_server_base_url,
)
from core.settings import (
    get_updates_base_url as resolve_configured_updates_base_url,
)
from infra.device_identity import get_or_create_device_id
from infra.realtime import CallbackBridge, RemoteRealtimeMixin


def require_object(value: Any, *, context: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RuntimeError(f"{context} returned a non-object response")
    return value


def require_required_keys(value: dict[str, Any], *, required: set[str], context: str) -> None:
    missing = required.difference(value)
    if missing:
        raise RuntimeError(f"{context} contract mismatch: missing={sorted(missing)}")


def require_exact_keys(
    value: dict[str, Any],
    *,
    required: set[str],
    optional: set[str] | None = None,
    context: str,
) -> None:
    allowed = required | (optional or set())
    missing = required.difference(value)
    unexpected = set(value).difference(allowed)
    if missing or unexpected:
        raise RuntimeError(
            f"{context} contract mismatch: missing={sorted(missing)}, "
            f"unexpected={sorted(unexpected)}"
        )


def require_object_list(value: Any, *, context: str) -> list[dict[str, Any]]:
    if not isinstance(value, list) or any(not isinstance(item, dict) for item in value):
        raise RuntimeError(f"{context} returned an invalid list")
    return list(value)


logger = logging.getLogger(__name__)


_ADMIN_BOOTSTRAP_REQUIRED_KEYS = {
    "authority_revision",
    "available_modules",
    "allowed_actions",
    "scope_policy",
    "manageable_roles",
    "permission_catalog",
    "summary",
}


def _string_set(value: Any, *, context: str) -> set[str]:
    if not isinstance(value, list) or any(
        not isinstance(item, str) or not item.strip() for item in value
    ):
        raise RuntimeError(f"{context} must be a list of non-empty strings")
    result = {item.strip() for item in value}
    if len(result) != len(value):
        raise RuntimeError(f"{context} must not contain duplicate values")
    return result


def validate_administration_bootstrap(value: Any) -> dict[str, Any]:
    """Validate and normalize the administration authority response.

    The canonical wire format for ``allowed_actions`` is a JSON object of
    permission code -> boolean. A legacy list is accepted only when every item
    is a unique, known permission code from the accompanying server catalog;
    it is then converted to explicit ``True`` grants for those exact items.
    Lists of objects, unknown codes, duplicate codes and truthy non-booleans
    are rejected so malformed data can never grant a capability.
    """
    data = require_object(value, context=Routes.ADMIN_BOOTSTRAP)
    require_required_keys(
        data,
        required=_ADMIN_BOOTSTRAP_REQUIRED_KEYS,
        context=Routes.ADMIN_BOOTSTRAP,
    )
    catalog = _string_set(data["permission_catalog"], context="permission_catalog")
    modules = _string_set(data["available_modules"], context="available_modules")
    actions = data["allowed_actions"]
    normalized_actions: dict[str, bool]
    if isinstance(actions, dict):
        normalized_actions = {}
        for code, allowed in actions.items():
            if not isinstance(code, str) or not code.strip() or not isinstance(allowed, bool):
                raise RuntimeError(
                    "allowed_actions must map non-empty permission codes to booleans"
                )
            clean_code = code.strip()
            if clean_code not in catalog:
                raise RuntimeError("allowed_actions contains a code outside permission_catalog")
            normalized_actions[clean_code] = allowed
    elif isinstance(actions, list):
        # Compatibility with released servers that returned role_permissions()
        # directly. This is safe only after validating the list's exact meaning.
        legacy_actions = _string_set(actions, context="allowed_actions")
        if not legacy_actions.issubset(catalog):
            raise RuntimeError("allowed_actions contains a code outside permission_catalog")
        normalized_actions = dict.fromkeys(sorted(legacy_actions), True)
        logger.warning(
            "ADMIN_BOOTSTRAP_LEGACY_ACTION_LIST_NORMALIZED action_count=%d module_count=%d",
            len(normalized_actions),
            len(modules),
        )
    else:
        raise RuntimeError("allowed_actions must be an object mapping permission codes to booleans")

    if not isinstance(data["scope_policy"], dict):
        raise RuntimeError("scope_policy must be an object")
    _string_set(data["manageable_roles"], context="manageable_roles")
    if not isinstance(data["summary"], dict):
        raise RuntimeError("summary must be an object")

    normalized = dict(data)
    normalized["available_modules"] = sorted(modules)
    normalized["allowed_actions"] = normalized_actions
    return normalized


def redact_url_for_log(url: str) -> str:
    """Return a URL safe for logs: no credentials, query parameters, or fragments."""
    try:
        parsed = urlsplit(str(url or ""))
    except ValueError:
        return "<invalid-url>"
    hostname = parsed.hostname or ""
    if not hostname:
        return parsed.path or "<relative-url>"
    host = f"[{hostname}]" if ":" in hostname and not hostname.startswith("[") else hostname
    try:
        port = parsed.port
    except ValueError:
        return "<invalid-url>"
    if port is not None:
        host = f"{host}:{port}"
    return urlunsplit((parsed.scheme.lower(), host, parsed.path or "/", "", ""))


_thread_local = threading.local()
_thread_sessions_lock = threading.RLock()
_thread_sessions: set[requests.Session] = set()
_IDEMPOTENT_METHODS = {"GET", "HEAD", "OPTIONS", "PUT", "DELETE"}
_MUTATION_METHODS = {"POST", "PATCH", "PUT", "DELETE"}
_SESSION_POOL_SIZE = 8

_REDIRECT_STATUS_CODES = {301, 302, 303, 307, 308}
_REDIRECT_SAFE_METHODS = {"GET", "HEAD", "OPTIONS"}
_SENSITIVE_REDIRECT_HEADERS = {"authorization", "cookie", "proxy-authorization"}


def _url_origin(url: str) -> tuple[str, str, int | None]:
    try:
        parsed = urlsplit(str(url or ""))
        port = parsed.port
    except ValueError as exc:
        raise RemoteRequestError("Invalid HTTP URL was rejected") from exc
    scheme = parsed.scheme.lower()
    hostname = (parsed.hostname or "").lower()
    if port is None:
        port = 443 if scheme == "https" else 80 if scheme == "http" else None
    return (scheme, hostname, port)


def _validated_redirect_target(source_url: str, location: str) -> str:
    target = urljoin(source_url, str(location or "").strip())
    parsed = urlsplit(target)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise RemoteRequestError("Unsafe HTTP redirect target was rejected")
    if parsed.username is not None or parsed.password is not None:
        raise RemoteRequestError("Credential-bearing HTTP redirect was rejected")
    source_scheme = urlsplit(source_url).scheme.lower()
    if source_scheme == "https" and parsed.scheme.lower() != "https":
        raise RemoteRequestError("HTTPS downgrade redirect was rejected")
    if _url_origin(source_url) != _url_origin(target):
        raise RemoteRequestError("Cross-origin API redirect was rejected")
    return target


def _redirect_kwargs(
    source_url: str, target_url: str, request_kwargs: dict[str, Any]
) -> dict[str, Any]:
    redirected = dict(request_kwargs)
    redirected.pop("params", None)
    if _url_origin(source_url) == _url_origin(target_url):
        return redirected
    headers = dict(redirected.get("headers") or {})
    redirected["headers"] = {
        key: value
        for key, value in headers.items()
        if str(key).strip().lower() not in _SENSITIVE_REDIRECT_HEADERS
    }
    redirected.pop("auth", None)
    redirected.pop("cookies", None)
    return redirected


def create_configured_session() -> requests.Session:
    session = requests.Session()
    # Production transport must not be silently redirected or weakened by
    # HTTP(S)_PROXY / REQUESTS_CA_BUNDLE environment variables.
    session.trust_env = False
    adapter = HTTPAdapter(
        pool_connections=_SESSION_POOL_SIZE,
        pool_maxsize=_SESSION_POOL_SIZE,
        max_retries=0,
        pool_block=True,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _thread_session() -> requests.Session:
    session = getattr(_thread_local, "session", None)
    if session is None:
        session = create_configured_session()
        _thread_local.session = session
        with _thread_sessions_lock:
            _thread_sessions.add(session)
    return session


def close_thread_session() -> None:
    session = getattr(_thread_local, "session", None)
    if session is None:
        return
    try:
        session.close()
    except requests.RequestException:
        logger.debug("HTTP thread-session close skipped", exc_info=True)
    finally:
        with _thread_sessions_lock:
            _thread_sessions.discard(session)
        with suppress(AttributeError):
            delattr(_thread_local, "session")


def close_all_thread_sessions() -> None:
    """Close all HTTP sessions owned by the shared request transport."""
    with _thread_sessions_lock:
        sessions = list(_thread_sessions)
        _thread_sessions.clear()
    for session in sessions:
        try:
            session.close()
        except requests.RequestException:
            logger.debug("HTTP managed-session close skipped", exc_info=True)
    # The current thread may still reference a session that has just been closed.
    with suppress(AttributeError):
        delattr(_thread_local, "session")


def _default_retries_for(method: str) -> int:
    return 2 if str(method or "GET").upper() in _IDEMPOTENT_METHODS else 0


def _backoff_wait(seconds: float) -> None:
    if threading.current_thread() is threading.main_thread():
        logger.warning("HTTP retry backoff skipped on main thread")
        return
    base = max(0.0, float(seconds or 0.0))
    jitter = random.uniform(0.0, min(0.35, base * 0.25)) if base else 0.0
    threading.Event().wait(base + jitter)


def _retry_after_seconds(response: requests.Response, fallback: float) -> float:
    raw = str(response.headers.get("Retry-After") or "").strip()
    if raw.isdigit():
        return min(30.0, max(0.0, float(raw)))
    return max(0.0, float(fallback))


def _headers_with_idempotency(method: str, kwargs: dict[str, Any]) -> dict[str, Any]:
    request_kwargs = dict(kwargs)
    if str(method or "").upper() not in _MUTATION_METHODS:
        return request_kwargs
    headers = dict(request_kwargs.get("headers") or {})
    if "Idempotency-Key" not in headers:
        headers["Idempotency-Key"] = str(uuid.uuid4())
    request_kwargs["headers"] = headers
    return request_kwargs


def _headers_with_release_identity(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Attach immutable release identity and a correlation ID to every API call."""
    request_kwargs = dict(kwargs)
    headers = dict(request_kwargs.get("headers") or {})
    binding = get_server_binding()
    headers.setdefault("X-Client-Version", binding.client_version)
    headers.setdefault("X-Client-Architecture", binding.client_architecture)
    headers.setdefault("X-API-Contract-SHA256", binding.api_contract_sha256)
    headers.setdefault("Accept", "application/json")
    raw_request_id = str(headers.get("X-Request-ID") or "").strip()
    try:
        request_id = str(uuid.UUID(raw_request_id)) if raw_request_id else str(uuid.uuid4())
    except (ValueError, AttributeError):
        request_id = str(uuid.uuid4())
    headers["X-Request-ID"] = request_id
    request_kwargs["headers"] = headers
    return request_kwargs


def _normalize_base(url: str) -> str:
    return normalize_api_base_url(url, default=DEFAULT_SERVER_BASE_URL)


def get_server_base_url(default: str = DEFAULT_SERVER_BASE_URL) -> str:
    configured = str(resolve_configured_server_base_url() or "").strip()
    if configured:
        return configured
    return _normalize_base(default)


def get_updates_base_url(default: str = "") -> str:
    configured = str(resolve_configured_updates_base_url() or "").strip()
    if configured:
        return configured.rstrip("/")
    return str(default or "").strip().rstrip("/")


def current_http_timeout() -> float:
    return float(get_http_timeout_seconds())


def current_requests_verify() -> bool:
    return bool(get_request_verify_ssl())


def _detail_message(value: Any) -> str:
    if isinstance(value, list):
        messages: list[str] = []
        for item in value:
            if isinstance(item, dict):
                loc = item.get("loc")
                loc_text = (
                    ".".join((str(x) for x in loc))
                    if isinstance(loc, list | tuple)
                    else str(loc or "")
                )
                msg = str(item.get("msg") or item.get("message") or "").strip()
                if loc_text and msg:
                    messages.append(f"{loc_text}: {msg}")
                elif msg:
                    messages.append(msg)
            else:
                text = str(item or "").strip()
                if text:
                    messages.append(text)
        return "; ".join(messages)
    if isinstance(value, dict):
        return str(value.get("detail") or value.get("message") or value.get("msg") or "").strip()
    return str(value or "").strip()


def _error_contract_from_response(response: requests.Response) -> dict[str, Any]:
    """Read the server's documented ErrorResponse without retaining raw bodies."""
    try:
        data = response.json()
    except SERVICE_OPERATION_EXCEPTIONS:
        return {}
    if not isinstance(data, dict):
        return {}
    error = data.get("error")
    if not isinstance(error, dict):
        return {}
    details = error.get("details")
    return {
        "code": str(error.get("code") or "").strip(),
        "message": str(error.get("message") or "").strip(),
        "request_id": str(
            error.get("request_id") or response.headers.get("X-Request-ID") or ""
        ).strip(),
        "retryable": bool(error.get("retryable", False)),
        "details": dict(details) if isinstance(details, dict) else {},
    }


def _detail_from_response(response: requests.Response) -> str:
    contract = _error_contract_from_response(response)
    if contract.get("message"):
        return str(contract["message"])
    try:
        data = response.json()
        if isinstance(data, dict):
            return _detail_message(data.get("detail") or data.get("message") or data)
        return _detail_message(data)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("_detail_from_response fallback failed", exc_info=True)
    return str(response.text or "").strip()


def _is_bound_api_url(url: str) -> bool:
    binding = get_server_binding()
    try:
        target = urlsplit(str(url or ""))
        bound = urlsplit(binding.api_base_url)
    except ValueError:
        return False
    target_origin = (
        target.scheme.lower(),
        (target.hostname or "").lower(),
        target.port or (443 if target.scheme.lower() == "https" else 80),
    )
    bound_origin = (
        bound.scheme.lower(),
        (bound.hostname or "").lower(),
        bound.port or (443 if bound.scheme.lower() == "https" else 80),
    )
    prefix = str(bound.path or "").rstrip("/") + "/"
    return target_origin == bound_origin and str(target.path or "").startswith(prefix)


_RELEASE_IDENTITY_META_CACHE_TTL_SECONDS = 30.0
_release_identity_meta_cache_lock = threading.RLock()
_release_identity_meta_cache: dict[str, tuple[float, bool, str, str]] = {}


def _release_identity_meta_cache_key() -> str:
    binding = get_server_binding()
    return "|".join(
        (
            binding.api_base_url.rstrip("/"),
            binding.api_contract_sha256.lower(),
            binding.client_version,
            binding.client_architecture,
        )
    )


def _meta_version_url_for_binding() -> str:
    binding = get_server_binding()
    return f"{binding.api_base_url.rstrip('/')}{Routes.META_VERSION}"


def _verify_release_identity_from_meta() -> tuple[bool, str, str]:
    """Verify the pinned release contract using only the bound API origin.

    A reverse proxy can accidentally omit custom response headers on a business
    response.  That must not cause the client to trust a different server: the
    fallback calls only the immutable same-origin ``/api/meta/version`` endpoint
    and requires the pinned contract digest plus a non-empty server version.
    """
    binding = get_server_binding()
    key = _release_identity_meta_cache_key()
    now = time.monotonic()
    with _release_identity_meta_cache_lock:
        cached = _release_identity_meta_cache.get(key)
        if cached and now < cached[0]:
            return cached[1], cached[2], cached[3]

    ok = False
    received_contract = ""
    received_server_version = ""
    session = create_configured_session()
    try:
        response = session.get(
            _meta_version_url_for_binding(),
            timeout=max(3.0, min(current_http_timeout(), 10.0)),
            verify=current_requests_verify(),
            allow_redirects=False,
            headers={
                "Accept": "application/json",
                "Cache-Control": "no-store",
                "X-Client-Version": binding.client_version,
                "X-Client-Architecture": binding.client_architecture,
                "X-API-Contract-SHA256": binding.api_contract_sha256,
                "X-Request-ID": str(uuid.uuid4()),
            },
        )
        try:
            if response.status_code == 200:
                payload = response.json()
                if isinstance(payload, dict):
                    received_contract = (
                        str(payload.get("api_contract_sha256") or "").strip().lower()
                    )
                    received_server_version = str(payload.get("server_version") or "").strip()
                    ok = received_contract == binding.api_contract_sha256.lower() and bool(
                        received_server_version
                    )
        finally:
            response.close()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.warning("Server release identity meta fallback failed", exc_info=True)
    except requests.RequestException:
        logger.warning("Server release identity meta fallback transport failed", exc_info=True)
    finally:
        session.close()

    with _release_identity_meta_cache_lock:
        _release_identity_meta_cache[key] = (
            time.monotonic() + _RELEASE_IDENTITY_META_CACHE_TTL_SECONDS,
            ok,
            received_contract,
            received_server_version,
        )
    return ok, received_contract, received_server_version


def _validate_response_release_identity(response: requests.Response, request_url: str) -> None:
    """Validate the pinned API contract identity on bound production responses.

    A present but different response contract hash fails immediately.  Only when
    an identity header is missing may the client use the constrained meta-endpoint
    fallback.  This retains fail-closed validation while tolerating a proxy that
    strips identity headers from an otherwise valid production response.
    """
    if not _is_bound_api_url(request_url):
        return
    binding = get_server_binding()
    expected_contract = binding.api_contract_sha256.lower()
    server_version = str(response.headers.get("X-Server-Version") or "").strip()
    contract_hash = str(response.headers.get("X-API-Contract-SHA256") or "").strip().lower()
    if contract_hash and contract_hash != expected_contract:
        raise RemoteRequestError(
            "The server API contract does not match this client release.",
            status_code=response.status_code,
            error_code="API_CONTRACT_MISMATCH",
            request_id=str(response.headers.get("X-Request-ID") or ""),
            details={
                "expected": expected_contract,
                "received": contract_hash,
                "source": "response-header",
            },
        )

    if contract_hash == expected_contract and server_version:
        return

    meta_ok, meta_contract, meta_server_version = _verify_release_identity_from_meta()
    if meta_ok:
        logger.info("Server release identity validated through /api/meta/version fallback")
        return

    if not contract_hash:
        raise RemoteRequestError(
            "The server API contract does not match this client release.",
            status_code=response.status_code,
            error_code="API_CONTRACT_MISMATCH",
            request_id=str(response.headers.get("X-Request-ID") or ""),
            details={
                "expected": expected_contract,
                "received": meta_contract or "",
                "source": "meta-fallback",
                "response_header_missing": True,
            },
        )

    raise RemoteRequestError(
        "The server did not provide release identity.",
        status_code=response.status_code,
        error_code="SERVER_VERSION_MISSING",
        request_id=str(response.headers.get("X-Request-ID") or ""),
        details={
            "expected_contract": expected_contract,
            "received_contract": contract_hash,
            "received_server_version": server_version or meta_server_version,
        },
    )


def _http_error_message(status_code: int, detail: str, url: str) -> str:
    clean_detail = str(detail or "").strip()
    lower_detail = clean_detail.lower()
    request_path = urlsplit(str(url or "")).path.lower()
    if "<html" in lower_detail or "<body" in lower_detail:
        clean_detail = ""
    if status_code == 404:
        package_probe = package_path("__route_probe__")
        package_prefix = package_probe.rsplit("/", 1)[0].casefold() + "/"
        if request_path.startswith(package_prefix):
            return "The update package is missing on the update server. Upload the remote update package again and verify the package URL."
    if status_code == 404:
        return "The requested server resource was not found."
    if status_code == 403:
        return clean_detail or canonical_error_message("permission_denied")
    if status_code == 426:
        return clean_detail or "A required HERFY-TS update is available."
    if status_code == 409 and "version" in lower_detail:
        return clean_detail or "This HERFY-TS client release is not approved by the server."
    return clean_detail or f"Server error (HTTP {status_code})"


def _close_response(response: requests.Response | None, *, context: str) -> None:
    if response is None:
        return
    try:
        response.close()
    except requests.RequestException:
        logger.debug("HTTP response close skipped: %s", context, exc_info=True)


def request_with_retry(
    method: str,
    url: str,
    *,
    session: requests.Session | None = None,
    timeout: float | None = None,
    verify: bool | None = None,
    max_retries: int | None = None,
    optional_statuses: set[int] | tuple[int, ...] | list[int] | None = None,
    **kwargs: Any,
) -> requests.Response:
    method = str(method or "GET").upper()
    optional_statuses = {int(code) for code in optional_statuses or []}
    timeout = current_http_timeout() if timeout is None else float(timeout)
    verify = current_requests_verify() if verify is None else bool(verify)
    max_retries = _default_retries_for(method) if max_retries is None else int(max_retries)
    request_kwargs = _headers_with_release_identity(_headers_with_idempotency(method, kwargs))
    owns_thread_session = session is None
    sender = session.request if session is not None else _thread_session().request
    delays = [0.7, 1.5, 2.5]
    last_exc: Exception | None = None
    logger.info("HTTP Request: %s %s", method, redact_url_for_log(url))
    for attempt in range(max_retries + 1):
        try:
            response = sender(
                method,
                url,
                timeout=timeout,
                verify=verify,
                allow_redirects=False,
                **request_kwargs,
            )
            if response.status_code in _REDIRECT_STATUS_CODES:
                status_code = response.status_code
                location = str(response.headers.get("location") or "").strip()
                _close_response(response, context="redirect")
                if method not in _REDIRECT_SAFE_METHODS:
                    raise RemoteRequestError(
                        f"HTTP redirect rejected for non-read request ({status_code})",
                        status_code=status_code,
                    )
                if not location:
                    raise RemoteRequestError(
                        f"HTTP redirect did not include a destination ({status_code})",
                        status_code=status_code,
                    )
                target_url = _validated_redirect_target(url, location)
                retry_kwargs = _redirect_kwargs(url, target_url, request_kwargs)
                logger.info(
                    "HTTP Redirect: %s -> %s",
                    status_code,
                    redact_url_for_log(target_url),
                )
                response = sender(
                    method,
                    target_url,
                    timeout=timeout,
                    verify=verify,
                    allow_redirects=False,
                    **retry_kwargs,
                )
                if response.status_code in _REDIRECT_STATUS_CODES:
                    second_status = response.status_code
                    _close_response(response, context="redirect chain")
                    raise RemoteRequestError(
                        "Multiple HTTP redirects were rejected",
                        status_code=second_status,
                    )
            try:
                _validate_response_release_identity(response, str(response.url or url))
            except RemoteRequestError:
                _close_response(response, context="release identity mismatch")
                raise
            logger.info(
                "HTTP Response: %s request_id=%s",
                response.status_code,
                str(response.headers.get("X-Request-ID") or ""),
            )
        except requests.Timeout as exc:
            last_exc = exc
            logger.warning(
                "Request timeout (attempt %s/%s; error=%s)",
                attempt + 1,
                max_retries + 1,
                type(exc).__name__,
            )
            if attempt >= max_retries:
                if owns_thread_session:
                    close_thread_session()
                raise RemoteRequestError(canonical_error_message("server_timeout")) from exc
            if owns_thread_session:
                close_thread_session()
                sender = _thread_session().request
            _backoff_wait(delays[min(attempt, len(delays) - 1)])
            continue
        except requests.ConnectionError as exc:
            last_exc = exc
            logger.warning(
                "Connection error (attempt %s/%s; error=%s)",
                attempt + 1,
                max_retries + 1,
                type(exc).__name__,
            )
            if attempt >= max_retries:
                if owns_thread_session:
                    close_thread_session()
                raise RemoteRequestError(canonical_error_message("connection_failed")) from exc
            if owns_thread_session:
                close_thread_session()
                sender = _thread_session().request
            _backoff_wait(delays[min(attempt, len(delays) - 1)])
            continue
        except requests.RequestException as exc:
            if owns_thread_session:
                close_thread_session()
            logger.error("Request failed: %s", type(exc).__name__)
            raise RemoteRequestError(canonical_error_message("operation_failed")) from exc
        if response.status_code == 401:
            error = _error_contract_from_response(response)
            detail = str(error.get("message") or _detail_from_response(response))
            _close_response(response, context="401")
            request_path = urlsplit(url).path.rstrip("/")
            is_login_request = request_path.endswith(Routes.AUTH_LOGIN)
            metadata = {
                "error_code": str(error.get("code") or ""),
                "request_id": str(error.get("request_id") or ""),
                "retryable": bool(error.get("retryable", False)),
                "details": dict(error.get("details") or {}),
            }
            if is_login_request:
                logger.warning(
                    "Authentication rejected request_id=%s code=%s",
                    metadata["request_id"],
                    metadata["error_code"],
                )
                raise RemoteRequestError(
                    detail or canonical_error_message("invalid_credentials"),
                    status_code=401,
                    **metadata,
                )
            logger.warning(
                "Session expired request_id=%s code=%s",
                metadata["request_id"],
                metadata["error_code"],
            )
            raise SessionExpiredError(
                detail or canonical_error_message("session_expired"),
                status_code=401,
                **metadata,
            )
        if response.status_code in (429, 502, 503, 504):
            logger.warning(
                "Server error %s (attempt %s/%s)",
                response.status_code,
                attempt + 1,
                max_retries + 1,
            )
            if attempt >= max_retries:
                status_code = response.status_code
                _close_response(response, context="final server error")
                raise RemoteRequestError(
                    canonical_error_message("server_unavailable"),
                    status_code=status_code,
                )
            retry_delay = _retry_after_seconds(response, delays[min(attempt, len(delays) - 1)])
            _close_response(response, context="retryable server error")
            _backoff_wait(retry_delay)
            continue
        if response.status_code >= 400:
            status_code = response.status_code
            error = _error_contract_from_response(response)
            detail = str(error.get("message") or _detail_from_response(response))
            _close_response(response, context=f"HTTP {status_code}")
            if status_code in optional_statuses:
                logger.info("Optional HTTP endpoint unavailable: %s", status_code)
            else:
                logger.error(
                    "HTTP request failed status=%s request_id=%s code=%s",
                    status_code,
                    str(error.get("request_id") or ""),
                    str(error.get("code") or ""),
                )
            raise RemoteRequestError(
                _http_error_message(status_code, detail, url),
                status_code=status_code,
                error_code=str(error.get("code") or ""),
                request_id=str(error.get("request_id") or ""),
                retryable=bool(error.get("retryable", False)),
                details=dict(error.get("details") or {}),
            )
        return response
    if last_exc is not None:
        raise RemoteRequestError(canonical_error_message("operation_failed")) from last_exc
    raise RemoteRequestError("Request failed after all retries")


def resolve_api_url(path_or_url: str, base_url: str | None = None) -> str:
    """Join the canonical API base URL with one registered relative route."""
    value = str(path_or_url or "").strip()
    root = normalize_api_base_url(
        str(base_url or get_server_base_url()),
        default=DEFAULT_SERVER_BASE_URL,
    ).rstrip("/")
    if not value:
        return root
    if value.startswith(("http://", "https://")):
        return value
    if not value.startswith("/"):
        raise ValueError("API routes must begin with '/'")
    if value.startswith("/api/"):
        raise ValueError("Routes must be relative to the configured /api base")
    return f"{root}{value}"


def api_request(
    method: str, path_or_url: str, *, base_url: str | None = None, **kwargs: Any
) -> requests.Response:
    return request_with_retry(method, resolve_api_url(path_or_url, base_url=base_url), **kwargs)


def api_fetch_json(
    path_or_url: str, *, base_url: str | None = None, **kwargs: Any
) -> dict[str, Any]:
    response = api_request("GET", path_or_url, base_url=base_url, **kwargs)
    try:
        try:
            data = response.json()
        except SERVICE_OPERATION_EXCEPTIONS:
            data = {}
        return data if isinstance(data, dict) else {}
    finally:
        response.close()


def _api_payload_json(
    method: str,
    path_or_url: str,
    payload: dict[str, Any],
    *,
    base_url: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    response = api_request(method, path_or_url, base_url=base_url, json=payload, **kwargs)
    try:
        try:
            data = response.json()
        except json.JSONDecodeError as exc:
            raise RemoteRequestError(canonical_error_message("malformed_response")) from exc
        except (TypeError, ValueError) as exc:
            raise RemoteRequestError(canonical_error_message("invalid_response")) from exc
        return data if isinstance(data, dict) else {}
    finally:
        response.close()


def api_post_json(
    path_or_url: str,
    payload: dict[str, Any],
    *,
    base_url: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    return _api_payload_json("POST", path_or_url, payload, base_url=base_url, **kwargs)


logger = logging.getLogger(__name__)


class RemoteApiCacheMixin:
    def init_remote_cache(self) -> None:
        self._request_lock = threading.RLock()
        self._memo: dict[str, tuple[float, Any]] = {}
        self._inflight_cache_events: dict[str, threading.Event] = {}
        self._pull_lock = threading.Lock()
        self._items_truncated = False

    def client_bootstrap(self, client_version: str) -> dict[str, Any]:
        version = normalize_text(client_version)
        if not version:
            raise ValueError("client_version is required")

        def _load() -> dict[str, Any]:
            response = self._req(
                "GET",
                Routes.META_CLIENT_BOOTSTRAP,
                params={"client_version": version},
            )
            payload = validate_client_bootstrap(self._safe_json(response))
            if "authority" in payload:
                payload["authority"] = validate_server_authority(payload["authority"])
            return payload

        result = self._cached(
            f"client_bootstrap:{version}",
            60.0,
            _load,
        )
        if not isinstance(result, dict):
            raise RuntimeError("Client bootstrap cache returned invalid data")
        return dict(result)

    def _cached(self, key: str, ttl_seconds: float, loader):
        now = time.monotonic()
        should_load = False
        with self._request_lock:
            cached = self._memo.get(key)
            if cached and now - cached[0] <= ttl_seconds:
                return cached[1]
            loader_event = self._inflight_cache_events.get(key)
            if loader_event is None:
                loader_event = threading.Event()
                self._inflight_cache_events[key] = loader_event
                should_load = True
        if not should_load:
            wait_for_inflight_event(
                loader_event,
                timeout_seconds=max(5.0, min(15.0, float(ttl_seconds) if ttl_seconds else 5.0)),
                logger_=logger,
                context=f"ApiClient._cached[{key}]",
            )
            with self._request_lock:
                cached = self._memo.get(key)
                if cached and time.monotonic() - cached[0] <= ttl_seconds:
                    return cached[1]
                stale_cached = self._memo.get(key)
            if stale_cached:
                logger.debug(
                    "ApiClient._cached returning stale memoized value for %s after wait timeout",
                    key,
                )
                return stale_cached[1]
            logger.debug(
                "ApiClient._cached skipped duplicate network load while another worker owns it: %s",
                key,
            )
            return []
        try:
            value = loader()
            with self._request_lock:
                self._memo[key] = (time.monotonic(), value)
            return value
        finally:
            with self._request_lock:
                event = self._inflight_cache_events.pop(key, None)
                if event is not None:
                    event.set()

    def _invalidate_prefix(self, prefix: str) -> None:
        with self._request_lock:
            for key in list(self._memo.keys()):
                if key.startswith(prefix):
                    self._memo.pop(key, None)

    def invalidate_tracking_cache(self, branch: str | None = None) -> None:
        branch_key = normalize_text(branch).lower() if branch else ""
        with self._request_lock:
            for key in list(self._memo.keys()):
                if key.startswith("items:") and (
                    not branch_key or key in {f"items:{branch_key}", "items:all"}
                ):
                    self._memo.pop(key, None)


def _user_to_dict(user: Any) -> dict[str, Any]:
    if user is None:
        return {}
    if isinstance(user, dict):
        return dict(user)

    # UserProfile owns the canonical server-authority serialization. Prefer it
    # over dataclasses.asdict(), which would incorrectly nest PermissionContext
    # below "permission_context" and hide permissions/scope from HTTP mixins.
    to_cloud_payload = getattr(user, "to_cloud_user_payload", None)
    if callable(to_cloud_payload):
        try:
            payload = to_cloud_payload()
            if isinstance(payload, dict):
                return dict(payload)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("_user_to_dict canonical authority serialization failed", exc_info=True)

    if is_dataclass(user):
        try:
            return asdict(user)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("_user_to_dict fallback failed", exc_info=True)
    data: dict[str, Any] = {}
    fields = (
        "user_id",
        "username",
        "display_name",
        "role",
        "account_type",
        "branches",
        "active_branch",
        "permission_context",
        "must_change_password",
        "is_active",
    )
    for key in fields:
        try:
            if hasattr(user, key):
                data[key] = getattr(user, key)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("_user_to_dict fallback failed", exc_info=True)
    return data


class RemoteApiAdminMixin:
    """Thin HTTP adapter for the canonical administration API.

    This layer deliberately contains no role/scope/business orchestration.  It
    serializes explicit API requests and returns the canonical server result.
    """

    def _invalidate_admin_sync_cache(self) -> None:
        invalidate = getattr(self, "_invalidate_prefix", None)
        if callable(invalidate):
            for prefix in ("admin_", "meta_", "catalog_", "items:"):
                invalidate(prefix)

    @staticmethod
    def _require_text(value: Any, label: str) -> str:
        text = normalize_text(value)
        if not text:
            raise ValueError(f"{label} is required")
        return text

    def _request_object(
        self,
        method: str,
        route: str,
        *,
        payload: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {}
        if payload is not None:
            kwargs["json"] = payload
        if params:
            kwargs["params"] = {k: v for k, v in params.items() if v is not None and v != ""}
        response = self._req(method, route, **kwargs)
        return require_object(self._safe_json(response), context=route)

    def _request_list(
        self,
        method: str,
        route: str,
        *,
        params: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Request and validate a top-level object list from an admin route.

        ``ApiClient._safe_json`` intentionally accepts only object envelopes, while
        the two catalog administration list endpoints return a top-level array.
        Keep that distinction explicit so catalog reads do not depend on a helper
        that the concrete client does not provide.
        """
        kwargs: dict[str, Any] = {}
        if params:
            kwargs["params"] = {
                key: value for key, value in params.items() if value is not None and value != ""
            }
        response = self._req(method, route, **kwargs)
        try:
            try:
                data = response.json()
            except (TypeError, ValueError) as exc:
                raise RuntimeError(f"{route} returned invalid JSON") from exc
            return require_object_list(data, context=route)
        finally:
            close = getattr(response, "close", None)
            if callable(close):
                close()

    # Bootstrap / reads -------------------------------------------------
    def admin_bootstrap(self) -> dict[str, Any]:
        data = self._request_object("GET", Routes.ADMIN_BOOTSTRAP)
        return validate_administration_bootstrap(data)

    def _admin_paged_list(self, route: str, **filters: Any) -> dict[str, Any]:
        """Read and validate a paged administration collection."""
        data = self._request_object("GET", route, params=filters)
        require_required_keys(data, required={"items", "next_cursor"}, context=route)
        require_object_list(data["items"], context=route)
        return data

    def admin_list_users(self, **filters: Any) -> dict[str, Any]:
        return self._admin_paged_list(Routes.ADMIN_USERS, **filters)

    def admin_structure(self) -> dict[str, Any]:
        data = self._request_object("GET", Routes.ADMIN_STRUCTURE)
        for key in ("organizations", "regions", "areas", "branches"):
            require_object_list(data.get(key, []), context=f"{Routes.ADMIN_STRUCTURE}:{key}")
        return data

    def admin_list_permissions(self) -> dict[str, Any]:
        return self._request_object("GET", Routes.ADMIN_PERMISSIONS)

    def admin_list_audit_events(self, **filters: Any) -> dict[str, Any]:
        return self._admin_paged_list(Routes.ADMIN_AUDIT, **filters)

    # User / authority --------------------------------------------------
    def admin_create_user(self, payload: dict[str, Any]) -> dict[str, Any]:
        result = self._request_object("POST", Routes.ADMIN_USERS, payload=dict(payload))
        self._invalidate_admin_sync_cache()
        return result

    def admin_update_user(self, user_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        route = Routes.admin_user(self._require_text(user_id, "user_id"))
        result = self._request_object("PATCH", route, payload=dict(payload))
        self._invalidate_admin_sync_cache()
        return result

    def admin_set_user_active(
        self, user_id: str, *, active: bool, base_authority_revision: int
    ) -> dict[str, Any]:
        uid = self._require_text(user_id, "user_id")
        if active:
            return self.admin_update_user(
                uid, {"base_authority_revision": int(base_authority_revision), "is_active": True}
            )
        route = Routes.admin_user(uid)
        result = self._request_object(
            "DELETE", route, params={"base_authority_revision": int(base_authority_revision)}
        )
        self._invalidate_admin_sync_cache()
        return result

    def admin_reset_password(
        self, user_id: str, *, base_authority_revision: int, password: str | None = None
    ) -> dict[str, Any]:
        route = Routes.admin_reset_password(self._require_text(user_id, "user_id"))
        payload: dict[str, Any] = {
            "base_authority_revision": int(base_authority_revision),
            "password": normalize_text(password) or None,
        }
        result = self._request_object("POST", route, payload=payload)
        self._invalidate_admin_sync_cache()
        return result

    def admin_replace_user_scopes(
        self, user_id: str, *, base_authority_revision: int, assignments: list[dict[str, str]]
    ) -> dict[str, Any]:
        route = Routes.admin_user_scopes(self._require_text(user_id, "user_id"))
        payload = {
            "base_authority_revision": int(base_authority_revision),
            "assignments": [
                {
                    "scope_type": self._require_text(row.get("scope_type"), "scope_type"),
                    "scope_id": self._require_text(row.get("scope_id"), "scope_id"),
                }
                for row in (assignments or [])
            ],
        }
        result = self._request_object("PUT", route, payload=payload)
        self._invalidate_admin_sync_cache()
        return result

    # Structure ---------------------------------------------------------
    def _create_resource(self, resource: str, payload: dict[str, Any]) -> dict[str, Any]:
        # The desktop administration workspace treats HERFY as its fixed root.
        # Keep mutable structure transport limited to the canonical child levels
        # exposed by the client use-case boundary. Server contracts may still
        # advertise organization administration for older/admin consumers, but
        # this client must not expose a dormant bypass around the fixed-root UI.
        route = {
            "regions": Routes.ADMIN_REGIONS,
            "areas": Routes.ADMIN_AREAS,
            "branches": Routes.ADMIN_BRANCHES,
        }[resource]
        result = self._request_object("POST", route, payload=payload)
        self._invalidate_admin_sync_cache()
        return result

    def _update_resource(
        self, resource: str, identifier: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        result = self._request_object(
            "PATCH", Routes.admin_update_resource(resource, identifier), payload=payload
        )
        self._invalidate_admin_sync_cache()
        return result

    def _delete_resource(
        self, resource: str, identifier: str, base_revision: int
    ) -> dict[str, Any]:
        result = self._request_object(
            "DELETE",
            Routes.admin_resource(resource, identifier),
            params={"base_revision": int(base_revision)},
        )
        self._invalidate_admin_sync_cache()
        return result

    def admin_create_region(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._create_resource("regions", payload)

    def admin_update_region(self, region_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._update_resource("regions", region_id, payload)

    def admin_delete_region(self, region_id: str, base_revision: int) -> dict[str, Any]:
        return self._delete_resource("regions", region_id, base_revision)

    def admin_create_area(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._create_resource("areas", payload)

    def admin_update_area(self, area_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._update_resource("areas", area_id, payload)

    def admin_delete_area(self, area_id: str, base_revision: int) -> dict[str, Any]:
        return self._delete_resource("areas", area_id, base_revision)

    def admin_create_branch(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._create_resource("branches", payload)

    def admin_update_branch(self, branch_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        return self._update_resource("branches", branch_id, payload)

    def admin_delete_branch(self, branch_id: str, base_revision: int) -> dict[str, Any]:
        return self._delete_resource("branches", branch_id, base_revision)

    def admin_create_branches_batch(self, items: list[dict[str, Any]]) -> dict[str, Any]:
        result = self._request_object(
            "POST", Routes.ADMIN_BRANCHES_BATCH, payload={"items": list(items or [])}
        )
        self._invalidate_admin_sync_cache()
        return result

    def admin_transfer_branch(
        self, branch_id: str, *, area_id: str, base_revision: int
    ) -> dict[str, Any]:
        result = self._request_object(
            "POST",
            Routes.branch_transfer(self._require_text(branch_id, "branch_id")),
            payload={
                "area_id": self._require_text(area_id, "area_id"),
                "base_revision": int(base_revision),
            },
        )
        self._invalidate_admin_sync_cache()
        return result

    # Permissions -------------------------------------------------------
    def admin_set_role_permissions(
        self, role_key: str, *, base_revision: int, permissions: list[str]
    ) -> dict[str, Any]:
        result = self._request_object(
            "PUT",
            Routes.role_permissions(self._require_text(role_key, "role_key")),
            payload={
                "base_revision": int(base_revision),
                "permissions": [str(p).strip() for p in permissions if str(p).strip()],
            },
        )
        self._invalidate_admin_sync_cache()
        return result

    # Catalog administration ------------------------------------------
    def _catalog_list(self, kind: str, *, include_inactive: bool = True) -> list[dict[str, Any]]:
        route = Routes.ADMIN_STORED_PRODUCTS if kind == "stored" else Routes.ADMIN_USAGE_PRODUCTS
        return self._request_list("GET", route, params={"include_inactive": bool(include_inactive)})

    def admin_list_stored_products(self, *, include_inactive: bool = True) -> list[dict[str, Any]]:
        return self._catalog_list("stored", include_inactive=include_inactive)

    def admin_list_usage_products(self, *, include_inactive: bool = True) -> list[dict[str, Any]]:
        return self._catalog_list("usage", include_inactive=include_inactive)

    def _catalog_create(self, kind: str, payload: dict[str, Any]) -> dict[str, Any]:
        route = Routes.ADMIN_STORED_PRODUCTS if kind == "stored" else Routes.ADMIN_USAGE_PRODUCTS
        result = self._request_object("POST", route, payload=payload)
        self._invalidate_admin_sync_cache()
        return result

    def _catalog_update(
        self, kind: str, material_number: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        route = (
            Routes.stored_product(material_number)
            if kind == "stored"
            else Routes.usage_product(material_number)
        )
        result = self._request_object("PATCH", route, payload=payload)
        self._invalidate_admin_sync_cache()
        return result

    def _catalog_delete(
        self, kind: str, material_number: str, base_revision: int
    ) -> dict[str, Any]:
        route = (
            Routes.stored_product(material_number)
            if kind == "stored"
            else Routes.usage_product(material_number)
        )
        result = self._request_object("DELETE", route, params={"base_revision": int(base_revision)})
        self._invalidate_admin_sync_cache()
        return result

    def admin_create_stored_product(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._catalog_create("stored", payload)

    def admin_update_stored_product(
        self, material_number: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._catalog_update("stored", material_number, payload)

    def admin_delete_stored_product(
        self, material_number: str, base_revision: int
    ) -> dict[str, Any]:
        return self._catalog_delete("stored", material_number, base_revision)

    def admin_create_usage_product(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._catalog_create("usage", payload)

    def admin_update_usage_product(
        self, material_number: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._catalog_update("usage", material_number, payload)

    def admin_delete_usage_product(
        self, material_number: str, base_revision: int
    ) -> dict[str, Any]:
        return self._catalog_delete("usage", material_number, base_revision)

    # Account security --------------------------------------------------
    def password_policy(self) -> dict[str, Any]:
        return self._request_object("GET", Routes.AUTH_PASSWORD_POLICY)

    def change_own_password(
        self, current_password: str | None, new_password: str
    ) -> dict[str, Any]:
        payload = {"new_password": new_password}
        if current_password is not None:
            payload["current_password"] = current_password
        result = self._request_object(
            "POST",
            Routes.AUTH_CHANGE_PASSWORD,
            payload=payload,
        )
        self._invalidate_admin_sync_cache()
        return result


logger = logging.getLogger(__name__)


class RemoteTrackingMetadataMixin:
    """Read organizational data only from the authenticated server contract."""

    def _server_authority_valid(self) -> bool:
        source = normalize_text(safe_get(self.user, "permission_source"))
        scope = safe_get(self.user, "scope")
        permissions = safe_get(self.user, "permissions")
        return (
            source == "postgresql.role_permissions"
            and isinstance(scope, dict)
            and isinstance(permissions, (list, tuple, set))
        )

    def _server_permissions(self) -> set[str]:
        if not self._server_authority_valid():
            return set()
        return {
            normalize_text(value).lower()
            for value in safe_get(self.user, "permissions") or []
            if normalize_text(value)
        }

    def _server_has_permission(self, permission: str) -> bool:
        code = normalize_text(permission).lower()
        permissions = self._server_permissions()
        if not code:
            return False
        policy_name = code if code in {"catalog.stored.view", "catalog.usage.view"} else ""
        return (
            policy_allows(policy_name, permissions)
            if policy_name
            else bool("*" in permissions or code in permissions)
        )

    def _server_has_any_permission(self, *permissions: str) -> bool:
        return any(self._server_has_permission(code) for code in permissions)

    def _require_server_permission(self, permission: str) -> None:
        if not self._server_has_permission(permission):
            raise PermissionError(f"Server permission required: {permission}")

    def _server_scope_all_branches(self) -> bool:
        if not self._server_authority_valid():
            return False
        scope = safe_get(self.user, "scope") or {}
        return parse_bool(safe_get(scope, "all_branches"), False)

    def _known_scope_branches(self) -> list[str]:
        if not self._server_authority_valid():
            return []
        scope = safe_get(self.user, "scope") or {}
        return clean_string_list(safe_get(scope, "branches") or [])

    def _server_can_access_branch(self, branch: str | None) -> bool:
        value = normalize_text(branch)
        if not value or not self._server_authority_valid():
            return False
        if self._server_scope_all_branches():
            return True
        return value.casefold() in {item.casefold() for item in self._known_scope_branches()}

    def _metadata_cache_ttl(self) -> float:
        return float(get_cache_ttl().metadata)

    @staticmethod
    def _strict_items_response(data: Any, *, context: str) -> list[dict[str, Any]]:
        payload = require_object(data, context=context)
        require_exact_keys(payload, required={"items"}, context=context)
        items = payload["items"]
        if not isinstance(items, list) or any(not isinstance(item, dict) for item in items):
            raise RuntimeError(f"{context} returned invalid items")
        return list(items)

    @staticmethod
    def _normalize_rows(
        items: list[dict[str, Any]], normalizer, id_key: str
    ) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for item in items:
            row = normalizer(item)
            if not row.get(id_key):
                raise RuntimeError(f"Server row is missing {id_key}")
            rows.append(row)
        return rows

    def _load_metadata(
        self,
        *,
        cache_key: str,
        route: str,
        normalizer,
        id_key: str,
    ) -> list[dict[str, Any]]:
        def load() -> list[dict[str, Any]]:
            data = self._safe_json(self._req("GET", route))
            items = self._strict_items_response(data, context=route)
            return self._normalize_rows(items, normalizer, id_key)

        return list(self._cached(cache_key, self._metadata_cache_ttl(), load))

    def meta_branches_full(self) -> list[dict[str, Any]]:
        return self._load_metadata(
            cache_key="meta_branches",
            route=Routes.META_BRANCHES,
            normalizer=normalize_branch_payload,
            id_key="branch_id",
        )

    def meta_branches(self) -> list[str]:
        return [str(row["branch_id"]) for row in self.meta_branches_full()]


class RemoteTrackingSyncMixin:
    """Strict cursor synchronization using the single /sync contract."""

    def _validate_requested_scope(
        self,
        branch_id: str | None,
        branch_ids: list[str] | None,
    ) -> None:
        requested = clean_string_list(
            ([branch_id] if normalize_text(branch_id) else []) + list(branch_ids or [])
        )
        if self._server_scope_all_branches():
            return
        allowed = {item.casefold() for item in self._known_scope_branches()}
        denied = [item for item in requested if item.casefold() not in allowed]
        if denied:
            raise PermissionError(f"Requested branches are outside server authority: {denied}")

    @staticmethod
    def _canonical_server_event(change: dict[str, Any]) -> dict[str, Any]:
        """Validate one persisted server sync change without compatibility aliases."""
        required = {
            "event_id",
            "cursor",
            "entity_type",
            "entity_id",
            "operation",
            "revision",
            "server_timestamp",
            "scope",
            "payload",
        }
        require_exact_keys(change, required=required, context="server sync change")
        payload = change["payload"]
        scope = change["scope"]
        if not isinstance(payload, dict):
            raise RuntimeError("Server sync change payload is invalid")
        if not isinstance(scope, dict) or set(scope) != {"type", "id"}:
            raise RuntimeError("Server sync change scope is invalid")
        operation = str(change["operation"] or "").strip().lower()
        if operation not in {
            "create",
            "update",
            "delete",
            "status_change",
            "role_change",
            "permission_change",
            "scope_change",
        }:
            raise RuntimeError("Server sync change operation is invalid")
        event_id = normalize_int(change["event_id"])
        cursor = normalize_int(change["cursor"])
        if event_id <= 0 or cursor != event_id:
            raise RuntimeError("Server sync event identity/cursor is invalid")
        entity_type = str(change["entity_type"] or "").strip()
        entity_id = str(change["entity_id"] or "").strip()
        if not entity_type or not entity_id:
            raise RuntimeError("Server sync change identity is invalid")
        return {
            "event_id": event_id,
            "cursor": cursor,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "operation": operation,
            "revision": normalize_int(change["revision"]),
            "server_timestamp": str(change["server_timestamp"] or ""),
            "scope": {
                "type": str(scope["type"] or "").strip(),
                "id": str(scope["id"] or "").strip(),
            },
            "payload": dict(payload),
        }

    def pull_sync_changes(
        self,
        branch_id: str | None = None,
        *,
        cursor: int | None = None,
        branch_ids: list[str] | None = None,
        authority_revision: int | None = None,
    ) -> dict[str, Any]:
        self._require_server_permission("sync.pull")
        self._validate_requested_scope(branch_id, branch_ids)
        params = {
            "from_cursor": max(0, normalize_int(self.sync_cursor() if cursor is None else cursor)),
            "authority_revision": max(
                0,
                normalize_int(
                    self.sync_authority_revision()
                    if authority_revision is None
                    else authority_revision
                ),
            ),
            "limit": 200,
        }
        data = require_object(
            self._safe_json(self._req("GET", Routes.SYNC_PULL, params=params)),
            context=Routes.SYNC_PULL,
        )
        mode = str(data.get("mode") or "").strip().lower()
        recovery_reason = str(data.get("recovery_reason") or "").strip().lower()
        try:
            authority = validate_server_authority(data.get("authority"))
        except ValueError as exc:
            raise RuntimeError(f"Server sync authority snapshot is invalid: {exc}") from exc
        tracking_items: list[dict[str, Any]] = []
        stored_products: list[dict[str, Any]] = []
        usage_products: list[dict[str, Any]] = []
        organizations: list[dict[str, Any]] = []
        regions: list[dict[str, Any]] = []
        areas: list[dict[str, Any]] = []
        branches: list[dict[str, Any]] = []
        if mode == "full":
            required_full = {
                "mode",
                "recovery_reason",
                "min_retained_cursor",
                "tracking_items",
                "stored_products",
                "usage_products",
                "organizations",
                "regions",
                "areas",
                "branches",
                "authority_revision",
                "authority",
                "changes",
                "next_cursor",
                "has_more",
                "server_time",
                "from_cursor",
                "high_watermark",
            }
            require_exact_keys(data, required=required_full, context="full sync response")
            if recovery_reason not in {"initial", "authority_changed"}:
                raise RuntimeError("Full sync recovery reason is invalid")
            for key in (
                "tracking_items",
                "stored_products",
                "usage_products",
                "organizations",
                "regions",
                "areas",
                "branches",
                "changes",
            ):
                if not isinstance(data[key], list) or any(
                    not isinstance(row, dict) for row in data[key]
                ):
                    raise RuntimeError(f"Full sync {key} must be a list of objects")
            events: list[dict[str, Any]] = []
            tracking_items = [dict(row) for row in data["tracking_items"]]
            stored_products = [normalize_stored_product(row) for row in data["stored_products"]]
            usage_products = [normalize_usage_product(row) for row in data["usage_products"]]
            organizations = [dict(row) for row in data["organizations"]]
            regions = [dict(row) for row in data["regions"]]
            areas = [dict(row) for row in data["areas"]]
            branches = [dict(row) for row in data["branches"]]
        elif mode == "incremental":
            required_incremental = {
                "mode",
                "changes",
                "next_cursor",
                "has_more",
                "min_retained_cursor",
                "authority_revision",
                "authority",
                "server_time",
                "from_cursor",
                "high_watermark",
            }
            require_exact_keys(
                data, required=required_incremental, context="incremental sync response"
            )
            if not isinstance(data["changes"], list):
                raise RuntimeError("Incremental sync changes must be a list")
            events = [
                self._canonical_server_event(item)
                for item in data["changes"]
                if isinstance(item, dict)
            ]
            if len(events) != len(data["changes"]):
                raise RuntimeError("Server sync changes include an invalid event")
        else:
            raise RuntimeError("Sync pull response does not match the matched server contract")
        if not isinstance(events, list) or any(not isinstance(item, dict) for item in events):
            raise RuntimeError("Sync pull returned invalid events")
        next_cursor = normalize_int(data["next_cursor"])
        if next_cursor < params["from_cursor"]:
            raise RuntimeError("Sync cursor moved backwards")
        return {
            "events": list(events),
            "tracking_items": tracking_items,
            "next_cursor": next_cursor,
            "has_more": bool(data.get("has_more", False)),
            "mode": mode,
            "recovery_reason": recovery_reason,
            "stored_products": stored_products,
            "usage_products": usage_products,
            "organizations": organizations,
            "regions": regions,
            "areas": areas,
            "branches": branches,
            "authority_revision": normalize_int(data.get("authority_revision"), 0),
            "authority": authority,
        }

    def pull_now(self, branch_id: str | None = None) -> dict[str, Any]:
        """Drain the server delta stream without committing the local cursor.

        ``self._cursor`` is the last *successfully applied and persisted* cursor.  A
        network response is only a candidate cursor; the UI/application layer commits
        it after every returned event has been applied locally.  This prevents a
        failed local write from silently skipping server changes on the next pull.
        """
        with self._pull_lock:
            committed_cursor = self.sync_cursor()
            candidate_cursor = committed_cursor
            all_events: list[dict[str, Any]] = []
            rows: list[dict[str, Any]] = []
            mode = "incremental"
            recovery_reason = ""
            stored_products: list[dict[str, Any]] = []
            usage_products: list[dict[str, Any]] = []
            organizations: list[dict[str, Any]] = []
            regions: list[dict[str, Any]] = []
            areas: list[dict[str, Any]] = []
            branches: list[dict[str, Any]] = []
            authority_revision = self.sync_authority_revision()
            authority: dict[str, Any] | None = None

            while True:
                data = self.pull_sync_changes(
                    branch_id=branch_id,
                    cursor=candidate_cursor,
                    authority_revision=authority_revision,
                )
                page_events = list(data["events"])
                if data["mode"] == "full":
                    # Authority may change between incremental pages. A full snapshot
                    # supersedes any uncommitted deltas collected in this drain.
                    if candidate_cursor != committed_cursor:
                        all_events.clear()
                        rows.clear()
                        stored_products.clear()
                        usage_products.clear()
                        organizations.clear()
                        regions.clear()
                        areas.clear()
                        branches.clear()
                    mode = "full"
                    recovery_reason = str(data["recovery_reason"] or "")
                    stored_products = list(data["stored_products"] or [])
                    usage_products = list(data["usage_products"] or [])
                    organizations = list(data["organizations"] or [])
                    regions = list(data["regions"] or [])
                    areas = list(data["areas"] or [])
                    branches = list(data["branches"] or [])
                    for raw in data["tracking_items"]:
                        rows.append(normalize_tracking_item(raw))
                authority_revision = normalize_int(data.get("authority_revision"), 0)
                authority = dict(data["authority"])
                next_cursor = normalize_int(data["next_cursor"], candidate_cursor)
                if next_cursor < candidate_cursor:
                    raise RuntimeError("Sync cursor moved backwards while draining changes")
                if data["has_more"] and next_cursor <= candidate_cursor:
                    raise RuntimeError("Sync pull reported has_more without cursor progress")

                for event in page_events:
                    require_exact_keys(
                        event,
                        required={
                            "event_id",
                            "cursor",
                            "entity_type",
                            "entity_id",
                            "operation",
                            "revision",
                            "server_timestamp",
                            "scope",
                            "payload",
                        },
                        context="sync event",
                    )
                    all_events.append(event)
                    if event["entity_type"] != "tracking_item":
                        continue
                    if event["operation"] == "delete":
                        continue
                    payload = event["payload"]
                    if not isinstance(payload, dict):
                        raise RuntimeError("Tracking sync event is missing its payload")
                    normalized = normalize_tracking_item(payload)
                    if not (normalized.get("doc_id") or normalized.get("id")):
                        raise RuntimeError("Tracking sync event has no entity identifier")
                    rows.append(normalized)

                candidate_cursor = next_cursor
                if not data["has_more"]:
                    break

        return {
            "rows": rows,
            "events": all_events,
            "next_cursor": candidate_cursor,
            "has_more": False,
            "mode": mode,
            "recovery_reason": recovery_reason,
            "stored_products": stored_products,
            "usage_products": usage_products,
            "organizations": organizations,
            "regions": regions,
            "areas": areas,
            "branches": branches,
            "authority_revision": authority_revision,
            "authority": dict(authority or {}),
        }

    def invalidate_after_sync_apply(self, events: list[dict[str, Any]] | None = None) -> None:
        """Invalidate HTTP memoized reads only after durable local apply succeeds."""
        if not events:
            return
        self.invalidate_tracking_cache(None)
        for prefix in ("catalog_", "meta_", "admin_"):
            self._invalidate_prefix(prefix)

    def set_sync_cursor(self, cursor: int | str | None) -> None:
        value = max(0, normalize_int(cursor))
        with self._cursor_lock:
            self._cursor = value

    def sync_cursor(self) -> int:
        with self._cursor_lock:
            return max(0, int(self._cursor or 0))

    def set_sync_authority_revision(self, revision: int | str | None) -> None:
        value = max(0, normalize_int(revision))
        with self._cursor_lock:
            self._sync_authority_revision = value

    def sync_authority_revision(self) -> int:
        with self._cursor_lock:
            return max(0, int(getattr(self, "_sync_authority_revision", 0) or 0))


logger = logging.getLogger(__name__)


def _strict_items(
    payload: dict[str, Any],
    *,
    label: str,
    row_keys: set[str],
) -> list[dict[str, Any]]:
    if set(payload) != {"items"} or not isinstance(payload.get("items"), list):
        raise RuntimeError(f"Invalid {label} response contract")
    rows: list[dict[str, Any]] = []
    for item in payload["items"]:
        if not isinstance(item, dict) or set(item) != row_keys:
            raise RuntimeError(f"Invalid {label} row contract")
        if not isinstance(item.get("material_number"), str) or not isinstance(
            item.get("name"), str
        ):
            raise RuntimeError(f"Invalid {label} row contract")
        # Usage UOM is optional server metadata. The operational UOM is
        # hydrated from the imported Excel workbooks, so JSON null is valid.
        if (
            "uom" in row_keys
            and item.get("uom") is not None
            and not isinstance(item.get("uom"), str)
        ):
            raise RuntimeError(f"Invalid {label} row contract")
        rows.append(dict(item))
    return rows


class RemoteTrackingCatalogMixin:
    def _catalog_cache_ttl(self) -> float:
        return float(get_cache_ttl().catalog)

    def list_stored_products(self) -> list[dict[str, Any]]:
        # contracts/api.json authorizes this route with catalog.stored.view.
        self._require_server_permission("catalog.stored.view")

        def _load() -> list[dict[str, Any]]:
            data = self._safe_json(self._req("GET", Routes.CATALOG_STORED_PRODUCTS))
            return [
                normalize_stored_product(item)
                for item in _strict_items(
                    data,
                    label="stored products",
                    row_keys={"material_number", "name"},
                )
            ]

        return list(self._cached("catalog_products", self._catalog_cache_ttl(), _load))

    def _default_branch_id(self) -> str:
        active = normalize_text(safe_get(self.user, "active_branch"))
        if active and self._server_can_access_branch(active):
            return active
        branches = self._known_scope_branches()
        return normalize_text(branches[0]) if branches else ""

    def list_usage_products(
        self,
        *,
        force_refresh: bool = False,
        branch_id: str | None = None,
    ) -> list[dict[str, Any]]:
        # contracts/api.json authorizes this route with catalog.usage.view and
        # declares no request schema/branch parameter. Branch/scope filtering is
        # therefore server-authoritative; the desktop must not suppress rows
        # locally before the request is sent.
        self._require_server_permission("catalog.usage.view")
        del branch_id

        cache_key = "usage_products"

        def _load() -> list[dict[str, Any]]:
            data = self._safe_json(self._req("GET", Routes.CATALOG_USAGE_PRODUCTS))
            return [
                normalize_usage_product(item)
                for item in _strict_items(
                    data,
                    label="usage products",
                    row_keys={"material_number", "name", "uom"},
                )
            ]

        if force_refresh:
            self._invalidate_prefix(cache_key)
            value = list(_load())
            with self._request_lock:
                self._memo[cache_key] = (time.monotonic(), value)
            return value
        return list(self._cached(cache_key, self._catalog_cache_ttl(), _load))

    def stored_snapshot(self) -> dict[str, str]:
        rows = self.list_stored_products()
        self._stored_cache = {
            normalize_text(row.get("material_number")): normalize_text(row.get("name"))
            for row in rows
            if normalize_text(row.get("material_number"))
        }
        return dict(self._stored_cache)


_REQUIRED_TRACKING_RESPONSE_KEYS = {
    "id",
    "branch_id",
    "material_number",
    "material_name",
    "quantity",
    "production_date",
    "expiry_date",
    "notes",
    "responsible_user_id",
    "revision",
    "is_deleted",
    "created_at",
    "updated_at",
    "deleted_at",
    "deleted_by",
    "created_by",
    "updated_by",
}
_OPTIONAL_TRACKING_RESPONSE_KEYS: set[str] = set()


def _strict_tracking_item(payload: Any) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise RuntimeError("Invalid tracking item response contract")
    missing = _REQUIRED_TRACKING_RESPONSE_KEYS - set(payload)
    unknown = set(payload) - _REQUIRED_TRACKING_RESPONSE_KEYS - _OPTIONAL_TRACKING_RESPONSE_KEYS
    if missing or unknown:
        raise RuntimeError(
            f"Invalid tracking item response contract: missing={sorted(missing)} unknown={sorted(unknown)}"
        )
    return dict(payload)


class RemoteTrackingItemsMixin:
    def _tracking_row(self, item_id: str, branch_id: str) -> dict[str, Any]:
        for row in self.list_items(branch_filter=branch_id):
            row_id = normalize_remote_id(row) or normalize_text(row.get("id"))
            if row_id == item_id:
                return dict(row)
        raise RuntimeError(
            "Tracking item is unavailable; synchronization is required before editing"
        )

    def _push_tracking_mutation(self, *, operation: str, item: dict[str, Any]) -> dict[str, Any]:
        # ``/sync/push`` is an authenticated transport, not an independently
        # grantable capability.  The server authorizes each mutation using its
        # matching tracking permission and the destination branch scope.  Do
        # not require a fictitious ``sync.push`` permission here: production
        # roles correctly receive ``tracking.create/update/delete`` and would
        # otherwise be rejected by the desktop before the server can evaluate
        # the legitimate mutation.
        operation_id = str(uuid4())
        payload = {
            "operation_id": operation_id,
            "device_id": get_or_create_device_id(),
            "operations": [{"operation": operation, "item": item}],
        }
        data = self._safe_json(
            self._req(
                "POST", Routes.SYNC_PUSH, json=payload, headers={"Idempotency-Key": operation_id}
            )
        )
        expected = {
            "ok",
            "operation_id",
            "accepted",
            "conflicts",
            "rejected",
            "server_cursor",
            "server_time",
        }
        if (
            not isinstance(data, dict)
            or set(data) != expected
            or data.get("operation_id") != operation_id
        ):
            raise RuntimeError("Invalid sync push response contract")
        if data["conflicts"]:
            first = data["conflicts"][0]
            raise RuntimeError(
                str(first.get("detail") or first.get("code") or "Tracking revision conflict")
            )
        if data["rejected"]:
            first = data["rejected"][0]
            raise RuntimeError(
                str(first.get("detail") or first.get("code") or "Tracking mutation rejected")
            )
        if len(data["accepted"]) != 1 or not isinstance(data["accepted"][0], dict):
            raise RuntimeError("Sync push did not return one accepted mutation")
        authoritative = data["accepted"][0].get("item")
        if not isinstance(authoritative, dict):
            raise RuntimeError("Sync push did not return the authoritative tracking item")
        self.invalidate_tracking_cache(normalize_text(item.get("branch_id")))
        return _strict_tracking_item(authoritative)

    def add_item(
        self,
        *,
        branch: str,
        material_number: str,
        material_name: str,
        quantity: int | str,
        production_date: str,
        expiry_date: str,
    ) -> dict[str, Any]:
        resolved_branch = normalize_text(branch)
        if not resolved_branch or resolved_branch.casefold() == "all":
            raise ValueError("A branch is required")
        # Branch authorization is deliberately evaluated by the authoritative
        # ``/sync/push`` transaction.  A desktop permission snapshot can be
        # stale while an administrator changes scope; rejecting here made a
        # valid branch-specific Add click appear inert even though the server
        # would accept it.  The client supplies a concrete branch id only; the
        # API validates both ``tracking.create`` and that branch atomically.
        material = normalize_text(material_number)
        if not material:
            raise RuntimeError("Material number is required")
        name = normalize_text(material_name, material)
        row = self._push_tracking_mutation(
            operation="create",
            item={
                "id": str(uuid4()),
                "branch_id": resolved_branch,
                "material_number": material,
                "material_name": name,
                "quantity": normalize_int(quantity),
                "production_date": normalize_text(production_date) or None,
                "expiry_date": normalize_text(expiry_date) or None,
                "notes": "",
                "responsible_user_id": None,
                "base_revision": 0,
                "is_deleted": False,
            },
        )
        item = normalize_tracking_item(row, stored_name=name)
        item["doc_id"] = str(row["id"])
        return item

    def update_item(
        self,
        *,
        branch: str,
        doc_id: str,
        material_number: str,
        quantity: int | str,
        production_date: str,
        expiry_date: str,
        revision: int | None = None,
    ) -> dict[str, Any]:
        self._require_server_permission("tracking.update")
        branch_id = normalize_text(branch)
        item_id = normalize_remote_id({"id": doc_id}) or normalize_text(doc_id)
        if not branch_id or not self._server_can_access_branch(branch_id):
            raise PermissionError("Branch outside server-authorized scope")
        if not item_id:
            raise RuntimeError("Item id is required")
        current = self._tracking_row(item_id, branch_id)
        expected_revision = int(revision or current.get("revision") or 0)
        if expected_revision <= 0:
            raise RuntimeError("Tracking revision is required")
        material = normalize_text(material_number)
        name = normalize_text(self.stored_snapshot().get(material), material)
        row = self._push_tracking_mutation(
            operation="update",
            item={
                "id": item_id,
                "branch_id": branch_id,
                "material_number": material,
                "material_name": name,
                "quantity": normalize_int(quantity),
                "production_date": normalize_text(production_date) or None,
                "expiry_date": normalize_text(expiry_date) or None,
                "notes": normalize_text(current.get("notes")),
                "responsible_user_id": current.get("responsible_user_id"),
                "base_revision": expected_revision,
                "is_deleted": False,
            },
        )
        item = normalize_tracking_item(row, stored_name=name)
        item["doc_id"] = str(row["id"])
        return item

    def delete_item(
        self, *, branch: str, doc_id: str, revision: int | None = None
    ) -> dict[str, Any]:
        self._require_server_permission("tracking.delete")
        branch_id = normalize_text(branch)
        item_id = normalize_remote_id({"id": doc_id}) or normalize_text(doc_id)
        if not branch_id or not self._server_can_access_branch(branch_id):
            raise PermissionError("Branch outside server-authorized scope")
        if not item_id:
            raise RuntimeError("Item id is required")
        current = self._tracking_row(item_id, branch_id)
        expected_revision = int(revision or current.get("revision") or 0)
        row = self._push_tracking_mutation(
            operation="delete",
            item={
                "id": item_id,
                "branch_id": branch_id,
                "material_number": normalize_text(current.get("material_number")),
                "material_name": normalize_text(current.get("material_name")),
                "quantity": normalize_int(current.get("quantity")),
                "production_date": current.get("production_date"),
                "expiry_date": current.get("expiry_date"),
                "notes": normalize_text(current.get("notes")),
                "responsible_user_id": current.get("responsible_user_id"),
                "base_revision": expected_revision,
                "is_deleted": True,
            },
        )
        return {
            "id": str(row["id"]),
            "revision": int(row["revision"]),
            "deleted": bool(row["is_deleted"]),
        }

    def list_items(
        self, branch_id: str | None = None, *, branch_filter: str | None = None
    ) -> list[dict[str, Any]]:
        if not self._server_has_permission("tracking.view"):
            return []
        branch = normalize_text(branch_filter if branch_filter is not None else branch_id)
        if branch and not self._server_can_access_branch(branch):
            return []
        cache_key = f"items:{branch.casefold()}" if branch else "items:all"

        def _load() -> list[dict[str, Any]]:
            params = {"branch_id": branch} if branch else None
            data = self._safe_json(self._req("GET", Routes.TRACKING_ITEMS, params=params))
            if (
                not isinstance(data, dict)
                or set(data) != {"items", "next_cursor"}
                or not isinstance(data["items"], list)
            ):
                raise RuntimeError("Invalid tracking list response contract")
            names = self.stored_snapshot()
            rows = []
            for raw in data["items"]:
                row = _strict_tracking_item(raw)
                material = normalize_text(row["material_number"])
                normalized = normalize_tracking_item(
                    row,
                    stored_name=normalize_text(names.get(material), row["material_name"]),
                )
                normalized["doc_id"] = str(row["id"])
                rows.append(normalized)
            return rows

        return list(self._cached(cache_key, self._metadata_cache_ttl(), _load))

    def snapshot_items(
        self, branch_id: str | None = None, *, branch_filter: str | None = None
    ) -> list[dict[str, Any]]:
        requested = normalize_text(branch_filter if branch_filter is not None else branch_id)
        return self.list_items(branch_filter=requested) if requested else self.list_items()


logger = logging.getLogger(__name__)


class CloudTrackingService:
    def __init__(self, id_token: str | None = None, user: Any = None, base_url: str | None = None):
        super().__init__()
        self.base_url = (
            get_server_base_url() if not str(base_url or "").strip() else str(base_url).rstrip("/")
        )
        self.id_token = id_token
        self.user = _user_to_dict(user)
        self._session_lock = threading.RLock()
        self._thread_local = threading.local()
        self._sessions: list[requests.Session] = []
        self._realtime_lock = threading.RLock()
        self._stored_cache: dict[str, str] = {}
        self._cursor_lock = threading.RLock()
        self._cursor: int = 0
        self._sync_authority_revision: int = 0
        self._rt_stop = threading.Event()
        self._rt_thread: threading.Thread | None = None
        self._rt_session: requests.Session | None = None
        self._rt_response: requests.Response | None = None
        self._items_truncated: bool = False
        self._callback_bridge = CallbackBridge()
        self._closed = False

    def _headers(self) -> dict[str, str]:
        binding = get_server_binding()
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Client-Version": binding.client_version,
            "X-Client-Architecture": binding.client_architecture,
            "X-API-Contract-SHA256": binding.api_contract_sha256,
        }
        if self.id_token:
            headers["Authorization"] = f"Bearer {self.id_token}"
        return dict(_headers_with_release_identity({"headers": headers})["headers"])

    def _ensure_open(self) -> None:
        if bool(getattr(self, "_closed", False)):
            raise RuntimeError("Cloud tracking service is closed")

    def _new_session(self) -> requests.Session:
        self._ensure_open()
        return create_configured_session()

    def _thread_session(self) -> requests.Session:
        self._ensure_open()
        session = getattr(self._thread_local, "session", None)
        if session is not None:
            return session
        session = self._new_session()
        setattr(self._thread_local, "session", session)
        with self._session_lock:
            self._sessions.append(session)
        return session

    def _request_with_session(self, method: str, url: str, **kwargs) -> requests.Response:
        return request_with_retry(
            method,
            url,
            session=self._thread_session(),
            timeout=current_http_timeout(),
            verify=current_requests_verify(),
            **kwargs,
        )

    def _realtime_get(self, session: requests.Session, url: str, **kwargs):
        connect_timeout = max(3.0, current_http_timeout())
        # The server heartbeat is 15 seconds; keep the read timeout comfortably
        # above it so an idle but healthy SSE connection is not recycled.
        stream_timeout = (connect_timeout, max(45.0, connect_timeout * 4.0))
        response = session.get(
            url,
            timeout=stream_timeout,
            verify=current_requests_verify(),
            allow_redirects=False,
            **kwargs,
        )
        try:
            _validate_response_release_identity(response, url)
        except RemoteRequestError:
            response.close()
            raise
        return response

    def _resolve_request_url(self, path: str) -> str:
        return resolve_api_url(path, base_url=self.base_url)

    def _req(self, method: str, path: str, **kwargs) -> requests.Response:
        url = self._resolve_request_url(path)
        merged_headers = self._headers()
        merged_headers.update(dict(kwargs.pop("headers", {}) or {}))
        kwargs["headers"] = merged_headers
        logger.info("Tracking API: %s %s -> %s", method, path, redact_url_for_log(url))
        try:
            response = self._request_with_session(method, url, **kwargs)
            logger.info("Tracking API response: %s", response.status_code)
            return response
        except SERVICE_OPERATION_EXCEPTIONS as e:
            logger.error("Tracking API error: %s %s - %s", method, path, e)
            raise

    def _reset_realtime_worker(self) -> None:
        # A new SSE owner is not allowed until the previous transport is fully
        # closed. This preserves the one-connection invariant across logout,
        # token refresh, authority changes, and reconnects.
        if not self.stop_realtime():
            raise RuntimeError("Previous realtime worker did not terminate cleanly")
        with self._realtime_lock:
            self._rt_stop = threading.Event()
            self._rt_thread = None
            self._rt_session = None
            self._rt_response = None

    def _register_realtime_transport(
        self, session: requests.Session, response: requests.Response
    ) -> bool:
        with self._realtime_lock:
            if self._rt_stop.is_set():
                return False
            self._rt_session = session
            self._rt_response = response
            return True

    def _clear_realtime_transport(
        self, session: requests.Session, response: requests.Response
    ) -> None:
        with self._realtime_lock:
            if self._rt_response is response:
                self._rt_response = None
            if self._rt_session is session:
                self._rt_session = None

    def _start_realtime_worker(self, target) -> None:
        def _runner() -> None:
            try:
                target()
            finally:
                with self._realtime_lock:
                    if self._rt_thread is threading.current_thread():
                        self._rt_thread = None

        with self._realtime_lock:
            if self._rt_thread is not None and self._rt_thread.is_alive():
                raise RuntimeError("Realtime worker is already running")
            thread = threading.Thread(
                target=_runner,
                name="herfy-realtime-sse",
                daemon=True,
            )
            self._rt_thread = thread
            thread.start()

    def close(self) -> None:
        with self._session_lock:
            if self._closed:
                return
            self._closed = True
        self.stop_realtime()
        with self._session_lock:
            sessions = list(getattr(self, "_sessions", []) or [])
            self._sessions.clear()
        for session in sessions:
            try:
                session.close()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Session close failed", exc_info=True)


class RemoteApiTrackingMixin(
    RemoteTrackingMetadataMixin,
    RemoteTrackingCatalogMixin,
    RemoteTrackingItemsMixin,
    RemoteTrackingSyncMixin,
):
    """Composition surface for tracking-related remote API responsibilities."""


logger = logging.getLogger(__name__)
__all__ = ["ApiClient"]


class ApiClient(
    RemoteApiCacheMixin,
    RemoteApiAdminMixin,
    RemoteApiTrackingMixin,
    RemoteRealtimeMixin,
    CloudTrackingService,
):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.init_remote_cache()
        logger.info("ApiClient initialized with base_url: %s", redact_url_for_log(self.base_url))

    def _safe_json(self, response) -> dict:
        try:
            try:
                data = response.json()
            except json.JSONDecodeError as exc:
                raise RuntimeError(canonical_error_message("malformed_response")) from exc
            except SERVICE_OPERATION_EXCEPTIONS as exc:
                raise RuntimeError(canonical_error_message("invalid_response")) from exc
            return data if isinstance(data, dict) else {}
        finally:
            close = getattr(response, "close", None)
            if callable(close):
                close()
