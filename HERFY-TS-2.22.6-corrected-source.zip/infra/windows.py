from __future__ import annotations

import base64
import html
import importlib.util
import logging
import os
import shutil
import subprocess
import sys
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from core.models import parse_bool
from core.settings import APP_DESKTOP_APP_ID, APP_DISPLAY_NAME, resource_path, source_root_dir


class RegistryBackend(Protocol):
    def set_value(self, name: str, value: str) -> None: ...
    def get_value(self, name: str) -> str | None: ...
    def delete_value(self, name: str) -> None: ...


class WindowsRunRegistryBackend:
    KEY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"

    def __init__(self) -> None:
        if os.name != "nt":
            raise OSError("Windows registry is only available on Windows")
        import winreg

        self._winreg = winreg

    def set_value(self, name: str, value: str) -> None:
        with self._winreg.OpenKey(
            self._winreg.HKEY_CURRENT_USER, self.KEY_PATH, 0, self._winreg.KEY_SET_VALUE
        ) as key:
            self._winreg.SetValueEx(key, name, 0, self._winreg.REG_SZ, value)

    def get_value(self, name: str) -> str | None:
        try:
            with self._winreg.OpenKey(
                self._winreg.HKEY_CURRENT_USER,
                self.KEY_PATH,
                0,
                self._winreg.KEY_QUERY_VALUE,
            ) as key:
                value, _ = self._winreg.QueryValueEx(key, name)
                return str(value)
        except FileNotFoundError:
            return None

    def delete_value(self, name: str) -> None:
        try:
            with self._winreg.OpenKey(
                self._winreg.HKEY_CURRENT_USER,
                self.KEY_PATH,
                0,
                self._winreg.KEY_SET_VALUE,
            ) as key:
                self._winreg.DeleteValue(key, name)
        except FileNotFoundError:
            return


@dataclass(slots=True)
class AutostartService:
    app_name: str
    command: str
    backend: RegistryBackend

    def enable(self) -> None:
        self.backend.set_value(self.app_name, self.command)

    def disable(self) -> None:
        self.backend.delete_value(self.app_name)

    def is_enabled(self) -> bool:
        return self.backend.get_value(self.app_name) == self.command


def _quote(value: Path | str) -> str:
    return f'"{value}"'


def build_autostart_command() -> str:
    """Build the one canonical Windows startup command."""
    if getattr(sys, "frozen", False):
        executable = Path(sys.executable).resolve()
        return f"{_quote(executable)} --background"
    executable = Path(sys.executable).resolve()
    pythonw = executable.with_name("pythonw.exe")
    if pythonw.exists():
        executable = pythonw
    return f"{_quote(executable)} {_quote(source_root_dir() / 'main.py')} --background"


def sync_startup_from_preferences(preferences: Mapping[str, bool]) -> bool:
    if os.name != "nt":
        return False
    enabled = parse_bool(preferences.get("start_with_windows"), True)
    service = AutostartService(
        app_name=APP_DISPLAY_NAME,
        command=build_autostart_command(),
        backend=WindowsRunRegistryBackend(),
    )
    if enabled:
        service.enable()
    else:
        service.disable()
    return service.is_enabled() if enabled else not service.is_enabled()


logger = logging.getLogger(__name__)
_toast_registration_verified: bool | None = None


@dataclass(frozen=True)
class WindowsToastResult:
    delivered: bool
    backend: str
    detail: str = ""


def _powershell_executable() -> str | None:
    for candidate in ("powershell.exe", "powershell", "pwsh.exe", "pwsh"):
        resolved = shutil.which(candidate)
        if resolved:
            return resolved
    return None


def _encoded_powershell(script: str) -> str:
    return base64.b64encode(script.encode("utf-16le")).decode("ascii")


def _toast_logo_uri() -> str:
    """Return the packaged HERFY mark as a local URI for WinRT toast XML."""
    try:
        logo = Path(resource_path("resources", "images", "logo.png")).resolve()
        return logo.as_uri() if logo.is_file() else ""
    except (OSError, ValueError):
        return ""


def _win11toast_available() -> bool:
    """Check the optional native toast package without importing WinRT at startup."""
    return bool(importlib.util.find_spec("win11toast"))


def _send_win11toast(
    *,
    title: str,
    message: str,
    app_id: str = APP_DESKTOP_APP_ID,
    activation_uri: str = "",
) -> WindowsToastResult:
    """Submit a Windows 11 toast through the maintained WinRT package.

    ``notify`` submits immediately; unlike ``toast`` it does not wait for the
    operator to dismiss a notification, so it is safe in the bounded desktop
    notification worker.  The application owns sound playback through
    QSoundEffect after delivery, therefore the native toast is kept silent to
    prevent two competing audio cues.
    """
    if os.name != "nt":
        return WindowsToastResult(False, "win11toast", "not_windows")
    if not _win11toast_available():
        return WindowsToastResult(False, "win11toast", "library_unavailable")
    if _toast_registration_verified is not True and not verify_windows_toast_registration():
        return WindowsToastResult(False, "win11toast", "start_menu_registration_invalid")
    try:
        from win11toast import notify

        notify(
            title=str(title or APP_DISPLAY_NAME),
            body=str(message or ""),
            on_click=str(activation_uri or "") or None,
            icon=_toast_logo_uri() or None,
            audio={"silent": "true"},
            app_id=str(app_id or APP_DESKTOP_APP_ID),
        )
        logger.info("WINDOWS_TOAST_WIN11TOAST=PASS app_id=%s", app_id)
        return WindowsToastResult(True, "win11toast", "submitted")
    except Exception as exc:  # WinRT exposes platform-specific exception classes.
        logger.warning("WINDOWS_TOAST_WIN11TOAST=FAIL reason=%s", type(exc).__name__)
        return WindowsToastResult(False, "win11toast", f"{type(exc).__name__}: {exc}")


def _toast_script(*, title: str, message: str, app_id: str, activation_uri: str = "") -> str:
    safe_title = html.escape(str(title or APP_DISPLAY_NAME), quote=False)
    safe_message = html.escape(str(message or ""), quote=False)
    safe_app_id = str(app_id or APP_DESKTOP_APP_ID).replace("'", "''")
    safe_activation = html.escape(str(activation_uri or "").strip(), quote=True)
    safe_logo_uri = html.escape(_toast_logo_uri(), quote=True)
    toast_open = (
        f'<toast activationType="protocol" launch="{safe_activation}">'
        if safe_activation
        else "<toast>"
    )
    xml = (
        toast_open
        + '<visual><binding template="ToastGeneric">'
        + (
            f'<image placement="appLogoOverride" hint-crop="circle" src="{safe_logo_uri}"/>'
            if safe_logo_uri
            else ""
        )
        + f"<text>{safe_title}</text><text>{safe_message}</text>"
        "</binding></visual>"
                '<audio silent="true" />'
        "</toast>"
    ).replace("'", "''")
    return f"""
$ErrorActionPreference = 'Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null
$xml = New-Object Windows.Data.Xml.Dom.XmlDocument
$xml.LoadXml('{xml}')
$toast = [Windows.UI.Notifications.ToastNotification]::new($xml)
$notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{safe_app_id}')
$notifier.Show($toast)
"HERFY_WINDOWS_TOAST_SENT=PASS"
""".strip()


def _send_winrt_toast(
    *,
    title: str,
    message: str,
    app_id: str = APP_DESKTOP_APP_ID,
    timeout_seconds: float = 6.0,
    activation_uri: str = "",
) -> WindowsToastResult:
    """Send the preferred actionable Windows toast through WinRT.

    The installed Start-menu shortcut owns the AppUserModelID. When that
    registration is unavailable we return a structured failure; the GUI layer
    then uses the Qt system-tray notification fallback on the GUI thread.
    """
    if os.name != "nt":
        return WindowsToastResult(False, "windows_winrt", "not_windows")

    global _toast_registration_verified
    if _toast_registration_verified is not True and not verify_windows_toast_registration():
        return WindowsToastResult(False, "windows_winrt", "start_menu_registration_invalid")

    powershell = _powershell_executable()
    if not powershell:
        logger.error("WINDOWS_TOAST_WINRT=FAIL reason=powershell_not_found")
        return WindowsToastResult(False, "windows_winrt", "powershell_not_found")

    script = _toast_script(
        title=title,
        message=message,
        app_id=app_id,
        activation_uri=activation_uri,
    )
    startupinfo = None
    if hasattr(subprocess, "STARTUPINFO"):
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0
    try:
        completed = subprocess.run(
            [
                powershell,
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-EncodedCommand",
                _encoded_powershell(script),
            ],
            capture_output=True,
            text=True,
            timeout=max(1.0, float(timeout_seconds)),
            startupinfo=startupinfo,
            creationflags=int(getattr(subprocess, "CREATE_NO_WINDOW", 0)),
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.exception("WINDOWS_TOAST_WINRT=FAIL")
        return WindowsToastResult(False, "windows_winrt", f"{type(exc).__name__}: {exc}")

    output = "\n".join(part for part in (completed.stdout, completed.stderr) if part).strip()
    if completed.returncode == 0 and "HERFY_WINDOWS_TOAST_SENT=PASS" in output:
        logger.info("WINDOWS_TOAST_WINRT=PASS app_id=%s", app_id)
        return WindowsToastResult(True, "windows_winrt", "sent")
    detail = output[-1000:] if output else f"exit_code={completed.returncode}"
    logger.error("WINDOWS_TOAST_WINRT=FAIL detail=%s", detail)
    return WindowsToastResult(False, "windows_winrt", detail)


def send_windows_toast(
    *,
    title: str,
    message: str,
    app_id: str = APP_DESKTOP_APP_ID,
    timeout_seconds: float = 6.0,
    activation_uri: str = "",
) -> WindowsToastResult:
    """Deliver one actionable Windows toast through the native WinRT path.

    Qt tray fallback is deliberately owned by ``DesktopNotifier`` so fallback
    UI work always executes on the GUI thread.
    """
    if os.name != "nt":
        return WindowsToastResult(False, "windows_notification", "not_windows")

    packaged = _send_win11toast(
        title=title,
        message=message,
        app_id=app_id,
        activation_uri=activation_uri,
    )
    if packaged.delivered:
        return packaged
    winrt = _send_winrt_toast(
        title=title,
        message=message,
        app_id=app_id,
        timeout_seconds=timeout_seconds,
        activation_uri=activation_uri,
    )
    if winrt.delivered:
        return winrt
    return WindowsToastResult(
        False,
        "windows_notification",
        f"winrt={winrt.detail}",
    )


def start_menu_shortcut_candidates() -> tuple[Path, ...]:
    if os.name != "nt":
        return ()
    candidates: list[Path] = []
    program_data = str(os.environ.get("PROGRAMDATA") or "").strip()
    appdata = str(os.environ.get("APPDATA") or "").strip()
    if program_data:
        programs = Path(program_data) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        candidates.extend((programs / "HERFY-TS" / "HERFY-TS.lnk", programs / "HERFY-TS.lnk"))
    if appdata:
        programs = Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs"
        candidates.extend((programs / "HERFY-TS" / "HERFY-TS.lnk", programs / "HERFY-TS.lnk"))
    return tuple(candidates)


def verify_windows_toast_registration() -> bool:
    """Verify and cache the installed Start-menu identity used by WinRT Toast."""
    global _toast_registration_verified
    if os.name != "nt":
        _toast_registration_verified = False
        return False
    powershell = _powershell_executable()
    if not powershell:
        logger.error("WINDOWS_TOAST_REGISTERED=FAIL reason=powershell_not_found")
        _toast_registration_verified = False
        return False
    shortcut = next((path for path in start_menu_shortcut_candidates() if path.is_file()), None)
    if shortcut is None:
        logger.error("WINDOWS_TOAST_REGISTERED=FAIL reason=start_menu_shortcut_missing")
        _toast_registration_verified = False
        return False
    escaped = str(shortcut).replace("'", "''")
    script = f"""
$ErrorActionPreference = 'Stop'
$p = '{escaped}'
$folder = Split-Path -Parent $p
$name = Split-Path -Leaf $p
$shell = New-Object -ComObject Shell.Application
$item = $shell.Namespace($folder).ParseName($name)
if ($null -eq $item) {{ throw 'shortcut_not_resolved' }}
$id = [string]$item.ExtendedProperty('System.AppUserModel.ID')
$id
""".strip()
    try:
        completed = subprocess.run(
            [
                powershell,
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-EncodedCommand",
                _encoded_powershell(script),
            ],
            capture_output=True,
            text=True,
            timeout=5.0,
            creationflags=int(getattr(subprocess, "CREATE_NO_WINDOW", 0)),
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        logger.error("WINDOWS_TOAST_REGISTERED=FAIL reason=%s", type(exc).__name__)
        _toast_registration_verified = False
        return False
    actual = str(completed.stdout or "").strip().splitlines()[-1:]
    app_id = actual[0].strip() if actual else ""
    if completed.returncode == 0 and app_id == APP_DESKTOP_APP_ID:
        _toast_registration_verified = True
        logger.info("WINDOWS_TOAST_REGISTERED=PASS app_id=%s", APP_DESKTOP_APP_ID)
        return True
    logger.error(
        "WINDOWS_TOAST_REGISTERED=FAIL expected=%s actual=%s exit_code=%s",
        APP_DESKTOP_APP_ID,
        app_id,
        completed.returncode,
    )
    _toast_registration_verified = False
    return False


def windows_notification_capability() -> dict[str, object]:
    """Return non-delivery diagnostics for the installed Windows toast path.

    This does not claim that a visual toast was shown. It verifies only the
    prerequisites that can be checked deterministically without sending one.
    """
    if os.name != "nt":
        return {
            "windows": False,
            "winrt_registered": False,
            "powershell": False,
            "win11toast": False,
        }
    powershell = bool(_powershell_executable())
    win11toast = _win11toast_available()
    registered = (
        bool(_toast_registration_verified)
        if _toast_registration_verified is not None
        else bool(verify_windows_toast_registration())
    )
    return {
        "windows": True,
        "winrt_registered": registered,
        "powershell": powershell,
        "win11toast": win11toast,
    }
