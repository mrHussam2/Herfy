from __future__ import annotations

import base64
import ctypes
import json
import logging
import os
import sqlite3
import tempfile
import threading
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import (
    best_product_name,
    call_if_callable,
    change_entity,
    change_operation,
    change_payload,
    deduplicate_tracking_records,
    normalize_int,
    normalize_remote_id,
    normalize_text,
    normalize_tracking_item,
    safe_get,
    tracking_record_identity_keys,
)
from core.settings import db_file_path, get_cache_ttl, runtime_cache_path
from infra.files import read_json_dict, write_json_dict


class SerializedCursor:
    def __init__(self, cursor, lock: threading.RLock):
        self._cursor = cursor
        self._lock = lock

    def execute(self, *args, **kwargs):
        with self._lock:
            return self._cursor.execute(*args, **kwargs)

    def executemany(self, *args, **kwargs):
        with self._lock:
            return self._cursor.executemany(*args, **kwargs)

    def fetchone(self, *args, **kwargs):
        with self._lock:
            return self._cursor.fetchone(*args, **kwargs)

    def fetchall(self, *args, **kwargs):
        with self._lock:
            return self._cursor.fetchall(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._cursor, name)


class SerializedConnection:
    def __init__(self, connection, lock: threading.RLock):
        self._connection = connection
        self._lock = lock

    def cursor(self, *args, **kwargs):
        with self._lock:
            return SerializedCursor(self._connection.cursor(*args, **kwargs), self._lock)

    def execute(self, *args, **kwargs):
        with self._lock:
            return self._connection.execute(*args, **kwargs)

    def executemany(self, *args, **kwargs):
        with self._lock:
            return self._connection.executemany(*args, **kwargs)

    def commit(self):
        with self._lock:
            return self._connection.commit()

    def rollback(self):
        with self._lock:
            return self._connection.rollback()

    def close(self):
        with self._lock:
            return self._connection.close()

    def __getattr__(self, name):
        return getattr(self._connection, name)


def _configure_connection(conn: sqlite3.Connection) -> sqlite3.Connection:
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=60000")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA wal_autocheckpoint=500")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA locking_mode=NORMAL")
    return conn


class SQLiteEngine:
    """Single SQLite connection owner. It owns schema/connection lifecycle only."""

    def __init__(self, *, db_path_override: str | Path | None = None):
        path_input = db_path_override if db_path_override is not None else db_file_path()
        self.db_path = Path(path_input)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        raw = _configure_connection(
            sqlite3.connect(
                self.db_path, timeout=90.0, check_same_thread=False, isolation_level=None
            )
        )
        self.connection = SerializedConnection(raw, self.lock)
        self.apply_migrations()

    def fresh_connection(self) -> sqlite3.Connection:
        return _configure_connection(
            sqlite3.connect(self.db_path, timeout=90.0, isolation_level=None)
        )

    def apply_migrations(self) -> None:
        """Apply each local schema migration once, in its recorded order."""
        c = self.connection.cursor()
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS local_schema_migrations(
                version INTEGER PRIMARY KEY,
                applied_at TEXT NOT NULL
            )
            """
        )
        applied = {
            int(row[0])
            for row in c.execute("SELECT version FROM local_schema_migrations").fetchall()
        }
        migrations = (
            (1, self._create_initial_schema),
            (2, self._add_notification_acknowledger),
        )
        for version, migration in migrations:
            if version in applied:
                continue
            try:
                c.execute("BEGIN IMMEDIATE")
                migration(c)
                c.execute(
                    "INSERT INTO local_schema_migrations(version, applied_at) VALUES (?, ?)",
                    (version, datetime.now(timezone.utc).isoformat(timespec="seconds")),
                )
                c.execute("COMMIT")
            except sqlite3.Error:
                self.connection.rollback()
                raise

    @staticmethod
    def _create_initial_schema(c: SerializedCursor) -> None:
        c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
        c.execute(
            """CREATE TABLE IF NOT EXISTS cloud_tracked_products(
            id TEXT PRIMARY KEY,
            branch TEXT DEFAULT '',
            material_number TEXT DEFAULT '',
            expiry_date TEXT DEFAULT '',
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )"""
        )
        c.execute(
            "CREATE INDEX IF NOT EXISTS idx_cloud_tracking_branch ON cloud_tracked_products(branch)"
        )
        c.execute(
            "CREATE INDEX IF NOT EXISTS idx_cloud_tracking_material ON cloud_tracked_products(material_number)"
        )
        c.execute(
            "CREATE TABLE IF NOT EXISTS notify_log(key TEXT PRIMARY KEY, last_date TEXT NOT NULL)"
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS alert_state(
            key TEXT PRIMARY KEY,
            last_date TEXT DEFAULT '',
            last_notified_at REAL DEFAULT 0,
            last_seen_at REAL DEFAULT 0,
            fingerprint TEXT DEFAULT '',
            severity_rank INTEGER DEFAULT 0,
            status_text TEXT DEFAULT '',
            notify_count INTEGER DEFAULT 0
        )"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS server_projection(
            context_key TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            revision INTEGER NOT NULL DEFAULT 0,
            payload TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(context_key, entity_type, entity_id)
        )"""
        )
        c.execute(
            "CREATE INDEX IF NOT EXISTS idx_server_projection_context "
            "ON server_projection(context_key, entity_type)"
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS notification_ledger(
            notification_key TEXT PRIMARY KEY,
            state TEXT NOT NULL,
            severity INTEGER NOT NULL,
            last_shown_at TEXT,
            last_payload_hash TEXT,
            shown_count INTEGER NOT NULL DEFAULT 0,
            acknowledged_at TEXT,
            acknowledged_by TEXT DEFAULT ''
            )"""
        )

    @staticmethod
    def _add_notification_acknowledger(c: SerializedCursor) -> None:
        c.execute("PRAGMA table_info(notification_ledger)")
        notification_ledger_cols = [safe_get(row, "name", "") for row in c.fetchall()]
        if "acknowledged_by" not in notification_ledger_cols:
            c.execute("ALTER TABLE notification_ledger ADD COLUMN acknowledged_by TEXT DEFAULT ''")

    def integrity_check(self) -> bool:
        row = self.connection.execute("PRAGMA integrity_check").fetchone()
        return bool(row and str(row[0]).casefold() == "ok")

    def close(self) -> None:
        self.connection.close()


logger = logging.getLogger(__name__)
_PURPOSE = b"HERFY-TS.session.v1"


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_ulong), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _windows_dpapi(raw: bytes, *, protect: bool, purpose: bytes = _PURPOSE) -> bytes:
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    blob_pointer = ctypes.POINTER(_DATA_BLOB)
    for operation in (crypt32.CryptProtectData, crypt32.CryptUnprotectData):
        operation.argtypes = [
            blob_pointer,
            ctypes.c_void_p,
            blob_pointer,
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_ulong,
            blob_pointer,
        ]
        operation.restype = ctypes.c_int
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    # Keep the backing buffers alive until the native DPAPI call returns.
    # A cast pointer alone does not retain the temporary ctypes buffer.
    input_buffer = ctypes.create_string_buffer(raw)
    entropy_buffer = ctypes.create_string_buffer(purpose)
    in_blob = _DATA_BLOB(
        len(raw),
        ctypes.cast(input_buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    out_blob = _DATA_BLOB()
    entropy = _DATA_BLOB(
        len(purpose),
        ctypes.cast(entropy_buffer, ctypes.POINTER(ctypes.c_ubyte)),
    )
    operation = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    operation_name = "CryptProtectData" if protect else "CryptUnprotectData"
    if not operation(
        ctypes.byref(in_blob),
        None,
        ctypes.byref(entropy),
        None,
        None,
        0,
        ctypes.byref(out_blob),
    ):
        raise OSError(f"{operation_name} failed")
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        if out_blob.pbData:
            kernel32.LocalFree(ctypes.cast(out_blob.pbData, ctypes.c_void_p))


def _windows_protect(raw: bytes) -> bytes:
    return _windows_dpapi(raw, protect=True, purpose=_PURPOSE)


def _windows_unprotect(raw: bytes, *, purpose: bytes = _PURPOSE) -> bytes:
    return _windows_dpapi(raw, protect=False, purpose=purpose)


def _protect(raw: bytes) -> tuple[str, bytes]:
    if os.name != "nt":
        raise RuntimeError("HERFY-TS session persistence requires Windows DPAPI")
    try:
        return ("dpapi", _windows_protect(raw))
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        logger.exception("Windows DPAPI session protection failed; session token was not saved")
        raise RuntimeError("Windows DPAPI session protection failed") from exc


def _unprotect(method: str, raw: bytes) -> bytes:
    if method != "dpapi":
        raise ValueError(f"unsupported secure payload method: {method}")
    return _windows_unprotect(raw, purpose=_PURPOSE)


def read_secure_json(path: str | Path) -> dict[str, Any]:
    file_path = Path(path)
    if not file_path.exists():
        return {}
    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return {}
        if payload.get("format") != "secure-json-v1":
            return {}
        method = str(payload.get("method") or "")
        encoded = str(payload.get("payload") or "")
        if not encoded:
            return {}
        raw = base64.b64decode(encoded.encode("ascii"), validate=True)
        plain = _unprotect(method, raw)
        data = json.loads(plain.decode("utf-8"))
        if not isinstance(data, dict):
            return {}
        return data
    except (OSError, UnicodeError, ValueError, TypeError, json.JSONDecodeError):
        logger.warning("Secure session snapshot could not be read: %s", file_path)
        return {}


def write_secure_json(
    path: str | Path, data: dict[str, Any], *, ensure_ascii: bool = False
) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(data, ensure_ascii=ensure_ascii, separators=(",", ":")).encode("utf-8")
    method, protected = _protect(raw)
    payload = {
        "format": "secure-json-v1",
        "method": method,
        "payload": base64.b64encode(protected).decode("ascii"),
    }
    encoded_payload = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            prefix=f".{file_path.name}.",
            suffix=".tmp",
            dir=file_path.parent,
            delete=False,
        ) as handle:
            temp_path = Path(handle.name)
            handle.write(encoded_payload)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temp_path, 0o600)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug(
                "Unable to restrict secure file permissions for %s",
                temp_path,
                exc_info=True,
            )
        temp_path.replace(file_path)
    finally:
        if temp_path is not None and temp_path.exists():
            try:
                temp_path.unlink()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug(
                    "Temporary secure-file cleanup failed: %s",
                    temp_path,
                    exc_info=True,
                )


@dataclass(frozen=True, slots=True)
class SessionSnapshot:
    username: str = ""
    remember: bool = False
    refresh_token: str = ""
    saved_at: int = 0


@dataclass(frozen=True, slots=True)
class LoginFormState:
    username: str = ""
    remember: bool = False


class SessionStore:
    """Single persistence owner for remembered authentication state.

    Only the refresh token is persisted as a secret. Permissions and scope are
    always reconstructed from the server after refresh and are never trusted
    from local storage.
    """

    def __init__(
        self,
        session_file: str | Path | None = None,
        login_form_file: str | Path | None = None,
    ) -> None:
        self.session_file = Path(session_file or runtime_cache_path("session/session_secure.json"))
        self.login_form_file = Path(
            login_form_file or runtime_cache_path("session/login_form_state.json")
        )

    def save(
        self,
        *,
        session: Any,
        profile: Any,
        remember: bool,
        saved_at: int = 0,
    ) -> None:
        if not remember:
            self.clear()
            return
        refresh_token = str(getattr(session, "refresh_token", "") or "").strip()
        username = str(getattr(profile, "username", "") or "").strip()
        if not refresh_token or not username:
            raise ValueError("remembered session requires username and refresh_token")
        write_secure_json(
            self.session_file,
            {
                "username": username,
                "remember": True,
                "refresh_token": refresh_token,
                "saved_at": max(0, int(saved_at or 0)),
            },
            ensure_ascii=False,
        )

    def load_snapshot(self) -> SessionSnapshot | None:
        payload = read_secure_json(self.session_file)
        if not isinstance(payload, dict) or not payload:
            return None
        username = str(payload.get("username") or "").strip()
        refresh_token = str(payload.get("refresh_token") or "").strip()
        remember = bool(payload.get("remember"))
        # Older builds wrote remember=True unconditionally.  The separate
        # login choice is evidence of consent; an orphan token is not.
        choice = self.load_login_form_state()
        if not choice.remember:
            self.clear()
            return None
        if not remember or not username or not refresh_token:
            return None
        try:
            saved_at = max(0, int(payload.get("saved_at") or 0))
        except (TypeError, ValueError):
            saved_at = 0
        return SessionSnapshot(
            username=username,
            remember=True,
            refresh_token=refresh_token,
            saved_at=saved_at,
        )

    def save_login_form_state(self, *, username: str, remember: bool) -> None:
        if not remember:
            self.clear()
            self._unlink(self.login_form_file)
            return
        write_json_dict(
            self.login_form_file,
            {"username": str(username or "").strip(), "remember": bool(remember)},
            ensure_ascii=False,
        )

    def load_login_form_state(self) -> LoginFormState:
        payload = read_json_dict(self.login_form_file)
        if not bool(payload.get("remember")):
            return LoginFormState()
        return LoginFormState(
            username=str(payload.get("username") or "").strip(),
            remember=bool(payload.get("remember")),
        )

    def clear(self) -> None:
        self._unlink(self.session_file)

    @staticmethod
    def _unlink(path: Path) -> None:
        try:
            path.unlink(missing_ok=True)
        except TypeError:
            if path.exists():
                path.unlink()


logger = logging.getLogger(__name__)
_SQLITE_LOCK_MARKERS = (
    "database is locked",
    "database table is locked",
    "database is busy",
    "locked",
)


def _is_sqlite_lock_error(exc: BaseException) -> bool:
    text = str(exc or "").lower()
    return any((marker in text for marker in _SQLITE_LOCK_MARKERS))


class DatabaseSettingsAlertMixin:
    def _run_sqlite_retry(self, action: Callable[[], Any], *, label: str) -> Any:
        main_thread = threading.current_thread() is threading.main_thread()
        attempts = 2 if main_thread else 40
        delay = 0.005 if main_thread else 0.04
        max_delay = 0.02 if main_thread else 1.25
        last_error: BaseException | None = None
        for attempt in range(1, attempts + 1):
            try:
                return action()
            except sqlite3.OperationalError as exc:
                if not _is_sqlite_lock_error(exc):
                    raise
                last_error = exc
                logger.warning(
                    "SQLite busy while %s; retry %s/%s",
                    label,
                    attempt,
                    attempts,
                    exc_info=True,
                )
                time.sleep(delay)
                delay = min(delay * 1.45, max_delay)
        if last_error is not None:
            raise last_error
        return None

    def _open_settings_connection(self):
        opener = getattr(self, "_fresh_connection", None)
        if not callable(opener):
            return self.connection
        return call_if_callable(opener)

    def _close_settings_connection(self, conn) -> None:
        if conn is not getattr(self, "connection", None):
            try:
                conn.close()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Closing settings connection failed", exc_info=True)

    def set_setting(self, key: str, value: str) -> None:
        setting_key = str(key or "").strip()
        if not setting_key:
            return

        def _write() -> None:
            lock = getattr(self, "_db_lock", None)
            if lock is not None:
                with lock:
                    return self._set_setting_once(setting_key, value)
            return self._set_setting_once(setting_key, value)

        try:
            self._run_sqlite_retry(_write, label=f"saving setting {setting_key}")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Saving setting failed: %s", setting_key)

    def _set_setting_once(self, key: str, value: str) -> None:
        conn = self._open_settings_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                "INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",
                (str(key), str(value or "")),
            )
            conn.commit()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            try:
                conn.rollback()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Rollback failed while saving setting", exc_info=True)
            raise
        finally:
            self._close_settings_connection(conn)

    def delete_setting(self, key: str) -> None:
        setting_key = str(key or "").strip()
        if not setting_key:
            return

        def _delete() -> None:
            conn = self._open_settings_connection()
            try:
                conn.execute("BEGIN IMMEDIATE")
                conn.execute("DELETE FROM settings WHERE key=?", (setting_key,))
                conn.commit()
            except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                try:
                    conn.rollback()
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Rollback failed while deleting setting", exc_info=True)
                raise
            finally:
                self._close_settings_connection(conn)

        try:
            self._run_sqlite_retry(_delete, label=f"deleting setting {setting_key}")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Deleting setting failed: %s", setting_key)

    def get_setting(self, key: str, default=None):
        setting_key = str(key or "").strip()
        if not setting_key:
            return default

        def _read():
            conn = self._open_settings_connection()
            try:
                cursor = conn.cursor()
                cursor.execute("SELECT value FROM settings WHERE key=?", (setting_key,))
                row = cursor.fetchone()
                if row:
                    return safe_get(row, "value", default)
                return default
            finally:
                self._close_settings_connection(conn)

        try:
            return self._run_sqlite_retry(_read, label=f"reading setting {setting_key}")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Reading setting failed: %s", setting_key)
            return default

    def replace_server_projection(
        self,
        context_key: str,
        snapshots: dict[str, list[dict[str, Any]]],
    ) -> None:
        context = str(context_key or "").strip()
        if not context:
            raise ValueError("server projection context is required")
        entity_id_keys = {
            "organization": "organization_id",
            "region": "region_id",
            "area": "area_id",
            "branch": "branch_id",
            "stored_product": "material_number",
            "usage_product": "material_number",
        }
        now = datetime.now(timezone.utc).isoformat()

        def _write() -> None:
            conn = self._open_settings_connection()
            try:
                conn.execute("BEGIN IMMEDIATE")
                conn.execute(
                    "DELETE FROM server_projection WHERE context_key=?",
                    (context,),
                )
                for entity_type, rows in snapshots.items():
                    id_key = entity_id_keys.get(str(entity_type))
                    if id_key is None:
                        continue
                    for row in list(rows or []):
                        payload = dict(row or {})
                        # Defensive compatibility for legacy client-side usage rows.
                        # The wire contract remains material_number; normalize the old
                        # local alias before persisting the authoritative projection.
                        if entity_type == "usage_product" and not payload.get("material_number"):
                            legacy_material = str(payload.get("material") or "").strip()
                            if legacy_material:
                                payload["material_number"] = legacy_material
                        entity_id = str(payload.get(id_key) or "").strip()
                        if not entity_id:
                            raise RuntimeError(
                                f"server projection {entity_type} is missing {id_key}"
                            )
                        revision = max(0, int(payload.get("revision") or 0))
                        conn.execute(
                            """
                            INSERT INTO server_projection(
                                context_key, entity_type, entity_id,
                                revision, payload, updated_at
                            ) VALUES(?,?,?,?,?,?)
                            """,
                            (
                                context,
                                entity_type,
                                entity_id,
                                revision,
                                json.dumps(
                                    payload,
                                    ensure_ascii=False,
                                    separators=(",", ":"),
                                    sort_keys=True,
                                ),
                                now,
                            ),
                        )
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                self._close_settings_connection(conn)

        lock = getattr(self, "_db_lock", None)
        if lock is not None:
            with lock:
                self._run_sqlite_retry(_write, label="replacing server projection")
        else:
            self._run_sqlite_retry(_write, label="replacing server projection")

    def apply_server_projection_changes(
        self,
        context_key: str,
        changes: list[dict[str, Any]] | None,
    ) -> int:
        context = str(context_key or "").strip()
        if not context:
            raise ValueError("server projection context is required")
        entity_id_keys = {
            "organization": "organization_id",
            "region": "region_id",
            "area": "area_id",
            "branch": "branch_id",
            "stored_product": "material_number",
            "usage_product": "material_number",
        }
        accepted = [
            dict(event)
            for event in list(changes or [])
            if str((event or {}).get("entity_type") or "") in entity_id_keys
        ]
        if not accepted:
            return 0
        now = datetime.now(timezone.utc).isoformat()

        def _write() -> int:
            conn = self._open_settings_connection()
            count = 0
            try:
                conn.execute("BEGIN IMMEDIATE")
                for event in accepted:
                    entity_type = str(event.get("entity_type") or "")
                    payload = dict(event.get("payload") or {})
                    if entity_type == "usage_product" and not payload.get("material_number"):
                        legacy_material = str(payload.get("material") or "").strip()
                        if legacy_material:
                            payload["material_number"] = legacy_material
                    entity_id = str(
                        event.get("entity_id") or payload.get(entity_id_keys[entity_type]) or ""
                    ).strip()
                    if not entity_id:
                        raise RuntimeError("server projection change is missing entity_id")
                    revision = max(
                        0,
                        int(event.get("revision") or payload.get("revision") or 0),
                    )
                    existing = conn.execute(
                        """
                        SELECT revision FROM server_projection
                        WHERE context_key=? AND entity_type=? AND entity_id=?
                        """,
                        (context, entity_type, entity_id),
                    ).fetchone()
                    current = int(existing["revision"]) if existing else -1
                    if current > revision:
                        continue
                    operation = str(event.get("operation") or "").strip().lower()
                    if operation == "delete":
                        conn.execute(
                            """
                            DELETE FROM server_projection
                            WHERE context_key=? AND entity_type=? AND entity_id=?
                            """,
                            (context, entity_type, entity_id),
                        )
                        count += 1
                        continue
                    conn.execute(
                        """
                        INSERT INTO server_projection(
                            context_key, entity_type, entity_id,
                            revision, payload, updated_at
                        ) VALUES(?,?,?,?,?,?)
                        ON CONFLICT(context_key, entity_type, entity_id)
                        DO UPDATE SET
                            revision=excluded.revision,
                            payload=excluded.payload,
                            updated_at=excluded.updated_at
                        """,
                        (
                            context,
                            entity_type,
                            entity_id,
                            revision,
                            json.dumps(
                                payload,
                                ensure_ascii=False,
                                separators=(",", ":"),
                                sort_keys=True,
                            ),
                            now,
                        ),
                    )
                    count += 1
                conn.commit()
                return count
            except Exception:
                conn.rollback()
                raise
            finally:
                self._close_settings_connection(conn)

        lock = getattr(self, "_db_lock", None)
        if lock is not None:
            with lock:
                return int(
                    self._run_sqlite_retry(_write, label="applying server projection changes") or 0
                )
        return int(self._run_sqlite_retry(_write, label="applying server projection changes") or 0)

    def clear_server_projection(self, context_key: str) -> None:
        context = str(context_key or "").strip()
        if not context:
            return

        def _delete() -> None:
            conn = self._open_settings_connection()
            try:
                conn.execute("BEGIN IMMEDIATE")
                conn.execute(
                    "DELETE FROM server_projection WHERE context_key=?",
                    (context,),
                )
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                self._close_settings_connection(conn)

        self._run_sqlite_retry(_delete, label="clearing server projection")

    def get_server_projection(
        self,
        context_key: str,
        entity_type: str,
    ) -> list[dict[str, Any]]:
        context = str(context_key or "").strip()
        kind = str(entity_type or "").strip()
        if not context or not kind:
            return []
        conn = self._open_settings_connection()
        try:
            rows = conn.execute(
                """
                SELECT payload FROM server_projection
                WHERE context_key=? AND entity_type=?
                ORDER BY entity_id
                """,
                (context, kind),
            ).fetchall()
            return [
                json.loads(str(row["payload"])) for row in rows if str(row["payload"] or "").strip()
            ]
        finally:
            self._close_settings_connection(conn)

    def _read_settings_row(
        self,
        query: str,
        key: str,
        *,
        retry_label: str,
        error_message: str,
    ) -> dict:
        """Read one settings-backed row through the shared retry/close contract."""

        def _read():
            conn = self._open_settings_connection()
            try:
                cursor = conn.cursor()
                cursor.execute(query, (key,))
                row = cursor.fetchone()
                return dict(row) if row else {}
            finally:
                self._close_settings_connection(conn)

        try:
            return self._run_sqlite_retry(_read, label=retry_label) or {}
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception(error_message, key)
            return {}

    def get_alert_state(self, key: str) -> dict:
        alert_key = str(key or "")
        return self._read_settings_row(
            "SELECT key, last_date, last_notified_at, last_seen_at, fingerprint, severity_rank, status_text, notify_count FROM alert_state WHERE key=?",
            alert_key,
            retry_label="reading alert state",
            error_message="Reading alert state failed: %s",
        )

    def set_alert_state(
        self,
        key: str,
        *,
        last_date: str = "",
        last_notified_at: float = 0.0,
        last_seen_at: float = 0.0,
        fingerprint: str = "",
        severity_rank: int = 0,
        status_text: str = "",
        notify_count: int = 0,
    ) -> None:
        alert_key = str(key or "")

        def _write() -> None:
            lock = getattr(self, "_db_lock", None)
            if lock is not None:
                with lock:
                    return self._set_alert_state_once(
                        alert_key,
                        last_date,
                        last_notified_at,
                        last_seen_at,
                        fingerprint,
                        severity_rank,
                        status_text,
                        notify_count,
                    )
            return self._set_alert_state_once(
                alert_key,
                last_date,
                last_notified_at,
                last_seen_at,
                fingerprint,
                severity_rank,
                status_text,
                notify_count,
            )

        try:
            self._run_sqlite_retry(_write, label="saving alert state")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Saving alert state failed: %s", alert_key)

    def _set_alert_state_once(
        self,
        key: str,
        last_date: str,
        last_notified_at: float,
        last_seen_at: float,
        fingerprint: str,
        severity_rank: int,
        status_text: str,
        notify_count: int,
    ) -> None:
        conn = self._open_settings_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                "\n                INSERT INTO alert_state(\n                    key, last_date, last_notified_at, last_seen_at,\n                    fingerprint, severity_rank, status_text, notify_count\n                )\n                VALUES(?,?,?,?,?,?,?,?)\n                ON CONFLICT(key) DO UPDATE SET\n                  last_date=excluded.last_date,\n                  last_notified_at=excluded.last_notified_at,\n                  last_seen_at=excluded.last_seen_at,\n                  fingerprint=excluded.fingerprint,\n                  severity_rank=excluded.severity_rank,\n                  status_text=excluded.status_text,\n                  notify_count=excluded.notify_count\n                ",
                (
                    str(key or ""),
                    str(last_date or ""),
                    float(last_notified_at or 0.0),
                    float(last_seen_at or 0.0),
                    str(fingerprint or ""),
                    int(severity_rank or 0),
                    str(status_text or ""),
                    int(notify_count or 0),
                ),
            )
            conn.commit()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            try:
                conn.rollback()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Rollback failed while saving alert state", exc_info=True)
            raise
        finally:
            self._close_settings_connection(conn)

    def get_notification_ledger(self, key: str) -> dict:
        ledger_key = str(key or "")
        return self._read_settings_row(
            """
            SELECT notification_key, state, severity, last_shown_at,
                   last_payload_hash, shown_count, acknowledged_at, acknowledged_by
            FROM notification_ledger
            WHERE notification_key=?
            """,
            ledger_key,
            retry_label="reading notification ledger",
            error_message="Reading notification ledger failed: %s",
        )

    def acknowledge_notification_ledger(
        self,
        key: str,
        *,
        acknowledged_at: str,
        acknowledged_by: str,
        expected_payload_hash: str = "",
    ) -> None:
        ledger_key = str(key or "").strip()
        if not ledger_key:
            return

        def _write() -> None:
            conn = self._open_settings_connection()
            try:
                conn.execute("BEGIN IMMEDIATE")
                conn.execute(
                    """
                    UPDATE notification_ledger
                    SET acknowledged_at=?, acknowledged_by=?
                    WHERE notification_key=?
                      AND (?='' OR last_payload_hash=?)
                    """,
                    (
                        str(acknowledged_at or ""),
                        str(acknowledged_by or ""),
                        ledger_key,
                        str(expected_payload_hash or ""),
                        str(expected_payload_hash or ""),
                    ),
                )
                conn.commit()
            except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                try:
                    conn.rollback()
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Rollback failed while acknowledging notification", exc_info=True)
                raise
            finally:
                self._close_settings_connection(conn)

        try:
            self._run_sqlite_retry(_write, label="acknowledging notification")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Acknowledging notification failed: %s", ledger_key)

    def record_notification_ledger(
        self,
        key: str,
        *,
        state: str,
        severity: int,
        payload_hash: str,
        acknowledged_at: str = "",
    ) -> None:
        ledger_key = str(key or "")
        shown_at = datetime.now(timezone.utc).isoformat()

        def _write() -> None:
            lock = getattr(self, "_db_lock", None)
            if lock is not None:
                with lock:
                    return self._record_notification_ledger_once(
                        ledger_key,
                        state,
                        severity,
                        payload_hash,
                        shown_at,
                        acknowledged_at,
                    )
            return self._record_notification_ledger_once(
                ledger_key,
                state,
                severity,
                payload_hash,
                shown_at,
                acknowledged_at,
            )

        try:
            self._run_sqlite_retry(_write, label="saving notification ledger")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Saving notification ledger failed: %s", ledger_key)

    def _record_notification_ledger_once(
        self,
        key: str,
        state: str,
        severity: int,
        payload_hash: str,
        shown_at: str,
        acknowledged_at: str,
    ) -> None:
        conn = self._open_settings_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute(
                """
                INSERT INTO notification_ledger(
                  notification_key, state, severity, last_shown_at,
                  last_payload_hash, shown_count, acknowledged_at
                ) VALUES(?,?,?,?,?,?,?)
                ON CONFLICT(notification_key) DO UPDATE SET
                  state=excluded.state,
                  severity=excluded.severity,
                  last_shown_at=excluded.last_shown_at,
                  last_payload_hash=excluded.last_payload_hash,
                  shown_count=notification_ledger.shown_count + 1,
                  acknowledged_at=excluded.acknowledged_at
                """,
                (
                    str(key or ""),
                    str(state or ""),
                    int(severity or 0),
                    str(shown_at or ""),
                    str(payload_hash or ""),
                    1,
                    str(acknowledged_at or ""),
                ),
            )
            conn.commit()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            try:
                conn.rollback()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug(
                    "Rollback failed while saving notification ledger",
                    exc_info=True,
                )
            raise
        finally:
            self._close_settings_connection(conn)

    def clear_alert_states(self) -> None:

        def _write() -> None:
            lock = getattr(self, "_db_lock", None)
            if lock is not None:
                with lock:
                    return self._clear_alert_states_once()
            return self._clear_alert_states_once()

        try:
            self._run_sqlite_retry(_write, label="clearing alert states")
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Clearing alert states failed")

    def _clear_alert_states_once(self) -> None:
        conn = self._open_settings_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            conn.execute("DELETE FROM alert_state")
            conn.commit()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            try:
                conn.rollback()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Rollback failed while clearing alert states", exc_info=True)
            raise
        finally:
            self._close_settings_connection(conn)


logger = logging.getLogger(__name__)


def build_cloud_cache_key(branch: str, doc_id: str) -> str:
    branch_text = str(branch or "").strip()
    doc_text = str(doc_id or "").strip()
    if branch_text and doc_text:
        return f"{branch_text}::{doc_text}"
    return doc_text


def normalize_cloud_tracking_record(
    record: Mapping[str, Any] | None,
    *,
    stored_name_cache: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Normalize one canonical internal tracking row for durable cloud cache storage."""
    source = dict(record or {})
    material = str(source.get("material_number") or "").strip()
    doc_id = normalize_remote_id(source)
    branch = str(source.get("branch") or "").strip()
    cached_name = ""
    if stored_name_cache:
        cached_name = str(stored_name_cache.get(material) or "").strip()
    name = best_product_name(
        material,
        source.get("name"),
        cached_name,
        material,
    )
    normalized: dict[str, Any] = {
        "doc_id": doc_id,
        "material_number": material,
        "name": name,
        "quantity": normalize_int(source.get("quantity"), 0),
        "production_date": str(source.get("production_date") or ""),
        "expiry_date": str(source.get("expiry_date") or ""),
        "branch": branch,
        "notes": str(source.get("notes") or "").strip(),
        "responsible_user_id": str(source.get("responsible_user_id") or "").strip(),
        "revision": normalize_int(source.get("revision"), 0),
        "is_deleted": bool(source.get("is_deleted", False)),
        "created_at": str(source.get("created_at") or "").strip(),
        "updated_at": str(source.get("updated_at") or "").strip(),
        "deleted_at": str(source.get("deleted_at") or "").strip(),
        "deleted_by": str(source.get("deleted_by") or "").strip(),
        "created_by": str(source.get("created_by") or "").strip(),
        "updated_by": str(source.get("updated_by") or "").strip(),
    }
    normalized["id"] = build_cloud_cache_key(branch, doc_id)
    return normalized


def cloud_tracking_record_from_item(
    item: Mapping[str, Any] | None,
    *,
    stored_name_cache: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Cache the canonical client tracking item; no legacy/raw envelope is accepted."""
    return normalize_cloud_tracking_record(
        item,
        stored_name_cache=stored_name_cache,
    )


_SESSION_CLEAR_SQL = {
    "cloud_tracked_products": "DELETE FROM cloud_tracked_products",
    "notify_log": "DELETE FROM notify_log",
}


class TrackingCacheRepositoryMixin:
    def clear_session_scoped_local_data(self, *, clear_catalog: bool = True) -> None:
        self._cloud_cache_by_id.clear()
        self._cloud_list_cache.clear()
        self._stored_name_cache.clear()
        self._tracking_fetch_events.clear()
        tables = ["cloud_tracked_products", "notify_log"]
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                conn.execute("BEGIN IMMEDIATE")
                for table in tables:
                    try:
                        conn.execute(_SESSION_CLEAR_SQL[table])
                    except sqlite3.Error:
                        logger.debug("Skipping unavailable session table %s", table, exc_info=True)
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()

    def invalidate_cloud_cache(self, branch: str | None = None) -> None:
        if branch:
            value = str(branch).strip()
            for key in {value, value.lower(), value.upper()}:
                self._cloud_list_cache.pop(key, None)
        for key in ("", "all", "scope_all"):
            self._cloud_list_cache.pop(key, None)

    def _cloud_cache_key(self, branch: str, doc_id: str) -> str:
        return build_cloud_cache_key(branch, doc_id)

    def _cache_cloud_record(self, record: dict | None) -> dict:
        rec = normalize_cloud_tracking_record(record, stored_name_cache=self._stored_name_cache)
        cid = str(rec.get("id") or "").strip()
        if cid:
            identities = set(tracking_record_identity_keys(rec))
            if identities:
                for cached_id, cached_row in list(self._cloud_cache_by_id.items()):
                    if cached_id == cid:
                        continue
                    if identities.intersection(tracking_record_identity_keys(cached_row)):
                        self._cloud_cache_by_id.pop(cached_id, None)
            self._cloud_cache_by_id[cid] = rec
        return rec

    def _cloud_record_from_item(self, item: dict) -> dict:
        return cloud_tracking_record_from_item(item, stored_name_cache=self._stored_name_cache)

    def _tracking_cache_key_accepts_record(self, cache_key: str, record: dict) -> bool:
        key = str(cache_key or "").strip().lower()
        branch = str(record.get("branch") or "").strip().lower()
        if key in {"", "all"}:
            return True
        if key == "scope_all":
            return True
        return branch == key

    def _persisted_cloud_tracking_revision(self, row_id: str, branch: str = "") -> int:
        key = normalize_text(row_id)
        branch_text = normalize_text(branch)
        if not key:
            return 0
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    if branch_text:
                        row = conn.execute(
                            """
                            SELECT payload FROM cloud_tracked_products
                            WHERE id=?
                               OR (
                                   json_extract(payload, '$.doc_id')=?
                                   AND lower(branch)=lower(?)
                               )
                            LIMIT 1
                            """,
                            (key, key.split("::")[-1], branch_text),
                        ).fetchone()
                    else:
                        row = conn.execute(
                            """
                            SELECT payload FROM cloud_tracked_products
                            WHERE id=? OR json_extract(payload, '$.doc_id')=?
                            LIMIT 1
                            """,
                            (key, key.split("::")[-1]),
                        ).fetchone()
                finally:
                    conn.close()
            if not row:
                return 0
            payload_text = safe_get(row, "payload", "")
            payload = json.loads(str(payload_text or "{}"))
            return (
                max(0, normalize_int(payload.get("revision"), 0))
                if isinstance(payload, dict)
                else 0
            )
        except (
            sqlite3.Error,
            TypeError,
            ValueError,
            json.JSONDecodeError,
            *SERVICE_OPERATION_EXCEPTIONS,
        ):
            # Revision checks are part of durable apply. An unreadable persisted
            # row must fail closed rather than allowing a stale event through.
            logger.exception("Reading persisted cloud tracking revision failed")
            raise RuntimeError("Persisted tracking revision read failed")

    def _remove_tracking_record_from_cloud_caches(
        self,
        doc_id: str,
        branch: str = "",
        *,
        incoming_revision: int = 0,
    ) -> list[str]:
        doc = str(doc_id or "").strip()
        branch_text = str(branch or "").strip()
        if not doc:
            return []
        exact_key = self._cloud_cache_key(branch_text, doc) if branch_text else doc
        incoming_rev = max(0, normalize_int(incoming_revision, 0))
        current_rev = self._persisted_cloud_tracking_revision(exact_key, branch_text)
        if incoming_rev and current_rev > incoming_rev:
            logger.info(
                "Ignoring stale tracking delete id=%s incoming_revision=%s current_revision=%s",
                exact_key,
                incoming_rev,
                current_rev,
            )
            return []
        # Durable state is authoritative. Delete it first even when no in-memory
        # list/cache has been loaded in this process. Cursor commit is forbidden
        # if this write cannot be proven successful.
        if not self._delete_persisted_cloud_tracking_record(exact_key, branch_text):
            raise RuntimeError("Persisted tracking delete failed")

        removed: list[str] = []
        for cache_key, rec in list(self._cloud_cache_by_id.items()):
            rec_doc = str(rec.get("doc_id") or rec.get("id") or "").split("::")[-1].strip()
            rec_branch = str(rec.get("branch") or "").strip()
            if cache_key == exact_key or (
                rec_doc == doc and (not branch_text or rec_branch.lower() == branch_text.lower())
            ):
                removed.append(str(rec.get("id") or cache_key))
                self._cloud_cache_by_id.pop(cache_key, None)

        def _keep(row: dict) -> bool:
            row_doc = str(row.get("doc_id") or row.get("id") or "").split("::")[-1].strip()
            row_branch = str(row.get("branch") or "").strip()
            return not (
                row_doc == doc and (not branch_text or row_branch.lower() == branch_text.lower())
            )

        for key, cached in list(self._cloud_list_cache.items()):
            ts, rows = cached
            filtered = [row for row in rows if _keep(row)]
            if len(filtered) != len(rows):
                self._cloud_list_cache[key] = (ts, filtered)
        return removed or [exact_key]

    def _upsert_tracking_record_in_cloud_caches(self, record: dict) -> dict | None:
        rec = normalize_cloud_tracking_record(record, stored_name_cache=self._stored_name_cache)
        rec_id = str(rec.get("id") or "").strip()
        if not rec_id:
            return None
        incoming_rev = max(0, normalize_int(rec.get("revision"), 0))
        current_rev = self._persisted_cloud_tracking_revision(rec_id, str(rec.get("branch") or ""))
        if incoming_rev and current_rev > incoming_rev:
            logger.info(
                "Ignoring stale tracking upsert id=%s incoming_revision=%s current_revision=%s",
                rec_id,
                incoming_rev,
                current_rev,
            )
            return None
        # Persist first. Do not let volatile memory claim a server event was
        # applied when SQLite rejected it.
        if not self._persist_cloud_tracking_records([rec]):
            raise RuntimeError("Persisted tracking upsert failed")
        self._cache_cloud_record(rec)
        for key, cached in list(self._cloud_list_cache.items()):
            ts, rows = cached
            accepts = self._tracking_cache_key_accepts_record(key, rec)
            updated: list[dict] = []
            found = False
            for row in rows:
                row_id = str(row.get("id") or "").strip()
                row_doc = str(row.get("doc_id") or "").strip()
                if row_id == rec_id or (row_doc and row_doc == str(rec.get("doc_id") or "")):
                    found = True
                    if accepts:
                        updated.append(dict(rec))
                    continue
                updated.append(row)
            if accepts and (not found):
                updated.append(dict(rec))
            self._cloud_list_cache[key] = (ts, deduplicate_tracking_records(updated))
        return rec

    def upsert_cached_cloud_tracking_product(self, record: dict) -> dict:
        """Persist one canonical client tracking row returned by a successful mutation."""
        applied = self._upsert_tracking_record_in_cloud_caches(dict(record or {}))
        if not applied:
            raise RuntimeError("Tracking mutation response was not applied")
        return dict(applied)

    def delete_cached_cloud_tracking_product(
        self, *, doc_id: str, branch: str, revision: int
    ) -> list[str]:
        """Remove one canonical tracking row returned by a successful server delete."""
        return self._remove_tracking_record_from_cloud_caches(
            normalize_text(doc_id),
            normalize_text(branch),
            incoming_revision=normalize_int(revision, 0),
        )

    def apply_remote_tracking_changes(self, changes: list[dict]) -> dict:
        upserts: list[dict] = []
        deletes: list[str] = []
        changed_branches: set[str] = set()
        for change in changes or []:
            if not isinstance(change, dict):
                continue
            entity = change_entity(change)
            if entity != "tracking_item":
                continue
            payload = change_payload(change)
            op = change_operation(change)
            branch = normalize_text(payload.get("branch_id"))
            doc_id = normalize_text(payload.get("id"))
            if branch:
                changed_branches.add(branch)
            if op == "delete":
                deletes.extend(
                    self._remove_tracking_record_from_cloud_caches(
                        doc_id,
                        branch,
                        incoming_revision=normalize_int(payload.get("revision"), 0),
                    )
                )
                continue
            record = normalize_tracking_item(
                payload,
                stored_name=normalize_text(
                    self._stored_name_cache.get(payload.get("material_number"))
                ),
            )
            applied = self._upsert_tracking_record_in_cloud_caches(record)
            if applied:
                upserts.append(dict(applied))
        return {
            "upserts": upserts,
            "deletes": deletes,
            "branches": sorted(changed_branches),
            "applied": bool(upserts or deletes),
        }

    def _persist_cloud_tracking_records(self, rows: list[dict]) -> bool:
        rows = deduplicate_tracking_records(rows)
        if not rows:
            return True
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    now_text = datetime.now(timezone.utc).isoformat(timespec="seconds")
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        row_id = normalize_text(row.get("id") or row.get("doc_id"))
                        if not row_id:
                            continue
                        branch = normalize_text(row.get("branch"))
                        material = normalize_text(row.get("material_number"))
                        expiry = normalize_text(row.get("expiry_date"))
                        if material and expiry:
                            conn.execute(
                                """
                                DELETE FROM cloud_tracked_products
                                WHERE lower(branch)=lower(?)
                                  AND lower(material_number)=lower(?)
                                  AND expiry_date=?
                                  AND id<>?
                                """,
                                (branch, material, expiry, row_id),
                            )
                        conn.execute(
                            "\n                            INSERT OR REPLACE INTO cloud_tracked_products(\n                                id, branch, material_number, expiry_date, payload, updated_at\n                            ) VALUES(?,?,?,?,?,?)\n                            ",
                            (
                                row_id,
                                branch,
                                material,
                                expiry,
                                json.dumps(row, ensure_ascii=False, sort_keys=True),
                                now_text,
                            ),
                        )
                    conn.commit()
                    return True
                except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                    try:
                        conn.rollback()
                    except SERVICE_OPERATION_EXCEPTIONS:
                        logger.debug("Cloud tracking cache rollback failed", exc_info=True)
                    raise
                finally:
                    conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Persisting cloud tracking cache failed")
            return False

    def replace_cached_cloud_tracking_products(self, rows: list[dict] | None) -> bool:
        """Atomically replace the authoritative cloud tracking projection."""
        normalized_rows = deduplicate_tracking_records(list(rows or []))
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    conn.execute("DELETE FROM cloud_tracked_products")
                    now_text = datetime.now(timezone.utc).isoformat(timespec="seconds")
                    for row in normalized_rows:
                        if not isinstance(row, dict):
                            continue
                        row_id = normalize_text(row.get("id") or row.get("doc_id"))
                        if not row_id:
                            raise ValueError("Authoritative tracking row is missing its identity")
                        branch = normalize_text(row.get("branch") or row.get("branch_id"))
                        material = normalize_text(row.get("material_number"))
                        expiry = normalize_text(row.get("expiry_date"))
                        conn.execute(
                            """
                            INSERT OR REPLACE INTO cloud_tracked_products(
                                id, branch, material_number, expiry_date, payload, updated_at
                            ) VALUES(?,?,?,?,?,?)
                            """,
                            (
                                row_id,
                                branch,
                                material,
                                expiry,
                                json.dumps(row, ensure_ascii=False, sort_keys=True),
                                now_text,
                            ),
                        )
                    conn.commit()
                except (sqlite3.Error, ValueError, *SERVICE_OPERATION_EXCEPTIONS):
                    try:
                        conn.rollback()
                    except SERVICE_OPERATION_EXCEPTIONS:
                        logger.debug("Cloud tracking baseline rollback failed", exc_info=True)
                    raise
                finally:
                    conn.close()
                self._cloud_cache_by_id.clear()
                self._cloud_list_cache.clear()
                for row in normalized_rows:
                    self._cache_cloud_record(row)
                return True
        except (sqlite3.Error, ValueError, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Replacing cloud tracking baseline failed")
            return False

    def _delete_persisted_cloud_tracking_record(self, row_id: str, branch: str = "") -> bool:
        try:
            key = normalize_text(row_id)
            branch_text = normalize_text(branch)
            if not key:
                return True
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    if branch_text:
                        conn.execute(
                            """
                            DELETE FROM cloud_tracked_products
                            WHERE id=?
                               OR (
                                   json_extract(payload, '$.doc_id')=?
                                   AND lower(branch)=lower(?)
                               )
                            """,
                            (key, key.split("::")[-1], branch_text),
                        )
                    else:
                        conn.execute(
                            """
                            DELETE FROM cloud_tracked_products
                            WHERE id=? OR json_extract(payload, '$.doc_id')=?
                            """,
                            (key, key.split("::")[-1]),
                        )
                    conn.commit()
                    return True
                except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                    try:
                        conn.rollback()
                    except SERVICE_OPERATION_EXCEPTIONS:
                        logger.debug("Cloud tracking delete rollback failed", exc_info=True)
                    raise
                finally:
                    conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Deleting persisted cloud tracking cache failed")
            return False

    def _load_persisted_cloud_tracking_records(self, cache_key: str) -> list[dict]:
        try:
            conn = self._fresh_connection()
            try:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT payload FROM cloud_tracked_products ORDER BY updated_at DESC"
                )
                rows: list[dict] = []
                wanted = normalize_text(cache_key).lower()
                for db_row in cursor.fetchall():
                    payload_text = safe_get(db_row, "payload", "")
                    try:
                        row = json.loads(str(payload_text or "{}"))
                    except (TypeError, ValueError, json.JSONDecodeError):
                        continue
                    if not isinstance(row, dict):
                        continue
                    branch = normalize_text(row.get("branch")).lower()
                    if wanted in {"", "all"}:
                        rows.append(row)
                    elif wanted == "scope_all":
                        rows.append(row)
                    elif branch == wanted:
                        rows.append(row)
                rows = deduplicate_tracking_records(rows)
                for row in rows:
                    self._cache_cloud_record(row)
                if rows:
                    self._cloud_list_cache[wanted] = (
                        time.monotonic(),
                        [dict(row) for row in rows],
                    )
                return rows
            finally:
                conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.debug("Loading persisted cloud tracking cache failed", exc_info=True)
            return []

    def _cloud_cache_key_for_branch(self, branch_filter_override: str | None = None) -> str:
        value = normalize_text(branch_filter_override).lower()
        return value or "all"

    def fetch_cached_tracked_products(
        self, branch_filter_override: str | None = None
    ) -> list[dict]:
        cache_key = self._cloud_cache_key_for_branch(branch_filter_override)
        cached = self._cloud_list_cache.get(cache_key)
        if cached is not None:
            _ts, rows = cached
            return deduplicate_tracking_records(rows)
        rows: list[dict] = []
        for row in self._cloud_cache_by_id.values():
            branch = normalize_text(row.get("branch")).lower()
            if cache_key in ("", "all", "scope_all") or branch == cache_key:
                rows.append(dict(row))
        if rows:
            return deduplicate_tracking_records(rows)
        return self._load_persisted_cloud_tracking_records(cache_key)


class TrackingCatalogRepositoryMixin:
    """Ephemeral server-authoritative stored-product projection.

    Stored products are never persisted to SQLite. The desktop receives them
    from the server and keeps only an in-memory session projection.
    """

    def apply_stored_product_projection(self, mat_num: str, name_: str) -> None:
        material = normalize_text(mat_num)
        name = normalize_text(name_)
        if not material or not name:
            raise ValueError("Material number and name are required")
        self._stored_name_cache[material] = name

    def fetch_stored_products(self) -> list[dict]:
        return [
            {"material_number": material, "name": name}
            for material, name in sorted(self._stored_name_cache.items())
        ]

    def merge_remote_stored_products(self, rows: list[dict] | None) -> list[dict]:
        applied: list[dict] = []
        for row in rows or []:
            if not isinstance(row, dict):
                continue
            material = normalize_text(row.get("material_number"))
            if not material:
                continue
            name = normalize_text(row.get("name"), material)
            self._stored_name_cache[material] = name
            applied.append({"material_number": material, "name": name})
        return applied

    def replace_stored_products(self, rows: list[dict] | None) -> list[dict]:
        self._stored_name_cache.clear()
        return self.merge_remote_stored_products(rows)

    def apply_remote_stored_product_changes(self, changes: list[dict] | None) -> dict:
        upserts = 0
        deletes = 0
        for change in changes or []:
            if not isinstance(change, dict) or change_entity(change) != "stored_product":
                continue
            payload = change_payload(change)
            material = normalize_text(payload.get("material_number"))
            if not material:
                continue
            if change_operation(change) == "delete":
                if material in self._stored_name_cache:
                    self._stored_name_cache.pop(material, None)
                deletes += 1
                continue
            name = normalize_text(payload.get("name"), material)
            self._stored_name_cache[material] = name
            upserts += 1
        return {"upserts": upserts, "deletes": deletes, "applied": bool(upserts or deletes)}

    def stored_product_exists(self, mat_num: str) -> bool:
        return normalize_text(mat_num) in self._stored_name_cache

    def delete_stored_product_local(self, mat_num: str) -> None:
        self._stored_name_cache.pop(normalize_text(mat_num), None)


class DatabaseTrackingCatalogMixin(
    TrackingCacheRepositoryMixin,
    TrackingCatalogRepositoryMixin,
):
    """Durable tracking cache plus ephemeral server catalog projection."""


class UsageRepositoryMixin:
    """Ephemeral server-authoritative usage catalogue projection.

    The desktop never persists usage catalogue rows. They exist only for the
    authenticated runtime session and are repopulated from server authority.
    """

    def fetch_usage_products(self) -> list[dict]:
        return [dict(self._usage_memory[key]) for key in sorted(self._usage_memory)]

    def apply_usage_product_projection(self, material: str, name: str, uom: str = "") -> None:
        material = normalize_text(material)
        if not material:
            raise ValueError("Material is required")
        self._usage_memory[material] = {
            "material": material,
            "name": normalize_text(name, material),
            "uom": normalize_text(uom),
        }

    def delete_usage_product_local(self, material: str) -> None:
        self._usage_memory.pop(normalize_text(material), None)

    def replace_usage_products(self, items: list[dict] | None) -> list[dict]:
        self._usage_memory.clear()
        for item in items or []:
            if not isinstance(item, dict):
                continue
            material = normalize_text(item.get("material") or item.get("material_number"))
            if not material:
                continue
            self._usage_memory[material] = {
                "material": material,
                "name": normalize_text(item.get("name"), material),
                "uom": normalize_text(item.get("uom")),
            }
        return self.fetch_usage_products()

    def apply_remote_usage_changes(self, changes: list[dict] | None) -> dict:
        upserts = 0
        deletes = 0
        for change in changes or []:
            if not isinstance(change, dict) or change_entity(change) != "usage_product":
                continue
            payload = change_payload(change)
            material = normalize_text(payload.get("material_number") or payload.get("material"))
            if not material:
                continue
            if change_operation(change) == "delete":
                self._usage_memory.pop(material, None)
                deletes += 1
                continue
            self._usage_memory[material] = {
                "material": material,
                "name": normalize_text(payload.get("name"), material),
                "uom": normalize_text(payload.get("uom")),
            }
            upserts += 1
        return {"upserts": upserts, "deletes": deletes, "applied": bool(upserts or deletes)}

    def clear_memory(self) -> None:
        self._usage_memory.clear()


class _RepositoryBase:
    def __init__(self, engine: SQLiteEngine):
        self._engine = engine
        self.connection = engine.connection
        self._db_lock = engine.lock
        self.db_path = engine.db_path

    def _fresh_connection(self):
        return self._engine.fresh_connection()


class SettingsRepository(DatabaseSettingsAlertMixin, _RepositoryBase):
    """SQLite settings and notification-state repository."""

    def __init__(self, engine: SQLiteEngine):
        _RepositoryBase.__init__(self, engine)


class TrackingRepository(DatabaseTrackingCatalogMixin, _RepositoryBase):
    """SQLite tracking/stored-catalog projection repository; network-free."""

    def __init__(self, engine: SQLiteEngine):
        _RepositoryBase.__init__(self, engine)
        self._cloud_cache_by_id: dict[str, dict] = {}
        self._stored_name_cache: dict[str, str] = {}
        self._cloud_list_cache: dict[str, tuple[float, list[dict]]] = {}
        self._tracking_fetch_events: dict[str, threading.Event] = {}
        self.cloud_list_cache_ttl_seconds = int(get_cache_ttl().catalog)

    @property
    def stored_name_cache_size(self) -> int:
        return len(self._stored_name_cache)


class UsageRepository(UsageRepositoryMixin, _RepositoryBase):
    """Ephemeral server usage-catalog projection."""

    def __init__(self, engine: SQLiteEngine):
        _RepositoryBase.__init__(self, engine)
        self._usage_memory: dict[str, dict] = {}


@dataclass(frozen=True)
class LocalRepositories:
    engine: SQLiteEngine
    settings: SettingsRepository
    tracking: TrackingRepository
    usage: UsageRepository

    @classmethod
    def create(cls, *, db_path_override=None) -> "LocalRepositories":
        engine = SQLiteEngine(db_path_override=db_path_override)
        return cls(
            engine=engine,
            settings=SettingsRepository(engine),
            tracking=TrackingRepository(engine),
            usage=UsageRepository(engine),
        )

    def clear_session_scoped_data(self, *, clear_catalog: bool = True) -> None:
        self.tracking.clear_session_scoped_local_data(clear_catalog=clear_catalog)
        if clear_catalog:
            self.usage.clear_memory()

    def close(self) -> None:
        self.engine.close()
