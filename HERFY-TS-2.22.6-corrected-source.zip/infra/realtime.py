from __future__ import annotations

import json
import logging
import secrets
import threading
import time
from collections.abc import Callable
from typing import Any

from contracts.routes import Routes
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import normalize_int
from core.signals import safe_disconnect

logger = logging.getLogger(__name__)


class Signal:
    """Small thread-safe callback signal used outside Qt objects."""

    def __init__(self) -> None:
        self._callbacks: list[Callable[..., None]] = []
        self._lock = threading.RLock()

    def connect(self, callback: Callable[..., None]) -> None:
        with self._lock:
            if callback not in self._callbacks:
                self._callbacks.append(callback)

    def disconnect(self, callback: Callable[..., None] | None = None) -> None:
        with self._lock:
            if callback is None:
                self._callbacks.clear()
                return
            # Bound-method objects are recreated on each attribute access. Equality,
            # unlike identity, correctly matches the same instance/method pair.
            self._callbacks = [item for item in self._callbacks if item != callback]

    def emit(self, *args: Any) -> None:
        with self._lock:
            callbacks = list(self._callbacks)
        for callback in callbacks:
            try:
                callback(*args)
            except Exception:
                # Receiver failures must never terminate the single SSE owner.
                logger.exception("Realtime callback raised an exception")


class CoalescedCursorSignal(Signal):
    """Thread-safe monotonic cursor signal with bounded callback pressure.

    SSE can deliver many ``changed`` events in a short burst.  Crossing every
    event into Qt is unnecessary because the durable sync pull is cursor based.
    The first newer cursor is delivered immediately; later cursors inside the
    coalescing window collapse to the highest value and are delivered once.
    """

    def __init__(
        self,
        min_interval_seconds: float = 0.08,
        *,
        monotonic=None,
        timer_factory=None,
    ) -> None:
        super().__init__()
        self._min_interval_seconds = max(0.0, float(min_interval_seconds))
        self._monotonic = monotonic or time.monotonic
        self._timer_factory = timer_factory or threading.Timer
        self._pending_cursor = 0
        self._last_delivered_cursor = 0
        self._last_emit_at: float | None = None
        self._timer = None
        self._timer_epoch = 0

    def _cancel_timer_locked(self) -> None:
        timer = self._timer
        self._timer = None
        if timer is None:
            return
        try:
            timer.cancel()
        except Exception:
            logger.debug("Realtime cursor timer cancellation failed", exc_info=True)

    def cancel_pending(self, *, reset_delivery: bool = False) -> None:
        """Cancel delayed delivery so stale session callbacks cannot leak forward."""
        with self._lock:
            self._timer_epoch += 1
            self._cancel_timer_locked()
            self._pending_cursor = 0
            if reset_delivery:
                self._last_delivered_cursor = 0
                self._last_emit_at = None

    def disconnect(self, callback: Callable[..., None] | None = None) -> None:
        if callback is None:
            self.cancel_pending(reset_delivery=True)
        super().disconnect(callback)

    def _flush_pending(self, epoch: int) -> None:
        cursor = 0
        with self._lock:
            if epoch != self._timer_epoch:
                return
            self._timer = None
            cursor = max(0, int(self._pending_cursor or 0))
            self._pending_cursor = 0
            if cursor <= self._last_delivered_cursor:
                return
            self._last_delivered_cursor = cursor
            self._last_emit_at = float(self._monotonic())
        super().emit(cursor)

    def emit(self, cursor: Any) -> None:
        try:
            value = max(0, int(cursor or 0))
        except (TypeError, ValueError):
            return
        if value <= 0:
            return

        immediate = False
        timer_to_start = None
        with self._lock:
            if value <= max(self._last_delivered_cursor, self._pending_cursor):
                return
            now = float(self._monotonic())
            elapsed = (
                self._min_interval_seconds
                if self._last_emit_at is None
                else max(0.0, now - self._last_emit_at)
            )
            if self._last_emit_at is None or elapsed >= self._min_interval_seconds:
                self._timer_epoch += 1
                self._cancel_timer_locked()
                self._pending_cursor = 0
                self._last_delivered_cursor = value
                self._last_emit_at = now
                immediate = True
            else:
                self._pending_cursor = value
                if self._timer is None:
                    delay = max(0.0, self._min_interval_seconds - elapsed)
                    self._timer_epoch += 1
                    epoch = self._timer_epoch
                    timer = self._timer_factory(delay, lambda e=epoch: self._flush_pending(e))
                    try:
                        timer.daemon = True
                    except Exception:
                        logger.debug("Realtime cursor timer daemon flag unavailable", exc_info=True)
                    self._timer = timer
                    timer_to_start = timer

        if immediate:
            super().emit(value)
        elif timer_to_start is not None:
            timer_to_start.start()


class CallbackBridge:
    def __init__(self) -> None:
        self.on_changed = CoalescedCursorSignal()
        self.on_state = Signal()

    def cancel_pending(self) -> None:
        self.on_changed.cancel_pending(reset_delivery=True)


class RemoteRealtimeMixin:
    def _next_reconnect_delay(self, attempt: int) -> float:
        base = min(30.0, float(2 ** max(0, attempt)))
        jitter = 1.0 + secrets.SystemRandom().uniform(0.0, 0.2)
        return min(30.0, base * jitter)

    @staticmethod
    def _is_keepalive_line(line: str) -> bool:
        return str(line or "").startswith(":")

    @staticmethod
    def _cursor_from_realtime_payload(payload_text: str) -> int:
        text = str(payload_text or "").strip()
        if not text:
            return 0
        direct_value = normalize_int(text, 0)
        if direct_value > 0:
            return direct_value
        try:
            payload = json.loads(text)
        except SERVICE_OPERATION_EXCEPTIONS:
            return 0
        if not isinstance(payload, dict):
            return 0
        for key in ("cursor", "last_id", "id", "event_id", "version"):
            value = normalize_int(payload.get(key), 0)
            if value > 0:
                return value
        return 0

    def start_realtime(
        self,
        on_changed: Callable[[int], None] | None,
        *,
        on_state: Callable[[bool], None] | None = None,
    ) -> None:
        """Start the single SSE contract exposed at ``Routes.EVENTS``."""
        ensure_open = getattr(self, "_ensure_open", None)
        if callable(ensure_open):
            ensure_open()
        self._start_events_mode(on_changed, on_state=on_state)

    @staticmethod
    def _replace_realtime_signal(signal: Signal, callback: Callable[..., None] | None) -> None:
        # Always clear the previous receiver. Starting a mode without a callback
        # must not leave a stale callback from an earlier window/session attached.
        safe_disconnect(signal, logger_=logger, context="Realtime signal disconnect")
        if callback is not None:
            signal.connect(callback)

    def _iter_sse_events(self, response: Any, stop_event: threading.Event):
        event: str | None = None
        event_id: str | None = None
        data_buf: list[str] = []
        for raw in response.iter_lines(chunk_size=1, decode_unicode=True):
            if stop_event.is_set():
                break
            if raw is None:
                continue
            line = raw.strip("\r")
            if not line:
                if event and data_buf:
                    yield (event, "\n".join(data_buf), event_id)
                event = None
                event_id = None
                data_buf = []
                continue
            if self._is_keepalive_line(line):
                continue
            if line.startswith("id:"):
                event_id = line.split(":", 1)[1].strip()
                continue
            if line.startswith("event:"):
                event = line.split(":", 1)[1].strip()
                continue
            if line.startswith("data:"):
                data_buf.append(line.split(":", 1)[1].lstrip())
        if not stop_event.is_set() and event and data_buf:
            yield (event, "\n".join(data_buf), event_id)

    def _start_events_mode(
        self,
        on_changed: Callable[[int], None] | None,
        on_state: Callable[[bool], None] | None = None,
    ) -> None:
        self._reset_realtime_worker()
        stop_event = self._rt_stop
        bridge = self._callback_bridge
        self._replace_realtime_signal(bridge.on_changed, on_changed)
        self._replace_realtime_signal(bridge.on_state, on_state)

        def _run() -> None:
            connected = False
            attempt = 0
            while not stop_event.is_set():
                try:
                    with self._new_session() as stream_session:
                        cursor = self.sync_cursor()
                        logger.info("Realtime SSE connecting cursor=%s", cursor)
                        response = self._realtime_get(
                            stream_session,
                            self._resolve_request_url(Routes.EVENTS),
                            headers={**self._headers(), "Last-Event-ID": str(cursor)},
                            params={"cursor": cursor},
                            stream=True,
                        )
                        if not self._register_realtime_transport(stream_session, response):
                            response.close()
                            break
                        try:
                            with response:
                                if response.status_code >= 400:
                                    raise RuntimeError(response.text)
                                if not connected:
                                    connected = True
                                    attempt = 0
                                    logger.info(
                                        "Realtime SSE connected cursor=%s", self.sync_cursor()
                                    )
                                    logger.info("REALTIME_SINGLE_CONNECTION=PASS transport=SSE")
                                    bridge.on_state.emit(True)
                                for event, payload_text, event_id in self._iter_sse_events(
                                    response, stop_event
                                ):
                                    if event == "changed" and payload_text:
                                        try:
                                            last_id = max(
                                                self._cursor_from_realtime_payload(payload_text),
                                                normalize_int(event_id, 0),
                                            )
                                            if last_id <= self.sync_cursor():
                                                continue
                                            logger.info(
                                                "Realtime SSE change received event_id=%s target_cursor=%s current_cursor=%s",
                                                event_id or "",
                                                last_id,
                                                self.sync_cursor(),
                                            )
                                            bridge.on_changed.emit(last_id)
                                        except SERVICE_OPERATION_EXCEPTIONS:
                                            logger.debug(
                                                "Realtime event dispatch failed",
                                                exc_info=True,
                                            )
                        finally:
                            self._clear_realtime_transport(stream_session, response)
                except SERVICE_OPERATION_EXCEPTIONS:
                    if stop_event.is_set():
                        break
                    if connected:
                        connected = False
                        logger.info("Realtime SSE disconnected")
                        bridge.on_state.emit(False)
                    delay = self._next_reconnect_delay(attempt)
                    logger.info("Realtime SSE reconnect scheduled delay_seconds=%.2f", delay)
                    if stop_event.wait(delay):
                        break
                    attempt = min(attempt + 1, 5)

        self._start_realtime_worker(_run)

    def stop_realtime(self) -> bool:
        # Close the active streaming transport before joining so requests.iter_lines()
        # cannot keep an obsolete SSE owner alive until its read timeout. Never hold
        # the lifecycle lock while closing sockets or joining.
        with self._realtime_lock:
            stop_event = self._rt_stop
            thread = self._rt_thread
            response = getattr(self, "_rt_response", None)
            session = getattr(self, "_rt_session", None)
            stop_event.set()
        try:
            self._callback_bridge.cancel_pending()
        except Exception:
            logger.debug("Realtime pending signal cancellation failed", exc_info=True)

        for transport in (response, session):
            if transport is None:
                continue
            try:
                transport.close()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Realtime transport close failed", exc_info=True)

        if thread and thread.is_alive() and thread is not threading.current_thread():
            try:
                join_timeout = (
                    0.20 if threading.current_thread() is threading.main_thread() else 2.0
                )
                thread.join(timeout=join_timeout)
            except RuntimeError:
                logger.debug("Realtime worker join failed", exc_info=True)

        terminated = bool(
            thread is None or thread is threading.current_thread() or not thread.is_alive()
        )
        with self._realtime_lock:
            if response is self._rt_response:
                self._rt_response = None
            if session is self._rt_session:
                self._rt_session = None
            if terminated and thread is self._rt_thread:
                self._rt_thread = None
        if not terminated:
            logger.error("Realtime worker did not terminate after transport close")
        return terminated
