"""Application bootstrap for the native PySide6 runtime."""

from __future__ import annotations

import atexit
import os
import sys
import tempfile
import traceback
from pathlib import Path

_BOOTSTRAPPED = False
_TRACE_NAME = "HERFY_TS_EARLY_BOOT_TRACE.txt"


def _safe_write_trace(message: str) -> None:
    """Write an early startup trace before the normal logging system exists."""
    targets: list[Path] = []
    appdata = os.environ.get("APPDATA")
    if appdata:
        targets.append(Path(appdata) / "HERFY-TS" / "logs" / _TRACE_NAME)
    targets.append(Path(tempfile.gettempdir()) / _TRACE_NAME)

    payload = str(message).rstrip() + "\n"
    for target in targets:
        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("a", encoding="utf-8") as handle:
                handle.write(payload)
        except Exception:
            continue


def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            return Path(meipass).resolve()
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]


def _load_binding() -> dict[str, object]:
    from contracts.binding import get_server_binding

    binding = get_server_binding()
    return {
        "client_version": binding.client_version,
        "client_architecture": binding.client_architecture,
        "api_contract_sha256": binding.api_contract_sha256,
    }


def _set_cert_paths(base: Path) -> None:
    # Never trust inherited certificate variables from an old unpacked build.
    for name in ("REQUESTS_CA_BUNDLE", "SSL_CERT_FILE", "CURL_CA_BUNDLE"):
        try:
            value = os.environ.get(name)
            if value and not Path(value).is_file():
                os.environ.pop(name, None)
        except Exception:
            os.environ.pop(name, None)

    candidates = [base / "certifi" / "cacert.pem"]
    if not bool(getattr(sys, "frozen", False)):
        candidates.append(Path.cwd() / "certifi" / "cacert.pem")
    for cert_path in candidates:
        try:
            if cert_path.is_file():
                os.environ["REQUESTS_CA_BUNDLE"] = str(cert_path)
                os.environ["SSL_CERT_FILE"] = str(cert_path)
                return
        except Exception:
            continue


def _set_qt_paths(base: Path) -> None:
    # Prefer the Qt plugin packaged with this executable/source tree.
    for name in ("QT_QPA_PLATFORM_PLUGIN_PATH", "QT_PLUGIN_PATH"):
        try:
            value = os.environ.get(name)
            if value and not Path(value).exists():
                os.environ.pop(name, None)
        except Exception:
            os.environ.pop(name, None)

    # PyInstaller's modern PySide hook places plugins beside the binding.
    # Keep the former Qt subdirectory as a compatibility fallback for an
    # existing deployed runtime, without relying on the working directory.
    candidates = [
        base / "PySide6" / "plugins" / "platforms",
        base / "PySide6" / "Qt" / "plugins" / "platforms",
    ]
    for platform_dir in candidates:
        try:
            if (platform_dir / "qwindows.dll").is_file():
                os.environ["QT_QPA_PLATFORM_PLUGIN_PATH"] = str(platform_dir)
                os.environ["QT_PLUGIN_PATH"] = str(platform_dir.parent)
                return
        except Exception:
            continue


def _apply_client_request_headers(
    kwargs: dict[str, object],
    *,
    client_version: str,
    architecture: str,
    contract_sha: str,
) -> None:
    """Apply the canonical client identity headers to one Requests call."""
    headers = dict(kwargs.pop("headers", None) or {})
    headers.setdefault("X-Client-Version", client_version)
    headers.setdefault("X-Client-Architecture", architecture)
    if contract_sha:
        headers.setdefault("X-API-Contract-SHA256", contract_sha)
    kwargs["headers"] = headers


def _patch_requests(binding: dict[str, object]) -> None:
    try:
        import requests
    except Exception:
        return

    client_version = str(binding.get("client_version") or "").strip()
    if not client_version:
        raise RuntimeError("Canonical client version is missing")
    arch = str(binding.get("client_architecture") or "").strip()
    if not arch:
        raise RuntimeError("Client architecture detection failed")
    contract_sha = str(binding.get("api_contract_sha256") or "").strip().lower()

    if getattr(requests.sessions.Session.request, "_herfy_patched", False):
        return

    original_session_request = requests.sessions.Session.request

    def patched_session_request(self, method, url, **kwargs):
        _apply_client_request_headers(
            kwargs,
            client_version=client_version,
            architecture=arch,
            contract_sha=contract_sha,
        )
        return original_session_request(self, method, url, **kwargs)

    patched_session_request._herfy_patched = True  # type: ignore[attr-defined]
    requests.sessions.Session.request = patched_session_request

    original_api_request = requests.api.request

    def patched_api_request(method, url, **kwargs):
        _apply_client_request_headers(
            kwargs,
            client_version=client_version,
            architecture=arch,
            contract_sha=contract_sha,
        )
        return original_api_request(method, url, **kwargs)

    requests.api.request = patched_api_request


def install() -> None:
    global _BOOTSTRAPPED
    if _BOOTSTRAPPED:
        return
    _BOOTSTRAPPED = True

    base = _base_dir()
    binding = _load_binding()

    if os.environ.get("HERFY_TS_BOOT_TRACE") == "1":
        _safe_write_trace(
            "=== HERFY EARLY BOOT START ===\n"
            f"argv={sys.argv!r}\n"
            f"exe={sys.executable!r}\n"
            f"cwd={str(Path.cwd())!r}\n"
            f"frozen={bool(getattr(sys, 'frozen', False))!r}\n"
            f"_MEIPASS={getattr(sys, '_MEIPASS', None)!r}\n"
            f"base_dir={str(base)!r}\n"
            f"client_version={binding.get('client_version')!r}\n"
            f"client_architecture={binding.get('client_architecture')!r}\n"
            f"api_contract_sha256={binding.get('api_contract_sha256')!r}"
        )

    _set_cert_paths(base)
    _set_qt_paths(base)
    _patch_requests(binding)

    if os.environ.get("HERFY_TS_BOOT_TRACE") == "1":

        def _normal_exit_trace() -> None:
            _safe_write_trace(
                "=== HERFY EARLY BOOT EXIT ===\n" f"argv={sys.argv!r}\n" f"exe={sys.executable!r}"
            )

        atexit.register(_normal_exit_trace)


try:
    install()
except Exception:
    _safe_write_trace("=== HERFY EARLY BOOT FAULT ===\n" + traceback.format_exc())
    raise
