"""Ed25519-signed update manifest + HTTPS + SHA-256 artifact verification."""

from __future__ import annotations

import argparse
import base64
import contextlib
import hashlib
import json
import logging
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import urlparse

import requests
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from packaging.version import Version

from contracts.binding import get_server_binding, get_update_trust
from core.processes import launch_detached
from core.settings import installed_root, is_frozen
from infra.files import sha256_file

_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_PUBLIC_KEY_RELATIVE = Path("resources") / "update_signing_public.pem"
_REQUIRED = {
    "version",
    "platform",
    "architecture",
    "contract_sha256",
    "runtime_url",
    "runtime_sha256",
    "runtime_size",
    "installer_url",
    "installer_sha256",
    "installer_size",
    "key_id",
    "signature",
}


def _validate_update_public_key_bytes(key_bytes: bytes) -> Ed25519PublicKey:
    trust = get_update_trust()
    if hashlib.sha256(key_bytes).hexdigest() != trust.public_key_pem_sha256:
        raise RuntimeError("Pinned update signing PEM fingerprint mismatch")
    try:
        key = serialization.load_pem_public_key(key_bytes)
    except (ValueError, TypeError) as exc:
        raise RuntimeError("Pinned update signing public key is invalid") from exc
    if not isinstance(key, Ed25519PublicKey):
        raise RuntimeError("Pinned update signing key is not Ed25519")
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    if hashlib.sha256(raw).hexdigest() != trust.key_id:
        raise RuntimeError("Pinned update signing key identity mismatch")
    return key


def _fetch_source_update_public_key() -> bytes:
    trust = get_update_trust()
    binding = get_server_binding()
    try:
        response = requests.get(
            trust.public_key_url,
            headers={
                "Accept": "application/octet-stream",
                "X-Client-Version": binding.client_version,
                "X-Client-Architecture": binding.client_architecture,
                "X-API-Contract-SHA256": binding.api_contract_sha256,
            },
            timeout=binding.http_timeout_seconds,
            allow_redirects=False,
        )
    except requests.RequestException as exc:
        raise RuntimeError("Pinned update signing public key is unavailable") from exc
    try:
        if response.status_code != 200:
            raise RuntimeError("Pinned update signing public key request failed")
        key_bytes = bytes(response.content or b"")
        if not key_bytes or len(key_bytes) > 16 * 1024:
            raise RuntimeError("Pinned update signing public key response is invalid")
        return key_bytes
    finally:
        response.close()


@lru_cache(maxsize=1)
def load_pinned_update_public_key() -> Ed25519PublicKey:
    key_path = installed_root() / _PUBLIC_KEY_RELATIVE
    if key_path.is_file():
        key_bytes = key_path.read_bytes()
    elif is_frozen():
        raise RuntimeError("Pinned update signing public key is missing")
    else:
        key_bytes = _fetch_source_update_public_key()
    return _validate_update_public_key_bytes(key_bytes)


def _canonical_signed_payload(payload: Mapping[str, Any]) -> bytes:
    body = {k: v for k, v in payload.items() if k != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def _effective_port(parsed) -> int | None:
    if parsed.port is not None:
        return int(parsed.port)
    if parsed.scheme.lower() == "https":
        return 443
    if parsed.scheme.lower() == "http":
        return 80
    return None


def _verify_url(url: str, *, expected_name: str) -> None:
    binding = get_server_binding()
    base = urlparse(binding.updates_base_url.rstrip("/"))
    parsed = urlparse(url)
    expected_prefix = base.path.rstrip("/") + "/updates/packages/"
    expected_path = expected_prefix + expected_name
    if (
        parsed.scheme.lower() != "https"
        or (parsed.hostname or "").lower() != (base.hostname or "").lower()
        or _effective_port(parsed) != _effective_port(base)
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path != expected_path
        or parsed.params
        or parsed.query
        or parsed.fragment
    ):
        raise RuntimeError("Update artifact URL is not canonical")


class UpdateManifestVerifier:
    def verify(self, payload: Mapping[str, Any]) -> None:
        if not isinstance(payload, Mapping) or set(payload) != _REQUIRED:
            raise RuntimeError("Update manifest schema mismatch")
        version = str(payload["version"] or "").strip()
        if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", version):
            raise RuntimeError("Update manifest version is invalid")
        Version(version)
        binding = get_server_binding()
        architecture = str(payload["architecture"] or "").strip().lower()
        if payload["platform"] != "windows" or architecture != binding.client_architecture:
            raise RuntimeError("Update manifest platform/architecture mismatch")
        if str(payload["contract_sha256"]).lower() != binding.api_contract_sha256.lower():
            raise RuntimeError("Update manifest contract mismatch")
        trust = get_update_trust()
        if str(payload["key_id"]).lower() != trust.key_id:
            raise RuntimeError("Update manifest key identity mismatch")
        expected_names = {
            "runtime": f"HERFY-TS-{version}-windows-{architecture}-runtime.zip",
            "installer": f"HERFY-TS-Setup-{version}-windows-{architecture}.exe",
        }
        for prefix in ("runtime", "installer"):
            digest = str(payload[f"{prefix}_sha256"] or "").lower()
            size = int(payload[f"{prefix}_size"] or 0)
            if not _SHA256.fullmatch(digest) or size <= 0:
                raise RuntimeError("Update artifact integrity metadata is invalid")
            _verify_url(
                str(payload[f"{prefix}_url"]),
                expected_name=expected_names[prefix],
            )
        try:
            signature = base64.b64decode(str(payload["signature"]), validate=True)
            load_pinned_update_public_key().verify(signature, _canonical_signed_payload(payload))
        except (ValueError, InvalidSignature) as exc:
            raise RuntimeError("Update manifest Ed25519 signature verification failed") from exc

    def verify_package(
        self, payload: Mapping[str, Any], path: Path, *, artifact_key: str = "runtime"
    ) -> None:
        self.verify(payload)
        prefix = "runtime" if artifact_key in {"runtime", "package"} else "installer"
        target = Path(path)
        if not target.is_file():
            raise RuntimeError("Update artifact file is missing")
        if target.stat().st_size != int(payload[f"{prefix}_size"]):
            raise RuntimeError("Update artifact size mismatch")
        h = hashlib.sha256()
        with target.open("rb") as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(block)
        if h.hexdigest() != str(payload[f"{prefix}_sha256"]).lower():
            raise RuntimeError("Update artifact SHA-256 mismatch")


def verify_signed_manifest_response(response: Any) -> dict[str, Any]:
    raw = bytes(response.content or b"")
    if not raw:
        raise RuntimeError("Update manifest is empty")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("Signed update manifest JSON is invalid") from exc
    if not isinstance(payload, dict):
        raise RuntimeError("Signed update manifest payload is invalid")
    UpdateManifestVerifier().verify(payload)
    return payload


APP_EXE_NAME = "HERFY-TS.exe"
AGENT_EXE_NAME = "HERFY-TSUpdateAgent.exe"


logger = logging.getLogger(__name__)
if not logging.getLogger().handlers:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
RUNTIME_MANIFEST_NAME = "runtime_files.txt"
_RUNTIME_KEEP_DIRS = {".pending_update", ".update_backup", "installer"}
_RUNTIME_KEEP_FILES = {AGENT_EXE_NAME.lower(), "installer_defaults.ini", ".update_success.json"}
_INNO_UNINSTALLER_SUFFIXES = {".exe", ".dat", ".msg"}
_WINDOWS_RESERVED_NAMES = {
    "CON",
    "PRN",
    "AUX",
    "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}
_WINDOWS_INVALID_FILENAME_CHARS = frozenset('<>:"|?*')
_MAX_WINDOWS_COMPONENT_LENGTH = 255
_MAX_RUNTIME_RELATIVE_PATH_LENGTH = 220
_MAX_PATCH_MEMBERS = 10000
_MAX_PATCH_FILE_SIZE = 1024 * 1024 * 1024
_MAX_PATCH_TOTAL_SIZE = 2 * 1024 * 1024 * 1024
_MAX_COMPRESSION_RATIO = 500


def _is_inno_uninstaller_file(name: str) -> bool:
    candidate = Path(name).name.casefold()
    stem = Path(candidate).stem
    suffix = Path(candidate).suffix
    return suffix in _INNO_UNINSTALLER_SUFFIXES and stem.startswith("unins") and stem[5:].isdigit()


def _is_runtime_keep_path(relative: Path) -> bool:
    parts = relative.parts
    if not parts:
        return True
    if parts[0].casefold() in _RUNTIME_KEEP_DIRS:
        return True
    name = relative.name.casefold()
    return name in _RUNTIME_KEEP_FILES or _is_inno_uninstaller_file(name)


def _remove_tree_with_retry(path: Path, *, attempts: int = 20, delay_seconds: float = 0.25) -> None:
    if not path.exists():
        return
    last_error: OSError | None = None
    for _ in range(max(1, attempts)):
        try:
            shutil.rmtree(path)
            return
        except OSError as exc:
            last_error = exc
            time.sleep(max(0.01, delay_seconds))
    raise RuntimeError(f"Unable to remove directory: {path}: {last_error}")


def _prune_update_backups(root: Path, *, keep: int = 0) -> None:
    """Remove completed-update snapshots; rollback exists only during activation."""
    backup_parent = root / ".update_backup"
    if not backup_parent.is_dir():
        return
    backups = sorted(
        (item for item in backup_parent.iterdir() if item.is_dir()),
        key=lambda item: item.name,
        reverse=True,
    )
    retained = max(0, int(keep))
    for stale in backups[retained:]:
        _remove_tree_with_retry(stale)
    if not any(backup_parent.iterdir()):
        backup_parent.rmdir()


def _remove_obsolete_update_artifacts(root: Path) -> None:
    obsolete_restore = root / ".update_restore_backup"
    if obsolete_restore.exists():
        _remove_tree_with_retry(obsolete_restore)


def _snapshot_runtime(destination: Path, backup_root: Path) -> None:
    """Capture the complete replaceable runtime before changing any file."""
    if backup_root.exists():
        raise RuntimeError(f"Update backup already exists: {backup_root}")
    backup_root.mkdir(parents=True, exist_ok=False)
    for item in sorted(destination.rglob("*")):
        if item.is_dir():
            continue
        relative = item.relative_to(destination)
        # Keep installer metadata/uninstaller state outside the runtime transaction,
        # but snapshot the currently installed UpdateAgent explicitly.  The running
        # agent cannot restore itself in-process; the post-exit activation helper
        # uses this backup if replacement or the new agent self-check fails.
        if (
            _is_runtime_keep_path(relative)
            and relative.name.casefold() != AGENT_EXE_NAME.casefold()
        ):
            continue
        target = backup_root / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)


def _remove_replaceable_runtime(destination: Path) -> None:
    for item in sorted(destination.rglob("*"), key=lambda value: len(value.parts), reverse=True):
        if item == destination or not item.exists():
            continue
        relative = item.relative_to(destination)
        if _is_runtime_keep_path(relative):
            continue
        if item.is_dir():
            with contextlib.suppress(OSError):
                item.rmdir()
            continue
        item.unlink()


def _restore_runtime_snapshot(backup_root: Path, destination: Path) -> None:
    pending = destination / ".pending_update"
    if pending.exists():
        _remove_tree_with_retry(pending)
    _remove_replaceable_runtime(destination)
    for item in sorted(backup_root.rglob("*")):
        if item.is_dir():
            continue
        relative = item.relative_to(backup_root)
        # The currently running UpdateAgent cannot safely overwrite itself on
        # Windows.  In-process rollback restores the application runtime only;
        # the post-exit activation helper owns UpdateAgent restore/commit.
        if relative.name.casefold() == AGENT_EXE_NAME.casefold():
            continue
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)


def _parse_runtime_manifest_text(text: str) -> set[Path]:
    entries: set[Path] = set()
    folded: set[str] = set()
    for raw_line in str(text or "").splitlines():
        value = raw_line.strip().replace("\\", "/")
        if not value:
            continue
        relative = Path(*value.split("/"))
        folded_value = relative.as_posix().casefold()
        if relative.is_absolute() or ".." in relative.parts:
            raise RuntimeError(f"Unsafe runtime manifest entry: {raw_line}")
        if relative in entries or folded_value in folded:
            raise RuntimeError(f"Duplicate runtime manifest entry: {raw_line}")
        entries.add(relative)
        folded.add(folded_value)
    return entries


def _baseline_required_runtime_entries() -> set[Path]:
    return {
        Path(APP_EXE_NAME),
        Path(AGENT_EXE_NAME),
        Path("version.json"),
        Path("resources/i18n/ar.json"),
        Path("resources/i18n/en.json"),
        Path("resources/images/logo.png"),
        Path("resources/images/app_icon.ico"),
        Path("contracts/CONTRACTS.json"),
        Path("resources/update_signing_public.pem"),
        Path("BUILD_PROVENANCE.json"),
    }


def _canonical_contract_entries_from_bytes(raw: bytes) -> set[Path]:
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("contracts/CONTRACTS.json is not valid UTF-8 JSON") from exc
    entries = payload.get("contracts")
    if not isinstance(entries, list) or not entries:
        raise RuntimeError("contracts/CONTRACTS.json contracts must be a non-empty array")
    result: set[Path] = set()
    folded: set[str] = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise RuntimeError("contracts/CONTRACTS.json entries must be objects")
        name = str(entry.get("filename") or "").strip()
        relative = Path(name)
        folded_name = name.casefold()
        if (
            not name
            or relative.name != name
            or relative.suffix.casefold() != ".json"
            or folded_name == "contracts.json"
            or folded_name in folded
        ):
            raise RuntimeError(f"Invalid canonical contract filename: {name!r}")
        result.add(Path("contracts") / relative)
        folded.add(folded_name)
    return result


def _required_runtime_entries(root: Path) -> set[Path]:
    manifest = root / "contracts" / "CONTRACTS.json"
    if not manifest.is_file():
        raise RuntimeError(f"Canonical contract manifest is missing: {manifest}")
    return _baseline_required_runtime_entries() | _canonical_contract_entries_from_bytes(
        manifest.read_bytes()
    )


def _validate_required_runtime_entries(entries: set[Path], root: Path) -> None:
    missing = sorted(str(item) for item in _required_runtime_entries(root) - entries)
    if missing:
        raise RuntimeError(f"Runtime manifest is incomplete: {', '.join(missing)}")


def _runtime_manifest_entries(root: Path) -> set[Path]:
    manifest = root / RUNTIME_MANIFEST_NAME
    if not manifest.is_file():
        raise RuntimeError(f"Runtime manifest is missing: {manifest}")
    entries = _parse_runtime_manifest_text(manifest.read_text(encoding="utf-8"))
    _validate_required_runtime_entries(entries, root)
    return entries


def _verify_patch_source_file_set(source: Path) -> None:
    declared = _runtime_manifest_entries(source)
    expected = declared | {Path(RUNTIME_MANIFEST_NAME)}
    actual = {item.relative_to(source) for item in source.rglob("*") if item.is_file()}
    missing = sorted(item.as_posix() for item in expected - actual)
    extra = sorted(item.as_posix() for item in actual - expected)
    if missing or extra:
        raise RuntimeError(
            "Patch source does not exactly match runtime_files.txt. "
            f"missing={missing[:10]} extra={extra[:10]}"
        )


def _delete_stale_runtime_files(source: Path, destination: Path) -> int:
    """Remove every replaceable file absent from the declared runtime manifest."""
    expected_files = _runtime_manifest_entries(source) | {Path(RUNTIME_MANIFEST_NAME)}
    removed = 0
    for item in sorted(destination.rglob("*"), key=lambda value: len(value.parts), reverse=True):
        if item == destination or not item.exists():
            continue
        relative = item.relative_to(destination)
        if _is_runtime_keep_path(relative):
            continue
        if item.is_dir():
            with contextlib.suppress(OSError):
                item.rmdir()
            continue
        if relative in expected_files:
            continue
        item.unlink()
        removed += 1
    return removed


def _verify_runtime_file_set(source: Path, destination: Path) -> None:
    expected = {
        item for item in _runtime_manifest_entries(source) if not _is_runtime_keep_path(item)
    } | {Path(RUNTIME_MANIFEST_NAME)}
    actual = {
        item.relative_to(destination)
        for item in destination.rglob("*")
        if item.is_file() and not _is_runtime_keep_path(item.relative_to(destination))
    }
    missing = sorted(str(item) for item in expected - actual)
    extra = sorted(str(item) for item in actual - expected)
    if missing or extra:
        raise RuntimeError(
            "Installed runtime file set does not match manifest. "
            f"missing={missing[:10]} extra={extra[:10]}"
        )
    source_artifacts = sorted(
        str(item.relative_to(destination))
        for item in destination.rglob("*")
        if item.is_file()
        and item.suffix.lower() in {".py", ".pyc", ".pyo"}
        and not _is_runtime_keep_path(item.relative_to(destination))
    )
    if source_artifacts:
        raise RuntimeError(f"Source files leaked into installed runtime: {source_artifacts[:10]}")


def _verify_updated_runtime(destination: Path) -> None:
    executable = destination / APP_EXE_NAME
    version_file = destination / "version.json"
    if not executable.is_file() or not version_file.is_file():
        raise RuntimeError("Updated runtime is missing the executable or version.json")
    version_data = json.loads(version_file.read_text(encoding="utf-8"))
    expected_version = str(version_data.get("version") or "").strip()
    if not expected_version:
        raise RuntimeError("Updated runtime version.json has no version")
    with tempfile.TemporaryDirectory(prefix="herfy_update_self_check_") as temp_dir:
        result_path = Path(temp_dir) / "self_check.json"
        environment = os.environ.copy()
        environment["QT_QPA_PLATFORM"] = "offscreen"
        environment["HERFY_SELF_CHECK_FILE"] = str(result_path)
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        completed = subprocess.run(
            [str(executable), "--self-check"],
            cwd=str(destination),
            env=environment,
            timeout=120,
            check=False,
            creationflags=creation_flags,
        )
        if completed.returncode != 0:
            raise RuntimeError(f"Updated executable self-check exited with {completed.returncode}")
        if not result_path.is_file():
            raise RuntimeError("Updated executable self-check produced no result file")
        payload = json.loads(result_path.read_text(encoding="utf-8"))
        if str(payload.get("status") or "") != "ok":
            raise RuntimeError(f"Updated executable self-check failed: {payload}")
        if str(payload.get("version") or "") != expected_version:
            raise RuntimeError(
                "Updated executable self-check version mismatch. "
                f"expected={expected_version} actual={payload.get('version')}"
            )
        if not bool(payload.get("frozen")):
            raise RuntimeError("Updated executable self-check reported frozen=false")
    _write_line(f"HERFY_UPDATE_RUNTIME_SELF_CHECK_OK version={expected_version}")


def _write_line(message: str) -> None:
    logger.info(message)


def _safe_resolve(path: str | Path) -> Path:
    return Path(path).expanduser().resolve()


def _validate_package_integrity(
    patch_zip: Path, *, expected_sha256: str = "", expected_size: int = 0
) -> None:
    if expected_size and patch_zip.stat().st_size != expected_size:
        raise RuntimeError(
            f"Patch size mismatch. expected={expected_size} actual={patch_zip.stat().st_size}"
        )
    normalized_sha = str(expected_sha256 or "").strip().lower()
    if normalized_sha:
        actual = sha256_file(patch_zip).lower()
        if actual != normalized_sha:
            raise RuntimeError(f"Patch SHA256 mismatch. expected={normalized_sha} actual={actual}")


def _validate_patch_zip(patch_zip: Path) -> None:
    if not patch_zip.is_file() or patch_zip.suffix.lower() != ".zip":
        raise RuntimeError(f"Patch package is not a zip file: {patch_zip}")
    with zipfile.ZipFile(patch_zip, "r") as package:
        bad = package.testzip()
        if bad:
            raise RuntimeError(f"Patch package contains a corrupt file: {bad}")
        members = package.infolist()
        if len(members) > _MAX_PATCH_MEMBERS:
            raise RuntimeError(f"Patch package contains too many members: {len(members)}")
        names: set[str] = set()
        folded_names: set[str] = set()
        total_size = 0
        for member in members:
            name = member.filename.replace("\\", "/")
            if name != name.strip():
                raise RuntimeError(
                    f"Patch member has leading or trailing whitespace: {member.filename}"
                )
            if not name or name.endswith("/"):
                continue
            raw_parts = tuple(name.split("/"))
            if any(part in {"", "."} for part in raw_parts):
                raise RuntimeError(f"Non-canonical patch member path rejected: {member.filename}")
            pure_parts = raw_parts
            if name.startswith("/") or ".." in pure_parts:
                raise RuntimeError(f"Unsafe patch member path rejected: {member.filename}")
            if len(name) > _MAX_RUNTIME_RELATIVE_PATH_LENGTH:
                raise RuntimeError(f"Patch member path is too long: {member.filename}")
            for part in pure_parts:
                if (
                    len(part) > _MAX_WINDOWS_COMPONENT_LENGTH
                    or part.endswith((" ", "."))
                    or any(ord(character) < 32 for character in part)
                    or any(character in _WINDOWS_INVALID_FILENAME_CHARS for character in part)
                    or part.split(".", 1)[0].upper() in _WINDOWS_RESERVED_NAMES
                ):
                    raise RuntimeError(
                        f"Windows-incompatible patch member rejected: {member.filename}"
                    )
            if stat.S_ISLNK((member.external_attr >> 16) & 0xFFFF):
                raise RuntimeError(f"Symbolic-link patch member rejected: {member.filename}")
            if member.file_size > _MAX_PATCH_FILE_SIZE:
                raise RuntimeError(f"Oversized patch member rejected: {member.filename}")
            total_size += member.file_size
            if total_size > _MAX_PATCH_TOTAL_SIZE:
                raise RuntimeError(f"Patch package expands beyond the allowed size: {total_size}")
            if (
                member.file_size > 1024 * 1024
                and member.file_size / max(1, member.compress_size) > _MAX_COMPRESSION_RATIO
            ):
                raise RuntimeError(f"Suspicious compression ratio rejected: {member.filename}")
            if name.lower().endswith((".py", ".pyc", ".pyo")) or "__pycache__" in pure_parts:
                raise RuntimeError(f"Source/cache artifact rejected from patch: {name}")
            folded = name.casefold()
            if folded in folded_names:
                raise RuntimeError(
                    f"Case-insensitive duplicate patch member rejected: {member.filename}"
                )
            names.add(name)
            folded_names.add(folded)
        try:
            canonical_contracts = {
                item.as_posix()
                for item in _canonical_contract_entries_from_bytes(
                    package.read("contracts/CONTRACTS.json")
                )
            }
        except KeyError as exc:
            raise RuntimeError("Patch package is missing contracts/CONTRACTS.json") from exc
        required = (
            {item.as_posix() for item in _baseline_required_runtime_entries()}
            | canonical_contracts
            | {RUNTIME_MANIFEST_NAME}
        )
        missing = sorted(required - names)
        if missing:
            raise RuntimeError(f"Patch package is incomplete. Missing: {', '.join(missing)}")
        try:
            manifest_text = package.read(RUNTIME_MANIFEST_NAME).decode("utf-8")
        except (KeyError, UnicodeDecodeError) as exc:
            raise RuntimeError("Patch runtime_files.txt is missing or invalid UTF-8") from exc
        declared_paths = _parse_runtime_manifest_text(manifest_text)
        missing_declared_required = sorted(
            required - {item.as_posix() for item in declared_paths} - {RUNTIME_MANIFEST_NAME}
        )
        if missing_declared_required:
            raise RuntimeError(
                "Patch runtime_files.txt is missing canonical runtime entries: "
                + ", ".join(missing_declared_required)
            )
        declared_names = {item.as_posix() for item in declared_paths}
        archive_runtime_names = set(names) - {RUNTIME_MANIFEST_NAME}
        missing_declared = sorted(declared_names - archive_runtime_names)
        undeclared_archive = sorted(archive_runtime_names - declared_names)
        if missing_declared or undeclared_archive:
            raise RuntimeError(
                "Patch ZIP does not exactly match runtime_files.txt. "
                f"missing={missing_declared[:10]} extra={undeclared_archive[:10]}"
            )


def _wait_for_target_release(root: Path, wait_seconds: int) -> None:
    target = root / APP_EXE_NAME
    temp_name = root / f".{APP_EXE_NAME}.rename_test"
    probe = root / f".{APP_EXE_NAME}.write_test"
    deadline = time.monotonic() + max(1, int(wait_seconds))
    while time.monotonic() < deadline:
        try:
            if temp_name.exists() and not target.exists():
                temp_name.rename(target)
            elif temp_name.exists():
                temp_name.unlink()
            if not target.exists():
                return
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            target.rename(temp_name)
            try:
                temp_name.rename(target)
            except OSError:
                with contextlib.suppress(OSError):
                    if temp_name.exists() and not target.exists():
                        temp_name.rename(target)
                raise
            return
        except OSError:
            with contextlib.suppress(OSError):
                probe.unlink(missing_ok=True)
            time.sleep(1)
    with contextlib.suppress(OSError):
        if temp_name.exists() and not target.exists():
            temp_name.rename(target)
    raise RuntimeError(f"Timed out waiting for {APP_EXE_NAME} to close")


def _copy_tree_contents(source: Path, destination: Path) -> bool:
    destination = destination.resolve()
    _delete_stale_runtime_files(source, destination)
    staged_agent_update = False
    for item in sorted(source.rglob("*")):
        if item.is_dir():
            continue
        relative = item.relative_to(source)
        if relative.name.lower() == AGENT_EXE_NAME.lower():
            pending = destination / ".pending_update" / AGENT_EXE_NAME
            pending.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, pending)
            staged_agent_update = True
            continue
        target = (destination / relative).resolve()
        if destination not in target.parents and target != destination:
            raise RuntimeError(f"Unsafe target path rejected: {target}")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(item, target)
    return staged_agent_update


def _extract_patch(patch_zip: Path) -> tuple[Path, Path]:
    """Extract validated members without delegating path creation to extractall()."""
    temp_root = Path(tempfile.mkdtemp(prefix="herfy_update_extract_")).resolve()
    try:
        with zipfile.ZipFile(patch_zip, "r") as package:
            for member in package.infolist():
                name = member.filename.replace("\\", "/")
                if not name or name.endswith("/"):
                    continue
                target = (temp_root / Path(*name.split("/"))).resolve()
                if temp_root not in target.parents:
                    raise RuntimeError(f"Unsafe extraction target rejected: {member.filename}")
                target.parent.mkdir(parents=True, exist_ok=True)
                with (
                    package.open(member, "r") as source,
                    target.open("xb") as destination,
                ):
                    shutil.copyfileobj(source, destination, length=1024 * 1024)
        return temp_root, temp_root
    except BaseException:
        with contextlib.suppress(RuntimeError):
            _remove_tree_with_retry(temp_root)
        raise


def _write_update_success_marker(root: Path) -> None:
    version_file = root / "version.json"
    version = ""
    if version_file.is_file():
        with contextlib.suppress(OSError, ValueError, json.JSONDecodeError):
            version = str(
                json.loads(version_file.read_text(encoding="utf-8")).get("version") or ""
            ).strip()
    payload = {
        "status": "ok",
        "version": version,
        "completed_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    (root / ".update_success.json").write_text(
        json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8"
    )


def _restart_application(restart: Path) -> None:
    if not restart.exists():
        return
    launch_detached([restart], cwd=restart.parent)


def _escape_cmd_value(value: str | Path) -> str:
    text = str(value)
    if any(character in text for character in ("\r", "\n", '"')):
        raise RuntimeError("Unsafe character in update command path")
    return text.replace("^", "^^").replace("%", "%%")


def _build_agent_commit_script(
    *,
    pending: Path,
    target: Path,
    backup_root: Path,
    root: Path,
    restart: Path,
    check_file: Path,
    failure_log: Path,
) -> str:
    """Build the Windows post-exit UpdateAgent commit helper deterministically."""
    lines = [
        "@echo off",
        "setlocal EnableExtensions",
        f'set "SOURCE={_escape_cmd_value(pending)}"',
        f'set "TARGET={_escape_cmd_value(target)}"',
        f'set "BACKUP={_escape_cmd_value(backup_root)}"',
        f'set "ROOT={_escape_cmd_value(root)}"',
        f'set "RESTART={_escape_cmd_value(restart)}"',
        f'set "CHECK={_escape_cmd_value(check_file)}"',
        f'set "FAILLOG={_escape_cmd_value(failure_log)}"',
        'del /Q "%CHECK%" >nul 2>nul',
        "for /L %%i in (1,1,45) do (",
        '  copy /Y "%SOURCE%" "%TARGET%" >nul 2>nul && goto copied',
        "  timeout /t 1 /nobreak >nul",
        ")",
        "goto activation_failed",
        ":copied",
        'set "HERFY_UPDATE_AGENT_SELF_CHECK_FILE=%CHECK%"',
        # Explicitly wait for the GUI-subsystem UpdateAgent before reading its JSON result.
        "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command \"$p=Start-Process -FilePath $env:TARGET -ArgumentList '--self-check' -WindowStyle Hidden -Wait -PassThru; exit [int]$p.ExitCode\"",
        "if errorlevel 1 goto activation_failed",
        'if not exist "%CHECK%" goto activation_failed',
        "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command \"$p=Get-Content -LiteralPath $env:HERFY_UPDATE_AGENT_SELF_CHECK_FILE -Raw | ConvertFrom-Json; if(([string]$p.status -ne 'ok') -or (-not [bool]$p.frozen) -or ([string]$p.agent_exe -ne 'HERFY-TSUpdateAgent.exe')){exit 1}\"",
        "if errorlevel 1 goto activation_failed",
        'del /Q "%CHECK%" >nul 2>nul',
        'del /Q "%SOURCE%" >nul 2>nul',
        'rmdir /S /Q "%BACKUP%" >nul 2>nul',
        r'for %%D in ("%BACKUP%\..") do rmdir "%%~fD" >nul 2>nul',
        r'rmdir /S /Q "%ROOT%\.pending_update" >nul 2>nul',
        "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command \"$v=(Get-Content -LiteralPath (Join-Path $env:ROOT 'version.json') -Raw | ConvertFrom-Json).version; $p=@{status='ok';version=[string]$v;completed_at=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress; Set-Content -LiteralPath (Join-Path $env:ROOT '.update_success.json') -Value $p -Encoding UTF8\"",
        "if errorlevel 1 goto activation_failed",
        'if exist "%RESTART%" start "" /D "%ROOT%" "%RESTART%"',
        'del /Q "%~f0" >nul 2>nul',
        "exit /b 0",
        ":activation_failed",
        r'del /Q "%ROOT%\.update_success.json" >nul 2>nul',
        '> "%FAILLOG%" echo UpdateAgent activation failed; previous agent restored and rollback snapshot retained.',
        r'if exist "%ROOT%\runtime_files.txt" for /F "usebackq delims=" %%F in ("%ROOT%\runtime_files.txt") do del /F /Q "%ROOT%\%%F" >nul 2>nul',
        r'del /F /Q "%ROOT%\runtime_files.txt" >nul 2>nul',
        # Remove empty directories created only by the failed new runtime, while preserving
        # installer metadata plus rollback/pending evidence. /E alone restores files but
        # otherwise leaves stale empty directories from the rejected runtime.
        "powershell.exe -NoProfile -ExecutionPolicy Bypass -Command \"Get-ChildItem -LiteralPath $env:ROOT -Directory -Recurse -Force | Sort-Object { $_.FullName.Length } -Descending | Where-Object { $_.FullName -notlike ($env:ROOT + '\\.update_backup*') -and $_.FullName -notlike ($env:ROOT + '\\.pending_update*') -and $_.FullName -notlike ($env:ROOT + '\\installer*') } | Remove-Item -Force -ErrorAction SilentlyContinue\"",
        'robocopy "%BACKUP%" "%ROOT%" /E /COPY:DAT /R:3 /W:1 /NFL /NDL /NJH /NJS /NP >nul',
        "if errorlevel 8 goto rollback_failed",
        'del /Q "%CHECK%" >nul 2>nul',
        'if exist "%RESTART%" start "" /D "%ROOT%" "%RESTART%"',
        'del /Q "%~f0" >nul 2>nul',
        "exit /b 1",
        ":rollback_failed",
        '> "%FAILLOG%" echo UpdateAgent activation failed and full runtime rollback also failed; rollback snapshot retained.',
        'del /Q "%CHECK%" >nul 2>nul',
        'del /Q "%~f0" >nul 2>nul',
        "exit /b 1",
    ]
    return "\r\n".join(lines) + "\r\n"


def _schedule_agent_self_replace(root: Path, restart: Path, backup_root: Path) -> None:
    """Commit a staged UpdateAgent only after the old process has exited."""
    pending = root / ".pending_update" / AGENT_EXE_NAME
    target = root / AGENT_EXE_NAME
    previous_agent = backup_root / AGENT_EXE_NAME
    if os.name != "nt" or not pending.exists():
        _restart_application(restart)
        return
    if not previous_agent.is_file():
        raise RuntimeError("UpdateAgent rollback snapshot is missing")

    helper_dir = root / ".pending_update" / "helpers"
    helper_dir.mkdir(parents=True, exist_ok=True)
    script = helper_dir / (f"HERFY-TS-complete-update-{os.getpid()}-{time.time_ns()}.cmd")
    check_file = root / ".pending_update" / "agent_self_check.json"
    failure_log = root / ".pending_update" / "complete_update_failed.log"
    script.write_bytes(
        _build_agent_commit_script(
            pending=pending,
            target=target,
            backup_root=backup_root,
            root=root,
            restart=restart,
            check_file=check_file,
            failure_log=failure_log,
        ).encode("utf-8")
    )
    launch_detached(["cmd.exe", "/c", script], cwd=root)


def apply_patch(
    patch_zip: Path,
    root: Path,
    restart: Path,
    wait_seconds: int,
    *,
    expected_sha256: str = "",
    expected_size: int = 0,
) -> int:
    patch_zip = _safe_resolve(patch_zip)
    root = _safe_resolve(root)
    restart = _safe_resolve(restart)
    if not root.is_dir():
        raise RuntimeError(f"Install root does not exist: {root}")
    expected_restart = (root / APP_EXE_NAME).resolve()
    if restart != expected_restart:
        raise RuntimeError(
            "Restart target must be the existing HERFY-TS.exe in the current install root"
        )
    _validate_package_integrity(
        patch_zip, expected_sha256=expected_sha256, expected_size=expected_size
    )
    _validate_patch_zip(patch_zip)
    _wait_for_target_release(root, wait_seconds)
    _remove_obsolete_update_artifacts(root)
    pending_root = root / ".pending_update"
    if pending_root.exists():
        _remove_tree_with_retry(pending_root)
    backup_root = root / ".update_backup" / datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    _snapshot_runtime(root, backup_root)
    extracted: Path | None = None
    extraction_root: Path | None = None
    try:
        extracted, extraction_root = _extract_patch(patch_zip)
        _verify_patch_source_file_set(extracted)
        staged_agent_update = _copy_tree_contents(extracted, root)
        _verify_runtime_file_set(extracted, root)
        _verify_updated_runtime(root)
    except (OSError, RuntimeError, ValueError, TimeoutError, zipfile.BadZipFile):
        _write_line("Patch failed; restoring complete runtime snapshot...")
        _restore_runtime_snapshot(backup_root, root)
        raise
    finally:
        if extraction_root is not None and extraction_root.exists():
            _remove_tree_with_retry(extraction_root)
    try:
        if staged_agent_update:
            _schedule_agent_self_replace(root, restart, backup_root)
        else:
            _write_update_success_marker(root)
            _restart_application(restart)
    except (OSError, RuntimeError, ValueError, TimeoutError):
        _write_line("Post-copy activation failed; restoring complete runtime snapshot...")
        _restore_runtime_snapshot(backup_root, root)
        with contextlib.suppress(OSError, RuntimeError, ValueError):
            _restart_application(root / APP_EXE_NAME)
        raise
    # The snapshot is rollback-only.  Non-agent updates commit here after the
    # new application runtime passes its frozen self-check.  Agent-changing
    # updates commit later in the post-exit helper, after the *new* agent also
    # passes its frozen self-check.
    if not staged_agent_update:
        # Agent-changing updates cross their final commit boundary only in the
        # post-exit helper after the new agent passes its frozen self-check.
        with contextlib.suppress(OSError, RuntimeError):
            _prune_update_backups(root, keep=0)
    with contextlib.suppress(OSError):
        patch_zip.unlink(missing_ok=True)
    with contextlib.suppress(OSError):
        pending_root = root / ".pending_update"
        if pending_root.is_dir() and not any(pending_root.iterdir()):
            pending_root.rmdir()
    _write_line(f"HERFY_UPDATE_AGENT_OK root={root} restart={restart}")
    return 0


def _write_cleanup_diagnostic(
    diagnostic_path: Path | None, *, status: str, removed: int = 0, error: str = ""
) -> None:
    if diagnostic_path is None:
        return
    target = _safe_resolve(diagnostic_path)
    if not target.parent.is_dir():
        raise RuntimeError(f"Cleanup diagnostic directory does not exist: {target.parent}")
    payload = {
        "status": str(status),
        "removed": max(0, int(removed)),
        "error": str(error or ""),
    }
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8"
    )
    temporary.replace(target)


def cleanup_installed_runtime(root: Path, diagnostic_path: Path | None = None) -> int:
    """Prune stale runtime files only after the installer has installed a verified runtime.

    The destination's own ``runtime_files.txt`` is authoritative. Installer metadata,
    Inno uninstaller state and update markers are explicitly preserved by
    ``_is_runtime_keep_path``. This mode performs no download, patching or restart.
    """
    root = _safe_resolve(root)
    try:
        if not root.is_dir():
            raise RuntimeError(f"Install root does not exist: {root}")
        _runtime_manifest_entries(root)
        removed = _delete_stale_runtime_files(root, root)
        _verify_runtime_file_set(root, root)
        _write_cleanup_diagnostic(diagnostic_path, status="ok", removed=removed)
        _write_line(f"HERFY_RUNTIME_CLEANUP_OK root={root} removed={removed}")
        return 0
    except (OSError, RuntimeError, ValueError, TimeoutError) as exc:
        try:
            _write_cleanup_diagnostic(diagnostic_path, status="failed", error=str(exc))
        except (OSError, RuntimeError, ValueError):
            _write_line("HERFY_RUNTIME_CLEANUP_DIAGNOSTIC_FAILED")
        raise


def _parse_cleanup_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="HERFY-TS installed runtime cleanup")
    parser.add_argument("--cleanup-installed-runtime", action="store_true", required=True)
    parser.add_argument("--root", required=True, help="Installed application directory")
    parser.add_argument("--diagnostic", default="", help="Optional JSON cleanup diagnostic path")
    return parser.parse_args()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="HERFY-TS safe update agent")
    parser.add_argument("--apply", dest="patch_zip", required=True, help="Verified patch zip path")
    parser.add_argument(
        "--root", dest="root", required=True, help="Installed application directory"
    )
    parser.add_argument(
        "--restart", dest="restart", required=True, help="Application exe to restart"
    )
    parser.add_argument(
        "--wait",
        dest="wait",
        type=int,
        default=60,
        help="Seconds to wait for app shutdown",
    )
    parser.add_argument("--sha256", default="", help="Expected patch SHA256")
    parser.add_argument("--expected-size", type=int, default=0, help="Expected patch size in bytes")
    return parser.parse_args()


def _write_self_check_result() -> int:
    payload = {
        "status": "ok",
        "frozen": bool(getattr(sys, "frozen", False)),
        "app_exe": APP_EXE_NAME,
        "agent_exe": AGENT_EXE_NAME,
        "executable": str(Path(sys.executable).resolve()),
    }
    target = str(os.environ.get("HERFY_UPDATE_AGENT_SELF_CHECK_FILE") or "").strip()
    if target:
        Path(target).write_text(
            json.dumps(payload, ensure_ascii=False, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    return 0


def main() -> int:
    if "--self-check" in sys.argv[1:]:
        return _write_self_check_result()
    if "--cleanup-installed-runtime" in sys.argv[1:]:
        args = _parse_cleanup_args()
        try:
            diagnostic = Path(args.diagnostic) if str(args.diagnostic or "").strip() else None
            return cleanup_installed_runtime(Path(args.root), diagnostic)
        except (OSError, RuntimeError, ValueError, TimeoutError) as exc:
            _write_line(f"HERFY_RUNTIME_CLEANUP_FAILED: {exc}")
            return 1
    args = parse_args()
    try:
        return apply_patch(
            Path(args.patch_zip),
            Path(args.root),
            Path(args.restart),
            args.wait,
            expected_sha256=args.sha256,
            expected_size=args.expected_size,
        )
    except (OSError, RuntimeError, ValueError, TimeoutError, zipfile.BadZipFile) as exc:
        _write_line(f"HERFY_UPDATE_AGENT_FAILED: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
