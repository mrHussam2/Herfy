"""Windows/Qt system-tray integration; no application business decisions."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from PySide6.QtCore import QPoint, Qt
from PySide6.QtGui import QAction, QFont, QIcon, QPainter, QPalette, QPixmap
from PySide6.QtWidgets import QMenu, QSystemTrayIcon, QWidget

from core.settings import _
from core.tray import (
    EXIT_TEXT,
    LOGIN_TEXT,
    LOGOUT_TEXT,
    OPEN_TEXT,
    SETTINGS_TEXT,
    validate_tray_contract,
)


@dataclass(frozen=True, slots=True)
class TrayBadgeState:
    unread_count: int = 0
    update_available: bool = False

    @property
    def visible(self) -> bool:
        return self.unread_count > 0 or self.update_available

    @property
    def text(self) -> str:
        if self.unread_count > 99:
            return "99+"
        return (
            str(self.unread_count)
            if self.unread_count > 0
            else "!" if self.update_available else ""
        )


class SystemTrayAdapter:
    """Single system-tray adapter. Callbacks are supplied by the runtime owner."""

    def __init__(
        self,
        *,
        parent: QWidget,
        base_icon: QIcon,
        tooltip: str,
        open_window: Callable[[], None],
        hide_window: Callable[[], None],
        show_login: Callable[[], None],
        logout: Callable[[], None],
        open_settings: Callable[[], None],
        exit_application: Callable[[], None],
        activated: Callable[[object], None] | None = None,
    ) -> None:
        validate_tray_contract()
        if not QSystemTrayIcon.isSystemTrayAvailable():
            raise RuntimeError("system tray is not available")
        self._base_icon = QIcon(base_icon)
        self._state = TrayBadgeState()
        self.tray_icon = QSystemTrayIcon(parent)
        self.tray_icon.setToolTip(str(tooltip))
        self.menu = QMenu(parent)
        self.open_action = QAction(_(OPEN_TEXT), parent)
        self.hide_action = QAction(_("Hide HERFY"), parent)
        self.login_action = QAction(_(LOGIN_TEXT), parent)
        self.identity_action = QAction(parent)
        self.identity_action.setEnabled(False)
        self.logout_action = QAction(_(LOGOUT_TEXT), parent)
        self.settings_action = QAction(_(SETTINGS_TEXT), parent)
        self.monitoring_action = QAction(parent)
        self.monitoring_action.setEnabled(False)
        self.notifications_action = QAction(parent)
        self.notifications_action.setEnabled(False)
        self.exit_action = QAction(_(EXIT_TEXT), parent)
        for action, callback in (
            (self.open_action, open_window),
            (self.hide_action, hide_window),
            (self.login_action, show_login),
            (self.logout_action, logout),
            (self.settings_action, open_settings),
            (self.exit_action, exit_application),
        ):
            action.triggered.connect(callback)
        for action in (
            self.open_action,
            self.hide_action,
            self.identity_action,
            self.login_action,
            self.logout_action,
            self.settings_action,
            self.monitoring_action,
            self.notifications_action,
            self.exit_action,
        ):
            self.menu.addAction(action)
        self.tray_icon.setContextMenu(self.menu)
        if activated is not None:
            self.tray_icon.activated.connect(activated)
        self._apply_icon()
        self.set_session_state(None)

    @property
    def state(self) -> TrayBadgeState:
        return self._state

    def set_badge(self, *, unread_count: int = 0, update_available: bool = False) -> None:
        self._state = TrayBadgeState(max(0, int(unread_count)), bool(update_available))
        self._apply_icon()

    def set_session_state(
        self,
        display_name: str | None,
        *,
        monitoring_enabled: bool = True,
        notifications_enabled: bool = True,
    ) -> None:
        username = str(display_name or "").strip()
        signed_in = bool(username)
        self.identity_action.setText(_("User: {username}").format(username=username))
        self.logout_action.setText(_("Log out — {username}").format(username=username))
        self.monitoring_action.setText(
            _("Monitoring: {state}").format(
                state=_("Enabled") if monitoring_enabled else _("Disabled")
            )
        )
        self.notifications_action.setText(
            _("Notifications: {state}").format(
                state=_("Enabled") if notifications_enabled else _("Disabled")
            )
        )
        for action in (
            self.identity_action,
            self.logout_action,
            self.monitoring_action,
            self.notifications_action,
        ):
            action.setVisible(signed_in)
        self.login_action.setVisible(not signed_in)

    def show(self) -> None:
        self.tray_icon.show()
        self.tray_icon.setVisible(True)

    def hide(self) -> None:
        self.tray_icon.hide()
        self.tray_icon.setVisible(False)

    def close(self) -> None:
        try:
            self.tray_icon.hide()
            self.tray_icon.setContextMenu(None)
            self.menu.clear()
            self.menu.deleteLater()
            self.tray_icon.deleteLater()
        finally:
            self._state = TrayBadgeState()

    def _apply_icon(self) -> None:
        self.tray_icon.setIcon(self._render_icon(self._base_icon, self._state))

    @staticmethod
    def _render_icon(base_icon: QIcon, state: TrayBadgeState) -> QIcon:
        size = 64
        pixmap = base_icon.pixmap(size, size)
        if pixmap.isNull():
            pixmap = QPixmap(size, size)
            pixmap.fill(Qt.transparent)
        if not state.visible:
            return QIcon(pixmap)
        canvas = QPixmap(size, size)
        canvas.fill(Qt.transparent)
        painter = QPainter(canvas)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.drawPixmap(0, 0, pixmap)
        diameter = 30 if len(state.text) <= 2 else 36
        center = QPoint(size - diameter // 2 - 2, diameter // 2 + 2)
        painter.setPen(Qt.NoPen)
        painter.setBrush(QPalette().color(QPalette.LinkVisited))
        painter.drawEllipse(center, diameter // 2, diameter // 2)
        font = QFont()
        font.setBold(True)
        font.setPixelSize(14 if len(state.text) <= 2 else 11)
        painter.setFont(font)
        painter.setPen(QPalette().color(QPalette.HighlightedText))
        painter.drawText(
            center.x() - diameter // 2,
            center.y() - diameter // 2,
            diameter,
            diameter,
            Qt.AlignCenter,
            state.text,
        )
        painter.end()
        return QIcon(canvas)
