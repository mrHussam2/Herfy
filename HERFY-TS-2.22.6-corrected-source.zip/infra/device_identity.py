from __future__ import annotations

from threading import RLock
from uuid import UUID, uuid4

from core.settings import runtime_cache_path
from infra.files import read_json_dict, write_json_dict

_LOCK = RLock()
_FORMAT = "herfy-device-v1"


class PersistentDeviceIdentity:
    """Adapter that preserves the existing on-disk device identity contract."""

    def get_device_id(self) -> str:
        return get_or_create_device_id()


def _normalized_uuid(value: object) -> str:
    try:
        parsed = UUID(str(value or "").strip())
    except (ValueError, AttributeError, TypeError):
        return ""
    return str(parsed)


def get_or_create_device_id() -> str:
    """Return a stable, non-secret installation identifier.

    The identifier contains no user, host, network, or hardware information.
    It exists only to correlate server sessions and synchronization operations.
    """
    path = runtime_cache_path("device/device_identity.json")
    with _LOCK:
        payload = read_json_dict(path)
        if payload.get("format") == _FORMAT:
            existing = _normalized_uuid(payload.get("device_id"))
            if existing:
                return existing

        device_id = str(uuid4())
        write_json_dict(
            path,
            {"format": _FORMAT, "device_id": device_id},
            ensure_ascii=False,
        )
        return device_id
