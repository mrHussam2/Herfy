param(
    [switch]$PreflightOnly,

    [string]$CertThumbprint = "",

    [ValidatePattern('^https://')]
    [string]$TimestampUrl = "https://timestamp.digicert.com",

    [string]$UpdatePrivateKeyPath = "C:\HERFY-OFFLINE-KEY\update-signing-private.pem",

    [string]$PublicationPath = "",

    # Retained for older invocation scripts; Ed25519 verification is still mandatory.
    [switch]$AllowUnsignedAuthenticode,

    [string]$LocalPublishRoot = "",

    [string]$SshTarget = "root@herfy.online",

    [switch]$SkipDependencies,
    [string]$BuildPython = ""
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$SourceRoot = Split-Path -Parent $PSScriptRoot
$ReleaseContractPath = Join-Path $PSScriptRoot "release_contract.json"
$AuditScript = Join-Path $PSScriptRoot "audit.py"

function Fail([string]$Message) {
    throw $Message
}

function Need-File([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Fail "$Label not found: $Path"
    }
}

function Need-Command([string]$Name) {
    $command = Get-Command $Name -ErrorAction SilentlyContinue
    if (-not $command) {
        Fail "$Name is required for production publication."
    }
    return $command.Source
}

function Hash([string]$Path) {
    Need-File $Path "File to hash"
    $stream = [System.IO.File]::OpenRead($Path)
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $algorithm.ComputeHash($stream)
        return (-join ($bytes | ForEach-Object { $_.ToString("x2") }))
    }
    finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}

function Get-ReleaseContract {
    Need-File $ReleaseContractPath "Release contract"
    $contract = Get-Content -LiteralPath $ReleaseContractPath -Raw | ConvertFrom-Json
    $expected = [ordered]@{
        api_base_url = "https://api.herfy.online/api"
        server_root = "/opt/server"
        update_manifest_url = "https://updates.herfy.online/updates/manifest"
        updates_root = "/opt/server/updates"
    }
    foreach ($entry in $expected.GetEnumerator()) {
        if ([string]$contract.$($entry.Key) -ne $entry.Value) {
            Fail "Release contract drift for $($entry.Key)."
        }
    }
    return $expected
}

function Assert-PublicArtifact(
    [string]$Url,
    [string]$ExpectedHash,
    [string]$Label
) {
    if (-not $Url.StartsWith("https://updates.herfy.online/updates/packages/")) {
        Fail "Noncanonical public $Label URL."
    }
    if ($ExpectedHash -notmatch '^[A-Fa-f0-9]{64}$') {
        Fail "Invalid expected SHA-256 for public $Label."
    }
    # The artifacts have already been SHA-256 checked on the server after the
    # SSH upload.  Here we prove that the public CDN route exposes their bytes
    # without requiring a second full multi-megabyte download from the builder.
    $download = Join-Path ([IO.Path]::GetTempPath()) ("herfy-public-range-" + [Guid]::NewGuid())
    $headers = "$download.headers"
    try {
        $curl = Need-Command "curl.exe"
        & $curl --fail --location --silent --show-error --connect-timeout 20 --max-time 30 --retry 2 --range 0-1023 --dump-header $headers --output $download $Url
        if ($LASTEXITCODE -ne 0) {
            Fail "Public $Label range download failed with exit code $LASTEXITCODE."
        }
        if ((Get-Item -LiteralPath $download).Length -lt 1) {
            Fail "Public $Label range download was empty."
        }
        if (-not (Select-String -LiteralPath $headers -Pattern '^Content-Range:\s*bytes\s+0-' -Quiet)) {
            Fail "Public $Label did not honor its byte-range request."
        }
    }
    finally {
        Remove-Item -LiteralPath $download -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $headers -Force -ErrorAction SilentlyContinue
    }
}

$contract = Get-ReleaseContract
if ($PreflightOnly) {
    $contract | ConvertTo-Json -Compress
    exit 0
}

Set-Location $SourceRoot
$identity = Get-Content -LiteralPath (Join-Path $SourceRoot "version.json") -Raw | ConvertFrom-Json
$version = [string]$identity.version
if ($version -notmatch '^\d+\.\d+\.\d+$') {
    Fail "Release version is not semantic."
}

if ($PublicationPath) {
    # Authenticode is independent of the mandatory signed update manifest.
    # The audit below rejects unsigned or untrusted update publications.
    $publicationBase = (Resolve-Path -LiteralPath $PublicationPath -ErrorAction Stop).Path
    $venvPython = if ($BuildPython) { $BuildPython } else { Join-Path $SourceRoot ".venv-build\Scripts\python.exe" }
    Need-File $venvPython "Build Python"
    & $venvPython $AuditScript verify_update_transition --root $SourceRoot --publication $publicationBase
    if ($LASTEXITCODE -ne 0) {
        Fail "Verified local Ed25519 publication is required before production upload."
    }
}
else {
    Need-File $UpdatePrivateKeyPath "Offline Ed25519 update private key"
    $releaseScript = Join-Path $PSScriptRoot "release.ps1"
    Need-File $releaseScript "Canonical release pipeline"
    $releaseArgs = @("-UpdatePrivateKeyPath", $UpdatePrivateKeyPath)
    if (-not [string]::IsNullOrWhiteSpace($CertThumbprint)) {
        $releaseArgs += @("-CertThumbprint", $CertThumbprint, "-TimestampUrl", $TimestampUrl)
    }
    if ($LocalPublishRoot) {
        $releaseArgs += @("-PublishRoot", $LocalPublishRoot)
    }
    if ($SkipDependencies) {
        $releaseArgs += "-SkipDependencies"
    }
    & $releaseScript @releaseArgs
    if ($LASTEXITCODE -ne 0) {
        Fail "Canonical release pipeline failed with exit code $LASTEXITCODE."
    }
    $publicationBase = Join-Path $SourceRoot "release\publication"
}

Need-File $AuditScript "Release audit tool"
$ssh = Need-Command "ssh.exe"
$scp = Need-Command "scp.exe"
$publicationRoot = Join-Path $publicationBase "updates"
$runtime = Join-Path $publicationRoot "packages\HERFY-TS-$version-windows-x64-runtime.zip"
$installer = Join-Path $publicationRoot "packages\HERFY-TS-Setup-$version-windows-x64.exe"
$manifest = Join-Path $publicationRoot "manifest"
$publicKey = Join-Path $publicationRoot "public-key"
foreach ($item in @(
    @($runtime, "Runtime package"),
    @($installer, "Installer"),
    @($manifest, "Signed update manifest"),
    @($publicKey, "Published update public key")
)) {
    Need-File $item[0] $item[1]
}
$runtimeHash = Hash $runtime
$installerHash = Hash $installer
$manifestHash = Hash $manifest
$publicKeyHash = Hash $publicKey

$remoteRoot = [string]$contract.updates_root
$remoteStage = "$remoteRoot/.incoming-herfy-$version-$PID"
$remotePreflight = @"
set -eu
test -d '$remoteRoot'
test -w '$remoteRoot'
systemctl is-active --quiet nginx
systemctl is-active --quiet herfy-api
mkdir -m 0700 '$remoteStage'
"@
& $ssh -o BatchMode=yes -o ConnectTimeout=20 $SshTarget $remotePreflight
if ($LASTEXITCODE -ne 0) {
    Fail "Production update-host preflight failed."
}

try {
    & $scp -o BatchMode=yes -o ConnectTimeout=20 -r $publicationRoot "${SshTarget}:$remoteStage/updates"
    if ($LASTEXITCODE -ne 0) {
        Fail "Release artifact upload failed."
    }

    $remotePublish = @"
set -eu
source='$remoteStage/updates'
destination='$remoteRoot/updates'
runtime='HERFY-TS-$version-windows-x64-runtime.zip'
installer='HERFY-TS-Setup-$version-windows-x64.exe'
test -f "`$source/manifest"
test -f "`$source/public-key"
test -f "`$source/packages/`$runtime"
test -f "`$source/packages/`$installer"
test "`$(sha256sum "`$source/packages/`$runtime" | awk '{print `$1}')" = '$runtimeHash'
test "`$(sha256sum "`$source/packages/`$installer" | awk '{print `$1}')" = '$installerHash'
test "`$(sha256sum "`$source/manifest" | awk '{print `$1}')" = '$manifestHash'
test "`$(sha256sum "`$source/public-key" | awk '{print `$1}')" = '$publicKeyHash'
install -d -m 0755 "`$destination/packages"
for item in "`$runtime" "`$installer"; do
  install -m 0644 "`$source/packages/`$item" "`$destination/packages/`$item"
  cmp -s "`$source/packages/`$item" "`$destination/packages/`$item"
done
install -m 0644 "`$source/public-key" "`$destination/public-key"
cmp -s "`$source/public-key" "`$destination/public-key"
# Legacy contract manifests must be in place before the canonical manifest is
# advertised.  They use the same verified packages and pinned Ed25519 key,
# allowing supported pre-contract clients to resolve their signed route while
# the default manifest continues to serve current clients.
if [ -d "`$source/manifests" ]; then
  find "`$source/manifests" -type f -name manifest -print | while IFS= read -r legacy_manifest; do
    relative="`${legacy_manifest#`$source/manifests/}"
    target="`$destination/manifests/`$relative"
    install -d -m 0755 "`$(dirname "`$target")"
    install -m 0644 "`$legacy_manifest" "`$target"
    cmp -s "`$legacy_manifest" "`$target"
  done
fi
manifest_tmp="`$destination/.manifest-$version"
install -m 0644 "`$source/manifest" "`$manifest_tmp"
cmp -s "`$source/manifest" "`$manifest_tmp"
mv -f "`$manifest_tmp" "`$destination/manifest"
"@
    & $ssh -o BatchMode=yes -o ConnectTimeout=20 $SshTarget $remotePublish
    if ($LASTEXITCODE -ne 0) {
        Fail "Atomic production update publication failed."
    }
}
finally {
    & $ssh -o BatchMode=yes -o ConnectTimeout=20 $SshTarget "rm -rf '$remoteStage'" 2>$null | Out-Null
}

$cacheBust = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$publicManifestFile = Join-Path ([IO.Path]::GetTempPath()) ("herfy-manifest-" + [Guid]::NewGuid())
try {
    Invoke-WebRequest -Uri "$($contract.update_manifest_url)?t=$cacheBust" -OutFile $publicManifestFile -TimeoutSec 30
    if ((Hash $publicManifestFile) -ne (Hash $manifest)) {
        Fail "Public signed manifest bytes mismatch."
    }
    $publicManifest = Get-Content -LiteralPath $publicManifestFile -Raw | ConvertFrom-Json
}
finally {
    Remove-Item -LiteralPath $publicManifestFile -Force -ErrorAction SilentlyContinue
}
if ([string]$publicManifest.version -ne $version) {
    Fail "Public manifest version mismatch."
}
if ([string]$publicManifest.key_id -ne [string]$identity.update_key_id) {
    Fail "Public manifest key ID mismatch."
}
if ([string]$publicManifest.contract_sha256 -ne [string]$identity.api_contract_sha256) {
    Fail "Public manifest contract hash mismatch."
}
Assert-PublicArtifact ([string]$publicManifest.runtime_url) ([string]$publicManifest.runtime_sha256) "runtime"
Assert-PublicArtifact ([string]$publicManifest.installer_url) ([string]$publicManifest.installer_sha256) "installer"

# WEBSITE DOWNLOAD SWITCH: the server-side tool atomically replaces a static
# installer link or verifies the manifest-driven website contract, then checks
# every configured HERFY web root and validates Nginx before returning success.
$installerUrl = [string]$publicManifest.installer_url
$remoteWebsiteTool = "/tmp/herfy-switch-website-download-$PID.py"
try {
    & $scp -o BatchMode=yes -o ConnectTimeout=20 $AuditScript "${SshTarget}:$remoteWebsiteTool"
    if ($LASTEXITCODE -ne 0) {
        Fail "Website switch tool upload failed."
    }
    & $ssh -o BatchMode=yes -o ConnectTimeout=20 $SshTarget "python3 '$remoteWebsiteTool' switch_website_download --domain herfy.online --installer-url '$installerUrl'"
    if ($LASTEXITCODE -ne 0) {
        Fail "Website download switch failed."
    }
}
finally {
    & $ssh -o BatchMode=yes -o ConnectTimeout=20 $SshTarget "rm -f '$remoteWebsiteTool'" 2>$null | Out-Null
}

Write-Output "PRODUCTION_UPDATE_PUBLICATION=PASS"
