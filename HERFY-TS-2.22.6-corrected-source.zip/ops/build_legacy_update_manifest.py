"""Create a one-release Ed25519 manifest bridge for a legacy update contract."""

from __future__ import annotations

import argparse
import base64
import getpass
import hashlib
import json
import os
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)


def _canonical_payload(payload: dict[str, object]) -> bytes:
    body = {key: value for key, value in payload.items() if key != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )


def _load_private_key(path: Path, password_env: str) -> Ed25519PrivateKey:
    raw = path.read_bytes()
    password = os.environ.get(password_env)
    if password is None:
        password = getpass.getpass("Update signing key passphrase: ")
    key = serialization.load_pem_private_key(raw, password=password.encode("utf-8"))
    if not isinstance(key, Ed25519PrivateKey):
        raise RuntimeError("The update signing key must use Ed25519.")
    return key


def _load_public_key(path: Path) -> Ed25519PublicKey:
    key = serialization.load_pem_public_key(path.read_bytes())
    if not isinstance(key, Ed25519PublicKey):
        raise RuntimeError("The packaged update public key must use Ed25519.")
    return key


def _key_id(key: Ed25519PublicKey) -> str:
    raw = key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return hashlib.sha256(raw).hexdigest()


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--publication", required=True, type=Path)
    parser.add_argument("--private-key", required=True, type=Path)
    parser.add_argument("--legacy-contract-sha256", required=True)
    parser.add_argument("--password-env", default="HERFY_UPDATE_KEY_PASSWORD")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    legacy_contract = args.legacy_contract_sha256.strip().lower()
    if len(legacy_contract) != 64 or any(
        char not in "0123456789abcdef" for char in legacy_contract
    ):
        raise RuntimeError("The legacy update contract hash must be a lowercase SHA-256 value.")
    updates = args.publication.resolve() / "updates"
    manifest_path = updates / "manifest"
    public_key_path = updates / "public-key"
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError("The canonical update manifest is invalid.")
    public_key = _load_public_key(public_key_path)
    signature = base64.b64decode(str(payload.get("signature") or ""), validate=True)
    public_key.verify(signature, _canonical_payload(payload))
    private_key = _load_private_key(args.private_key.resolve(), args.password_env)
    derived_key_id = _key_id(private_key.public_key())
    if derived_key_id != _key_id(public_key) or derived_key_id != str(payload.get("key_id") or ""):
        raise RuntimeError("The private signing key does not match the packaged public key.")
    payload["contract_sha256"] = legacy_contract
    payload["signature"] = base64.b64encode(private_key.sign(_canonical_payload(payload))).decode(
        "ascii"
    )
    public_key.verify(
        base64.b64decode(payload["signature"], validate=True), _canonical_payload(payload)
    )
    destination = updates / "manifests" / legacy_contract / "manifest"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(
        json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
    )
    print(f"LEGACY_MANIFEST=PASS path={destination}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
