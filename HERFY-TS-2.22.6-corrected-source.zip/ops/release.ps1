param(
    # Windows Authenticode is optional. Update authenticity is enforced by
    # the mandatory Ed25519 manifest/package signature and SHA-256 hashes.
    [ValidatePattern('^[A-Fa-f0-9 ]*$')]
    [string]$CertThumbprint = "",

    [string]$TimestampUrl = "",

    [Parameter(Mandatory = $true)]
    [string]$UpdatePrivateKeyPath,

    [string]$PublishRoot = "",

    [switch]$SkipDependencies,

    [switch]$Authenticode,

    [string]$BuildPython = ""
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest
$SourceRoot = Split-Path -Parent $PSScriptRoot
$AuditScript = Join-Path $PSScriptRoot "audit.py"
$PackagingRoot = Join-Path $PSScriptRoot "packaging"
Set-Location $SourceRoot

function Fail([string]$Message) {
    throw $Message
}

function Require-File([string]$Path, [string]$Label) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        Fail "$Label not found: $Path"
    }
}

# Keep release verification independent of optional PowerShell utility modules.
# This is also used by the publication hand-off, so hashes are identical on
# Windows PowerShell and PowerShell Core hosts.
function Get-HerfyFileSha256([string]$Path) {
    Require-File $Path "File to hash"
    $stream = [System.IO.File]::OpenRead($Path)
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = $algorithm.ComputeHash($stream)
        return (-join ($bytes | ForEach-Object { $_.ToString("x2") }))
    }
    finally {
        $algorithm.Dispose()
        $stream.Dispose()
    }
}

function Resolve-SignTool {
    $cmd = Get-Command signtool.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $kits = Join-Path ${env:ProgramFiles(x86)} "Windows Kits\10\bin"
    if (Test-Path $kits) {
        $candidate = Get-ChildItem $kits -Directory -ErrorAction SilentlyContinue |
            Sort-Object Name -Descending |
            ForEach-Object { Join-Path $_.FullName "x64\signtool.exe" } |
            Where-Object { Test-Path $_ } |
            Select-Object -First 1
        if ($candidate) { return $candidate }
    }

    # Windows SDK is optional. PowerShell Authenticode is used as fallback.
    return $null
}

function Resolve-Iscc {
    $cmd = Get-Command ISCC.exe -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }

    $candidates = @(
        (Join-Path ${env:ProgramFiles(x86)} "Inno Setup 6\ISCC.exe"),
        (Join-Path $env:ProgramFiles "Inno Setup 6\ISCC.exe")
    )
    foreach ($candidate in $candidates) {
        if (Test-Path $candidate) { return $candidate }
    }
    Fail "ISCC.exe not found. Install Inno Setup 6."
}

function Normalize-Thumbprint([string]$Value) {
    return ($Value -replace '\s','').ToUpperInvariant()
}

function Assert-CodeSigningCertificate([string]$Thumbprint) {
    $certPath = "Cert:\CurrentUser\My\$Thumbprint"
    if (-not (Test-Path $certPath)) {
        Fail "Code-signing certificate not found in CurrentUser\Personal: $Thumbprint"
    }
    $cert = Get-Item $certPath
    if (-not $cert.HasPrivateKey) {
        Fail "Certificate exists but its private key is unavailable."
    }
    if ($cert.NotAfter -le (Get-Date)) {
        Fail "Code-signing certificate is expired: $($cert.NotAfter)"
    }
    $ekuOids = @()

    foreach ($eku in @($cert.EnhancedKeyUsageList)) {
        if ($null -eq $eku) { continue }

        $oid = $null

        if ($eku.PSObject.Properties.Name -contains "ObjectId") {
            $obj = $eku.ObjectId

            if ($null -ne $obj) {
                if ($obj.PSObject.Properties.Name -contains "Value") {
                    $oid = [string]$obj.Value
                }
                elseif ($obj -is [string]) {
                    $oid = [string]$obj
                }
            }
        }

        if (-not $oid -and ($eku.PSObject.Properties.Name -contains "Oid")) {
            $obj = $eku.Oid

            if ($null -ne $obj) {
                if ($obj.PSObject.Properties.Name -contains "Value") {
                    $oid = [string]$obj.Value
                }
                elseif ($obj -is [string]) {
                    $oid = [string]$obj
                }
            }
        }

        if (-not $oid -and ($eku.PSObject.Properties.Name -contains "Value")) {
            $oid = [string]$eku.Value
        }

        if ($oid) {
            $ekuOids += $oid
        }
    }

    # Fallback for Windows/PowerShell versions that expose EnhancedKeyUsageList differently.
    if ($ekuOids.Count -eq 0) {
        foreach ($ext in @($cert.Extensions)) {
            if ($null -eq $ext -or $null -eq $ext.Oid) { continue }

            $extOid = $null
            if ($ext.Oid.PSObject.Properties.Name -contains "Value") {
                $extOid = [string]$ext.Oid.Value
            }

            if ($extOid -ne "2.5.29.37") { continue }

            $formatted = [string]$ext.Format($false)

            if (
                $formatted -match "1\.3\.6\.1\.5\.5\.7\.3\.3" -or
                $formatted -match "Code Signing"
            ) {
                $ekuOids += "1.3.6.1.5.5.7.3.3"
            }
        }
    }

    if ($ekuOids -notcontains "1.3.6.1.5.5.7.3.3") {
        Fail "Certificate does not contain the Code Signing EKU (1.3.6.1.5.5.7.3.3), or Windows could not expose it."
    }
    return $cert
}

function Stop-HerfyRuntimeProcesses {
    foreach ($processName in @("HERFY-TS", "HERFY-TSUpdateAgent")) {
        @(Get-Process -Name $processName -ErrorAction SilentlyContinue) |
            ForEach-Object {
                try {
                    Stop-Process -Id $_.Id -Force -ErrorAction Stop
                    Wait-Process -Id $_.Id -Timeout 5 -ErrorAction SilentlyContinue
                }
                catch {
                    # Process may already have exited.
                }
            }
    }
}

function Test-ExclusiveWritable([string]$Path) {
    try {
        $stream = [System.IO.File]::Open(
            $Path,
            [System.IO.FileMode]::Open,
            [System.IO.FileAccess]::ReadWrite,
            [System.IO.FileShare]::None
        )
        $stream.Dispose()
        return $true
    }
    catch {
        return $false
    }
}

function Wait-ExclusiveWritable(
    [string]$Path,
    [int]$TimeoutSeconds = 60
) {
    Require-File $Path "File to sign"

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)

    while ((Get-Date) -lt $deadline) {
        Stop-HerfyRuntimeProcesses

        if (Test-ExclusiveWritable $Path) {
            # Give AV/indexer a short quiet period before modifying the PE.
            Start-Sleep -Milliseconds 750
            if (Test-ExclusiveWritable $Path) {
                return
            }
        }

        Start-Sleep -Milliseconds 500
    }

    Fail "File remained locked for $TimeoutSeconds seconds: $Path"
}

function Resolve-PowerShellTimestampUrl([string]$Rfc3161Url) {
    if ($env:HERFY_POWERSHELL_TIMESTAMP_URL) {
        return [string]$env:HERFY_POWERSHELL_TIMESTAMP_URL
    }

    if ($Rfc3161Url -match '^https://timestamp\.digicert\.com/?$') {
        return "http://timestamp.digicert.com"
    }

    if ($Rfc3161Url -match '^https://') {
        return ($Rfc3161Url -replace '^https://', 'http://')
    }

    return $Rfc3161Url
}

function Sign-File(
    [string]$Path,
    [string]$SignTool,
    [System.Security.Cryptography.X509Certificates.X509Certificate2]$Certificate,
    [string]$Timestamp
) {
    Require-File $Path "File to sign"
    Write-Host "Signing: $Path" -ForegroundColor Cyan

    Stop-HerfyRuntimeProcesses
    Wait-ExclusiveWritable -Path $Path -TimeoutSeconds 60

    if ($SignTool) {
        $signed = $false
        $lastExit = $null

        for ($attempt = 1; $attempt -le 5; $attempt++) {
            Stop-HerfyRuntimeProcesses
            Wait-ExclusiveWritable -Path $Path -TimeoutSeconds 30

            & $SignTool sign /sha1 $Certificate.Thumbprint /fd SHA256 /tr $Timestamp /td SHA256 /v $Path
            $lastExit = $LASTEXITCODE

            if ($lastExit -eq 0) {
                $signed = $true
                break
            }

            Start-Sleep -Seconds $attempt
        }

        if (-not $signed) {
            Fail "signtool failed for '$Path' after 5 attempts. Exit code: $lastExit"
        }

        & $SignTool verify /pa /v $Path
        if ($LASTEXITCODE -ne 0) {
            Fail "signtool verification failed for: $Path"
        }
    }
    else {
        Write-Host "signtool.exe not found; using PowerShell Authenticode signing." -ForegroundColor Yellow

        $powerShellTimestamp = Resolve-PowerShellTimestampUrl $Timestamp
        Write-Host "PowerShell timestamp: $powerShellTimestamp" -ForegroundColor DarkGray

        if (-not $powerShellTimestamp.StartsWith("http://")) {
            Fail "PowerShell Authenticode timestamp URL must use http://. Resolved URL: $powerShellTimestamp"
        }

        $result = $null
        $lastError = $null

        for ($attempt = 1; $attempt -le 5; $attempt++) {
            try {
                Stop-HerfyRuntimeProcesses
                Wait-ExclusiveWritable -Path $Path -TimeoutSeconds 30

                $result = Set-AuthenticodeSignature `
                    -FilePath $Path `
                    -Certificate $Certificate `
                    -HashAlgorithm SHA256 `
                    -TimestampServer $powerShellTimestamp `
                    -ErrorAction Stop

                if ($result.Status -eq "Valid") {
                    break
                }

                $lastError = "$($result.Status) $($result.StatusMessage)"
            }
            catch {
                $lastError = $_.Exception.Message
            }

            Start-Sleep -Seconds $attempt
        }

        if ($null -eq $result -or $result.Status -ne "Valid") {
            Fail "PowerShell Authenticode signing failed for '$Path' after 5 attempts. Last error: $lastError"
        }
    }

    $signature = Get-AuthenticodeSignature -FilePath $Path
    if ($signature.Status -ne "Valid") {
        Fail "Authenticode status is '$($signature.Status)' for: $Path"
    }
    if (-not $signature.TimeStamperCertificate) {
        Fail "Timestamp was not attached to the signature: $Path"
    }
}

$useAuthenticode = $Authenticode -or -not [string]::IsNullOrWhiteSpace($CertThumbprint)
$thumbprint = ""
$cert = $null
$signTool = $null
$publisher = "HERFY"
if ($useAuthenticode) {
    if ([string]::IsNullOrWhiteSpace($CertThumbprint)) {
        Fail "-Authenticode requires -CertThumbprint."
    }
    if ([string]::IsNullOrWhiteSpace($TimestampUrl) -or -not $TimestampUrl.StartsWith("https://")) {
        Fail "-Authenticode requires an HTTPS -TimestampUrl."
    }
    $thumbprint = Normalize-Thumbprint $CertThumbprint
    $cert = Assert-CodeSigningCertificate $thumbprint
    $publisher = $cert.GetNameInfo([System.Security.Cryptography.X509Certificates.X509NameType]::SimpleName, $false)
    if ([string]::IsNullOrWhiteSpace($publisher)) {
        Fail "Could not derive publisher name from the code-signing certificate."
    }
    $signTool = Resolve-SignTool
}
$iscc = Resolve-Iscc

Write-Host ""
if ($useAuthenticode) {
    Write-Host "Certificate:" -ForegroundColor Yellow
    Write-Host "  Subject    : $($cert.Subject)"
    Write-Host "  Thumbprint : $thumbprint"
    Write-Host "  Expires    : $($cert.NotAfter)"
    Write-Host "  Publisher  : $publisher"
    Write-Host "Timestamp   : $TimestampUrl"
    if ($signTool) {
        Write-Host "Signing tool: $signTool"
    } else {
        Write-Host "Signing tool: PowerShell Authenticode fallback"
    }
} else {
    Write-Host "Authenticode: not requested; release authenticity is enforced by Ed25519 + SHA-256." -ForegroundColor Yellow
}
Write-Host ""

# 1) Build and validate unsigned runtime.
$buildScript = Join-Path $PSScriptRoot "build.ps1"
if ($SkipDependencies) {
    & $buildScript -SkipInstall -BuildPython $BuildPython
} else {
    & $buildScript -BuildPython $BuildPython
}

$runtime = Join-Path $SourceRoot "dist\HERFY-TS"
$mainExe = Join-Path $runtime "HERFY-TS.exe"
$agentExe = Join-Path $runtime "HERFY-TSUpdateAgent.exe"
Require-File $mainExe "Main executable"
Require-File $agentExe "Update agent"

# PyInstaller/Defender/indexers can retain a short-lived handle after build completion.
Stop-HerfyRuntimeProcesses
Wait-ExclusiveWritable -Path $mainExe -TimeoutSeconds 60
Wait-ExclusiveWritable -Path $agentExe -TimeoutSeconds 60
Start-Sleep -Seconds 2

# 2) Authenticode is optional; Ed25519 package signing below is mandatory.
if ($useAuthenticode) {
    Sign-File $mainExe $signTool $cert $TimestampUrl
    Sign-File $agentExe $signTool $cert $TimestampUrl
}

# 3) Recreate runtime manifest after optional Authenticode signing.  Keep the
# same validated Python environment that performed the build rather than
# assuming a developer-only `.venv-build` path exists.
if ([string]::IsNullOrWhiteSpace($BuildPython)) {
    $BuildPython = Join-Path $SourceRoot ".venv-build\Scripts\python.exe"
}
Require-File $BuildPython "Build Python"
$venvPython = (Resolve-Path -LiteralPath $BuildPython).Path
& $venvPython $AuditScript write_runtime_manifest $runtime
if ($LASTEXITCODE -ne 0) { Fail "Failed to regenerate runtime_files.txt." }

# 4) Validate the frozen runtime (Authenticode-signed when requested).
& $agentExe --self-check
if ($LASTEXITCODE -ne 0) { Fail "Signed UpdateAgent self-check failed." }
& $mainExe --self-check
if ($LASTEXITCODE -ne 0) { Fail "Signed application self-check failed." }

# 5) Read canonical release identity and compile installer.
# PUBLIC API BINDING
# SERVER PREFLIGHT
# verify_update_transition.py
# publish_publication.sh
# Website download switcher
$versionPath = Join-Path $SourceRoot "version.json"
$v = Get-Content $versionPath -Raw | ConvertFrom-Json
$Version=[string]$v.version
$Contract=[string]$v.api_contract_sha256
$ApiBaseUrl=[string]$v.api_base_url
$UpdateOrigin=[string]$v.update_origin
$UpdateKeyId=[string]$v.update_key_id
if (-not $Version) { Fail "version.json does not contain a version." }
if (-not $Contract) { Fail "version.json does not contain api_contract_sha256." }
if (-not $ApiBaseUrl -or -not $ApiBaseUrl.StartsWith("https://api.herfy.online/api")) { Fail "PUBLIC API BINDING drift: $ApiBaseUrl" }
if ($ApiBaseUrl.Contains("/api/" + "v2")) { Fail "Forbidden API binding detected." }
if ($UpdateOrigin -ne "https://updates.herfy.online") { Fail "Update origin drift: $UpdateOrigin" }
if (-not $UpdateKeyId) { Fail "Update key id is missing." }
$version = $Version

$releaseDir = Join-Path $SourceRoot "release"
Remove-Item $releaseDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $releaseDir | Out-Null

$installerScript = Join-Path $PackagingRoot "HERFY-TS.iss"
Require-File $installerScript "Inno Setup script"
& $iscc "/DMyAppVersion=$version" "/DMyAppPublisher=$publisher" $installerScript
if ($LASTEXITCODE -ne 0) { Fail "Inno Setup compilation failed." }

$setup = Join-Path $releaseDir "HERFY-TS-Setup-$version-windows-x64.exe"
Require-File $setup "Installer"

# 6) Optionally Authenticode-sign the installer. The release is still
# cryptographically verified through the Ed25519 update protocol either way.
if ($useAuthenticode) {
    Sign-File $setup $signTool $cert $TimestampUrl
}


# 7) Build the canonical signed update publication tree.
$privateKey = (Resolve-Path -LiteralPath $UpdatePrivateKeyPath).Path
Require-File $privateKey "Ed25519 update private key"

$publicationDir = Join-Path $releaseDir "publication"
$publicationTool = $AuditScript
Require-File $publicationTool "Update publication builder"

& $venvPython $publicationTool build_update_publication `
    --root $SourceRoot `
    --runtime-dir $runtime `
    --installer $setup `
    --private-key $privateKey `
    --out $publicationDir
if ($LASTEXITCODE -ne 0) {
    Fail "Canonical update publication generation failed."
}

# 8) Prove that this publication is a real newer update from the currently
# packaged server-contract baseline, and that the signed manifest/artifacts
# agree byte-for-byte before any remote publication is attempted.
$transitionVerifier = $AuditScript
Require-File $transitionVerifier "Update transition verifier"
& $venvPython $transitionVerifier verify_update_transition `
    --root $SourceRoot `
    --publication $publicationDir
if ($LASTEXITCODE -ne 0) {
    Fail "Update transition verification failed."
}

# Optional live publication. Publish artifacts first and manifest LAST.
if (-not [string]::IsNullOrWhiteSpace($PublishRoot)) {
    $publishRootResolved = (Resolve-Path -LiteralPath $PublishRoot).Path
    $marker = Join-Path $publishRootResolved ".herfy-updates-origin"
    Require-File $marker "HERFY update-origin marker"
    $markerValue = (Get-Content -LiteralPath $marker -Raw).Trim()
    if ($markerValue -ne "https://updates.herfy.online") {
        Fail "Publish root marker does not identify https://updates.herfy.online. Refusing to publish."
    }

    $sourceUpdates = Join-Path $publicationDir "updates"
    $destUpdates = Join-Path $publishRootResolved "updates"
    $destPackages = Join-Path $destUpdates "packages"
    New-Item -ItemType Directory -Path $destPackages -Force | Out-Null

    # Copy packages and public key before the manifest.
    Copy-Item -LiteralPath (Join-Path $sourceUpdates "packages\HERFY-TS-$version-windows-x64-runtime.zip") `
        -Destination $destPackages -Force
    Copy-Item -LiteralPath (Join-Path $sourceUpdates "packages\HERFY-TS-Setup-$version-windows-x64.exe") `
        -Destination $destPackages -Force
    Copy-Item -LiteralPath (Join-Path $sourceUpdates "public-key") `
        -Destination (Join-Path $destUpdates "public-key") -Force

    # Byte-for-byte verify deployed artifacts before advertising them.
    foreach ($name in @(
        "HERFY-TS-$version-windows-x64-runtime.zip",
        "HERFY-TS-Setup-$version-windows-x64.exe"
    )) {
        $src = Join-Path (Join-Path $sourceUpdates "packages") $name
        $dst = Join-Path $destPackages $name
        if ((Get-HerfyFileSha256 $src) -ne (Get-HerfyFileSha256 $dst)) {
            Fail "Published artifact hash mismatch: $name"
        }
    }

    $sourcePublic = Join-Path $sourceUpdates "public-key"
    $destPublic = Join-Path $destUpdates "public-key"
    if ((Get-HerfyFileSha256 $sourcePublic) -ne (Get-HerfyFileSha256 $destPublic)) {
        Fail "Published update public-key hash mismatch."
    }

    # Manifest is copied last so clients never see metadata before artifacts exist.
    Copy-Item -LiteralPath (Join-Path $sourceUpdates "manifest") `
        -Destination (Join-Path $destUpdates "manifest") -Force

    if ((Get-HerfyFileSha256 (Join-Path $sourceUpdates "manifest")) -ne
        (Get-HerfyFileSha256 (Join-Path $destUpdates "manifest"))) {
        Fail "Published update manifest hash mismatch."
    }

    Write-Host "Published canonical update tree to: $publishRootResolved" -ForegroundColor Green
}

# 9) Produce hashes and release metadata for BOTH distributable artifacts.
$publishedRuntime = Join-Path $publicationDir "updates\packages\HERFY-TS-$version-windows-x64-runtime.zip"
$publishedInstaller = Join-Path $publicationDir "updates\packages\HERFY-TS-Setup-$version-windows-x64.exe"
Require-File $publishedRuntime "Published runtime archive"
Require-File $publishedInstaller "Published installer"

$runtimeHash = Get-HerfyFileSha256 $publishedRuntime
$installerHash = Get-HerfyFileSha256 $publishedInstaller
$hashLines = @(
    "$runtimeHash  $(Split-Path $publishedRuntime -Leaf)",
    "$installerHash  $(Split-Path $publishedInstaller -Leaf)"
)
Set-Content -LiteralPath (Join-Path $releaseDir "SHA256SUMS.txt") -Value $hashLines -Encoding ascii

$releaseInfo = [ordered]@{
    product = "HERFY-TS"
    version = [string]$version
    installer = (Split-Path $publishedInstaller -Leaf)
    installer_sha256 = $installerHash
    runtime = (Split-Path $publishedRuntime -Leaf)
    runtime_sha256 = $runtimeHash
    api_origin = $ApiBaseUrl
    updates_origin = $UpdateOrigin
    manifest_url = "$UpdateOrigin/updates/manifest"
    publisher = $publisher
    ed25519_signed = $true
    authenticode_signed = [bool]$useAuthenticode
    signer_subject = if ($cert) { $cert.Subject } else { "" }
    signer_thumbprint = $thumbprint
    timestamp_url = if ($useAuthenticode) { $TimestampUrl } else { "" }
    generated_utc = [DateTime]::UtcNow.ToString("o")
}
$releaseInfo | ConvertTo-Json -Depth 5 |
    Set-Content -LiteralPath (Join-Path $releaseDir "RELEASE_INFO.json") -Encoding utf8

# 10) Report optional Authenticode status without treating its absence as an
# update-security failure.
if ($useAuthenticode) {
    $items = @($mainExe, $agentExe, $setup)
    $summary = foreach ($item in $items) {
        $sig = Get-AuthenticodeSignature -FilePath $item
        [pscustomobject]@{
            File = $item
            Status = $sig.Status
            Signer = if ($sig.SignerCertificate) { $sig.SignerCertificate.Subject } else { "" }
            Timestamped = [bool]$sig.TimeStamperCertificate
        }
    }
    $summary | Format-Table -AutoSize
}

Write-Host ""
Write-Host "RELEASE OK" -ForegroundColor Green
Write-Host "Installer : $setup"
Write-Host "Runtime SHA-256  : $runtimeHash"
Write-Host "Installer SHA-256: $installerHash"
Write-Host "Checksums : $(Join-Path $releaseDir 'SHA256SUMS.txt')"
Write-Host "Metadata  : $(Join-Path $releaseDir 'RELEASE_INFO.json')"
