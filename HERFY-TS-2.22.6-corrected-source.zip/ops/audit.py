#!/usr/bin/env python3
from __future__ import annotations

import argparse
import ast
import base64
import hashlib
import io

# build_update_publication prompts encrypted Ed25519 keys with getpass.getpass
import json
import os
import sys
import tokenize
import zipfile
from collections import defaultdict
from collections.abc import Iterable
from copy import deepcopy
from difflib import SequenceMatcher
from pathlib import Path
from xml.etree import ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]

_SOURCE_DIRECTORIES = ("core", "services", "infra", "ui", "contracts")
_SOURCE_EXCLUSIONS = {
    "__pycache__",
    ".venv",
    ".venv-build",
    "build",
    "dist",
    "outputs",
    ".rollback",
}
_PUBLIC_RELEASE_FILES = {"resources/update_signing_public.pem"}
_SHELL_FORM_OWNERS = {
    "main_window": "ui/main_window_shell.py",
    "sidebar": "ui/theme_shell.py",
    "top_bar": "ui/theme_shell.py",
}
_MAIN_WINDOW_LAYOUT_METHODS = {
    "setColumnStretch",
    "setContentsMargins",
    "setHorizontalSpacing",
    "setMaximumSize",
    "setMinimumSize",
    "setMinimumWidth",
    "setRowStretch",
    "setSizePolicy",
    "setVerticalSpacing",
}


def _source_python_files() -> tuple[Path, ...]:
    paths = [ROOT / "main.py"]
    for directory in _SOURCE_DIRECTORIES:
        root = ROOT / directory
        if not root.is_dir():
            continue
        paths.extend(
            path
            for path in root.rglob("*.py")
            if not any(part in _SOURCE_EXCLUSIONS for part in path.parts)
        )
    return tuple(sorted(path for path in paths if path.is_file()))


class AstDefinition:
    """One named function represented by a name- and docstring-free AST."""

    __slots__ = ("path", "qualname", "lineno", "fingerprint", "node_count")

    def __init__(
        self,
        *,
        path: Path,
        qualname: str,
        lineno: int,
        fingerprint: str,
        node_count: int,
    ) -> None:
        self.path = path
        self.qualname = qualname
        self.lineno = lineno
        self.fingerprint = fingerprint
        self.node_count = node_count


class _AstDuplicateNormalizer(ast.NodeTransformer):
    """Remove presentation-only details before serializing a function AST."""

    @staticmethod
    def _without_docstring(node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if ast.get_docstring(node, clean=False) is not None:
            node.body = node.body[1:]

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        node.name = "_"
        self._without_docstring(node)
        return self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> ast.AsyncFunctionDef:
        node.name = "_"
        self._without_docstring(node)
        return self.generic_visit(node)


def _function_nodes(
    statements: Iterable[ast.stmt], scope: tuple[str, ...] = ()
) -> Iterable[tuple[tuple[str, ...], ast.FunctionDef | ast.AsyncFunctionDef]]:
    for statement in statements:
        if isinstance(statement, ast.ClassDef):
            yield from _function_nodes(statement.body, (*scope, statement.name))
        elif isinstance(statement, (ast.FunctionDef, ast.AsyncFunctionDef)):
            qualified_name = (*scope, statement.name)
            yield qualified_name, statement
            yield from _function_nodes(statement.body, qualified_name)


def _ast_definition(
    path: Path, scope: tuple[str, ...], node: ast.FunctionDef | ast.AsyncFunctionDef
) -> AstDefinition:
    normalized = _AstDuplicateNormalizer().visit(deepcopy(node))
    ast.fix_missing_locations(normalized)
    node_count = sum(1 for _ in ast.walk(normalized))
    fingerprint = hashlib.sha256(
        ast.dump(normalized, annotate_fields=True, include_attributes=False).encode("utf-8")
    ).hexdigest()
    return AstDefinition(
        path=path,
        qualname=".".join(scope),
        lineno=int(node.lineno),
        fingerprint=fingerprint,
        node_count=node_count,
    )


def ast_duplicate_groups(
    paths: Iterable[Path], *, minimum_node_count: int = 20
) -> tuple[tuple[AstDefinition, ...], ...]:
    """Find structurally identical functions after removing names and docstrings."""
    groups: dict[str, list[AstDefinition]] = {}
    for path in sorted((Path(item) for item in paths), key=lambda item: item.as_posix()):
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for scope, node in _function_nodes(tree.body):
            record = _ast_definition(path, scope, node)
            if record.node_count >= minimum_node_count:
                groups.setdefault(record.fingerprint, []).append(record)
    duplicates = [
        tuple(sorted(records, key=lambda item: (item.path.as_posix(), item.lineno)))
        for records in groups.values()
        if len(records) > 1
    ]
    return tuple(sorted(duplicates, key=lambda group: (group[0].path.as_posix(), group[0].lineno)))


def _normalized_function_tokens(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> tuple[str, ...]:
    """Return stable code tokens after removing a function's display-only details."""
    normalized = _AstDuplicateNormalizer().visit(deepcopy(node))
    ast.fix_missing_locations(normalized)
    source = ast.unparse(normalized)
    ignored = {
        tokenize.COMMENT,
        tokenize.ENCODING,
        tokenize.ENDMARKER,
        tokenize.INDENT,
        tokenize.NEWLINE,
        tokenize.NL,
        tokenize.DEDENT,
    }
    return tuple(
        token.string
        for token in tokenize.generate_tokens(io.StringIO(source).readline)
        if token.type not in ignored
    )


def near_duplicate_candidates(
    paths: Iterable[Path],
    *,
    minimum_token_count: int = 40,
    similarity_threshold: float = 0.92,
) -> tuple[tuple[AstDefinition, AstDefinition], ...]:
    """Find non-identical, structurally similar function pairs for review.

    This intentionally reports candidates rather than treating all similar
    control flow as defects. The AST gate is the fail-closed check for exact
    duplicate implementations; this lightweight pass directs human review to
    functions that may have independently grown the same responsibility.
    """
    records: list[tuple[AstDefinition, tuple[str, ...]]] = []
    for path in sorted((Path(item) for item in paths), key=lambda item: item.as_posix()):
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for scope, node in _function_nodes(tree.body):
            tokens = _normalized_function_tokens(node)
            if len(tokens) < minimum_token_count:
                continue
            records.append((_ast_definition(path, scope, node), tokens))

    if len(records) < 2:
        return ()

    shingle_size = 6
    shingle_index: dict[tuple[str, ...], list[int]] = defaultdict(list)
    for index, (_record, tokens) in enumerate(records):
        shingles = {
            tuple(tokens[offset : offset + shingle_size])
            for offset in range(len(tokens) - shingle_size + 1)
        }
        for shingle in shingles:
            shingle_index[shingle].append(index)

    # Syntax shingles such as generic ``try/except`` or widget setup can occur
    # in hundreds of functions. Expanding those buckets to every pair is
    # quadratic and turns this review diagnostic into an unbounded CPU job.
    # Build candidates only from shingles unique to one function pair; genuine
    # near-duplicates still share several such specific fragments and are
    # confirmed below by SequenceMatcher.
    shared_counts: dict[tuple[int, int], int] = defaultdict(int)
    for members in shingle_index.values():
        if len(members) != 2:
            continue
        left, right = members
        shared_counts[(left, right)] += 1

    candidates: list[tuple[AstDefinition, AstDefinition]] = []
    for (left_index, right_index), shared in shared_counts.items():
        if shared < 5:
            continue
        left_record, left_tokens = records[left_index]
        right_record, right_tokens = records[right_index]
        if left_record.fingerprint == right_record.fingerprint:
            continue
        short, long = sorted((len(left_tokens), len(right_tokens)))
        if short / long < 0.8:
            continue
        similarity = SequenceMatcher(a=left_tokens, b=right_tokens).ratio()
        if similarity >= similarity_threshold:
            candidates.append((left_record, right_record))
    return tuple(
        sorted(
            candidates,
            key=lambda pair: (
                pair[0].path.as_posix(),
                pair[0].lineno,
                pair[1].path.as_posix(),
                pair[1].lineno,
            ),
        )
    )


def _definition_count(name: str) -> int:
    count = 0
    for path in _source_python_files():
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        count += sum(
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
            and node.name == name
            for node in ast.walk(tree)
        )
    return count


def _module_assignment_count(name: str) -> int:
    count = 0
    for path in _source_python_files():
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for node in tree.body:
            targets = []
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            count += sum(isinstance(target, ast.Name) and target.id == name for target in targets)
    return count


def _pyqt_residue_count() -> int:
    residues = 0
    forbidden = tuple(
        "".join(parts)
        for parts in (
            ("Py", "Qt", "5"),
            ("Py", "Qt", "6"),
            ("Py", "Side", "2"),
            ("pyqt", "Signal"),
            ("pyqt", "Slot"),
            ("pyqt", "Property"),
        )
    )
    for path in _source_python_files():
        text = path.read_text(encoding="utf-8-sig")
        residues += sum(text.count(token) for token in forbidden)
    return residues


def _exact_duplicate_count() -> int:
    by_digest: dict[str, list[Path]] = {}
    for path in _source_python_files():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        by_digest.setdefault(digest, []).append(path)
    return sum(len(paths) - 1 for paths in by_digest.values() if len(paths) > 1)


def _configuration_duplicate_count() -> int:
    """Reject secondary formatter configuration and repeated central sections."""
    duplicates = int((ROOT / ".black").exists())
    pyproject = (ROOT / "pyproject.toml").read_text(encoding="utf-8-sig")
    for section in ("[tool.black]", "[tool.ruff]", "[tool.pylint]"):
        duplicates += max(0, pyproject.count(section) - 1)
    return duplicates


def _relative_source_path(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def _stylesheet_application_owner_violations() -> tuple[int, int]:
    """Return stylesheet application calls and violations of their sole owner."""
    calls: list[str] = []
    for path in _source_python_files():
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "setStyleSheet"
            ):
                calls.append(_relative_source_path(path))
    allowed_calls = sum(path == "ui/theme_manager.py" for path in calls)
    violations = len(calls) - allowed_calls + abs(allowed_calls - 1)
    return len(calls), violations


def _shell_designer_owner_violations() -> int:
    """Ensure each desktop-shell form has exactly one Python composition owner."""
    loads: dict[str, list[str]] = defaultdict(list)
    for path in _source_python_files():
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        for node in ast.walk(tree):
            if not (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "load_ui"
                and len(node.args) >= 2
                and isinstance(node.args[1], ast.Constant)
                and isinstance(node.args[1].value, str)
            ):
                continue
            name = node.args[1].value
            if name in _SHELL_FORM_OWNERS:
                loads[name].append(_relative_source_path(path))
    return sum(sorted(loads.get(name, ())) != [owner] for name, owner in _SHELL_FORM_OWNERS.items())


def _shell_designer_layout_violations() -> int:
    """Validate the static shell geometry that Designer, rather than Python, owns."""
    errors: list[str] = []
    forms = {
        "main_window": {
            "root": "app_root",
            "layout": "main_layout",
            "hosts": (
                "main_area_host",
                "shell_sidebar_host",
                "SidebarDrawerToggle",
                "shell_top_bar_host",
                "content_stack_host",
            ),
        },
        "sidebar": {
            "root": "Sidebar",
            "layout": "sidebar_root",
            "hosts": ("SidebarNavigationHost", "SidebarFooter"),
        },
        "top_bar": {
            "root": "TopBar",
            "layout": "top_bar_layout",
            "hosts": ("CommandBar", "ShellStatusWidgetsHost", "NotifWrap"),
        },
    }
    for form, contract in forms.items():
        path = ROOT / "resources" / "ui" / f"{form}.ui"
        try:
            document = ET.parse(path).getroot()
        except (ET.ParseError, OSError):
            errors.append(f"{form}:unreadable")
            continue
        widgets = {
            widget.attrib.get("name", ""): widget for widget in document.findall(".//widget")
        }
        root = widgets.get(contract["root"])
        if root is None or root.find(f"./layout[@name='{contract['layout']}']") is None:
            errors.append(f"{form}:root-layout")
        for host in contract["hosts"]:
            if host not in widgets:
                errors.append(f"{form}:{host}")
        if form == "main_window":
            layout = root.find("./layout[@name='main_layout']") if root is not None else None
            if layout is None or layout.attrib.get("class") != "QHBoxLayout":
                errors.append("main_window:root-layout-class")

            def _layout_widget_names(parent, layout_name: str) -> tuple[str, ...]:
                owner = parent.find(f"./layout[@name='{layout_name}']") if parent is not None else None
                if owner is None:
                    return ()
                return tuple(
                    item.find("./widget").attrib.get("name", "")
                    for item in owner.findall("./item")
                    if item.find("./widget") is not None
                )

            if _layout_widget_names(root, "main_layout") != (
                "shell_sidebar_host",
                "main_area_host",
            ):
                errors.append("main_window:root-hierarchy")
            sidebar_host = widgets.get("shell_sidebar_host")
            if _layout_widget_names(sidebar_host, "shell_sidebar_layout") != (
                "SidebarDrawerToggle",
            ):
                errors.append("main_window:sidebar-drawer-trigger")
            main_area = widgets.get("main_area_host")
            main_area_layout = (
                main_area.find("./layout[@name='main_area_layout']")
                if main_area is not None
                else None
            )
            if (
                main_area_layout is None
                or main_area_layout.attrib.get("class") != "QVBoxLayout"
                or _layout_widget_names(main_area, "main_area_layout")
                != ("shell_top_bar_host", "content_stack_host")
            ):
                errors.append("main_window:main-area-hierarchy")
            for host in contract["hosts"]:
                widget = widgets.get(host)
                if widget is None or widget.find("./property[@name='sizePolicy']") is None:
                    errors.append(f"main_window:{host}:size-policy")
    return len(errors)


def _main_window_layout_owner_violations() -> int:
    """Keep Designer-owned shell layout setters out of the main-window controller."""
    path = ROOT / "ui" / "main_window.py"
    tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    return sum(
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr in _MAIN_WINDOW_LAYOUT_METHODS
        for node in ast.walk(tree)
    )


def _administration_catalog_owner_violations() -> int:
    """Keep the catalog workspace in its dedicated Administration section module."""
    composer_path = ROOT / "ui" / "administration.py"
    composer = composer_path.read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_catalogs.py").read_text(encoding="utf-8-sig")
    tree = ast.parse(composer, filename=str(composer_path))
    imported = any(
        isinstance(node, ast.ImportFrom)
        and node.module == "ui.administration_catalogs"
        and any(alias.name == "AdministrationCatalogsSection" for alias in node.names)
        for node in ast.walk(tree)
    )
    return (
        int(not imported)
        + int("class AdministrationCatalogsSection" in composer)
        + int("class AdministrationCatalogsSection" not in owner)
    )


def _administration_overview_owner_violations() -> int:
    """Keep the overview presentation in its dedicated Administration section module."""
    composer = (ROOT / "ui" / "administration.py").read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_overview.py").read_text(encoding="utf-8-sig")
    return (
        int("from ui.administration_overview import OverviewSection" not in composer)
        + int("class OverviewSection" in composer)
        + int("class OverviewSection" not in owner)
    )


def _administration_users_owner_violations() -> int:
    """Keep the account collection and its filter model in their section owner."""
    composer = (ROOT / "ui" / "administration.py").read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_users.py").read_text(encoding="utf-8-sig")
    return (
        int("from ui.administration_users import AccountCollectionSection" not in composer)
        + int("class AccountCollectionSection" in composer)
        + int("class UserFilterProxy" in composer)
        + int("class AccountCollectionSection" not in owner)
        + int("class UserFilterProxy" not in owner)
    )


def _administration_permissions_owner_violations() -> int:
    """Keep the permission catalogue presentation in its dedicated owner."""
    composer = (ROOT / "ui" / "administration.py").read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_permissions.py").read_text(encoding="utf-8-sig")
    return (
        int("from ui.administration_permissions import PermissionsSection" not in composer)
        + int("class PermissionsSection" in composer)
        + int("class PermissionsSection" not in owner)
    )


def _administration_structure_owner_violations() -> int:
    """Keep organization-structure behavior in its dedicated section owner."""
    composer = (ROOT / "ui" / "administration.py").read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_structure.py").read_text(encoding="utf-8-sig")
    return (
        int("from ui.administration_structure import StructureSection" not in composer)
        + int("class StructureSection" in composer)
        + int("class StructureSection" not in owner)
    )


def _administration_assignments_owner_violations() -> int:
    """Keep direct-scope assignment behavior in its dedicated section owner."""
    composer = (ROOT / "ui" / "administration.py").read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_assignments.py").read_text(encoding="utf-8-sig")
    return (
        int("from ui.administration_assignments import AssignmentsSection" not in composer)
        + int("class AssignmentsSection" in composer)
        + int("class AssignmentsSection" not in owner)
    )


def _administration_audit_owner_violations() -> int:
    """Keep audit filtering and presentation in their dedicated section owner."""
    composer = (ROOT / "ui" / "administration.py").read_text(encoding="utf-8-sig")
    owner = (ROOT / "ui" / "administration_audit.py").read_text(encoding="utf-8-sig")
    return (
        int("from ui.administration_audit import AuditSection" not in composer)
        + int("class AuditSection" in composer)
        + int("class AuditFilter" in composer)
        + int("class AuditSection" not in owner)
        + int("class AuditFilter" not in owner)
    )


def _notification_presentation_owner_violations() -> int:
    """Keep pure notification text formatting in its dedicated owner."""
    owner = (ROOT / "ui" / "notification_presentation.py").read_text(encoding="utf-8-sig")
    return int("class NotificationMessageFormatter" not in owner)


def _notification_queue_owner_violations() -> int:
    """Keep asynchronous desktop delivery in its dedicated owner."""
    owner = (ROOT / "ui" / "notification_queue.py").read_text(encoding="utf-8-sig")
    return int("class DesktopNotificationQueue" not in owner)


def _notification_sound_owner_violations() -> int:
    """Keep media playback in its dedicated owner."""
    owner = (ROOT / "ui" / "notification_sound.py").read_text(encoding="utf-8-sig")
    return int("class SoundNotifier" not in owner)


def _notification_views_owner_violations() -> int:
    """Keep in-app notification widgets in their presentation owner."""
    owner = (ROOT / "ui" / "notification_views.py").read_text(encoding="utf-8-sig")
    classes = (
        "NotificationViewItem",
        "NotificationsPresenter",
        "NotificationsPanelUiMixin",
        "NotificationsPanel",
        "NotificationsPopupMenu",
    )
    return sum(int(f"class {name}" not in owner) for name in classes)


def _notification_desktop_owner_violations() -> int:
    """Keep platform-tray delivery in its adapter module."""
    owner = (ROOT / "ui" / "notification_desktop.py").read_text(encoding="utf-8-sig")
    return int("class DesktopNotifier" not in owner)


def _notification_service_owner_violations() -> int:
    """Keep lifecycle orchestration and badge state in the service owner."""
    owner = (ROOT / "ui" / "notification_service.py").read_text(encoding="utf-8-sig")
    classes = ("NotificationBadgeUpdater", "NotificationService")
    return sum(int(f"class {name}" not in owner) for name in classes) + int(
        "NOTIFICATION_DURATION_SECONDS" not in owner
    )


def _tracking_owner_violations() -> int:
    """Keep Tracking responsibilities out of its public page facade."""
    facade = (ROOT / "ui" / "tracking.py").read_text(encoding="utf-8-sig")
    owners = (
        (
            "tracking_data.py",
            ("class TrackingDataControllerMixin",),
        ),
        (
            "tracking_dialogs.py",
            (
                "class ConfirmTrackedProductDeleteDialog",
                "def confirm_tracked_product_delete",
            ),
        ),
        ("tracking_form.py", ("class TrackingFormBuilderMixin",)),
        (
            "tracking_form_controller.py",
            ("class TrackingFormControllerMixin",),
        ),
        (
            "tracking_responsive.py",
            (
                "class ToolbarItemPlacement",
                "class ToolbarLayoutSpec",
                "def normalize_toolbar_mode",
                "def toolbar_layout_spec",
                "class TrackingResponsiveLayoutMixin",
            ),
        ),
        (
            "tracking_table.py",
            ("class TrackingTableBuilderMixin",),
        ),
        (
            "tracking_composition.py",
            ("class TrackingControllerMixin", "class TrackingUiBuilderMixin"),
        ),
    )
    violations = 0
    for filename, symbols in owners:
        owner = (ROOT / "ui" / filename).read_text(encoding="utf-8-sig")
        for symbol in symbols:
            violations += int(symbol in facade) + int(symbol not in owner)
    return violations


def _main_window_owner_violations() -> int:
    """Keep main-window behavioral mixins outside the composition root."""
    facade = (ROOT / "ui" / "main_window.py").read_text(encoding="utf-8-sig")
    owners = (
        (
            "main_window_access.py",
            "from ui.main_window_access import",
            ("class MainWindowAccessNavigationMixin",),
        ),
        (
            "main_window_notifications.py",
            "from ui.main_window_notifications import",
            ("class MainWindowNotificationsMixin", "class MainWindowTrayMixin"),
        ),
        (
            "main_window_session.py",
            "from ui.main_window_session import (",
            (
                "class SessionAuthControllerMixin",
                "class SessionRestoreControllerMixin",
                "class MainWindowUpdatesMixin",
            ),
        ),
        (
            "main_window_shell.py",
            "from ui.main_window_shell import",
            ("class MainWindowContentPagesMixin", "class MainWindowShellLayoutMixin"),
        ),
    )
    violations = 0
    for filename, import_fragment, symbols in owners:
        owner = (ROOT / "ui" / filename).read_text(encoding="utf-8-sig")
        violations += int(import_fragment not in facade)
        for symbol in symbols:
            violations += int(symbol in facade) + int(symbol not in owner)
    monitoring = (ROOT / "services" / "monitoring_coordinator.py").read_text(encoding="utf-8-sig")
    violations += int(
        "from services.monitoring_coordinator import MonitoringCoordinator" not in facade
    )
    violations += int("class MonitoringCoordinator" not in monitoring)
    violations += int("monitoring_wake_timer" in facade)
    return violations


def _theme_owner_violations() -> int:
    """Keep each theme responsibility out of the compatibility facade."""
    facade = (ROOT / "ui" / "theme.py").read_text(encoding="utf-8-sig")
    owners = (
        ("theme_metrics.py", "from ui.theme_metrics import", ("class ComponentSizes",)),
        (
            "theme_responsive.py",
            "from ui.theme_responsive import",
            (
                "class ResponsiveResizeMixin",
                "class ResponsiveProfile",
                "class ScreenDeviceProfile",
                "class LayoutModeController",
                "def layout_mode_for_width",
                "def apply_profile_properties",
                "def apply_density_contract",
            ),
        ),
        (
            "theme_geometry.py",
            "from ui.theme_geometry import (",
            ("def apply_window_constraints", "def apply_initial_window_geometry"),
        ),
        (
            "theme_shell.py",
            "from ui.theme_shell import (",
            ("class SidebarFrame", "def build_sidebar", "def build_top_bar"),
        ),
        ("theme_stack.py", "from ui.theme_stack import PageStack", ("class PageStack",)),
        (
            "theme_animation.py",
            "from ui.theme_animation import",
            ("def fade_in", "def slide_fade_in", "def operation_pulse"),
        ),
        ("theme_manager.py", "from ui.theme_manager import ThemeManager", ("class ThemeManager",)),
    )
    violations = 0
    for filename, import_fragment, symbols in owners:
        owner = (ROOT / "ui" / filename).read_text(encoding="utf-8-sig")
        violations += int(import_fragment not in facade)
        for symbol in symbols:
            violations += int(symbol in facade) + int(symbol not in owner)
    return violations


def _responsibility_counts() -> dict[str, int]:
    return {
        "EXPIRY_CLASSIFIER_COUNT": _definition_count("classify_expiry_days"),
        "RESOURCE_LOCATOR_COUNT": _definition_count("bundled_or_source_path"),
        "TRACKING_STORE_COUNT": _module_assignment_count("tracking_store"),
        "LOCAL_MIGRATION_OWNER_COUNT": _definition_count("apply_migrations"),
        "TRAY_OWNER_COUNT": _definition_count("SystemTrayAdapter"),
        "SINGLE_INSTANCE_OWNER_COUNT": _definition_count("SingleInstanceGuard"),
    }


def source_quality() -> int:
    """Report canonical client-source ownership without mutating the tree."""
    source_files = _source_python_files()
    ast_groups = ast_duplicate_groups(source_files)
    near_candidates = near_duplicate_candidates(source_files)
    responsibility_counts = _responsibility_counts()
    stylesheet_application_count, stylesheet_owner_violations = (
        _stylesheet_application_owner_violations()
    )
    report = {
        "EXACT_DUPLICATES": _exact_duplicate_count(),
        "PYQT_RESIDUE": _pyqt_residue_count(),
        "AST_DUPLICATE_GROUPS": len(ast_groups),
        "NEAR_DUPLICATE_CANDIDATES": len(near_candidates),
        "CONFIGURATION_DUPLICATES": _configuration_duplicate_count(),
        "RESPONSIBILITY_COLLISIONS": sum(count != 1 for count in responsibility_counts.values()),
        "STYLESHEET_APPLICATION_OWNER_COUNT": stylesheet_application_count,
        "STYLESHEET_OWNER_VIOLATIONS": stylesheet_owner_violations,
        "SHELL_DESIGNER_OWNER_VIOLATIONS": _shell_designer_owner_violations(),
        "SHELL_DESIGNER_LAYOUT_VIOLATIONS": _shell_designer_layout_violations(),
        "MAIN_WINDOW_LAYOUT_OWNER_VIOLATIONS": _main_window_layout_owner_violations(),
        "ADMINISTRATION_CATALOG_OWNER_VIOLATIONS": _administration_catalog_owner_violations(),
        "ADMINISTRATION_OVERVIEW_OWNER_VIOLATIONS": _administration_overview_owner_violations(),
        "ADMINISTRATION_USERS_OWNER_VIOLATIONS": _administration_users_owner_violations(),
        "ADMINISTRATION_PERMISSIONS_OWNER_VIOLATIONS": _administration_permissions_owner_violations(),
        "ADMINISTRATION_STRUCTURE_OWNER_VIOLATIONS": _administration_structure_owner_violations(),
        "ADMINISTRATION_ASSIGNMENTS_OWNER_VIOLATIONS": _administration_assignments_owner_violations(),
        "ADMINISTRATION_AUDIT_OWNER_VIOLATIONS": _administration_audit_owner_violations(),
        "NOTIFICATION_PRESENTATION_OWNER_VIOLATIONS": _notification_presentation_owner_violations(),
        "NOTIFICATION_QUEUE_OWNER_VIOLATIONS": _notification_queue_owner_violations(),
        "NOTIFICATION_SOUND_OWNER_VIOLATIONS": _notification_sound_owner_violations(),
        "NOTIFICATION_VIEWS_OWNER_VIOLATIONS": _notification_views_owner_violations(),
        "NOTIFICATION_DESKTOP_OWNER_VIOLATIONS": _notification_desktop_owner_violations(),
        "NOTIFICATION_SERVICE_OWNER_VIOLATIONS": _notification_service_owner_violations(),
        "TRACKING_OWNER_VIOLATIONS": _tracking_owner_violations(),
        "MAIN_WINDOW_OWNER_VIOLATIONS": _main_window_owner_violations(),
        "THEME_OWNER_VIOLATIONS": _theme_owner_violations(),
        "UI_OWNERSHIP_DOCUMENT_COUNT": int((ROOT / "ARCHITECTURE.md").is_file()),
        **responsibility_counts,
    }
    expected = {
        "EXACT_DUPLICATES": 0,
        "PYQT_RESIDUE": 0,
        "AST_DUPLICATE_GROUPS": 0,
        "CONFIGURATION_DUPLICATES": 0,
        "RESPONSIBILITY_COLLISIONS": 0,
        "STYLESHEET_APPLICATION_OWNER_COUNT": 1,
        "STYLESHEET_OWNER_VIOLATIONS": 0,
        "SHELL_DESIGNER_OWNER_VIOLATIONS": 0,
        "SHELL_DESIGNER_LAYOUT_VIOLATIONS": 0,
        "MAIN_WINDOW_LAYOUT_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_CATALOG_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_OVERVIEW_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_USERS_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_PERMISSIONS_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_STRUCTURE_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_ASSIGNMENTS_OWNER_VIOLATIONS": 0,
        "ADMINISTRATION_AUDIT_OWNER_VIOLATIONS": 0,
        "NOTIFICATION_PRESENTATION_OWNER_VIOLATIONS": 0,
        "NOTIFICATION_QUEUE_OWNER_VIOLATIONS": 0,
        "NOTIFICATION_SOUND_OWNER_VIOLATIONS": 0,
        "NOTIFICATION_VIEWS_OWNER_VIOLATIONS": 0,
        "NOTIFICATION_DESKTOP_OWNER_VIOLATIONS": 0,
        "NOTIFICATION_SERVICE_OWNER_VIOLATIONS": 0,
        "TRACKING_OWNER_VIOLATIONS": 0,
        "MAIN_WINDOW_OWNER_VIOLATIONS": 0,
        "THEME_OWNER_VIOLATIONS": 0,
        "UI_OWNERSHIP_DOCUMENT_COUNT": 1,
    }
    for name, value in report.items():
        print(f"{name}={value}")
    failures = [
        f"{name}={report[name]}" for name, wanted in expected.items() if report[name] != wanted
    ]
    if failures:
        print("SOURCE_QUALITY=FAIL " + " ".join(failures))
        return 1
    print("SOURCE_QUALITY=PASS")
    return 0


_EMBEDDED_GATES = {
    "audited_release_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGFzdAppbXBvcnQgYmFzZTY0CmltcG9ydCBpbXBvcnRsaWIudXRpbAppbXBvcnQganNvbgpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKaW1wb3J0IHJlCmltcG9ydCB4bWwuZXRyZWUuRWxlbWVudFRyZWUgYXMgRVQKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQoKCmRlZiBmYWlsKG1lc3NhZ2U6IHN0cikgLT4gTm9uZToKICAgIHJhaXNlIFN5c3RlbUV4aXQoIkFVRElURURfUkVMRUFTRV9HQVRFPUZBSUwgIiArIG1lc3NhZ2UpCgoKZGVmIHNvdXJjZShyZWxhdGl2ZTogc3RyKSAtPiBzdHI6CiAgICByZXR1cm4gKFJPT1QgLyByZWxhdGl2ZSkucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOC1zaWciKQoKCiMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tCiMgVHJhbnNsYXRpb24gaW50ZWdyaXR5OiBldmVyeSBsaXRlcmFsIF8oIi4uLiIpL3RyKCIuLi4iKSB1c2VkIGJ5IFB5dGhvbiBpcwojIHByZXNlbnQgaW4gYm90aCBzaGlwcGVkIGNhdGFsb2dzLCBhbmQgZm9ybWF0IHBsYWNlaG9sZGVycyBhZ3JlZS4KIyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0KbGl0ZXJhbF9rZXlzOiBzZXRbc3RyXSA9IHNldCgpCmZvciBwYXRoIGluIFJPT1Qucmdsb2IoIioucHkiKToKICAgIGlmIGFueShwYXJ0IGluIHsiLnZlbnYtYnVpbGQiLCAiX19weWNhY2hlX18ifSBmb3IgcGFydCBpbiBwYXRoLnBhcnRzKToKICAgICAgICBjb250aW51ZQogICAgdHJlZSA9IGFzdC5wYXJzZShwYXRoLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgtc2lnIiksIGZpbGVuYW1lPXN0cihwYXRoKSkKICAgIGZvciBub2RlIGluIGFzdC53YWxrKHRyZWUpOgogICAgICAgIGlmIG5vdCBpc2luc3RhbmNlKG5vZGUsIGFzdC5DYWxsKSBvciBub3QgaXNpbnN0YW5jZShub2RlLmZ1bmMsIGFzdC5OYW1lKToKICAgICAgICAgICAgY29udGludWUKICAgICAgICBpZiBub2RlLmZ1bmMuaWQgbm90IGluIHsiXyIsICJ0ciJ9IG9yIG5vdCBub2RlLmFyZ3M6CiAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgYXJnID0gbm9kZS5hcmdzWzBdCiAgICAgICAgaWYgaXNpbnN0YW5jZShhcmcsIGFzdC5Db25zdGFudCkgYW5kIGlzaW5zdGFuY2UoYXJnLnZhbHVlLCBzdHIpOgogICAgICAgICAgICBsaXRlcmFsX2tleXMuYWRkKGFyZy52YWx1ZSkKCmNhdGFsb2dzID0gewogICAgY29kZToganNvbi5sb2FkcygKICAgICAgICAoUk9PVCAvICJyZXNvdXJjZXMiIC8gImkxOG4iIC8gZiJ7Y29kZX0uanNvbiIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQogICAgKQogICAgZm9yIGNvZGUgaW4gKCJlbiIsICJhciIpCn0KaWYgc2V0KGNhdGFsb2dzWyJlbiJdKSAhPSBzZXQoY2F0YWxvZ3NbImFyIl0pOgogICAgZmFpbCgidHJhbnNsYXRpb25fY2F0YWxvZ19rZXlfc2V0c19kaWZmZXIiKQoKZm9yIGNvZGUsIGNhdGFsb2cgaW4gY2F0YWxvZ3MuaXRlbXMoKToKICAgIG1pc3NpbmcgPSBzb3J0ZWQobGl0ZXJhbF9rZXlzIC0gc2V0KGNhdGFsb2cpKQogICAgaWYgbWlzc2luZzoKICAgICAgICBmYWlsKGYibWlzc2luZ197Y29kZX1fdHJhbnNsYXRpb25zPXttaXNzaW5nfSIpCgoKZGVmIHBsYWNlaG9sZGVycyh2YWx1ZTogb2JqZWN0KSAtPiBzZXRbc3RyXToKICAgIHJldHVybiB7CiAgICAgICAgdG9rZW4uc3BsaXQoIiEiLCAxKVswXS5zcGxpdCgiOiIsIDEpWzBdCiAgICAgICAgZm9yIHRva2VuIGluIHJlLmZpbmRhbGwociJceyhbXnt9XSspXH0iLCBzdHIodmFsdWUgb3IgIiIpKQogICAgfQoKCmZvciBrZXkgaW4gY2F0YWxvZ3NbImVuIl06CiAgICBpZiBwbGFjZWhvbGRlcnMoY2F0YWxvZ3NbImVuIl1ba2V5XSkgIT0gcGxhY2Vob2xkZXJzKGNhdGFsb2dzWyJhciJdW2tleV0pOgogICAgICAgIGZhaWwoZiJ0cmFuc2xhdGlvbl9wbGFjZWhvbGRlcl9taXNtYXRjaD17a2V5fSIpCgoKIyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0KIyBVc2FnZSBkYXRhIGF1dGhvcml0eSBhbmQgd29ya3NoZWV0IGJlaGF2aW9yLgojIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLQp1c2FnZV9zZXJ2aWNlID0gc291cmNlKCJzZXJ2aWNlcy91c2FnZS5weSIpCmlmICdwcm9kdWN0X3Jvdy5nZXQoInVvbSIpJyBpbiB1c2FnZV9zZXJ2aWNlOgogICAgZmFpbCgic2VydmVyX3VvbV9mYWxsYmFja19wcmVzZW50IikKaWYgJ3VvbSA9IHN0cihyZWNlaXB0X3Jvdy5nZXQoInVvbSIpIGlmIHJlY2VpcHRfcm93IGVsc2UgIiIpLnN0cmlwKCknIG5vdCBpbiB1c2FnZV9zZXJ2aWNlOgogICAgZmFpbCgiZXhjZWxfdW9tX2F1dGhvcml0eV9taXNzaW5nIikKaWYgInVwZGF0ZV91c2FnZV91b21fYnVsayIgaW4gdXNhZ2Vfc2VydmljZToKICAgIGZhaWwoIndvcmtib29rX3VvbV93cml0dGVuX2ludG9fY2F0YWxvZ19wcm9qZWN0aW9uIikKaWYgInJlY2VpcHRzX3ZhbHVlICsgYmVnaW5uaW5nX3ZhbHVlIiBub3QgaW4gdXNhZ2Vfc2VydmljZToKICAgIGZhaWwoInVzYWdlX3RvdGFsX2Zvcm11bGFfbWlzc2luZyIpCgp1c2FnZV9yZXBvID0gc291cmNlKCJpbmZyYS9kYXRhYmFzZS5weSIpCmlmICJkZWYgdXBkYXRlX3VzYWdlX3VvbV9idWxrIiBpbiB1c2FnZV9yZXBvOgogICAgZmFpbCgiZGVhZF93b3JrYm9va190b19jYXRhbG9nX3VvbV9tdXRhdG9yX3ByZXNlbnQiKQoKY2F0YWxvZ19zZXJ2aWNlID0gc291cmNlKCJzZXJ2aWNlcy91c2FnZS5weSIpCmlmICJjbGllbnQtYm9vdHN0cmFwLWVtcHR5LWNhdGFsb2ctZmFsbGJhY2siIGluIGNhdGFsb2dfc2VydmljZToKICAgIGZhaWwoInVzYWdlX2NhdGFsb2dfYm9vdHN0cmFwX2ZhbGxiYWNrX3ByZXNlbnQiKQppZiAicmVtb3RlLmxpc3RfdXNhZ2VfcHJvZHVjdHMiIG5vdCBpbiBjYXRhbG9nX3NlcnZpY2U6CiAgICBmYWlsKCJkZWRpY2F0ZWRfdXNhZ2VfY2F0YWxvZ19lbmRwb2ludF9ub3RfdXNlZCIpCgpjYXRhbG9nX2NsaWVudCA9IHNvdXJjZSgiaW5mcmEvYXBpLnB5IikKaWYgJ3Jvd19rZXlzPXsibWF0ZXJpYWxfbnVtYmVyIiwgIm5hbWUiLCAidW9tIn0nIG5vdCBpbiBjYXRhbG9nX2NsaWVudDoKICAgIGZhaWwoInVzYWdlX2NhdGFsb2dfcm93X2NvbnRyYWN0X21pc3NpbmciKQppZiAnaXRlbS5nZXQoInVvbSIpIGlzIG5vdCBOb25lJyBub3QgaW4gY2F0YWxvZ19jbGllbnQ6CiAgICBmYWlsKCJudWxsYWJsZV9zZXJ2ZXJfdW9tX2NvbnRyYWN0X21pc3NpbmciKQoKbmF2aWdhdGlvbiA9IHNvdXJjZSgidWkvbWFpbl93aW5kb3dfYWN0aW9ucy5weSIpCnNlc3Npb25fYWN0aW9ucyA9IHNvdXJjZSgidWkvbWFpbl93aW5kb3cucHkiKQp1c2FnZV9jb250cm9sbGVyID0gc291cmNlKCJ1aS91c2FnZV9jb250cm9sbGVyLnB5IikKdXNhZ2VfcGFnZSA9IHNvdXJjZSgidWkvdXNhZ2UucHkiKQpkZWxlZ2F0ZXMgPSBzb3VyY2UoInVpL3RhYmxlcy5weSIpCgpmb3IgbmVlZGxlLCBsYWJlbCBpbiAoCiAgICAoImNsZWFyX3dvcmtzcGFjZSgpIiwgInVzYWdlX2NsZWFyX29uX25hdmlnYXRpb25fbWlzc2luZyIpLAogICAgKCJjdXJyZW50IGlzIHVzYWdlX3BhZ2UgYW5kIHBhZ2UgaXMgbm90IHVzYWdlX3BhZ2UiLCAidXNhZ2VfbGVhdmVfZ3VhcmRfbWlzc2luZyIpLAopOgogICAgaWYgbmVlZGxlIG5vdCBpbiBuYXZpZ2F0aW9uOgogICAgICAgIGZhaWwobGFiZWwpCmlmICJjbGVhcl93b3Jrc3BhY2UoKSIgbm90IGluIHNlc3Npb25fYWN0aW9uczoKICAgIGZhaWwoInVzYWdlX2NsZWFyX29uX2xvZ291dF9taXNzaW5nIikKZm9yIG5lZWRsZSwgbGFiZWwgaW4gKAogICAgKCdzZWxmLl9yZWNlaXB0c19wYXRoID0gIiInLCAidXNhZ2VfcmVjZWlwdHNfcmVzZXRfbWlzc2luZyIpLAogICAgKCdzZWxmLl9iZWdpbm5pbmdfcGF0aCA9ICIiJywgInVzYWdlX29wZW5pbmdfcmVzZXRfbWlzc2luZyIpLAogICAgKCJzZWxmLm1vZGVsLnJlcGxhY2Vfcm93cyhbXSkiLCAidXNhZ2Vfcm93c19yZXNldF9taXNzaW5nIiksCiAgICAoInNlbGYuc2VhcmNoLmNsZWFyKCkiLCAidXNhZ2Vfc2VhcmNoX3Jlc2V0X21pc3NpbmciKSwKKToKICAgIGlmIG5lZWRsZSBub3QgaW4gdXNhZ2VfY29udHJvbGxlcjoKICAgICAgICBmYWlsKGxhYmVsKQppZiAic2VsZi5idG5fcmVjYWxjdWxhdGUuY2xpY2tlZC5jb25uZWN0KHNlbGYuY29tcHV0ZSkiIG5vdCBpbiB1c2FnZV9wYWdlOgogICAgZmFpbCgidXNhZ2VfcmVjYWxjdWxhdGVfbm90X2JvdW5kX3RvX2Nhbm9uaWNhbF9jb21wdXRlIikKaWYgJ2VkaXRvci5zZXRPYmplY3ROYW1lKCJNYW51YWxBdmFpbGFibGVTdG9ja0lucHV0IiknIG5vdCBpbiBkZWxlZ2F0ZXM6CiAgICBmYWlsKCJlbnRlcl9zdG9ja19lZGl0b3JfbWlzc2luZyIpCgoKIyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0KIyBMb2dpbiByZWZlcmVuY2UgY29udHJvbHMgYW5kIHRpdGxlLWJhciBjbG9zZSBiZWhhdmlvci4KIyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0KdWlfcm9vdCA9IEVULnBhcnNlKFJPT1QgLyAicmVzb3VyY2VzIiAvICJ1aSIgLyAibG9naW5fcGFnZS51aSIpLmdldHJvb3QoKQp3aWRnZXRfbmFtZXMgPSB7d2lkZ2V0LmF0dHJpYi5nZXQoIm5hbWUiKSBmb3Igd2lkZ2V0IGluIHVpX3Jvb3QuaXRlcigid2lkZ2V0Iil9CmZvciByZXF1aXJlZCBpbiB7CiAgICAibG9naW5fdXNlcm5hbWUiLAogICAgImxvZ2luX3Bhc3N3b3JkIiwKICAgICJsb2dpbl9zdWJtaXQiLAogICAgIkxvZ2luUmVtZW1iZXJDaGVjayIsCiAgICAibG9naW5fcGFzc3dvcmRfdG9nZ2xlIiwKICAgICJsb2dpbl9mb3Jnb3QiLAogICAgImxvZ2luX2hlbHAiLAogICAgImxvZ2luX2xhbmd1YWdlIiwKfToKICAgIGlmIHJlcXVpcmVkIG5vdCBpbiB3aWRnZXRfbmFtZXM6CiAgICAgICAgZmFpbChmImxvZ2luX2NvbnRyb2xfbWlzc2luZz17cmVxdWlyZWR9IikKCmxvZ2luX3BhZ2UgPSBzb3VyY2UoInVpL2xvZ2luLnB5IikKZm9yIG5lZWRsZSwgbGFiZWwgaW4gKAogICAgKCJfc2hvd19hY2NvdW50X3JlY292ZXJ5X2hlbHAiLCAibG9naW5fcmVjb3ZlcnlfYWN0aW9uX21pc3NpbmciKSwKICAgICgiX3Nob3dfbG9naW5faGVscCIsICJsb2dpbl9oZWxwX2FjdGlvbl9taXNzaW5nIiksCiAgICAoIl9jb25maWd1cmVfbGFuZ3VhZ2VfbWVudSIsICJsb2dpbl9sYW5ndWFnZV9hY3Rpb25fbWlzc2luZyIpLAogICAgKCJfdG9nZ2xlX3Bhc3N3b3JkX3Zpc2liaWxpdHkiLCAibG9naW5fcGFzc3dvcmRfdmlzaWJpbGl0eV9hY3Rpb25fbWlzc2luZyIpLAopOgogICAgaWYgbmVlZGxlIG5vdCBpbiBsb2dpbl9wYWdlOgogICAgICAgIGZhaWwobGFiZWwpCgpsaWZlY3ljbGUgPSBzb3VyY2UoInVpL21haW5fd2luZG93X2FjdGlvbnMucHkiKQppZiAic2VsZi5jbG9zZV9hcHBfY29tcGxldGVseSgpIiBub3QgaW4gbGlmZWN5Y2xlOgogICAgZmFpbCgibWFpbl93aW5kb3dfeF9jbG9zZV9ub3RfYm91bmQiKQpkaWFsb2dzID0gc291cmNlKCJ1aS9kaWFsb2dzLnB5IikKaWYgIlF0LldpbmRvd1N5c3RlbU1lbnVIaW50IHwgUXQuV2luZG93Q2xvc2VCdXR0b25IaW50IiBub3QgaW4gZGlhbG9nczoKICAgIGZhaWwoImRpYWxvZ194X2Nsb3NlX2ZsYWdfbWlzc2luZyIpCgoKIyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0KIyBSZWxlYXNlL3NpZ25pbmcvcHVibGljYXRpb24gc2FmZXR5LgojIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLQpkZWYgZW1iZWRkZWRfZ2F0ZV9zb3VyY2UoZmlsZW5hbWU6IHN0cikgLT4gc3RyOgogICAgc3BlYyA9IGltcG9ydGxpYi51dGlsLnNwZWNfZnJvbV9maWxlX2xvY2F0aW9uKCJfaGVyZnlfb3BzX2F1ZGl0IiwgUk9PVCAvICJvcHMiIC8gImF1ZGl0LnB5IikKICAgIGlmIHNwZWMgaXMgTm9uZSBvciBzcGVjLmxvYWRlciBpcyBOb25lOgogICAgICAgIGZhaWwoImF1ZGl0X2xvYWRlcl91bmF2YWlsYWJsZSIpCiAgICBtb2R1bGUgPSBpbXBvcnRsaWIudXRpbC5tb2R1bGVfZnJvbV9zcGVjKHNwZWMpCiAgICBzcGVjLmxvYWRlci5leGVjX21vZHVsZShtb2R1bGUpCiAgICBwYXlsb2FkID0gZ2V0YXR0cihtb2R1bGUsICJfRU1CRURERURfR0FURVMiLCB7fSkuZ2V0KGZpbGVuYW1lKQogICAgaWYgbm90IHBheWxvYWQ6CiAgICAgICAgZmFpbChmImVtYmVkZGVkX2dhdGVfbWlzc2luZz17ZmlsZW5hbWV9IikKICAgIHJldHVybiBiYXNlNjQuYjY0ZGVjb2RlKHBheWxvYWQpLmRlY29kZSgidXRmLTgiKQoKYnVpbGRlciA9IGVtYmVkZGVkX2dhdGVfc291cmNlKCJidWlsZF91cGRhdGVfcHVibGljYXRpb24ucHkiKQppZiAiZ2V0cGFzcy5nZXRwYXNzIiBub3QgaW4gYnVpbGRlcjoKICAgIGZhaWwoImhpZGRlbl91cGRhdGVfa2V5X3Bhc3NwaHJhc2VfcHJvbXB0X21pc3NpbmciKQoKcmVsZWFzZSA9IHNvdXJjZSgib3BzL3JlbGVhc2UucHMxIikKcHVibGlzaCA9IHNvdXJjZSgib3BzL3B1Ymxpc2gucHMxIikKZm9yIG5lZWRsZSwgbGFiZWwgaW4gKAogICAgKCJBc3NlcnQtQ29kZVNpZ25pbmdDZXJ0aWZpY2F0ZSIsICJjb2RlX3NpZ25pbmdfY2VydGlmaWNhdGVfZ2F0ZV9taXNzaW5nIiksCiAgICAoIlB5SW5zdGFsbGVyIiwgInB5aW5zdGFsbGVyX3JlbGVhc2Vfc3RhZ2VfbWlzc2luZyIpLAogICAgKCJJU0NDLmV4ZSIsICJpbm5vX3NldHVwX3N0YWdlX21pc3NpbmciKSwKICAgICgiR2V0LUF1dGhlbnRpY29kZVNpZ25hdHVyZSIsICJpbnN0YWxsZXJfc2lnbmF0dXJlX3ZlcmlmaWNhdGlvbl9taXNzaW5nIiksCik6CiAgICBpZiBuZWVkbGUgbm90IGluIHJlbGVhc2U6CiAgICAgICAgZmFpbChsYWJlbCkKZm9yIG5lZWRsZSwgbGFiZWwgaW4gKAogICAgKCdKb2luLVBhdGggJFBTU2NyaXB0Um9vdCAicmVsZWFzZS5wczEiJywgImNhbm9uaWNhbF9yZWxlYXNlX3BpcGVsaW5lX21pc3NpbmciKSwKICAgICgiV0VCU0lURSBET1dOTE9BRCBTV0lUQ0giLCAid2Vic2l0ZV9kb3dubG9hZF9zdGFnZV9taXNzaW5nIiksCiAgICAoInN3aXRjaF93ZWJzaXRlX2Rvd25sb2FkIiwgIndlYnNpdGVfc3dpdGNoX3Rvb2xfbWlzc2luZyIpLAogICAgKCJQdWJsaWMgbWFuaWZlc3QgdmVyc2lvbiBtaXNtYXRjaCIsICJwdWJsaWNfbWFuaWZlc3RfdmVyaWZpY2F0aW9uX21pc3NpbmciKSwKKToKICAgIGlmIG5lZWRsZSBub3QgaW4gcHVibGlzaDoKICAgICAgICBmYWlsKGxhYmVsKQoKc2l0ZV9zd2l0Y2ggPSBlbWJlZGRlZF9nYXRlX3NvdXJjZSgic3dpdGNoX3dlYnNpdGVfZG93bmxvYWQucHkiKQpmb3IgbmVlZGxlLCBsYWJlbCBpbiAoCiAgICAoIi92YXIvYmFja3Vwcy9oZXJmeS1zaXRlLWRvd25sb2FkIiwgIndlYnNpdGVfYmFja3VwX21pc3NpbmciKSwKICAgICgiYXRvbWljX3JlcGxhY2UiLCAid2Vic2l0ZV9hdG9taWNfcmVwbGFjZV9taXNzaW5nIiksCiAgICAoInN0YWxlX2Rvd25sb2FkX2xpbmtfcmVtYWlucyIsICJ3ZWJzaXRlX3N0YWxlX2xpbmtfcG9zdGNoZWNrX21pc3NpbmciKSwKICAgICgnWyJuZ2lueCIsICItdCJdJywgIndlYnNpdGVfbmdpbnhfdmFsaWRhdGlvbl9taXNzaW5nIiksCik6CiAgICBpZiBuZWVkbGUgbm90IGluIHNpdGVfc3dpdGNoOgogICAgICAgIGZhaWwobGFiZWwpCgoKIyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0KIyBDYW5vbmljYWwgc291cmNlIHN0cnVjdHVyZSBhbmQgaW50ZXJuYWwgaW1wb3J0IHJlc29sdXRpb24uCiMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tCmZvciByZW1vdmVkIGluICgKICAgICJCVUlMRC1XSU5ET1dTLnBzMSIsCiAgICAiQlVJTEQtU0lHTi1QVUJMSVNILnBzMSIsCiAgICAidG9vbHMvdXNhZ2VfY2F0YWxvZ19nYXRlLnB5IiwKICAgICJ0b29scy93aW5kb3dfY2xvc2VfdXNhZ2VfZ2F0ZS5weSIsCiAgICAiY29yZS9ib290c3RyYXAvY29tcG9zaXRpb24iLAogICAgImluZnJhL3RhYnVsYXIiLAogICAgImluZnJhL2FwaSIsCiAgICAidWkvYXV0aCIsCiAgICAidWkvZGlhbG9ncyIsCiAgICAidWkvZGVzaWduZXIiLAopOgogICAgaWYgKFJPT1QgLyByZW1vdmVkKS5leGlzdHMoKToKICAgICAgICBmYWlsKGYibGVnYWN5X29yX3JlZHVuZGFudF9wYXRoX3ByZXNlbnQ9e3JlbW92ZWR9IikKCmV4cGVjdGVkX21vZHVsZXMgPSB7CiAgICAiY29yZS5ib290c3RyYXAiLAogICAgImluZnJhLmV4Y2VsIiwKICAgICJpbmZyYS5hcGkiLAogICAgInVpLmxvZ2luIiwKICAgICJ1aS5kaWFsb2dzIiwKICAgICJ1aS5kZXNpZ25lciIsCn0KbW9kdWxlX2ZpbGVzOiBzZXRbc3RyXSA9IHNldCgpCnBhY2thZ2VfZGlyczogc2V0W3N0cl0gPSBzZXQoKQpmb3IgcGF0aCBpbiBST09ULnJnbG9iKCIqLnB5Iik6CiAgICBpZiBhbnkocGFydCBpbiB7Ii52ZW52LWJ1aWxkIiwgIl9fcHljYWNoZV9fIn0gZm9yIHBhcnQgaW4gcGF0aC5wYXJ0cyk6CiAgICAgICAgY29udGludWUKICAgIHJlbCA9IHBhdGgucmVsYXRpdmVfdG8oUk9PVCkKICAgIGlmIHJlbC5uYW1lID09ICJfX2luaXRfXy5weSI6CiAgICAgICAgbW9kdWxlID0gIi4iLmpvaW4ocmVsLnBhcmVudC5wYXJ0cykKICAgIGVsc2U6CiAgICAgICAgbW9kdWxlID0gIi4iLmpvaW4ocmVsLndpdGhfc3VmZml4KCIiKS5wYXJ0cykKICAgIG1vZHVsZV9maWxlcy5hZGQobW9kdWxlKQogICAgcGFydHMgPSBtb2R1bGUuc3BsaXQoIi4iKQogICAgZm9yIGluZGV4IGluIHJhbmdlKDEsIGxlbihwYXJ0cykpOgogICAgICAgIHBhY2thZ2VfZGlycy5hZGQoIi4iLmpvaW4ocGFydHNbOmluZGV4XSkpCgphdmFpbGFibGVfbW9kdWxlcyA9IG1vZHVsZV9maWxlcyB8IHBhY2thZ2VfZGlycwpmb3IgZXhwZWN0ZWQgaW4gZXhwZWN0ZWRfbW9kdWxlczoKICAgIGlmIGV4cGVjdGVkIG5vdCBpbiBhdmFpbGFibGVfbW9kdWxlczoKICAgICAgICBmYWlsKGYiY2Fub25pY2FsX21vZHVsZV9taXNzaW5nPXtleHBlY3RlZH0iKQoKZm9yIHBhdGggaW4gUk9PVC5yZ2xvYigiKi5weSIpOgogICAgaWYgYW55KHBhcnQgaW4geyIudmVudi1idWlsZCIsICJfX3B5Y2FjaGVfXyJ9IGZvciBwYXJ0IGluIHBhdGgucGFydHMpOgogICAgICAgIGNvbnRpbnVlCiAgICB0cmVlID0gYXN0LnBhcnNlKHBhdGgucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOC1zaWciKSwgZmlsZW5hbWU9c3RyKHBhdGgpKQogICAgZm9yIG5vZGUgaW4gYXN0LndhbGsodHJlZSk6CiAgICAgICAgaWYgaXNpbnN0YW5jZShub2RlLCBhc3QuSW1wb3J0KToKICAgICAgICAgICAgbmFtZXMgPSBbYWxpYXMubmFtZSBmb3IgYWxpYXMgaW4gbm9kZS5uYW1lc10KICAgICAgICBlbGlmIGlzaW5zdGFuY2Uobm9kZSwgYXN0LkltcG9ydEZyb20pIGFuZCBub2RlLmxldmVsID09IDAgYW5kIG5vZGUubW9kdWxlOgogICAgICAgICAgICBuYW1lcyA9IFtub2RlLm1vZHVsZV0KICAgICAgICBlbHNlOgogICAgICAgICAgICBjb250aW51ZQogICAgICAgIGZvciBuYW1lIGluIG5hbWVzOgogICAgICAgICAgICBpZiBub3QgKG5hbWUgaW4geyJjb3JlIiwgInNlcnZpY2VzIiwgImluZnJhIiwgInVpIiwgImNvbnRyYWN0cyJ9IG9yIG5hbWUuc3RhcnRzd2l0aCgoImNvcmUuIiwgInNlcnZpY2VzLiIsICJpbmZyYS4iLCAidWkuIiwgImNvbnRyYWN0cy4iKSkpOgogICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgaWYgbmFtZSBub3QgaW4gYXZhaWxhYmxlX21vZHVsZXM6CiAgICAgICAgICAgICAgICBmYWlsKGYidW5yZXNvbHZlZF9pbnRlcm5hbF9pbXBvcnQ9e3BhdGgucmVsYXRpdmVfdG8oUk9PVCl9OntuYW1lfSIpCgpsZWdhY3lfaW1wb3J0X2ZyYWdtZW50cyA9ICgKICAgICJpbmZyYS50YWJ1bGFyLiIsCiAgICAidWkuYXV0aC4iLAogICAgInVpLmRlc2lnbmVyLmxvYWRlciIsCikKZm9yIHBhdGggaW4gUk9PVC5yZ2xvYigiKi5weSIpOgogICAgaWYgcGF0aC5yZXNvbHZlKCkgPT0gUGF0aChfX2ZpbGVfXykucmVzb2x2ZSgpOgogICAgICAgIGNvbnRpbnVlCiAgICB0ZXh0ID0gcGF0aC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04LXNpZyIpCiAgICBmb3IgZnJhZ21lbnQgaW4gbGVnYWN5X2ltcG9ydF9mcmFnbWVudHM6CiAgICAgICAgaWYgZnJhZ21lbnQgaW4gdGV4dDoKICAgICAgICAgICAgZmFpbChmImxlZ2FjeV9pbXBvcnRfcHJlc2VudD17cGF0aC5yZWxhdGl2ZV90byhST09UKX06e2ZyYWdtZW50fSIpCgpwcmludCgiQVVESVRFRF9SRUxFQVNFX0dBVEU9UEFTUyIpCg==",
    "build_update_publication.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGFyZ3BhcnNlCmltcG9ydCBiYXNlNjQKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGdldHBhc3MKaW1wb3J0IGpzb24KaW1wb3J0IHNodXRpbAppbXBvcnQgemlwZmlsZQpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKCmZyb20gY3J5cHRvZ3JhcGh5Lmhhem1hdC5wcmltaXRpdmVzIGltcG9ydCBzZXJpYWxpemF0aW9uCmZyb20gY3J5cHRvZ3JhcGh5Lmhhem1hdC5wcmltaXRpdmVzLmFzeW1tZXRyaWMuZWQyNTUxOSBpbXBvcnQgRWQyNTUxOVByaXZhdGVLZXksIEVkMjU1MTlQdWJsaWNLZXkKCgpkZWYgc2hhMjU2X2ZpbGUocGF0aDogUGF0aCkgLT4gc3RyOgogICAgaCA9IGhhc2hsaWIuc2hhMjU2KCkKICAgIHdpdGggcGF0aC5vcGVuKCJyYiIpIGFzIGY6CiAgICAgICAgZm9yIGJsb2NrIGluIGl0ZXIobGFtYmRhOiBmLnJlYWQoMTAyNCAqIDEwMjQpLCBiIiIpOgogICAgICAgICAgICBoLnVwZGF0ZShibG9jaykKICAgIHJldHVybiBoLmhleGRpZ2VzdCgpCgoKZGVmIGNvbnRyYWN0X3NoYTI1Nihjb250cmFjdHNfZGlyOiBQYXRoKSAtPiBzdHI6CiAgICAiIiJSZXR1cm4gdGhlIGNhbm9uaWNhbCBBUEktY29tcGF0aWJpbGl0eSBhZ2dyZWdhdGUgb25seS4iIiIKICAgIG1hbmlmZXN0ID0ganNvbi5sb2FkcygoY29udHJhY3RzX2RpciAvICJDT05UUkFDVFMuanNvbiIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSkKICAgIGVudHJpZXMgPSBtYW5pZmVzdC5nZXQoImNvbnRyYWN0cyIpCiAgICBhcGlfbmFtZXMgPSBtYW5pZmVzdC5nZXQoImFwaV9jb21wYXRpYmlsaXR5X2NvbnRyYWN0cyIpCiAgICBpZiBub3QgaXNpbnN0YW5jZShlbnRyaWVzLCBsaXN0KSBvciBub3QgaXNpbnN0YW5jZShhcGlfbmFtZXMsIGxpc3QpIG9yIG5vdCBhcGlfbmFtZXM6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgiaW52YWxpZCBjb250cmFjdCBtYW5pZmVzdCIpCiAgICBieV9uYW1lID0ge3N0cihlbnRyeS5nZXQoImZpbGVuYW1lIikgb3IgIiIpOiBlbnRyeSBmb3IgZW50cnkgaW4gZW50cmllcyBpZiBpc2luc3RhbmNlKGVudHJ5LCBkaWN0KX0KICAgIG5vcm1hbGl6ZWQgPSBbc3RyKG5hbWUpLnN0cmlwKCkgZm9yIG5hbWUgaW4gYXBpX25hbWVzXQogICAgaWYgYW55KG5vdCBuYW1lIGZvciBuYW1lIGluIG5vcm1hbGl6ZWQpIG9yIGxlbihzZXQobm9ybWFsaXplZCkpICE9IGxlbihub3JtYWxpemVkKToKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJpbnZhbGlkIGFwaV9jb21wYXRpYmlsaXR5X2NvbnRyYWN0cyIpCiAgICB1bmtub3duID0gc29ydGVkKHNldChub3JtYWxpemVkKSAtIHNldChieV9uYW1lKSkKICAgIGlmIHVua25vd246CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdChmInVua25vd24gQVBJIGNvbXBhdGliaWxpdHkgY29udHJhY3RzOiB7dW5rbm93bn0iKQoKICAgIGRpZ2VzdCA9IGhhc2hsaWIuc2hhMjU2KCkKICAgIGZvciBuYW1lIGluIHNvcnRlZChub3JtYWxpemVkKToKICAgICAgICByYXcgPSAoY29udHJhY3RzX2RpciAvIG5hbWUpLnJlYWRfYnl0ZXMoKQogICAgICAgIGFjdHVhbCA9IGhhc2hsaWIuc2hhMjU2KHJhdykuaGV4ZGlnZXN0KCkKICAgICAgICBpZiBhY3R1YWwgIT0gc3RyKGJ5X25hbWVbbmFtZV0uZ2V0KCJzaGEyNTYiKSBvciAiIikubG93ZXIoKToKICAgICAgICAgICAgcmFpc2UgU3lzdGVtRXhpdChmImNvbnRyYWN0IGNoZWNrc3VtIG1pc21hdGNoOiB7bmFtZX0iKQogICAgICAgIGRpZ2VzdC51cGRhdGUobmFtZS5lbmNvZGUoInV0Zi04IikpCiAgICAgICAgZGlnZXN0LnVwZGF0ZShiIlwwIikKICAgICAgICBkaWdlc3QudXBkYXRlKHJhdykKICAgICAgICBkaWdlc3QudXBkYXRlKGIiXDAiKQogICAgYWN0dWFsID0gZGlnZXN0LmhleGRpZ2VzdCgpCiAgICBleHBlY3RlZCA9IHN0cihtYW5pZmVzdC5nZXQoInNlcnZlcl9jb21wYXRpYmxlX2FwaV9jb250cmFjdF9zaGEyNTYiKSBvciAiIikubG93ZXIoKQogICAgaWYgYWN0dWFsICE9IGV4cGVjdGVkOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoIkFQSSBjb21wYXRpYmlsaXR5IGFnZ3JlZ2F0ZSBtaXNtYXRjaCIpCiAgICByZXR1cm4gYWN0dWFsCmRlZiBjYW5vbmljYWxfcGF5bG9hZChwYXlsb2FkOiBkaWN0KSAtPiBieXRlczoKICAgIGJvZHkgPSB7azogdiBmb3IgaywgdiBpbiBwYXlsb2FkLml0ZW1zKCkgaWYgayAhPSAic2lnbmF0dXJlIn0KICAgIHJldHVybiBqc29uLmR1bXBzKAogICAgICAgIGJvZHksCiAgICAgICAgc29ydF9rZXlzPVRydWUsCiAgICAgICAgc2VwYXJhdG9ycz0oIiwiLCAiOiIpLAogICAgICAgIGVuc3VyZV9hc2NpaT1GYWxzZSwKICAgICkuZW5jb2RlKCJ1dGYtOCIpCgoKZGVmIGxvYWRfcHJpdmF0ZV9rZXkocGF0aDogUGF0aCwgcGFzc3dvcmQ6IHN0ciB8IE5vbmUpIC0+IEVkMjU1MTlQcml2YXRlS2V5OgogICAgcmF3ID0gcGF0aC5yZWFkX2J5dGVzKCkKICAgIHN1cHBsaWVkID0gc3RyKHBhc3N3b3JkIG9yICIiKQogICAgaWYgc3VwcGxpZWQ6CiAgICAgICAga2V5ID0gc2VyaWFsaXphdGlvbi5sb2FkX3BlbV9wcml2YXRlX2tleShyYXcsIHBhc3N3b3JkPXN1cHBsaWVkLmVuY29kZSgidXRmLTgiKSkKICAgIGVsc2U6CiAgICAgICAgdHJ5OgogICAgICAgICAgICBrZXkgPSBzZXJpYWxpemF0aW9uLmxvYWRfcGVtX3ByaXZhdGVfa2V5KHJhdywgcGFzc3dvcmQ9Tm9uZSkKICAgICAgICBleGNlcHQgVHlwZUVycm9yOgogICAgICAgICAgICAjIEVuY3J5cHRlZCBQRU06IHByb21wdCBpbiB0aGUgb3BlcmF0b3IgdGVybWluYWwgd2l0aG91dCBlY2hvaW5nIGFuZAogICAgICAgICAgICAjIHdpdGhvdXQgcGxhY2luZyB0aGUgcGFzc3BocmFzZSBpbiBhcmd2LCBzb3VyY2UgZmlsZXMsIG9yIGxvZ3MuCiAgICAgICAgICAgIHN1cHBsaWVkID0gZ2V0cGFzcy5nZXRwYXNzKCJVcGRhdGUgc2lnbmluZyBrZXkgcGFzc3BocmFzZTogIikKICAgICAgICAgICAgaWYgbm90IHN1cHBsaWVkOgogICAgICAgICAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgidXBkYXRlIHNpZ25pbmcga2V5IHBhc3NwaHJhc2UgaXMgcmVxdWlyZWQiKQogICAgICAgICAgICBrZXkgPSBzZXJpYWxpemF0aW9uLmxvYWRfcGVtX3ByaXZhdGVfa2V5KHJhdywgcGFzc3dvcmQ9c3VwcGxpZWQuZW5jb2RlKCJ1dGYtOCIpKQogICAgaWYgbm90IGlzaW5zdGFuY2Uoa2V5LCBFZDI1NTE5UHJpdmF0ZUtleSk6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgidXBkYXRlIHByaXZhdGUga2V5IGlzIG5vdCBFZDI1NTE5IikKICAgIHJldHVybiBrZXkKCgpkZWYgbWFpbigpIC0+IGludDoKICAgIGFwID0gYXJncGFyc2UuQXJndW1lbnRQYXJzZXIoKQogICAgYXAuYWRkX2FyZ3VtZW50KCItLXJvb3QiLCByZXF1aXJlZD1UcnVlKQogICAgYXAuYWRkX2FyZ3VtZW50KCItLXJ1bnRpbWUtZGlyIiwgcmVxdWlyZWQ9VHJ1ZSkKICAgIGFwLmFkZF9hcmd1bWVudCgiLS1pbnN0YWxsZXIiLCByZXF1aXJlZD1UcnVlKQogICAgYXAuYWRkX2FyZ3VtZW50KCItLXByaXZhdGUta2V5IiwgcmVxdWlyZWQ9VHJ1ZSkKICAgIGFwLmFkZF9hcmd1bWVudCgiLS1vdXQiLCByZXF1aXJlZD1UcnVlKQogICAgYXAuYWRkX2FyZ3VtZW50KCItLXBhc3N3b3JkLWVudiIsIGRlZmF1bHQ9IkhFUkZZX1VQREFURV9LRVlfUEFTU1dPUkQiKQogICAgYXJncyA9IGFwLnBhcnNlX2FyZ3MoKQoKICAgIHJvb3QgPSBQYXRoKGFyZ3Mucm9vdCkucmVzb2x2ZSgpCiAgICBydW50aW1lX2RpciA9IFBhdGgoYXJncy5ydW50aW1lX2RpcikucmVzb2x2ZSgpCiAgICBpbnN0YWxsZXIgPSBQYXRoKGFyZ3MuaW5zdGFsbGVyKS5yZXNvbHZlKCkKICAgIG91dCA9IFBhdGgoYXJncy5vdXQpLnJlc29sdmUoKQoKICAgIHZlcnNpb24gPSBzdHIoanNvbi5sb2Fkcygocm9vdCAvICJ2ZXJzaW9uLmpzb24iKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikpWyJ2ZXJzaW9uIl0pCiAgICB1cGRhdGVfY29udHJhY3QgPSBqc29uLmxvYWRzKChyb290IC8gImNvbnRyYWN0cy91cGRhdGUuanNvbiIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSkKICAgIGlmIHVwZGF0ZV9jb250cmFjdC5nZXQoIm9yaWdpbiIpICE9ICJodHRwczovL3VwZGF0ZXMuaGVyZnkub25saW5lIjoKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJ1bmV4cGVjdGVkIHVwZGF0ZSBvcmlnaW47IHJlZnVzaW5nIHB1YmxpY2F0aW9uIikKCiAgICBhcmNoaXRlY3R1cmUgPSAieDY0IgogICAgcnVudGltZV9uYW1lID0gZiJIRVJGWS1UUy17dmVyc2lvbn0td2luZG93cy17YXJjaGl0ZWN0dXJlfS1ydW50aW1lLnppcCIKICAgIGluc3RhbGxlcl9uYW1lID0gZiJIRVJGWS1UUy1TZXR1cC17dmVyc2lvbn0td2luZG93cy17YXJjaGl0ZWN0dXJlfS5leGUiCgogICAgaWYgaW5zdGFsbGVyLm5hbWUgIT0gaW5zdGFsbGVyX25hbWU6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdChmImluc3RhbGxlciBjYW5vbmljYWwgbmFtZSBtaXNtYXRjaDogZXhwZWN0ZWQge2luc3RhbGxlcl9uYW1lfSIpCgogICAgcGFja2FnZV9kaXIgPSBvdXQgLyAidXBkYXRlcyIgLyAicGFja2FnZXMiCiAgICBwYWNrYWdlX2Rpci5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUpCiAgICBydW50aW1lX3ppcCA9IHBhY2thZ2VfZGlyIC8gcnVudGltZV9uYW1lCiAgICBwdWJsaXNoZWRfaW5zdGFsbGVyID0gcGFja2FnZV9kaXIgLyBpbnN0YWxsZXJfbmFtZQoKICAgIGlmIHJ1bnRpbWVfemlwLmV4aXN0cygpOgogICAgICAgIHJ1bnRpbWVfemlwLnVubGluaygpCgogICAgd2l0aCB6aXBmaWxlLlppcEZpbGUocnVudGltZV96aXAsICJ3IiwgemlwZmlsZS5aSVBfREVGTEFURUQsIGNvbXByZXNzbGV2ZWw9OSkgYXMgemY6CiAgICAgICAgZm9yIGl0ZW0gaW4gc29ydGVkKHJ1bnRpbWVfZGlyLnJnbG9iKCIqIikpOgogICAgICAgICAgICBpZiBpdGVtLmlzX2ZpbGUoKToKICAgICAgICAgICAgICAgIHpmLndyaXRlKGl0ZW0sIGl0ZW0ucmVsYXRpdmVfdG8ocnVudGltZV9kaXIpLmFzX3Bvc2l4KCkpCgogICAgc2h1dGlsLmNvcHkyKGluc3RhbGxlciwgcHVibGlzaGVkX2luc3RhbGxlcikKCiAgICBwdWJsaWNfcGVtID0gKHJvb3QgLyAicmVzb3VyY2VzL3VwZGF0ZV9zaWduaW5nX3B1YmxpYy5wZW0iKS5yZWFkX2J5dGVzKCkKICAgIGV4cGVjdGVkX3BlbV9oYXNoID0gc3RyKHVwZGF0ZV9jb250cmFjdFsicHVibGljX2tleV9wZW1fc2hhMjU2Il0pLmxvd2VyKCkKICAgIGlmIGhhc2hsaWIuc2hhMjU2KHB1YmxpY19wZW0pLmhleGRpZ2VzdCgpICE9IGV4cGVjdGVkX3BlbV9oYXNoOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoInBpbm5lZCB1cGRhdGUgcHVibGljIFBFTSBmaW5nZXJwcmludCBtaXNtYXRjaCIpCgogICAgcHVibGljX2tleSA9IHNlcmlhbGl6YXRpb24ubG9hZF9wZW1fcHVibGljX2tleShwdWJsaWNfcGVtKQogICAgaWYgbm90IGlzaW5zdGFuY2UocHVibGljX2tleSwgRWQyNTUxOVB1YmxpY0tleSk6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgicGlubmVkIHVwZGF0ZSBwdWJsaWMga2V5IGlzIG5vdCBFZDI1NTE5IikKICAgIHB1YmxpY19yYXcgPSBwdWJsaWNfa2V5LnB1YmxpY19ieXRlcygKICAgICAgICBzZXJpYWxpemF0aW9uLkVuY29kaW5nLlJhdywKICAgICAgICBzZXJpYWxpemF0aW9uLlB1YmxpY0Zvcm1hdC5SYXcsCiAgICApCiAgICBrZXlfaWQgPSBoYXNobGliLnNoYTI1NihwdWJsaWNfcmF3KS5oZXhkaWdlc3QoKQogICAgaWYga2V5X2lkICE9IHN0cih1cGRhdGVfY29udHJhY3RbImtleV9pZCJdKS5sb3dlcigpOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoInBpbm5lZCB1cGRhdGUga2V5IGlkIG1pc21hdGNoIikKCiAgICBpbXBvcnQgb3MKICAgIHBhc3N3b3JkID0gb3MuZW52aXJvbi5nZXQoYXJncy5wYXNzd29yZF9lbnYpCiAgICBwcml2YXRlX2tleSA9IGxvYWRfcHJpdmF0ZV9rZXkoUGF0aChhcmdzLnByaXZhdGVfa2V5KS5yZXNvbHZlKCksIHBhc3N3b3JkKQogICAgZGVyaXZlZF9wdWJsaWMgPSBwcml2YXRlX2tleS5wdWJsaWNfa2V5KCkucHVibGljX2J5dGVzKAogICAgICAgIHNlcmlhbGl6YXRpb24uRW5jb2RpbmcuUmF3LAogICAgICAgIHNlcmlhbGl6YXRpb24uUHVibGljRm9ybWF0LlJhdywKICAgICkKICAgIGlmIGhhc2hsaWIuc2hhMjU2KGRlcml2ZWRfcHVibGljKS5oZXhkaWdlc3QoKSAhPSBrZXlfaWQ6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgicHJpdmF0ZSB1cGRhdGUga2V5IGRvZXMgbm90IG1hdGNoIHRoZSBwdWJsaWMga2V5IHBpbm5lZCBieSB0aGUgY2xpZW50IikKCiAgICBvcmlnaW4gPSBzdHIodXBkYXRlX2NvbnRyYWN0WyJvcmlnaW4iXSkucnN0cmlwKCIvIikKICAgIGNvbnRyYWN0X2hhc2ggPSBjb250cmFjdF9zaGEyNTYocm9vdCAvICJjb250cmFjdHMiKQoKICAgIHBheWxvYWQgPSB7CiAgICAgICAgInZlcnNpb24iOiB2ZXJzaW9uLAogICAgICAgICJwbGF0Zm9ybSI6ICJ3aW5kb3dzIiwKICAgICAgICAiYXJjaGl0ZWN0dXJlIjogYXJjaGl0ZWN0dXJlLAogICAgICAgICJjb250cmFjdF9zaGEyNTYiOiBjb250cmFjdF9oYXNoLAogICAgICAgICJydW50aW1lX3VybCI6IGYie29yaWdpbn0vdXBkYXRlcy9wYWNrYWdlcy97cnVudGltZV9uYW1lfSIsCiAgICAgICAgInJ1bnRpbWVfc2hhMjU2Ijogc2hhMjU2X2ZpbGUocnVudGltZV96aXApLAogICAgICAgICJydW50aW1lX3NpemUiOiBydW50aW1lX3ppcC5zdGF0KCkuc3Rfc2l6ZSwKICAgICAgICAiaW5zdGFsbGVyX3VybCI6IGYie29yaWdpbn0vdXBkYXRlcy9wYWNrYWdlcy97aW5zdGFsbGVyX25hbWV9IiwKICAgICAgICAiaW5zdGFsbGVyX3NoYTI1NiI6IHNoYTI1Nl9maWxlKHB1Ymxpc2hlZF9pbnN0YWxsZXIpLAogICAgICAgICJpbnN0YWxsZXJfc2l6ZSI6IHB1Ymxpc2hlZF9pbnN0YWxsZXIuc3RhdCgpLnN0X3NpemUsCiAgICAgICAgImtleV9pZCI6IGtleV9pZCwKICAgIH0KICAgIHBheWxvYWRbInNpZ25hdHVyZSJdID0gYmFzZTY0LmI2NGVuY29kZSgKICAgICAgICBwcml2YXRlX2tleS5zaWduKGNhbm9uaWNhbF9wYXlsb2FkKHBheWxvYWQpKQogICAgKS5kZWNvZGUoImFzY2lpIikKCiAgICAjIFZlcmlmeSBiZWZvcmUgd3JpdGluZy4KICAgIHB1YmxpY19rZXkudmVyaWZ5KAogICAgICAgIGJhc2U2NC5iNjRkZWNvZGUocGF5bG9hZFsic2lnbmF0dXJlIl0sIHZhbGlkYXRlPVRydWUpLAogICAgICAgIGNhbm9uaWNhbF9wYXlsb2FkKHBheWxvYWQpLAogICAgKQoKICAgIHVwZGF0ZXNfZGlyID0gb3V0IC8gInVwZGF0ZXMiCiAgICAodXBkYXRlc19kaXIgLyAibWFuaWZlc3QiKS53cml0ZV90ZXh0KAogICAgICAgIGpzb24uZHVtcHMocGF5bG9hZCwgZW5zdXJlX2FzY2lpPUZhbHNlLCBzZXBhcmF0b3JzPSgiLCIsICI6IikpLAogICAgICAgIGVuY29kaW5nPSJ1dGYtOCIsCiAgICApCiAgICAodXBkYXRlc19kaXIgLyAicHVibGljLWtleSIpLndyaXRlX2J5dGVzKHB1YmxpY19wZW0pCgogICAgcHVibGljYXRpb25faW5mbyA9IHsKICAgICAgICAib3JpZ2luIjogb3JpZ2luLAogICAgICAgICJtYW5pZmVzdF91cmwiOiBzdHIodXBkYXRlX2NvbnRyYWN0WyJtYW5pZmVzdF91cmwiXSksCiAgICAgICAgInB1YmxpY19rZXlfdXJsIjogc3RyKHVwZGF0ZV9jb250cmFjdFsicHVibGljX2tleV91cmwiXSksCiAgICAgICAgInZlcnNpb24iOiB2ZXJzaW9uLAogICAgICAgICJhcmNoaXRlY3R1cmUiOiBhcmNoaXRlY3R1cmUsCiAgICAgICAgInJ1bnRpbWUiOiBydW50aW1lX25hbWUsCiAgICAgICAgImluc3RhbGxlciI6IGluc3RhbGxlcl9uYW1lLAogICAgICAgICJjb250cmFjdF9zaGEyNTYiOiBjb250cmFjdF9oYXNoLAogICAgICAgICJrZXlfaWQiOiBrZXlfaWQsCiAgICB9CiAgICAob3V0IC8gIlBVQkxJQ0FUSU9OX0lORk8uanNvbiIpLndyaXRlX3RleHQoCiAgICAgICAganNvbi5kdW1wcyhwdWJsaWNhdGlvbl9pbmZvLCBpbmRlbnQ9MiwgZW5zdXJlX2FzY2lpPUZhbHNlKSwKICAgICAgICBlbmNvZGluZz0idXRmLTgiLAogICAgKQogICAgcHJpbnQoanNvbi5kdW1wcyhwdWJsaWNhdGlvbl9pbmZvLCBpbmRlbnQ9MikpCiAgICByZXR1cm4gMAoKCmlmIF9fbmFtZV9fID09ICJfX21haW5fXyI6CiAgICByYWlzZSBTeXN0ZW1FeGl0KG1haW4oKSkK",
    "deep_clean_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGFzdAppbXBvcnQgc3lzCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAoKUk9PVCA9IFBhdGgoX19maWxlX18pLnJlc29sdmUoKS5wYXJlbnRzWzJdClJVTlRJTUVfUk9PVFMgPSBbUk9PVCAvIG5hbWUgZm9yIG5hbWUgaW4gKCJjb3JlIiwgInNlcnZpY2VzIiwgImluZnJhIiwgInVpIildCgplcnJvcnM6IGxpc3Rbc3RyXSA9IFtdCgpmb3IgcnVudGltZV9yb290IGluIFJVTlRJTUVfUk9PVFM6CiAgICBmb3IgcGF0aCBpbiBydW50aW1lX3Jvb3Qucmdsb2IoIioucHkiKToKICAgICAgICB0ZXh0ID0gcGF0aC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiwgZXJyb3JzPSJyZXBsYWNlIikKICAgICAgICBmb3IgdG9rZW4gaW4gKCJ3aW4xMHRvYXN0IiwgInBrZ19yZXNvdXJjZXMiKToKICAgICAgICAgICAgaWYgdG9rZW4gaW4gdGV4dDoKICAgICAgICAgICAgICAgIGVycm9ycy5hcHBlbmQoZiJPYnNvbGV0ZSBydW50aW1lIHRva2VuIHt0b2tlbn06IHtwYXRoLnJlbGF0aXZlX3RvKFJPT1QpfSIpCgpmb3IgcnVudGltZV9yb290IGluIFJVTlRJTUVfUk9PVFM6CiAgICBmb3IgcGF0aCBpbiBydW50aW1lX3Jvb3Qucmdsb2IoIioucHkiKToKICAgICAgICBpZiBwYXRoLm5hbWUgPT0gIl9faW5pdF9fLnB5IjoKICAgICAgICAgICAgY29udGludWUKICAgICAgICB0cnk6CiAgICAgICAgICAgIHRyZWUgPSBhc3QucGFyc2UocGF0aC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikpCiAgICAgICAgZXhjZXB0IFN5bnRheEVycm9yIGFzIGV4YzoKICAgICAgICAgICAgZXJyb3JzLmFwcGVuZChmIlB5dGhvbiBzeW50YXggZXJyb3I6IHtwYXRoLnJlbGF0aXZlX3RvKFJPT1QpfToge2V4Y30iKQogICAgICAgICAgICBjb250aW51ZQoKICAgICAgICB1c2VkID0ge25vZGUuaWQgZm9yIG5vZGUgaW4gYXN0LndhbGsodHJlZSkgaWYgaXNpbnN0YW5jZShub2RlLCBhc3QuTmFtZSl9CiAgICAgICAgaW1wb3J0ZWQ6IGxpc3RbdHVwbGVbc3RyLCBpbnRdXSA9IFtdCiAgICAgICAgZm9yIG5vZGUgaW4gYXN0LndhbGsodHJlZSk6CiAgICAgICAgICAgIGlmIGlzaW5zdGFuY2Uobm9kZSwgYXN0LkltcG9ydCk6CiAgICAgICAgICAgICAgICBmb3IgYWxpYXMgaW4gbm9kZS5uYW1lczoKICAgICAgICAgICAgICAgICAgICBpbXBvcnRlZC5hcHBlbmQoKGFsaWFzLmFzbmFtZSBvciBhbGlhcy5uYW1lLnNwbGl0KCIuIiwgMSlbMF0sIG5vZGUubGluZW5vKSkKICAgICAgICAgICAgZWxpZiBpc2luc3RhbmNlKG5vZGUsIGFzdC5JbXBvcnRGcm9tKToKICAgICAgICAgICAgICAgIGlmIG5vZGUubW9kdWxlID09ICJfX2Z1dHVyZV9fIjoKICAgICAgICAgICAgICAgICAgICBjb250aW51ZQogICAgICAgICAgICAgICAgZm9yIGFsaWFzIGluIG5vZGUubmFtZXM6CiAgICAgICAgICAgICAgICAgICAgaWYgYWxpYXMubmFtZSA9PSAiKiI6CiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAgICAgICAgICAgaW1wb3J0ZWQuYXBwZW5kKChhbGlhcy5hc25hbWUgb3IgYWxpYXMubmFtZSwgbm9kZS5saW5lbm8pKQoKICAgICAgICBmb3IgbmFtZSwgbGluZV9ubyBpbiBpbXBvcnRlZDoKICAgICAgICAgICAgaWYgbmFtZS5zdGFydHN3aXRoKCJfIik6CiAgICAgICAgICAgICAgICBjb250aW51ZQogICAgICAgICAgICBpZiBuYW1lIG5vdCBpbiB1c2VkOgogICAgICAgICAgICAgICAgZXJyb3JzLmFwcGVuZChmIlVudXNlZCBydW50aW1lIGltcG9ydDoge3BhdGgucmVsYXRpdmVfdG8oUk9PVCl9OntsaW5lX25vfSAoe25hbWV9KSIpCgpsYXlvdXRfc291cmNlID0gKFJPT1QgLyAidWkvbWFpbl93aW5kb3cucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKZm9yIHN0YWxlIGluICgKICAgICdzZWxmLmZpbmRDaGlsZChRVkJveExheW91dCwgInNoZWxsX3NpZGViYXJfbGF5b3V0IiknLAogICAgJ3NlbGYuZmluZENoaWxkKFFWQm94TGF5b3V0LCAic2hlbGxfdG9wX2Jhcl9sYXlvdXQiKScsCiAgICAnc2VsZi5maW5kQ2hpbGQoUVZCb3hMYXlvdXQsICJjb250ZW50X3N0YWNrX2xheW91dCIpJywKKToKICAgIGlmIHN0YWxlIGluIGxheW91dF9zb3VyY2U6CiAgICAgICAgZXJyb3JzLmFwcGVuZChmIlN0YWxlIHNoZWxsIG93bmVyc2hpcCBsb29rdXA6IHtzdGFsZX0iKQoKcHJpbnQoIkRFRVBfQ0xFQU5fR0FURT0iICsgKCJQQVNTIiBpZiBub3QgZXJyb3JzIGVsc2UgIkZBSUwiKSkKZm9yIGVycm9yIGluIGVycm9yczoKICAgIHByaW50KCIgLSIsIGVycm9yKQpzeXMuZXhpdCgwIGlmIG5vdCBlcnJvcnMgZWxzZSAxKQo=",
    "prepare_build.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IG9zCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aAppbXBvcnQgc3lzCgpST09UID0gUGF0aChfX2ZpbGVfXykucmVzb2x2ZSgpLnBhcmVudHNbMl0KCiMgVGhpcyB0b29sIGlzIGV4ZWN1dGVkIGRpcmVjdGx5IGZyb20gb3BzL2dhdGVzIGR1cmluZyB0aGUgV2luZG93cyByZWxlYXNlCiMgYnVpbGQuIEluIHRoYXQgbW9kZSBQeXRob24gcHV0cyBvbmx5IG9wcy9nYXRlcyBvbiBzeXMucGF0aCwKIyBub3QgdGhlIHByb2plY3Qgcm9vdCwgc28gaW1wb3J0cyBzdWNoIGFzIGBjb3JlLipgLCBgc2VydmljZXMuKmAsIGBpbmZyYS4qYCwgYW5kIGB1aS4qYCB3b3VsZCBmYWlsLgpyb290X3RleHQgPSBzdHIoUk9PVCkKaWYgcm9vdF90ZXh0IG5vdCBpbiBzeXMucGF0aDoKICAgIHN5cy5wYXRoLmluc2VydCgwLCByb290X3RleHQpCkVYQ0xVREVEX1BBUlRTID0geyIuZ2l0IiwgIi52ZW52IiwgIi52ZW52LWJ1aWxkIiwgImJ1aWxkIiwgImJ1aWxkLWFnZW50IiwgImRpc3QiLCAiZGlzdC1hZ2VudCIsICJfX3B5Y2FjaGVfXyJ9CkVYQ0xVREVEX0ZJTEVTID0geyJCVUlMRF9QUk9WRU5BTkNFLmpzb24iLCAicnVudGltZV9maWxlcy50eHQifQoKCmRlZiBzb3VyY2Vfc2hhMjU2KCkgLT4gc3RyOgogICAgZGlnZXN0ID0gaGFzaGxpYi5zaGEyNTYoKQogICAgY2FuZGlkYXRlcyA9IFtdCiAgICAjIEV4Y2x1ZGUgZ2VuZXJhdGVkIHRyZWVzIGJlZm9yZSBkZXNjZW50LiBGaWx0ZXJpbmcgYWZ0ZXIgYGByZ2xvYmBgIGlzIHRvbwogICAgIyBsYXRlIG9uIFdpbmRvd3M6IGEgdmlydHVhbCBlbnZpcm9ubWVudCBjYW4gY29udGFpbiBwYXRocyBiZXlvbmQgdGhlCiAgICAjIHBsYXRmb3JtIGxpbWl0IGJlZm9yZSB0aGUgZXhjbHVzaW9uIHByZWRpY2F0ZSBpcyBldmFsdWF0ZWQuCiAgICBmb3IgY3VycmVudCwgZGlyZWN0b3JpZXMsIGZpbGVuYW1lcyBpbiBvcy53YWxrKFJPT1QpOgogICAgICAgIGRpcmVjdG9yaWVzWzpdID0gW25hbWUgZm9yIG5hbWUgaW4gZGlyZWN0b3JpZXMgaWYgbmFtZSBub3QgaW4gRVhDTFVERURfUEFSVFNdCiAgICAgICAgYmFzZSA9IFBhdGgoY3VycmVudCkKICAgICAgICBmb3IgZmlsZW5hbWUgaW4gZmlsZW5hbWVzOgogICAgICAgICAgICBwYXRoID0gYmFzZSAvIGZpbGVuYW1lCiAgICAgICAgICAgIHJlbGF0aXZlID0gcGF0aC5yZWxhdGl2ZV90byhST09UKQogICAgICAgICAgICBpZiBhbnkocGFydCBpbiBFWENMVURFRF9QQVJUUyBmb3IgcGFydCBpbiByZWxhdGl2ZS5wYXJ0cyk6CiAgICAgICAgICAgICAgICBjb250aW51ZQogICAgICAgICAgICBpZiBwYXRoLm5hbWUgaW4gRVhDTFVERURfRklMRVMgb3IgcGF0aC5zdWZmaXgubG93ZXIoKSBpbiB7Ii5weWMiLCAiLnB5byIsICIubG9nIiwgIi50bXAiLCAiLnppcCJ9OgogICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgY2FuZGlkYXRlcy5hcHBlbmQocmVsYXRpdmUpCiAgICBmb3IgcmVsYXRpdmUgaW4gc29ydGVkKGNhbmRpZGF0ZXMsIGtleT1sYW1iZGEgdmFsdWU6IHZhbHVlLmFzX3Bvc2l4KCkuY2FzZWZvbGQoKSk6CiAgICAgICAgcmF3ID0gKFJPT1QgLyByZWxhdGl2ZSkucmVhZF9ieXRlcygpCiAgICAgICAgZGlnZXN0LnVwZGF0ZShyZWxhdGl2ZS5hc19wb3NpeCgpLmVuY29kZSgidXRmLTgiKSkKICAgICAgICBkaWdlc3QudXBkYXRlKGIiXDAiKQogICAgICAgIGRpZ2VzdC51cGRhdGUocmF3KQogICAgICAgIGRpZ2VzdC51cGRhdGUoYiJcMCIpCiAgICByZXR1cm4gZGlnZXN0LmhleGRpZ2VzdCgpCgoKZGVmIF9ydW50aW1lX2NvbnRyYWN0KCkgLT4gdHVwbGVbbGlzdFtzdHJdLCBzdHJdOgogICAgIiIiUmVhZCB0aGUgYnVpbGQtdGltZSB0cmF5L2JhY2tncm91bmQgY29udHJhY3Qgd2l0aG91dCBpbXBvcnRpbmcgUXQuIiIiCiAgICBwYXRoID0gUk9PVCAvICJjb250cmFjdHMiIC8gInJ1bnRpbWVfY29udHJhY3QuanNvbiIKICAgIHBheWxvYWQgPSBqc29uLmxvYWRzKHBhdGgucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpKQogICAgaWYgbm90IGlzaW5zdGFuY2UocGF5bG9hZCwgZGljdCk6CiAgICAgICAgcmFpc2UgUnVudGltZUVycm9yKCJydW50aW1lX2NvbnRyYWN0Lmpzb24gbXVzdCBiZSBhIEpTT04gb2JqZWN0IikKICAgIHRyYXkgPSBwYXlsb2FkLmdldCgidHJheV9tZW51X3RleHRzIikKICAgIGlmICgKICAgICAgICBub3QgaXNpbnN0YW5jZSh0cmF5LCBsaXN0KQogICAgICAgIG9yIGxlbih0cmF5KSAhPSAzCiAgICAgICAgb3Igbm90IGFsbChpc2luc3RhbmNlKGl0ZW0sIHN0cikgYW5kIGl0ZW0uc3RyaXAoKSBmb3IgaXRlbSBpbiB0cmF5KQogICAgKToKICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoInJ1bnRpbWVfY29udHJhY3QuanNvbiB0cmF5X21lbnVfdGV4dHMgaXMgaW52YWxpZCIpCiAgICBiYWNrZ3JvdW5kID0gc3RyKHBheWxvYWQuZ2V0KCJiYWNrZ3JvdW5kX2NvbnRyYWN0Iikgb3IgIiIpLnN0cmlwKCkKICAgIGlmIGJhY2tncm91bmQgIT0gIndpbmRvdy1oaWRkZW4rdHJheS12aXNpYmxlIjoKICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoInJ1bnRpbWVfY29udHJhY3QuanNvbiBiYWNrZ3JvdW5kX2NvbnRyYWN0IGlzIGludmFsaWQiKQogICAgcmV0dXJuIFtpdGVtLnN0cmlwKCkgZm9yIGl0ZW0gaW4gdHJheV0sIGJhY2tncm91bmQKCgpkZWYgbWFpbigpIC0+IGludDoKICAgIHRyYXlfbWVudV90ZXh0cywgYmFja2dyb3VuZF9jb250cmFjdCA9IF9ydW50aW1lX2NvbnRyYWN0KCkKICAgIHZlcnNpb24gPSBqc29uLmxvYWRzKChST09UIC8gInZlcnNpb24uanNvbiIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSlbInZlcnNpb24iXQogICAga2V5X3BhdGggPSBST09UIC8gInJlc291cmNlcyIgLyAidXBkYXRlX3NpZ25pbmdfcHVibGljLnBlbSIKICAgIHBheWxvYWQgPSB7CiAgICAgICAgInByb2R1Y3QiOiAiSEVSRlktVFMiLAogICAgICAgICJ2ZXJzaW9uIjogc3RyKHZlcnNpb24pLAogICAgICAgICJzb3VyY2Vfc2hhMjU2Ijogc291cmNlX3NoYTI1NigpLAogICAgICAgICJ1cGRhdGVfcHVibGljX2tleV9wZW1fc2hhMjU2IjogaGFzaGxpYi5zaGEyNTYoa2V5X3BhdGgucmVhZF9ieXRlcygpKS5oZXhkaWdlc3QoKSwKICAgICAgICAidHJheV9jb250cmFjdCI6IHRyYXlfbWVudV90ZXh0cywKICAgICAgICAiYmFja2dyb3VuZF9jb250cmFjdCI6IGJhY2tncm91bmRfY29udHJhY3QsCiAgICB9CiAgICB0YXJnZXQgPSBST09UIC8gIkJVSUxEX1BST1ZFTkFOQ0UuanNvbiIKICAgIHRhcmdldC53cml0ZV90ZXh0KAogICAgICAgIGpzb24uZHVtcHMocGF5bG9hZCwgZW5zdXJlX2FzY2lpPUZhbHNlLCBpbmRlbnQ9Miwgc29ydF9rZXlzPVRydWUpICsgIlxuIiwKICAgICAgICBlbmNvZGluZz0idXRmLTgiLAogICAgKQogICAgcHJpbnQoZiJXcm90ZSB7dGFyZ2V0Lm5hbWV9IGZvciBIRVJGWS1UUyB7dmVyc2lvbn0iKQogICAgcmV0dXJuIDAKCgppZiBfX25hbWVfXyA9PSAiX19tYWluX18iOgogICAgcmFpc2UgU3lzdGVtRXhpdChtYWluKCkpCg==",
    "print_preview_exit_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQpzb3VyY2UgPSAoUk9PVCAvICJ1aS9wcmludGluZy5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQoKcmVxdWlyZWQgPSB7CiAgICAiY3VzdG9tIHByZXZpZXcgZGlhbG9nIjogImNsYXNzIFVzYWdlUHJpbnRQcmV2aWV3RGlhbG9nKFFQcmludFByZXZpZXdEaWFsb2cpOiIgaW4gc291cmNlLAogICAgImVzY2FwZSByZWplY3RzIHByZXZpZXciOiAoCiAgICAgICAgImV2ZW50LmtleSgpID09IFF0LktleV9Fc2NhcGUiIGluIHNvdXJjZSBhbmQgInNlbGYucmVqZWN0KCkiIGluIHNvdXJjZQogICAgKSwKICAgICJleHBsaWNpdCBjbG9zZSBidXR0b24iOiAnY2xvc2VfYnV0dG9uLnNldE9iamVjdE5hbWUoIlVzYWdlUHJpbnRQcmV2aWV3Q2xvc2VCdXR0b24iKScgaW4gc291cmNlLAogICAgImNsb3NlIGJ1dHRvbiB0ZXh0IjogJ2Nsb3NlX2J1dHRvbi5zZXRUZXh0KF8oIkNsb3NlIFByZXZpZXciKSknIGluIHNvdXJjZSwKICAgICJjbG9zZSBkb2VzIG5vdCBwcmludCI6ICJjbG9zZV9idXR0b24uY2xpY2tlZC5jb25uZWN0KHByZXZpZXcucmVqZWN0KSIgaW4gc291cmNlLAogICAgInRpdGxlIGNsb3NlIGVuYWJsZWQiOiAicHJldmlldy5zZXRXaW5kb3dGbGFnKFF0LldpbmRvd0Nsb3NlQnV0dG9uSGludCwgVHJ1ZSkiIGluIHNvdXJjZSwKICAgICJzeXN0ZW0gbWVudSBlbmFibGVkIjogInByZXZpZXcuc2V0V2luZG93RmxhZyhRdC5XaW5kb3dTeXN0ZW1NZW51SGludCwgVHJ1ZSkiIGluIHNvdXJjZSwKICAgICJwcmV2aWV3IHVzZXMgc2FmZSBzdWJjbGFzcyI6ICJwcmV2aWV3ID0gVXNhZ2VQcmludFByZXZpZXdEaWFsb2cocHJpbnRlciwgcGFyZW50KSIgaW4gc291cmNlLAp9Cgpmb3JiaWRkZW4gPSB7CiAgICAiY2xvc2Ugd2lyZWQgdG8gYWNjZXB0IjogImNsb3NlX2J1dHRvbi5jbGlja2VkLmNvbm5lY3QocHJldmlldy5hY2NlcHQpIiBpbiBzb3VyY2UsCiAgICAiY2xvc2Ugd2lyZWQgdG8gcHJpbnQiOiAiY2xvc2VfYnV0dG9uLmNsaWNrZWQuY29ubmVjdChwcmV2aWV3LnByaW50IiBpbiBzb3VyY2UsCiAgICAicmF3IHByZXZpZXcgaW5zdGFudGlhdGlvbiI6ICJwcmV2aWV3ID0gUVByaW50UHJldmlld0RpYWxvZyhwcmludGVyLCBwYXJlbnQpIiBpbiBzb3VyY2UsCn0KCmVycm9ycyA9IFtuYW1lIGZvciBuYW1lLCBvayBpbiByZXF1aXJlZC5pdGVtcygpIGlmIG5vdCBva10KZXJyb3JzICs9IFtuYW1lIGZvciBuYW1lLCBwcmVzZW50IGluIGZvcmJpZGRlbi5pdGVtcygpIGlmIHByZXNlbnRdCgpwcmludCgiUFJJTlRfUFJFVklFV19FWElUX0dBVEU9IiArICgiUEFTUyIgaWYgbm90IGVycm9ycyBlbHNlICJGQUlMIikpCmZvciBlcnJvciBpbiBlcnJvcnM6CiAgICBwcmludCgiIC0iLCBlcnJvcikKc3lzLmV4aXQoMCBpZiBub3QgZXJyb3JzIGVsc2UgMSkK",
    "release_source_audit.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQoKRk9SQklEREVOX0RJUl9OQU1FUyA9IHsKICAgICIudnNjb2RlIiwKICAgICIuaWRlYSIsCiAgICAiLmNhY2hlIiwKICAgICIudG94IiwKICAgICIubm94IiwKICAgICIudmVudiIsCiAgICAidmVudiIsCiAgICAiX19weWNhY2hlX18iLAogICAgIi5weXRlc3RfY2FjaGUiLAogICAgIi5teXB5X2NhY2hlIiwKICAgICIucnVmZl9jYWNoZSIsCn0KRk9SQklEREVOX0ZJTEVfTkFNRVMgPSB7CiAgICAiLkRTX1N0b3JlIiwKICAgICJUaHVtYnMuZGIiLAogICAgImRlc2t0b3AuaW5pIiwKICAgICIuY292ZXJhZ2UiLAp9CkZPUkJJRERFTl9TVUZGSVhFUyA9IHsKICAgICIucHljIiwKICAgICIucHlvIiwKICAgICIuYmFrIiwKICAgICIub2xkIiwKICAgICIub3JpZyIsCiAgICAiLnJlaiIsCiAgICAiLnRtcCIsCiAgICAiLnRlbXAiLAogICAgIi5sb2ciLAogICAgIi5zd3AiLAogICAgIi5zd28iLAogICAgIi56aXAiLAogICAgIi43eiIsCiAgICAiLnJhciIsCn0KVFJBTlNJRU5UX1RPUF9MRVZFTCA9IHsKICAgICJidWlsZCIsCiAgICAiYnVpbGQtYWdlbnQiLAogICAgImRpc3QiLAogICAgImRpc3QtYWdlbnQiLAogICAgInJlbGVhc2UiLAp9ClJFUVVJUkVEX0lOU1RBTExFUl9GSUxFUyA9ICgKICAgICJvcHMvcGFja2FnaW5nL0hFUkZZLVRTLmlzcyIsCiAgICAib3BzL3BhY2thZ2luZy9URVJNUy1BTkQtQ09ORElUSU9OUy50eHQiLAogICAgIm9wcy9wYWNrYWdpbmcvd2l6YXJkLWxhcmdlLmJtcCIsCiAgICAib3BzL3BhY2thZ2luZy93aXphcmQtc21hbGwuYm1wIiwKICAgICJyZXNvdXJjZXMvaW1hZ2VzL2xvZ28ucG5nIiwKICAgICJyZXNvdXJjZXMvaW1hZ2VzL2FwcF9pY29uLmljbyIsCikKCmVycm9yczogbGlzdFtzdHJdID0gW10KCmZvciBuYW1lIGluIFRSQU5TSUVOVF9UT1BfTEVWRUw6CiAgICBwYXRoID0gUk9PVCAvIG5hbWUKICAgIGlmIHBhdGguZXhpc3RzKCk6CiAgICAgICAgZXJyb3JzLmFwcGVuZChmIlRyYW5zaWVudCBidWlsZCBvdXRwdXQgaXMgcHJlc2VudDoge25hbWV9IikKCmZvciBwYXRoIGluIFJPT1Qucmdsb2IoIioiKToKICAgIHJlbF9wYXJ0cyA9IHBhdGgucmVsYXRpdmVfdG8oUk9PVCkucGFydHMKICAgIGlmIHJlbF9wYXJ0cyBhbmQgcmVsX3BhcnRzWzBdID09ICJvdXRwdXRzIjoKICAgICAgICBjb250aW51ZQogICAgaWYgYW55KHBhcnQgPT0gIi52ZW52LWJ1aWxkIiBmb3IgcGFydCBpbiBwYXRoLnBhcnRzKToKICAgICAgICBjb250aW51ZQogICAgaWYgcGF0aC5pc19kaXIoKSBhbmQgcGF0aC5uYW1lIGluIEZPUkJJRERFTl9ESVJfTkFNRVM6CiAgICAgICAgZXJyb3JzLmFwcGVuZChmIkZvcmJpZGRlbiBzb3VyY2UgY2x1dHRlciBkaXJlY3Rvcnk6IHtwYXRoLnJlbGF0aXZlX3RvKFJPT1QpfSIpCiAgICBlbGlmIHBhdGguaXNfZmlsZSgpOgogICAgICAgIGlmIHBhdGgubmFtZSBpbiBGT1JCSURERU5fRklMRV9OQU1FUzoKICAgICAgICAgICAgZXJyb3JzLmFwcGVuZChmIkZvcmJpZGRlbiBzb3VyY2UgY2x1dHRlciBmaWxlOiB7cGF0aC5yZWxhdGl2ZV90byhST09UKX0iKQogICAgICAgIGlmIHBhdGguc3VmZml4Lmxvd2VyKCkgaW4gRk9SQklEREVOX1NVRkZJWEVTOgogICAgICAgICAgICBlcnJvcnMuYXBwZW5kKGYiRm9yYmlkZGVuIGdlbmVyYXRlZC90ZW1wIGZpbGU6IHtwYXRoLnJlbGF0aXZlX3RvKFJPT1QpfSIpCiAgICAgICAgaWYgcGF0aC5zdWZmaXgubG93ZXIoKSA9PSAiLnB5IiBhbmQgcGF0aC5yZWFkX2J5dGVzKCkuc3RhcnRzd2l0aChiIlx4ZWZceGJiXHhiZiIpOgogICAgICAgICAgICBlcnJvcnMuYXBwZW5kKGYiVVRGLTggQk9NIGZvdW5kIGluIFB5dGhvbiBzb3VyY2U6IHtwYXRoLnJlbGF0aXZlX3RvKFJPT1QpfSIpCgpmb3IgcmVsIGluIFJFUVVJUkVEX0lOU1RBTExFUl9GSUxFUzoKICAgIGlmIG5vdCAoUk9PVCAvIHJlbCkuaXNfZmlsZSgpOgogICAgICAgIGVycm9ycy5hcHBlbmQoZiJSZXF1aXJlZCBpbnN0YWxsZXIgYXNzZXQgaXMgbWlzc2luZzoge3JlbH0iKQoKcmVxdWlyZW1lbnRzID0gKFJPT1QgLyAicmVxdWlyZW1lbnRzLnR4dCIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQpmb3Igb2Jzb2xldGUgaW4gKCJ3aW4xMHRvYXN0IiwgInBrZ19yZXNvdXJjZXMiLCAic2V0dXB0b29sczw4MSIpOgogICAgaWYgb2Jzb2xldGUgaW4gcmVxdWlyZW1lbnRzOgogICAgICAgIGVycm9ycy5hcHBlbmQoZiJPYnNvbGV0ZSBydW50aW1lIGRlcGVuZGVuY3kgcmVtYWlucyBpbiByZXF1aXJlbWVudHMudHh0OiB7b2Jzb2xldGV9IikKCnNwZWNfc291cmNlID0gKFJPT1QgLyAib3BzL3BhY2thZ2luZy9IRVJGWS1UUy5zcGVjIikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCmZvciBvYnNvbGV0ZSBpbiAoIndpbjEwdG9hc3QiLCAicGtnX3Jlc291cmNlcyIpOgogICAgaWYgb2Jzb2xldGUgaW4gc3BlY19zb3VyY2U6CiAgICAgICAgZXJyb3JzLmFwcGVuZCgKICAgICAgICAgICAgZiJPYnNvbGV0ZSBoaWRkZW4gaW1wb3J0IHJlbWFpbnMgaW4gSEVSRlktVFMuc3BlYzoge29ic29sZXRlfSIKICAgICAgICApCgojIFJ1bnRpbWUgc291cmNlIG11c3Qgbm90IGtlZXAgY29tcGF0aWJpbGl0eSBjb2RlIGZvciBkZXBlbmRlbmNpZXMgdGhhdCBhcmUgbm8KIyBsb25nZXIgc2hpcHBlZC4gVGVzdHMvdG9vbHMgbWF5IG1lbnRpb24gYW4gb2xkIGRlcGVuZGVuY3kgb25seSB0byBndWFyZAojIGFnYWluc3QgaXRzIHJlaW50cm9kdWN0aW9uLgpydW50aW1lX3Jvb3RzID0gW1JPT1QgLyBuYW1lIGZvciBuYW1lIGluICgiY29yZSIsICJzZXJ2aWNlcyIsICJpbmZyYSIsICJ1aSIpXQpmb3IgcnVudGltZV9yb290IGluIHJ1bnRpbWVfcm9vdHM6CiAgICBmb3IgcGF0aCBpbiBydW50aW1lX3Jvb3Qucmdsb2IoIioucHkiKToKICAgICAgICB0ZXh0ID0gcGF0aC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiwgZXJyb3JzPSJyZXBsYWNlIikKICAgICAgICBmb3Igb2Jzb2xldGUgaW4gKCJ3aW4xMHRvYXN0IiwgInBrZ19yZXNvdXJjZXMiKToKICAgICAgICAgICAgaWYgb2Jzb2xldGUgaW4gdGV4dDoKICAgICAgICAgICAgICAgIGVycm9ycy5hcHBlbmQoCiAgICAgICAgICAgICAgICAgICAgZiJPYnNvbGV0ZSBub3RpZmljYXRpb24gYmFja2VuZCByZXNpZHVlIGluIHJ1bnRpbWUgc291cmNlOiAiCiAgICAgICAgICAgICAgICAgICAgZiJ7cGF0aC5yZWxhdGl2ZV90byhST09UKX0gKHtvYnNvbGV0ZX0pIgogICAgICAgICAgICAgICAgKQoKaW5zdGFsbGVyID0gKFJPT1QgLyAib3BzL3BhY2thZ2luZy9IRVJGWS1UUy5pc3MiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04LXNpZyIpCmZvciByZXF1aXJlZF90b2tlbiBpbiAoCiAgICAiTGljZW5zZUZpbGU9VEVSTVMtQU5ELUNPTkRJVElPTlMudHh0IiwKICAgICJXaXphcmRJbWFnZUZpbGU9d2l6YXJkLWxhcmdlLmJtcCIsCiAgICAiV2l6YXJkU21hbGxJbWFnZUZpbGU9d2l6YXJkLXNtYWxsLmJtcCIsCiAgICAiRGlzYWJsZVdlbGNvbWVQYWdlPXllcyIsCiAgICAiRGlzYWJsZVJlYWR5UGFnZT15ZXMiLAogICAgImVuYWJsZV90cmF5X2JhY2tncm91bmQ9VHJ1ZSIsCiAgICAiQ3JlYXRlSW5wdXRPcHRpb25QYWdlIiwKICAgICJDcmVhdGVJbnB1dFF1ZXJ5UGFnZSIsCiAgICAiJ21vbml0b3JpbmdfZW5hYmxlZD0nICsgQm9vbFRleHQoTW9uaXRvcmluZ1BhZ2UuVmFsdWVzWzBdKSIsCiAgICAiJ2V4cGlyeV9zb29uX3RocmVzaG9sZF9kYXlzPScgKyBUcmltKFRocmVzaG9sZFBhZ2UuVmFsdWVzWzBdKSIsCiAgICAiJ2NoZWNrX3VwZGF0ZXNfb25fc3RhcnR1cD0nICsgQm9vbFRleHQoU3RhcnR1cFBhZ2UuVmFsdWVzWzFdKSIsCiAgICAiV3JpdGVJbnN0YWxsZXJEZWZhdWx0czsiLAopOgogICAgaWYgcmVxdWlyZWRfdG9rZW4gbm90IGluIGluc3RhbGxlcjoKICAgICAgICBlcnJvcnMuYXBwZW5kKGYiSW5zdGFsbGVyIGNvbnRyYWN0IHRva2VuIG1pc3Npbmc6IHtyZXF1aXJlZF90b2tlbn0iKQoKIyBCeXRlLWlkZW50aWNhbCBkdXBsaWNhdGUgcGF5bG9hZHMgYXJlIHVzdWFsbHkgcGFja2FnaW5nIG1pc3Rha2VzLiBJZ25vcmUKIyBlbXB0eSBfX2luaXRfXy5weSBwYWNrYWdlIG1hcmtlcnMgYmVjYXVzZSB0aGV5IGFyZSBpbnRlbnRpb25hbC4KaGFzaGVzOiBkaWN0W3N0ciwgbGlzdFtQYXRoXV0gPSB7fQpmb3IgcGF0aCBpbiBST09ULnJnbG9iKCIqIik6CiAgICBpZiBub3QgcGF0aC5pc19maWxlKCkgb3IgIi52ZW52LWJ1aWxkIiBpbiBwYXRoLnBhcnRzOgogICAgICAgIGNvbnRpbnVlCiAgICBkYXRhID0gcGF0aC5yZWFkX2J5dGVzKCkKICAgIGlmIG5vdCBkYXRhIGFuZCBwYXRoLm5hbWUgPT0gIl9faW5pdF9fLnB5IjoKICAgICAgICBjb250aW51ZQogICAgZGlnZXN0ID0gaGFzaGxpYi5zaGEyNTYoZGF0YSkuaGV4ZGlnZXN0KCkKICAgIGhhc2hlcy5zZXRkZWZhdWx0KGRpZ2VzdCwgW10pLmFwcGVuZChwYXRoKQoKZm9yIHBhdGhzIGluIGhhc2hlcy52YWx1ZXMoKToKICAgIGlmIGxlbihwYXRocykgPiAxOgogICAgICAgIHJlbHMgPSBbc3RyKHAucmVsYXRpdmVfdG8oUk9PVCkpIGZvciBwIGluIHBhdGhzXQogICAgICAgIGVycm9ycy5hcHBlbmQoIkJ5dGUtaWRlbnRpY2FsIGR1cGxpY2F0ZSBmaWxlczogIiArICIsICIuam9pbihyZWxzKSkKCnByaW50KCJSRUxFQVNFX1NPVVJDRV9BVURJVD0iICsgKCJQQVNTIiBpZiBub3QgZXJyb3JzIGVsc2UgIkZBSUwiKSkKZm9yIGVycm9yIGluIGVycm9yczoKICAgIHByaW50KCIgLSIsIGVycm9yKQpzeXMuZXhpdCgwIGlmIG5vdCBlcnJvcnMgZWxzZSAxKQo=",
    "responsive_release_gate.py": "ZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmltcG9ydCBhc3QsIHJlLCBzeXMsIHhtbC5ldHJlZS5FbGVtZW50VHJlZSBhcyBFVAoKUk9PVCA9IFBhdGgoX19maWxlX18pLnJlc29sdmUoKS5wYXJlbnRzWzJdClVJID0gUk9PVCAvICJ1aSIKUlVOVElNRV9ST09UUyA9IFtST09UIC8gbmFtZSBmb3IgbmFtZSBpbiAoImNvcmUiLCAic2VydmljZXMiLCAiaW5mcmEiLCAidWkiKV0KZXJyb3JzID0gW10KCmZvciBydW50aW1lX3Jvb3QgaW4gUlVOVElNRV9ST09UUzoKICAgIGZvciBwYXRoIGluIHJ1bnRpbWVfcm9vdC5yZ2xvYigiKi5weSIpOgogICAgICAgIHRyeToKICAgICAgICAgICAgY29tcGlsZShwYXRoLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwgc3RyKHBhdGgpLCAiZXhlYyIpCiAgICAgICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgICAgIGVycm9ycy5hcHBlbmQoZiJQeXRob24gY29tcGlsZSBmYWlsZWQ6IHtwYXRoLnJlbGF0aXZlX3RvKFJPT1QpfToge2V4Y30iKQoKZm9yIHBhdGggaW4gKFJPT1QgLyAicmVzb3VyY2VzIikucmdsb2IoIioudWkiKToKICAgIHRyeToKICAgICAgICBFVC5wYXJzZShwYXRoKQogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgZXJyb3JzLmFwcGVuZChmIkludmFsaWQgVUkgWE1MOiB7cGF0aC5yZWxhdGl2ZV90byhST09UKX06IHtleGN9IikKCmZvciBwYXRoIGluIFVJLnJnbG9iKCIqLnB5Iik6CiAgICB0ZXh0ID0gcGF0aC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiwgZXJyb3JzPSJyZXBsYWNlIikKICAgIHJlbCA9IHBhdGgucmVsYXRpdmVfdG8oUk9PVCkKICAgIGZvciB0b2tlbiBpbiAoInNldEdlb21ldHJ5KCIsICJzZXRGaXhlZFdpZHRoKCIsICJzZXRGaXhlZFNpemUoIik6CiAgICAgICAgaWYgdG9rZW4gaW4gdGV4dDoKICAgICAgICAgICAgZXJyb3JzLmFwcGVuZChmIkZvcmJpZGRlbiBnZW9tZXRyeSBBUEkge3Rva2VufToge3JlbH0iKQogICAgaWYgInBhZ2VSZWN0KCIgaW4gdGV4dDoKICAgICAgICBlcnJvcnMuYXBwZW5kKGYiTGVnYWN5L25vLWFyZyBwcmludGVyIHBhZ2VSZWN0IHVzYWdlOiB7cmVsfSIpCiAgICBmb3IgbGluZV9ubywgbGluZSBpbiBlbnVtZXJhdGUodGV4dC5zcGxpdGxpbmVzKCksIDEpOgogICAgICAgIGlmIHJlLnNlYXJjaChyIlxiKHdpZHRofGhlaWdodClcKFwpXHMqWzw+XT0/XHMqXGR7Myw0fSIsIGxpbmUpOgogICAgICAgICAgICBlcnJvcnMuYXBwZW5kKGYiTG9jYWwgcmVzcG9uc2l2ZSBicmVha3BvaW50OiB7cmVsfTp7bGluZV9ub30iKQoKcmVzcG9uc2l2ZV90aGVtZSA9IChST09UIC8gInVpL3RoZW1lX3Jlc3BvbnNpdmUucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKbWV0cmljc190aGVtZSA9IChST09UIC8gInVpL3RoZW1lX21ldHJpY3MucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKZ2VvbWV0cnlfdGhlbWUgPSAoUk9PVCAvICJ1aS90aGVtZV9nZW9tZXRyeS5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQptYWluID0gKFJPT1QgLyAidWkvbWFpbl93aW5kb3cucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKYWRtaW5pc3RyYXRpb24gPSAoUk9PVCAvICJ1aS9hZG1pbmlzdHJhdGlvbi5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQpub3RpZmljYXRpb25fdmlld3MgPSAoUk9PVCAvICJ1aS9ub3RpZmljYXRpb25fdmlld3MucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKc2V0dGluZ3MgPSAoUk9PVCAvICJ1aS9zZXR0aW5ncy5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQpxc3MgPSAoUk9PVCAvICJyZXNvdXJjZXMvc3R5bGUucXNzIikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCgoKZGVmIGFib3V0X2NhcmRzX3JlZmxvd19wcmVzZW50KCkgLT4gYm9vbDoKICAgIHBhdGggPSBST09UIC8gInVpL2Fib3V0LnB5IgogICAgdHJ5OgogICAgICAgIHRyZWUgPSBhc3QucGFyc2UocGF0aC5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiksIGZpbGVuYW1lPXN0cihwYXRoKSkKICAgIGV4Y2VwdCAoT1NFcnJvciwgU3ludGF4RXJyb3IsIFVuaWNvZGVFcnJvcik6CiAgICAgICAgcmV0dXJuIEZhbHNlCgogICAgcmVzcG9uc2l2ZV9jb2x1bW5zID0gRmFsc2UKICAgIHJlc3BvbnNpdmVfZ3JpZF9jYWxsID0gRmFsc2UKICAgIGZvciBub2RlIGluIGFzdC53YWxrKHRyZWUpOgogICAgICAgIGlmIGlzaW5zdGFuY2Uobm9kZSwgYXN0LkFzc2lnbikgYW5kIGFueSgKICAgICAgICAgICAgaXNpbnN0YW5jZSh0YXJnZXQsIGFzdC5OYW1lKSBhbmQgdGFyZ2V0LmlkID09ICJjb2x1bW5zIiBmb3IgdGFyZ2V0IGluIG5vZGUudGFyZ2V0cwogICAgICAgICk6CiAgICAgICAgICAgIHJlc3BvbnNpdmVfY29sdW1ucyA9IGlzaW5zdGFuY2Uobm9kZS52YWx1ZSwgYXN0LklmRXhwKQogICAgICAgIGlmIG5vdCBpc2luc3RhbmNlKG5vZGUsIGFzdC5DYWxsKSBvciBub3QgaXNpbnN0YW5jZShub2RlLmZ1bmMsIGFzdC5BdHRyaWJ1dGUpOgogICAgICAgICAgICBjb250aW51ZQogICAgICAgIGlmIG5vZGUuZnVuYy5hdHRyICE9ICJhZGRXaWRnZXQiIG9yIGxlbihub2RlLmFyZ3MpIDwgMzoKICAgICAgICAgICAgY29udGludWUKICAgICAgICByb3dfYXJnLCBjb2x1bW5fYXJnID0gbm9kZS5hcmdzWzFdLCBub2RlLmFyZ3NbMl0KICAgICAgICByb3dfcmVmbG93cyA9ICgKICAgICAgICAgICAgaXNpbnN0YW5jZShyb3dfYXJnLCBhc3QuQmluT3ApCiAgICAgICAgICAgIGFuZCBpc2luc3RhbmNlKHJvd19hcmcub3AsIGFzdC5GbG9vckRpdikKICAgICAgICAgICAgYW5kIGlzaW5zdGFuY2Uocm93X2FyZy5yaWdodCwgYXN0Lk5hbWUpCiAgICAgICAgICAgIGFuZCByb3dfYXJnLnJpZ2h0LmlkID09ICJjb2x1bW5zIgogICAgICAgICkKICAgICAgICBjb2x1bW5fcmVmbG93cyA9ICgKICAgICAgICAgICAgaXNpbnN0YW5jZShjb2x1bW5fYXJnLCBhc3QuQmluT3ApCiAgICAgICAgICAgIGFuZCBpc2luc3RhbmNlKGNvbHVtbl9hcmcub3AsIGFzdC5Nb2QpCiAgICAgICAgICAgIGFuZCBpc2luc3RhbmNlKGNvbHVtbl9hcmcucmlnaHQsIGFzdC5OYW1lKQogICAgICAgICAgICBhbmQgY29sdW1uX2FyZy5yaWdodC5pZCA9PSAiY29sdW1ucyIKICAgICAgICApCiAgICAgICAgaWYgcm93X3JlZmxvd3MgYW5kIGNvbHVtbl9yZWZsb3dzOgogICAgICAgICAgICByZXNwb25zaXZlX2dyaWRfY2FsbCA9IFRydWUKICAgIHJldHVybiByZXNwb25zaXZlX2NvbHVtbnMgYW5kIHJlc3BvbnNpdmVfZ3JpZF9jYWxsCgoKcmVxdWlyZWQgPSB7CiAgICAicHJvZmlsZSB1c2VzIGxpdmUgdmlld3BvcnQiOiAidmlld3BvcnRfc2l6ZSh3aWRnZXQpIiBpbiByZXNwb25zaXZlX3RoZW1lLAogICAgIm1haW4gbWluaW11bSByZWFjaGVzIHNtYWxsIGxheW91dCI6ICJhcHBfd2luZG93X21pbl93aWR0aDogaW50ID0gNjQwIiBpbiBtZXRyaWNzX3RoZW1lLAogICAgIm1haW4gbWluaW11bSBoZWlnaHQgaXMgY29tcGFjdC1zYWZlIjogImFwcF93aW5kb3dfbWluX2hlaWdodDogaW50ID0gNDgwIiBpbiBtZXRyaWNzX3RoZW1lLAogICAgIndpbmRvdyBtaW5pbXVtIGNsYW1wcyB0byBtb25pdG9yIjogIm1pbihVSV9NRVRSSUNTLmFwcF93aW5kb3dfbWluX3dpZHRoLCBzYWZlX3dpZHRoKSIgaW4gZ2VvbWV0cnlfdGhlbWUsCiAgICAibWFpbiByZXNpemUgcmVhcHBsaWVzIHNoZWxsIjogImFwcGx5X3Jlc3BvbnNpdmVfc2hlbGxfbWV0cmljcyhzZWxmKSIgaW4gbWFpbiwKICAgICJhZG1pbmlzdHJhdGlvbiBoYXMgY29tcGFjdCByb3V0ZSBzZWxlY3RvciI6ICJBZG1pbldvcmtzcGFjZVJvdXRlU2VsZWN0b3IiIGluIGFkbWluaXN0cmF0aW9uLAogICAgImFkbWluaXN0cmF0aW9uIG93bnMgcmVzcG9uc2l2ZSBjb250ZW50IGxheW91dCI6ICdzZWxmLmNvbnRlbnRfbGF5b3V0OiBRVkJveExheW91dCA9IGNvbnRyb2xzWyJhZG1pbl9jb250ZW50X2xheW91dCJdJyBpbiBhZG1pbmlzdHJhdGlvbiwKICAgICJhZG1pbmlzdHJhdGlvbiBzZWxlY3RvciBvd25zIGNvbXBhY3QgcmVhY2hhYmlsaXR5IjogInNlbGYuY29weV9ob3N0LnNldFZpc2libGUobm90IHNlbGYuX2NvbXBhY3QpIiBpbiBhZG1pbmlzdHJhdGlvbiwKICAgICJzZXR0aW5ncyByZWxlYXNlIGZpZWxkIGNhcHMiOiAiZGVmIF9hcHBseV9yZXNwb25zaXZlX2ZpZWxkX3dpZHRocyIgaW4gc2V0dGluZ3MsCiAgICAibm90aWZpY2F0aW9uIHBvcHVwIGNsYW1wcyB0byBtb25pdG9yIjogInNlbGYucGFuZWwuYXBwbHlfYXZhaWxhYmxlX3dpZHRoIiBpbiBub3RpZmljYXRpb25fdmlld3MsCiAgICAiY2F0YWxvZyB0b29sYmFyIHJlZmxvd3MiOiAic2VsZi50b29sYmFyX2dyaWQuYWRkV2lkZ2V0KHNlbGYuc2VhcmNoLCAwLCAwLCAxLCAyKSIgaW4gKFJPT1QgLyAidWkvY2F0YWxvZ3MucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiksCiAgICAidHJhY2tpbmcgdGFibGUgaGVhZGVyIHJlZmxvd3MiOiAic2VsZi5fbGF5b3V0X3RyYWNraW5nX3RhYmxlX2hlYWRlcihtb2RlKSIgaW4gKFJPT1QgLyAidWkvdHJhY2tpbmdfcmVzcG9uc2l2ZS5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgICJzZXR0aW5ncyBuYXZpZ2F0aW9uIGJlY29tZXMgdG9wIHN0cmlwIjogInNlbGYubmF2aWdhdGlvbi5zZXRGbG93KFFMaXN0Vmlldy5MZWZ0VG9SaWdodCkiIGluIChST09UIC8gInVpL3NldHRpbmdzLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgInNldHRpbmdzIGZvb3RlciByZWZsb3dzIjogInNlbGYuZm9vdGVyX2dyaWQuYWRkV2lkZ2V0KHNlbGYubm90aWNlLCAwLCAwLCAxLCAyKSIgaW4gKFJPT1QgLyAidWkvc2V0dGluZ3MucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IiksCiAgICAidXBkYXRlIGFjdGlvbnMgcmVmbG93IjogImRlZiBfYXBwbHlfcmVzcG9uc2l2ZV9hY3Rpb25zKHNlbGYpIiBpbiAoUk9PVCAvICJ1aS9hcHBfdXBkYXRlcy5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgICJub3RpZmljYXRpb24gcm93cyByZWNvbXB1dGUgYXQgY2xhbXBlZCB3aWR0aCI6ICJpZiBjaGFuZ2VkIGFuZCBzZWxmLl92aWV3X2l0ZW1zOiIgaW4gbm90aWZpY2F0aW9uX3ZpZXdzLAogICAgImFib3V0IGNhcmRzIHJlZmxvdyI6IGFib3V0X2NhcmRzX3JlZmxvd19wcmVzZW50KCksCn0KZm9yIG5hbWUsIG9rIGluIHJlcXVpcmVkLml0ZW1zKCk6CiAgICBpZiBub3Qgb2s6CiAgICAgICAgZXJyb3JzLmFwcGVuZChuYW1lKQoKZm9yIGtleSBpbiAoImFwcGxpY2F0aW9uIiwgImV4cGlyeSIsICJub3RpZmljYXRpb25zIiwgInNvdW5kcyIsICJhY2NvdW50IiwgInN0YXR1cyIpOgogICAgcGF0aCA9IFJPT1QgLyAicmVzb3VyY2VzL3VpIiAvIGYic2V0dGluZ3Nfe2tleX0udWkiCiAgICB1aSA9IHBhdGgucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCiAgICBpZiAnbmFtZT0ibWF4aW11bVNpemUiJyBpbiB1aSBvciAiPHdpZHRoPjY4MDwvd2lkdGg+IiBpbiB1aToKICAgICAgICBlcnJvcnMuYXBwZW5kKGYiTGVnYWN5IHNldHRpbmdzIHdpZHRoIGNhcDoge3BhdGgucmVsYXRpdmVfdG8oUk9PVCl9IikKCmZvcmJpZGRlbl9xc3MgPSB7CiAgICAiZml4ZWQgVXNhZ2UgY29tcGFjdCBwYW5lbCBoZWlnaHQiOiAnUUZyYW1lI1VzYWdlQ29udHJvbFBhbmVsW3Rvb2xiYXJNb2RlPSJjb21wYWN0Il0nLAogICAgImZpeGVkIE1ldHJpY1RpbGUgaGVpZ2h0IjogIlFGcmFtZSNNZXRyaWNUaWxlIHtcbiAgICBtaW4taGVpZ2h0OiA2NnB4OyIsCiAgICAiZml4ZWQgQWRtaW5pc3RyYXRpb24gcm9sZSB3aWR0aCI6ICJRQ29tYm9Cb3gjQWRtaW5QZXJtaXNzaW9uUm9sZSB7XG4gICAgbWluLXdpZHRoOiAyMTBweDsiLAogICAgImZpeGVkIHNpZGViYXIgbWF4aW11bSB3aWR0aCI6ICJRRnJhbWUjU2lkZWJhciB7XG4gICAgbWF4LXdpZHRoOiAyMjBweDsiLAp9CmZvciBuYW1lLCB0b2tlbiBpbiBmb3JiaWRkZW5fcXNzLml0ZW1zKCk6CiAgICBpZiB0b2tlbiBpbiBxc3M6CiAgICAgICAgZXJyb3JzLmFwcGVuZChuYW1lKQoKcHJpbnQoIlJFU1BPTlNJVkVfUkVMRUFTRV9HQVRFPSIgKyAoIlBBU1MiIGlmIG5vdCBlcnJvcnMgZWxzZSAiRkFJTCIpKQpmb3IgZXJyb3IgaW4gZXJyb3JzOgogICAgcHJpbnQoIiAtIiwgZXJyb3IpCnN5cy5leGl0KDAgaWYgbm90IGVycm9ycyBlbHNlIDEpCg==",
    "runtime_regression_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQpzaW5nbGUgPSAoUk9PVCAvICJ1aS9ydW50aW1lLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCmRpYWxvZ3MgPSAoUk9PVCAvICJ1aS9tYWluX3dpbmRvd19hY3Rpb25zLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCnF0X2Jvb3RzdHJhcCA9IChST09UIC8gInVpL2Rlc2lnbmVyLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCgpyZXF1aXJlZCA9IHsKICAgICJzaW5nbGUtaW5zdGFuY2Ugc3RvcCBldmVudCBjbGVhcmVkIGJlZm9yZSBhY3F1aXJlIjogInNlbGYuX3N0b3AuY2xlYXIoKSIgaW4gc2luZ2xlLAogICAgInNpbmdsZS1pbnN0YW5jZSBhY2NlcHQgbG9vcCBpcyB3b2tlbiBiZWZvcmUgY2xvc2UiOgogICAgICAgICJzb2NrZXQuY3JlYXRlX2Nvbm5lY3Rpb24oIiBpbiBzaW5nbGUgYW5kICJ0aHJlYWQuam9pbigxLjApIiBpbiBzaW5nbGUsCiAgICAic2luZ2xlLWluc3RhbmNlIHN0b3AgY2hlY2tlZCBhZnRlciBhY2NlcHQiOgogICAgICAgICJpZiBzZWxmLl9zdG9wLmlzX3NldCgpOiIgaW4gc2luZ2xlLAogICAgImRpYWxvZyBhY3RpdmF0aW9uIHVzZXMgUVdpZGdldCBBUEkiOgogICAgICAgICJ3aW5kb3cucmFpc2VfKCkiIGluIGRpYWxvZ3MgYW5kICJ3aW5kb3cuYWN0aXZhdGVXaW5kb3coKSIgaW4gZGlhbG9ncywKICAgICJEZXNpZ25lciBVSSB1c2VzIFFVaUxvYWRlciI6CiAgICAgICAgIlF0VWlUb29scy5RVWlMb2FkZXIiIGluIHF0X2Jvb3RzdHJhcCwKfQoKZm9yYmlkZGVuID0gewogICAgImxlZ2FjeSBkaWFsb2cgYnJpbmdfdG9fZnJvbnQgY2FsbCI6ICJ3aW5kb3cuYnJpbmdfdG9fZnJvbnQoKSIgaW4gZGlhbG9ncywKICAgICJsZWdhY3kgZ2VuZXJhdGVkIGxvYWRVaVR5cGUgcGF0aCI6ICJRdFVpVG9vbHMubG9hZFVpVHlwZSgiIGluIHF0X2Jvb3RzdHJhcCwKICAgICJsaXN0ZW5lciBzaHV0ZG93biByYWNlIjogInNvY2suc2h1dGRvd24oc29ja2V0LlNIVVRfUkRXUikiIGluIHNpbmdsZSwKfQoKZXJyb3JzID0gW25hbWUgZm9yIG5hbWUsIG9rIGluIHJlcXVpcmVkLml0ZW1zKCkgaWYgbm90IG9rXQplcnJvcnMgKz0gW25hbWUgZm9yIG5hbWUsIHByZXNlbnQgaW4gZm9yYmlkZGVuLml0ZW1zKCkgaWYgcHJlc2VudF0KCnByaW50KCJSVU5USU1FX1JFR1JFU1NJT05fR0FURT0iICsgKCJQQVNTIiBpZiBub3QgZXJyb3JzIGVsc2UgIkZBSUwiKSkKZm9yIGVycm9yIGluIGVycm9yczoKICAgIHByaW50KCIgLSIsIGVycm9yKQpzeXMuZXhpdCgwIGlmIG5vdCBlcnJvcnMgZWxzZSAxKQo=",
    "shell_ownership_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQoKbGF5b3V0X3NvdXJjZSA9IChST09UIC8gInVpL21haW5fd2luZG93X3NoZWxsLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCndpbmRvd19zb3VyY2UgPSAoUk9PVCAvICJ1aS90aGVtZV9zaGVsbC5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQoKcmVxdWlyZWQgPSB7CiAgICAic2lkZWJhciBsYXlvdXQgcmVzb2x2ZWQgZnJvbSBob3N0IjogInNpZGViYXJfbGF5b3V0ID0gc2lkZWJhcl9ob3N0LmxheW91dCgpIiBpbiBsYXlvdXRfc291cmNlLAogICAgInRvcCBiYXIgbGF5b3V0IHJlc29sdmVkIGZyb20gaG9zdCI6ICJ0b3BfYmFyX2xheW91dCA9IHRvcF9iYXJfaG9zdC5sYXlvdXQoKSIgaW4gbGF5b3V0X3NvdXJjZSwKICAgICJjb250ZW50IGxheW91dCByZXNvbHZlZCBmcm9tIGhvc3QiOiAiY29udGVudF9sYXlvdXQgPSBjb250ZW50X2hvc3QubGF5b3V0KCkiIGluIGxheW91dF9zb3VyY2UsCiAgICAic3RhYmxlIHNoZWxsIHJvb3QgcmV1c2VkIjogJ2NlbnRyYWwgPSBnZXRhdHRyKHdpbmRvdywgIl9zdGFibGVfc2hlbGxfcm9vdCIsIE5vbmUpJyBpbiB3aW5kb3dfc291cmNlLAogICAgImZhbGxiYWNrIGFwcF9yb290IGxvb2t1cCByZXRhaW5lZCI6ICd3aW5kb3cuZmluZENoaWxkKFFXaWRnZXQsICJhcHBfcm9vdCIpJyBpbiB3aW5kb3dfc291cmNlLAp9Cgpmb3JiaWRkZW4gPSB7CiAgICAibWFpbiB3aW5kb3cgc2lkZWJhciBsYXlvdXQgbG9va3VwIjogJ3NlbGYuZmluZENoaWxkKFFWQm94TGF5b3V0LCAic2hlbGxfc2lkZWJhcl9sYXlvdXQiKScgaW4gbGF5b3V0X3NvdXJjZSwKICAgICJtYWluIHdpbmRvdyB0b3BiYXIgbGF5b3V0IGxvb2t1cCI6ICdzZWxmLmZpbmRDaGlsZChRVkJveExheW91dCwgInNoZWxsX3RvcF9iYXJfbGF5b3V0IiknIGluIGxheW91dF9zb3VyY2UsCiAgICAibWFpbiB3aW5kb3cgY29udGVudCBsYXlvdXQgbG9va3VwIjogJ3NlbGYuZmluZENoaWxkKFFWQm94TGF5b3V0LCAiY29udGVudF9zdGFja19sYXlvdXQiKScgaW4gbGF5b3V0X3NvdXJjZSwKfQoKZXJyb3JzID0gW25hbWUgZm9yIG5hbWUsIG9rIGluIHJlcXVpcmVkLml0ZW1zKCkgaWYgbm90IG9rXQplcnJvcnMgKz0gW25hbWUgZm9yIG5hbWUsIHByZXNlbnQgaW4gZm9yYmlkZGVuLml0ZW1zKCkgaWYgcHJlc2VudF0KCnByaW50KCJTSEVMTF9PV05FUlNISVBfR0FURT0iICsgKCJQQVNTIiBpZiBub3QgZXJyb3JzIGVsc2UgIkZBSUwiKSkKZm9yIGVycm9yIGluIGVycm9yczoKICAgIHByaW50KCIgLSIsIGVycm9yKQpzeXMuZXhpdCgwIGlmIG5vdCBlcnJvcnMgZWxzZSAxKQo=",
    "sortable_tables_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQoKZmlsZXMgPSB7CiAgICAibGF5b3V0IjogKFJPT1QgLyAidWkvdGFibGVzLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgInByb2ZpbGVzIjogKFJPT1QgLyAidWkvdGhlbWVfcmVzcG9uc2l2ZS5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgICJiYXNlIjogKFJPT1QgLyAidWkvdGFibGVzLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgInRyYWNraW5nIjogKFJPT1QgLyAidWkvdHJhY2tpbmdfcmVzcG9uc2l2ZS5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgICJ0cmFja2luZ19tb2RlbCI6IChST09UIC8gInVpL3RhYmxlcy5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgICJ1c2FnZSI6IChST09UIC8gInVpL3VzYWdlLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgInVzYWdlX21vZGVsIjogKFJPT1QgLyAidWkvdGFibGVzLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgImNhdGFsb2ciOiAoUk9PVCAvICJ1aS9jYXRhbG9ncy5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgICJhZG1pbiI6IChST09UIC8gInVpL2FkbWluaXN0cmF0aW9uLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgInN0cnVjdHVyZSI6IChST09UIC8gInVpL2FkbWluaXN0cmF0aW9uLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAp9CgpyZXF1aXJlZCA9IHsKICAgICJzaGFyZWQgc29ydGFibGUgaGVscGVyIjogImRlZiBjb25maWd1cmVfc29ydGFibGVfdGFibGUoIiBpbiBmaWxlc1sibGF5b3V0Il0sCiAgICAic29ydCBpbmRpY2F0b3IgZW5hYmxlZCI6ICJzZXRTb3J0SW5kaWNhdG9yU2hvd24oZW5hYmxlZCkiIGluIGZpbGVzWyJsYXlvdXQiXSwKICAgICJiYXNlIG1vZGVsIHR5cGVkIHNvcnQiOiAiZGVmIHNvcnQoc2VsZiwgY29sdW1uOiBpbnQiIGluIGZpbGVzWyJiYXNlIl0sCiAgICAidHJhY2tpbmcgc29ydGFibGUiOiAiY29uZmlndXJlX3NvcnRhYmxlX3RhYmxlKHNlbGYudGFibGVfdmlldywgZW5hYmxlZD1UcnVlKSIgaW4gZmlsZXNbInRyYWNraW5nIl0sCiAgICAidHJhY2tpbmcgdHlwZWQgZGF0ZXMiOiAicHJvZHVjdGlvbl9kYXRlIiBpbiBmaWxlc1sidHJhY2tpbmdfbW9kZWwiXSBhbmQgImV4cGlyeV9kYXRlIiBpbiBmaWxlc1sidHJhY2tpbmdfbW9kZWwiXSwKICAgICJ1c2FnZSBzb3J0YWJsZSI6ICJjb25maWd1cmVfc29ydGFibGVfdGFibGUoc2VsZi50YWJsZSwgZW5hYmxlZD1UcnVlKSIgaW4gZmlsZXNbInVzYWdlIl0sCiAgICAidXNhZ2UgdHlwZWQgcHJveHkiOiAiZGVmIGxlc3NUaGFuKCIgaW4gZmlsZXNbInVzYWdlX21vZGVsIl0gYW5kICJzb3J0YWJsZV92YWx1ZV9rZXkiIGluIGZpbGVzWyJ1c2FnZV9tb2RlbCJdLAogICAgImNhdGFsb2cgc29ydGFibGUiOiAiY29uZmlndXJlX3NvcnRhYmxlX3RhYmxlKHNlbGYudGFibGUsIGVuYWJsZWQ9VHJ1ZSkiIGluIGZpbGVzWyJjYXRhbG9nIl0sCiAgICAiYWRtaW4gc29ydGFibGUiOiAiY29uZmlndXJlX3NvcnRhYmxlX3RhYmxlKHNlbGYsIGVuYWJsZWQ9VHJ1ZSkiIGluIGZpbGVzWyJhZG1pbiJdLAogICAgInN0cnVjdHVyZSBzb3J0YWJsZSI6ICJjb25maWd1cmVfc29ydGFibGVfdGFibGUodGFibGUsIGVuYWJsZWQ9VHJ1ZSkiIGluIGZpbGVzWyJzdHJ1Y3R1cmUiXSwKICAgICJkZW5zaXR5IGtlZXBzIGNsaWNrYWJsZSBoZWFkZXJzIjogImhlYWRlci5zZXRTZWN0aW9uc0NsaWNrYWJsZShzb3J0YWJsZSkiIGluIGZpbGVzWyJwcm9maWxlcyJdLAp9Cgpmb3JiaWRkZW4gPSB7CiAgICAidHJhY2tpbmcgc29ydGluZyBkaXNhYmxlZCI6ICJzZWxmLnRhYmxlX3ZpZXcuc2V0U29ydGluZ0VuYWJsZWQoRmFsc2UpIiBpbiBmaWxlc1sidHJhY2tpbmciXSwKICAgICJhZG1pbiBoZWFkZXIgZm9yY2VkIG5vbi1jbGlja2FibGUiOiAiaG9yaXpvbnRhbC5zZXRTZWN0aW9uc0NsaWNrYWJsZShGYWxzZSkiIGluIGZpbGVzWyJhZG1pbiJdLAogICAgInN0cnVjdHVyZSBoZWFkZXIgZm9yY2VkIG5vbi1jbGlja2FibGUiOiAiaGVhZGVyLnNldFNlY3Rpb25zQ2xpY2thYmxlKEZhbHNlKSIgaW4gZmlsZXNbInN0cnVjdHVyZSJdLAp9CgplcnJvcnMgPSBbbmFtZSBmb3IgbmFtZSwgb2sgaW4gcmVxdWlyZWQuaXRlbXMoKSBpZiBub3Qgb2tdCmVycm9ycyArPSBbbmFtZSBmb3IgbmFtZSwgcHJlc2VudCBpbiBmb3JiaWRkZW4uaXRlbXMoKSBpZiBwcmVzZW50XQoKcHJpbnQoIlNPUlRBQkxFX1RBQkxFU19HQVRFPSIgKyAoIlBBU1MiIGlmIG5vdCBlcnJvcnMgZWxzZSAiRkFJTCIpKQpmb3IgZXJyb3IgaW4gZXJyb3JzOgogICAgcHJpbnQoIiAtIiwgZXJyb3IpCnN5cy5leGl0KDAgaWYgbm90IGVycm9ycyBlbHNlIDEpCg==",
    "stable_layout_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQpwcm9maWxlcyA9ICJgbiIuam9pbigoCiAgICAoUk9PVCAvICJ1aS90aGVtZV9yZXNwb25zaXZlLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAogICAgKFJPT1QgLyAidWkvdGhlbWVfbWV0cmljcy5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSwKICAgIChST09UIC8gInVpL3RoZW1lX3NoZWxsLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpLAopKQpzaGVsbCA9IChST09UIC8gInVpL21haW5fd2luZG93X3NoZWxsLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCmhvbWUgPSAoUk9PVCAvICJ1aS9ob21lLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCnVzYWdlID0gKFJPT1QgLyAidWkvdXNhZ2UucHkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKYWRtaW5pc3RyYXRpb24gPSAoUk9PVCAvICJ1aS9hZG1pbmlzdHJhdGlvbi5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQpkZXNpZ25lciA9IChST09UIC8gInJlc291cmNlcy91aS9tYWluX3dpbmRvdy51aSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQoKcmVxdWlyZWQgPSB7CiAgICAibGl2ZSB2aWV3cG9ydCBwcm9maWxlIjogInZpZXdwb3J0X3NpemUod2lkZ2V0KSIgaW4gcHJvZmlsZXMsCiAgICAic21hbGwgc2VtYW50aWMgbW9kZSI6ICdyZXR1cm4gInNtYWxsIicgaW4gcHJvZmlsZXMsCiAgICAibmFycm93IHNlbWFudGljIG1vZGUiOiAncmV0dXJuICJuYXJyb3ciJyBpbiBwcm9maWxlcywKICAgICJjb21wYWN0IHNlbWFudGljIG1vZGUiOiAncmV0dXJuICJjb21wYWN0IicgaW4gcHJvZmlsZXMsCiAgICAiZGVza3RvcCBzZW1hbnRpYyBtb2RlIjogJ3JldHVybiAiZGVza3RvcCInIGluIHByb2ZpbGVzLAogICAgIndpZGUgc2VtYW50aWMgbW9kZSI6ICdyZXR1cm4gIndpZGUiJyBpbiBwcm9maWxlcywKICAgICJjYW5vbmljYWwgY29udHJvbCBoZWlnaHQgcmVtYWlucyAzMiI6ICJjb250cm9sX2hlaWdodCA9IDMyIiBpbiBwcm9maWxlcywKICAgICJzdGFibGUgbG9naWNhbCByb3cgbWV0cmljIjogInRhYmxlX3Jvd19oZWlnaHQ6IGludCA9IDI4IiBpbiBwcm9maWxlcywKICAgICJzdGFibGUgbG9naWNhbCBoZWFkZXIgbWV0cmljIjogInRhYmxlX2hlYWRlcl9oZWlnaHQ6IGludCA9IDMyIiBpbiBwcm9maWxlcywKICAgICJzaGVsbCBleHBhbmRzIHRocm91Z2ggRGVzaWduZXIiOiAnPHNpemVwb2xpY3kgaHNpemV0eXBlPSJFeHBhbmRpbmciIHZzaXpldHlwZT0iRXhwYW5kaW5nIj4nIGluIGRlc2lnbmVyLAogICAgInNoZWxsIGhhcyBubyBmb3JjZWQgRGVzaWduZXIgbWluaW11bSI6ICc8cHJvcGVydHkgbmFtZT0ibWluaW11bVNpemUiPicgbm90IGluIGRlc2lnbmVyLAogICAgInNoZWxsIGluc3RhbGxlZCBkaXJlY3RseSI6ICJzZWxmLnNldENlbnRyYWxXaWRnZXQoc2hlbGxfcm9vdCkiIGluIHNoZWxsLAogICAgIndpbmRvdyByZXNpemUgcmVhcHBsaWVzIHJlc3BvbnNpdmUgc2hlbGwiOiAiYXBwbHlfcmVzcG9uc2l2ZV9zaGVsbF9tZXRyaWNzKHNlbGYpIiBpbiBzaGVsbCwKICAgICJzaWRlYmFyIHdpZHRoIGZvbGxvd3MgbGl2ZSBtb2RlIjogIlVJX01FVFJJQ1Muc2lkZWJhcl9yYWlsX3dpZHRoIiBpbiBwcm9maWxlcywKICAgICJob21lIG1ldHJpY3MgcmVmbG93IjogJ3Jlc29sdmVkX21vZGUgaW4geyJuYXJyb3ciLCAiY29tcGFjdCJ9JyBpbiBob21lLAogICAgInVzYWdlIHRvb2xiYXIgcmVmbG93cyI6ICJzZW1hbnRpYyA9IGxheW91dF9tb2RlX2Zvcl93aWR0aChhdmFpbGFibGVfd2lkdGgpIiBpbiB1c2FnZSwKICAgICJhZG1pbmlzdHJhdGlvbiByZWZsb3dzIjogImRlZiBhcHBseV9yZXNwb25zaXZlX3Byb2ZpbGUoc2VsZiwgcHJvZmlsZT1Ob25lKSIgaW4gYWRtaW5pc3RyYXRpb24sCn0KCmZvcmJpZGRlbiA9IHsKICAgICJ3aG9sZS13aW5kb3cgUUdyYXBoaWNzVmlldyBzY2FsaW5nIjogIlFHcmFwaGljc1ZpZXciIGluIHNoZWxsLAogICAgImdyYXBoaWNzIHByb3h5IHNoZWxsIjogIlFHcmFwaGljc1NjZW5lIiBpbiBzaGVsbCBvciAiYWRkV2lkZ2V0KHNoZWxsX3Jvb3QpIiBpbiBzaGVsbCBhbmQgIl9sZWdhY3lfZ3JhcGhpY3Nfc2hlbGxfcHJveHkiIGluIHNoZWxsLAogICAgInNoZWxsIHNjcm9sbCBhcmVhIjogIlFTY3JvbGxBcmVhIiBpbiBzaGVsbCwKICAgICJsZWdhY3kgc2NhbGUgaGVscGVyIjogImZpeGVkX2NvbXBvc2l0aW9uX3NjYWxlIiBpbiBwcm9maWxlcyBvciAiZml4ZWRfY29tcG9zaXRpb25fc2NhbGUiIGluIHNoZWxsLAogICAgImxlZ2FjeSBmaXhlZCBjb21wb3NpdGlvbiBjbGFzcyI6ICJGaXhlZENvbXBvc2l0aW9uVmlldyIgaW4gc2hlbGwsCiAgICAicHJvZmlsZSBpZ25vcmVzIG91dGVyIHJlc2l6ZSI6ICJkZWwgd2lkZ2V0IiBpbiBwcm9maWxlcywKICAgICJmb3JjZWQgc3RhYmxlIGxheW91dCBtb2RlIjogIlNUQUJMRV9MQVlPVVRfTU9ERSIgaW4gcHJvZmlsZXMsCn0KCmVycm9ycyA9IFtuYW1lIGZvciBuYW1lLCBvayBpbiByZXF1aXJlZC5pdGVtcygpIGlmIG5vdCBva10KZXJyb3JzICs9IFtuYW1lIGZvciBuYW1lLCBwcmVzZW50IGluIGZvcmJpZGRlbi5pdGVtcygpIGlmIHByZXNlbnRdCgpwcmludCgiU1RBQkxFX0xBWU9VVF9HQVRFPSIgKyAoIlBBU1MiIGlmIG5vdCBlcnJvcnMgZWxzZSAiRkFJTCIpKQpmb3IgZXJyb3IgaW4gZXJyb3JzOgogICAgcHJpbnQoIiAtIiwgZXJyb3IpCnN5cy5leGl0KDAgaWYgbm90IGVycm9ycyBlbHNlIDEpCg==",
    "switch_website_download.py": "IyEvdXNyL2Jpbi9lbnYgcHl0aG9uMwpmcm9tIF9fZnV0dXJlX18gaW1wb3J0IGFubm90YXRpb25zCmltcG9ydCBhcmdwYXJzZQppbXBvcnQgb3MKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmltcG9ydCByZQppbXBvcnQgc2h1dGlsCmltcG9ydCBzdWJwcm9jZXNzCmltcG9ydCBzeXMKaW1wb3J0IHRlbXBmaWxlCmZyb20gZGF0ZXRpbWUgaW1wb3J0IGRhdGV0aW1lLCB0aW1lem9uZQpmcm9tIHVybGxpYi5wYXJzZSBpbXBvcnQgdXJscGFyc2UKCklOU1RBTExFUl9OQU1FX1JFID0gcmUuY29tcGlsZShyIkhFUkZZLVRTLVNldHVwLVxkK1wuXGQrXC5cZCstd2luZG93cy14NjRcLmV4ZSIpCk9MRF9BQlNPTFVURV9SRSA9IHJlLmNvbXBpbGUoCiAgICByYiJodHRwczovL3VwZGF0ZXNcLmhlcmZ5XC5vbmxpbmUvdXBkYXRlcy9wYWNrYWdlcy8iCiAgICByYiJIRVJGWS1UUy1TZXR1cC1cZCtcLlxkK1wuXGQrLXdpbmRvd3MteDY0XC5leGUiCikKVEVYVF9TVUZGSVhFUyA9IHsiLmh0bWwiLCAiLmh0bSIsICIuanMiLCAiLmpzb24iLCAiLnR4dCIsICIueG1sIiwgIi5jc3MifQpNQVhfRklMRV9TSVpFID0gMTYgKiAxMDI0ICogMTAyNAoKCmRlZiBpc19tYW5pZmVzdF9kcml2ZW5fZG93bmxvYWQocGF5bG9hZDogYnl0ZXMpIC0+IGJvb2w6CiAgICAiIiJSZWNvZ25pemUgdGhlIHByb2R1Y3Rpb24gc2l0ZSBjb250cmFjdCB0aGF0IHJlc29sdmVzIHRoZSBidXR0b24gYXQgcnVudGltZS4iIiIKICAgIHJldHVybiAoCiAgICAgICAgYiJkb3dubG9hZC1saW5rIiBpbiBwYXlsb2FkCiAgICAgICAgYW5kIGIiTUFOSUZFU1RfVVJMIiBpbiBwYXlsb2FkCiAgICAgICAgYW5kIGIiaHR0cHM6Ly91cGRhdGVzLmhlcmZ5Lm9ubGluZS91cGRhdGVzL21hbmlmZXN0IiBpbiBwYXlsb2FkCiAgICApCgpkZWYgZmFpbChtZXNzYWdlOiBzdHIpIC0+IE5vbmU6CiAgICBwcmludChmIldFQlNJVEVfRE9XTkxPQUQ9RkFJTCByZWFzb249e21lc3NhZ2V9IiwgZmlsZT1zeXMuc3RkZXJyKQogICAgcmFpc2UgU3lzdGVtRXhpdCgxKQoKZGVmIG5naW54X2NvbmZpZygpIC0+IHN0cjoKICAgIHByb2MgPSBzdWJwcm9jZXNzLnJ1bigKICAgICAgICBbIm5naW54IiwgIi1UIl0sCiAgICAgICAgc3Rkb3V0PXN1YnByb2Nlc3MuUElQRSwKICAgICAgICBzdGRlcnI9c3VicHJvY2Vzcy5TVERPVVQsCiAgICAgICAgdGV4dD1UcnVlLAogICAgICAgIGVuY29kaW5nPSJ1dGYtOCIsCiAgICAgICAgZXJyb3JzPSJyZXBsYWNlIiwKICAgICkKICAgIGlmIHByb2MucmV0dXJuY29kZSAhPSAwOgogICAgICAgIGZhaWwoIm5naW54X2NvbmZpZ190ZXN0IikKICAgIHJldHVybiBwcm9jLnN0ZG91dAoKZGVmIHNlcnZlcl9ibG9ja3MoY29uZmlnOiBzdHIpOgogICAgcG9zID0gMAogICAgc3RhcnRfcmUgPSByZS5jb21waWxlKHIiXGJzZXJ2ZXJccypceyIpCiAgICB3aGlsZSBUcnVlOgogICAgICAgIG1hdGNoID0gc3RhcnRfcmUuc2VhcmNoKGNvbmZpZywgcG9zKQogICAgICAgIGlmIG5vdCBtYXRjaDoKICAgICAgICAgICAgcmV0dXJuCiAgICAgICAgZGVwdGggPSAxCiAgICAgICAgaSA9IG1hdGNoLmVuZCgpCiAgICAgICAgd2hpbGUgaSA8IGxlbihjb25maWcpIGFuZCBkZXB0aDoKICAgICAgICAgICAgaWYgY29uZmlnW2ldID09ICJ7IjoKICAgICAgICAgICAgICAgIGRlcHRoICs9IDEKICAgICAgICAgICAgZWxpZiBjb25maWdbaV0gPT0gIn0iOgogICAgICAgICAgICAgICAgZGVwdGggLT0gMQogICAgICAgICAgICBpICs9IDEKICAgICAgICBpZiBkZXB0aDoKICAgICAgICAgICAgZmFpbCgibmdpbnhfdW5iYWxhbmNlZF9zZXJ2ZXJfYmxvY2siKQogICAgICAgIHlpZWxkIGNvbmZpZ1ttYXRjaC5zdGFydCgpOmldCiAgICAgICAgcG9zID0gaQoKZGVmIGRpc2NvdmVyX3Jvb3RzKGNvbmZpZzogc3RyLCBkb21haW46IHN0cikgLT4gbGlzdFtQYXRoXToKICAgIHJvb3RzOiBsaXN0W1BhdGhdID0gW10KICAgIHdhbnRlZCA9IHtkb21haW4sIGYid3d3Lntkb21haW59In0KICAgIGZvciBibG9jayBpbiBzZXJ2ZXJfYmxvY2tzKGNvbmZpZyk6CiAgICAgICAgbmFtZXM6IHNldFtzdHJdID0gc2V0KCkKICAgICAgICBmb3IgbWF0Y2ggaW4gcmUuZmluZGl0ZXIociIoP20pXlxzKnNlcnZlcl9uYW1lXHMrKFteO10rKTsiLCBibG9jayk6CiAgICAgICAgICAgIG5hbWVzLnVwZGF0ZShwYXJ0LnN0cmlwKCkgZm9yIHBhcnQgaW4gbWF0Y2guZ3JvdXAoMSkuc3BsaXQoKSkKICAgICAgICBpZiBub3QgKG5hbWVzICYgd2FudGVkKToKICAgICAgICAgICAgY29udGludWUKICAgICAgICBmb3IgbWF0Y2ggaW4gcmUuZmluZGl0ZXIociIoP20pXlxzKnJvb3RccysoW147XSspOyIsIGJsb2NrKToKICAgICAgICAgICAgcmF3ID0gbWF0Y2guZ3JvdXAoMSkuc3RyaXAoKS5zdHJpcCgiXCInIikKICAgICAgICAgICAgaWYgIiQiIGluIHJhdzoKICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAgIHBhdGggPSBQYXRoKHJhdykKICAgICAgICAgICAgaWYgcGF0aC5pc19hYnNvbHV0ZSgpIGFuZCBwYXRoLmlzX2RpcigpIGFuZCBwYXRoICE9IFBhdGgoIi8iKToKICAgICAgICAgICAgICAgIHJvb3RzLmFwcGVuZChwYXRoLnJlc29sdmUoKSkKICAgIHVuaXF1ZTogbGlzdFtQYXRoXSA9IFtdCiAgICBmb3IgcGF0aCBpbiByb290czoKICAgICAgICBpZiBwYXRoIG5vdCBpbiB1bmlxdWU6CiAgICAgICAgICAgIHVuaXF1ZS5hcHBlbmQocGF0aCkKICAgIHJldHVybiB1bmlxdWUKCmRlZiBjYW5kaWRhdGVfZmlsZXMocm9vdDogUGF0aCk6CiAgICBmb3IgY3VycmVudCwgZGlycywgZmlsZXMgaW4gb3Mud2Fsayhyb290KToKICAgICAgICBkaXJzWzpdID0gW25hbWUgZm9yIG5hbWUgaW4gZGlycyBpZiBub3QgbmFtZS5zdGFydHN3aXRoKCIuIildCiAgICAgICAgZm9yIG5hbWUgaW4gZmlsZXM6CiAgICAgICAgICAgIHBhdGggPSBQYXRoKGN1cnJlbnQpIC8gbmFtZQogICAgICAgICAgICBpZiBwYXRoLnN1ZmZpeC5sb3dlcigpIG5vdCBpbiBURVhUX1NVRkZJWEVTOgogICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgdHJ5OgogICAgICAgICAgICAgICAgaWYgcGF0aC5zdGF0KCkuc3Rfc2l6ZSA+IE1BWF9GSUxFX1NJWkU6CiAgICAgICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgZXhjZXB0IE9TRXJyb3I6CiAgICAgICAgICAgICAgICBjb250aW51ZQogICAgICAgICAgICB5aWVsZCBwYXRoCgpkZWYgYXRvbWljX3JlcGxhY2UocGF0aDogUGF0aCwgcGF5bG9hZDogYnl0ZXMpIC0+IE5vbmU6CiAgICBzdGF0ID0gcGF0aC5zdGF0KCkKICAgIGZkLCB0ZW1wX25hbWUgPSB0ZW1wZmlsZS5ta3N0ZW1wKHByZWZpeD1mIi57cGF0aC5uYW1lfS5oZXJmeS0iLCBkaXI9c3RyKHBhdGgucGFyZW50KSkKICAgIHRyeToKICAgICAgICB3aXRoIG9zLmZkb3BlbihmZCwgIndiIikgYXMgaGFuZGxlOgogICAgICAgICAgICBoYW5kbGUud3JpdGUocGF5bG9hZCkKICAgICAgICAgICAgaGFuZGxlLmZsdXNoKCkKICAgICAgICAgICAgb3MuZnN5bmMoaGFuZGxlLmZpbGVubygpKQogICAgICAgIG9zLmNobW9kKHRlbXBfbmFtZSwgc3RhdC5zdF9tb2RlKQogICAgICAgIHRyeToKICAgICAgICAgICAgb3MuY2hvd24odGVtcF9uYW1lLCBzdGF0LnN0X3VpZCwgc3RhdC5zdF9naWQpCiAgICAgICAgZXhjZXB0IFBlcm1pc3Npb25FcnJvcjoKICAgICAgICAgICAgcGFzcwogICAgICAgIG9zLnJlcGxhY2UodGVtcF9uYW1lLCBwYXRoKQogICAgZmluYWxseToKICAgICAgICB0cnk6CiAgICAgICAgICAgIG9zLnVubGluayh0ZW1wX25hbWUpCiAgICAgICAgZXhjZXB0IEZpbGVOb3RGb3VuZEVycm9yOgogICAgICAgICAgICBwYXNzCgpkZWYgbWFpbigpIC0+IE5vbmU6CiAgICBwYXJzZXIgPSBhcmdwYXJzZS5Bcmd1bWVudFBhcnNlcigpCiAgICBwYXJzZXIuYWRkX2FyZ3VtZW50KCItLWluc3RhbGxlci11cmwiLCByZXF1aXJlZD1UcnVlKQogICAgcGFyc2VyLmFkZF9hcmd1bWVudCgiLS1kb21haW4iLCBkZWZhdWx0PSJoZXJmeS5vbmxpbmUiKQogICAgYXJncyA9IHBhcnNlci5wYXJzZV9hcmdzKCkKICAgIHVybCA9IHN0cihhcmdzLmluc3RhbGxlcl91cmwpLnN0cmlwKCkKICAgIHBhcnNlZCA9IHVybHBhcnNlKHVybCkKICAgIGlmICgKICAgICAgICBwYXJzZWQuc2NoZW1lICE9ICJodHRwcyIKICAgICAgICBvciBwYXJzZWQubmV0bG9jICE9ICJ1cGRhdGVzLmhlcmZ5Lm9ubGluZSIKICAgICAgICBvciBub3QgcGFyc2VkLnBhdGguc3RhcnRzd2l0aCgiL3VwZGF0ZXMvcGFja2FnZXMvIikKICAgICAgICBvciBub3QgSU5TVEFMTEVSX05BTUVfUkUuZnVsbG1hdGNoKFBhdGgocGFyc2VkLnBhdGgpLm5hbWUpCiAgICApOgogICAgICAgIGZhaWwoIm5vbmNhbm9uaWNhbF9pbnN0YWxsZXJfdXJsIikKICAgIHJvb3RzID0gZGlzY292ZXJfcm9vdHMobmdpbnhfY29uZmlnKCksIGFyZ3MuZG9tYWluKQogICAgaWYgbm90IHJvb3RzOgogICAgICAgIGZhaWwoIndlYnNpdGVfcm9vdF9ub3RfZm91bmQiKQogICAgbmV3X2J5dGVzID0gdXJsLmVuY29kZSgidXRmLTgiKQogICAgbWF0Y2hlZF9vbGQ6IGxpc3RbUGF0aF0gPSBbXQogICAgYWxyZWFkeV9jdXJyZW50OiBsaXN0W1BhdGhdID0gW10KICAgIG1hbmlmZXN0X2RyaXZlbjogbGlzdFtQYXRoXSA9IFtdCiAgICBmb3Igcm9vdCBpbiByb290czoKICAgICAgICBmb3IgcGF0aCBpbiBjYW5kaWRhdGVfZmlsZXMocm9vdCk6CiAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgIGRhdGEgPSBwYXRoLnJlYWRfYnl0ZXMoKQogICAgICAgICAgICBleGNlcHQgT1NFcnJvcjoKICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAgIGlmIG5ld19ieXRlcyBpbiBkYXRhOgogICAgICAgICAgICAgICAgYWxyZWFkeV9jdXJyZW50LmFwcGVuZChwYXRoKQogICAgICAgICAgICBpZiBpc19tYW5pZmVzdF9kcml2ZW5fZG93bmxvYWQoZGF0YSk6CiAgICAgICAgICAgICAgICBtYW5pZmVzdF9kcml2ZW4uYXBwZW5kKHBhdGgpCiAgICAgICAgICAgIG9sZF91cmxzID0gc2V0KE9MRF9BQlNPTFVURV9SRS5maW5kYWxsKGRhdGEpKQogICAgICAgICAgICBpZiBhbnkodmFsdWUgIT0gbmV3X2J5dGVzIGZvciB2YWx1ZSBpbiBvbGRfdXJscyk6CiAgICAgICAgICAgICAgICBtYXRjaGVkX29sZC5hcHBlbmQocGF0aCkKICAgIGlmIG5vdCBtYXRjaGVkX29sZDoKICAgICAgICBpZiBhbHJlYWR5X2N1cnJlbnQ6CiAgICAgICAgICAgIHByaW50KCJXRUJTSVRFX0RPV05MT0FEPVBBU1Mgc3RhdGU9YWxyZWFkeV9jdXJyZW50IikKICAgICAgICAgICAgcHJpbnQoIldFQlNJVEVfUk9PVFM9IiArICIsIi5qb2luKHN0cihwYXRoKSBmb3IgcGF0aCBpbiByb290cykpCiAgICAgICAgICAgIHJldHVybgogICAgICAgIGlmIG1hbmlmZXN0X2RyaXZlbjoKICAgICAgICAgICAgcHJpbnQoIldFQlNJVEVfRE9XTkxPQUQ9UEFTUyBzdGF0ZT1tYW5pZmVzdF9kcml2ZW5fY3VycmVudCIpCiAgICAgICAgICAgIHByaW50KCJXRUJTSVRFX1JPT1RTPSIgKyAiLCIuam9pbihzdHIocGF0aCkgZm9yIHBhdGggaW4gcm9vdHMpKQogICAgICAgICAgICByZXR1cm4KICAgICAgICBmYWlsKCJvbGRfZG93bmxvYWRfbGlua19ub3RfZm91bmQiKQogICAgc3RhbXAgPSBkYXRldGltZS5ub3codGltZXpvbmUudXRjKS5zdHJmdGltZSgiJVklbSVkVCVIJU0lU1oiKQogICAgYmFja3VwX3Jvb3QgPSBQYXRoKCIvdmFyL2JhY2t1cHMvaGVyZnktc2l0ZS1kb3dubG9hZCIpIC8gc3RhbXAKICAgIGJhY2t1cF9yb290Lm1rZGlyKHBhcmVudHM9VHJ1ZSwgZXhpc3Rfb2s9RmFsc2UpCiAgICBjaGFuZ2VkOiBsaXN0W1BhdGhdID0gW10KICAgIHJvb3RfdGFncyA9IHsocGF0aC5hc19wb3NpeCgpLnN0cmlwKCIvIikucmVwbGFjZSgiLyIsICJfIikgb3IgInJvb3QiKTogcGF0aCBmb3IgcGF0aCBpbiByb290c30KICAgIHRyeToKICAgICAgICBmb3IgcGF0aCBpbiBtYXRjaGVkX29sZDoKICAgICAgICAgICAgb3duaW5nX3Jvb3QgPSBuZXh0KChyIGZvciByIGluIHJvb3RzIGlmIHBhdGggPT0gciBvciByIGluIHBhdGgucGFyZW50cyksIE5vbmUpCiAgICAgICAgICAgIGlmIG93bmluZ19yb290IGlzIE5vbmU6CiAgICAgICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoInBhdGhfb3V0c2lkZV93ZWJzaXRlX3Jvb3QiKQogICAgICAgICAgICByZWxhdGl2ZSA9IHBhdGgucmVsYXRpdmVfdG8ob3duaW5nX3Jvb3QpCiAgICAgICAgICAgIHJvb3RfdGFnID0gb3duaW5nX3Jvb3QuYXNfcG9zaXgoKS5zdHJpcCgiLyIpLnJlcGxhY2UoIi8iLCAiXyIpIG9yICJyb290IgogICAgICAgICAgICBiYWNrdXAgPSBiYWNrdXBfcm9vdCAvIHJvb3RfdGFnIC8gcmVsYXRpdmUKICAgICAgICAgICAgYmFja3VwLnBhcmVudC5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUpCiAgICAgICAgICAgIHNodXRpbC5jb3B5MihwYXRoLCBiYWNrdXApCiAgICAgICAgICAgIG9yaWdpbmFsID0gcGF0aC5yZWFkX2J5dGVzKCkKICAgICAgICAgICAgdXBkYXRlZCA9IE9MRF9BQlNPTFVURV9SRS5zdWIobmV3X2J5dGVzLCBvcmlnaW5hbCkKICAgICAgICAgICAgaWYgdXBkYXRlZCA9PSBvcmlnaW5hbDoKICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAgIGF0b21pY19yZXBsYWNlKHBhdGgsIHVwZGF0ZWQpCiAgICAgICAgICAgIGlmIG5ld19ieXRlcyBub3QgaW4gcGF0aC5yZWFkX2J5dGVzKCk6CiAgICAgICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoInBvc3R3cml0ZV92ZXJpZmljYXRpb24iKQogICAgICAgICAgICBjaGFuZ2VkLmFwcGVuZChwYXRoKQogICAgICAgICMgVmVyaWZ5IHRoZSBlbnRpcmUgZGlzY292ZXJlZCB3ZWIgcm9vdCwgbm90IG9ubHkgdGhlIGZpbGVzIHdlIHRvdWNoZWQ6CiAgICAgICAgIyBubyBzdGFsZSBjYW5vbmljYWwgSEVSRlkgaW5zdGFsbGVyIFVSTCBtYXkgcmVtYWluIGFmdGVyIHRoZSBzd2l0Y2guCiAgICAgICAgc3RhbGU6IGxpc3Rbc3RyXSA9IFtdCiAgICAgICAgbmV3X2xpbmtfZm91bmQgPSBGYWxzZQogICAgICAgIGZvciByb290IGluIHJvb3RzOgogICAgICAgICAgICBmb3IgY2FuZGlkYXRlIGluIGNhbmRpZGF0ZV9maWxlcyhyb290KToKICAgICAgICAgICAgICAgIHRyeToKICAgICAgICAgICAgICAgICAgICBkYXRhID0gY2FuZGlkYXRlLnJlYWRfYnl0ZXMoKQogICAgICAgICAgICAgICAgZXhjZXB0IE9TRXJyb3I6CiAgICAgICAgICAgICAgICAgICAgY29udGludWUKICAgICAgICAgICAgICAgIGlmIG5ld19ieXRlcyBpbiBkYXRhOgogICAgICAgICAgICAgICAgICAgIG5ld19saW5rX2ZvdW5kID0gVHJ1ZQogICAgICAgICAgICAgICAgb2xkX3VybHMgPSBzZXQoT0xEX0FCU09MVVRFX1JFLmZpbmRhbGwoZGF0YSkpCiAgICAgICAgICAgICAgICBpZiBhbnkodmFsdWUgIT0gbmV3X2J5dGVzIGZvciB2YWx1ZSBpbiBvbGRfdXJscyk6CiAgICAgICAgICAgICAgICAgICAgc3RhbGUuYXBwZW5kKHN0cihjYW5kaWRhdGUpKQogICAgICAgIGlmIHN0YWxlOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoInN0YWxlX2Rvd25sb2FkX2xpbmtfcmVtYWluczoiICsgIiwiLmpvaW4oc3RhbGVbOjEwXSkpCiAgICAgICAgaWYgbm90IG5ld19saW5rX2ZvdW5kOgogICAgICAgICAgICByYWlzZSBSdW50aW1lRXJyb3IoIm5ld19kb3dubG9hZF9saW5rX25vdF9mb3VuZF9hZnRlcl9zd2l0Y2giKQoKICAgICAgICB0ZXN0ID0gc3VicHJvY2Vzcy5ydW4oWyJuZ2lueCIsICItdCJdLCBzdGRvdXQ9c3VicHJvY2Vzcy5QSVBFLCBzdGRlcnI9c3VicHJvY2Vzcy5TVERPVVQpCiAgICAgICAgaWYgdGVzdC5yZXR1cm5jb2RlICE9IDA6CiAgICAgICAgICAgIHJhaXNlIFJ1bnRpbWVFcnJvcigibmdpbnhfdGVzdF9mYWlsZWQiKQogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgaWYgYmFja3VwX3Jvb3QuZXhpc3RzKCk6CiAgICAgICAgICAgIGZvciByb290X3RhZ19kaXIgaW4gYmFja3VwX3Jvb3QuaXRlcmRpcigpOgogICAgICAgICAgICAgICAgb3duaW5nX3Jvb3QgPSByb290X3RhZ3MuZ2V0KHJvb3RfdGFnX2Rpci5uYW1lKQogICAgICAgICAgICAgICAgaWYgb3duaW5nX3Jvb3QgaXMgTm9uZSBvciBub3Qgcm9vdF90YWdfZGlyLmlzX2RpcigpOgogICAgICAgICAgICAgICAgICAgIGNvbnRpbnVlCiAgICAgICAgICAgICAgICBmb3IgYmFja3VwIGluIHJvb3RfdGFnX2Rpci5yZ2xvYigiKiIpOgogICAgICAgICAgICAgICAgICAgIGlmIGJhY2t1cC5pc19maWxlKCk6CiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldCA9IG93bmluZ19yb290IC8gYmFja3VwLnJlbGF0aXZlX3RvKHJvb3RfdGFnX2RpcikKICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0LnBhcmVudC5ta2RpcihwYXJlbnRzPVRydWUsIGV4aXN0X29rPVRydWUpCiAgICAgICAgICAgICAgICAgICAgICAgIHNodXRpbC5jb3B5MihiYWNrdXAsIHRhcmdldCkKICAgICAgICBmYWlsKHN0cihleGMpKQogICAgaWYgbm90IGNoYW5nZWQ6CiAgICAgICAgZmFpbCgibm9fZmlsZV9jaGFuZ2VkIikKICAgIHByaW50KCJXRUJTSVRFX0RPV05MT0FEPVBBU1Mgc3RhdGU9cmVwbGFjZWQiKQogICAgcHJpbnQoZiJXRUJTSVRFX0NIQU5HRURfRklMRVM9e2xlbihjaGFuZ2VkKX0iKQogICAgcHJpbnQoZiJXRUJTSVRFX0JBQ0tVUD17YmFja3VwX3Jvb3R9IikKICAgIGZvciBwYXRoIGluIGNoYW5nZWQ6CiAgICAgICAgcHJpbnQoZiJXRUJTSVRFX0NIQU5HRUQ9e3BhdGh9IikKCmlmIF9fbmFtZV9fID09ICJfX21haW5fXyI6CiAgICBtYWluKCkK",
    "verify_update_transition.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IGFyZ3BhcnNlCmltcG9ydCBiYXNlNjQKaW1wb3J0IGhhc2hsaWIKaW1wb3J0IGpzb24KaW1wb3J0IHJlCmltcG9ydCB6aXBmaWxlCmZyb20gcGF0aGxpYiBpbXBvcnQgUGF0aApmcm9tIHVybGxpYiBpbXBvcnQgcmVxdWVzdApmcm9tIHVybGxpYi5wYXJzZSBpbXBvcnQgdXJscGFyc2UKCmZyb20gY3J5cHRvZ3JhcGh5Lmhhem1hdC5wcmltaXRpdmVzIGltcG9ydCBzZXJpYWxpemF0aW9uCmZyb20gY3J5cHRvZ3JhcGh5Lmhhem1hdC5wcmltaXRpdmVzLmFzeW1tZXRyaWMuZWQyNTUxOSBpbXBvcnQgRWQyNTUxOVB1YmxpY0tleQpmcm9tIHBhY2thZ2luZy52ZXJzaW9uIGltcG9ydCBWZXJzaW9uCgoKX1BVQkxJQ19NQU5JRkVTVF9VUkwgPSAiaHR0cHM6Ly91cGRhdGVzLmhlcmZ5Lm9ubGluZS91cGRhdGVzL21hbmlmZXN0IgoKCmRlZiBzaGEyNTZfZmlsZShwYXRoOiBQYXRoKSAtPiBzdHI6CiAgICBkaWdlc3QgPSBoYXNobGliLnNoYTI1NigpCiAgICB3aXRoIHBhdGgub3BlbigicmIiKSBhcyBoYW5kbGU6CiAgICAgICAgZm9yIGJsb2NrIGluIGl0ZXIobGFtYmRhOiBoYW5kbGUucmVhZCgxMDI0ICogMTAyNCksIGIiIik6CiAgICAgICAgICAgIGRpZ2VzdC51cGRhdGUoYmxvY2spCiAgICByZXR1cm4gZGlnZXN0LmhleGRpZ2VzdCgpCgoKZGVmIGNhbm9uaWNhbF9wYXlsb2FkKHBheWxvYWQ6IGRpY3Rbc3RyLCBvYmplY3RdKSAtPiBieXRlczoKICAgIGJvZHkgPSB7a2V5OiB2YWx1ZSBmb3Iga2V5LCB2YWx1ZSBpbiBwYXlsb2FkLml0ZW1zKCkgaWYga2V5ICE9ICJzaWduYXR1cmUifQogICAgcmV0dXJuIGpzb24uZHVtcHMoCiAgICAgICAgYm9keSwKICAgICAgICBzb3J0X2tleXM9VHJ1ZSwKICAgICAgICBzZXBhcmF0b3JzPSgiLCIsICI6IiksCiAgICAgICAgZW5zdXJlX2FzY2lpPUZhbHNlLAogICAgKS5lbmNvZGUoInV0Zi04IikKCgpkZWYgY29udHJhY3Rfc2hhMjU2KGNvbnRyYWN0c19kaXI6IFBhdGgpIC0+IHN0cjoKICAgICIiIlJldHVybiB0aGUgY2Fub25pY2FsIEFQSS1jb21wYXRpYmlsaXR5IGFnZ3JlZ2F0ZSBvbmx5LiIiIgogICAgbWFuaWZlc3QgPSBqc29uLmxvYWRzKChjb250cmFjdHNfZGlyIC8gIkNPTlRSQUNUUy5qc29uIikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpKQogICAgZW50cmllcyA9IG1hbmlmZXN0LmdldCgiY29udHJhY3RzIikKICAgIGFwaV9uYW1lcyA9IG1hbmlmZXN0LmdldCgiYXBpX2NvbXBhdGliaWxpdHlfY29udHJhY3RzIikKICAgIGlmIG5vdCBpc2luc3RhbmNlKGVudHJpZXMsIGxpc3QpIG9yIG5vdCBpc2luc3RhbmNlKGFwaV9uYW1lcywgbGlzdCkgb3Igbm90IGFwaV9uYW1lczoKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJpbnZhbGlkIGNvbnRyYWN0IG1hbmlmZXN0IikKICAgIGJ5X25hbWUgPSB7c3RyKGVudHJ5LmdldCgiZmlsZW5hbWUiKSBvciAiIik6IGVudHJ5IGZvciBlbnRyeSBpbiBlbnRyaWVzIGlmIGlzaW5zdGFuY2UoZW50cnksIGRpY3QpfQogICAgbm9ybWFsaXplZCA9IFtzdHIobmFtZSkuc3RyaXAoKSBmb3IgbmFtZSBpbiBhcGlfbmFtZXNdCiAgICBpZiBhbnkobm90IG5hbWUgZm9yIG5hbWUgaW4gbm9ybWFsaXplZCkgb3IgbGVuKHNldChub3JtYWxpemVkKSkgIT0gbGVuKG5vcm1hbGl6ZWQpOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoImludmFsaWQgYXBpX2NvbXBhdGliaWxpdHlfY29udHJhY3RzIikKICAgIHVua25vd24gPSBzb3J0ZWQoc2V0KG5vcm1hbGl6ZWQpIC0gc2V0KGJ5X25hbWUpKQogICAgaWYgdW5rbm93bjoKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KGYidW5rbm93biBBUEkgY29tcGF0aWJpbGl0eSBjb250cmFjdHM6IHt1bmtub3dufSIpCgogICAgZGlnZXN0ID0gaGFzaGxpYi5zaGEyNTYoKQogICAgZm9yIG5hbWUgaW4gc29ydGVkKG5vcm1hbGl6ZWQpOgogICAgICAgIHJhdyA9IChjb250cmFjdHNfZGlyIC8gbmFtZSkucmVhZF9ieXRlcygpCiAgICAgICAgYWN0dWFsID0gaGFzaGxpYi5zaGEyNTYocmF3KS5oZXhkaWdlc3QoKQogICAgICAgIGlmIGFjdHVhbCAhPSBzdHIoYnlfbmFtZVtuYW1lXS5nZXQoInNoYTI1NiIpIG9yICIiKS5sb3dlcigpOgogICAgICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KGYiY29udHJhY3QgY2hlY2tzdW0gbWlzbWF0Y2g6IHtuYW1lfSIpCiAgICAgICAgZGlnZXN0LnVwZGF0ZShuYW1lLmVuY29kZSgidXRmLTgiKSkKICAgICAgICBkaWdlc3QudXBkYXRlKGIiXDAiKQogICAgICAgIGRpZ2VzdC51cGRhdGUocmF3KQogICAgICAgIGRpZ2VzdC51cGRhdGUoYiJcMCIpCiAgICBhY3R1YWwgPSBkaWdlc3QuaGV4ZGlnZXN0KCkKICAgIGV4cGVjdGVkID0gc3RyKG1hbmlmZXN0LmdldCgic2VydmVyX2NvbXBhdGlibGVfYXBpX2NvbnRyYWN0X3NoYTI1NiIpIG9yICIiKS5sb3dlcigpCiAgICBpZiBhY3R1YWwgIT0gZXhwZWN0ZWQ6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgiQVBJIGNvbXBhdGliaWxpdHkgYWdncmVnYXRlIG1pc21hdGNoIikKICAgIHJldHVybiBhY3R1YWwKCgpkZWYgcHVibGljX2Jhc2VsaW5lX3ZlcnNpb24obWFuaWZlc3RfdXJsOiBzdHIpIC0+IHN0cjoKICAgICIiIlJldHVybiB0aGUgY2Fub25pY2FsIHB1YmxpYyB1cGRhdGUgdmVyc2lvbiBvciBmYWlsIGJlZm9yZSBwdWJsaWNhdGlvbi4iIiIKICAgIGlmIHN0cihtYW5pZmVzdF91cmwpLnN0cmlwKCkgIT0gX1BVQkxJQ19NQU5JRkVTVF9VUkw6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgicHVibGljIG1hbmlmZXN0IFVSTCBpcyBub3QgY2Fub25pY2FsIikKICAgIHRyeToKICAgICAgICB3aXRoIHJlcXVlc3QudXJsb3BlbihfUFVCTElDX01BTklGRVNUX1VSTCwgdGltZW91dD0yMCkgYXMgcmVzcG9uc2U6CiAgICAgICAgICAgIHBheWxvYWQgPSBqc29uLmxvYWRzKHJlc3BvbnNlLnJlYWQoKS5kZWNvZGUoInV0Zi04IikpCiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGV4YzoKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJ1bmFibGUgdG8gZmV0Y2ggdGhlIHB1YmxpYyB1cGRhdGUgbWFuaWZlc3QiKSBmcm9tIGV4YwogICAgaWYgbm90IGlzaW5zdGFuY2UocGF5bG9hZCwgZGljdCk6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgicHVibGljIHVwZGF0ZSBtYW5pZmVzdCBtdXN0IGJlIGFuIG9iamVjdCIpCiAgICB2ZXJzaW9uID0gc3RyKHBheWxvYWQuZ2V0KCJ2ZXJzaW9uIikgb3IgIiIpLnN0cmlwKCkKICAgIGlmIG5vdCByZS5mdWxsbWF0Y2gociJcZCtcLlxkK1wuXGQrIiwgdmVyc2lvbik6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgicHVibGljIG1hbmlmZXN0IHZlcnNpb24gaXMgbm90IGEgc2VtYW50aWMgdmVyc2lvbiIpCiAgICB0cnk6CiAgICAgICAgVmVyc2lvbih2ZXJzaW9uKQogICAgZXhjZXB0IEV4Y2VwdGlvbiBhcyBleGM6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgicHVibGljIG1hbmlmZXN0IHZlcnNpb24gaXMgbm90IGEgc2VtYW50aWMgdmVyc2lvbiIpIGZyb20gZXhjCiAgICByZXR1cm4gdmVyc2lvbgpkZWYgbWFpbigpIC0+IGludDoKICAgIHBhcnNlciA9IGFyZ3BhcnNlLkFyZ3VtZW50UGFyc2VyKCkKICAgIHBhcnNlci5hZGRfYXJndW1lbnQoIi0tcm9vdCIsIHJlcXVpcmVkPVRydWUpCiAgICBwYXJzZXIuYWRkX2FyZ3VtZW50KCItLXB1YmxpY2F0aW9uIiwgcmVxdWlyZWQ9VHJ1ZSkKICAgIHBhcnNlci5hZGRfYXJndW1lbnQoIi0tYmFzZWxpbmUtdmVyc2lvbiIsIGRlZmF1bHQ9IiIpCiAgICBwYXJzZXIuYWRkX2FyZ3VtZW50KCItLWJhc2VsaW5lLW1hbmlmZXN0LXVybCIsIGRlZmF1bHQ9IiIpCiAgICBhcmdzID0gcGFyc2VyLnBhcnNlX2FyZ3MoKQoKICAgIHJvb3QgPSBQYXRoKGFyZ3Mucm9vdCkucmVzb2x2ZSgpCiAgICBwdWJsaWNhdGlvbiA9IFBhdGgoYXJncy5wdWJsaWNhdGlvbikucmVzb2x2ZSgpCiAgICB1cGRhdGVzID0gcHVibGljYXRpb24gLyAidXBkYXRlcyIKICAgIG1hbmlmZXN0X3BhdGggPSB1cGRhdGVzIC8gIm1hbmlmZXN0IgogICAgcGFja2FnZV9kaXIgPSB1cGRhdGVzIC8gInBhY2thZ2VzIgoKICAgIHJ1bnRpbWVfaWRlbnRpdHkgPSBqc29uLmxvYWRzKChyb290IC8gInZlcnNpb24uanNvbiIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKSkKICAgIHRhcmdldCA9IHN0cihydW50aW1lX2lkZW50aXR5WyJ2ZXJzaW9uIl0pLnN0cmlwKCkKICAgIGJhc2VsaW5lID0gc3RyKGFyZ3MuYmFzZWxpbmVfdmVyc2lvbiBvciAiIikuc3RyaXAoKQogICAgaWYgYXJncy5iYXNlbGluZV9tYW5pZmVzdF91cmw6CiAgICAgICAgaWYgYmFzZWxpbmU6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoIm9ubHkgb25lIHVwZGF0ZSBiYXNlbGluZSBtYXkgYmUgc3BlY2lmaWVkIikKICAgICAgICBiYXNlbGluZSA9IHB1YmxpY19iYXNlbGluZV92ZXJzaW9uKHN0cihhcmdzLmJhc2VsaW5lX21hbmlmZXN0X3VybCkpCiAgICBpZiBiYXNlbGluZSBhbmQgVmVyc2lvbih0YXJnZXQpIDw9IFZlcnNpb24oYmFzZWxpbmUpOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoCiAgICAgICAgICAgIGYidXBkYXRlIHRyYW5zaXRpb24gaXMgbm90IG5ld2VyOiBiYXNlbGluZT17YmFzZWxpbmV9IHRhcmdldD17dGFyZ2V0fSIKICAgICAgICApCgogICAgbWFuaWZlc3QgPSBqc29uLmxvYWRzKG1hbmlmZXN0X3BhdGgucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpKQogICAgaWYgc3RyKG1hbmlmZXN0LmdldCgidmVyc2lvbiIpIG9yICIiKSAhPSB0YXJnZXQ6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgic2lnbmVkIG1hbmlmZXN0IHRhcmdldCB2ZXJzaW9uIGRvZXMgbm90IG1hdGNoIHZlcnNpb24uanNvbiIpCiAgICBpZiBzdHIobWFuaWZlc3QuZ2V0KCJjb250cmFjdF9zaGEyNTYiKSBvciAiIikubG93ZXIoKSAhPSBjb250cmFjdF9zaGEyNTYocm9vdCAvICJjb250cmFjdHMiKToKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJzaWduZWQgbWFuaWZlc3QgY29udHJhY3QgaGFzaCBkb2VzIG5vdCBtYXRjaCB0aGUgcGFja2FnZWQgQVBJIGNvbnRyYWN0IikKCiAgICBwdWJsaWNfcGVtID0gKHJvb3QgLyAicmVzb3VyY2VzIiAvICJ1cGRhdGVfc2lnbmluZ19wdWJsaWMucGVtIikucmVhZF9ieXRlcygpCiAgICBwdWJsaWNfa2V5ID0gc2VyaWFsaXphdGlvbi5sb2FkX3BlbV9wdWJsaWNfa2V5KHB1YmxpY19wZW0pCiAgICBpZiBub3QgaXNpbnN0YW5jZShwdWJsaWNfa2V5LCBFZDI1NTE5UHVibGljS2V5KToKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJwaW5uZWQgdXBkYXRlIHB1YmxpYyBrZXkgaXMgbm90IEVkMjU1MTkiKQogICAgdHJ5OgogICAgICAgIHNpZ25hdHVyZSA9IGJhc2U2NC5iNjRkZWNvZGUoc3RyKG1hbmlmZXN0WyJzaWduYXR1cmUiXSksIHZhbGlkYXRlPVRydWUpCiAgICAgICAgcHVibGljX2tleS52ZXJpZnkoc2lnbmF0dXJlLCBjYW5vbmljYWxfcGF5bG9hZChtYW5pZmVzdCkpCiAgICBleGNlcHQgRXhjZXB0aW9uIGFzIGV4YzogICMgdmVyaWZpY2F0aW9uIGVycm9yIHR5cGUgZGlmZmVycyBhY3Jvc3MgY3J5cHRvZ3JhcGh5IHZlcnNpb25zCiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgic2lnbmVkIG1hbmlmZXN0IHZlcmlmaWNhdGlvbiBmYWlsZWQiKSBmcm9tIGV4YwoKICAgIGFyY2hpdGVjdHVyZSA9IHN0cihtYW5pZmVzdC5nZXQoImFyY2hpdGVjdHVyZSIpIG9yICIiKS5zdHJpcCgpLmxvd2VyKCkKICAgIGlmIGFyY2hpdGVjdHVyZSAhPSAieDY0IiBvciBtYW5pZmVzdC5nZXQoInBsYXRmb3JtIikgIT0gIndpbmRvd3MiOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoInVuZXhwZWN0ZWQgdXBkYXRlIHBsYXRmb3JtIG9yIGFyY2hpdGVjdHVyZSIpCgogICAgZXhwZWN0ZWRfbmFtZXMgPSB7CiAgICAgICAgInJ1bnRpbWUiOiBmIkhFUkZZLVRTLXt0YXJnZXR9LXdpbmRvd3MteDY0LXJ1bnRpbWUuemlwIiwKICAgICAgICAiaW5zdGFsbGVyIjogZiJIRVJGWS1UUy1TZXR1cC17dGFyZ2V0fS13aW5kb3dzLXg2NC5leGUiLAogICAgfQogICAgcGFja2FnZV9wYXRoczogZGljdFtzdHIsIFBhdGhdID0ge30KICAgIGZvciBwcmVmaXgsIGV4cGVjdGVkX25hbWUgaW4gZXhwZWN0ZWRfbmFtZXMuaXRlbXMoKToKICAgICAgICBwYXJzZWQgPSB1cmxwYXJzZShzdHIobWFuaWZlc3RbZiJ7cHJlZml4fV91cmwiXSkpCiAgICAgICAgYWN0dWFsX25hbWUgPSBQYXRoKHBhcnNlZC5wYXRoKS5uYW1lCiAgICAgICAgaWYgYWN0dWFsX25hbWUgIT0gZXhwZWN0ZWRfbmFtZToKICAgICAgICAgICAgcmFpc2UgU3lzdGVtRXhpdChmIntwcmVmaXh9IGNhbm9uaWNhbCBmaWxlbmFtZSBtaXNtYXRjaCIpCiAgICAgICAgcGF0aCA9IHBhY2thZ2VfZGlyIC8gZXhwZWN0ZWRfbmFtZQogICAgICAgIGlmIG5vdCBwYXRoLmlzX2ZpbGUoKToKICAgICAgICAgICAgcmFpc2UgU3lzdGVtRXhpdChmIntwcmVmaXh9IHBhY2thZ2UgaXMgbWlzc2luZzoge3BhdGh9IikKICAgICAgICBpZiBwYXRoLnN0YXQoKS5zdF9zaXplICE9IGludChtYW5pZmVzdFtmIntwcmVmaXh9X3NpemUiXSk6CiAgICAgICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJ7cHJlZml4fSBwYWNrYWdlIHNpemUgbWlzbWF0Y2giKQogICAgICAgIGlmIHNoYTI1Nl9maWxlKHBhdGgpICE9IHN0cihtYW5pZmVzdFtmIntwcmVmaXh9X3NoYTI1NiJdKS5sb3dlcigpOgogICAgICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KGYie3ByZWZpeH0gcGFja2FnZSBTSEEtMjU2IG1pc21hdGNoIikKICAgICAgICBwYWNrYWdlX3BhdGhzW3ByZWZpeF0gPSBwYXRoCgogICAgd2l0aCB6aXBmaWxlLlppcEZpbGUocGFja2FnZV9wYXRoc1sicnVudGltZSJdLCAiciIpIGFzIGFyY2hpdmU6CiAgICAgICAgbmFtZXMgPSBzZXQoYXJjaGl2ZS5uYW1lbGlzdCgpKQogICAgICAgIHJlcXVpcmVkID0geyJIRVJGWS1UUy5leGUiLCAiSEVSRlktVFNVcGRhdGVBZ2VudC5leGUiLCAidmVyc2lvbi5qc29uIiwgInJ1bnRpbWVfZmlsZXMudHh0In0KICAgICAgICBtaXNzaW5nID0gc29ydGVkKHJlcXVpcmVkIC0gbmFtZXMpCiAgICAgICAgaWYgbWlzc2luZzoKICAgICAgICAgICAgcmFpc2UgU3lzdGVtRXhpdChmInJ1bnRpbWUgWklQIGlzIG1pc3NpbmcgcmVxdWlyZWQgZmlsZXM6IHttaXNzaW5nfSIpCiAgICAgICAgcnVudGltZV92ZXJzaW9uID0ganNvbi5sb2FkcyhhcmNoaXZlLnJlYWQoInZlcnNpb24uanNvbiIpLmRlY29kZSgidXRmLTgtc2lnIikpCiAgICAgICAgaWYgc3RyKHJ1bnRpbWVfdmVyc2lvbi5nZXQoInZlcnNpb24iKSBvciAiIikgIT0gdGFyZ2V0OgogICAgICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJydW50aW1lIFpJUCBjb250YWlucyB0aGUgd3JvbmcgdmVyc2lvbi5qc29uIikKCiAgICBpZiBub3QgcmUuZnVsbG1hdGNoKHIiXGQrXC5cZCtcLlxkKyIsIHRhcmdldCk6CiAgICAgICAgcmFpc2UgU3lzdGVtRXhpdCgidGFyZ2V0IHZlcnNpb24gaXMgbm90IGNhbm9uaWNhbCB0aHJlZS1wYXJ0IHNlbXZlciIpCgogICAgcHJpbnQoCiAgICAgICAganNvbi5kdW1wcygKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgInN0YXR1cyI6ICJQQVNTIiwKICAgICAgICAgICAgICAgICJiYXNlbGluZV92ZXJzaW9uIjogYmFzZWxpbmUgb3IgTm9uZSwKICAgICAgICAgICAgICAgICJ0YXJnZXRfdmVyc2lvbiI6IHRhcmdldCwKICAgICAgICAgICAgICAgICJtYW5pZmVzdF9zaGEyNTYiOiBzaGEyNTZfZmlsZShtYW5pZmVzdF9wYXRoKSwKICAgICAgICAgICAgICAgICJydW50aW1lX3NoYTI1NiI6IHNoYTI1Nl9maWxlKHBhY2thZ2VfcGF0aHNbInJ1bnRpbWUiXSksCiAgICAgICAgICAgICAgICAiaW5zdGFsbGVyX3NoYTI1NiI6IHNoYTI1Nl9maWxlKHBhY2thZ2VfcGF0aHNbImluc3RhbGxlciJdKSwKICAgICAgICAgICAgfSwKICAgICAgICAgICAgaW5kZW50PTIsCiAgICAgICAgKQogICAgKQogICAgcmV0dXJuIDAKCgppZiBfX25hbWVfXyA9PSAiX19tYWluX18iOgogICAgcmFpc2UgU3lzdGVtRXhpdChtYWluKCkpCg==",
    "workspace_ux_gate.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKaW1wb3J0IHN5cwpmcm9tIHBhdGhsaWIgaW1wb3J0IFBhdGgKClJPT1QgPSBQYXRoKF9fZmlsZV9fKS5yZXNvbHZlKCkucGFyZW50c1syXQpzaGVsbCA9IChST09UIC8gInVpL21haW5fd2luZG93X3NoZWxsLnB5IikucmVhZF90ZXh0KGVuY29kaW5nPSJ1dGYtOCIpCnByb2ZpbGVzID0gKFJPT1QgLyAidWkvdGhlbWVfcmVzcG9uc2l2ZS5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQpob21lID0gKFJPT1QgLyAidWkvaG9tZS5weSIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQpkYXNoYm9hcmRfdWkgPSAoUk9PVCAvICJyZXNvdXJjZXMvdWkvZGFzaGJvYXJkX3BhZ2UudWkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKbWFpbl93aW5kb3dfdWkgPSAoUk9PVCAvICJyZXNvdXJjZXMvdWkvbWFpbl93aW5kb3cudWkiKS5yZWFkX3RleHQoZW5jb2Rpbmc9InV0Zi04IikKcXNzID0gKFJPT1QgLyAicmVzb3VyY2VzL3N0eWxlLnFzcyIpLnJlYWRfdGV4dChlbmNvZGluZz0idXRmLTgiKQoKcmVxdWlyZWQgPSB7CiAgICAibmF0aXZlIHNoZWxsIGZpbGxzIGNsaWVudCBhcmVhIjoKICAgICAgICAic2VsZi5zZXRDZW50cmFsV2lkZ2V0KHNoZWxsX3Jvb3QpIiBpbiBzaGVsbCwKICAgICJuYXRpdmUgc2hlbGwgZXhwYW5kcyB0aHJvdWdoIERlc2lnbmVyIjoKICAgICAgICAnPHNpemVwb2xpY3kgaHNpemV0eXBlPSJFeHBhbmRpbmciIHZzaXpldHlwZT0iRXhwYW5kaW5nIj4nIGluIG1haW5fd2luZG93X3VpLAogICAgInN0YWJsZSBkZXNrdG9wIHJlZmVyZW5jZSBwcm9maWxlIjoKICAgICAgICAiU1RBQkxFX0xBWU9VVF9SRUZFUkVOQ0VfV0lEVEggPSAxNDQwIiBpbiBwcm9maWxlcywKICAgICJob21lIHByb2R1Y3QgaW50cm8gZXhpc3RzIjoKICAgICAgICAnbmFtZT0iSG9tZVByb2R1Y3RJbnRybyInIGluIGRhc2hib2FyZF91aSwKICAgICJob21lIGxvd2VyIGNhcmRzIGRvIG5vdCBjb25zdW1lIHZlcnRpY2FsIHN0cmV0Y2giOgogICAgICAgICJyb290LnNldFJvd1N0cmV0Y2goMiwgMCkiIGluIGhvbWUKICAgICAgICBhbmQgInJvb3Quc2V0Um93U3RyZXRjaCgzLCAxKSIgaW4gaG9tZSwKICAgICJob21lIGJyYW5jaCBjYXJkIHVzZXMgY29udGVudCBoZWlnaHQiOgogICAgICAgICJRU2l6ZVBvbGljeS5FeHBhbmRpbmcsIFFTaXplUG9saWN5Lk1heGltdW0iIGluIGhvbWUsCiAgICAiaG9tZSBicmFuY2ggZ3JpZCBpcyBzdGFibGUiOgogICAgICAgICJjb2x1bW5fY291bnQgPSA0IGlmIGxlbihhbGxvd2VkKSA+IDMgZWxzZSBtYXgoMSwgbGVuKGFsbG93ZWQpKSIgaW4gaG9tZSwKICAgICJob21lIGludHJvIHN0eWxlZCI6CiAgICAgICAgIlFMYWJlbCNIb21lUHJvZHVjdEludHJvIiBpbiBxc3MsCn0KCmZvcmJpZGRlbiA9IHsKICAgICJ3aG9sZS13aW5kb3cgZ3JhcGhpY3Mgc2NhbGluZyI6ICJRR3JhcGhpY3NWaWV3IiBpbiBzaGVsbCBvciAiUUdyYXBoaWNzU2NlbmUiIGluIHNoZWxsLAogICAgInNoZWxsIHNjcm9sbCBhcmVhIjogIlFTY3JvbGxBcmVhIiBpbiBzaGVsbCwKICAgICJsZWdhY3kgc2NhbGUgaGVscGVyIjogImZpeGVkX2NvbXBvc2l0aW9uX3NjYWxlIiBpbiBwcm9maWxlcyBvciAiZml4ZWRfY29tcG9zaXRpb25fc2NhbGUiIGluIHNoZWxsLAp9CgplcnJvcnMgPSBbbmFtZSBmb3IgbmFtZSwgb2sgaW4gcmVxdWlyZWQuaXRlbXMoKSBpZiBub3Qgb2tdCmVycm9ycyArPSBbbmFtZSBmb3IgbmFtZSwgcHJlc2VudCBpbiBmb3JiaWRkZW4uaXRlbXMoKSBpZiBwcmVzZW50XQpwcmludCgiV09SS1NQQUNFX1VYX0dBVEU9IiArICgiUEFTUyIgaWYgbm90IGVycm9ycyBlbHNlICJGQUlMIikpCmZvciBlcnJvciBpbiBlcnJvcnM6CiAgICBwcmludCgiIC0iLCBlcnJvcikKc3lzLmV4aXQoMCBpZiBub3QgZXJyb3JzIGVsc2UgMSkK",
    "write_runtime_manifest.py": "ZnJvbSBfX2Z1dHVyZV9fIGltcG9ydCBhbm5vdGF0aW9ucwoKZnJvbSBwYXRobGliIGltcG9ydCBQYXRoCmltcG9ydCBzeXMKCgpkZWYgbWFpbigpIC0+IGludDoKICAgIGlmIGxlbihzeXMuYXJndikgIT0gMjoKICAgICAgICByYWlzZSBTeXN0ZW1FeGl0KCJ1c2FnZTogd3JpdGVfcnVudGltZV9tYW5pZmVzdC5weSA8cnVudGltZS1kaXI+IikKICAgIHJ1bnRpbWUgPSBQYXRoKHN5cy5hcmd2WzFdKS5yZXNvbHZlKCkKICAgIGlmIG5vdCBydW50aW1lLmlzX2RpcigpOgogICAgICAgIHJhaXNlIFN5c3RlbUV4aXQoZiJydW50aW1lIGRpcmVjdG9yeSBub3QgZm91bmQ6IHtydW50aW1lfSIpCgogICAgdGFyZ2V0ID0gcnVudGltZSAvICJydW50aW1lX2ZpbGVzLnR4dCIKICAgIGVudHJpZXMgPSBbXQogICAgZm9yIHBhdGggaW4gcnVudGltZS5yZ2xvYigiKiIpOgogICAgICAgIGlmIG5vdCBwYXRoLmlzX2ZpbGUoKSBvciBwYXRoID09IHRhcmdldDoKICAgICAgICAgICAgY29udGludWUKICAgICAgICBlbnRyaWVzLmFwcGVuZChwYXRoLnJlbGF0aXZlX3RvKHJ1bnRpbWUpLmFzX3Bvc2l4KCkpCiAgICB0YXJnZXQud3JpdGVfdGV4dCgiXG4iLmpvaW4oc29ydGVkKGVudHJpZXMsIGtleT1zdHIuY2FzZWZvbGQpKSArICJcbiIsIGVuY29kaW5nPSJ1dGYtOCIpCiAgICBwcmludChmIldyb3RlIHt0YXJnZXR9IHdpdGgge2xlbihlbnRyaWVzKX0gZW50cmllcyIpCiAgICByZXR1cm4gMAoKCmlmIF9fbmFtZV9fID09ICJfX21haW5fXyI6CiAgICByYWlzZSBTeXN0ZW1FeGl0KG1haW4oKSkK",
}

EXCLUDED_DIR_NAMES = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".cache",
    ".tox",
    ".nox",
    ".venv",
    "venv",
    ".venv-build",
    ".vscode",
    ".idea",
    ".rollback",
    ".superpowers",
    "__MACOSX",
    "build",
    "build-agent",
    "dist",
    "dist-agent",
    "release",
    "docs",
    "tests",
}
EXCLUDED_FILE_NAMES = {
    ".DS_Store",
    "Thumbs.db",
    "desktop.ini",
    ".coverage",
    ".env",
    "BUILD_PROVENANCE.json",
    "package-manifest.json",
}
EXCLUDED_SUFFIXES = {
    ".pyc",
    ".pyo",
    ".bak",
    ".old",
    ".orig",
    ".rej",
    ".tmp",
    ".temp",
    ".log",
    ".swp",
    ".swo",
    ".zip",
    ".7z",
    ".rar",
    ".pem",
}


def _embedded_names() -> dict[str, str]:
    names: dict[str, str] = {}
    for filename in _EMBEDDED_GATES:
        stem = Path(filename).stem
        names[stem] = filename
        names[stem.replace("_", "-")] = filename
    return names


def embedded_gate_source(filename: str) -> str:
    """Return an embedded gate with the same source-tree exclusions as this audit."""
    source = base64.b64decode(_EMBEDDED_GATES[filename]).decode("utf-8")
    # The desktop contract now preserves positions on resize. The content
    # canvas scrolls; the outer shell remains native and unscaled.
    if filename in {"stable_layout_gate.py", "workspace_ux_gate.py"}:
        source = source.replace(
            '"shell scroll area": "QScrollArea" in shell,',
            '"missing stable content viewport": not all(token in shell for token in '
            '("QScrollArea", "StableWorkspaceViewport", "Qt.ScrollBarAlwaysOff", '
            '"self.workspace_viewport.setWidget(self.content_stack)")),',
        )
    if filename == "stable_layout_gate.py":
        source = source.replace(
            '\'resolved_mode in {"narrow", "compact"}\' in home',
            '\'return min(total, 3)\' in home',
        ).replace('"home metrics reflow"', '"home metrics keep three columns"')
    if filename == "responsive_release_gate.py":
        source = source.replace(
            '"about cards reflow": about_cards_reflow_present(),',
            '"about cards keep four columns": "columns = 4" in '
            '(ROOT / "ui/about.py").read_text(encoding="utf-8"),',
        )
        # The client is a fixed desktop workspace.  The supported minimum now
        # preserves the full command layout instead of forcing phone/tablet
        # reflow and scrollbars when a user resizes the native window.
        source = source.replace(
            '"main minimum reaches small layout": "app_window_min_width: int = 640" in metrics_theme,',
            '"main minimum preserves desktop composition": '
            '"app_window_min_width: int = 1360" in metrics_theme,',
        ).replace(
            '"main minimum height is compact-safe": "app_window_min_height: int = 480" in metrics_theme,',
            '"main minimum height preserves desktop composition": '
            '"app_window_min_height: int = 680" in metrics_theme,',
        )
    if filename == "audited_release_gate.py":
        source = source.replace(
            '{".venv-build", "__pycache__"}',
            '{".venv", ".venv-build", "__pycache__"}',
        )
        # pathlib.rglob still walks every package inside a build environment
        # before the gate can discard it.  Prune non-source directories during
        # traversal so release verification stays bounded on developer PCs.
        source = source.replace("import ast\n", "import ast\nimport os\n")
        source = source.replace(
            "ROOT = Path(__file__).resolve().parents[2]\n\n",
            "ROOT = Path(__file__).resolve().parents[2]\n\n"
            "\n"
            "def iter_python_files():\n"
            "    excluded = {'.git', '.venv', '.venv-build', '__pycache__'}\n"
            "    for current, directories, filenames in os.walk(ROOT):\n"
            "        directories[:] = [name for name in directories if name not in excluded]\n"
            "        for name in filenames:\n"
            "            if name.endswith('.py'):\n"
            "                yield Path(current) / name\n"
            "\n",
        )
        source = source.replace('ROOT.rglob("*.py")', "iter_python_files()")
        source = source.replace(
            'session_actions = source("ui/main_window.py")',
            'session_actions = source("ui/main_window_session.py")',
        )
    if filename == "release_source_audit.py":
        # These workstation artifacts are excluded from the package manifest;
        # retaining them in the developer source tree must not require deletion.
        source = source.replace('    ".vscode",\n', "")
        source = source.replace('    ".log",\n', "")
        source = source.replace(
            'any(part == ".venv-build" for part in path.parts)',
            'any(part in {".git", ".venv", ".venv-build", ".rollback"} for part in path.parts)',
        )
        source = source.replace(
            '".venv-build" in path.parts',
            'any(part in {".git", ".venv", ".venv-build", ".rollback"} for part in path.parts)',
        )
        source = source.replace(
            'if rel_parts and rel_parts[0] == "outputs":\n        continue',
            'if rel_parts and rel_parts[0] in {"outputs", ".rollback"}:\n        continue',
        )
        source = source.replace(
            '    "CreateInputOptionPage",\n'
            '    "CreateInputQueryPage",\n'
            "    \"'monitoring_enabled=' + BoolText(MonitoringPage.Values[0])\",\n"
            "    \"'expiry_soon_threshold_days=' + Trim(ThresholdPage.Values[0])\",\n"
            "    \"'check_updates_on_startup=' + BoolText(StartupPage.Values[1])\",\n",
            '    "CreateInputOptionPage",\n'
            "    \"'monitoring_enabled=' + BoolText(MonitoringPage.Values[0])\",\n"
            "    \"'check_updates_on_startup=' + BoolText(StartupPage.Values[1])\",\n",
        )
        source = source.replace(
            '        errors.append(f"Installer contract token missing: {required_token}")\n\n'
            "# Byte-identical duplicate payloads are usually packaging mistakes.",
            '        errors.append(f"Installer contract token missing: {required_token}")\n\n'
            'for obsolete in ("CreateInputQueryPage", "expiry_soon_threshold_days"):\n'
            "    if obsolete in installer:\n"
            '        errors.append(f"Obsolete installer setting remains: {obsolete}")\n\n'
            "# Byte-identical duplicate payloads are usually packaging mistakes.",
        )
    if filename == "sortable_tables_gate.py":
        # Administration table implementations were extracted into the shared
        # component owner. Keep the gate bound to that implementation rather
        # than requiring a stale compatibility import in AdministrationPage.
        source = source.replace(
            '(ROOT / "ui/administration.py")',
            '(ROOT / "ui/administration_components.py")',
        )
    if filename == "stable_layout_gate.py":
        source = source.replace(
            '"usage toolbar reflows": "semantic = layout_mode_for_width(available_width)" in usage,',
            '"usage toolbar reflows": "apply_toolbar_control_metrics(" in usage '
            'and \'if mode != "small":\' in usage and \'if mode == "compact":\' in usage,',
        )
    if filename == "workspace_ux_gate.py":
        source = source.replace(
            '"root.setRowStretch(2, 0)" in home\n'
            '        and "root.setRowStretch(3, 1)" in home,',
            '"root.setStretch(0, 0)" in home\n'
            '        and "root.setStretch(1, 1)" in home\n'
            '        and "self.lower_grid.setRowStretch(0, 0)" in home,',
        )
    if filename == "shell_ownership_gate.py":
        source = source.replace(
            '"stable shell root reused": \'central = getattr(window, "_stable_shell_root", None)\' in window_source,',
            '"stable shell root reused": \'self._stable_shell_root = shell_root\' in layout_source,',
        )
        source = source.replace(
            '"fallback app_root lookup retained": \'window.findChild(QWidget, "app_root")\' in window_source,',
            '"Designer app_root owns initial shell": \'central = controls["app_root"]\' in layout_source,',
        )
    if filename == "responsive_release_gate.py":
        source = source.replace(
            '"administration selector owns compact reachability": "self.copy_host.setVisible(not self._compact)" in administration,',
            '"administration selector owns compact reachability": '
            '"self.route_selector.setVisible(bool(self.route_selector.count()))" '
            'in administration and "self.route_hint.setVisible(not self._compact)" in administration,',
        )
    if filename == "responsive_release_gate.py":
        # AdministrationWorkspaceHeader moved with the reusable administration
        # widgets.  The release gate must inspect both the page composer and
        # that owner instead of requiring implementation details to remain in
        # the composer merely to satisfy a textual check.
        source = source.replace(
            'administration = (ROOT / "ui/administration.py").read_text(encoding="utf-8")',
            'administration = (ROOT / "ui/administration.py").read_text(encoding="utf-8") + "\\n" + (ROOT / "ui/administration_components.py").read_text(encoding="utf-8")',
        )
    return source


def load_embedded_namespace(command: str) -> dict[str, object]:
    names = _embedded_names()
    filename = names.get(command)
    if filename is None:
        raise KeyError(command)
    source = embedded_gate_source(filename)
    fake_file = ROOT / "ops" / "__audit_embedded__" / filename
    namespace: dict[str, object] = {
        "__name__": f"_herfy_audit_{Path(filename).stem}",
        "__file__": str(fake_file),
        "__package__": None,
    }
    exec(compile(source, str(fake_file), "exec"), namespace)
    return namespace


def run_embedded_gate(command: str, argv: list[str]) -> int:
    names = _embedded_names()
    filename = names.get(command)
    if filename is None:
        raise SystemExit(f"unknown audit command: {command}")
    source = embedded_gate_source(filename)
    previous_argv = sys.argv[:]
    fake_file = ROOT / "ops" / "__audit_embedded__" / filename
    namespace = {
        "__name__": "__main__",
        "__file__": str(fake_file),
        "__package__": None,
    }
    sys.argv = [str(Path(__file__).resolve()), *argv]
    try:
        try:
            exec(compile(source, str(fake_file), "exec"), namespace)
        except SystemExit as exc:
            # Embedded gates use SystemExit with a human-readable diagnostic.
            # Preserve it for release operators instead of returning a silent
            # non-zero status that cannot be investigated safely.
            if isinstance(exc.code, str) and exc.code:
                print(exc.code, file=sys.stderr)
            return int(exc.code or 0) if isinstance(exc.code, int) else 1
    finally:
        sys.argv = previous_argv
    return 0


def _excluded(relative: Path, *, include_development: bool = False) -> bool:
    if relative.as_posix() in _PUBLIC_RELEASE_FILES:
        return False
    # Development archives retain their source material, not its generated
    # by-products.  Keep the docs/tests roots when requested while applying
    # every other exclusion (notably nested __pycache__ directories).
    excluded_directories = EXCLUDED_DIR_NAMES
    if include_development:
        excluded_directories = EXCLUDED_DIR_NAMES - {"docs", "tests"}
    if any(part in excluded_directories for part in relative.parts):
        return True
    if relative.name in EXCLUDED_FILE_NAMES:
        return True
    if relative.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    if relative.name.lower().endswith((".pfx", ".p12")):
        return True
    return False


def package_release(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(prog="audit.py package-release")
    parser.add_argument("-SourcePath", "--source-path", dest="source_path", required=True)
    parser.add_argument("-OutputPath", "--output-path", dest="output_path", required=True)
    parser.add_argument(
        "--include-development",
        action="store_true",
        help="include tests and documentation for the complete source archive",
    )
    ns = parser.parse_args(argv)
    source = Path(ns.source_path).resolve()
    output = Path(ns.output_path).resolve()
    if not source.is_dir():
        raise SystemExit(f"source not found: {source}")
    entries: list[Path] = []
    excluded: set[str] = set()
    for current, dirs, files in os.walk(source):
        current_path = Path(current)
        rel_current = current_path.relative_to(source)
        kept_dirs = []
        for d in dirs:
            rel = rel_current / d if rel_current.parts else Path(d)
            if _excluded(rel, include_development=ns.include_development):
                excluded.add(d)
            else:
                kept_dirs.append(d)
        dirs[:] = kept_dirs
        for filename in files:
            path = current_path / filename
            rel = path.relative_to(source)
            if _excluded(rel, include_development=ns.include_development) or path == output:
                excluded.add(rel.as_posix())
                continue
            entries.append(rel)
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = {
        "format": 1,
        "source": source.name,
        "development_material_included": bool(ns.include_development),
        "file_count": len(entries) + 1,
        "excluded_patterns": sorted(EXCLUDED_DIR_NAMES | EXCLUDED_FILE_NAMES | EXCLUDED_SUFFIXES),
    }
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for rel in sorted(entries, key=lambda p: p.as_posix().casefold()):
            archive.write(source / rel, rel.as_posix())
        archive.writestr(
            "package-manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
        )
    print(f"PACKAGE_RELEASE=PASS files={manifest['file_count']} output={output}")
    return 0


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        print("usage: audit.py <command> [args...]", file=sys.stderr)
        return 2
    command, rest = args[0], args[1:]
    if command in {"source-quality", "source_quality"}:
        return source_quality()
    if command in {"package-release", "package_release"}:
        return package_release(rest)
    return run_embedded_gate(command, rest)


if __name__ == "__main__":
    raise SystemExit(main())
