# -*- mode: python ; coding: utf-8 -*-
import sys
from pathlib import Path

ROOT = Path(SPECPATH).parents[1]
sys.path.insert(0, str(Path(SPECPATH)))
from version_resource import write_windows_version_resource

ICON = str(ROOT / "resources" / "images" / "app_icon.ico")
VERSION_INFO_FILE = write_windows_version_resource(
    ROOT / "version.json",
    ROOT / "build-agent" / "HERFY-TSUpdateAgent.version-info",
    product_name="HERFY-TS",
    description="HERFY-TS Update Agent",
    original_filename="HERFY-TSUpdateAgent.exe",
)
CONTRACT_DATA = [
    (str(path), "contracts")
    for path in ROOT.joinpath("contracts").glob("*.json")
]

a = Analysis(
    [str(ROOT / "infra" / "updater.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=[
        (str(ROOT / "version.json"), "."),
        *CONTRACT_DATA,
    ],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="HERFY-TSUpdateAgent",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=True,
    icon=ICON,
    version=str(VERSION_INFO_FILE),
)
