from __future__ import annotations

import json
import re
from pathlib import Path

_VERSION_PATTERN = re.compile(r"(\d+)\.(\d+)\.(\d+)\Z")


def write_windows_version_resource(
    version_json: Path,
    output_path: Path,
    *,
    product_name: str,
    description: str,
    original_filename: str,
) -> Path:
    version_data = json.loads(version_json.read_text(encoding="utf-8"))
    version = version_data.get("version")
    match = _VERSION_PATTERN.fullmatch(version) if isinstance(version, str) else None
    if match is None:
        raise ValueError(f"Unsupported application version in {version_json}.")

    version_parts = tuple(int(part) for part in match.groups())
    if any(part > 65535 for part in version_parts):
        raise ValueError(f"Application version exceeds Windows version limits: {version}.")

    fixed_version = (*version_parts, 0)
    strings = {
        "CompanyName": "HERFY",
        "FileDescription": description,
        "FileVersion": version,
        "InternalName": product_name,
        "OriginalFilename": original_filename,
        "ProductName": product_name,
        "ProductVersion": version,
    }
    string_rows = ",\n".join(
        f"            StringStruct({key!r}, {value!r})"
        for key, value in strings.items()
    )
    content = f"""VSVersionInfo(
  ffi=FixedFileInfo(
    filevers={fixed_version!r},
    prodvers={fixed_version!r},
    mask=0x3f,
    flags=0x0,
    OS=0x4,
    fileType=0x1,
    subtype=0x0,
    date=(0, 0)
  ),
  kids=[
    StringFileInfo([
      StringTable(
        u'040904B0',
        [
{string_rows}
        ])
    ]),
    VarFileInfo([VarStruct(u'Translation', [1033, 1200])])
  ]
)
"""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(content, encoding="utf-8")
    return output_path
