#define MyAppName "HERFY-TS"
#ifndef MyAppVersion
#define MyAppVersion "2.21.12"
#endif
#ifndef MyAppPublisher
  #define MyAppPublisher "HERFY"
#endif
#define MyAppExeName "HERFY-TS.exe"
#define MyAppUserModelID "Herfy.HerfyClient"

[Setup]
AppId=HERFY-TS
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
VersionInfoCompany={#MyAppPublisher}
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoDescription=HERFY-TS
UninstallDisplayName=HERFY-TS
DefaultDirName={autopf}\HERFY-TS
DefaultGroupName=HERFY-TS
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\..\release
OutputBaseFilename=HERFY-TS-Setup-{#MyAppVersion}-windows-x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=yes
DisableReadyPage=yes
DisableFinishedPage=yes
LicenseFile=TERMS-AND-CONDITIONS.txt
WizardImageFile=wizard-large.bmp
WizardSmallImageFile=wizard-small.bmp
SetupIconFile=..\..\resources\images\app_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
CloseApplications=yes
RestartApplications=no
SetupLogging=yes

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"

[Files]
Source: "..\..\dist\HERFY-TS\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\HERFY-TS"; Filename: "{app}\{#MyAppExeName}"; AppUserModelID: "{#MyAppUserModelID}"
Name: "{autodesktop}\HERFY-TS"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon; AppUserModelID: "{#MyAppUserModelID}"

[Tasks]
Name: "desktopicon"; Description: "Desktop shortcut"; Flags: checkedonce

[Registry]
Root: HKLM64; Subkey: "Software\Classes\herfy-ts"; ValueType: string; ValueName: ""; ValueData: "URL:HERFY-TS Protocol"; Flags: uninsdeletekey
Root: HKLM64; Subkey: "Software\Classes\herfy-ts"; ValueType: string; ValueName: "URL Protocol"; ValueData: ""
Root: HKLM64; Subkey: "Software\Classes\herfy-ts\DefaultIcon"; ValueType: string; ValueName: ""; ValueData: "{app}\{#MyAppExeName},0"
Root: HKLM64; Subkey: "Software\Classes\herfy-ts\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#MyAppExeName}"" ""%1"""

[UninstallDelete]
Type: files; Name: "{app}\installer_defaults.ini"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch HERFY-TS"; Flags: nowait postinstall skipifsilent

[Code]

var
  MonitoringPage: TInputOptionWizardPage;
  StartupPage: TInputOptionWizardPage;

function LocalText(EnglishText, ArabicText: String): String;
begin
  if CompareText(ActiveLanguage, 'arabic') = 0 then
    Result := ArabicText
  else
    Result := EnglishText;
end;

function AppLanguageCode: String;
begin
  if CompareText(ActiveLanguage, 'arabic') = 0 then
    Result := 'ar'
  else
    Result := 'en';
end;

function BoolText(Value: Boolean): String;
begin
  if Value then
    Result := 'True'
  else
    Result := 'False';
end;

procedure InitializeWizard;
begin
  MonitoringPage := CreateInputOptionPage(
    wpSelectTasks,
    LocalText('HERFY initial settings', 'إعدادات HERFY الأولية'),
    LocalText('Monitoring and notifications', 'المراقبة والتنبيهات'),
    LocalText(
      'Choose the initial monitoring preferences. You can change them later from Settings.',
      'اختر إعدادات المراقبة الأولية. يمكنك تغييرها لاحقاً من الإعدادات.'
    ),
    False,
    False
  );
  MonitoringPage.Add(LocalText('Enable local expiry monitoring', 'تفعيل مراقبة الصلاحية المحلية'));
  MonitoringPage.Add(LocalText('Enable Windows desktop notifications', 'تفعيل تنبيهات سطح مكتب Windows'));
  MonitoringPage.Add(LocalText('Enable notification sounds', 'تفعيل أصوات التنبيهات'));
  MonitoringPage.Values[0] := True;
  MonitoringPage.Values[1] := True;
  MonitoringPage.Values[2] := True;

  StartupPage := CreateInputOptionPage(
    MonitoringPage.ID,
    LocalText('Startup and updates', 'بدء التشغيل والتحديثات'),
    LocalText('Application startup preferences', 'تفضيلات بدء تشغيل التطبيق'),
    LocalText(
      'Choose the initial Windows startup and update-check preferences.',
      'اختر إعدادات بدء التشغيل والتحقق من التحديثات الأولية.'
    ),
    False,
    False
  );
  StartupPage.Add(LocalText('Start HERFY with Windows', 'تشغيل HERFY مع Windows'));
  StartupPage.Add(LocalText('Check for signed updates at startup', 'التحقق من التحديثات الموقعة عند بدء التشغيل'));
  StartupPage.Values[0] := True;
  StartupPage.Values[1] := True;
end;

procedure WriteInstallerDefaults;
var
  DefaultsPath: String;
  Payload: AnsiString;
begin
  DefaultsPath := ExpandConstant('{app}\installer_defaults.ini');
  Payload :=
    'language=' + AppLanguageCode + #13#10 +
    'monitoring_enabled=' + BoolText(MonitoringPage.Values[0]) + #13#10 +
    'enable_tray_background=True' + #13#10 +
    'enable_desktop_notifications=' + BoolText(MonitoringPage.Values[1]) + #13#10 +
    'enable_sounds=' + BoolText(MonitoringPage.Values[2]) + #13#10 +
    'expiry_enable_status_colors=True' + #13#10 +
    'expiry_enable_status_icons=True' + #13#10 +
    'start_with_windows=' + BoolText(StartupPage.Values[0]) + #13#10 +
    'check_updates_on_startup=' + BoolText(StartupPage.Values[1]) + #13#10 +
    'tray_show_message_on_minimize=False' + #13#10 +
    'usage_hide_total_zero=False' + #13#10 +
    'ui_scale_percent=100' + #13#10;

  if not SaveStringToFile(DefaultsPath, Payload, False) then
    RaiseException('Unable to write HERFY-TS defaults.');
end;

function IsRemoteUpdate: Boolean;
begin
  Result := CompareText(ExpandConstant('{param:REMOTEUPDATE|0}'), '1') = 0;
end;

procedure DeleteRemoteUpdateMarker;
var
  MarkerPath: String;
begin
  MarkerPath := ExpandConstant('{app}\.update_success.json');
  if FileExists(MarkerPath) then
  begin
    if not DeleteFile(MarkerPath) then
      RaiseException('Unable to remove the previous HERFY-TS update success marker.');
  end;
end;

procedure CleanupInstalledRuntime;
var
  AppRoot: String;
  AgentExe: String;
  DiagnosticFile: String;
  ResultCode: Integer;
begin
  AppRoot := ExpandConstant('{app}');
  AgentExe := ExpandConstant('{app}\HERFY-TSUpdateAgent.exe');
  DiagnosticFile := ExpandConstant('{tmp}\HERFY-TS-runtime-cleanup.json');

  if FileExists(DiagnosticFile) then
    DeleteFile(DiagnosticFile);

  if not Exec(
    AgentExe,
    '--cleanup-installed-runtime --root "' + AppRoot + '" --diagnostic "' + DiagnosticFile + '"',
    AppRoot,
    SW_HIDE,
    ewWaitUntilTerminated,
    ResultCode
  ) then
    RaiseException('Unable to start HERFY-TS installed runtime cleanup.');

  if ResultCode <> 0 then
    RaiseException('HERFY-TS installed runtime cleanup failed with exit code ' + IntToStr(ResultCode) + '. Diagnostic: ' + DiagnosticFile);

  DeleteFile(DiagnosticFile);
end;

procedure VerifyInstalledRuntime;
var
  AppRoot: String;
  AppExe: String;
  CheckFile: String;
  ResultCode: Integer;
begin
  AppRoot := ExpandConstant('{app}');
  AppExe := ExpandConstant('{app}\{#MyAppExeName}');
  CheckFile := ExpandConstant('{tmp}\HERFY-TS-remote-update-self-check.json');

  if FileExists(CheckFile) then
  begin
    if not DeleteFile(CheckFile) then
      RaiseException('Unable to clear the previous HERFY-TS self-check result.');
  end;

  if not Exec(
    AppExe,
    '--self-check --self-check-file "' + CheckFile + '"',
    AppRoot,
    SW_HIDE,
    ewWaitUntilTerminated,
    ResultCode
  ) then
    RaiseException('Unable to start the installed HERFY-TS self-check.');

  if ResultCode <> 0 then
    RaiseException('Installed HERFY-TS self-check failed with exit code ' + IntToStr(ResultCode) + '.');

  if not FileExists(CheckFile) then
    RaiseException('Installed HERFY-TS self-check did not produce its verification file.');

  DeleteFile(CheckFile);
end;

procedure WriteRemoteUpdateMarker;
var
  MarkerPath: String;
  MarkerPayload: AnsiString;
begin
  MarkerPath := ExpandConstant('{app}\.update_success.json');
  MarkerPayload := '{"status":"ok","version":"{#MyAppVersion}"}' + #13#10;

  if not SaveStringToFile(MarkerPath, MarkerPayload, False) then
    RaiseException('Unable to write the HERFY-TS update success marker.');
end;

procedure RestartRemoteUpdateAsOriginalUser;
var
  AppRoot: String;
  AppExe: String;
  ResultCode: Integer;
begin
  AppRoot := ExpandConstant('{app}');
  AppExe := ExpandConstant('{app}\{#MyAppExeName}');

  if not ExecAsOriginalUser(
    AppExe,
    '',
    AppRoot,
    SW_SHOWNORMAL,
    ewNoWait,
    ResultCode
  ) then
  begin
    Log('HERFY-TS remote update installed successfully, but automatic restart as the original user failed.');
  end;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssInstall) and IsRemoteUpdate then
  begin
    DeleteRemoteUpdateMarker;
  end
  else if CurStep = ssPostInstall then
  begin
    CleanupInstalledRuntime;
    WriteInstallerDefaults;

    if IsRemoteUpdate then
    begin
      VerifyInstalledRuntime;
      WriteRemoteUpdateMarker;
    end;
  end
  else if (CurStep = ssDone) and IsRemoteUpdate then
  begin
    RestartRemoteUpdateAsOriginalUser;
  end;
end;
