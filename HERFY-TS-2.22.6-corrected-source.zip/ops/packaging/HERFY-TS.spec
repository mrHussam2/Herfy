# -*- mode: python ; coding: utf-8 -*-
import sys
from pathlib import Path

ROOT = Path(SPECPATH).parents[1]
sys.path.insert(0, str(Path(SPECPATH)))
from version_resource import write_windows_version_resource

ICON = str(ROOT / "resources" / "images" / "app_icon.ico")
VERSION_INFO_FILE = write_windows_version_resource(
    ROOT / "version.json",
    ROOT / "build" / "HERFY-TS.version-info",
    product_name="HERFY-TS",
    description="HERFY-TS Client",
    original_filename="HERFY-TS.exe",
)
CONTRACT_DATA = [
    (str(path), "contracts")
    for path in ROOT.joinpath("contracts").glob("*.json")
]
RESOURCE_DATA = [
    (str(path), str(path.relative_to(ROOT).parent))
    for path in ROOT.joinpath("resources").rglob("*")
    if path.is_file()
    and path.suffix.lower() not in {".py", ".pyc", ".pyo"}
    and "__pycache__" not in path.parts
]

a = Analysis(
    [str(ROOT / "main.py")],
    pathex=[str(ROOT)],
    binaries=[],
    datas=[
        *RESOURCE_DATA,
        *CONTRACT_DATA,
        (str(ROOT / "version.json"), "."),
        (str(ROOT / "BUILD_PROVENANCE.json"), "."),
    ],
    hiddenimports=[
        "PySide6.QtCharts",
        "PySide6.QtMultimedia",
        "win32api",
        "win32con",
        "win32gui",
        "win32timezone",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="HERFY-TS",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    icon=ICON,
    version=str(VERSION_INFO_FILE),
    contents_directory=".",
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="HERFY-TS",
)
