# HERFY-TS Qt Designer forms

Open the required `.ui` file in Qt Designer, save it, then reopen the related
screen in a development run. The application loads the source file directly;
there is no generated Python form file to overwrite controller code.

Do not rename a widget's `objectName` unless its Python consumer and its test
are updated together. The current active contracts are:

- `main_window.ui`: `shell_sidebar_host`, `shell_top_bar_host`,
  `content_stack_host`.
- `login_page.ui`: `login_username`, `login_password`, `login_submit`,
  `LoginRememberCheck`, `LoginProgress`, and `LoginStatusLabel`.
- `usage_page.ui`: `usage_receipts`, `usage_opening`, `usage_search`,
  `usage_hide_zero`, `usage_print`, `UsageTable`, and `usage_table_host`.
- `tracking_page.ui`: `tracking_branch`, `tracking_product`,
  `tracking_quantity`, `tracking_production`, `tracking_expiry`,
  `tracking_save`, `TrackingProductsTable`, and `tracking_table_host`.

Use layouts, stretch factors, and size policies instead of fixed screen-sized
geometry. The application applies the responsive profile after each screen is
loaded, including DPI, RTL, narrow-window, and touch-target adjustments.

For a signed production release, rebuild and sign after saving a `.ui` file.
Do not edit `.ui` files inside an installed package: the update and signing
chain intentionally treats the installed program as immutable.
