# HERFY-TS Development Guide

This folder is the clean HERFY-TS 2.21.12 source tree. It preserves the Python
application, Qt Designer sources, runtime assets, and the project's existing
build, installer, signing, and release scripts. Tests, build outputs, and
machine-local Python environments are intentionally excluded from the source
archive; run the test suite from the canonical development repository.

## Requirements

- Windows x64.
- CPython 3.11 x64 for the official `ops/build.ps1` release build. The
  application also supports Python 3.12; the source was verified with Python
  3.12.15.
- PowerShell, Windows SDK SignTool, Inno Setup 6, and network access to install
  dependencies. SignTool and Inno Setup are needed only for their respective
  release steps.

## Use an approved development environment

Use the project-approved Python environment already provisioned on the build
host. Do not create a virtual environment from this source archive during a
release or verification run. The official release build uses the existing
`.venv-build` environment with CPython 3.11 x64. On a provisioned host without
that folder, pass `-BuildPython 'C:\Program Files\Python311\python.exe' -SkipInstall`
to use its existing CPython 3.11 dependencies. The build never creates a virtual
environment. The same `-BuildPython` option is available for publication verification.

## Run the application

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
python .\main.py
```

The application loads resources from the source tree through the resource
helpers. Do not run from a copied or installed directory containing a different
version of the source.

## Run source quality checks

```powershell
$env:PYTHONDONTWRITEBYTECODE = '1'
python -m compileall -q .\core .\infra .\services .\ui .\ops .\main.py .\version.py
python -m ruff check .
```

Require `python -m ruff check .` to pass with no findings. Do not disable rules
or exclude source files to hide lint violations. Tests are intentionally not
distributed in this source archive; run pytest from the canonical development
repository, where the maintained test suite lives.

## Edit Qt Designer forms

Open the required `.ui` file under `resources\ui\` in Qt Designer, save it, and
run the focused Designer and UI regression tests. Forms are loaded at runtime
with `QUiLoader`; there are no checked-in generated Python form classes.
Preserve `objectName` values consumed by Python, and update the consumer and
regression tests together if a name must change. See
`resources\ui\README.md` for the active Designer contracts.

## Build the application and installer

Install CPython 3.11 x64, the project dependencies, and Inno Setup 6, then run
from the source root:

```powershell
.\ops\build.ps1
```

The script runs the release audits and regression suite, prepares provenance,
builds both frozen executables, validates their self-checks, and creates the
installer under `release\`. Do not package stale files from an earlier `dist\`
directory. Inspect the generated runtime manifest, executable metadata, build
logs, and installer hash before approving a release.

## Signing and publication

Update signing (the HERFY manifest/package signature) and Windows Authenticode
signing are separate trust mechanisms. Use the existing `ops\release.ps1`
pipeline and its preflight before signing. It requires an authorized
code-signing certificate thumbprint, an HTTPS timestamp URL, and the path to
the authorized offline update private key. Keep private-key passphrases out of
command arguments, scripts, environment dumps, logs, source, and archives; use
only the approved protected prompt/secret-store flow.

`ops\publish.ps1` is a production-writing operation. Do not run it until
signature verification, installer testing, historical update compatibility,
server backup, staging, and rollback gates have passed. Never disable SSH host
key verification or upload a private key.

## Versioning and future releases

For a future release (for example 2.21.10), first review the release and update
protocol contracts. Update the version fields in `version.json`,
`contracts\version.json`, `pyproject.toml`, and the Installer's fallback
version in `ops\packaging\HERFY-TS.iss` together. Update contract identities
only through the repository's documented contract process; never accept an old
contract or signing key merely to make a new client pass. Run the full source
and release gates, then use `ops\build.ps1` so build provenance and executable
version resources are regenerated from the verified source. Sign and publish
only through the approved release pipeline after every required gate passes.
