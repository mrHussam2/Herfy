param([string]$Python = "python")
$env:QT_QPA_PLATFORM = "offscreen"
& $Python -m pytest tests -q -p no:cacheprovider
exit $LASTEXITCODE
