from __future__ import annotations

from urllib.parse import parse_qs, urlencode, urlparse

SCHEME = "herfy-ts"


def build_notification_activation_uri(payload: dict | None) -> str:
    """Build a minimal local activation URI for a Windows notification.

    Only routing identifiers are included.  No authentication/session material is
    ever placed in the URI.  Authorization is re-checked by the running window
    before any branch/product is shown.
    """
    data = dict(payload or {})
    branch = str(data.get("branch") or data.get("branch_id") or "").strip()
    material = str(
        data.get("material_number") or data.get("product_id") or data.get("material") or ""
    ).strip()
    if not branch and not material:
        return f"{SCHEME}://notifications"
    query = urlencode(
        {key: value for key, value in (("branch", branch), ("material", material)) if value}
    )
    return f"{SCHEME}://notification?{query}"


def parse_notification_activation_uri(value: str) -> tuple[str, dict]:
    """Return (action, payload) for a HERFY local activation URI."""
    text = str(value or "").strip()
    try:
        parsed = urlparse(text)
    except ValueError:
        return ("", {})
    if parsed.scheme.casefold() != SCHEME:
        return ("", {})
    action = str(parsed.netloc or parsed.path.lstrip("/") or "").strip().casefold()
    if action == "notifications":
        return ("notifications", {})
    if action != "notification":
        return ("", {})
    params = parse_qs(parsed.query, keep_blank_values=False)
    branch = str((params.get("branch") or [""])[0]).strip()
    material = str((params.get("material") or [""])[0]).strip()
    # Bound data accepted from the OS protocol surface before it reaches the UI.
    if len(branch) > 128 or len(material) > 128:
        return ("", {})
    if not branch and not material:
        return ("notifications", {})
    return (
        "notification",
        {
            "branch": branch,
            "material_number": material,
        },
    )


def activation_uri_from_arguments(arguments: list[str] | tuple[str, ...] | None) -> str:
    for argument in list(arguments or ()):
        value = str(argument or "").strip()
        if value.casefold().startswith(f"{SCHEME}://"):
            return value
    return ""


__all__ = [
    "SCHEME",
    "activation_uri_from_arguments",
    "build_notification_activation_uri",
    "parse_notification_activation_uri",
]
