from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, Protocol

from core.errors import RemoteRequestError

# --- HTTP transport port ---


@dataclass(frozen=True)
class HttpTransportPort:
    api_request: Callable[..., Any]
    api_fetch_json: Callable[..., dict[str, Any]]
    api_post_json: Callable[..., dict[str, Any]]
    get_server_base_url: Callable[..., str]
    get_updates_base_url: Callable[..., str]
    close_all_thread_sessions: Callable[[], None]


_transport: HttpTransportPort | None = None


def configure_http_transport(transport: HttpTransportPort) -> None:
    global _transport
    _transport = transport


def _require_transport() -> HttpTransportPort:
    if _transport is None:
        raise RemoteRequestError("HTTP transport adapter is not configured.")
    return _transport


def api_request(
    method: str, path_or_url: str, *, base_url: str | None = None, **kwargs: Any
) -> Any:
    return _require_transport().api_request(method, path_or_url, base_url=base_url, **kwargs)


def api_fetch_json(
    path_or_url: str, *, base_url: str | None = None, **kwargs: Any
) -> dict[str, Any]:
    payload = _require_transport().api_fetch_json(path_or_url, base_url=base_url, **kwargs)
    return payload if isinstance(payload, dict) else {}


def api_post_json(
    path_or_url: str,
    payload: dict[str, Any] | None = None,
    *,
    base_url: str | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """POST a JSON payload through the configured transport.

    The request payload is positional because callers supply it alongside the
    endpoint when performing authentication refreshes and related operations.
    """
    request_payload = payload if isinstance(payload, dict) else {}
    response_payload = _require_transport().api_post_json(
        path_or_url, request_payload, base_url=base_url, **kwargs
    )
    return response_payload if isinstance(response_payload, dict) else {}


def _configured_base_url(
    accessor: Literal["get_server_base_url", "get_updates_base_url"],
    default: str | None = None,
) -> str:
    """Read one configured transport URL while preserving safe startup defaults."""
    if _transport is None:
        if default is not None:
            return str(default or "").strip()
        raise RemoteRequestError("HTTP transport adapter is not configured.")
    getter = getattr(_transport, accessor)
    if default is None:
        return str(getter()).strip()
    return str(getter(default)).strip()


def get_server_base_url(default: str | None = None) -> str:
    """Return the configured API base URL.

    During isolated UI construction/tests the HTTP transport may not be configured yet.
    When a caller provides a default, keep the call safe and return that default instead
    of raising before the application bootstrap has installed the real transport.
    """
    return _configured_base_url("get_server_base_url", default)


def get_updates_base_url(default: str | None = None) -> str:
    """Return the configured update-repository base URL."""
    return _configured_base_url("get_updates_base_url", default)


def close_all_thread_sessions() -> None:
    if _transport is not None:
        _transport.close_all_thread_sessions()


# --- startup registration port ---


@dataclass(frozen=True)
class StartupRegistrationPort:
    sync_startup_from_preferences: Callable[[Mapping[str, bool]], bool]


_startup_registration_port: StartupRegistrationPort | None = None


def configure_startup_registration(port: StartupRegistrationPort) -> None:
    global _startup_registration_port
    _startup_registration_port = port


def sync_startup_from_preferences(preferences: Mapping[str, bool]) -> bool:
    if _startup_registration_port is None:
        return False
    return bool(_startup_registration_port.sync_startup_from_preferences(preferences))


# --- desktop notification port ---


@dataclass(frozen=True)
class DesktopNotificationPort:
    send_windows_toast: Callable[..., Any]
    capability_snapshot: Callable[[], Mapping[str, object]] | None = None


_desktop_notification_port: DesktopNotificationPort | None = None


def configure_desktop_notifications(port: DesktopNotificationPort) -> None:
    global _desktop_notification_port
    _desktop_notification_port = port


def send_windows_toast(*, title: str, message: str, activation_uri: str = ""):
    if _desktop_notification_port is None:
        return None
    return _desktop_notification_port.send_windows_toast(
        title=title,
        message=message,
        activation_uri=str(activation_uri or ""),
    )


def desktop_notification_capability() -> dict[str, object]:
    if _desktop_notification_port is None or not callable(
        _desktop_notification_port.capability_snapshot
    ):
        return {}
    return dict(_desktop_notification_port.capability_snapshot() or {})


# --- device identity port ---


class DeviceIdentityPort(Protocol):
    def get_device_id(self) -> str: ...


_device_identity_port: DeviceIdentityPort | None = None


def configure_device_identity(port: DeviceIdentityPort) -> None:
    global _device_identity_port
    _device_identity_port = port


def get_device_id() -> str:
    if _device_identity_port is None:
        raise RuntimeError("Device identity adapter is not configured.")
    value = str(_device_identity_port.get_device_id()).strip()
    if not value:
        raise RuntimeError("Device identity adapter returned an empty identifier.")
    return value


# --- application event port ---


@dataclass(frozen=True)
class ApplicationEventPort:
    emit_updated: Callable[[str, Any], None]
    emit_deleted: Callable[[str, Any], None]
    emit_data_changed: Callable[[str, Any], None]


_application_event_port: ApplicationEventPort | None = None


def configure_application_events(port: ApplicationEventPort) -> None:
    global _application_event_port
    _application_event_port = port


def emit_updated(domain: str, payload: Any = None) -> None:
    if _application_event_port is not None:
        _application_event_port.emit_updated(str(domain or "").strip().lower(), payload)


def emit_deleted(domain: str, payload: Any = None) -> None:
    if _application_event_port is not None:
        _application_event_port.emit_deleted(str(domain or "").strip().lower(), payload)


def emit_data_changed(domain: str, payload: Any = None) -> None:
    if _application_event_port is not None:
        _application_event_port.emit_data_changed(str(domain or "").strip().lower(), payload)


# --- tabular input port ---


class TabularInputReader(Protocol):
    """Read a user-selected tabular file into raw row values."""

    def read_rows(self, path: str | Path) -> list[list[Any]]: ...


# --- update security port ---


@dataclass(frozen=True)
class UpdateSecurityPort:
    verify_manifest: Callable[[Mapping[str, Any]], None]
    verify_signed_manifest_response: Callable[[Any], dict[str, Any]]


_update_security_port: UpdateSecurityPort | None = None


def configure_update_security(port: UpdateSecurityPort) -> None:
    global _update_security_port
    _update_security_port = port


def _require_update_security_port() -> UpdateSecurityPort:
    if _update_security_port is None:
        raise RuntimeError("Update security adapter is not configured.")
    return _update_security_port


def verify_update_manifest(payload: Mapping[str, Any]) -> None:
    _require_update_security_port().verify_manifest(payload)


def verify_signed_update_manifest_response(response: Any) -> dict[str, Any]:
    payload = _require_update_security_port().verify_signed_manifest_response(response)
    if not isinstance(payload, dict):
        raise RuntimeError("Signed update manifest payload is invalid")
    return payload
