from __future__ import annotations

import os
import subprocess
from collections.abc import Sequence
from pathlib import Path
from typing import Any, cast


def _resolve_cwd(cwd: str | Path | None) -> str | None:
    if cwd is None:
        return None
    resolved = Path(cwd).expanduser().resolve()
    if not resolved.is_dir():
        raise RuntimeError(f"Process working directory does not exist: {resolved}")
    return str(resolved)


def _normalize_command(command: Sequence[str | Path]) -> list[str]:
    args = [str(item) for item in command]
    if not args or not args[0].strip():
        raise RuntimeError("Cannot launch an empty process command")
    return args


def launch_detached(command: Sequence[str | Path], *, cwd: str | Path | None = None) -> None:
    args = _normalize_command(command)
    options: dict[str, Any] = {
        "cwd": _resolve_cwd(cwd),
        "close_fds": True,
        "stdin": subprocess.DEVNULL,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
    }
    if os.name == "nt":
        options["creationflags"] = int(
            getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        )
    else:
        options["start_new_session"] = True
    subprocess.Popen(args, **cast(Any, options))  # noqa: S603


def launch_elevated_detached(
    command: Sequence[str | Path], *, cwd: str | Path | None = None,
    show_window: bool = False,
) -> None:
    """Launch a trusted executable with Windows UAC elevation without shell parsing.

    Program Files is intentionally not user-writable. Online updates therefore
    cross the elevation boundary explicitly instead of relying on CreateProcess,
    which cannot satisfy a require-administrator operation from a standard user.
    """
    args = _normalize_command(command)
    resolved_cwd = _resolve_cwd(cwd)
    if os.name != "nt":
        launch_detached(args, cwd=resolved_cwd)
        return

    executable = Path(args[0]).expanduser().resolve()
    if not executable.is_file():
        raise RuntimeError(f"Elevated executable does not exist: {executable}")

    import ctypes
    from ctypes import wintypes

    shell_execute = ctypes.windll.shell32.ShellExecuteW
    shell_execute.argtypes = [
        wintypes.HWND,
        wintypes.LPCWSTR,
        wintypes.LPCWSTR,
        wintypes.LPCWSTR,
        wintypes.LPCWSTR,
        ctypes.c_int,
    ]
    shell_execute.restype = ctypes.c_void_p
    parameters = subprocess.list2cmdline(args[1:]) if len(args) > 1 else None
    result = shell_execute(
        None,
        "runas",
        str(executable),
        parameters,
        resolved_cwd,
        1 if show_window else 0,
    )
    result_code = int(result or 0)
    if result_code <= 32:
        raise OSError(f"Windows elevation launch failed with ShellExecute code {result_code}")
