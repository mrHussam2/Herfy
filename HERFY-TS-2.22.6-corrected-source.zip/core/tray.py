from __future__ import annotations

import json
from pathlib import Path

from core.settings import bundled_or_source_path


def _contract_path() -> Path:
    return bundled_or_source_path("contracts", "runtime_contract.json")


def _load_runtime_contract() -> dict[str, object]:
    path = _contract_path()
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise RuntimeError("runtime contract must be a JSON object")
    return payload


def _require_text(payload: dict[str, object], key: str) -> str:
    value = str(payload.get(key) or "").strip()
    if not value:
        raise RuntimeError(f"runtime_contract.json {key} must be a non-empty string")
    return value


def _load_menu_texts(payload: dict[str, object]) -> tuple[str, str, str]:
    values = payload.get("tray_menu_texts")
    if (
        not isinstance(values, list)
        or len(values) != 3
        or not all(isinstance(v, str) and v.strip() for v in values)
    ):
        raise RuntimeError(
            "runtime_contract.json tray_menu_texts must contain exactly three non-empty strings"
        )
    result = tuple(v.strip() for v in values)
    if len(set(result)) != 3:
        raise RuntimeError("runtime_contract.json tray menu values must be unique")
    return result[0], result[1], result[2]


_RUNTIME_CONTRACT = _load_runtime_contract()
OPEN_TEXT, LOGOUT_TEXT, EXIT_TEXT = _load_menu_texts(_RUNTIME_CONTRACT)
LOGIN_TEXT = "tray.login"
SETTINGS_TEXT = "tray.settings"
TRAY_MENU_TEXTS = (OPEN_TEXT, LOGOUT_TEXT, EXIT_TEXT)
BACKGROUND_CONTRACT = _require_text(_RUNTIME_CONTRACT, "background_contract")


def validate_tray_contract() -> None:
    payload = _load_runtime_contract()
    current = _load_menu_texts(payload)
    if current != TRAY_MENU_TEXTS:
        raise RuntimeError(f"invalid system-tray menu contract: {current!r}")
    background = _require_text(payload, "background_contract")
    if background != BACKGROUND_CONTRACT or background != "window-hidden+tray-visible":
        raise RuntimeError("invalid background runtime contract")


__all__ = [
    "BACKGROUND_CONTRACT",
    "EXIT_TEXT",
    "LOGIN_TEXT",
    "LOGOUT_TEXT",
    "OPEN_TEXT",
    "SETTINGS_TEXT",
    "TRAY_MENU_TEXTS",
    "validate_tray_contract",
]
