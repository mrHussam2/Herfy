from __future__ import annotations

import hashlib
import importlib.util
import json
import logging
import os
import sys
import tempfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from core.app_state import AppState
from core.errors import FILESYSTEM_OPERATION_EXCEPTIONS
from core.models import parse_bool
from core.presentation import (
    HomeDashboardService,
    PageVisibleStateService,
    UsageRowPresenter,
)
from core.runtime_ports import (
    ApplicationEventPort,
    DesktopNotificationPort,
    HttpTransportPort,
    StartupRegistrationPort,
    UpdateSecurityPort,
    configure_application_events,
    configure_desktop_notifications,
    configure_device_identity,
    configure_http_transport,
    configure_startup_registration,
    configure_update_security,
)
from core.settings import (
    bundled_or_source_path,
    install_exception_hooks,
    prepare_runtime_environment,
    setup_crash_logging,
)
from core.settings_contract import CANONICAL_SETTINGS_DEFAULTS
from core.state import UserProfile
from infra.api import (
    ApiClient,
)
from infra.api import (
    api_fetch_json as http_api_fetch_json,
)
from infra.api import (
    api_post_json as http_api_post_json,
)
from infra.api import (
    api_request as http_api_request,
)
from infra.api import (
    close_all_thread_sessions as http_close_all_thread_sessions,
)
from infra.api import (
    get_server_base_url as http_get_server_base_url,
)
from infra.api import (
    get_updates_base_url as http_get_updates_base_url,
)
from infra.database import LocalRepositories, SessionStore
from infra.device_identity import PersistentDeviceIdentity
from infra.excel import FileTabularInputReader
from services.administration import AdminService, CatalogManagementRuntimeService
from services.application_resources import ApplicationResourceService
from services.auth import (
    AccountSecurityService,
    AuthenticationService,
    SessionPersistenceService,
    SessionRuntimeService,
)
from services.catalogs import StoredCatalogService
from services.desktop_application import DesktopApplication
from services.lifecycle import ApplicationLifecycle
from services.monitoring_runtime import MonitoringRuntimeService
from services.notifications import NotificationRuntimeService
from services.preferences import PresentationPreferencesService, SettingsService
from services.runtime_cloud import CloudRuntimeService
from services.runtime_context import RuntimeContextService
from services.runtime_dependencies import UiRuntimeDependencies
from services.session_scope import SessionScope
from services.settings_schema import validate_canonical_settings
from services.startup_preferences import StartupPreferencesService
from services.sync import (
    CloudSyncRuntimeService,
    RealtimePullScheduler,
    ServerRuntimeService,
    SyncCoordinator,
)
from services.tracking import TrackingFormService, TrackingService
from services.updates import UpdateManager, UpdateRuntimeService
from services.usage import UsageCatalogService, UsageService, UsageWorkspaceService


@dataclass(frozen=True)
class RuntimeRequirement:
    import_name: str
    project_name: str
    purpose: str


REQUIRED_RUNTIME_REQUIREMENTS: tuple[RuntimeRequirement, ...] = (
    RuntimeRequirement("PySide6", "PySide6", "desktop user interface"),
    RuntimeRequirement("requests", "requests", "server communication"),
    RuntimeRequirement("packaging", "packaging", "version comparison"),
    RuntimeRequirement("cryptography", "cryptography", "signed update verification"),
    RuntimeRequirement("openpyxl", "openpyxl", "Excel workbook support"),
    RuntimeRequirement("xlrd", "xlrd", "XLS workbook support"),
)


def is_supported_python() -> bool:
    return sys.version_info[:2] == (3, 11)


def is_dependency_available(import_name: str) -> bool:
    try:
        return importlib.util.find_spec(import_name) is not None
    except (ImportError, AttributeError, ValueError):
        return False


def missing_runtime_requirements() -> list[RuntimeRequirement]:
    return [
        item
        for item in REQUIRED_RUNTIME_REQUIREMENTS
        if not is_dependency_available(item.import_name)
    ]


def runtime_requirements_ready() -> bool:
    return not missing_runtime_requirements()


"""Application composition boundary used by the root entry point."""


def _run_composed_application(argv: list[str] | None = None) -> int:
    _ = argv
    prepare_runtime_environment()
    setup_crash_logging()
    install_exception_hooks()
    from ui.runtime import run_gui_application

    container = create_dependency_container()
    return run_gui_application(container.create_ui_runtime())


@dataclass(frozen=True)
class ApplicationRunner:
    """Small executable application facade; composition remains in bootstrap."""

    arguments: tuple[str, ...]

    def run(self) -> int:
        return int(_run_composed_application(list(self.arguments)))


def build_application(arguments: list[str] | None = None) -> ApplicationRunner:
    return ApplicationRunner(tuple(sys.argv[1:] if arguments is None else arguments))


logger = logging.getLogger(__name__)
_INSTALLER_DEFAULTS_FILE = "installer_defaults.ini"
_BOOLEAN_INSTALLER_DEFAULTS: dict[str, str] = {
    "check_updates_on_startup": "True",
    "start_with_windows": "True",
    "tray_show_message_on_minimize": "False",
    "usage_hide_total_zero": "False",
}
_INTEGER_INSTALLER_DEFAULTS: dict[str, tuple[int, int, int]] = {
    # key: (default, minimum, maximum)
    "ui_scale_percent": (100, 90, 125),
}
_DEFAULT_LOCAL_SETTINGS = {
    **CANONICAL_SETTINGS_DEFAULTS,
    **_BOOLEAN_INSTALLER_DEFAULTS,
    "ui_scale_percent": "100",
}


def _read_flat_ini(path: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    try:
        for raw_line in path.read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith(("#", ";", "[")) or "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            if key:
                values[key] = value.strip()
    except (OSError, UnicodeError, *FILESYSTEM_OPERATION_EXCEPTIONS):
        logger.debug("Unable to read installer defaults: %s", path, exc_info=True)
    return values


def _load_installer_defaults() -> dict[str, str]:
    path = bundled_or_source_path(_INSTALLER_DEFAULTS_FILE)
    raw = _read_flat_ini(path) if path.exists() else {}
    if not raw:
        return {}
    canonical_input = {key: raw[key] for key in CANONICAL_SETTINGS_DEFAULTS if key in raw}
    normalized: dict[str, str] = {}
    if canonical_input:
        validation = validate_canonical_settings(canonical_input)
        normalized.update(validation.values)
        if validation.errors:
            logger.warning(
                "Installer defaults normalized with validation warnings: %s", validation.errors
            )
    for key, default in _BOOLEAN_INSTALLER_DEFAULTS.items():
        if key in raw:
            normalized[key] = (
                "True" if parse_bool(raw.get(key), parse_bool(default, True)) else "False"
            )
    for key, (default, minimum, maximum) in _INTEGER_INSTALLER_DEFAULTS.items():
        if key not in raw:
            continue
        try:
            value = int(str(raw.get(key) or default).strip())
        except (TypeError, ValueError):
            value = int(default)
        normalized[key] = str(max(minimum, min(maximum, value)))
    return normalized


def _initialize_local_settings(settings) -> None:
    defaults = dict(_DEFAULT_LOCAL_SETTINGS)
    for key, value in _load_installer_defaults().items():
        if key in defaults:
            defaults[key] = value
    for key, value in defaults.items():
        if settings.get_setting(key, None) in (None, ""):
            settings.set_setting(key, value)

    # Initialization is intentionally idempotent and value-based. Existing user
    # preferences always win; installer defaults fill only missing keys. This
    # avoids release-specific migration markers becoming permanent runtime state.
    if settings.get_setting("installer_language_initialized", "") != "True":
        if not settings.get_setting("language", ""):
            installer_language = _load_installer_defaults().get("language", "")
            settings.set_setting("language", installer_language or defaults["language"])
        settings.set_setting("installer_language_initialized", "True")

    if settings.get_setting("tray_settings_initialized", "") != "True":
        if settings.get_setting("enable_tray_background", None) in (None, ""):
            settings.set_setting(
                "enable_tray_background",
                defaults.get("enable_tray_background", "True"),
            )
        if settings.get_setting("tray_show_message_on_minimize", None) in (None, ""):
            settings.set_setting(
                "tray_show_message_on_minimize",
                defaults.get("tray_show_message_on_minimize", "False"),
            )
        settings.set_setting("tray_settings_initialized", "True")


def configure_application_ports(app_state: AppState | None = None) -> None:
    from infra.updater import (
        UpdateManifestVerifier,
        verify_signed_manifest_response,
    )
    from infra.windows import (
        send_windows_toast,
        sync_startup_from_preferences,
        verify_windows_toast_registration,
        windows_notification_capability,
    )

    configure_device_identity(PersistentDeviceIdentity())
    configure_http_transport(
        HttpTransportPort(
            api_request=http_api_request,
            api_fetch_json=http_api_fetch_json,
            api_post_json=http_api_post_json,
            get_server_base_url=http_get_server_base_url,
            get_updates_base_url=http_get_updates_base_url,
            close_all_thread_sessions=http_close_all_thread_sessions,
        )
    )
    verifier = UpdateManifestVerifier()
    configure_update_security(
        UpdateSecurityPort(
            verify_manifest=verifier.verify,
            verify_signed_manifest_response=verify_signed_manifest_response,
        )
    )
    configure_startup_registration(
        StartupRegistrationPort(sync_startup_from_preferences=sync_startup_from_preferences)
    )
    configure_desktop_notifications(
        DesktopNotificationPort(
            send_windows_toast=send_windows_toast,
            capability_snapshot=windows_notification_capability,
        )
    )
    verify_windows_toast_registration()
    if app_state is not None:
        configure_application_events(
            ApplicationEventPort(
                emit_updated=app_state.emit_item_updated,
                emit_deleted=app_state.emit_item_deleted,
                emit_data_changed=app_state.emit_data_changed,
            )
        )


@dataclass
class DependencyContainer:
    app_state: AppState = field(default_factory=AppState)
    api_client_factory: Callable[..., ApiClient] = ApiClient
    update_manager_factory: Callable[[str], UpdateManager] = UpdateManager
    runtime_scheduler_factory: Callable[..., Any] | None = None
    session_store_factory: Callable[..., SessionStore] = SessionStore
    lifecycle: ApplicationLifecycle = field(default_factory=ApplicationLifecycle)
    repositories: LocalRepositories = field(init=False)
    context: RuntimeContextService = field(init=False)
    stored_catalog: StoredCatalogService = field(init=False)
    usage_catalog: UsageCatalogService = field(init=False)
    tracking_service: TrackingService = field(init=False)
    sync_coordinator: SyncCoordinator = field(init=False)
    application: DesktopApplication = field(init=False)
    session_persistence: SessionPersistenceService = field(init=False)
    authentication_service: AuthenticationService = field(init=False)
    admin_service: AdminService = field(init=False)
    account_security: AccountSecurityService = field(init=False)
    cloud_runtime: CloudRuntimeService = field(init=False)
    server_runtime_service: ServerRuntimeService = field(init=False)

    def __post_init__(self) -> None:
        configure_application_ports(self.app_state)
        self.repositories = LocalRepositories.create()
        _initialize_local_settings(self.repositories.settings)
        self.context = RuntimeContextService(
            self.app_state,
            self.repositories.settings,
            invalidate_tracking_cache=self.repositories.tracking.invalidate_cloud_cache,
        )

        def remote_provider() -> ApiClient:
            return self.context.api_client

        self.stored_catalog = StoredCatalogService(
            self.repositories.tracking,
            remote_provider=remote_provider,
        )
        self.usage_catalog = UsageCatalogService(
            self.repositories.usage,
            remote_provider=remote_provider,
        )
        self.tracking_service = TrackingService(
            self.repositories.tracking,
            self.context,
            self.repositories.settings,
            self.stored_catalog,
        )
        self.sync_coordinator = SyncCoordinator(
            self.repositories.settings,
            self.repositories.tracking,
            self.stored_catalog,
            self.usage_catalog,
            self.context,
        )
        self.server_runtime_service = ServerRuntimeService()
        self.cloud_runtime = CloudRuntimeService(
            state=self.app_state,
            client_factory=self.api_client_factory,
            context=self.context,
            sync_coordinator=self.sync_coordinator,
        )
        cloud_provider = self.cloud_runtime.client_for_application
        self.session_persistence = SessionPersistenceService(self.session_store_factory())
        self.authentication_service = AuthenticationService()
        self.admin_service = AdminService(cloud_provider, app_state=self.app_state)
        self.account_security = AccountSecurityService(cloud_provider)
        self.application = DesktopApplication(
            state=self.app_state,
            repositories=self.repositories,
            context=self.context,
            tracking_service=self.tracking_service,
            stored_catalog=self.stored_catalog,
            usage_catalog=self.usage_catalog,
            sync_coordinator=self.sync_coordinator,
            admin_service=self.admin_service,
            account_security=self.account_security,
            cloud_runtime=self.cloud_runtime,
        )

    def create_api_client(self, id_token: str, user: UserProfile | None = None) -> ApiClient:
        return self.api_client_factory(id_token=id_token, user=user)

    def create_runtime_scheduler(self, owner) -> Any:
        factory = self.runtime_scheduler_factory
        if factory is None:
            from services.runtime_timers import RuntimeTimerScheduler

            factory = RuntimeTimerScheduler
        return factory(owner)

    def create_tracking_service(self) -> TrackingService:
        return self.tracking_service

    def create_session_store(self) -> SessionStore:
        return self.session_store_factory()

    def create_ui_runtime(self) -> UiRuntimeDependencies:
        presentation_preferences = PresentationPreferencesService(self.application)
        cloud_sync_runtime = CloudSyncRuntimeService(self.application)
        session_runtime = SessionRuntimeService(
            self.session_persistence, self.authentication_service, cloud_sync_runtime
        )
        update_runtime = UpdateRuntimeService(self.application, self.server_runtime_service)
        settings_service = SettingsService(self.application)
        usage_workspace_service = UsageWorkspaceService(
            presentation_preferences=presentation_preferences,
            settings_service=settings_service,
            app_state=self.app_state,
        )
        return UiRuntimeDependencies(
            app_state=self.app_state,
            application_resource_service=ApplicationResourceService(self.application),
            lifecycle=self.lifecycle,
            session_scope=SessionScope(),
            session_persistence=self.session_persistence,
            authentication_service=self.authentication_service,
            account_security_service=self.account_security,
            session_runtime_service=session_runtime,
            cloud_sync_runtime_service=cloud_sync_runtime,
            monitoring_service=MonitoringRuntimeService(self.application, self.tracking_service),
            notification_runtime_service=NotificationRuntimeService(
                self.application, presentation_preferences
            ),
            settings_service=settings_service,
            catalog_management_service=CatalogManagementRuntimeService(
                self.application, self.admin_service
            ),
            admin_service=self.admin_service,
            tracking_service=self.tracking_service,
            usage_service=self.create_usage_service(),
            usage_workspace_service=usage_workspace_service,
            usage_row_presenter=UsageRowPresenter(),
            home_dashboard_service=HomeDashboardService(self.application),
            tracking_form_service=TrackingFormService(),
            page_visible_state_service=PageVisibleStateService(),
            presentation_preferences=presentation_preferences,
            server_runtime_service=self.server_runtime_service,
            update_runtime_service=update_runtime,
            realtime_pull_scheduler=RealtimePullScheduler(min_gap_ms=450),
            startup_preferences_service=StartupPreferencesService(self.application),
            update_manager_factory=self.update_manager_factory,
        )

    def create_usage_service(self) -> UsageService:
        return UsageService(
            self.usage_catalog,
            self.repositories.usage,
            FileTabularInputReader(),
        )


def create_dependency_container() -> DependencyContainer:
    return DependencyContainer()


def _self_check_target() -> str:
    """Return the requested self-check output path from argv or environment."""
    args = list(sys.argv[1:])
    for index, arg in enumerate(args):
        if arg == "--self-check-file" and index + 1 < len(args):
            return str(args[index + 1]).strip().strip('"')
        if arg.startswith("--self-check-file="):
            return arg.split("=", 1)[1].strip().strip('"')
    return str(os.environ.get("HERFY_SELF_CHECK_FILE") or "").strip()


def _write_self_check(payload: dict[str, object]) -> None:
    """Write the machine-readable self-check result when requested."""
    target = _self_check_target()
    if not target:
        return
    path = Path(target)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def run_self_check() -> int:
    """Validate a frozen runtime without starting network workers or the UI."""
    payload: dict[str, object] = {"status": "failed", "frozen": bool(getattr(sys, "frozen", False))}
    app = None
    try:
        from contracts.binding import get_server_binding, get_update_trust
        from core.settings import (
            APP_PRODUCT_NAME,
            bundled_or_source_path,
            bundled_root_dir,
            executable_dir,
        )
        from infra.database import LocalRepositories
        from version import get_version

        __version__ = get_version()

        missing = missing_runtime_requirements()
        if missing:
            names = ", ".join(item.project_name for item in missing)
            raise RuntimeError(f"Required runtime packages are missing: {names}")

        # Exercise the actual runtime libraries, not only import discovery.
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        import certifi
        import requests
        import xlrd
        from cryptography.hazmat.primitives import hashes
        from openpyxl import Workbook
        from packaging.version import Version
        from PySide6 import QtCore, QtMultimedia
        from shiboken6 import isValid as shiboken_is_valid

        if not Path(certifi.where()).is_file():
            raise RuntimeError("certifi CA bundle probe failed")
        qt_version = getattr(QtCore, "QT_VERSION_STR", "") or QtCore.qVersion()
        if not qt_version or not hasattr(QtMultimedia, "QSoundEffect"):
            raise RuntimeError("PySide6/QtMultimedia runtime probe failed")
        if not callable(shiboken_is_valid):
            raise RuntimeError("Shiboken runtime probe failed")
        if str(Version(__version__)) != __version__:
            raise RuntimeError("packaging runtime probe failed")
        session = requests.Session()
        session.close()
        digest = hashes.Hash(hashes.SHA256())
        digest.update(APP_PRODUCT_NAME.encode("utf-8"))
        if len(digest.finalize()) != 32:
            raise RuntimeError("cryptography runtime probe failed")
        workbook = Workbook()
        workbook.active["A1"] = "HERFY"
        workbook.close()
        if not hasattr(xlrd, "open_workbook"):
            raise RuntimeError("xlrd runtime probe failed")

        # Exercise the deferred imports used by an ordinary launch as well.
        from ui.main_window import HerfyMainWindow
        from ui.runtime import run_gui_application

        del run_gui_application, HerfyMainWindow

        binding = get_server_binding()
        update_trust = get_update_trust()
        if not update_trust.manifest_url.startswith(f"{binding.updates_base_url.rstrip('/')}/"):
            raise RuntimeError("Canonical update manifest URL does not match the update origin")

        from core.tray import (
            BACKGROUND_CONTRACT,
            TRAY_MENU_TEXTS,
            validate_tray_contract,
        )

        validate_tray_contract()
        expected_tray_menu = TRAY_MENU_TEXTS

        required_resources = (
            ("resources", "i18n", "ar.json"),
            ("resources", "i18n", "en.json"),
            ("resources", "images", "logo.png"),
            ("resources", "images", "app_icon.ico"),
        )
        if getattr(sys, "frozen", False):
            required_resources += (("resources", "update_signing_public.pem"),)
        for parts in required_resources:
            resource = bundled_or_source_path(*parts)
            if not resource.is_file() or resource.stat().st_size <= 0:
                raise RuntimeError(f"Required resource is missing: {'/'.join(parts)}")
            if getattr(sys, "frozen", False):
                resolved = resource.resolve()
                allowed_roots = (bundled_root_dir().resolve(), executable_dir().resolve())
                if not any(resolved.is_relative_to(root) for root in allowed_roots):
                    raise RuntimeError(f"Frozen resource escaped the installed runtime: {resolved}")

        if getattr(sys, "frozen", False):
            from infra.updater import load_pinned_update_public_key

            load_pinned_update_public_key()
            provenance_path = bundled_or_source_path("BUILD_PROVENANCE.json")
            if not provenance_path.is_file():
                raise RuntimeError("Frozen build provenance is missing")
            provenance_resolved = provenance_path.resolve()
            if not any(
                provenance_resolved.is_relative_to(root)
                for root in (bundled_root_dir().resolve(), executable_dir().resolve())
            ):
                raise RuntimeError("Frozen build provenance escaped the installed runtime")
            provenance = json.loads(provenance_path.read_text(encoding="utf-8-sig"))
            if str(provenance.get("version") or "").strip() != __version__:
                raise RuntimeError("Frozen build provenance version mismatch")
            expected_key_hash = (
                str(provenance.get("update_public_key_pem_sha256") or "").strip().lower()
            )
            if len(expected_key_hash) != 64 or any(
                ch not in "0123456789abcdef" for ch in expected_key_hash
            ):
                raise RuntimeError("Frozen build provenance update-key fingerprint is invalid")
            public_key_path = bundled_or_source_path("resources", "update_signing_public.pem")
            actual_key_hash = hashlib.sha256(public_key_path.read_bytes()).hexdigest()
            if actual_key_hash != expected_key_hash:
                raise RuntimeError("Frozen update public key does not match build provenance")
            if tuple(provenance.get("tray_contract") or ()) != expected_tray_menu:
                raise RuntimeError("Frozen build contains the wrong tray-menu contract")
            if provenance.get("background_contract") != BACKGROUND_CONTRACT:
                raise RuntimeError("Frozen build contains the wrong background lifecycle contract")
            source_hash = str(provenance.get("source_sha256") or "").strip().lower()
            if len(source_hash) != 64 or any(ch not in "0123456789abcdef" for ch in source_hash):
                raise RuntimeError("Frozen build source fingerprint is invalid")

            os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
            from ui.main_window import HerfyMainWindow  # import contract

            del HerfyMainWindow
            from PySide6.QtWidgets import QApplication

            app = QApplication.instance() or QApplication(["HERFY-TS-self-check"])
        with tempfile.TemporaryDirectory(prefix="herfyts_self_check_") as directory:
            repositories = LocalRepositories.create(
                db_path_override=Path(directory) / "self_check.sqlite3"
            )
            store = repositories.engine
            try:
                row = store.connection.execute("PRAGMA integrity_check").fetchone()
                if not row or str(row[0]).casefold() != "ok":
                    raise RuntimeError("SQLite integrity check failed")
                tables = {
                    str(item[0])
                    for item in store.connection.execute(
                        "SELECT name FROM sqlite_master WHERE type='table'"
                    ).fetchall()
                }
                required_tables = {
                    "settings",
                    "cloud_tracked_products",
                    "notify_log",
                    "alert_state",
                    "notification_ledger",
                }
                if not required_tables.issubset(tables):
                    raise RuntimeError("Local repository schema is incomplete")
                forbidden_authority_or_obsolete_tables = {
                    "users",
                    "roles",
                    "permissions",
                    "scopes",
                    "tracked_products",
                    "usage_products_pending",
                    "operations",
                    "idempotency_records",
                    "sync_changes",
                    "tracking_records_v2",
                    "tracking_sync_state",
                    "tracking_remote_aliases",
                    "stored_products",
                    "usage_products",
                }
                forbidden_present = tables.intersection(forbidden_authority_or_obsolete_tables)
                if forbidden_present:
                    raise RuntimeError(
                        "Forbidden local authority/obsolete tables remain: "
                        + ",".join(sorted(forbidden_present))
                    )
            finally:
                repositories.close()

        startup_status = "not_applicable"
        windows_backends = "not_applicable"
        windows_notifications: object = "not_applicable"
        if os.name == "nt":
            import win32api
            import win32con
            import win32gui
            import win32timezone

            del win32api, win32con, win32gui, win32timezone
            windows_backends = "ok"

            from infra.windows import windows_notification_capability

            windows_notifications = windows_notification_capability()

            if getattr(sys, "frozen", False):
                qwindows_candidates = (
                    bundled_or_source_path("PySide6", "plugins", "platforms", "qwindows.dll"),
                    bundled_or_source_path("PySide6", "Qt", "plugins", "platforms", "qwindows.dll"),
                )
                if not any(path.is_file() for path in qwindows_candidates):
                    raise RuntimeError("Frozen Qt qwindows.dll plugin is missing")

            from infra.windows import build_autostart_command

            startup_command = build_autostart_command()
            if (
                not startup_command.endswith(" --background")
                or startup_command.count("--background") != 1
            ):
                raise RuntimeError("Windows startup command contract is invalid")
            startup_status = "command_ok"

        runtime_root = executable_dir()
        if getattr(sys, "frozen", False):
            from core.settings import UPDATE_AGENT_EXE

            agent = runtime_root / UPDATE_AGENT_EXE
            if not agent.is_file():
                raise RuntimeError(f"{UPDATE_AGENT_EXE} is missing from runtime")
            leaked = [
                item.relative_to(runtime_root).as_posix()
                for item in runtime_root.rglob("*")
                if item.is_file()
                and (item.suffix.lower() in {".py", ".pyc", ".pyo"} or "__pycache__" in item.parts)
            ]
            if leaked:
                raise RuntimeError(f"Python source leaked into runtime: {leaked[:5]}")
        payload.update(
            {
                "status": "ok",
                "version": __version__,
                "resources": "ok",
                "database": "ok",
                "imports": "ok",
                "windows_startup": startup_status,
                "windows_backends": windows_backends,
                "windows_notifications": windows_notifications,
                "tray_menu": list(expected_tray_menu),
                "background_contract": BACKGROUND_CONTRACT,
                "update_public_key_sha256": (
                    actual_key_hash if getattr(sys, "frozen", False) else "source"
                ),
                "source_sha256": (
                    str(provenance.get("source_sha256") or "")
                    if getattr(sys, "frozen", False)
                    else "source"
                ),
            }
        )
        return 0
    except Exception as exc:
        payload["error"] = f"{type(exc).__name__}: {exc}"
        return 1
    finally:
        if app is not None:
            app.quit()
        _write_self_check(payload)
