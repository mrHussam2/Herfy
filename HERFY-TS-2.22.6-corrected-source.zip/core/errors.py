from __future__ import annotations

import json
from subprocess import SubprocessError

UI_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    AttributeError,
    OSError,
    RuntimeError,
    TypeError,
    ValueError,
)
STATE_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    AttributeError,
    LookupError,
    OSError,
    RuntimeError,
    TypeError,
    ValueError,
)
FILESYSTEM_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    FileExistsError,
    FileNotFoundError,
    IsADirectoryError,
    NotADirectoryError,
    PermissionError,
    OSError,
)
PARSE_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    TypeError,
    ValueError,
    UnicodeDecodeError,
    json.JSONDecodeError,
)
IMPORT_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    AttributeError,
    ImportError,
    ModuleNotFoundError,
)
PROCESS_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    OSError,
    ValueError,
    SubprocessError,
)
CALLBACK_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    AttributeError,
    RuntimeError,
    TypeError,
    ValueError,
)
SERVICE_OPERATION_EXCEPTIONS: tuple[type[BaseException], ...] = (
    AttributeError,
    LookupError,
    OSError,
    RuntimeError,
    TypeError,
    ValueError,
    ImportError,
    ModuleNotFoundError,
    UnicodeDecodeError,
    json.JSONDecodeError,
    SubprocessError,
)


class RemoteRequestError(RuntimeError):
    """Raised when a remote API request fails.

    Structured server error metadata is retained for diagnostics without
    exposing tokens, passwords, or arbitrary response bodies.
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        *,
        error_code: str = "",
        request_id: str = "",
        retryable: bool = False,
        details: dict[str, object] | None = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = str(error_code or "").strip()
        self.request_id = str(request_id or "").strip()
        self.retryable = bool(retryable)
        self.details = dict(details or {})


class SessionExpiredError(RemoteRequestError):
    """Raised when the remote endpoint rejects the current session/token."""


__all__ = [
    "UI_OPERATION_EXCEPTIONS",
    "STATE_OPERATION_EXCEPTIONS",
    "FILESYSTEM_OPERATION_EXCEPTIONS",
    "PARSE_OPERATION_EXCEPTIONS",
    "IMPORT_OPERATION_EXCEPTIONS",
    "PROCESS_OPERATION_EXCEPTIONS",
    "CALLBACK_OPERATION_EXCEPTIONS",
    "SERVICE_OPERATION_EXCEPTIONS",
    "RemoteRequestError",
    "SessionExpiredError",
]


def is_transient_remote_error(exc: Exception) -> bool:
    """Classify temporary transport/server failures without depending on infrastructure."""
    exc_type = type(exc).__name__
    if exc_type == "SessionExpiredError":
        return False
    status_code = getattr(exc, "status_code", None)
    if exc_type == "RemoteRequestError":
        return status_code in (None, 502, 503, 504)
    message = str(exc or "").lower()
    if not message:
        return False
    return any(
        marker in message
        for marker in (
            "server not reachable",
            "temporarily unavailable",
            "timed out",
            "timeout",
            "connection aborted",
            "connection reset",
            "connection refused",
            "failed to establish a new connection",
            "name or service not known",
        )
    )
