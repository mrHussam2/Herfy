from __future__ import annotations

import logging
import time
from typing import Any

from core.errors import CALLBACK_OPERATION_EXCEPTIONS


def safe_disconnect(
    signal: Any,
    slot: Any = None,
    *,
    logger_: logging.Logger | None = None,
    context: str = "Signal disconnect",
) -> bool:
    try:
        if slot is None:
            signal.disconnect()
        else:
            signal.disconnect(slot)
        return True
    except CALLBACK_OPERATION_EXCEPTIONS:
        if logger_ is not None:
            logger_.debug("%s skipped; no active receiver", context)
        return False


class SignalRateGate:
    """Small monotonic rate gate for high-frequency UI progress signals.

    The gate is intentionally transport-agnostic.  It suppresses exact duplicate
    values and changed values that arrive inside ``min_interval_seconds``.  The
    first value after construction/reset always passes.
    """

    def __init__(self, min_interval_seconds: float = 0.05, *, monotonic=None) -> None:
        self._min_interval_seconds = max(0.0, float(min_interval_seconds))
        self._monotonic = monotonic or time.monotonic
        self._last_at: float | None = None
        self._last_value: Any = None

    def reset(self) -> None:
        self._last_at = None
        self._last_value = None

    def allow(self, value: Any) -> bool:
        now = float(self._monotonic())
        if self._last_at is None:
            self._last_at = now
            self._last_value = value
            return True
        if value == self._last_value:
            return False
        if max(0.0, now - self._last_at) < self._min_interval_seconds:
            return False
        self._last_at = now
        self._last_value = value
        return True
