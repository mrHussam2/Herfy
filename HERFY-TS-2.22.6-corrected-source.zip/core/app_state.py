from __future__ import annotations

from typing import Any

from PySide6.QtCore import QObject, Signal

from core.permissions import PermissionContext
from core.state import RuntimeStateCore


class AppState(QObject, RuntimeStateCore):
    """Application state and cross-domain change signals, independent of UI widgets."""

    session_changed = Signal(object)
    user_changed = Signal(object)
    permissions_changed = Signal(object)
    branch_changed = Signal(str)
    connection_changed = Signal(bool, str)
    connection_state_changed = Signal(str, str)
    sync_state_changed = Signal(str, str)
    update_state_changed = Signal(str, str)
    notification_state_changed = Signal(str, str)
    api_client_changed = Signal(object)
    data_changed = Signal(str, object)
    item_updated = Signal(str, object)
    item_deleted = Signal(str, object)

    def __init__(self, parent: QObject | None = None):
        QObject.__init__(self, parent)
        self._init_runtime_state()

    def _emit_session_changed(self, session: Any) -> None:
        self.session_changed.emit(session)

    def _emit_user_changed(self, profile: Any) -> None:
        self.user_changed.emit(profile)

    def _emit_permissions_changed(self, permission_context: PermissionContext) -> None:
        self.permissions_changed.emit(permission_context)

    def _emit_branch_changed(self, branch: str) -> None:
        self.branch_changed.emit(branch)

    def _emit_connection_changed(self, online: bool, message: str) -> None:
        self.connection_changed.emit(online, message)

    def _emit_connection_state_changed(self, state, message: str) -> None:
        self.connection_state_changed.emit(str(state.value), message)

    def _emit_sync_state_changed(self, state, message: str) -> None:
        self.sync_state_changed.emit(str(state.value), message)

    def _emit_update_state_changed(self, state, message: str) -> None:
        self.update_state_changed.emit(str(state.value), message)

    def _emit_notification_state_changed(self, state, message: str) -> None:
        self.notification_state_changed.emit(str(state.value), message)

    def _emit_api_client_changed(self, api_client: Any) -> None:
        self.api_client_changed.emit(api_client)

    @staticmethod
    def _clean_domain(domain: str) -> str:
        return str(domain or "").strip().lower()

    def emit_data_changed(self, domain: str, payload: Any = None) -> None:
        self.data_changed.emit(self._clean_domain(domain), payload)

    def _emit_item_change(self, signal, domain: str, payload: Any = None) -> None:
        signal.emit(self._clean_domain(domain), payload)
        self.emit_data_changed(domain, payload)

    def emit_item_updated(self, domain: str, payload: Any = None) -> None:
        self._emit_item_change(self.item_updated, domain, payload)

    def emit_item_deleted(self, domain: str, payload: Any = None) -> None:
        self._emit_item_change(self.item_deleted, domain, payload)
