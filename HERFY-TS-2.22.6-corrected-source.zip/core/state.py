from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from core.models import noop
from core.permissions import PermissionContext


@dataclass
class UserProfile:
    user_id: str
    username: str
    display_name: str
    role: str
    account_type: str = "employee"
    branches: list[str] = field(default_factory=list)
    active_branch: str = ""
    permission_context: PermissionContext = field(default_factory=PermissionContext)
    must_change_password: bool = False
    is_active: bool = True

    @classmethod
    def from_permission_context(cls, ctx: PermissionContext) -> "UserProfile":
        return cls(
            user_id=str(ctx.user_id or "").strip(),
            username=str(ctx.username or "").strip(),
            display_name=str(ctx.display_name or "").strip(),
            role=ctx.role,
            account_type=ctx.account_type,
            branches=list(ctx.scope.branches or []),
            active_branch=str(ctx.active_branch or "").strip(),
            permission_context=ctx,
            must_change_password=bool(ctx.must_change_password),
            is_active=bool(ctx.is_active),
        )

    def to_cloud_user_payload(self) -> dict:
        ctx = (
            self.permission_context
            if isinstance(self.permission_context, PermissionContext)
            else PermissionContext()
        )
        return ctx.to_payload()


@dataclass
class AuthSession:
    id_token: str
    user_id: str
    role: str
    branches: list[str] = field(default_factory=list)
    active_branch: str = ""
    refresh_token: str = ""
    token_type: str = "bearer"
    expires_in: int = 3600
    permission_context: PermissionContext = field(default_factory=PermissionContext)


class ConnectionState(str, Enum):
    ONLINE = "ONLINE"
    SYNCING = "SYNCING"
    OFFLINE = "OFFLINE"
    AUTH_REFRESHING = "AUTH_REFRESHING"
    ERROR = "ERROR"


class SyncState(str, Enum):
    IDLE = "IDLE"
    SYNCING = "SYNCING"
    OFFLINE = "OFFLINE"
    ERROR = "ERROR"


class UpdateState(str, Enum):
    IDLE = "IDLE"
    CHECKING = "CHECKING"
    AVAILABLE = "AVAILABLE"
    DOWNLOADING = "DOWNLOADING"
    ERROR = "ERROR"


class NotificationState(str, Enum):
    READY = "READY"
    DISABLED = "DISABLED"
    ERROR = "ERROR"


def _coerce_state(enum_type, value):
    if isinstance(value, enum_type):
        return value
    return enum_type(str(value or "").strip().upper())


def normalize_branch(branch: str | None) -> str:
    return str(branch or "").strip()


def normalize_branch_list(branches: Iterable[str] | None) -> list[str]:
    seen: set[str] = set()
    cleaned: list[str] = []
    for branch in branches or []:
        value = normalize_branch(branch)
        lowered = value.lower()
        if value and lowered not in seen:
            seen.add(lowered)
            cleaned.append(value)
    return cleaned


class RuntimeStateCore:
    def __init__(self) -> None:
        self._init_runtime_state()

    def _init_runtime_state(self) -> None:
        self._session: Any = None
        self._current_user: Any = None
        self._permissions = PermissionContext()
        self._current_branch = ""
        self._allowed_branches: list[str] = []
        self._connection_online = False
        self._connection_message = ""
        self._connection_state = ConnectionState.OFFLINE
        self._sync_state = SyncState.IDLE
        self._sync_message = ""
        self._update_state = UpdateState.IDLE
        self._update_message = ""
        self._notification_state = NotificationState.READY
        self._notification_message = ""
        self._api_client: Any = None

    _emit_session_changed = noop
    _emit_user_changed = noop
    _emit_permissions_changed = noop
    _emit_branch_changed = noop
    _emit_connection_changed = noop
    _emit_connection_state_changed = noop
    _emit_sync_state_changed = noop
    _emit_update_state_changed = noop
    _emit_notification_state_changed = noop
    _emit_api_client_changed = noop

    def _set_reference_state(self, attr_name: str, value: Any, emitter) -> None:
        if getattr(self, attr_name) is value:
            return
        setattr(self, attr_name, value)
        emitter(value)

    @property
    def session(self) -> Any:
        return self._session

    def set_session(self, session: Any) -> None:
        self._set_reference_state("_session", session, self._emit_session_changed)

    @property
    def current_user(self) -> Any:
        return self._current_user

    def set_current_user(self, profile: Any) -> None:
        self._set_reference_state("_current_user", profile, self._emit_user_changed)

    @property
    def permissions(self) -> PermissionContext:
        if isinstance(self._permissions, PermissionContext):
            return self._permissions
        return PermissionContext()

    def set_permissions(self, permission_context: PermissionContext | None) -> None:
        ctx = (
            permission_context
            if isinstance(permission_context, PermissionContext)
            else PermissionContext()
        )
        self._permissions = ctx
        self._emit_permissions_changed(ctx)

    @property
    def current_branch(self) -> str:
        return str(self._current_branch or "").strip()

    def set_current_branch(self, branch: str) -> None:
        value = normalize_branch(branch)
        if self.current_branch.lower() == value.lower():
            self._current_branch = value
            return
        self._current_branch = value
        self._emit_branch_changed(value)

    @property
    def allowed_branches(self) -> list[str]:
        return list(self._allowed_branches)

    def set_allowed_branches(self, branches: list[str] | tuple[str, ...] | None) -> None:
        cleaned = normalize_branch_list(branches)
        self._allowed_branches = cleaned

    @property
    def role(self) -> str:
        return str(self.permissions.role or "").strip()

    @property
    def connection_online(self) -> bool:
        return bool(self._connection_online)

    @property
    def connection_message(self) -> str:
        return str(self._connection_message or "")

    def set_connection_state(self, online: bool, message: str = "") -> None:
        self.set_connection_mode(
            ConnectionState.ONLINE if bool(online) else ConnectionState.OFFLINE,
            message,
        )

    @property
    def connection_state(self) -> ConnectionState:
        return self._connection_state

    def set_connection_mode(self, state: ConnectionState | str, message: str = "") -> None:
        new_state = _coerce_state(ConnectionState, state)
        new_online = new_state in {
            ConnectionState.ONLINE,
            ConnectionState.SYNCING,
            ConnectionState.AUTH_REFRESHING,
        }
        new_message = str(message or "")
        if (
            self._connection_online == new_online
            and self._connection_message == new_message
            and self._connection_state is new_state
        ):
            return
        legacy_changed = (
            self._connection_online != new_online or self._connection_message != new_message
        )
        self._connection_online = new_online
        self._connection_message = new_message
        self._connection_state = new_state
        self._emit_connection_state_changed(new_state, new_message)
        if legacy_changed:
            self._emit_connection_changed(new_online, new_message)

    @property
    def sync_state(self) -> SyncState:
        return self._sync_state

    @property
    def sync_message(self) -> str:
        return str(self._sync_message or "")

    def set_sync_state(self, state: SyncState | str, message: str = "") -> None:
        new_state = _coerce_state(SyncState, state)
        new_message = str(message or "")
        if self._sync_state is new_state and self._sync_message == new_message:
            return
        self._sync_state = new_state
        self._sync_message = new_message
        self._emit_sync_state_changed(new_state, new_message)

    @property
    def update_state(self) -> UpdateState:
        return self._update_state

    def set_update_state(self, state: UpdateState | str, message: str = "") -> None:
        new_state = _coerce_state(UpdateState, state)
        new_message = str(message or "")
        if self._update_state is new_state and self._update_message == new_message:
            return
        self._update_state = new_state
        self._update_message = new_message
        self._emit_update_state_changed(new_state, new_message)

    @property
    def notification_state(self) -> NotificationState:
        return self._notification_state

    def set_notification_state(self, state: NotificationState | str, message: str = "") -> None:
        new_state = _coerce_state(NotificationState, state)
        new_message = str(message or "")
        if self._notification_state is new_state and self._notification_message == new_message:
            return
        self._notification_state = new_state
        self._notification_message = new_message
        self._emit_notification_state_changed(new_state, new_message)

    @property
    def api_client(self) -> Any:
        return self._api_client

    def set_api_client(self, api_client: Any) -> None:
        self._set_reference_state("_api_client", api_client, self._emit_api_client_changed)

    def reset_identity(self) -> None:
        self.set_session(None)
        self.set_current_user(None)
        self.set_permissions(PermissionContext())
        self.set_allowed_branches([])
        self.set_current_branch("")
        self.set_api_client(None)
        self.set_connection_state(False, "")
        self.set_sync_state(SyncState.IDLE, "")
        self.set_update_state(UpdateState.IDLE, "")
        self.set_notification_state(NotificationState.READY, "")

    def snapshot(self) -> dict[str, Any]:
        return {
            "session": self._session,
            "current_user": self._current_user,
            "permissions": self.permissions,
            "current_branch": self.current_branch,
            "allowed_branches": self.allowed_branches,
            "connection_online": self.connection_online,
            "connection_message": self.connection_message,
            "connection_state": self.connection_state.value,
            "sync_state": self.sync_state.value,
            "sync_message": self.sync_message,
            "update_state": self.update_state.value,
            "notification_state": self.notification_state.value,
            "api_client": self.api_client,
            "role": self.role,
        }
