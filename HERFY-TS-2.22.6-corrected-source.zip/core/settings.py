from __future__ import annotations

import faulthandler
import logging
import os
import re
import sys
import tempfile
import threading
import traceback
from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from datetime import datetime
from functools import lru_cache
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any, TypeAlias
from urllib.parse import urlsplit, urlunsplit

from contracts.binding import get_server_binding
from core import i18n
from core.errors import FILESYSTEM_OPERATION_EXCEPTIONS, STATE_OPERATION_EXCEPTIONS
from version import __version__ as APP_VERSION

logger = logging.getLogger(__name__)
APP_DISPLAY_NAME = "HERFY-TS"
APP_PRODUCT_NAME = "HERFY-TS"
APP_DEVELOPER_NAME = "HUSSAM ALFAIFI #18016"
APP_ORGANIZATION_NAME = "Herfy"
APP_ORGANIZATION_DOMAIN = "herfy.online"
APP_RUNTIME_DIR_NAME = "HERFY-TS"
APP_DESKTOP_APP_ID = "Herfy.HerfyClient"
APP_EXE = "HERFY-TS.exe"
UPDATE_AGENT_EXE = "HERFY-TSUpdateAgent.exe"
APPDATA_DIR_NAME = APP_RUNTIME_DIR_NAME
DEFAULT_LANGUAGE = os.environ.get("HERFY_TS_DEFAULT_LANGUAGE", "en").strip() or "en"
DEFAULT_FONT_FAMILY = "Segoe UI"
DEFAULT_FONT_SIZE_PT = 10
_SERVER_BINDING = get_server_binding()
DEFAULT_SERVER_BASE_URL = _SERVER_BINDING.api_base_url
LOGO_RELATIVE_PATH = ("resources", "images", "logo.png")
APP_ICON_RELATIVE_PATH = ("resources", "images", "app_icon.ico")
NOTIFICATION_SOUND_DIR_RELATIVE_PATH = ("resources", "sounds")
IS_WINDOWS = sys.platform.startswith("win")
translations: dict[str, str] = {}


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def _resolve_or_none(value: str | Path | None) -> Path | None:
    if value in (None, ""):
        return None
    try:
        return Path(str(value)).resolve()
    except STATE_OPERATION_EXCEPTIONS:
        return None


def _source_tree_root_from_file() -> Path:
    """Find the clean client source root.

    The delivered source package is intentionally flat: main.py, core/, services/, infra/, ui/,
    contracts/, resources/, requirements.txt, and version.json live directly
    at the project root. Tests and build tooling are isolated under tests/ and
    tools/ and are never runtime resource roots. Older packages sometimes
    resolved a package subdirectory as the root, which broke resources and translations when
    running `py main.py`.
    """
    try:
        current = Path(__file__).resolve()
        for candidate in current.parents:
            if (
                (candidate / "main.py").is_file()
                and (candidate / "core").is_dir()
                and (candidate / "services").is_dir()
                and (candidate / "infra").is_dir()
                and (candidate / "ui").is_dir()
                and (candidate / "contracts").is_dir()
                and (candidate / "resources").is_dir()
            ):
                return candidate
    except STATE_OPERATION_EXCEPTIONS:
        pass
    return Path.home().resolve()


def package_root_dir() -> Path:
    """Return the installed/source package root without relying on cwd."""
    if is_frozen():
        bundled = _resolve_or_none(getattr(sys, "_MEIPASS", None))
        if bundled is not None:
            return bundled
        executable = _resolve_or_none(sys.executable)
        if executable is not None:
            return executable.parent
    return _source_tree_root_from_file()


def source_root_dir() -> Path:
    """Return the repository root for editable source runs."""
    return _source_tree_root_from_file()


def bundled_root_dir() -> Path:
    if is_frozen():
        bundled = _resolve_or_none(getattr(sys, "_MEIPASS", None))
        if bundled is not None:
            return bundled
    return package_root_dir()


def executable_dir() -> Path:
    if is_frozen():
        executable = _resolve_or_none(sys.executable)
        if executable is not None:
            return executable.parent
    argv_path = _resolve_or_none(sys.argv[0] if sys.argv else None)
    return argv_path.parent if argv_path is not None else source_root_dir()


def installed_root() -> Path:
    """Return the immutable application installation/source root."""
    return executable_dir() if is_frozen() else source_root_dir()


def _clean_parts(parts: tuple[str, ...]) -> tuple[str, ...]:
    return tuple((str(part).strip("/\\") for part in parts if str(part)))


def _resource_search_roots() -> tuple[Path, ...]:
    """Return deterministic resource roots without cross-mode fallbacks.

    Frozen releases are hermetic: they may resolve resources only from the
    PyInstaller bundle or the installed executable directory.  They must never
    consult an editable/source checkout, because doing so can hide an incomplete
    release behind stale files from an older source tree.

    Editable/source runs may use the package and project source roots.
    The current working directory is never a resource root in either mode.
    """
    if is_frozen():
        candidates = (
            bundled_root_dir(),
            executable_dir(),
        )
    else:
        candidates = (
            package_root_dir(),
            source_root_dir(),
        )
    unique: list[Path] = []
    seen: set[Path] = set()
    for candidate in candidates:
        resolved = _resolve_or_none(candidate)
        if resolved is not None and resolved not in seen:
            seen.add(resolved)
            unique.append(resolved)
    return tuple(unique)


def bundled_or_source_path(*parts: str) -> Path:
    relative = Path(*_clean_parts(parts)) if parts else Path()
    roots = _resource_search_roots()
    for base in roots:
        candidate = _resolve_or_none(base / relative)
        if candidate is not None and candidate.exists():
            return candidate
    # Preserve the same mode boundary even for a missing resource so callers
    # cannot accidentally escape a frozen release into an editable checkout.
    fallback_root = (
        roots[0] if roots else (bundled_root_dir() if is_frozen() else source_root_dir())
    )
    return (fallback_root / relative).resolve()


def resource_path(*parts: str) -> str:
    return str(bundled_or_source_path(*parts))


def existing_asset_path(*parts: str) -> str:
    """Return an existing packaged/source asset path, otherwise an empty string."""
    path = bundled_or_source_path(*parts)
    return str(path) if path.exists() else ""


def app_root_dir() -> Path:
    """Return the single writable runtime root.

    Windows always uses the user's Roaming profile:
    %APPDATA%\\HERFY-TS

    Installation files stay under Program Files and are never mixed with
    settings, logs, cache, database, downloaded updates, or notification state.
    """
    if IS_WINDOWS:
        roaming = str(os.environ.get("APPDATA") or "").strip()
        target = (
            Path(roaming) / APPDATA_DIR_NAME
            if roaming
            else Path.home() / "AppData" / "Roaming" / APPDATA_DIR_NAME
        )
        return target
    return Path.home() / ".config" / APPDATA_DIR_NAME


def ensure_runtime_dirs() -> Path:
    root = app_root_dir()
    for path in (root, root / "logs", root / "database", root / "cache"):
        path.mkdir(parents=True, exist_ok=True)
    return root


def app_data_path(*parts: str) -> str:
    return str(ensure_runtime_dirs().joinpath(*_clean_parts(parts)).resolve())


def db_file_path(name: str = "products.db") -> str:
    return app_data_path("database", name)


def runtime_cache_path(name: str) -> str:
    return app_data_path("cache", name)


def prepare_runtime_environment() -> str:
    root = ensure_runtime_dirs()
    return str(root)


def load_translations(language: str = DEFAULT_LANGUAGE) -> None:
    """Select the active application language."""
    global translations
    active = i18n.set_language(language)
    translations = i18n.language_entries(active)


def _(text: str) -> str:
    """Translate a key or public source phrase using the central i18n service."""
    return i18n.tr(str(text or ""))


load_translations(DEFAULT_LANGUAGE)


@dataclass(frozen=True)
class CacheTTL:
    metadata: int = 15
    catalog: int = 120


@dataclass(frozen=True)
class AppConfig:
    server_base_url: str
    updates_base_url: str
    http_timeout_seconds: float = 10.0
    request_verify_ssl: bool = True
    realtime_enabled: bool = True
    sync_pull_limit: int = 200
    cache_ttl_seconds: CacheTTL = field(default_factory=CacheTTL)
    production: bool = True


def _default_remote_scheme() -> str:
    parts = urlsplit(str(DEFAULT_SERVER_BASE_URL or "").strip())
    return str(parts.scheme or "https").strip().lower() or "https"


def _prefer_https(host: str, current_scheme: str = "") -> str:
    normalized = str(host or "").strip().lower()
    if normalized in {"localhost", "127.0.0.1", "::1"} or normalized.startswith("192.168."):
        return current_scheme or "http"
    return current_scheme or _default_remote_scheme()


def normalize_api_base_url(url: str, *, default: str = DEFAULT_SERVER_BASE_URL) -> str:
    raw = str(url or "").strip()
    if not raw:
        raw = str(default or "").strip()
    if not raw:
        return ""
    if not raw.startswith(("http://", "https://")):
        bare = raw.lstrip("/")
        host = bare.split("/", 1)[0].split(":", 1)[0].strip().lower()
        raw = f"{_prefer_https(host)}://{bare}"
    parts = urlsplit(raw)
    scheme = _prefer_https(parts.hostname or "", parts.scheme)
    path = str(parts.path or "").rstrip("/")
    if not path.endswith("/api"):
        path = f"{path}/api" if path else "/api"
    return urlunsplit((scheme, parts.netloc, path, "", "")).rstrip("/")


def _build_app_config() -> AppConfig:
    """Build runtime configuration only from the signed server binding.

    Runtime files, environment variables, and command-line locations cannot
    replace the production endpoint or weaken TLS in an approved client build.
    """
    binding = get_server_binding()
    cache = binding.cache_ttl_seconds
    return AppConfig(
        server_base_url=binding.api_base_url,
        updates_base_url=binding.updates_base_url,
        http_timeout_seconds=binding.http_timeout_seconds,
        request_verify_ssl=binding.request_verify_ssl,
        realtime_enabled=binding.realtime_enabled,
        sync_pull_limit=binding.sync_pull_limit,
        cache_ttl_seconds=CacheTTL(
            metadata=cache["metadata"],
            catalog=cache["catalog"],
        ),
        production=True,
    )


@lru_cache(maxsize=1)
def load_app_config() -> AppConfig:
    return _build_app_config()


def get_app_config() -> AppConfig:
    return load_app_config()


def get_server_base_url() -> str:
    return get_app_config().server_base_url


def get_updates_base_url() -> str:
    return get_app_config().updates_base_url


def get_http_timeout_seconds() -> float:
    return get_app_config().http_timeout_seconds


def get_request_verify_ssl() -> bool:
    return get_app_config().request_verify_ssl


def get_cache_ttl() -> CacheTTL:
    return get_app_config().cache_ttl_seconds


_LOGIN_FALLBACK = "Sign in failed. Check the username and password, then try again."
_GENERAL_FALLBACK = "The operation could not be completed. Please try again."
_CANONICAL_ERROR_MESSAGES = {
    "invalid_credentials": "The username or password is incorrect. Check the credentials and try again.",
    "missing_credentials": "Username and password are required.",
    "session_expired": "Your session expired. Sign in again to continue.",
    "server_unavailable": "The server is temporarily unavailable. Wait a moment and try again.",
    "server_timeout": "The server did not respond in time. Check the connection and try again.",
    "connection_failed": "Cannot reach the server. Check the internet connection and try again.",
    "server_release_mismatch": "The deployed server is not compatible with this client release. Deploy the matching HERFY-TS server package, then sign in again.",
    "api_contract_mismatch": "The deployed server API contract does not match this client release. Deploy the matching HERFY-TS server package, then sign in again.",
    "client_version_unapproved": "This HERFY-TS client version is not yet approved by the server. Publish the matching signed client release, then sign in again.",
    "client_version_too_old": "This HERFY-TS client version is below the server minimum. Install the required update, then sign in again.",
    "malformed_response": "The server returned an unreadable response. Try again or contact support.",
    "invalid_response": "The server response was incomplete. Try again or contact support.",
    "profile_missing": "Sign in succeeded, but the account profile is incomplete. Contact the administrator.",
    "permission_denied": "You do not have permission to perform this action.",
    "account_inactive": "This account is inactive. Ask a system administrator to reactivate it.",
    "login_access_denied": "Sign-in was rejected by the server before a session was created. Verify that the account is active and assigned a valid role.",
    "operation_failed": _GENERAL_FALLBACK,
    "login_failed": _LOGIN_FALLBACK,
    "settings_open_failed": "Settings could not be opened. Close other dialogs and try again.",
    "settings_save_failed": "Settings could not be saved. Review the values and try again.",
    "admin_open_failed": "The administration workspace could not be opened. Check the connection and your permissions, then try again.",
    "password_change_failed": "The password could not be changed. Check the current password and try again.",
    "update_install_failed": "The update could not be installed. Try again from the main application or contact support.",
    "update_package_missing": "The update package is not available on the update server. Contact support or retry after the server package is published.",
}


def canonical_error_message(key: str) -> str:
    return _(_CANONICAL_ERROR_MESSAGES.get(str(key or ""), _GENERAL_FALLBACK))


def _clean_error_text(error: Any) -> str:
    text = str(error or "").strip()
    text = re.sub("\\s+", " ", text)
    if "<html" in text.lower() or "traceback" in text.lower():
        return ""
    return text


def classify_user_error(error: Any, *, context: str = "general") -> str:
    raw = str(error or "")
    raw_lower = raw.lower()
    text = _clean_error_text(error)
    lower = text.lower()
    normalized_context = str(context or "general").strip().lower()
    if (
        normalized_context == "password"
        and text
        and any(
            (
                marker in lower
                for marker in (
                    "current password",
                    "old password",
                    "incorrect password",
                    "invalid password",
                )
            )
        )
    ):
        return "password_change_failed"
    if not text:
        if any(
            (
                marker in raw_lower
                for marker in (
                    "502",
                    "503",
                    "504",
                    "bad gateway",
                    "temporarily unavailable",
                )
            )
        ):
            return "server_unavailable"
        if "timeout" in raw_lower or "timed out" in raw_lower:
            return "server_timeout"
        if any(
            (
                marker in raw_lower
                for marker in (
                    "cannot connect",
                    "connection error",
                    "failed to establish",
                )
            )
        ):
            return "connection_failed"
        return "login_failed" if normalized_context == "login" else "operation_failed"
    if any(
        (
            marker in lower
            for marker in (
                "invalid username or password",
                "incorrect username or password",
                "bad credentials",
                "401",
                "unauthorized",
                "not authenticated",
            )
        )
    ):
        return "invalid_credentials" if normalized_context == "login" else "session_expired"
    if "missing token" in lower or "server did not return a session" in lower:
        return "invalid_response"
    if "profile missing" in lower or "profile is incomplete" in lower:
        return "profile_missing"
    if "account is inactive" in lower:
        return "account_inactive"
    if "sign-in was rejected by the server" in lower:
        return "login_access_denied"
    if "timed out" in lower or "timeout" in lower:
        return "server_timeout"
    if any(
        (
            marker in lower
            for marker in (
                "cannot connect",
                "connection error",
                "name resolution",
                "failed to establish",
            )
        )
    ):
        return "connection_failed"
    if any(
        (
            marker in lower
            for marker in (
                "502",
                "503",
                "504",
                "bad gateway",
                "temporarily unavailable",
            )
        )
    ):
        return "server_unavailable"
    if any((marker in lower for marker in ("malformed json", "unreadable response"))):
        return "malformed_response"
    if any((marker in lower for marker in ("invalid response", "incomplete"))):
        return "invalid_response"
    if any((marker in lower for marker in ("permission", "forbidden", "403"))):
        return "permission_denied"
    if normalized_context == "password":
        return "password_change_failed"
    if normalized_context == "settings":
        return "settings_save_failed"
    if normalized_context == "update" and any(
        (marker in lower or marker in raw_lower for marker in ("404", "not found"))
    ):
        return "update_package_missing"
    if normalized_context == "update":
        return "update_install_failed"
    return "login_failed" if normalized_context == "login" else "operation_failed"


def user_error_message(error: Any, *, context: str = "general") -> str:
    text = _clean_error_text(error)
    normalized_context = str(context or "general").strip().lower()
    key = classify_user_error(error, context=normalized_context)
    if normalized_context == "general" and key == "operation_failed" and text:
        return _(text)
    return canonical_error_message(key)


ExceptionClasses: TypeAlias = type[BaseException] | tuple[type[BaseException], ...]
_LOG_MAX_BYTES = 5 * 1024 * 1024
_LOG_BACKUP_COUNT = 5


def _normalize_log_path(path: str | os.PathLike[str] | None) -> str | None:
    if path in (None, ""):
        return None
    try:
        return str(Path(str(path)).expanduser().resolve())
    except OSError:
        return str(path)


def _handler_file_path(handler: logging.Handler) -> str | None:
    filename = getattr(handler, "baseFilename", None)
    return _normalize_log_path(filename) if filename else None


def _has_file_handler(root_logger: logging.Logger, path: str) -> bool:
    normalized = _normalize_log_path(path)
    return any((_handler_file_path(handler) == normalized for handler in root_logger.handlers))


def _ensure_parent_dir(path: str) -> None:
    parent = os.path.dirname(path)
    if not parent:
        return
    os.makedirs(parent, exist_ok=True)


def _make_formatter(log_format: str) -> logging.Formatter:
    return logging.Formatter(log_format)


def _add_file_handler(
    root_logger: logging.Logger,
    log_file: str,
    *,
    level: int,
    formatter: logging.Formatter,
    file_exceptions: ExceptionClasses,
) -> bool:
    normalized = _normalize_log_path(log_file)
    if not normalized or _has_file_handler(root_logger, normalized):
        return False
    try:
        _ensure_parent_dir(normalized)
        handler = RotatingFileHandler(
            normalized,
            maxBytes=_LOG_MAX_BYTES,
            backupCount=_LOG_BACKUP_COUNT,
            encoding="utf-8",
        )
        handler.setLevel(level)
        handler.setFormatter(formatter)
        root_logger.addHandler(handler)
        return True
    except file_exceptions:
        return False


def _add_stream_handler(
    root_logger: logging.Logger, *, level: int, formatter: logging.Formatter
) -> None:
    if any((isinstance(handler, logging.StreamHandler) for handler in root_logger.handlers)):
        return
    handler = logging.StreamHandler()
    handler.setLevel(level)
    handler.setFormatter(formatter)
    root_logger.addHandler(handler)


def configure_root_logging(
    log_file: str | None = None,
    *,
    level: int = logging.INFO,
    log_format: str = "%(asctime)s - %(levelname)s - %(name)s - %(message)s",
    fallback_level: int | None = None,
    file_exceptions: ExceptionClasses = OSError,
    additional_files: Iterable[str] | None = None,
) -> None:
    root_logger = logging.getLogger()
    effective_level = level
    if root_logger.handlers and root_logger.level not in (logging.NOTSET, 0):
        effective_level = min(root_logger.level, level)
    root_logger.setLevel(effective_level)
    formatter = _make_formatter(log_format)
    attached_file = False
    requested_files = []
    if log_file:
        requested_files.append(str(log_file))
    if additional_files:
        requested_files.extend((str(path) for path in additional_files if path))
    for requested in dict.fromkeys(requested_files):
        attached_file = (
            _add_file_handler(
                root_logger,
                requested,
                level=level,
                formatter=formatter,
                file_exceptions=file_exceptions,
            )
            or attached_file
        )
    if not root_logger.handlers or (not attached_file and requested_files):
        _add_stream_handler(
            root_logger,
            level=fallback_level if fallback_level is not None else level,
            formatter=formatter,
        )


def flush_root_logging() -> None:
    for handler in list(logging.getLogger().handlers):
        try:
            handler.flush()
        except (OSError, RuntimeError, ValueError):
            continue


ErrorPresenter = Callable[[str, str], None]
_error_presenter: ErrorPresenter | None = None
_crash_stream: Any | None = None


def candidate_log_dirs() -> list[str]:
    try:
        primary = str((app_root_dir() / "logs").resolve())
    except FILESYSTEM_OPERATION_EXCEPTIONS:
        if sys.platform.startswith("win"):
            base = os.environ.get("APPDATA") or os.path.join(
                os.path.expanduser("~"), "AppData", "Roaming"
            )
            primary = os.path.join(base, APP_RUNTIME_DIR_NAME, "logs")
        else:
            primary = os.path.join(os.path.expanduser("~"), ".config", APP_RUNTIME_DIR_NAME, "logs")
    fallback = str((Path(tempfile.gettempdir()) / APP_RUNTIME_DIR_NAME / "logs").resolve())
    return list(dict.fromkeys([primary, fallback]))


def ensure_log_dir() -> str:
    for log_dir in candidate_log_dirs():
        try:
            os.makedirs(log_dir, exist_ok=True)
            probe = Path(log_dir) / ".write_test"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            return log_dir
        except FILESYSTEM_OPERATION_EXCEPTIONS:
            continue
    raise OSError("No writable log directory is available")


def _rotate_plain_log(path: str | os.PathLike[str]) -> None:
    """Bound logs written directly by faulthandler/plain file APIs."""
    target = Path(path)
    try:
        if not target.is_file() or target.stat().st_size < _LOG_MAX_BYTES:
            return
        oldest = target.with_name(f"{target.name}.{_LOG_BACKUP_COUNT}")
        oldest.unlink(missing_ok=True)
        for index in range(_LOG_BACKUP_COUNT - 1, 0, -1):
            source = target.with_name(f"{target.name}.{index}")
            if source.exists():
                source.replace(target.with_name(f"{target.name}.{index + 1}"))
        target.replace(target.with_name(f"{target.name}.1"))
    except FILESYSTEM_OPERATION_EXCEPTIONS:
        logging.debug("Plain log rotation failed for %s", target, exc_info=True)


def setup_crash_logging() -> None:
    global _crash_stream
    log_dir = ensure_log_dir()
    configure_root_logging(
        os.path.join(log_dir, "desktop.log"),
        level=logging.INFO,
        file_exceptions=FILESYSTEM_OPERATION_EXCEPTIONS,
    )
    try:
        if _crash_stream is None or getattr(_crash_stream, "closed", True):
            _rotate_plain_log(os.path.join(log_dir, "crash.log"))
            _crash_stream = open(
                os.path.join(log_dir, "crash.log"),
                "a",
                encoding="utf-8",
                errors="ignore",
            )
        faulthandler.enable(file=_crash_stream, all_threads=True)
    except FILESYSTEM_OPERATION_EXCEPTIONS:
        try:
            faulthandler.enable(all_threads=True)
        except RuntimeError:
            logging.debug("Crash logger fallback enable failed", exc_info=True)
    logging.info("Crash logging initialized. log_dir=%s", log_dir)


def _crash_report_header() -> str:
    return "\n".join(
        (
            "=" * 78,
            f"timestamp={datetime.now().isoformat(timespec='seconds')}",
            f"app={APP_DISPLAY_NAME}",
            f"version={APP_VERSION}",
            f"python={sys.version}",
            f"executable={sys.executable}",
            f"argv={sys.argv!r}",
            f"cwd={os.getcwd()}",
            "=" * 78,
        )
    )


def write_emergency_crash_report(message: str) -> list[str]:
    payload = f"{_crash_report_header()}\n{message}\n"
    written: list[str] = []
    for log_dir in candidate_log_dirs():
        try:
            os.makedirs(log_dir, exist_ok=True)
            path = os.path.join(log_dir, "fatal_error.log")
            _rotate_plain_log(path)
            with open(path, "a", encoding="utf-8", errors="ignore") as handle:
                handle.write(payload)
                handle.write("\n")
            written.append(path)
            break
        except FILESYSTEM_OPERATION_EXCEPTIONS:
            continue
    flush_root_logging()
    return written


def _log_file_hint() -> str:
    preferred = []
    for log_dir in candidate_log_dirs():
        preferred.extend(
            [
                os.path.join(log_dir, "desktop.log"),
                os.path.join(log_dir, "fatal_error.log"),
            ]
        )
    return "\n".join((f"- {path}" for path in dict.fromkeys(preferred)))


def install_exception_hooks(error_presenter: ErrorPresenter | None = None) -> None:
    global _error_presenter
    if error_presenter is not None:
        _error_presenter = error_presenter

    def excepthook(exc_type: type[BaseException], exc: BaseException, tb: Any) -> None:
        message = "".join(traceback.format_exception(exc_type, exc, tb))
        logging.critical("Unhandled exception:\n%s", message)
        written = write_emergency_crash_report(message)
        hint = "\n".join((f"- {path}" for path in written)) or _log_file_hint()
        if _error_presenter is not None:
            _error_presenter(
                f"Unexpected error - {APP_DISPLAY_NAME}",
                f"The application encountered an unexpected error.\n\nA crash report was written here:\n{hint}",
            )

    sys.excepthook = excepthook

    def thread_excepthook(args: threading.ExceptHookArgs) -> None:
        message = "".join(
            traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback)
        )
        logging.critical(
            "Unhandled thread exception (thread=%s):\n%s",
            getattr(args, "thread", None),
            message,
        )
        write_emergency_crash_report(message)

    threading.excepthook = thread_excepthook
