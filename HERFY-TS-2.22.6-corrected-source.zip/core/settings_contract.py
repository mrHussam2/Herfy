"""Stable client-side settings contract shared by presentation and services."""

from __future__ import annotations

# Canonical user/device-local presentation and expiry settings. Expiry
# classification remains a fixed product policy, not a user preference.
CANONICAL_SETTINGS_DEFAULTS: dict[str, str] = {
    "language": "en",
    "monitoring_enabled": "True",
    "enable_tray_background": "True",
    "enable_desktop_notifications": "True",
    "enable_sounds": "True",
    "expiry_enable_status_colors": "True",
    "expiry_enable_status_icons": "True",
    "notification_sound_default": "default.wav",
    "notification_sound_expired": "expires_today.wav",
    "notification_sound_soon": "expiry_soon.wav",
    "notification_sound_approaching": "expiry_near.wav",
    "notification_sound_near": "expiry_near.wav",
    "notification_sound_tomorrow": "expiry_near.wav",
    "notification_sound_today": "expires_today.wav",
}
