from __future__ import annotations

import logging
import math
import os
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from enum import Enum
from hashlib import sha256
from pathlib import Path
from typing import Any, Literal
from urllib.parse import unquote, urljoin, urlsplit, urlunsplit

from packaging.version import InvalidVersion, Version

from core.errors import PARSE_OPERATION_EXCEPTIONS, SERVICE_OPERATION_EXCEPTIONS

logger = logging.getLogger(__name__)
_TRUE_VALUES = {"true", "1", "yes", "on"}
_FALSE_VALUES = {"false", "0", "no", "off"}


DISPLAY_DATE_FORMAT = "dd-MM-yyyy"
ISO_DATE_FORMAT = "yyyy-MM-dd"
DISPLAY_TIME_FORMAT = "HH:mm"
DISPLAY_DATETIME_FORMAT = "dd-MM-yyyy HH:mm:ss"
DISPLAY_DATE_STRFTIME = "%d-%m-%Y"
DISPLAY_DATETIME_STRFTIME = "%d-%m-%Y %H:%M:%S"
BUSINESS_TIMEZONE = "Asia/Riyadh"
BUSINESS_UTC_OFFSET_HOURS = 3
_BUSINESS_TZ = timezone(timedelta(hours=BUSINESS_UTC_OFFSET_HOURS), name=BUSINESS_TIMEZONE)


def business_timezone():
    """Return the dependency-free Saudi business timezone (UTC+03:00)."""
    return _BUSINESS_TZ


def business_now() -> datetime:
    """Return the current absolute instant represented in Saudi business time."""
    return datetime.now(_BUSINESS_TZ)


def business_today() -> date:
    """Return the Saudi business calendar date used by local expiry classification."""
    return business_now().date()


def business_datetime_from_timestamp(value: float) -> datetime:
    return datetime.fromtimestamp(float(value), tz=_BUSINESS_TZ)


_DIGIT_TRANSLATION = str.maketrans(
    {
        "٠": "0",
        "١": "1",
        "٢": "2",
        "٣": "3",
        "٤": "4",
        "٥": "5",
        "٦": "6",
        "٧": "7",
        "٨": "8",
        "٩": "9",
        "۰": "0",
        "۱": "1",
        "۲": "2",
        "۳": "3",
        "۴": "4",
        "۵": "5",
        "۶": "6",
        "۷": "7",
        "۸": "8",
        "۹": "9",
    }
)


def normalize_ascii_digits(value: Any) -> str:
    """Normalize Arabic/Persian decimal digits without removing leading zeros."""
    return str(value if value is not None else "").translate(_DIGIT_TRANSLATION)


def parse_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    raw = str(value or "").strip().lower()
    if raw in _TRUE_VALUES:
        return True
    if raw in _FALSE_VALUES:
        return False
    return bool(default)


def normalize_bool(value: Any, default: bool = False) -> bool:
    return parse_bool(value, default)


def setting_bool(getter, key: str, default: bool = False) -> bool:
    raw = getter(key, "True" if default else "False")
    return parse_bool(raw, default)


def truthy_env(name: str, default: bool) -> bool:
    return parse_bool(os.getenv(name), default)


def should_require_update_sha256() -> bool:
    return truthy_env("PTS_REQUIRE_UPDATE_SHA256", True)


def parse_plain_number(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    try:
        number = float(normalize_ascii_digits(value).replace(",", "").strip())
        return number if math.isfinite(number) else 0.0
    except (TypeError, ValueError, OverflowError):
        logger.debug("Failed to parse plain number: %r", value, exc_info=True)
        return 0.0


def format_plain_number(value: Any) -> str:
    try:
        number = float(normalize_ascii_digits(value))
    except (TypeError, ValueError, OverflowError):
        logger.debug("Failed to format plain number: %r", value, exc_info=True)
        return str(value or "")
    if not math.isfinite(number):
        return str(value or "")
    if abs(number - int(number)) < 1e-09:
        return str(int(number))
    return f"{number:.2f}".rstrip("0").rstrip(".")


def parse_excel_number(value: Any) -> float:
    if value is None:
        return 0.0
    if isinstance(value, int | float):
        number = float(value)
        return number if math.isfinite(number) else 0.0
    text = normalize_ascii_digits(value).strip()
    if not text or text.lower() == "nan":
        return 0.0
    negative = text.startswith("(") and text.endswith(")")
    numeric_text = text.strip("()").replace(",", "")
    try:
        parsed = float(numeric_text)
    except (TypeError, ValueError, OverflowError):
        logger.debug("Failed to parse Excel number: %r", value, exc_info=True)
        return 0.0
    if not math.isfinite(parsed):
        return 0.0
    return -parsed if negative else parsed


def normalize_text(value: Any, default: str = "") -> str:
    try:
        text = str(value if value is not None else default).strip()
        return text if text else str(default)
    except SERVICE_OPERATION_EXCEPTIONS:
        return str(default)


def looks_like_material_code(value: object, material: str = "") -> bool:
    text = str(value or "").strip()
    material_text = str(material or "").strip()
    if not text:
        return True
    if material_text and text.casefold() == material_text.casefold():
        return True
    compact = text.replace(" ", "").replace("-", "").replace("_", "")
    return compact.isdigit()


def best_product_name(material: str, *candidates: object) -> str:
    for candidate in candidates:
        text = str(candidate or "").strip()
        if text and not looks_like_material_code(text, material):
            return text
    for candidate in candidates:
        text = str(candidate or "").strip()
        if text:
            return text
    return str(material or "").strip()


def clean_text(value: object = "") -> str:
    return str(value or "").strip()


def safe_get(obj: Any, key: str, default: Any = None) -> Any:
    try:
        if isinstance(obj, dict):
            return obj.get(key, default)
        if obj is None:
            return default
        if hasattr(obj, "keys"):
            try:
                keys = obj.keys()
            except SERVICE_OPERATION_EXCEPTIONS:
                keys = ()
            if key in keys:
                return obj[key]
        return getattr(obj, key, default)
    except SERVICE_OPERATION_EXCEPTIONS:
        return default


def normalize_int(value: Any, default: int = 0) -> int:
    try:
        if value in (None, ""):
            return int(default)
        number = float(normalize_ascii_digits(value))
        if not math.isfinite(number):
            return int(default)
        return int(number)
    except (
        AttributeError,
        LookupError,
        OSError,
        RuntimeError,
        TypeError,
        ValueError,
        OverflowError,
    ):
        return int(default)


def first_value(source: dict[str, Any] | None, *keys: str, default: Any = "") -> Any:
    data = source if isinstance(source, dict) else {}
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return value
    return default


def clean_string_list(values: Iterable[Any] | Any | None, *, split_csv: bool = False) -> list[str]:
    if values is None:
        return []
    if isinstance(values, str | bytes):
        iterable = [part.strip() for part in str(values).split(",")] if split_csv else [str(values)]
    else:
        iterable = list(values)
    result: list[str] = []
    seen: set[str] = set()
    for value in iterable:
        item = str(value or "").strip()
        if not item:
            continue
        key = item.casefold()
        if key in seen:
            continue
        seen.add(key)
        result.append(item)
    return result


def call_if_callable(func: Any, *args: Any, default: Any = None, **kwargs: Any) -> Any:
    if not callable(func):
        return default
    return func(*args, **kwargs)


def noop(*args: Any, **kwargs: Any) -> None:
    return None


def normalized_result_key(obj: Any, default: str = "secondary") -> str:
    return str(getattr(obj, "_result", default) or default)


def normalize_stored_product(item: Any) -> dict[str, Any]:
    """Convert the current server stored-product DTO to the client catalogue DTO."""
    data = item if isinstance(item, dict) else {}
    material_number = normalize_text(data.get("material_number"))
    if not material_number:
        raise ValueError("Stored product is missing material_number")
    name = normalize_text(data.get("name"), material_number)
    return {
        "material_number": material_number,
        "name": name,
    }


def normalize_usage_product(item: Any) -> dict[str, Any]:
    """Convert the current server usage-product DTO to the canonical local usage DTO."""
    data = item if isinstance(item, dict) else {}
    material = normalize_text(data.get("material_number") or data.get("material"))
    if not material:
        raise ValueError("Usage product is missing material_number")
    return {
        "material_number": material,
        "material": material,
        "name": normalize_text(data.get("name"), material),
        "uom": normalize_text(data.get("uom")),
    }


_CANONICAL_SYNC_OPERATIONS = frozenset(
    {
        "create",
        "update",
        "delete",
        "status_change",
        "role_change",
        "permission_change",
        "scope_change",
    }
)


def change_entity(change: dict) -> str:
    return normalize_text(change.get("entity_type")).lower()


def change_operation(change: dict) -> str:
    operation = normalize_text(change.get("operation")).lower()
    if operation not in _CANONICAL_SYNC_OPERATIONS:
        raise ValueError(f"Unsupported sync operation: {operation!r}")
    return operation


def change_payload(change: dict) -> dict:
    payload = change.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("Canonical sync event payload must be an object")
    return dict(payload)


def normalize_branch_payload(item: Any) -> dict[str, Any]:
    data = item if isinstance(item, dict) else {}
    branch_id = normalize_text(data.get("branch_id"))
    if not branch_id:
        raise ValueError("Branch payload is missing branch_id")
    return {
        "branch_id": branch_id,
        "region_id": normalize_text(data.get("region_id")),
        "area_id": normalize_text(data.get("area_id")),
        "name": normalize_text(data.get("name"), branch_id),
        "is_active": parse_bool(data.get("is_active"), True),
        "revision": normalize_int(data.get("revision"), 0),
    }


def normalize_tracking_item(item: Any, stored_name: str = "") -> dict[str, Any]:
    """Convert the current server tracking DTO into one canonical client tracking row."""
    data = item if isinstance(item, dict) else {}
    remote_id = normalize_text(data.get("id"))
    branch = normalize_text(data.get("branch_id"))
    material_number = normalize_text(data.get("material_number"))
    if not remote_id or not branch or not material_number:
        raise ValueError("Tracking item is missing id, branch_id, or material_number")
    material_name = normalize_text(data.get("material_name"))
    name = best_product_name(material_number, material_name, stored_name, material_number)
    return {
        "id": f"{branch}::{remote_id}",
        "doc_id": remote_id,
        "branch": branch,
        "material_number": material_number,
        "name": name,
        "quantity": normalize_int(data.get("quantity"), 0),
        "production_date": normalize_text(data.get("production_date")),
        "expiry_date": normalize_text(data.get("expiry_date")),
        "notes": normalize_text(data.get("notes")),
        "responsible_user_id": normalize_text(data.get("responsible_user_id")),
        "revision": normalize_int(data.get("revision"), 0),
        "is_deleted": parse_bool(data.get("is_deleted"), False),
        "created_at": normalize_text(data.get("created_at")),
        "updated_at": normalize_text(data.get("updated_at")),
        "deleted_at": normalize_text(data.get("deleted_at")),
        "deleted_by": normalize_text(data.get("deleted_by")),
        "created_by": normalize_text(data.get("created_by")),
        "updated_by": normalize_text(data.get("updated_by")),
    }


@dataclass(frozen=True, slots=True)
class TrackingScope:
    branches: tuple[str, ...]

    @classmethod
    def from_value(cls, value: Any) -> "TrackingScope":
        if isinstance(value, TrackingScope):
            return value
        if isinstance(value, str):
            branches: tuple[str, ...] = (value.strip(),) if value.strip() else ()
        else:
            branches = tuple(
                str(branch or "").strip() for branch in value or () if str(branch or "").strip()
            )
        return cls(tuple(dict.fromkeys(branches)))

    @property
    def hash(self) -> str:
        payload = "\n".join(branch.casefold() for branch in self.branches)
        return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True, order=True)
class TrackingKey:
    branch_id: str
    material_number: str
    production_date: date | None
    expiry_date: date


@dataclass(frozen=True, slots=True)
class RemoteTrackingId:
    value: str


@dataclass(frozen=True, slots=True)
class TrackingRecord:
    key: TrackingKey
    remote_id: RemoteTrackingId
    product_name: str
    quantity: int
    branch_name: str
    revision: int
    updated_at: datetime


@dataclass(frozen=True, slots=True)
class TrackingBaseline:
    revision: int
    scope: TrackingScope
    records: tuple[TrackingRecord, ...]
    generated_at: datetime


@dataclass(frozen=True, slots=True)
class TrackingDelta:
    from_revision: int
    to_revision: int
    inserted: tuple[TrackingRecord, ...]
    updated: tuple[TrackingRecord, ...]
    deleted: tuple[TrackingKey, ...]


StoreEventKind = Literal[
    "baseline_committed",
    "delta_applied",
    "delta_queued",
    "revision_gap",
    "upserted",
    "removed",
    "reset",
]


@dataclass(frozen=True, slots=True)
class TrackingSnapshot:
    generation: int
    revision: int | None
    scope_hash: str
    baseline_ready: bool
    records: tuple[TrackingRecord, ...]


@dataclass(frozen=True, slots=True)
class TrackingStoreEvent:
    kind: StoreEventKind
    snapshot: TrackingSnapshot
    inserted: tuple[TrackingRecord, ...] = ()
    updated: tuple[TrackingRecord, ...] = ()
    deleted: tuple[TrackingKey, ...] = ()
    reason: str = ""


@dataclass(frozen=True, slots=True)
class CommitResult:
    accepted: bool
    reason: str
    event: TrackingStoreEvent | None = None


def tracking_row_text(row: Mapping[str, Any] | None, key: str) -> str:
    source = row if isinstance(row, Mapping) else {}
    return str(source.get(key) or "").strip()


def _date_or_none(value: str) -> date | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def tracking_key_from_row(row: Mapping[str, Any] | None) -> TrackingKey | None:
    branch = tracking_row_text(row, "branch")
    material = tracking_row_text(row, "material_number")
    production = _date_or_none(tracking_row_text(row, "production_date"))
    expiry = _date_or_none(tracking_row_text(row, "expiry_date"))
    if not branch or not material or expiry is None:
        return None
    return TrackingKey(
        branch_id=branch,
        material_number=material,
        production_date=production,
        expiry_date=expiry,
    )


def tracking_record_from_row(row: Mapping[str, Any] | None) -> TrackingRecord | None:
    key = tracking_key_from_row(row)
    if key is None:
        return None
    remote_id = tracking_row_text(row, "doc_id") or tracking_row_text(row, "id")
    if "::" in remote_id:
        remote_id = remote_id.split("::", 1)[1].strip()
    try:
        quantity = int((row or {}).get("quantity") or 0)
    except (TypeError, ValueError):
        quantity = 0
    try:
        revision = int((row or {}).get("revision") or 0)
    except (TypeError, ValueError):
        revision = 0
    updated_text = tracking_row_text(row, "updated_at") or tracking_row_text(row, "created_at")
    try:
        updated_at = datetime.fromisoformat(updated_text.replace("Z", "+00:00"))
    except ValueError:
        updated_at = datetime.now(timezone.utc)
    product_name = tracking_row_text(row, "name")
    branch_name = tracking_row_text(row, "branch_name")
    return TrackingRecord(
        key=key,
        remote_id=RemoteTrackingId(remote_id),
        product_name=product_name or key.material_number,
        branch_name=branch_name,
        quantity=quantity,
        revision=revision,
        updated_at=updated_at,
    )


def tracking_record_identity_keys(row: Mapping[str, Any] | None) -> tuple[str, ...]:
    branch = tracking_row_text(row, "branch").casefold()
    material = tracking_row_text(row, "material_number").casefold()
    production = tracking_row_text(row, "production_date")
    expiry = tracking_row_text(row, "expiry_date")
    remote_id = tracking_row_text(row, "doc_id") or tracking_row_text(row, "id")
    if "::" in remote_id:
        id_branch, bare_id = remote_id.split("::", 1)
        branch = branch or id_branch.strip().casefold()
        remote_id = bare_id.strip()

    keys: list[str] = []
    if material and expiry:
        keys.append(f"logical:{branch}|{material}|{production}|{expiry}")
    if remote_id:
        keys.append(f"remote:{branch}|{remote_id.casefold()}")
    return tuple(dict.fromkeys(keys))


def deduplicate_tracking_records(
    rows: Iterable[Mapping[str, Any]] | None,
) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for row in rows or ():
        if not isinstance(row, Mapping):
            continue
        copied = dict(row)
        keys = tracking_record_identity_keys(copied)
        if keys and any(key in seen for key in keys):
            continue
        result.append(copied)
        seen.update(keys)
    return result


def normalize_remote_id(data: Any) -> str:
    """Read a remote tracking identifier from the canonical row shape."""
    source = data if isinstance(data, dict) else {}
    value = normalize_text(source.get("doc_id") or source.get("id"))
    if "::" in value:
        value = value.split("::", 1)[1].strip()
    return "" if value == "0" else value


class ExpiryStatusKind(str, Enum):
    UNKNOWN = "unknown"
    VALID = "valid"
    EXPIRING_SOON = "expiring_soon"
    EXPIRING_APPROACHING = "expiring_approaching"
    EXPIRING_NEAR = "expiring_near"
    EXPIRES_TOMORROW = "expires_tomorrow"
    EXPIRES_TODAY = "expires_today"
    EXPIRED = "expired"


@dataclass(frozen=True, slots=True)
class ExpiryStatusResult:
    kind: ExpiryStatusKind
    severity_rank: int
    days_remaining: int | None
    days_expired: int | None
    label_key: str
    detail_key: str
    should_notify_default: bool
    notification_priority: str
    sort_weight: int


_KIND_META = {
    ExpiryStatusKind.UNKNOWN: (
        0,
        "expiry.status.unknown",
        "expiry.detail.unknown",
        False,
        "none",
        0,
    ),
    ExpiryStatusKind.VALID: (
        0,
        "expiry.status.valid",
        "expiry.detail.remaining_days",
        False,
        "none",
        10,
    ),
    ExpiryStatusKind.EXPIRING_SOON: (
        1,
        "expiry.status.expiring_soon",
        "expiry.detail.remaining_days",
        True,
        "low",
        20,
    ),
    ExpiryStatusKind.EXPIRING_APPROACHING: (
        2,
        "expiry.status.expiring_approaching",
        "expiry.detail.remaining_days",
        True,
        "medium",
        30,
    ),
    ExpiryStatusKind.EXPIRING_NEAR: (
        3,
        "expiry.status.expiring_near",
        "expiry.detail.remaining_days",
        True,
        "high",
        40,
    ),
    ExpiryStatusKind.EXPIRES_TOMORROW: (
        4,
        "expiry.status.expires_tomorrow",
        "expiry.detail.remaining_day",
        True,
        "high",
        50,
    ),
    ExpiryStatusKind.EXPIRES_TODAY: (
        5,
        "expiry.status.expires_today",
        "expiry.detail.expires_today",
        True,
        "urgent",
        60,
    ),
    ExpiryStatusKind.EXPIRED: (
        6,
        "expiry.status.expired",
        "expiry.detail.expired_days_ago",
        True,
        "urgent",
        70,
    ),
}

EXPIRY_VALID_DAYS = 30
EXPIRY_SOON_MIN_DAYS = 16
EXPIRY_APPROACHING_MIN_DAYS = 8
EXPIRY_NEAR_MIN_DAYS = 2


def parse_expiry_date(value: Any) -> date | None:
    text = str(value or "").strip()
    if not text:
        return None
    for raw_candidate in (text[:10], text):
        candidate = raw_candidate.strip()
        if not candidate:
            continue
        for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%Y/%m/%d"):
            try:
                return datetime.strptime(candidate, fmt).date()
            except PARSE_OPERATION_EXCEPTIONS:
                continue
    return None


def _result(
    kind: ExpiryStatusKind, days_remaining: int | None, days_expired: int | None
) -> ExpiryStatusResult:
    severity, label_key, detail_key, should_notify, priority, sort_weight = _KIND_META[kind]
    return ExpiryStatusResult(
        kind=kind,
        severity_rank=int(severity),
        days_remaining=days_remaining,
        days_expired=days_expired,
        label_key=label_key,
        detail_key=detail_key,
        should_notify_default=should_notify,
        notification_priority=priority,
        sort_weight=sort_weight,
    )


def classify_expiry_days(days_remaining: int | None) -> ExpiryStatusResult:
    """Classify an expiry date with HERFY's fixed 30-day policy."""
    if days_remaining is None:
        return _result(ExpiryStatusKind.UNKNOWN, None, None)
    days = int(days_remaining)
    if days < 0:
        return _result(ExpiryStatusKind.EXPIRED, days, abs(days))
    if days == 0:
        return _result(ExpiryStatusKind.EXPIRES_TODAY, days, None)
    if days == 1:
        return _result(ExpiryStatusKind.EXPIRES_TOMORROW, days, None)
    if EXPIRY_NEAR_MIN_DAYS <= days <= 7:
        return _result(ExpiryStatusKind.EXPIRING_NEAR, days, None)
    if EXPIRY_APPROACHING_MIN_DAYS <= days <= 15:
        return _result(ExpiryStatusKind.EXPIRING_APPROACHING, days, None)
    if EXPIRY_SOON_MIN_DAYS <= days <= 29:
        return _result(ExpiryStatusKind.EXPIRING_SOON, days, None)
    return _result(ExpiryStatusKind.VALID, days, None)


def classify_expiry_date(
    expiry_value: Any,
    *,
    today: date | None = None,
) -> ExpiryStatusResult:
    expiry = parse_expiry_date(expiry_value)
    if expiry is None:
        return classify_expiry_days(None)
    current_day = today or business_today()
    return classify_expiry_days((expiry - current_day).days)


def row_expiry_value(row: Mapping[str, Any] | None) -> str:
    data = row if isinstance(row, Mapping) else {}
    return str(data.get("expiry_date") or "").strip()


def expiry_progress_percent(
    kind_or_result: ExpiryStatusKind | ExpiryStatusResult | str,
    *,
    days_remaining: int | None = None,
) -> int:
    """Return proximity-to-expiry progress from 0 to 100.

    Inside the fixed 30-day window the value follows
    ((T - remaining_days) / T) * 100 and therefore increases monotonically as
    expiry approaches. Expired rows retain the same visual bar area at 100%,
    while their text switches to elapsed-since-expiry presentation.
    """
    if isinstance(kind_or_result, ExpiryStatusResult):
        kind = kind_or_result.kind
        days = kind_or_result.days_remaining
    else:
        try:
            kind = ExpiryStatusKind(str(kind_or_result))
        except ValueError:
            kind = ExpiryStatusKind.UNKNOWN
        days = days_remaining

    try:
        remaining = None if days is None else int(days)
    except (TypeError, ValueError):
        remaining = None

    if kind in {ExpiryStatusKind.UNKNOWN, ExpiryStatusKind.VALID} or remaining is None:
        return 0
    if kind == ExpiryStatusKind.EXPIRED:
        return 100
    progress = ((EXPIRY_VALID_DAYS - remaining) / EXPIRY_VALID_DAYS) * 100.0
    return max(0, min(100, int(round(progress))))


class VersionAction(str, Enum):
    ALLOW = "allow"
    OPTIONAL_UPDATE = "optional_update"
    MANDATORY_UPDATE = "mandatory_update"
    BLOCK_CLIENT_NEWER = "block_client_newer"
    BLOCK_INVALID_CONTRACT = "block_invalid_contract"


@dataclass(frozen=True, slots=True)
class VersionCompatibilityDecision:
    action: VersionAction
    client_version: str
    server_version: str
    latest_client_version: str
    minimum_supported_version: str
    update_mode: str
    reason: str

    @property
    def allowed(self) -> bool:
        return self.action in {VersionAction.ALLOW, VersionAction.OPTIONAL_UPDATE}

    @property
    def update_available(self) -> bool:
        return self.action in {
            VersionAction.OPTIONAL_UPDATE,
            VersionAction.MANDATORY_UPDATE,
        }


def parse_semver(version: Any) -> tuple[int, int, int]:
    parts = []
    for part in normalize_text(version).split("."):
        try:
            parts.append(int(part))
        except (TypeError, ValueError):
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return (parts[0], parts[1], parts[2])


def _packaging_version(value: Any) -> Version:
    text = normalize_text(value) or "0"
    try:
        return Version(text)
    except InvalidVersion:
        return Version(".".join((str(part) for part in parse_semver(text))))


def should_update(local_version: str, remote_version: str) -> bool:
    return _packaging_version(remote_version) > _packaging_version(local_version)


def compare_versions(left: str, right: str) -> int:
    left_version = _packaging_version(left)
    right_version = _packaging_version(right)
    return (left_version > right_version) - (left_version < right_version)


def evaluate_version_compatibility(
    *,
    client_version: str,
    server_version: str,
    latest_client_version: str = "",
    minimum_supported_version: str = "",
    update_mode: str = "none",
    contract_version: str = "",
) -> VersionCompatibilityDecision:
    client = normalize_text(client_version)
    server = normalize_text(server_version)
    latest = normalize_text(latest_client_version)
    minimum = normalize_text(minimum_supported_version)
    contract = normalize_text(contract_version)
    mode = normalize_text(update_mode).lower()

    if not client or not server or not latest or not minimum or not contract:
        return VersionCompatibilityDecision(
            VersionAction.BLOCK_INVALID_CONTRACT,
            client,
            server,
            latest,
            minimum,
            mode,
            "missing_version_contract",
        )

    if compare_versions(minimum, latest) > 0:
        return VersionCompatibilityDecision(
            VersionAction.BLOCK_INVALID_CONTRACT,
            client,
            server,
            latest,
            minimum,
            mode,
            "minimum_newer_than_latest",
        )

    if compare_versions(client, latest) > 0:
        return VersionCompatibilityDecision(
            VersionAction.BLOCK_CLIENT_NEWER,
            client,
            server,
            latest,
            minimum,
            "blocked",
            "client_newer_than_approved_release",
        )

    if compare_versions(client, minimum) < 0:
        return VersionCompatibilityDecision(
            VersionAction.MANDATORY_UPDATE,
            client,
            server,
            latest,
            minimum,
            "mandatory",
            "below_minimum_supported_version",
        )

    if mode not in {"none", "optional", "mandatory"}:
        return VersionCompatibilityDecision(
            VersionAction.BLOCK_INVALID_CONTRACT,
            client,
            server,
            latest,
            minimum,
            mode,
            "invalid_update_mode",
        )

    if compare_versions(client, latest) < 0:
        if mode == "mandatory":
            return VersionCompatibilityDecision(
                VersionAction.MANDATORY_UPDATE,
                client,
                server,
                latest,
                minimum,
                "mandatory",
                "update_available",
            )
        if mode == "optional":
            return VersionCompatibilityDecision(
                VersionAction.OPTIONAL_UPDATE,
                client,
                server,
                latest,
                minimum,
                "optional",
                "update_available",
            )
        return VersionCompatibilityDecision(
            VersionAction.ALLOW,
            client,
            server,
            latest,
            minimum,
            "none",
            "compatible_update_suppressed",
        )

    return VersionCompatibilityDecision(
        VersionAction.ALLOW,
        client,
        server,
        latest,
        minimum,
        "none",
        "compatible",
    )


_LOCAL_UPDATE_HOSTS = {"localhost", "127.0.0.1", "::1"}
_LOCAL_UPDATE_PREFIXES = (
    "127.",
    "10.",
    "192.168.",
    *(f"172.{index}." for index in range(16, 32)),
)
_SAFE_FILENAME_PATTERN = re.compile(r"[^\w.\- ]+", re.UNICODE)


def _hostname(value: str) -> str:
    return str(urlsplit(str(value or "")).hostname or "").strip().lower()


def _is_local_update_host(hostname: str) -> bool:
    host = str(hostname or "").strip().lower()
    return host in _LOCAL_UPDATE_HOSTS or host.startswith(_LOCAL_UPDATE_PREFIXES)


def _allowed_update_hosts(base_url: str) -> set[str]:
    """Return only the host approved by the canonical update-base binding."""
    base_host = _hostname(base_url)
    return {base_host} if base_host else set()


def _is_allowed_download_url(url: str, base_url: str) -> bool:
    parts = urlsplit(str(url or ""))
    scheme = str(parts.scheme or "").lower()
    host = str(parts.hostname or "").lower()
    if scheme not in {"http", "https"} or not host:
        return False
    if parts.username is not None or parts.password is not None:
        return False
    try:
        _ = parts.port
    except ValueError:
        return False
    if _is_local_update_host(host):
        base_host = _hostname(base_url)
        return _is_local_update_host(base_host)
    return scheme == "https" and host in _allowed_update_hosts(base_url)


def resolve_download_url(value: Any, base_url: str) -> str:
    """Resolve only the URL supplied by the canonical server manifest."""
    text = str(value or "").replace("\\", "/").strip()
    if not text or text.startswith("//"):
        return ""
    normalized_base = str(base_url or "").strip().rstrip("/")
    if text.lower().startswith(("http://", "https://")):
        candidate = text
    else:
        if not normalized_base:
            return ""
        candidate = urljoin(f"{normalized_base}/", text.lstrip("/"))
    parts = urlsplit(candidate)
    normalized = urlunsplit(
        (
            str(parts.scheme or "").lower(),
            parts.netloc,
            parts.path or "/",
            parts.query,
            "",
        )
    )
    return normalized if _is_allowed_download_url(normalized, normalized_base) else ""


def safe_update_filename(
    value: Any, fallback: str, *, allowed_suffixes: tuple[str, ...] = ()
) -> str:
    fallback_raw = str(fallback or "update.bin").replace("\\", "/")
    fallback_name = Path(fallback_raw).name.strip()
    fallback_name = _SAFE_FILENAME_PATTERN.sub("_", fallback_name)
    fallback_name = re.sub("_+", "_", fallback_name).strip(" ._") or "update.bin"
    raw = unquote(str(value or "")).replace("\\", "/").replace("\x00", "").strip()
    raw = raw.strip("\"'").split("?", 1)[0].split("#", 1)[0]
    name = Path(raw).name.strip() if raw else fallback_name
    name = _SAFE_FILENAME_PATTERN.sub("_", name)
    name = re.sub("_+", "_", name).strip(" ._")
    if not name or name in {".", ".."}:
        name = fallback_name
    allowed = tuple(s.lower() for s in allowed_suffixes if s)
    if allowed:
        suffix = Path(name).suffix.lower()
        fallback_suffix = Path(fallback_name).suffix.lower()
        if not suffix and fallback_suffix in allowed:
            name = f"{name}{fallback_suffix}"
            suffix = fallback_suffix
        if suffix not in allowed:
            return fallback_name
    return name or fallback_name
