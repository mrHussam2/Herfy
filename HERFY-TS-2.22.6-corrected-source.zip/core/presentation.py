from __future__ import annotations

import math
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from datetime import date, datetime
from typing import Any

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.i18n import format_days_text, is_rtl, normalize_language_code, tr
from core.models import (
    DISPLAY_DATE_STRFTIME,
    DISPLAY_DATETIME_STRFTIME,
    ExpiryStatusKind,
    ExpiryStatusResult,
    business_timezone,
    business_today,
    classify_expiry_date,
    expiry_progress_percent,
    normalize_ascii_digits,
    normalize_int,
    parse_bool,
    parse_plain_number,
    row_expiry_value,
)
from core.models import (
    clean_text as _text,
)
from core.permissions import (
    PermissionContext,
    PermissionService,
)
from core.permissions import (
    normalize_role as _normalize_role,
)
from core.permissions import (
    role_labels as _role_labels,
)
from core.settings import APP_DISPLAY_NAME, _


def _parse_temporal(value: Any) -> date | datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, date):
        return value
    text = normalize_ascii_digits(value).strip()
    if not text:
        return None
    try:
        if len(text) == 10 and text[4] == "-" and text[7] == "-":
            return date.fromisoformat(text)
    except ValueError:
        pass
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        pass
    try:
        return datetime.strptime(text, DISPLAY_DATETIME_STRFTIME)
    except ValueError:
        pass
    try:
        return datetime.strptime(text, DISPLAY_DATE_STRFTIME).date()
    except ValueError:
        return None


def _business_datetime(value: datetime) -> datetime:
    # Offset-aware server timestamps represent an absolute instant and are
    # presented in the business timezone. Naive local client timestamps retain
    # their wall-clock value instead of being guessed as UTC.
    if value.tzinfo is None or value.utcoffset() is None:
        return value
    return value.astimezone(business_timezone())


def format_display_date(value: Any, *, fallback: str = "—") -> str:
    """Format a date for UI/print surfaces without changing the stored ISO value."""
    parsed = _parse_temporal(value)
    if parsed is None:
        text = normalize_ascii_digits(value).strip()
        return text or fallback
    if isinstance(parsed, datetime):
        parsed = _business_datetime(parsed).date()
    return normalize_ascii_digits(parsed.strftime(DISPLAY_DATE_STRFTIME))


def format_display_datetime(value: Any, *, fallback: str = "—") -> str:
    """Format a timestamp using ASCII digits and Asia/Riyadh for aware instants."""
    parsed = _parse_temporal(value)
    if parsed is None:
        text = normalize_ascii_digits(value).strip()
        return text or fallback
    if isinstance(parsed, datetime):
        return normalize_ascii_digits(
            _business_datetime(parsed).strftime(DISPLAY_DATETIME_STRFTIME)
        )
    return normalize_ascii_digits(parsed.strftime(DISPLAY_DATE_STRFTIME))


def normalize_role(value: object) -> str:
    """Presentation-safe role normalization delegated to the domain authority."""
    return _normalize_role(str(value or ""))


def role_labels(language: str) -> dict[str, str]:
    """Return display labels without exposing domain implementation to Qt."""
    return dict(_role_labels(str(language or "")) or {})


__all__ = ["normalize_role", "role_labels"]


@dataclass(frozen=True)
class HomeDashboardStats:
    branches: int
    tracked: int
    expiring: int
    expired: int
    usage: int
    stored: int

    def as_dict(self) -> dict[str, int]:
        return {
            "branches": int(self.branches),
            "tracked": int(self.tracked),
            "expiring": int(self.expiring),
            "expired": int(self.expired),
            "usage": int(self.usage),
            "stored": int(self.stored),
        }


@dataclass(frozen=True)
class HomeDashboardSnapshot:
    ctx: PermissionContext
    profile: Any
    is_ar: bool
    username: str
    role_txt: str
    allowed: tuple[str, ...]
    active_branch: str
    values: HomeDashboardStats
    can_manage_org: bool
    stored_available: bool = True

    def as_dict(self) -> dict[str, object]:
        return {
            "ctx": self.ctx,
            "profile": self.profile,
            "is_ar": self.is_ar,
            "username": self.username,
            "role_txt": self.role_txt,
            "allowed": list(self.allowed),
            "active_branch": self.active_branch,
            "values": self.values.as_dict(),
            "can_manage_org": bool(self.can_manage_org),
            "data_available": {"stored": bool(self.stored_available)},
        }


class HomeDashboardService:
    def __init__(self, application: Any) -> None:
        self._app = application

    def _safe_int_setting(self, key: str, default: int) -> int:
        try:
            return int(self._app.get_setting(key, str(default)))
        except SERVICE_OPERATION_EXCEPTIONS:
            return int(default)
        except (TypeError, ValueError):
            return int(default)

    def _allowed_branches(self, ctx: PermissionContext) -> list[str]:
        return [
            str(branch).strip()
            for branch in self._app.allowed_branches() or ctx.scope.branches or []
            if str(branch).strip()
        ]

    def _safe_fetch_tracking_rows(self, ctx: PermissionContext, allowed: list[str]) -> list[dict]:
        branch_hint = (
            "all"
            if ctx.scope.all_branches or len(allowed) != 1
            else self._app.active_branch() or (allowed[0] if allowed else "")
        )
        try:
            rows = self._app.cached_tracking_rows(branch_hint)
        except SERVICE_OPERATION_EXCEPTIONS:
            rows = []
        if not isinstance(rows, list):
            rows = []
        if not ctx.scope.all_branches:
            # Never use an unscoped cache record to infer visibility. Missing
            # branch metadata cannot authorize a record for a limited account.
            allowed_set = {branch.lower() for branch in allowed}
            rows = [
                row
                for row in rows
                if isinstance(row, dict)
                and str(row.get("branch") or "").strip().lower() in allowed_set
            ]
        return rows

    def _active_branch(
        self, *, allowed: list[str], ctx: PermissionContext, view_branch: str | None
    ) -> str:
        active_branch = str(
            view_branch
            if view_branch is not None
            else self._app.active_branch() or ctx.active_branch or ""
        ).strip()
        if not active_branch or active_branch.lower() == "all":
            active_branch = allowed[0] if len(allowed) == 1 else ""
        return active_branch

    def _expiry_counters(self, rows: list[dict]) -> tuple[int, int]:
        warn = 30
        expiring_count = 0
        expired_count = 0
        today = business_today()
        for row in rows:
            exp_date = str((row or {}).get("expiry_date", "") or "").strip()
            if not exp_date:
                continue
            try:
                expiry_date = datetime.strptime(exp_date, "%Y-%m-%d").date()
            except (TypeError, ValueError):
                continue
            delta = (expiry_date - today).days
            if 0 <= delta < warn:
                expiring_count += 1
            elif delta < 0:
                expired_count += 1
        return (expiring_count, expired_count)

    def _safe_can_manage_org(self) -> bool:
        try:
            return bool(self._app.can_manage_org())
        except SERVICE_OPERATION_EXCEPTIONS:
            return False

    def build_snapshot(
        self,
        *,
        profile: Any = None,
        permission_context: PermissionContext | None = None,
        view_branch: str | None = None,
        is_ar: bool = False,
    ) -> HomeDashboardSnapshot:
        ctx = permission_context or self._app.permission_context()
        username = str(
            getattr(profile, "display_name", "")
            or getattr(ctx, "display_name", "")
            or getattr(profile, "username", "")
            or ctx.username
            or ""
        ).strip()
        role_txt = PermissionService.role_label(
            permission_context=ctx, language="ar" if is_ar else "en"
        )
        allowed = self._allowed_branches(ctx)
        active_branch = self._active_branch(allowed=allowed, ctx=ctx, view_branch=view_branch)
        tracked_rows = self._safe_fetch_tracking_rows(ctx, allowed)
        expiring_count, expired_recent_count = self._expiry_counters(tracked_rows)
        return HomeDashboardSnapshot(
            ctx=ctx,
            profile=profile,
            is_ar=bool(is_ar),
            username=username,
            role_txt=role_txt,
            allowed=tuple(allowed),
            active_branch=active_branch,
            values=HomeDashboardStats(
                branches=len(allowed),
                tracked=len(tracked_rows),
                expiring=expiring_count,
                expired=expired_recent_count,
                usage=0,
                stored=0,
            ),
            can_manage_org=self._safe_can_manage_org(),
            stored_available=False,
        )


@dataclass(frozen=True)
class HomeDashboardViewState:
    is_ar: bool
    greeting: str
    branches_title: str
    branches_subtitle: str
    actions_title: str
    actions_subtitle: str
    track_text: str
    usage_text: str
    stat_labels: dict[str, str]
    top_chips: tuple[str, ...]
    can_open_tracking: bool
    can_open_usage: bool


class HomeDashboardPresenter:
    @classmethod
    def build_from_payload(cls, payload: Mapping[str, Any]) -> HomeDashboardViewState:
        values = dict(payload.get("values") or {})
        snapshot = HomeDashboardSnapshot(
            ctx=payload.get("ctx"),
            profile=payload.get("profile"),
            is_ar=parse_bool(payload.get("is_ar"), False),
            username=str(payload.get("username") or "").strip(),
            role_txt=str(payload.get("role_txt") or "").strip(),
            allowed=tuple(
                (
                    str(branch).strip()
                    for branch in payload.get("allowed") or []
                    if str(branch).strip()
                )
            ),
            active_branch=str(payload.get("active_branch") or "").strip(),
            values=HomeDashboardStats(
                branches=normalize_int(values.get("branches"), 0),
                tracked=normalize_int(values.get("tracked"), 0),
                expiring=normalize_int(values.get("expiring"), 0),
                expired=normalize_int(values.get("expired"), 0),
                usage=normalize_int(values.get("usage"), 0),
                stored=normalize_int(values.get("stored"), 0),
            ),
            can_manage_org=parse_bool(payload.get("can_manage_org"), False),
        )
        return cls.build(snapshot)

    @staticmethod
    def build(snapshot: HomeDashboardSnapshot) -> HomeDashboardViewState:
        ctx = snapshot.ctx
        is_ar = bool(snapshot.is_ar)
        username = str(snapshot.username or "").strip()
        role_txt = str(snapshot.role_txt or "").strip()
        active_branch = str(snapshot.active_branch or "").strip()
        top_chips = tuple(
            (
                text
                for text in (
                    _("Role: {role}").format(role=role_txt) if role_txt else "",
                    (
                        _("Operating area: {area}").format(area=ctx.area_id)
                        if str(ctx.area_id or "").strip()
                        else ""
                    ),
                    (
                        _("Active restaurant branch: {branch}").format(branch=active_branch)
                        if active_branch
                        else ""
                    ),
                )
                if text
            )
        )
        stat_labels = {
            "branches": _("Authorized branches"),
            "tracked": _("Tracked items"),
            "expiring": _("Expiring soon"),
            "expired": _("Expired products"),
            "usage": _("Usage products"),
            "stored": _("Stored products"),
        }
        return HomeDashboardViewState(
            is_ar=is_ar,
            greeting=(
                _("Welcome, {username}").format(username=username) if username else _("Welcome")
            ),
            branches_title=_("Authorized branches"),
            branches_subtitle=_("Your assigned operating scope"),
            actions_title=_("Quick actions"),
            actions_subtitle=_("Open an authorized workspace"),
            track_text=_("Open tracking"),
            usage_text=_("Open usage"),
            stat_labels=stat_labels,
            top_chips=top_chips,
            can_open_tracking=bool(snapshot.allowed),
            can_open_usage=bool(snapshot.allowed),
        )


@dataclass(frozen=True, slots=True)
class ExpiryStatus:
    key: str
    label: str
    detail: str
    display_text: str
    severity: str
    severity_rank: int
    progress: int
    days_left: int | None
    should_notify: bool


_SEVERITY_BY_KIND = {
    ExpiryStatusKind.UNKNOWN: "neutral",
    ExpiryStatusKind.VALID: "valid",
    ExpiryStatusKind.EXPIRING_SOON: "warning",
    ExpiryStatusKind.EXPIRING_APPROACHING: "approaching",
    ExpiryStatusKind.EXPIRING_NEAR: "near",
    ExpiryStatusKind.EXPIRES_TOMORROW: "tomorrow",
    ExpiryStatusKind.EXPIRES_TODAY: "today",
    ExpiryStatusKind.EXPIRED: "expired",
}

_KEY_BY_KIND = {
    ExpiryStatusKind.UNKNOWN: "missing_expiry",
    ExpiryStatusKind.VALID: "valid",
    ExpiryStatusKind.EXPIRING_SOON: "expiring_soon",
    ExpiryStatusKind.EXPIRING_APPROACHING: "expiring_approaching",
    ExpiryStatusKind.EXPIRING_NEAR: "expiring_near",
    ExpiryStatusKind.EXPIRES_TOMORROW: "expires_tomorrow",
    ExpiryStatusKind.EXPIRES_TODAY: "expires_today",
    ExpiryStatusKind.EXPIRED: "expired",
}


def expiry_result_text(result: ExpiryStatusResult) -> tuple[str, str, str]:
    label = tr(result.label_key)
    if result.kind == ExpiryStatusKind.UNKNOWN:
        detail = tr("expiry.detail.unknown")
    elif result.kind == ExpiryStatusKind.EXPIRED:
        detail = format_days_text(result.days_expired, expired=True)
    elif result.kind == ExpiryStatusKind.EXPIRES_TODAY:
        detail = tr("expiry.detail.expires_today")
    elif result.kind == ExpiryStatusKind.EXPIRES_TOMORROW:
        detail = tr("expiry.detail.expires_tomorrow")
    else:
        detail = format_days_text(result.days_remaining, expired=False)

    if result.kind == ExpiryStatusKind.UNKNOWN:
        display = label
    elif result.kind == ExpiryStatusKind.VALID:
        display = f"{label} — {detail}" if detail else label
    elif result.kind == ExpiryStatusKind.EXPIRED:
        display = f"{label} — {detail}" if detail else label
    elif result.kind in {ExpiryStatusKind.EXPIRES_TODAY, ExpiryStatusKind.EXPIRES_TOMORROW}:
        display = label
    elif detail and detail != label:
        display = f"{label} — {detail}"
    else:
        display = label
    return label, detail, display


def expiry_display_text(result: ExpiryStatusResult) -> str:
    return expiry_result_text(result)[2]


def status_from_result(result: ExpiryStatusResult) -> ExpiryStatus:
    label, detail, display = expiry_result_text(result)
    return ExpiryStatus(
        key=_KEY_BY_KIND.get(result.kind, "missing_expiry"),
        label=label,
        detail=detail,
        display_text=display,
        severity=_SEVERITY_BY_KIND.get(result.kind, "neutral"),
        severity_rank=result.severity_rank,
        progress=expiry_progress_percent(result),
        days_left=result.days_remaining,
        should_notify=result.should_notify_default,
    )


def classify_tracking_row(row: Mapping[str, Any] | None) -> ExpiryStatus:
    return status_from_result(classify_expiry_date(row_expiry_value(row)))


@dataclass(frozen=True)
class TrackingBranchFilterState:
    branches: list[str]
    can_view_all: bool
    allow_scope_aggregate: bool
    show_row: bool
    items: list[tuple[str, str]]
    selected_data: str
    disable_selector: bool


def build_branch_filter_state(
    *, branches: Iterable[str] | None, can_view_all: bool, saved_view: str = ""
) -> TrackingBranchFilterState:
    normalized_branches = [
        str(branch or "").strip() for branch in branches or [] if str(branch or "").strip()
    ]
    allow_scope_aggregate = len(normalized_branches) > 1
    show_row = bool(normalized_branches) and allow_scope_aggregate
    candidate = str(saved_view or "").strip() or (
        "all" if allow_scope_aggregate else normalized_branches[0] if normalized_branches else ""
    )
    items: list[tuple[str, str]] = []
    if allow_scope_aggregate:
        label = _("All restaurant branches") if can_view_all else _("My restaurant branches")
        items.append((label, "all"))
    for branch in normalized_branches:
        items.append((branch, branch))
    allowed_values = {data for _, data in items}
    selected_data = candidate if candidate in allowed_values else items[0][1] if items else ""
    return TrackingBranchFilterState(
        branches=normalized_branches,
        can_view_all=bool(can_view_all),
        allow_scope_aggregate=allow_scope_aggregate,
        show_row=show_row,
        items=items,
        selected_data=selected_data,
        disable_selector=len(normalized_branches) == 1,
    )


def resolve_view_branch_selection(
    value: str, *, can_view_all: bool, allow_scope_aggregate: bool
) -> str:
    raw_value = str(value or "").strip()
    normalized = raw_value.lower()
    is_all = normalized == "all" and (bool(can_view_all) or bool(allow_scope_aggregate))
    return "all" if is_all else raw_value


@dataclass(frozen=True)
class PageVisibleState:
    status_text: str
    status_role: str


def _total(value: int) -> int:
    return max(0, int(value or 0))


class PageVisibleStateService:
    @staticmethod
    def tracking_state(
        *,
        total: int,
        loading: bool = False,
        truncated: bool = False,
        error_message: str = "",
    ) -> PageVisibleState:
        _total(total)
        if loading:
            return PageVisibleState(_("Loading..."), "muted")
        message = _text(error_message)
        if message:
            return PageVisibleState(message, "error")
        if truncated:
            return PageVisibleState(
                _("Showing first items only. Refine filters for a smaller result set."), "warning"
            )
        return PageVisibleState("", "muted")

    @staticmethod
    def usage_state(
        *,
        total: int,
        loading: bool = False,
        status_text: str = "",
        error_message: str = "",
        access_allowed: bool = True,
        access_reason: str = "",
    ) -> PageVisibleState:
        total = _total(total)
        if loading:
            return PageVisibleState(_text(status_text) or _("Calculating..."), "muted")
        if not access_allowed:
            return PageVisibleState(
                _text(access_reason) or _("Usage is not available for the current account."),
                "warning",
            )
        message = _text(error_message)
        if message:
            return PageVisibleState(message, "error")
        status = _text(status_text)
        return PageVisibleState(status, "warning" if not total and status else "muted")


@dataclass(frozen=True, slots=True)
class SettingsState:
    """Presentation-facing immutable settings snapshot.

    The Qt layer consumes this DTO without importing the preferences use-case
    implementation that loads or persists it.
    """

    language: str
    monitoring_enabled: bool
    enable_tray_background: bool
    enable_desktop_notifications: bool
    enable_sounds: bool
    expiry_enable_status_colors: bool
    expiry_enable_status_icons: bool
    notification_sound_default: str
    notification_sound_soon: str
    notification_sound_approaching: str
    notification_sound_near: str
    notification_sound_tomorrow: str
    notification_sound_today: str
    server_url: str
    ui_scale_percent: int = 100
    usage_hide_total_zero: bool = False
    start_with_windows: bool = True
    tray_show_message_on_minimize: bool = False
    check_updates_on_startup: bool = True
    expiry_runtime_snapshot: dict[str, str] | None = None


__all__ = ["SettingsState"]


@dataclass(frozen=True)
class RuntimeVisibleStateMessage:
    text: str
    timeout_ms: int = 0


class RuntimeVisibleStateService:
    @staticmethod
    def update_check_started(*, interactive: bool) -> RuntimeVisibleStateMessage:
        if not interactive:
            return RuntimeVisibleStateMessage("")
        return RuntimeVisibleStateMessage(_("Checking for updates..."), 0)

    @staticmethod
    def update_checks_disabled() -> RuntimeVisibleStateMessage:
        return RuntimeVisibleStateMessage(
            _("Automatic update checks are disabled in Settings."), 4000
        )


@dataclass(frozen=True)
class CloudConnectionViewState:
    online: bool
    status_text: str
    indicator_property: str
    tray_tooltip: str
    status_title: str
    status_message: str
    status_level: str
    should_refresh_on_connect: bool


class CloudConnectionPresenter:
    @staticmethod
    def build(
        *, online: bool, previous: bool, app_name: str = APP_DISPLAY_NAME
    ) -> CloudConnectionViewState:
        is_online = bool(online)
        was_online = bool(previous)
        status_text = "● " + (_("Online") if is_online else _("Offline"))
        if is_online:
            status_message = _("Connection restored.")
            status_level = "ok"
        else:
            status_message = _("Offline Mode — changes will sync when connection returns.")
            status_level = "warning"
        return CloudConnectionViewState(
            online=is_online,
            status_text=status_text,
            indicator_property="online" if is_online else "offline",
            tray_tooltip=f"{app_name} - {status_text}",
            status_title=_("Connection"),
            status_message=status_message,
            status_level=status_level,
            should_refresh_on_connect=is_online and (not was_online),
        )


def normalize_shell_scope(
    permission_context: PermissionContext | None, allowed_branches: Iterable[str] | None
) -> tuple[PermissionContext, list[str]]:
    context = (
        permission_context
        if isinstance(permission_context, PermissionContext)
        else PermissionContext()
    )
    branches = [str(branch).strip() for branch in allowed_branches or [] if str(branch).strip()]
    return (context, branches)


@dataclass(frozen=True)
class ShellAccessState:
    has_session: bool
    has_branch_scope: bool
    can_open_home: bool
    can_open_tracking: bool
    can_open_usage: bool
    can_open_kpi: bool
    can_open_about: bool
    can_open_settings: bool
    can_open_administration: bool
    can_manage_stored_products: bool
    can_manage_usage_products: bool
    can_change_own_password: bool
    can_open_notifications: bool
    can_logout: bool
    can_exit: bool


class ShellAccessService:
    @staticmethod
    def build(
        *,
        permission_context: PermissionContext | None = None,
        has_session: bool = False,
        allowed_branches: Iterable[str] | None = None,
        server_connected: bool = False,
    ) -> ShellAccessState:
        ctx, allowed = normalize_shell_scope(permission_context, allowed_branches)
        has_branch_scope = bool(PermissionService.can_view_all(permission_context=ctx) or allowed)
        password_change_required = bool(has_session and ctx.must_change_password)
        can_open_administration = bool(
            has_session
            and not password_change_required
            and PermissionService.can_manage_org(permission_context=ctx)
        )
        return ShellAccessState(
            has_session=bool(has_session),
            has_branch_scope=has_branch_scope,
            can_open_home=not password_change_required,
            can_open_tracking=bool(
                has_session
                and has_branch_scope
                and not password_change_required
                and ctx.has_permission("tracking.view")
            ),
            can_open_usage=bool(
                has_session
                and has_branch_scope
                and not password_change_required
                and ctx.has_permission("usage.view")
            ),
            can_open_kpi=bool(
                has_session
                and has_branch_scope
                and not password_change_required
                and ctx.has_permission("kpi.view")
            ),
            can_open_about=not password_change_required,
            can_open_settings=bool(has_session and not password_change_required),
            can_open_administration=can_open_administration,
            can_manage_stored_products=bool(
                has_session
                and not password_change_required
                and PermissionService.can_manage_catalog(permission_context=ctx)
            ),
            can_manage_usage_products=bool(
                has_session
                and not password_change_required
                and PermissionService.can_manage_usage(permission_context=ctx)
            ),
            can_change_own_password=bool(
                has_session and PermissionService.can_change_own_password(permission_context=ctx)
            ),
            can_open_notifications=bool(has_session and not password_change_required),
            can_logout=bool(has_session),
            can_exit=True,
        )


@dataclass(frozen=True)
class ShellUserScopeState:
    resolved_view_branch: str
    branch_text: str
    top_info: str
    greeting: str


class ShellUserScopePresenter:
    @staticmethod
    def build(
        *,
        permission_context: PermissionContext | None = None,
        username: str = "",
        allowed_branches: Iterable[str] | None = None,
        language: str = "en",
        view_branch: str | None = None,
    ) -> ShellUserScopeState:
        ctx, allowed = normalize_shell_scope(permission_context, allowed_branches)
        lang = normalize_language_code(language)
        is_ar = is_rtl(lang)
        user_name = str(username or ctx.username or "").strip()
        resolved_view_branch = str(
            view_branch if view_branch is not None else ctx.active_branch or ""
        ).strip()
        if not resolved_view_branch or resolved_view_branch.lower() == "all":
            resolved_view_branch = "all"
        if resolved_view_branch == "all":
            if PermissionService.can_view_all(permission_context=ctx):
                branch_text = _("All restaurant branches")
            elif len(allowed) > 1:
                branch_text = _("All my restaurant branches")
            else:
                branch_text = allowed[0] if allowed else _("All restaurant branches")
        else:
            branch_text = resolved_view_branch
        role_txt = PermissionService.role_label(
            permission_context=ctx, language="ar" if is_ar else "en"
        )
        is_single_branch_scope = PermissionService.is_single_branch_scope(permission_context=ctx)
        if is_single_branch_scope and branch_text:
            greeting = _("Welcome, branch {branch}").format(branch=branch_text)
        elif user_name and branch_text:
            greeting = _("Welcome {username} — branch: {branch}").format(
                username=user_name, branch=branch_text
            )
        else:
            greeting = ""
        parts = [part for part in (role_txt, user_name) if part]
        identity = " ".join(parts).strip()
        compact_identity = role_txt or user_name
        if branch_text:
            top_info = f"{compact_identity} · {branch_text}".strip(" ·")
        else:
            top_info = identity
        return ShellUserScopeState(
            resolved_view_branch=resolved_view_branch,
            branch_text=branch_text,
            top_info=top_info,
            greeting=greeting,
        )


def project_tracking_row(row: Mapping[str, Any] | None) -> dict[str, Any]:
    projected = dict(row or {})
    status = classify_tracking_row(projected)
    projected["expiry_status_text"] = status.display_text
    projected["expiry_status_progress"] = int(status.progress)
    projected["expiry_status_days_left"] = status.days_left
    projected["expiry_status_key"] = status.key
    return projected


def project_tracking_rows(rows: Iterable[Mapping[str, Any]] | None) -> list[dict[str, Any]]:
    return [project_tracking_row(row) for row in list(rows or [])]


__all__ = ["project_tracking_row", "project_tracking_rows"]


class UsageRowPresenter:
    """Pure row transformation rules for the Usage workspace.

    Qt models consume already-normalized row dictionaries and delegate editable
    quantity validation here. This keeps parsing/calculation rules out of
    QAbstractTableModel while preserving the existing table contract.
    """

    @staticmethod
    def _number(value: Any) -> float:
        return parse_plain_number(value)

    @staticmethod
    def _entry_key(row: dict[str, Any]) -> tuple[str, str, str]:
        return (
            str(row.get("material", "") or "").strip().lower(),
            str(row.get("name", "") or "").strip().lower(),
            str(row.get("uom", "") or "").strip().lower(),
        )

    @staticmethod
    def _parse_manual_quantity(value: Any) -> float:
        text = normalize_ascii_digits(value).strip()
        translation = str.maketrans("٫٬", ".,")
        text = text.translate(translation).replace(" ", "")
        if not text:
            return 0.0
        if "," in text and "." not in text:
            text = text.replace(",", ".") if text.count(",") == 1 else text.replace(",", "")
        elif "," in text and "." in text:
            text = text.replace(",", "")
        number = float(text)
        if not math.isfinite(number):
            raise ValueError("quantity must be finite")
        return number

    def normalize_row(self, row: dict | None) -> dict[str, Any]:
        source = dict(row or {})
        total = self._number(source.get("total"))
        user_set = parse_bool(source.get("user_set"), False)
        raw_onhand = source.get("onhand")
        if raw_onhand in (None, "") and not user_set:
            onhand = None
            usage = 0.0
        else:
            onhand = self._number(raw_onhand)
            usage = self._number(source.get("usage", total - onhand)) if user_set else None
        source.update(
            {
                "receipts": self._number(source.get("receipts")),
                "begin": self._number(source.get("begin")),
                "total": total,
                "onhand": onhand,
                "usage": usage,
                "user_set": user_set,
                "material": str(source.get("material", "") or ""),
                "name": str(source.get("name", "") or ""),
                "uom": str(source.get("uom", "") or ""),
            }
        )
        return source

    def apply_onhand_edit(
        self, row: dict[str, Any] | None, value: Any
    ) -> tuple[dict[str, Any], bool]:
        current = self.normalize_row(row)
        text = str(value or "").strip()
        if text == "":
            updated = dict(current)
            updated.update({"onhand": None, "usage": 0.0, "user_set": False})
            return updated, True
        try:
            onhand = self._parse_manual_quantity(text)
        except (TypeError, ValueError, OverflowError):
            return dict(current), False
        if onhand < 0.0:
            return dict(current), False
        total = self._number(current.get("total"))
        if onhand > total + 1e-09:
            return dict(current), False
        updated = dict(current)
        updated.update(
            {
                "onhand": onhand,
                "usage": total - onhand,
                "user_set": True,
            }
        )
        return updated, True

    def replace_rows_preserving_user_inputs(
        self,
        previous_rows: list[dict] | None,
        rows: list[dict] | None,
    ) -> list[dict[str, Any]]:
        previous_entries: dict[tuple[str, str, str], Any] = {}
        for previous in previous_rows or []:
            normalized = self.normalize_row(previous)
            if not parse_bool(normalized.get("user_set"), False):
                continue
            key = self._entry_key(normalized)
            if key[0] or key[1]:
                previous_entries[key] = normalized.get("onhand")

        result: list[dict[str, Any]] = []
        for source in rows or []:
            normalized = self.normalize_row(source)
            key = self._entry_key(normalized)
            if key in previous_entries:
                preserved, ok = self.apply_onhand_edit(normalized, previous_entries[key])
                if ok:
                    normalized = preserved
            result.append(normalized)
        return result
