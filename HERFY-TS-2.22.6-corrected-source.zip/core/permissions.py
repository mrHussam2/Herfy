from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from contracts.binding import CANONICAL_PERMISSION_CODES, CANONICAL_ROLE_KEYS
from core.models import clean_string_list, parse_bool

ALL_PERMISSION = "*"
MANAGED_ROLE_KEYS: tuple[str, ...] = CANONICAL_ROLE_KEYS
BASE_ROLE_LABELS: dict[str, str] = {
    "system": "System",
    "operations_director": "Operations Director",
    "operations_manager": "Operations Manager",
    "operations_consultant": "Operations Consultant",
    "store_manager": "Store Manager",
    "store": "Store Account",
}
_ADMIN_PERMISSION_PREFIXES = (
    "regions.",
    "areas.",
    "branches.",
    "users.",
    "organizations.",
    "roles.",
    "permissions.",
    "audit.",
)
ADMINISTRATION_PERMISSIONS: tuple[str, ...] = tuple(
    code for code in CANONICAL_PERMISSION_CODES if code.startswith(_ADMIN_PERMISSION_PREFIXES)
)
PERMISSION_SOURCE = "postgresql.role_permissions"
SCOPE_SOURCE = "postgresql.user_scope_assignments"


def role_labels(language: str = "en") -> dict[str, str]:
    if str(language or "").lower().startswith("ar"):
        return {
            "system": "النظام",
            "operations_director": "مدير العمليات العام",
            "operations_manager": "مدير العمليات",
            "operations_consultant": "مستشار العمليات",
            "store_manager": "مدير المتجر",
            "store": "حساب الفرع",
        }
    return dict(BASE_ROLE_LABELS)


@dataclass(frozen=True)
class PermissionScope:
    organizations: tuple[str, ...] = ()
    regions: tuple[str, ...] = ()
    areas: tuple[str, ...] = ()
    branches: tuple[str, ...] = ()
    all_organizations: bool = False
    all_regions: bool = False
    all_areas: bool = False
    all_branches: bool = False


def normalize_role(role: str | None) -> str:
    """Return the canonical server role key without client-side aliases."""
    return str(role or "").strip()


def match_scope(values: Iterable[str], value: str) -> bool:
    lookup = str(value or "").strip().lower()
    return bool(lookup) and any(str(item).strip().lower() == lookup for item in values)


def permission_scope_from_payload(scope_payload: dict[str, Any]) -> PermissionScope:
    return PermissionScope(
        organizations=tuple(clean_string_list(scope_payload.get("organizations"))),
        regions=tuple(clean_string_list(scope_payload.get("regions"))),
        areas=tuple(clean_string_list(scope_payload.get("areas"))),
        branches=tuple(clean_string_list(scope_payload.get("branches"))),
        all_organizations=parse_bool(scope_payload.get("all_organizations"), False),
        all_regions=parse_bool(scope_payload.get("all_regions"), False),
        all_areas=parse_bool(scope_payload.get("all_areas"), False),
        all_branches=parse_bool(scope_payload.get("all_branches"), False),
    )


def permissions_from_payload(permissions: list[Any] | tuple[Any, ...] | None) -> tuple[str, ...]:
    """Accept only the canonical list-like permission payload returned by the server."""
    if not isinstance(permissions, (list, tuple)):
        return ()
    return tuple(clean_string_list(permissions))


def identity_matches(ctx, user_payload: dict[str, Any]) -> bool:
    """Canonical identity uses immutable user_id; username remains a login field."""
    if not isinstance(user_payload, dict):
        return False
    own_id = str(getattr(ctx, "user_id", "") or "").strip()
    target_id = str(user_payload.get("user_id") or "").strip()
    return bool(own_id and target_id and own_id == target_id)


def can_view_user_record(ctx, user_payload: dict[str, Any] | None) -> bool:
    """Trust server-side dashboard scope filtering; client only gates the users.view capability."""
    if not getattr(ctx, "is_active", False):
        return False
    data = user_payload if isinstance(user_payload, dict) else {}
    if identity_matches(ctx, data):
        return True
    return bool(ctx.has_any_permission("users.view", ALL_PERMISSION))


@dataclass
class PermissionContext:
    user_id: str = ""
    username: str = ""
    display_name: str = ""
    role: str = ""
    account_type: str = "employee"
    permissions: tuple[str, ...] = ()
    scope: PermissionScope = field(default_factory=PermissionScope)
    direct_scope: tuple[tuple[str, str], ...] = ()
    must_change_password: bool = False
    is_active: bool = True
    active_branch: str = ""
    authority_source: str = ""
    scope_source: str = ""
    authority_revision: int = 0

    @property
    def branches(self) -> tuple[str, ...]:
        return tuple(self.scope.branches or ())

    @property
    def areas(self) -> tuple[str, ...]:
        return tuple(self.scope.areas or ())

    @property
    def regions(self) -> tuple[str, ...]:
        return tuple(self.scope.regions or ())

    @property
    def region_id(self) -> str:
        return str(self.scope.regions[0]).strip() if len(self.scope.regions) == 1 else ""

    @property
    def area_id(self) -> str:
        return str(self.scope.areas[0]).strip() if len(self.scope.areas) == 1 else ""

    def has_permission(self, permission: str) -> bool:
        perm = str(permission or "").strip()
        if not self.is_active:
            return False
        if ALL_PERMISSION in self.permissions:
            return True
        return perm in self.permissions

    def can_view_all_branches(self) -> bool:
        return bool(self.is_active and self.scope.all_branches)

    def _can_access_scope(
        self, value: str | None, *, all_scope: bool, scope_values: Iterable[str]
    ) -> bool:
        if not self.is_active:
            return False
        normalized = str(value or "").strip()
        if not normalized:
            return False
        return all_scope or match_scope(scope_values, normalized)

    def _can_use_branch_permission(self, branch: str | None, permission: str) -> bool:
        return self.can_access_branch(branch) and self.has_permission(permission)

    def can_access_region(self, region_id: str | None) -> bool:
        return self._can_access_scope(
            region_id, all_scope=self.scope.all_regions, scope_values=self.scope.regions
        )

    def can_access_branch(self, branch: str | None) -> bool:
        return self._can_access_scope(
            branch, all_scope=self.scope.all_branches, scope_values=self.scope.branches
        )

    def can_view_branch(self, branch: str | None) -> bool:
        return self.can_access_branch(branch) and self.has_any_permission(
            "tracking.view", "branches.view", ALL_PERMISSION
        )

    def can_create_tracking(self, branch: str | None) -> bool:
        return self._can_use_branch_permission(branch, "tracking.create")

    def can_update_tracking(self, branch: str | None) -> bool:
        return self._can_use_branch_permission(branch, "tracking.update")

    def can_delete_tracking(self, branch: str | None) -> bool:
        return self._can_use_branch_permission(branch, "tracking.delete")

    def can_access_area(self, area_id: str | None) -> bool:
        return self._can_access_scope(
            area_id, all_scope=self.scope.all_areas, scope_values=self.scope.areas
        )

    def can_manage_area(self, area_id: str | None) -> bool:
        return self.can_access_area(area_id) and self.can_manage_org()

    def can_manage_branch(self, branch_id: str | None, *, area_id: str = "") -> bool:
        branch = str(branch_id or "").strip()
        area = str(area_id or "").strip()
        if not self.can_manage_org():
            return False
        if branch and self.can_access_branch(branch):
            return True
        return bool(area and self.can_access_area(area))

    def can_view_user_record(self, user_payload: dict[str, Any] | None) -> bool:
        return can_view_user_record(self, user_payload)

    def has_any_permission(self, *permissions: str) -> bool:
        return any(self.has_permission(permission) for permission in permissions)

    def can_manage_catalog(self) -> bool:
        return self.has_any_permission("catalog.manage", ALL_PERMISSION)

    def can_manage_usage(self) -> bool:
        return self.has_any_permission("usage.manage", ALL_PERMISSION)

    def can_manage_org(self) -> bool:
        return bool(
            self.is_active and self.has_any_permission(*ADMINISTRATION_PERMISSIONS, ALL_PERMISSION)
        )

    def can_change_own_password(self) -> bool:
        # /auth/change-password is an authenticated self-service endpoint with
        # no role-specific scope rule.  This must remain available while the
        # server marks a session as must_change_password, including system users.
        return bool(self.is_active)

    def is_single_branch_scope(self) -> bool:
        return len(self.scope.branches) == 1 and not self.scope.all_branches

    def default_branch(self) -> str:
        active = str(self.active_branch or "").strip()
        if active and active.lower() != "all" and self.can_access_branch(active):
            return active
        if len(self.scope.branches) == 1:
            return str(self.scope.branches[0]).strip()
        return ""

    def role_label(self, language: str = "en") -> str:
        return role_labels(language).get(self.role, self.role.replace("_", " ").strip().title())

    def can_create_user_role(self, target_role: str) -> bool:
        return bool(
            str(target_role or "").strip()
            and self.has_any_permission("users.update", "users.create", ALL_PERMISSION)
            and self.has_any_permission("roles.assign", ALL_PERMISSION)
        )

    def to_payload(self) -> dict[str, Any]:
        return {
            "user_id": self.user_id,
            "username": self.username,
            "display_name": self.display_name,
            "role": self.role,
            "account_type": self.account_type,
            "permissions": list(self.permissions or []),
            "direct_scope": [
                {"scope_type": kind, "scope_id": ident} for kind, ident in self.direct_scope
            ],
            "scope": {
                "organizations": list(self.scope.organizations or []),
                "regions": list(self.scope.regions or []),
                "areas": list(self.scope.areas or []),
                "branches": list(self.scope.branches or []),
                "all_organizations": bool(self.scope.all_organizations),
                "all_regions": bool(self.scope.all_regions),
                "all_areas": bool(self.scope.all_areas),
                "all_branches": bool(self.scope.all_branches),
            },
            "active_branch": self.active_branch,
            "is_active": bool(self.is_active),
            "must_change_password": bool(self.must_change_password),
            "permission_source": self.authority_source,
            "scope_source": self.scope_source,
            "authority_revision": int(self.authority_revision or 0),
        }

    @staticmethod
    def from_payload(
        payload: dict[str, Any] | None, *, active_branch: str | None = None
    ) -> "PermissionContext":
        data = payload if isinstance(payload, dict) else {}
        raw_scope = data.get("scope")
        raw_permissions = data.get("permissions")
        user_id = str(data.get("user_id") or "").strip()
        username = str(data.get("username") or "").strip()
        authority_source = str(data.get("permission_source") or "").strip()
        scope_source = str(data.get("scope_source") or "").strip()
        role_norm = normalize_role(data.get("role"))
        account_type = str(data.get("account_type") or "").strip().lower()
        authority_valid = (
            bool(user_id and username)
            and role_norm in CANONICAL_ROLE_KEYS
            and account_type in {"employee", "branch"}
            and authority_source == PERMISSION_SOURCE
            and scope_source == SCOPE_SOURCE
            and isinstance(raw_scope, dict)
            and isinstance(raw_permissions, list)
        )
        if not authority_valid:
            return PermissionContext()
        scope = permission_scope_from_payload(raw_scope)
        permissions = permissions_from_payload(raw_permissions)
        raw_direct = data.get("direct_scope")
        if not isinstance(raw_direct, list):
            return PermissionContext()
        direct_scope: list[tuple[str, str]] = []
        for item in raw_direct:
            if not isinstance(item, dict):
                return PermissionContext()
            kind = str(item.get("scope_type") or "").strip()
            ident = str(item.get("scope_id") or "").strip()
            if kind not in {"organization", "region", "area", "branch"} or not ident:
                return PermissionContext()
            direct_scope.append((kind, ident))
        active_value = str(data.get("active_branch") or active_branch or "").strip()
        if active_value.lower() == "all":
            active_value = ""
        try:
            authority_revision = int(data.get("authority_revision"))
        except (TypeError, ValueError):
            return PermissionContext()
        return PermissionContext(
            user_id=user_id,
            username=username,
            display_name=str(data.get("display_name") or "").strip(),
            role=role_norm,
            account_type=account_type,
            permissions=permissions,
            scope=scope,
            direct_scope=tuple(direct_scope),
            must_change_password=parse_bool(data.get("must_change_password"), False),
            is_active=parse_bool(data.get("is_active"), False),
            active_branch=active_value,
            authority_source=authority_source,
            scope_source=scope_source,
            authority_revision=authority_revision,
        )


class PermissionService:
    @staticmethod
    def context(permission_context: PermissionContext | None = None) -> PermissionContext:
        return (
            permission_context
            if isinstance(permission_context, PermissionContext)
            else PermissionContext()
        )

    @staticmethod
    def has_permission(
        permission: str,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).has_permission(permission)

    @staticmethod
    def can_view_all(
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_view_all_branches()

    @staticmethod
    def can_access_branch(
        branch: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_access_branch(branch)

    @staticmethod
    def can_view_branch(
        branch: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_view_branch(branch)

    @staticmethod
    def can_create_tracking(
        branch: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_create_tracking(branch)

    @staticmethod
    def can_update_tracking(
        branch: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_update_tracking(branch)

    @staticmethod
    def can_delete_tracking(
        branch: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_delete_tracking(branch)

    @staticmethod
    def can_manage_catalog(
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_manage_catalog()

    @staticmethod
    def can_manage_usage(
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_manage_usage()

    @staticmethod
    def can_manage_org(
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_manage_org()

    @staticmethod
    def can_change_own_password(
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_change_own_password()

    @staticmethod
    def is_single_branch_scope(
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).is_single_branch_scope()

    @staticmethod
    def default_branch(
        *,
        permission_context: PermissionContext | None = None,
    ) -> str:
        return PermissionService.context(permission_context).default_branch()

    @staticmethod
    def role_label(
        *,
        permission_context: PermissionContext | None = None,
        language: str = "en",
    ) -> str:
        return PermissionService.context(permission_context).role_label(language)

    @staticmethod
    def can_create_user_role(
        target_role: str,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_create_user_role(target_role)

    @staticmethod
    def can_access_area(
        area_id: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_access_area(area_id)

    @staticmethod
    def can_manage_area(
        area_id: str | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_manage_area(area_id)

    @staticmethod
    def can_manage_branch(
        branch_id: str | None,
        *,
        area_id: str = "",
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_manage_branch(
            branch_id, area_id=area_id
        )

    @staticmethod
    def can_view_user_record(
        user_payload: dict | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> bool:
        return PermissionService.context(permission_context).can_view_user_record(user_payload)

    @staticmethod
    def filter_visible_users(
        users: Iterable[dict] | None,
        *,
        permission_context: PermissionContext | None = None,
    ) -> list[dict]:
        ctx = PermissionService.context(permission_context)
        return [
            dict(item)
            for item in users or []
            if ctx.can_view_user_record(item if isinstance(item, dict) else {})
        ]


# --- package exports ---
__all__ = [
    "ALL_PERMISSION",
    "BASE_ROLE_LABELS",
    "MANAGED_ROLE_KEYS",
    "PermissionScope",
    "PermissionContext",
    "PermissionService",
    "can_view_user_record",
    "identity_matches",
    "match_scope",
    "normalize_role",
    "permissions_from_payload",
    "permission_scope_from_payload",
    "role_labels",
]


AUTHORITY_KEYS = frozenset(
    {
        "user_id",
        "username",
        "display_name",
        "role",
        "account_type",
        "permissions",
        "capabilities",
        "direct_scope",
        "scope",
        "active_branch",
        "is_active",
        "must_change_password",
        "permission_source",
        "scope_source",
        "authority_revision",
    }
)
SCOPE_KEYS = frozenset(
    {
        "organizations",
        "regions",
        "areas",
        "branches",
        "all_organizations",
        "all_regions",
        "all_areas",
        "all_branches",
    }
)
SCOPE_TYPES = frozenset({"organization", "region", "area", "branch"})
PERMISSION_SOURCE = "postgresql.role_permissions"
SCOPE_SOURCE = "postgresql.user_scope_assignments"


def validate_server_authority(payload: Any) -> dict[str, Any]:
    """Validate the exact server authority snapshot.

    This is a client-side integrity check for UI/state. It never grants server
    access: every protected API operation is re-authorized by the server.
    """
    if not isinstance(payload, dict):
        raise ValueError("authority must be an object")
    data = dict(payload)
    if set(data) != AUTHORITY_KEYS:
        missing = sorted(AUTHORITY_KEYS - set(data))
        unknown = sorted(set(data) - AUTHORITY_KEYS)
        raise ValueError(f"authority keys mismatch missing={missing} unknown={unknown}")

    if str(data["permission_source"] or "") != PERMISSION_SOURCE:
        raise ValueError("authority permission source is not canonical")
    if str(data["scope_source"] or "") != SCOPE_SOURCE:
        raise ValueError("authority scope source is not canonical")
    if not str(data["user_id"] or "").strip() or not str(data["username"] or "").strip():
        raise ValueError("authority identity is missing")
    if not isinstance(data["display_name"], str) or not isinstance(data["active_branch"], str):
        raise ValueError("authority display/active branch is invalid")
    role = str(data["role"] or "").strip()
    if role not in CANONICAL_ROLE_KEYS:
        raise ValueError("authority role is unknown")
    if str(data["account_type"] or "").strip().lower() not in {"employee", "branch"}:
        raise ValueError("authority account type is invalid")
    if not isinstance(data["is_active"], bool) or not isinstance(
        data["must_change_password"], bool
    ):
        raise ValueError("authority status flags are invalid")

    permissions = data["permissions"]
    capabilities = data["capabilities"]
    if not isinstance(permissions, list) or not all(isinstance(v, str) for v in permissions):
        raise ValueError("authority permissions are invalid")
    if not isinstance(capabilities, list) or not all(isinstance(v, str) for v in capabilities):
        raise ValueError("authority capabilities are invalid")
    normalized_permissions = [str(v).strip() for v in permissions]
    if any(not v for v in normalized_permissions) or len(set(normalized_permissions)) != len(
        normalized_permissions
    ):
        raise ValueError("authority permissions contain empty/duplicate values")
    unknown_permissions = sorted(set(normalized_permissions) - set(CANONICAL_PERMISSION_CODES))
    if unknown_permissions:
        raise ValueError(f"authority permissions are not canonical: {unknown_permissions}")
    if set(capabilities) != set(normalized_permissions):
        raise ValueError("authority capabilities differ from permissions")

    direct_scope = data["direct_scope"]
    if not isinstance(direct_scope, list):
        raise ValueError("authority direct_scope must be an array")
    for item in direct_scope:
        if not isinstance(item, dict) or set(item) != {"scope_type", "scope_id"}:
            raise ValueError("authority direct_scope entry is invalid")
        if (
            str(item["scope_type"] or "") not in SCOPE_TYPES
            or not str(item["scope_id"] or "").strip()
        ):
            raise ValueError("authority direct_scope reference is invalid")

    scope = data["scope"]
    if not isinstance(scope, dict) or set(scope) != SCOPE_KEYS:
        raise ValueError("authority scope keys are invalid")
    for key in ("organizations", "regions", "areas", "branches"):
        values = scope[key]
        if not isinstance(values, list) or not all(
            isinstance(v, str) and v.strip() for v in values
        ):
            raise ValueError(f"authority scope {key} is invalid")
        if len(set(values)) != len(values):
            raise ValueError(f"authority scope {key} contains duplicates")
    for key in ("all_organizations", "all_regions", "all_areas", "all_branches"):
        if not isinstance(scope[key], bool):
            raise ValueError(f"authority scope flag {key} is invalid")

    try:
        revision = int(data["authority_revision"])
    except (TypeError, ValueError) as exc:
        raise ValueError("authority revision is invalid") from exc
    if revision < 0:
        raise ValueError("authority revision is negative")
    data["authority_revision"] = revision
    data["permissions"] = normalized_permissions
    data["capabilities"] = list(capabilities)
    return data
