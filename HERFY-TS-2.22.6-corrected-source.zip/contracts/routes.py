from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import quote

_CONTRACT_PATH = Path(__file__).with_name("api.json")


def _load_operation_paths() -> dict[str, str]:
    payload = json.loads(_CONTRACT_PATH.read_text(encoding="utf-8"))
    routes = payload.get("routes")
    if not isinstance(routes, list):
        raise RuntimeError("Canonical API contract routes are unavailable")
    result = {}
    for route in routes:
        op = str(route.get("operation_id") or "").strip()
        path = str(route.get("path") or "").strip()
        if not op or not path or op in result:
            raise RuntimeError("Canonical API route registry is invalid")
        result[op] = path
    if len(result) != int(payload.get("route_count") or 0):
        raise RuntimeError("Canonical API route registry is incomplete")
    return result


_OPERATION_PATHS = _load_operation_paths()


def _route(op: str) -> str:
    try:
        return _OPERATION_PATHS[op]
    except KeyError as exc:
        raise RuntimeError(f"Canonical API operation is missing: {op}") from exc


def _sub(op: str, **values: str) -> str:
    path = _route(op)
    for name, value in values.items():
        path = path.replace("{" + name + "}", quote(str(value), safe=""))
    if "{" in path:
        raise RuntimeError(f"Unresolved path parameter: {op}")
    return path


class Routes:
    AUTH_LOGIN = _route("auth_login")
    AUTH_REFRESH = _route("auth_refresh")
    AUTH_LOGOUT = _route("auth_logout")
    AUTH_AUTHORITY = _route("auth_authority")
    AUTH_CHANGE_PASSWORD = _route("auth_change_password")
    AUTH_PASSWORD_POLICY = _route("auth_password_policy")
    HEALTH = _route("health")
    READY = _route("ready")
    META_VERSION = _route("meta_version")
    META_CLIENT_BOOTSTRAP = _route("meta_client_bootstrap")
    META_BRANCHES = _route("meta_branches")
    CATALOG_STORED_PRODUCTS = _route("catalog_stored_list")
    CATALOG_USAGE_PRODUCTS = _route("catalog_usage_list")
    TRACKING_ITEMS = _route("tracking_items")
    SYNC_PULL = _route("sync_pull")
    SYNC_PUSH = _route("sync_push")
    EVENTS = _route("events")
    ADMIN_BOOTSTRAP = _route("admin_bootstrap")
    ADMIN_USERS = _route("admin_users_list")
    ADMIN_STRUCTURE = _route("admin_structure")
    ADMIN_PERMISSIONS = _route("admin_permissions_list")
    ADMIN_AUDIT = _route("admin_audit_list")
    ADMIN_REGIONS = _route("admin_regions_create")
    ADMIN_AREAS = _route("admin_areas_create")
    ADMIN_BRANCHES = _route("admin_branches_create")
    ADMIN_BRANCHES_BATCH = _route("admin_branches_batch")
    ADMIN_STORED_PRODUCTS = _route("admin_stored_list")
    ADMIN_USAGE_PRODUCTS = _route("admin_usage_list")

    @staticmethod
    def admin_user(user_id: str) -> str:
        return _sub("admin_users_update", user_id=user_id)

    @staticmethod
    def admin_user_scopes(user_id: str) -> str:
        return _sub("admin_users_replace_scopes", user_id=user_id)

    @staticmethod
    def admin_reset_password(user_id: str) -> str:
        return _sub("admin_users_reset_password", user_id=user_id)

    @staticmethod
    def admin_resource(resource: str, identifier: str) -> str:
        mapping = {
            "regions": ("admin_regions_delete", "region_id"),
            "areas": ("admin_areas_delete", "area_id"),
            "branches": ("admin_branches_delete", "branch_id"),
        }
        op, param = mapping[resource]
        return _sub(op, **{param: identifier})

    @staticmethod
    def admin_update_resource(resource: str, identifier: str) -> str:
        mapping = {
            "regions": ("admin_regions_update", "region_id"),
            "areas": ("admin_areas_update", "area_id"),
            "branches": ("admin_branches_update", "branch_id"),
        }
        op, param = mapping[resource]
        return _sub(op, **{param: identifier})

    @staticmethod
    def branch_transfer(branch_id: str) -> str:
        return _sub("admin_branches_transfer", branch_id=branch_id)

    @staticmethod
    def role_permissions(role_key: str) -> str:
        return _sub("admin_permissions_replace", role_key=role_key)

    @staticmethod
    def stored_product(material_number: str) -> str:
        return _sub("admin_stored_update", material_number=material_number)

    @staticmethod
    def usage_product(material_number: str) -> str:
        return _sub("admin_usage_update", material_number=material_number)
