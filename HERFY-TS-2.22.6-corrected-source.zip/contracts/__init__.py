"""Canonical HERFY client contract accessors."""
