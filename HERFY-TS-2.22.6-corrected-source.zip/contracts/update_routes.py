from __future__ import annotations

import json
from pathlib import Path
from urllib.parse import quote, urlsplit

_CONTRACT = Path(__file__).with_name("update.json")


def _data() -> dict:
    value = json.loads(_CONTRACT.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RuntimeError("update.json must be an object")
    return value


def _origin(payload: dict) -> str:
    value = str(payload.get("origin") or "").rstrip("/")
    parsed = urlsplit(value)
    if parsed.scheme != "https" or not parsed.netloc or parsed.path not in ("", "/"):
        raise RuntimeError("Canonical update origin must be an HTTPS origin without a path")
    return value


def _route(field: str) -> str:
    payload = _data()
    origin = _origin(payload)
    value = str(payload.get(field) or "").strip()
    if not value.startswith(origin + "/"):
        raise RuntimeError(f"Invalid canonical update URL: {field}")
    parsed = urlsplit(value)
    if parsed.query or parsed.fragment:
        raise RuntimeError(f"Invalid canonical update URL: {field}")
    return value[len(origin) :]


UPDATES_MANIFEST = _route("manifest_url")
UPDATES_PUBLIC_KEY = _route("public_key_url")


def package_path(package_name: str) -> str:
    name = quote(str(package_name or "").strip(), safe="")
    if not name:
        raise RuntimeError("Update package name is required")
    template = str(_data().get("artifact_route") or "").strip()
    if template != "/updates/packages/{package_name}":
        raise RuntimeError("Invalid canonical update package route")
    return template.replace("{package_name}", name)
