# HERFY-TS architecture ownership

This file is the implementation contract for the client. A behavior change is
separate from a cleanup change, and every responsibility has one owner.

| Responsibility | Canonical owner | Rule |
| --- | --- | --- |
| Page hierarchy, widget placement, static size policies, and stretch factors | `resources/ui/*.ui` | Python mounts Designer hosts; it does not recreate their layouts. |
| Palette, typography, borders, hover/focus states, and property-driven visual states | `resources/style.qss` | Pages never call `setStyleSheet()`. `ThemeManager` is the only stylesheet application owner. |
| Metrics | `ui/theme_metrics.py` | Design numbers are named once by `UI_METRICS`. |
| Breakpoints, DPI-aware sizing, and responsive reflow | `ui/theme_responsive.py` | Live viewport adaptation belongs here. |
| Window placement, shell composition, animation, and QSS loading | `ui/theme_geometry.py`, `ui/theme_shell.py`, `ui/theme_animation.py`, `ui/theme_manager.py` | Each concern has one implementation owner; `ui/theme.py` only preserves imports. |
| Page interaction, binding, and view state | the corresponding `ui/*.py` page/controller | It delegates domain work and does not own transport or persistence. |
| Domain workflows and validation | `services/` | UI calls services/controllers, not databases or HTTP clients. |
| HTTP, SQLite, files, and Windows integration | `infra/` | The server remains the authority for data, scope, and permissions. |
| Session scope, sync/realtime lifecycle, monitoring, and notification decisions | `services/` | These background owners do not depend on a page being open. |

`core/settings_contract.py` owns the stable local settings keys and defaults.
`services/preferences.py` owns their persisted and in-memory presentation cache;
core presentation code never imports a service to obtain configuration.

## Desktop shell

- `resources/ui/main_window.ui` owns the horizontal shell root and its static
  sidebar/MainArea hierarchy; MainArea vertically owns the top-bar and page
  hosts, with their size policies defined in Designer.
- `resources/ui/sidebar.ui` owns the sidebar hierarchy and navigation/profile
  hosts; `ui/theme_shell.py` builds its authorized dynamic navigation controls.
- Sidebar widths and breakpoints are shared metrics: 220 px desktop, 70 px
  compact, and a 44 px drawer trigger below 720 px. The small-screen popup
  temporarily hosts the same Sidebar widget and restores it to its Designer
  host when dismissed.
- Sidebar visual evidence is `PARTIALLY_OBSERVED` (textual status only); the
  formal visual, direction, and DPI verification gates remain
  `NOT_VERIFIED`.
- `resources/ui/top_bar.ui` owns the top-bar hierarchy and status hosts;
  `ui/theme_shell.py` wires standard shell controls and fixes the responsive
  top-bar height at the 52-logical-pixel `top_bar_height` metric, passed once
  through the optional user-scale helper. Qt handles monitor DPI conversion.
  The notification host clears the Designer grid's implicit margins and sizes
  from the button hint so its contents remain inside the one-row bar.
- `ui/main_window_shell.py` loads and mounts these three forms; its parent
  `ui/main_window.py` composes navigation and page lifecycle and must not set
  their layout margins, stretches, spacing, or size policies.

## Shared operational page headers

`resources/ui/*.ui` owns each page's static `pageHeader` hierarchy. Home retains
its public `DashboardHeader` object name, and existing KPI and Administration
control names remain stable. `ui/page_header.py` applies the shared spacing
metrics and QSS roles to those Designer-owned layouts without recreating them.
The title and description stay in the header; page actions, search, and filters
remain outside it. Administration keeps its route selector, activity status,
and refresh action together in the separate Designer-owned `pageToolbar`.
Settings and About remain dialogs and do not receive operational page headers.

Header typography and surface styling are shared in `resources/style.qss`;
header padding and text/action spacing are defined once in `ui/theme_metrics.py`.
The visual RTL/LTR and DPI verification gates remain `NOT_VERIFIED` until
captured and checked at those display settings.

## Guardrails

`python ops/audit.py source-quality` is fail-closed for the single stylesheet
application owner and the three shell Designer owners. The focused Designer,
responsive-shell, and theme tests are required before a shell cleanup is
accepted. Near-duplicate candidates are review work, not automatic deletions:
each is later recorded as `MERGE`, `KEEP`, or `EXTRACT` with its rationale.

## Administration decomposition

`ui/administration.py` is the workspace composer and public compatibility
surface. A section moves only when its complete implementation moves with it;
the original class body is then removed. Extracted owners are
`ui/administration_catalogs.py` for `AdministrationCatalogsSection` and
`ui/administration_overview.py` for `OverviewSection`; the user/branch-account
collection and its filter model are owned by `ui/administration_users.py`; the
permission catalogue is owned by `ui/administration_permissions.py`; the
organization-structure section is owned by `ui/administration_structure.py`.
Its dirty-editor contract and the public maximum-widget-extent constant are
shared through `ui/administration_shared.py`; direct-scope assignments are
owned by `ui/administration_assignments.py`; audit filtering and presentation
are owned by `ui/administration_audit.py`.

## Large UI module decomposition

Notification decision, identity, persistence, and deduplication are owned by
`services/notifications.py`. Pure notification message rendering is owned by
`ui/notification_presentation.py`; the one-shot delivery queue belongs to
`ui/notification_queue.py`. Sound playback is owned by
`ui/notification_sound.py`, in-app widgets by `ui/notification_views.py`,
Windows toast/tray delivery by `ui/notification_desktop.py`, and history,
badge, and delivery lifecycle orchestration by `ui/notification_service.py`.
There is no notification compatibility facade.

## Tracking decomposition

`ui/tracking.py` is the public `TrackingPage` facade and composition root.
Data loading belongs to `ui/tracking_data.py`; edit/delete dialogs to
`ui/tracking_dialogs.py`; form construction and mutation handling to
`ui/tracking_form.py` and `ui/tracking_form_controller.py`; toolbar and table
responsiveness to `ui/tracking_responsive.py`; table construction to
`ui/tracking_table.py`; and page mixin composition/Designer mounting to
`ui/tracking_composition.py`. Source-quality fails closed if any owner moves
back to the facade.

## Main-window decomposition

`ui/main_window.py` is the `HerfyMainWindow` shell composition root. Navigation
and access are owned by `ui/main_window_access.py`; session generation and
lifecycle state by `services/session_scope.py`; keyed runtime timers by
`services/runtime_timers.py`; expiry scheduling/evaluation by
`services/monitoring_coordinator.py`; notification history and tray state by
`ui/main_window_notifications.py`; session/auth/update lifecycle by
`ui/main_window_session.py`; and page lifecycle plus shell mounting by
`ui/main_window_shell.py`. SSE start policy is owned by
`services/sync.py`; `infra/tray.py` owns OS tray integration.

## Theme decomposition

`ui/theme.py` is a compatibility facade only. `ui/theme_metrics.py` owns
`ComponentSizes` and `UI_METRICS`; `ui/theme_responsive.py` owns profiles,
breakpoints, live reflow, density, and DPI-aware sizing; `ui/theme_geometry.py`
owns persisted window placement and screen fitting; `ui/theme_shell.py` owns
Designer-backed sidebar/top-bar composition and shell metrics;
`ui/theme_stack.py` owns `PageStack`; `ui/theme_animation.py` owns transient
effects; and `ui/theme_manager.py` is the sole QSS application owner.
Source-quality fails closed if one of these implementations returns to the
facade.
