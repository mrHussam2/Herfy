# Right-workspace layout guide

The left navigation sidebar is deliberately outside this guide and was not
modified in this workspace.

| Screen | Presentation file | Designer form | Margins | Spacing | Primary layout / safe manual adjustment point |
| --- | --- | --- | --- | --- | --- |
| Home | `ui/home.py` | `resources/ui/dashboard_page.ui` | `dashboard_root_layout` in the form, then page metrics in `HomePage` | form layout spacing and `UI_METRICS` | Adjust dashboard card distribution in the form's dashboard layout; do not edit `sidebar.ui`. |
| Tracking | `ui/tracking.py`, `ui/tracking_composition.py`, `ui/tracking_responsive.py` | `resources/ui/tracking_page.ui` | `tracking_content_layout` is zeroed in `TrackingUiBuilderMixin`; page metrics own outer margins | `tracking_content_layout` uses `UI_METRICS.page_section_gap` | `tracking_toolbar_layout` owns fields; `TrackingResponsiveLayoutMixin._layout_tracking_table_header` owns the title/action/count row. `TrackingUiBuilderMixin` disables outer scrollbars so `QTableView` owns row scrolling. |
| Usage | `ui/usage.py` | `resources/ui/usage_page.ui` | `usage_controls_grid` is set from toolbar metrics in `_build_controls_panel`; table host margins are zero in XML | grid gaps are set from `UI_METRICS.toolbar_horizontal_gap` | Adjust `usage_controls_grid`; the table remains the expanding `usage_table_host_layout` child. In small mode `_apply_responsive_usage_controls` keeps one row and moves file/print operations to More. |
| Sales KPI | `ui/kpi.py` | `resources/ui/kpi_page.ui` | `workspaceLayout` has XML margins 16; `KpiPage._build_ui` normalizes the workspace to `(8,6,8,6)` | XML `workspaceLayout` 12, normalized to 6 in `KpiPage` | `actionLayout` is the one desktop toolbar; `_apply_stable_toolbar_layout` owns desktop/compact distribution. `dashboardLayout` keeps the Activity inspector on demand so an empty panel never consumes report width. |
| Administration | `ui/administration.py`, `ui/administration_components.py`, `ui/administration_users.py` | `resources/ui/administration_page.ui`, `resources/ui/administration_header.ui`, `resources/ui/admin_account_collection.ui` | `AdministrationPage._build_ui` sets `admin_content_layout` from `UI_METRICS.page_margin`; `SplitWorkspace` keeps a 360px table minimum before compact stacking | root and content use `UI_METRICS.page_section_gap` | `admin_stack_layout` owns the expandable routed section; `AdministrationWorkspaceHeader` owns the compact toolbar; `AdminMasterDetailSplitter` owns the branch-account table/inspector ratio and `admin_account_actions` owns the mode-aware action strip. `HierarchyPicker.tree` owns vertical scrolling for long organization trees. |
| Product Catalogs | `ui/catalogs.py`, `ui/administration_catalogs.py` | `resources/ui/product_catalog_page.ui`, `resources/ui/catalog_page.ui` | form layouts own static margins; page composition applies shared page metrics | form layout spacing plus shared metrics | Modify the embedded list/inspector layouts only; catalog pages are routed inside ContentStack. |
| About | `ui/about.py` | `resources/ui/about_page.ui` | form layout and `AboutPage` responsive callback | form spacing | Adjust the form's root layout; it is an embedded page, not a dialog. |
| Settings | `ui/settings.py`, `ui/settings_controller.py` | `resources/ui/settings_dialog.ui` and section forms | section-form margins | section-form spacing | Change the selected settings section form, retaining the main workspace host. |

All values can be changed in XML when static. Use the named Python methods
above only for responsive behavior or dynamic controls; avoid manual geometry.

## Native control styling boundary

The shared theme is applied once by `ui/theme_manager.py`; no right-workspace
page calls `setStyleSheet()` for a button, input, table, or combo box.  The
application selects Qt Fusion in `main.py` before its one `QApplication` is
created.

The generic blue input rules remain available for non-workspace surfaces, but
the right workspace explicitly opts into palette-based Fusion controls by
setting `nativeWorkspace=True` in these real page constructors:

| Page | Opt-in location |
| --- | --- |
| Home | `ui/home.py`, `HomeDashboardPage.__init__` |
| Tracking | `ui/tracking.py`, `TrackingPage.__init__` |
| Usage | `ui/usage.py`, `UsagePage.__init__` |
| Sales KPI | `ui/kpi.py`, `KpiPage.__init__` |
| Administration | `ui/administration.py`, `AdministrationPage.__init__` |
| Product Catalogs | `ui/catalogs.py`, `CatalogPage.__init__` and `ProductCatalogPage.__init__` |
| About | `ui/about.py`, `AboutPage.__init__` |

The matching rules are the **RIGHT WORKSPACE — NATIVE FUSION CONTROLS** block
in `resources/style.qss`. It restores palette-based `QComboBox`, popup view,
input, date, spin, text, and table-view colors inside only those pages,
including the named Tracking, KPI, and Administration combo boxes that had
more-specific legacy rules. The protected `QFrame#Sidebar` and
`QFrame#NavigationDrawerPanel` rules are separate and were not edited.

Tracking's one-row create/edit toolbar is owned by
`ui/tracking_responsive.py:_STABLE_WORKSPACE_PLACEMENTS`. The form groups are
all row `0`; each group keeps only its own label/input vertical layout from
`resources/ui/tracking_page.ui`.
