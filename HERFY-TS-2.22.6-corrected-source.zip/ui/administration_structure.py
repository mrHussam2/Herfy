"""Server-authoritative organization structure presentation."""

from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QInputDialog,
    QMenu,
    QPushButton,
    QSplitter,
    QStackedWidget,
    QWidget,
)

from core.presentation import normalize_role
from ui.dialogs import show_question_message
from core.settings import _
from ui.administration_components import (
    HierarchyPicker,
    StructureDetailsView,
    StructureEditorDialog,
)
from ui.administration_controller import AdministrationPresenter
from ui.administration_shared import QT_WIDGET_SIZE_MAX, _ActiveEditorDirtyMixin
from ui.designer import load_ui
from ui.theme import (
    ADMIN_STRUCTURE_COLLAPSED_WIDTH,
    ADMIN_STRUCTURE_MIN_WIDTH,
    ADMIN_STRUCTURE_PREFERRED_WIDTH,
)
from ui.widgets import DataSurface


class StructureSection(_ActiveEditorDirtyMixin, QWidget):
    """Context-driven organization browser for the canonical HERFY hierarchy.

    The organization root is server-owned and read-only.  Administration mutates
    only Region, Area and Branch rows, while every action remains permission- and
    scope-gated by the server bootstrap projection.
    """

    entity_requested = Signal(str, str)

    _CREATE_CAP = {
        "region": "regions.create",
        "area": "areas.create",
        "branch": "branches.create",
    }
    _UPDATE_CAP = {
        "region": "regions.update",
        "area": "areas.update",
        "branch": "branches.update",
    }
    _DELETE_CAP = {
        "region": "regions.delete",
        "area": "areas.delete",
        "branch": "branches.delete",
    }

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminStructureSection")
        self.controller = controller
        self._snapshot: dict[str, Any] = {}
        self._selected: tuple[str, str, dict[str, Any]] | None = None
        self._tree_collapsed = False
        self._context_create: tuple[str, str] | None = None
        self._pending_structure_save = False

        controls = load_ui(
            self,
            "admin_structure_section",
            required=(
                "AdminStructureWorkspace",
                "AdminStructurePane",
                "AdminStructureCollapseButton",
                "admin_structure_tree_host",
                "AdminStructureWorkspacePanel",
            ),
        )
        self.split: QSplitter = controls["AdminStructureWorkspace"]
        self.split.setChildrenCollapsible(False)
        self.split.setHandleWidth(4)
        self.tree_panel: QFrame = controls["AdminStructurePane"]
        self.tree_panel.setMinimumWidth(ADMIN_STRUCTURE_MIN_WIDTH)
        self.tree_panel.layout().setContentsMargins(8, 8, 8, 8)
        self.tree_panel.layout().setSpacing(6)
        self.collapse_tree: QPushButton = controls["AdminStructureCollapseButton"]
        self.collapse_tree.setProperty("variant", "icon")
        self.collapse_tree.setToolTip(_("Collapse organization structure"))
        self.collapse_tree.clicked.connect(self._toggle_tree_panel)
        self.tree = HierarchyPicker(self.tree_panel)
        self.tree_surface = DataSurface(self.tree, self.tree_panel)
        controls["admin_structure_tree_host"].layout().addWidget(self.tree_surface)
        self.workspace_stack: QStackedWidget = controls["AdminStructureWorkspacePanel"]
        self.workspace_panel = self.workspace_stack
        self.details = StructureDetailsView(self.workspace_stack)
        self.editor = StructureEditorDialog(self.workspace_stack)
        self.workspace_stack.addWidget(self.details)
        self.workspace_stack.addWidget(self.editor)
        self.split.setStretchFactor(0, 3)
        self.split.setStretchFactor(1, 7)

        self.tree.entity_selected.connect(self._selected_entity)
        self.tree.add_requested.connect(self._create_context_child)
        self.details.edit_requested.connect(self._edit)
        self.details.move_requested.connect(self._move_branch)
        self.details.delete_requested.connect(self._delete)
        self.editor.cancel_requested.connect(self._cancel_editor)
        self.editor.save_requested.connect(self._save)
        self.controller.structure_saved.connect(self._on_structure_saved)
        self.controller.operation_failed.connect(self._on_operation_failed)
        self.tree.tree.customContextMenuRequested.connect(self._context_menu)
        self.tree.tree.itemDoubleClicked.connect(lambda _item, _column: self._emit_open_selected())

    def set_compact_mode(self, compact: bool) -> None:
        compact = bool(compact)
        self.details.set_compact_mode(compact)
        if getattr(self, "_responsive_compact", None) != compact:
            self._responsive_compact = compact
            self._set_tree_collapsed(compact)
        # Keep the hierarchy a true side panel.  On compact windows it can be
        # collapsed by the adjacent chevron instead of changing axis and causing
        # a second stacked layout.
        self.split.setOrientation(Qt.Horizontal)
        if not self._tree_collapsed:
            self.tree_panel.setMaximumWidth(QT_WIDGET_SIZE_MAX)

    def _toggle_tree_panel(self) -> None:
        self._set_tree_collapsed(not self._tree_collapsed)

    def _set_tree_collapsed(self, collapsed: bool) -> None:
        self._tree_collapsed = bool(collapsed)
        self.tree_surface.setVisible(not self._tree_collapsed)
        if self._tree_collapsed:
            self.tree_panel.layout().setContentsMargins(4, 8, 4, 8)
            self.tree_panel.layout().setAlignment(Qt.AlignTop)
            self.tree_panel.setMinimumWidth(0)
            self.tree_panel.setMaximumWidth(QT_WIDGET_SIZE_MAX)
            self.collapse_tree.setText("›")
            self.collapse_tree.setToolTip(_("Expand organization structure"))
            self.split.setSizes(
                [
                    ADMIN_STRUCTURE_COLLAPSED_WIDTH,
                    max(0, self.split.width() - ADMIN_STRUCTURE_COLLAPSED_WIDTH),
                ]
            )
        else:
            self.tree_panel.layout().setContentsMargins(8, 8, 8, 8)
            self.tree_panel.layout().setAlignment(Qt.AlignmentFlag(0))
            self.tree_panel.setMinimumWidth(ADMIN_STRUCTURE_MIN_WIDTH)
            self.tree_panel.setMaximumWidth(QT_WIDGET_SIZE_MAX)
            self.collapse_tree.setText("‹")
            self.collapse_tree.setToolTip(_("Collapse organization structure"))
            self.split.setSizes(
                [
                    ADMIN_STRUCTURE_PREFERRED_WIDTH,
                    max(0, self.split.width() - ADMIN_STRUCTURE_PREFERRED_WIDTH),
                ]
            )

    def _organizations(self) -> list[dict[str, Any]]:
        return AdministrationPresenter.structure_organizations(self._snapshot)

    def set_snapshot(self, snapshot: dict[str, Any]) -> None:
        editor_was_active = self.workspace_stack.currentWidget() is self.editor
        editor_was_dirty = editor_was_active and self.editor.is_dirty()
        previous = self._selected[:2] if self._selected else None
        self._snapshot = dict(snapshot or {})
        self._selected = None
        self.tree.set_snapshot(snapshot)
        organizations = self._organizations()
        total = sum(
            len([item for item in rows or [] if isinstance(item, dict)])
            for rows in (
                organizations,
                snapshot.get("regions"),
                snapshot.get("areas"),
                snapshot.get("branches"),
            )
        )
        self.tree_surface.set_state("content")
        if not total:
            self._update_context_create()
            self._update_action_caps()
            return

        # Preserve selection across refresh.  With one organization, default to
        # the fixed root so the only primary action becomes Add Region.
        restored = False
        if previous:
            restored = self.tree.select_entity(previous[0], previous[1])
        if not restored and len(organizations) == 1:
            oid = str(organizations[0].get("organization_id") or "").strip()
            if oid:
                self.tree.select_entity("organization", oid)
        self._update_context_create()
        self._update_action_caps()
        if editor_was_active and editor_was_dirty:
            # Snapshot refreshes may update tables/management projections while an
            # editor is open. Never discard a local draft as a side effect.
            self.editor.raise_()

    def _lookup(self, kind: str, ident: str) -> dict[str, Any] | None:
        key = {
            "region": "regions",
            "area": "areas",
            "branch": "branches",
        }.get(kind)
        if not key:
            for row in self._organizations():
                if str(row.get("organization_id") or "") == ident:
                    return row
            return None
        id_key = f"{kind}_id"
        for row in self._snapshot.get(key) or []:
            if isinstance(row, dict) and str(row.get(id_key) or "") == ident:
                return row
        return None

    def _hierarchy_context(self, kind: str, ident: str, row: dict[str, Any]) -> dict[str, str]:
        result = {"organization": "", "region": "", "area": "", "branch": ""}
        if kind == "organization":
            result["organization"] = ident
            return result
        if kind == "region":
            result["organization"] = str(row.get("organization_id") or "")
            result["region"] = ident
            return result
        if kind == "area":
            rid = str(row.get("region_id") or "")
            region = self._lookup("region", rid) or {}
            result["organization"] = str(region.get("organization_id") or "")
            result["region"] = rid
            result["area"] = ident
            return result
        if kind == "branch":
            aid = str(row.get("area_id") or "")
            area = self._lookup("area", aid) or {}
            rid = str(area.get("region_id") or "")
            region = self._lookup("region", rid) or {}
            result["organization"] = str(region.get("organization_id") or "")
            result["region"] = rid
            result["area"] = aid
            result["branch"] = ident
        return result

    _MANAGEMENT_SCOPE_BY_ROLE = {
        "operations_director": "region",
        "operations_manager": "region",
        "operations_consultant": "area",
        "store_manager": "branch",
    }

    @classmethod
    def _has_direct_management_scope(
        cls,
        user: dict[str, Any],
        *,
        role: str,
        context: dict[str, str],
    ) -> bool:
        """Match the server-issued direct assignment for the management role.

        The client intentionally does not expand scope inheritance here.  It only
        projects the role + direct scope facts returned by the server so a branch
        manager is never presented as an Area/Region manager merely because those
        ancestors are present in effective-scope context.
        """
        expected_kind = cls._MANAGEMENT_SCOPE_BY_ROLE.get(normalize_role(role), "")
        expected_id = str(context.get(expected_kind) or "").strip()
        if not expected_kind or not expected_id:
            return False
        for assignment in AdministrationPresenter.user_direct_assignments(user):
            if not isinstance(assignment, dict):
                continue
            kind = str(assignment.get("scope_type") or "").strip().lower()
            ident = str(assignment.get("scope_id") or "").strip()
            if kind == expected_kind and ident == expected_id:
                return True
        return False

    def _responsible_people(self, role: str, context: dict[str, str]) -> str:
        names: list[str] = []
        target_role = normalize_role(role)
        for user in self._snapshot.get("users") or []:
            if not isinstance(user, dict) or AdministrationPresenter.is_branch_account(user):
                continue
            if normalize_role(str(user.get("role") or "")) != target_role:
                continue
            if not self._has_direct_management_scope(user, role=target_role, context=context):
                continue
            label = str(user.get("display_name") or user.get("username") or "").strip()
            username = str(user.get("username") or "").strip()
            if label and username and label != username:
                label = f"{label} (#{username})"
            if label:
                names.append(label)
        return ", ".join(sorted(set(names))) if names else "—"

    def _selected_entity(self, kind: str, ident: str, row: object) -> None:
        payload = dict(row or {}) if isinstance(row, dict) else {}
        self._selected = (kind, ident, payload)
        update = self._UPDATE_CAP.get(kind, "")
        delete = self._DELETE_CAP.get(kind, "")
        can_edit = bool(
            kind != "organization"
            and update
            and AdministrationPresenter.has_capability(self._snapshot, update)
        )
        can_move = bool(
            kind == "branch"
            and AdministrationPresenter.has_capability(self._snapshot, "branches.transfer")
        )
        can_delete = bool(
            kind != "organization"
            and delete
            and AdministrationPresenter.has_capability(self._snapshot, delete)
        )
        self.details.set_entity(
            self._snapshot,
            kind,
            ident,
            payload,
            can_edit=can_edit,
            can_move=can_move,
            can_delete=can_delete,
        )
        self._update_context_create()

    def _update_context_create(self) -> None:
        self._context_create = None
        selected_kind = self._selected[0] if self._selected else ""
        selected_id = self._selected[1] if self._selected else ""
        mapping = {
            "organization": ("region", _("Add Region")),
            "region": ("area", _("Add Area")),
            "area": ("branch", _("Add Branch")),
        }
        target = mapping.get(selected_kind)
        if target:
            child_kind, label = target
            capability = self._CREATE_CAP.get(child_kind, "")
            allowed = bool(
                capability and AdministrationPresenter.has_capability(self._snapshot, capability)
            )
            if allowed:
                self._context_create = (child_kind, selected_id)
                self.tree.set_add_action(label, True)
                return
        self.tree.set_add_action(_("+ Add"), False)

    def _update_action_caps(self) -> None:
        if not self._selected:
            self.tree.set_add_action(_("+ Add"), False)
            return
        kind = self._selected[0]
        update = self._UPDATE_CAP.get(kind, "")
        delete = self._DELETE_CAP.get(kind, "")
        self.details.set_action_permissions(
            can_edit=bool(
                kind != "organization"
                and update
                and AdministrationPresenter.has_capability(self._snapshot, update)
            ),
            can_move=bool(
                kind == "branch"
                and AdministrationPresenter.has_capability(self._snapshot, "branches.transfer")
            ),
            can_delete=bool(
                kind != "organization"
                and delete
                and AdministrationPresenter.has_capability(self._snapshot, delete)
            ),
        )

    def _create_context_child(self) -> None:
        if not self._context_create:
            return
        kind, parent_id = self._context_create
        self._open_editor(kind, None, parent_id=parent_id)

    def _open_editor(
        self,
        kind: str,
        row: dict[str, Any] | None,
        *,
        parent_id: str = "",
    ) -> None:
        # Organization is intentionally not editable from the client workspace.
        if kind == "organization":
            return
        self.editor.configure(kind, self._snapshot, row, parent_id=parent_id)
        self.workspace_stack.setCurrentWidget(self.editor)
        self.editor.show()

    def _edit(self) -> None:
        if self._selected and self._selected[0] != "organization":
            self._open_editor(self._selected[0], self._selected[2])

    def _save(self, kind: str, values: dict[str, Any]) -> None:
        if kind == "organization":
            return
        existing = bool(
            self._selected
            and self._selected[0] == kind
            and str(self._selected[1]) == str(values.get("code"))
        )
        worker = self.controller.save_structure(kind, values, existing=existing)
        if worker is not None:
            self._pending_structure_save = True

    def _on_structure_saved(self, _kind: str, _result: dict[str, Any]) -> None:
        if not self._pending_structure_save:
            return
        self._pending_structure_save = False
        entity = _result.get("entity") if isinstance(_result, dict) else None
        self.editor.hide()
        self.workspace_stack.setCurrentWidget(self.details)
        if isinstance(entity, dict):
            ident = str(entity.get(f"{_kind}_id") or "").strip()
            if ident and self.select_entity(_kind, ident):
                return

    def _on_operation_failed(self, operation_key: str, _failure: object) -> None:
        if str(operation_key or "").startswith("admin.structure.save:"):
            # Keep the editor and its draft visible after a failed/conflicting
            # mutation; only clear the pending-close marker.
            self._pending_structure_save = False

    def _cancel_editor(self) -> None:
        if not self._confirm_editor_discard(
            dirty=self.editor.is_dirty(),
            message=_("Discard the unsaved structure changes?"),
        ):
            return
        self.editor.hide()
        self.workspace_stack.setCurrentWidget(self.details)

    def _move_branch(self) -> None:
        if not self._selected or self._selected[0] != "branch":
            return
        _kind, branch_id, row = self._selected
        current_area = str(row.get("area_id") or "").strip()
        areas = [
            dict(item)
            for item in self._snapshot.get("areas") or []
            if isinstance(item, dict) and str(item.get("area_id") or "").strip()
        ]
        options: list[tuple[str, str]] = []
        for area in sorted(areas, key=lambda item: str(item.get("area_id") or "")):
            area_id = str(area.get("area_id") or "").strip()
            label = str(area.get("name") or area_id).strip() or area_id
            options.append((f"{label} ({area_id})" if label != area_id else area_id, area_id))
        if not options:
            return
        labels = [label for label, _area_id in options]
        current_index = next(
            (index for index, (_label, area_id) in enumerate(options) if area_id == current_area),
            0,
        )
        selected, accepted = QInputDialog.getItem(
            self,
            _("Move Branch"),
            _("Target area for {branch}").format(branch=branch_id),
            labels,
            current_index,
            False,
        )
        if not accepted:
            return
        selected_index = labels.index(selected) if selected in labels else -1
        if selected_index < 0:
            return
        area_id = options[selected_index][1]
        if area_id == current_area:
            return
        answer = show_question_message(
            self,
            _("Confirm branch move"),
            _("Move {branch} from {current} to {target}?").format(
                branch=branch_id, current=current_area or "—", target=area_id
            )
        )
        if answer:
            self.controller.transfer_branch(row, area_id)

    def _delete(self) -> None:
        if not self._selected or self._selected[0] == "organization":
            return
        kind, ident, row = self._selected
        title = _("Confirm structure removal")
        message = _(
            "Remove {id}? If operational history or linked authority must be preserved, "
            "the server will disable it; otherwise it will be deleted permanently. "
            "Audit history is always preserved."
        ).format(id=ident)
        answer = show_question_message(
            self, title, message
        )
        if answer:
            self.controller.remove_structure(kind, ident, int(row.get("revision") or 0))

    def _emit_open_selected(self) -> None:
        if self._selected:
            self.entity_requested.emit(str(self._selected[0]), str(self._selected[1]))

    def _context_menu(self, pos) -> None:
        menu = self._build_context_menu(pos)
        if menu is not None:
            menu.exec(self.tree.tree.viewport().mapToGlobal(pos))

    def _build_context_menu(self, pos=None) -> QMenu | None:
        """Build the real hierarchy context menu for both interaction and QA.

        Keeping construction separate from presentation makes the exact menu
        reusable by the runtime visual harness without duplicating actions.
        """
        if pos is not None:
            item = self.tree.tree.itemAt(pos)
            if item is not None and item not in self.tree.tree.selectedItems():
                self.tree.tree.setCurrentItem(item)
                item.setSelected(True)
                self.tree._emit_selected()
        if not self._selected:
            return None
        menu = QMenu(self)
        menu.setObjectName("StructureContextMenu")
        menu.addAction(_("Open"), self._emit_open_selected)
        if self.details.edit.isVisible() and self.details.edit.isEnabled():
            menu.addAction(_("Edit"), self._edit)
        if self.details.move.isVisible() and self.details.move.isEnabled():
            menu.addAction(_("Move Branch"), self._move_branch)
        if self.details.delete.isVisible() and self.details.delete.isEnabled():
            menu.addAction(self.details.delete.text(), self._delete)
        if self._context_create and self.tree.add_button.isVisible():
            menu.addSeparator()
            menu.addAction(self.tree.add_button.text(), self._create_context_child)
        return menu

    def select_entity(self, kind: str, ident: str) -> bool:
        if self._tree_collapsed:
            self._set_tree_collapsed(False)
        return self.tree.select_entity(kind, ident)
