from __future__ import annotations

import logging

from PySide6.QtCore import QRect, QSettings, QSize, QTimer
from PySide6.QtWidgets import QApplication

from core.errors import UI_OPERATION_EXCEPTIONS
from ui.theme_metrics import UI_METRICS
from ui.theme_responsive import active_screen_geometry

logger = logging.getLogger(__name__)
"""Main-window placement, adaptive chrome, and screen-aware geometry tools."""


logger = logging.getLogger(__name__)

_GEOMETRY_KEY = "window/main_normal_geometry"
_SCREEN_KEY = "window/main_screen"
_GEOMETRY_SAVE_DELAY_MS = 280


def _screen_available_geometries(app: QApplication | None = None) -> list[QRect]:
    app = app or QApplication.instance()
    if app is None:
        return []
    geometries: list[QRect] = []
    try:
        for screen in app.screens():
            geometry = screen.availableGeometry()
            if geometry.isValid():
                geometries.append(QRect(geometry))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Unable to enumerate available screen geometries", exc_info=True)
    if geometries:
        return geometries
    geometry = active_screen_geometry(None, app)
    return [QRect(geometry)] if geometry is not None else []


def _screen_geometry_by_name(name: str, app: QApplication | None = None) -> QRect | None:
    app = app or QApplication.instance()
    target = str(name or "").strip()
    if app is None or not target:
        return None
    try:
        for screen in app.screens():
            if str(screen.name() or "") == target:
                geometry = screen.availableGeometry()
                return QRect(geometry) if geometry.isValid() else None
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Saved screen lookup failed", exc_info=True)
    return None


def _rect_has_visible_area(rect: QRect, app: QApplication | None = None) -> bool:
    """Return whether enough of a restored window remains reachable on any screen."""
    if not rect.isValid():
        return False
    minimum_visible = 96
    for area in _screen_available_geometries(app):
        visible = rect.intersected(area)
        if visible.width() >= minimum_visible and visible.height() >= minimum_visible:
            return True
    return False


def _fit_rect_to_area(rect: QRect, area: QRect, *, padding: int = 12) -> QRect:
    """Fit a normal-window rectangle into one monitor work area without distorting it."""
    safe = area.adjusted(padding, padding, -padding, -padding)
    if not safe.isValid():
        safe = QRect(area)
    safe_width = max(1, int(safe.width()))
    safe_height = max(1, int(safe.height()))
    minimum_width = min(320, safe_width)
    minimum_height = min(240, safe_height)
    width = min(max(minimum_width, rect.width()), safe_width)
    height = min(max(minimum_height, rect.height()), safe_height)
    x = min(max(rect.x(), safe.left()), max(safe.left(), safe.right() - width + 1))
    y = min(max(rect.y(), safe.top()), max(safe.top(), safe.bottom() - height + 1))
    return QRect(x, y, width, height)


def _default_window_rect(window, area: QRect) -> QRect:
    """Return a proportional first-run geometry based on the active work area."""
    max_width = max(1, int(area.width()) - 32)
    max_height = max(1, int(area.height()) - 32)
    width = min(
        max_width,
        max(
            min(UI_METRICS.app_window_min_width, max_width),
            int(area.width() * 0.90),
        ),
    )
    height = min(
        max_height,
        max(
            min(UI_METRICS.app_window_min_height, max_height),
            int(area.height() * 0.88),
        ),
    )
    x = area.left() + max(0, (area.width() - width) // 2)
    y = area.top() + max(0, (area.height() - height) // 2)
    return QRect(x, y, width, height)


def apply_window_constraints(window) -> None:
    """Apply a usable minimum that never exceeds the current monitor work area."""
    if window is None:
        return

    area = active_screen_geometry(window, QApplication.instance())
    if area is None:
        minimum = QSize(
            UI_METRICS.app_window_min_width,
            UI_METRICS.app_window_min_height,
        )
    else:
        safe_width = max(1, int(area.width()) - 24)
        safe_height = max(1, int(area.height()) - 24)
        minimum = QSize(
            min(UI_METRICS.app_window_min_width, safe_width),
            min(UI_METRICS.app_window_min_height, safe_height),
        )

    if window.minimumSize() != minimum:
        window.setMinimumSize(minimum)


def ensure_window_on_screen(window) -> None:
    """Clamp the current normal window geometry to the monitor it occupies."""
    if window is None or window.isMaximized() or window.isFullScreen():
        return
    app = QApplication.instance()
    area = active_screen_geometry(window, app)
    if area is None:
        return
    current = window.geometry()
    fitted = _fit_rect_to_area(current, QRect(area))
    if fitted != current:
        window.resize(fitted.size())
        window.move(fitted.topLeft())


def apply_initial_window_geometry(window) -> None:
    """Restore one persisted normal geometry and recover cleanly from monitor changes."""
    app = QApplication.instance()
    settings = QSettings()
    saved_screen = str(settings.value(_SCREEN_KEY, "") or "")
    area = _screen_geometry_by_name(saved_screen, app) or active_screen_geometry(window, app)
    if area is None:
        return

    apply_window_constraints(window)
    restored = False
    saved = settings.value(_GEOMETRY_KEY)
    if saved:
        try:
            restored = bool(window.restoreGeometry(saved))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Main window geometry restore failed", exc_info=True)
            restored = False

    if restored and not _rect_has_visible_area(window.frameGeometry(), app):
        restored = False

    if saved and not restored:
        settings.remove(_GEOMETRY_KEY)

    if not restored:
        initial = _default_window_rect(window, QRect(area))
        window.resize(initial.size())
        window.move(initial.topLeft())
    else:
        ensure_window_on_screen(window)


def save_window_placement(window) -> None:
    """Persist maximized state plus the last valid normal geometry."""
    if window is None:
        return
    settings = QSettings()
    try:
        handle = window.windowHandle() if hasattr(window, "windowHandle") else None
        screen = handle.screen() if handle is not None else None
        if screen is not None:
            settings.setValue(_SCREEN_KEY, str(screen.name() or ""))
        if (
            not window.isMaximized()
            and not window.isMinimized()
            and not window.isFullScreen()
            and window.isVisible()
        ):
            settings.setValue(_GEOMETRY_KEY, window.saveGeometry())
        settings.sync()
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Main-window placement persistence failed", exc_info=True)


def schedule_window_placement_save(window, *, delay_ms: int = _GEOMETRY_SAVE_DELAY_MS) -> None:
    """Debounce move/resize persistence so geometry I/O is not performed per pixel."""
    if window is None:
        return
    timer = getattr(window, "_window_placement_save_timer", None)
    if timer is None:
        timer = QTimer(window)
        timer.setSingleShot(True)
        timer.timeout.connect(lambda: save_window_placement(window))
        window._window_placement_save_timer = timer
    timer.start(max(80, int(delay_ms or _GEOMETRY_SAVE_DELAY_MS)))
