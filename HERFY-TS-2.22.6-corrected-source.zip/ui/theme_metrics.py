from __future__ import annotations

from dataclasses import dataclass

"""Shared component defaults in logical pixels; Qt handles monitor DPI."""


@dataclass(frozen=True)
class ComponentSizes:
    page_margin: int = 6
    page_section_gap: int = 6
    page_header_padding: int = 8
    page_header_gap: int = 4
    page_header_text_gap: int = 4
    page_header_min_height: int = 50
    card_padding: int = 6
    sidebar_rail_width: int = 44
    sidebar_compact_width: int = 70
    sidebar_width: int = 220
    sidebar_wide_max_width: int = 220
    sidebar_drawer_width: int = 220
    sidebar_small_breakpoint: int = 720
    sidebar_desktop_breakpoint: int = 960
    icon_size: int = 16
    badge_size: int = 16
    login_card_min_width: int = 360
    login_card_max_width: int = 420
    toast_min_width: int = 280
    toast_max_width: int = 400
    notifications_min_width: int = 300
    notifications_max_width: int = 420
    notifications_min_height: int = 200
    notifications_max_height: int = 400
    notifications_row_height: int = 44
    notifications_popup_fallback_height: int = 220
    progress_thin_height: int = 6
    input_min_width_sm: int = 100
    input_min_width_md: int = 120
    input_min_width_lg: int = 200
    compact_button_min_width: int = 64
    action_button_min_width: int = 72
    action_button_min_height: int = 32
    control_min_height: int = 32
    top_bar_height: int = 48
    table_row_height: int = 28
    table_header_height: int = 32
    qty_field_max_width: int = 80
    transition_progress_min_width: int = 130
    transition_progress_max_width: int = 180
    branch_list_min_height: int = 120
    # This is a desktop control centre, not a responsive web canvas.  Keep a
    # single stable composition instead of shrinking, reflowing, or adding a
    # second workspace scrollbar when an operator resizes the window.
    # The sidebar (220px) and the fixed page workspace need a little more
    # than 1280 logical pixels together.  Keeping this boundary explicit
    # prevents an otherwise valid desktop window from putting its pages into
    # their legacy compact arrangements while it is being resized.
    app_window_min_width: int = 1360
    app_window_min_height: int = 680
    app_window_fallback_width: int = 1280
    app_window_fallback_height: int = 800
    app_window_fallback_min_width: int = 800
    app_window_fallback_min_height: int = 600
    edit_product_dialog_min_width: int = 340
    edit_product_dialog_min_height: int = 190
    edit_product_dialog_max_width: int = 480
    edit_product_dialog_max_height: int = 320
    dashboard_metric_tile_min_height: int = 42
    dashboard_metric_small_two_column_width: int = 480
    dashboard_metric_tile_margin_horizontal: int = 5
    dashboard_metric_tile_margin_top: int = 3
    dashboard_metric_tile_margin_bottom: int = 3
    dashboard_metric_tile_horizontal_gap: int = 4
    dashboard_metric_tile_vertical_gap: int = 1
    dashboard_metric_icon_size: int = 18
    dashboard_metric_icon_box: int = 24
    dashboard_metric_accent_height: int = 2
    dashboard_hero_min_height: int = 36
    dashboard_actions_card_compact_min_width: int = 108
    dashboard_actions_card_min_width: int = 120
    dashboard_root_spacing: int = 8
    dashboard_action_icon_size: int = 20
    usage_receipts_button_min_width: int = 66
    usage_opening_button_min_width: int = 68
    usage_recalculate_button_min_width: int = 92
    usage_recalculate_icon_size: int = 16
    usage_print_icon_min_size: int = 20
    usage_print_icon_size: int = 22
    usage_table_margin_horizontal: int = 6
    usage_table_margin_top: int = 5
    usage_table_margin_bottom: int = 6
    usage_table_gap: int = 3
    usage_table_min_section_width: int = 48
    tracking_branch_input_min_width: int = 118
    tracking_quantity_input_min_width: int = 72
    tracking_date_input_min_width: int = 122
    # The add-product workflow is a desktop command strip.  The application
    # minimum width keeps this canvas intact without a nested scrollbar.
    tracking_workspace_min_width: int = 1040
    tracking_product_field_min_width: int = 300
    tracking_action_min_width: int = 96
    toolbar_control_height: int = 30
    toolbar_horizontal_gap: int = 6
    toolbar_horizontal_padding: int = 6
    toolbar_vertical_padding: int = 6
    toolbar_search_min_width: int = 120
    toolbar_more_min_width: int = 64
    toolbar_compact_breakpoint: int = 720
    toolbar_medium_breakpoint: int = 960
    toolbar_large_breakpoint: int = 1280
    analytics_outer_margin: int = 6
    analytics_section_gap: int = 6
    analytics_card_gap: int = 6
    analytics_card_min_width: int = 148
    analytics_card_min_height: int = 64
    analytics_card_padding: int = 6
    analytics_chart_gap: int = 12
    analytics_chart_min_width: int = 350
    analytics_chart_min_height: int = 220
    analytics_table_row_height: int = 30
    admin_collection_count_badge_min_width: int = 42
    admin_collection_count_badge_max_width: int = 56
    admin_permissions_selection_badge_min_width: int = 72
    admin_permissions_role_min_width: int = 210
    settings_select_field_max_width: int = 360
    settings_text_field_max_width: int = 440
    widget_maximum_extent: int = 16777215
    catalog_editor_min_width: int = 300
    catalog_editor_max_width: int = 400
    catalog_navigation_min_width: int = 174
    catalog_navigation_compact_max_width: int = 132
    catalog_navigation_max_width: int = 210
    catalog_navigation_spacing: int = 2


UI_METRICS = ComponentSizes()
