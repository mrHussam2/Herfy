from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Iterable
from typing import Any, Iterator

from PySide6.QtCore import (
    QModelIndex,
    QSize,
    Qt,
    Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QFormLayout,
    QFrame,
    QGridLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QTableView,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ui.dialogs import show_warning_message

from core.models import clean_text
from core.presentation import format_display_datetime, normalize_role
from core.settings import _
from ui.administration_controller import AdministrationPresenter
from ui.administration_shared import QT_WIDGET_SIZE_MAX as _QT_WIDGET_SIZE_MAX
from ui.designer import load_ui
from ui.responsive_toolbar import apply_toolbar_control_metrics
from ui.tables import (
    RowListTableModel,
    configure_sortable_table,
    configure_table_layout,
    horizontal_header_value,
    sortable_value_key,
)
from ui.theme import (
    ADMIN_INSPECTOR_MAX_WIDTH,
    ADMIN_INSPECTOR_MIN_WIDTH,
    ADMIN_INSPECTOR_PREFERRED_WIDTH,
    UI_METRICS,
    ResponsiveResizeMixin,
    ensure_layout_mode_controller,
    supports_admin_master_detail,
)
from ui.widgets import refresh_widget_style

logger = logging.getLogger(__name__)

# Public compatibility export; the shared module is the sole definition owner.
QT_WIDGET_SIZE_MAX = _QT_WIDGET_SIZE_MAX

# Administration UI building blocks


class AdminTableModel(RowListTableModel):
    def __init__(
        self,
        columns: list[tuple],
        parent=None,
    ):
        super().__init__(parent)
        self.columns = columns
        self._rows: list[dict[str, Any]] = []

    def rows(self) -> list[dict[str, Any]]:
        return list(self._rows)

    def row_payload(self, row: int) -> dict[str, Any] | None:
        return dict(self._rows[row]) if 0 <= row < len(self._rows) else None

    def replace_row(self, predicate, payload: dict[str, Any]) -> bool:
        for index, row in enumerate(self._rows):
            if predicate(row):
                self._rows[index] = dict(payload)
                self.dataChanged.emit(
                    self.index(index, 0),
                    self.index(index, max(0, len(self.columns) - 1)),
                    [Qt.DisplayRole, Qt.UserRole],
                )
                return True
        return False

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._rows)):
            return None
        row = self._rows[index.row()]
        if role == Qt.UserRole:
            return row
        if role not in (Qt.DisplayRole, Qt.EditRole, Qt.ToolTipRole):
            return None
        column = self.columns[index.column()]
        _label, accessor = column[0], column[1]
        value = accessor(row) if callable(accessor) else row.get(accessor, "")
        if role == Qt.EditRole:
            return value
        if isinstance(value, bool):
            return "✓" if value else "—"
        return str(value if value is not None else "")

    def sort(self, column: int, order=Qt.AscendingOrder) -> None:
        if not (0 <= column < len(self.columns)):
            return
        spec = self.columns[column]
        accessor = spec[2] if len(spec) > 2 else spec[1]

        def key(row: dict[str, Any]):
            value = accessor(row) if callable(accessor) else row.get(accessor, "")
            return sortable_value_key(value)

        self.layoutAboutToBeChanged.emit()
        self._rows.sort(key=key, reverse=order == Qt.DescendingOrder)
        self.layoutChanged.emit()

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        matches, label = horizontal_header_value(self.columns, section, orientation, role)
        if matches:
            return label
        return super().headerData(section, orientation, role)


class AdminTableView(QTableView):
    def __init__(self, parent=None, *, multi_select: bool = False):
        super().__init__(parent)
        self.setObjectName("AdminTable")
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(
            QAbstractItemView.ExtendedSelection
            if multi_select
            else QAbstractItemView.SingleSelection
        )
        self.setAlternatingRowColors(True)
        self.setWordWrap(False)
        self.setContextMenuPolicy(Qt.CustomContextMenu)
        self.setShowGrid(False)
        self.setCornerButtonEnabled(False)
        self.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        configure_table_layout(self, show_grid=False)

        vertical = self.verticalHeader()
        vertical.setVisible(False)
        vertical.setDefaultSectionSize(30)

        horizontal = self.horizontalHeader()
        horizontal.setMinimumSectionSize(1)
        horizontal.setStretchLastSection(False)
        horizontal.setHighlightSections(False)
        horizontal.setSectionsMovable(False)
        configure_sortable_table(self, enabled=True)

    def setModel(self, model) -> None:
        super().setModel(model)
        self._apply_semantic_header_policy()

    def _apply_semantic_header_policy(self) -> None:
        """Let Qt distribute administration columns by their semantic role.

        Descriptive identifiers share the available data surface; compact state
        and revision fields remain interactively sized. On narrow work areas the
        view may scroll horizontally rather than hiding server-authoritative data.
        """
        model = self.model()
        if model is None or model.columnCount() <= 0:
            return
        header = self.horizontalHeader()
        for column in range(model.columnCount()):
            label = str(model.headerData(column, Qt.Horizontal, Qt.DisplayRole) or "")
            normalized = label.casefold()
            descriptive = any(
                token in normalized
                for token in ("name", "username", "branch", "scope", "region", "area")
            )
            header.setSectionResizeMode(
                column,
                QHeaderView.Stretch if descriptive else QHeaderView.Interactive,
            )


class DetailsPanel(QFrame):
    """Read-only details surface used as a full administration workspace page.

    The panel can render one flat field set or several visual groups.  Grouping is
    presentation-only: it never changes the server-owned structure/user records.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminDetailsPanel")

        controls = load_ui(
            self,
            "admin_details_panel",
            required=("AdminDetailsTitle", "AdminDetailsSubtitle", "AdminDetailsBody"),
        )
        self.title: QLabel = controls["AdminDetailsTitle"]
        self.subtitle: QLabel = controls["AdminDetailsSubtitle"]
        self.body: QFrame = controls["AdminDetailsBody"]
        self.body_layout: QVBoxLayout = self.body.layout()
        self.title.setText(_("Details"))
        self.subtitle.hide()
        self.body_layout.setContentsMargins(0, 4, 0, 0)
        self.body_layout.setSpacing(7)

    def _clear_body(self) -> None:
        while self.body_layout.count():
            item = self.body_layout.takeAt(0)
            widget = item.widget() if item is not None else None
            if widget is not None:
                widget.deleteLater()
            child = item.layout() if item is not None else None
            if child is not None:
                while child.count():
                    nested = child.takeAt(0)
                    nested_widget = nested.widget() if nested is not None else None
                    if nested_widget is not None:
                        nested_widget.deleteLater()

    def _add_group(
        self,
        heading: str,
        fields: Iterable[tuple[str, str]],
        destination: QVBoxLayout,
        *,
        show_heading: bool = True,
    ) -> None:
        rows = [(str(label or ""), str(value or "—")) for label, value in fields]
        if not rows:
            return

        if show_heading and heading:
            group_title = QLabel(str(heading), self.body)
            group_title.setObjectName("AdminDetailsGroupTitle")
            destination.addWidget(group_title)

        form_host = QWidget(self.body)
        form_host.setObjectName("AdminDetailsFormHost")
        form = QFormLayout(form_host)
        form.setContentsMargins(0, 0, 0, 0)
        form.setHorizontalSpacing(10)
        form.setVerticalSpacing(2)
        form.setLabelAlignment(Qt.AlignLeading | Qt.AlignTop)
        form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)

        for label, value in rows:
            name = QLabel(label, form_host)
            name.setObjectName("AdminDetailsFieldLabel")
            name.setWordWrap(True)

            rendered = QLabel(value, form_host)
            rendered.setObjectName("AdminDetailsFieldValue")
            rendered.setWordWrap(True)
            rendered.setTextInteractionFlags(Qt.TextSelectableByMouse)
            # Status remains data-only, while these semantic properties allow
            # the one global theme to render a compact, consistent status pill.
            if str(label).casefold() == str(_("Status")).casefold():
                rendered.setProperty("uiRole", "status")
                rendered.setProperty(
                    "severity",
                    (
                        "success"
                        if str(value).casefold() == str(_("Active")).casefold()
                        else "critical"
                    ),
                )
            form.addRow(name, rendered)

        destination.addWidget(form_host)

    def _set_header(self, title: str, subtitle: str) -> None:
        self.title.setText(str(title or _("Details")))
        self.subtitle.setText(str(subtitle or ""))
        self.subtitle.setVisible(bool(subtitle))

    def set_details(
        self,
        title: str,
        fields: list[tuple[str, str]],
        *,
        subtitle: str = "",
    ) -> None:
        self._set_header(title, subtitle)
        self._clear_body()
        self._add_group("", fields, self.body_layout, show_heading=False)
        self.body_layout.addStretch(1)

    def set_grouped_details(
        self,
        title: str,
        groups: Iterable[tuple[str, Iterable[tuple[str, str]]]],
        *,
        subtitle: str = "",
    ) -> None:
        self._set_header(title, subtitle)
        self._clear_body()
        resolved = [(str(heading or ""), fields) for heading, fields in groups]
        for heading, fields in resolved:
            self._add_group(
                heading,
                fields,
                self.body_layout,
                show_heading=bool(heading),
            )
        self.body_layout.addStretch(1)


class FilterBar(QFrame):
    changed = Signal()
    refresh_requested = Signal()
    route_requested = Signal(str)

    def minimumSizeHint(self) -> QSize:  # noqa: N802 - Qt API
        hint = super().minimumSizeHint()
        return QSize(0, hint.height())

    def __init__(
        self,
        parent=None,
        *,
        show_role: bool = True,
        show_status: bool = True,
        show_scope: bool = False,
        show_refresh: bool = True,
    ):
        super().__init__(parent)
        self.setObjectName("AdminFilterBar")
        self.setProperty("uiRole", "standardToolbar")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMinimumWidth(0)
        controls = load_ui(
            self,
            "admin_filter_bar",
            required=(
                "AdminFilterSearch",
                "AdminFilterRole",
                "AdminFilterStatus",
                "AdminFilterScope",
                "AdminFilterCount",
                "AdminFilterRefresh",
                "AdminFilterMore",
            ),
        )
        layout: QGridLayout = self.layout()
        layout.setContentsMargins(
            UI_METRICS.toolbar_horizontal_padding,
            UI_METRICS.toolbar_vertical_padding,
            UI_METRICS.toolbar_horizontal_padding,
            UI_METRICS.toolbar_vertical_padding,
        )
        layout.setSpacing(UI_METRICS.toolbar_horizontal_gap)
        layout.setColumnStretch(0, 1)
        self.search: QLineEdit = controls["AdminFilterSearch"]
        self.role: QComboBox = controls["AdminFilterRole"]
        self.status: QComboBox = controls["AdminFilterStatus"]
        self.scope: QComboBox = controls["AdminFilterScope"]
        self.result_count: QLabel = controls["AdminFilterCount"]
        self.refresh: QPushButton = controls["AdminFilterRefresh"]
        self.more: QToolButton = controls["AdminFilterMore"]
        self._show_refresh = bool(show_refresh)
        self._show_role = bool(show_role)
        self._show_status = bool(show_status)
        self._show_scope = bool(show_scope)
        self.search.setPlaceholderText(_("Search..."))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.changed)
        self.role.addItem(_("All roles"), "")
        self.role.currentIndexChanged.connect(self.changed)
        self.role.setVisible(self._show_role)
        self.role.setMinimumWidth(0)
        self.status.addItem(_("All statuses"), "")
        self.status.addItem(_("Active"), "active")
        self.status.addItem(_("Disabled"), "disabled")
        self.status.currentIndexChanged.connect(self.changed)
        self.status.setVisible(self._show_status)
        self.status.setMinimumWidth(0)
        self.scope.addItem(_("All scopes"), ("", ""))
        self.scope.currentIndexChanged.connect(self.changed)
        self.scope.setVisible(self._show_scope)
        self.scope.setMinimumWidth(0)
        self.refresh.setText(_("Refresh"))
        self.refresh.setProperty("variant", "secondary")
        self.refresh.setProperty("toolbarActionAvailable", self._show_refresh)
        self.refresh.clicked.connect(self.refresh_requested)
        self.refresh.setVisible(self._show_refresh)
        self.more.setText(_("More"))
        self.more.setAccessibleName(_("More filters and actions"))
        self.more.setPopupMode(QToolButton.InstantPopup)
        self.more.setMinimumWidth(UI_METRICS.toolbar_more_min_width)
        self.more.setProperty("uiRole", "toolbarMore")
        self._more_menu = QMenu(self.more)
        self._more_menu.aboutToShow.connect(self._rebuild_more_menu)
        self.more.setMenu(self._more_menu)
        self.more.setVisible(False)
        self._toolbar_controls = [
            self.search,
            self.role,
            self.status,
            self.scope,
            self.refresh,
            self.more,
        ]
        self._toolbar_breakpoint = ""
        apply_toolbar_control_metrics(self, self._toolbar_controls, self.width())
        self.search.setMinimumWidth(UI_METRICS.toolbar_search_min_width)
        self.search.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.refresh.setVisible(self._show_refresh)
        self._apply_responsive_layout(force=True)

        self._filter_columns = None

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._apply_responsive_layout()

    def _apply_responsive_layout(self, *, force: bool = False) -> None:
        available_width = self.width()
        if available_width <= 0:
            available_width = (
                self.maximumWidth() if self.maximumWidth() > 0 else self.sizeHint().width()
            )
        if available_width <= 0 and self.parent() is not None:
            available_width = self.parent().width()
        if available_width <= 0:
            available_width = self.contentsRect().width()
        if available_width <= 0 and self.parent() is not None:
            available_width = self.parent().contentsRect().width()
        breakpoint = apply_toolbar_control_metrics(self, self._toolbar_controls, available_width)
        small = breakpoint == "small"
        self.role.setVisible(self._show_role and not small)
        self.status.setVisible(self._show_status and not small)
        self.scope.setVisible(self._show_scope and not small)
        self.refresh.setVisible(self._show_refresh and breakpoint in {"large", "medium"})
        self.more.setVisible(small or (self._show_refresh and breakpoint == "compact"))
        if not force and breakpoint == self._toolbar_breakpoint:
            self._rebuild_more_menu()
            return
        self._toolbar_breakpoint = breakpoint
        self._rebuild_more_menu()
        self._filter_columns = False
        layout = self.layout()
        items = [
            self.search,
            self.role,
            self.status,
            self.scope,
            self.result_count,
            self.refresh,
            self.more,
        ]
        for item in items:
            layout.removeWidget(item)
        for column in range(7):
            layout.setColumnStretch(column, 0)
        if small:
            # Never turn the administration toolbar into a vertical form.  The
            # search field remains available and the active filters move into
            # More, where their current selection is preserved.
            layout.addWidget(self.search, 0, 0)
            layout.addWidget(self.result_count, 0, 1)
            layout.addWidget(self.more, 0, 2)
            layout.setColumnStretch(0, 1)
        else:
            toolbar_items = items[:-2] + [
                self.refresh if breakpoint in {"large", "medium"} else self.more
            ]
            for column, item in enumerate(toolbar_items):
                layout.addWidget(item, 0, column)
            layout.setColumnStretch(0, 1)

    def _rebuild_more_menu(self) -> None:
        """Expose compact filters without reparenting or resetting widgets."""
        menu = self._more_menu
        menu.clear()
        if self._toolbar_breakpoint == "small":
            for caption, combo, enabled in (
                (_("Role"), self.role, self._show_role),
                (_("Status"), self.status, self._show_status),
                (_("Scope"), self.scope, self._show_scope),
            ):
                if enabled:
                    submenu = menu.addMenu(caption)
                    for index in range(combo.count()):
                        action = submenu.addAction(combo.itemText(index))
                        action.setCheckable(True)
                        action.setChecked(index == combo.currentIndex())
                        action.triggered.connect(
                            lambda _checked=False, selected=index, target=combo: target.setCurrentIndex(selected)
                        )
            if menu.actions() and self._show_refresh:
                menu.addSeparator()
        if self._show_refresh:
            refresh_action = menu.addAction(self.refresh.text())
            refresh_action.setEnabled(self.refresh.isEnabled())
            refresh_action.triggered.connect(self.refresh.click)
        menu.setLayoutDirection(self.layoutDirection())

    def set_result_count(self, shown: int, total: int) -> None:
        shown = max(0, int(shown))
        total = max(0, int(total))
        self.result_count.setText(f"{shown}/{total}")
        self.result_count.setToolTip(_("Visible items") + f": {shown} / {total}")

    def set_scope_options(self, rows: list[tuple[str, str, str]]) -> None:
        current = self.scope.currentData()
        self.scope.blockSignals(True)
        try:
            self.scope.clear()
            self.scope.addItem(_("All scopes"), ("", ""))
            for kind, ident, label in rows:
                text = (
                    f"{_(kind.title())} — {label} ({ident})"
                    if label and label != ident
                    else f"{_(kind.title())} — {ident}"
                )
                self.scope.addItem(text, (kind, ident))
            index = self.scope.findData(current)
            self.scope.setCurrentIndex(index if index >= 0 else 0)
        finally:
            self.scope.blockSignals(False)


"""Presentation-only hierarchy selector used by the Structure workspace.

The widget deliberately owns only tree composition, filtering and selection.
The administration section supplies the snapshot and remains responsible for
permissions, mutations and navigation.  This makes the hierarchy reusable and
keeps its visual treatment in ``resources/style.qss``.
"""


class HierarchyPicker(QFrame):
    """A one-column, non-scrolling structural hierarchy picker."""

    entity_selected = Signal(str, str, object)
    add_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("AdminHierarchyPicker")
        self._snapshot: dict[str, Any] = {}
        self._branches_by_area: dict[str, list[dict[str, Any]]] = {}
        self._area_items: dict[str, QTreeWidgetItem] = {}

        controls = load_ui(
            self,
            "admin_hierarchy_picker",
            required=("AdminHierarchySearch", "AdminHierarchyAddButton", "AdminHierarchyTree"),
        )
        self.search: QLineEdit = controls["AdminHierarchySearch"]
        self.search.setClearButtonEnabled(True)
        self.search.setPlaceholderText(_("Search regions, areas or branches..."))
        self.search.textChanged.connect(self._filter)
        self.add_button: QPushButton = controls["AdminHierarchyAddButton"]
        self.add_button.setText(_("+ Add"))
        self.add_button.setProperty("variant", "primary")
        self.add_button.setVisible(False)
        self.add_button.clicked.connect(self.add_requested)
        self.tree: QTreeWidget = controls["AdminHierarchyTree"]
        self.tree.setColumnCount(1)
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(True)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # A real organization can exceed the available inspector height. Keep
        # scrolling inside the tree rather than growing the whole workspace or
        # making lower branches unreachable.
        self.tree.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.itemSelectionChanged.connect(self._emit_selected)

    def set_add_action(self, text: str = "", visible: bool = False) -> None:
        self.add_button.setText(str(text or _("+ Add")))
        self.add_button.setVisible(bool(visible))

    def set_snapshot(self, snapshot: dict[str, Any]) -> None:
        """Render a server-provided snapshot without deriving access rights."""
        self._snapshot = dict(snapshot or {})
        self.tree.clear()
        self._area_items.clear()

        organizations = AdministrationPresenter.structure_organizations(snapshot)
        regions = self._rows(snapshot, "regions")
        areas = self._rows(snapshot, "areas")
        branches = self._rows(snapshot, "branches")
        regions_by_organization = self._group(rows=regions, parent_key="organization_id")
        areas_by_region = self._group(rows=areas, parent_key="region_id")
        self._branches_by_area = self._group(rows=branches, parent_key="area_id")

        for organization in sorted(
            organizations, key=lambda row: clean_text(row.get("organization_id"))
        ):
            organization_id = clean_text(organization.get("organization_id"))
            if not organization_id:
                continue
            organization_item = self._make_item(
                "organization",
                organization_id,
                organization,
                clean_text(organization.get("name")) or organization_id,
            )
            self.tree.addTopLevelItem(organization_item)
            for region in self._sorted(
                regions_by_organization.get(organization_id, []), "region_id"
            ):
                region_id = clean_text(region.get("region_id"))
                if not region_id:
                    continue
                region_item = self._make_item(
                    "region",
                    region_id,
                    region,
                    clean_text(region.get("name")) or region_id,
                )
                organization_item.addChild(region_item)
                for area in self._sorted(areas_by_region.get(region_id, []), "area_id"):
                    area_id = clean_text(area.get("area_id"))
                    if not area_id:
                        continue
                    area_item = self._make_item(
                        "area",
                        area_id,
                        area,
                        clean_text(area.get("name")) or area_id,
                    )
                    region_item.addChild(area_item)
                    self._area_items[area_id] = area_item
                    for branch in self._sorted(
                        self._branches_by_area.get(area_id, []), "branch_id"
                    ):
                        branch_id = clean_text(branch.get("branch_id"))
                        if branch_id:
                            area_item.addChild(
                                self._make_item(
                                    "branch",
                                    branch_id,
                                    branch,
                                    clean_text(branch.get("name")) or branch_id,
                                )
                            )
        self.tree.expandToDepth(1)
        self._filter()

    @staticmethod
    def _rows(snapshot: dict[str, Any], key: str) -> list[dict[str, Any]]:
        return [dict(row) for row in (snapshot or {}).get(key, []) if isinstance(row, dict)]

    @staticmethod
    def _group(*, rows: list[dict[str, Any]], parent_key: str) -> dict[str, list[dict[str, Any]]]:
        grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in rows:
            grouped[clean_text(row.get(parent_key))].append(row)
        return grouped

    @staticmethod
    def _sorted(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
        return sorted(rows, key=lambda row: clean_text(row.get(key)))

    def _make_item(self, kind: str, ident: str, row: dict[str, Any], label: str) -> QTreeWidgetItem:
        active = bool(row.get("is_active", True))
        display = label if active else f"{label} — {_('Disabled')}"
        item = QTreeWidgetItem([display])
        item.setData(0, Qt.UserRole, (kind, ident, dict(row)))
        item.setData(0, Qt.AccessibleTextRole, display)
        item.setToolTip(0, f"{kind.title()} · {ident}" if ident else kind.title())
        return item

    def select_entity(self, kind: str, ident: str) -> bool:
        for item in self._walk():
            item_kind, item_id, _row = self._item_data(item)
            if item_kind == str(kind or "") and item_id == str(ident or ""):
                self.tree.setCurrentItem(item)
                item.setSelected(True)
                parent = item.parent()
                while parent is not None:
                    parent.setExpanded(True)
                    parent = parent.parent()
                return True
        return False

    def _filter(self) -> None:
        needle = self.search.text().strip().casefold()

        def visit(item: QTreeWidgetItem) -> bool:
            child_match = any(visit(item.child(index)) for index in range(item.childCount()))
            own_match = not needle or needle in item.text(0).casefold()
            visible = own_match or child_match
            item.setHidden(not visible)
            if needle and visible:
                item.setExpanded(True)
            return visible

        for index in range(self.tree.topLevelItemCount()):
            visit(self.tree.topLevelItem(index))

    def _emit_selected(self) -> None:
        selected = self.tree.selectedItems()
        if not selected:
            return
        kind, ident, row = self._item_data(selected[0])
        if kind and ident:
            self.entity_selected.emit(kind, ident, row)

    def _walk(self) -> Iterator[QTreeWidgetItem]:
        pending = [self.tree.topLevelItem(index) for index in range(self.tree.topLevelItemCount())]
        while pending:
            item = pending.pop(0)
            yield item
            pending.extend(item.child(index) for index in range(item.childCount()))

    @staticmethod
    def _item_data(item: QTreeWidgetItem) -> tuple[str, str, dict[str, Any]]:
        raw = item.data(0, Qt.UserRole)
        if not isinstance(raw, tuple) or len(raw) != 3:
            return "", "", {}
        kind, ident, row = raw
        return str(kind or ""), str(ident or ""), dict(row or {})


KINDS = ("organization", "region", "area", "branch")


class ScopePicker(ResponsiveResizeMixin, QFrame):
    """Select direct mixed scopes without expanding parent selections locally.

    The widget is a presentation/editor for direct assignments only.  Effective
    descendants are calculated by the server; selecting a parent never writes
    synthetic child assignments into the request.
    """

    selection_changed = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminScopePicker")
        self._snapshot: dict[str, Any] = {}
        self._allowed: set[str] = set(KINDS)
        self._selected: set[tuple[str, str]] = set()
        self._syncing = False
        self._labels: dict[tuple[str, str], str] = {}
        self._lazy_branch_threshold = 1000
        self._lazy_branches = False
        self._branches_by_area: dict[str, list[dict[str, Any]]] = {}
        self._area_items: dict[str, QTreeWidgetItem] = {}

        controls = load_ui(
            self,
            "admin_scope_picker",
            required=(
                "AdminScopeSearch",
                "AdminScopeTree",
                "AdminScopeSummary",
                "admin_scope_select_visible",
                "admin_scope_clear",
                "admin_scope_expand",
                "admin_scope_collapse",
                "admin_scope_tools",
            ),
        )
        self.search: QLineEdit = controls["AdminScopeSearch"]
        self.select_visible: QPushButton = controls["admin_scope_select_visible"]
        self.clear: QPushButton = controls["admin_scope_clear"]
        self.expand: QPushButton = controls["admin_scope_expand"]
        self.collapse: QPushButton = controls["admin_scope_collapse"]
        self.tree: QTreeWidget = controls["AdminScopeTree"]
        self.summary: QLabel = controls["AdminScopeSummary"]
        self.tools_grid: QGridLayout = controls["admin_scope_tools"]
        self._tool_widgets = (
            self.search,
            self.select_visible,
            self.clear,
            self.expand,
            self.collapse,
        )
        self.search.setClearButtonEnabled(True)
        self.search.setPlaceholderText(_("Search scopes..."))
        for button, caption in (
            (self.select_visible, _("Select visible")),
            (self.clear, _("Clear")),
            (self.expand, _("Expand")),
            (self.collapse, _("Collapse")),
        ):
            button.setText(caption)
            button.setProperty("variant", "secondary")
        self.tree.setColumnCount(1)
        self.tree.setHeaderHidden(True)
        self.tree.setUniformRowHeights(True)
        self.tree.header().setSectionResizeMode(0, QHeaderView.Stretch)
        self.tree.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.tree.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.search.textChanged.connect(self._filter)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.itemExpanded.connect(self._populate_area)
        self.select_visible.clicked.connect(self._select_visible)
        self.clear.clicked.connect(lambda: self.set_selected_assignments([]))
        self.expand.clicked.connect(self.tree.expandAll)
        self.collapse.clicked.connect(self.tree.collapseAll)

        self._responsive_controller = ensure_layout_mode_controller(
            self,
            attr_name="_scope_picker_layout_controller",
        )
        self._responsive_controller.reflowRequested.connect(self._apply_responsive_layout)
        self._responsive_controller.schedule(force=True)

    def _apply_responsive_layout(self, mode: str, _profile) -> None:
        while self.tools_grid.count():
            self.tools_grid.takeAt(0)
        mode = str(mode or "desktop")
        if mode in {"small", "narrow"}:
            self.tools_grid.addWidget(self.search, 0, 0, 1, 2)
            for index, button in enumerate(
                (self.select_visible, self.clear, self.expand, self.collapse)
            ):
                self.tools_grid.addWidget(button, 1 + index // 2, index % 2)
            self.tools_grid.setColumnStretch(0, 1)
            self.tools_grid.setColumnStretch(1, 1)
        elif mode == "compact":
            self.tools_grid.addWidget(self.search, 0, 0, 1, 4)
            for index, button in enumerate(
                (self.select_visible, self.clear, self.expand, self.collapse)
            ):
                self.tools_grid.addWidget(button, 1, index)
                self.tools_grid.setColumnStretch(index, 1)
        else:
            for index, widget in enumerate(self._tool_widgets):
                self.tools_grid.addWidget(widget, 0, index)
            self.tools_grid.setColumnStretch(0, 1)
            for column in range(1, len(self._tool_widgets)):
                self.tools_grid.setColumnStretch(column, 0)

    def configure(
        self,
        snapshot: dict[str, Any],
        initial: Iterable[dict[str, str]] | None = None,
        allowed_types: Iterable[str] | None = None,
    ) -> None:
        self._snapshot = dict(snapshot or {})
        policy_types = set(AdministrationPresenter.allowed_scope_types(snapshot) or KINDS)
        requested_types = {
            str(value) for value in (allowed_types if allowed_types is not None else policy_types)
        }
        self._allowed = policy_types.intersection(requested_types)
        self._selected = {
            (str(row.get("scope_type")), str(row.get("scope_id")))
            for row in (initial or [])
            if isinstance(row, dict)
            and str(row.get("scope_type")) in self._allowed
            and str(row.get("scope_id") or "").strip()
        }
        self._build()
        self._filter()
        self._update_summary()

    def _make_item(
        self,
        parent: QTreeWidgetItem | None,
        kind: str,
        ident: str,
        name: str,
    ) -> QTreeWidgetItem:
        label = name or ident
        item = QTreeWidgetItem([label])
        item.setData(0, Qt.UserRole, {"type": kind, "id": ident})
        item.setFlags(
            item.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable
        )
        item.setCheckState(0, Qt.Checked if (kind, ident) in self._selected else Qt.Unchecked)
        self._labels[(kind, ident)] = label
        if parent is None:
            self.tree.addTopLevelItem(item)
        else:
            parent.addChild(item)
        return item

    def _build(self) -> None:
        self._syncing = True
        self.tree.clear()
        self._labels = {}
        try:
            organizations = AdministrationPresenter.structure_organizations(self._snapshot)
            regions = [
                dict(row) for row in self._snapshot.get("regions") or [] if isinstance(row, dict)
            ]
            areas = [
                dict(row) for row in self._snapshot.get("areas") or [] if isinstance(row, dict)
            ]
            branches = [
                dict(row) for row in self._snapshot.get("branches") or [] if isinstance(row, dict)
            ]

            self._lazy_branches = len(branches) > self._lazy_branch_threshold
            branches_by_area: dict[str, list[dict[str, Any]]] = defaultdict(list)
            for row in branches:
                area_id = clean_text(row.get("area_id"))
                if area_id:
                    branches_by_area[area_id].append(row)
                branch_id = clean_text(row.get("branch_id"))
                if branch_id:
                    self._labels[("branch", branch_id)] = clean_text(row.get("name")) or branch_id
            self._branches_by_area = {
                area_id: list(rows) for area_id, rows in branches_by_area.items()
            }
            self._area_items = {}

            organization_items: dict[str, QTreeWidgetItem] = {}
            region_items: dict[str, QTreeWidgetItem] = {}
            area_items: dict[str, QTreeWidgetItem] = {}

            # Structure rows are already server-filtered.  Never infer authority
            # from a missing parent or synthesize a hierarchy locally.
            for row in sorted(
                organizations,
                key=lambda value: clean_text(value.get("organization_id")),
            ):
                ident = clean_text(row.get("organization_id"))
                if ident:
                    organization_items[ident] = self._make_item(
                        None,
                        "organization",
                        ident,
                        clean_text(row.get("name")) or ident,
                    )

            for row in sorted(regions, key=lambda value: clean_text(value.get("region_id"))):
                ident = clean_text(row.get("region_id"))
                if not ident:
                    continue
                parent = organization_items.get(clean_text(row.get("organization_id")))
                region_items[ident] = self._make_item(
                    parent,
                    "region",
                    ident,
                    clean_text(row.get("name")) or ident,
                )

            for row in sorted(areas, key=lambda value: clean_text(value.get("area_id"))):
                ident = clean_text(row.get("area_id"))
                if not ident:
                    continue
                parent = region_items.get(clean_text(row.get("region_id")))
                area_item = self._make_item(
                    parent,
                    "area",
                    ident,
                    clean_text(row.get("name")) or ident,
                )
                area_items[ident] = area_item
                self._area_items[ident] = area_item
                if self._lazy_branches and self._branches_by_area.get(ident):
                    placeholder = QTreeWidgetItem([_("Expand to load branches")])
                    placeholder.setData(0, Qt.UserRole, {"type": "_placeholder", "id": ident})
                    placeholder.setFlags(Qt.NoItemFlags)
                    area_item.addChild(placeholder)
                else:
                    self._add_branches(area_item, ident)

            self._sync_states()
        finally:
            self._syncing = False

    def _add_branches(
        self,
        area_item: QTreeWidgetItem,
        area_id: str,
        *,
        needle: str = "",
    ) -> None:
        existing = {
            clean_text((area_item.child(index).data(0, Qt.UserRole) or {}).get("id"))
            for index in range(area_item.childCount())
            if str((area_item.child(index).data(0, Qt.UserRole) or {}).get("type") or "")
            == "branch"
        }
        for row in sorted(
            self._branches_by_area.get(area_id, []),
            key=lambda value: clean_text(value.get("branch_id")),
        ):
            ident = clean_text(row.get("branch_id"))
            label = clean_text(row.get("name")) or ident
            if not ident or ident in existing:
                continue
            if needle and needle not in f"{label} {ident}".casefold():
                continue
            self._make_item(area_item, "branch", ident, label)

    def _populate_area(self, item: QTreeWidgetItem) -> None:
        if not self._lazy_branches:
            return
        data = item.data(0, Qt.UserRole) or {}
        if str(data.get("type") or "") != "area":
            return
        if self._has_placeholder(item):
            item.takeChild(0)
            self._add_branches(item, clean_text(data.get("id")))
            self._sync_states()

    @staticmethod
    def _has_placeholder(item: QTreeWidgetItem) -> bool:
        if item.childCount() != 1:
            return False
        data = item.child(0).data(0, Qt.UserRole) or {}
        return str(data.get("type") or "") == "_placeholder"

    def _raw_branch_match(self, item: QTreeWidgetItem, needle: str) -> bool:
        if not self._lazy_branches or not needle:
            return False
        data = item.data(0, Qt.UserRole) or {}
        if str(data.get("type") or "") != "area":
            return False
        area_id = clean_text(data.get("id"))
        return any(
            needle
            in (
                f"{clean_text(row.get('name')) or clean_text(row.get('branch_id'))} "
                f"{clean_text(row.get('branch_id'))}"
            ).casefold()
            for row in self._branches_by_area.get(area_id, [])
        )

    def _populate_matching_area(self, item: QTreeWidgetItem, needle: str) -> None:
        if not self._raw_branch_match(item, needle):
            return
        data = item.data(0, Qt.UserRole) or {}
        area_id = clean_text(data.get("id"))
        if self._has_placeholder(item):
            item.takeChild(0)
        self._add_branches(item, area_id, needle=needle)
        self._sync_states()

    def _walk(self) -> Iterator[QTreeWidgetItem]:
        queue = [self.tree.topLevelItem(index) for index in range(self.tree.topLevelItemCount())]
        while queue:
            item = queue.pop(0)
            yield item
            queue[0:0] = [item.child(index) for index in range(item.childCount())]

    def _descendant_allowed_keys(self, item: QTreeWidgetItem) -> set[tuple[str, str]]:
        keys: set[tuple[str, str]] = set()
        data = item.data(0, Qt.UserRole) or {}
        if (
            self._lazy_branches
            and str(data.get("type") or "") == "area"
            and "branch" in self._allowed
        ):
            area_id = clean_text(data.get("id"))
            keys.update(
                ("branch", branch_id)
                for branch_id in (
                    clean_text(row.get("branch_id"))
                    for row in self._branches_by_area.get(area_id, [])
                )
                if branch_id
            )

        for index in range(item.childCount()):
            child = item.child(index)
            child_data = child.data(0, Qt.UserRole) or {}
            kind = str(child_data.get("type") or "")
            ident = clean_text(child_data.get("id"))
            if kind in self._allowed and ident:
                keys.add((kind, ident))
            keys.update(self._descendant_allowed_keys(child))
        return keys

    def _descendant_selection_state(self, item: QTreeWidgetItem) -> int:
        keys = self._descendant_allowed_keys(item)
        if not keys:
            return Qt.Unchecked
        selected_count = len(keys.intersection(self._selected))
        if selected_count == 0:
            return Qt.Unchecked
        if selected_count == len(keys):
            return Qt.Checked
        return Qt.PartiallyChecked

    def _sync_states(self) -> None:
        previous = self._syncing
        self._syncing = True
        try:
            for item in reversed(list(self._walk())):
                data = item.data(0, Qt.UserRole) or {}
                kind = str(data.get("type") or "")
                ident = clean_text(data.get("id"))
                key = (kind, ident)
                enabled = kind in self._allowed
                item.setDisabled(not enabled)
                if key in self._selected:
                    state = Qt.Checked
                else:
                    descendants = self._descendant_selection_state(item)
                    state = (
                        Qt.PartiallyChecked
                        if enabled and descendants != Qt.Unchecked
                        else descendants
                    )
                item.setCheckState(0, state)
        finally:
            self._syncing = previous

    def _item_changed(self, item: QTreeWidgetItem, _column: int) -> None:
        if self._syncing:
            return
        data = item.data(0, Qt.UserRole) or {}
        kind = str(data.get("type") or "")
        ident = clean_text(data.get("id"))
        if kind not in self._allowed or not ident:
            return
        key = (kind, ident)
        if item.checkState(0) == Qt.Checked:
            self._selected.add(key)
        else:
            self._selected.discard(key)
        self._sync_states()
        self._update_summary()
        self.selection_changed.emit(self.selected_assignments())

    def selected_assignments(self) -> list[dict[str, str]]:
        order = {kind: index for index, kind in enumerate(KINDS)}
        return [
            {"scope_type": kind, "scope_id": ident}
            for kind, ident in sorted(
                self._selected,
                key=lambda value: (order.get(value[0], 99), value[1]),
            )
        ]

    def selected_ids(self) -> list[str]:
        return [f"{row['scope_type']}:{row['scope_id']}" for row in self.selected_assignments()]

    def set_selected_assignments(self, values: Iterable[dict[str, str]]) -> None:
        self._selected = {
            (str(row.get("scope_type")), str(row.get("scope_id")))
            for row in values or []
            if isinstance(row, dict)
            and str(row.get("scope_type")) in self._allowed
            and str(row.get("scope_id") or "").strip()
        }
        self._sync_states()
        self._update_summary()
        self.selection_changed.emit(self.selected_assignments())

    def labels_for_assignments(self, values: Iterable[dict[str, str]]) -> list[str]:
        return [
            (
                f"{row.get('scope_type')}: "
                f"{self._labels.get((str(row.get('scope_type')), str(row.get('scope_id'))), str(row.get('scope_id')))}"
            )
            for row in values or []
        ]

    @staticmethod
    def labels_for_ids(values: Iterable[str]) -> list[str]:
        return [str(value) for value in values]

    def _filter(self) -> None:
        needle = self.search.text().strip().casefold()

        def visit(item: QTreeWidgetItem) -> bool:
            if needle:
                self._populate_matching_area(item, needle)
            own_match = (
                needle in item.text(0).casefold() or self._raw_branch_match(item, needle)
                if needle
                else True
            )
            child_match = False
            for index in range(item.childCount()):
                child_match = visit(item.child(index)) or child_match
            visible = own_match or child_match
            item.setHidden(not visible)
            if needle and visible:
                item.setExpanded(True)
            return visible

        for index in range(self.tree.topLevelItemCount()):
            visit(self.tree.topLevelItem(index))

    def _select_visible(self) -> None:
        selected = set(self._selected)
        for item in self._walk():
            if item.isHidden():
                continue
            data = item.data(0, Qt.UserRole) or {}
            kind = str(data.get("type") or "")
            ident = clean_text(data.get("id"))
            if kind in self._allowed and ident:
                selected.add((kind, ident))
        self.set_selected_assignments(
            [{"scope_type": kind, "scope_id": ident} for kind, ident in selected]
        )

    def _update_summary(self) -> None:
        counts: dict[str, int] = defaultdict(int)
        for kind, _scope_id in self._selected:
            counts[kind] += 1
        labels = {
            "organization": _("Organizations"),
            "region": _("Regions"),
            "area": _("Areas"),
            "branch": _("Branches"),
        }
        parts = [f"{counts[kind]} {labels[kind]}" for kind in KINDS if counts[kind]]
        selection_text = " • ".join(parts) if parts else _("No direct scope selected")
        self.summary.setText(
            selection_text
            + "\n"
            + _(
                "Parent scope inheritance is calculated by the server in effective scope; direct parent selections are not expanded into child assignments."
            )
        )


class SplitWorkspace(QWidget):
    """A fluid master-detail workspace with a centralized component constraint."""

    compactChanged = Signal(bool)

    def __init__(self, collection: QWidget, details: QWidget, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminSplitWorkspace")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.splitter = QSplitter(Qt.Horizontal, self)
        self.splitter.setObjectName("AdminMasterDetailSplitter")
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(6)
        collection.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        # A dense account table needs a meaningful minimum footprint before
        # the inspector is allowed to consume its preferred width.  Qt can
        # then retain the desktop arrangement with internal scrolling when
        # either pane becomes narrower than its content.
        collection.setMinimumWidth(360)
        details.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        details.setMinimumWidth(ADMIN_INSPECTOR_MIN_WIDTH)
        details.setMaximumWidth(ADMIN_INSPECTOR_MAX_WIDTH)
        self.collection_host = self._scroll_host(collection)
        self.details_host = self._scroll_host(details)
        self.splitter.addWidget(self.collection_host)
        self.splitter.addWidget(self.details_host)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        layout.addWidget(self.splitter)
        self._initial_ratio_applied = False

    def _scroll_host(self, widget: QWidget) -> QScrollArea:
        """Keep dense Designer content usable when a user narrows either pane."""
        host = QScrollArea(self.splitter)
        host.setFrameShape(QFrame.NoFrame)
        host.setWidgetResizable(True)
        host.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        host.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        host.setMinimumSize(0, 0)
        host.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        host.setWidget(widget)
        return host

    def showEvent(self, event) -> None:
        super().showEvent(event)
        if not self._initial_ratio_applied:
            self._apply_initial_ratio()

    def _apply_initial_ratio(self) -> None:
        if self._initial_ratio_applied:
            return
        total = max(0, self.splitter.width() - self.splitter.handleWidth())
        if total <= 0:
            return
        details_size = min(
            ADMIN_INSPECTOR_MAX_WIDTH,
            max(ADMIN_INSPECTOR_MIN_WIDTH, ADMIN_INSPECTOR_PREFERRED_WIDTH),
        )
        collection_size = max(0, total - details_size)
        if collection_size < 360:
            return
        self.splitter.setSizes([collection_size, details_size])
        self._initial_ratio_applied = True

    def set_compact(self, compact: bool) -> None:
        """Stack the retained inspector below the table on narrow workspaces."""
        compact = bool(compact)
        if getattr(self, "_compact", None) == compact:
            return
        changed = compact != bool(getattr(self, "_compact", False))
        self._compact = compact
        self.splitter.setOrientation(Qt.Vertical if compact else Qt.Horizontal)
        self.details_host.setVisible(True)
        self.splitter.setHandleWidth(6)
        details_widget = self.details_host.widget()
        if compact:
            # The inspector remains part of the page: no modal dialog, lost
            # selection, or inaccessible details when a window is narrowed.
            self.details_host.setMinimumWidth(0)
            self.details_host.setMaximumWidth(QT_WIDGET_SIZE_MAX)
            self.details_host.setMinimumHeight(220)
            details_widget.setMinimumWidth(0)
            details_widget.setMaximumWidth(QT_WIDGET_SIZE_MAX)
            details_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            self.splitter.setSizes([max(260, self.height() - 260), 250])
        else:
            self.details_host.setMinimumHeight(0)
            self.details_host.setMinimumWidth(ADMIN_INSPECTOR_MIN_WIDTH)
            self.details_host.setMaximumWidth(ADMIN_INSPECTOR_MAX_WIDTH)
            details_widget.setMinimumWidth(ADMIN_INSPECTOR_MIN_WIDTH)
            details_widget.setMaximumWidth(ADMIN_INSPECTOR_MAX_WIDTH)
            details_widget.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
            self._initial_ratio_applied = False
            self._apply_initial_ratio()
        if changed:
            self.compactChanged.emit(compact)

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        orientation = "landscape" if self.width() >= self.height() else "portrait"
        self.set_compact(not supports_admin_master_detail(self.width(), orientation))


__all__ = ["SplitWorkspace"]


class _ReadinessRow(QFrame):
    def __init__(self, title: str, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminDeleteReadinessRow")
        controls = load_ui(
            self,
            "admin_readiness_row",
            required=(
                "AdminDeleteReadinessMarker",
                "AdminDeleteReadinessTitle",
                "AdminDeleteReadinessValue",
            ),
        )
        self.marker: QLabel = controls["AdminDeleteReadinessMarker"]
        self.title: QLabel = controls["AdminDeleteReadinessTitle"]
        self.value: QLabel = controls["AdminDeleteReadinessValue"]
        self.title.setText(title)
        self.marker.setAlignment(Qt.AlignCenter)
        self.value.setAlignment(Qt.AlignLeft | Qt.AlignTop)

    def set_state(self, ok: bool, value: str) -> None:
        self.setProperty("ready", bool(ok))
        self.marker.setText("✓" if ok else "!")
        self.value.setText(value)
        for widget in (self, self.marker, self.title, self.value):
            widget.style().unpolish(widget)
            widget.style().polish(widget)
            widget.update()


class StructureDetailsView(QFrame):
    """One server-authoritative structure dashboard without tab duplication."""

    edit_requested = Signal()
    move_requested = Signal()
    delete_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminStructureDetailsView")
        self._snapshot: dict[str, Any] = {}
        self._kind = ""
        self._ident = ""
        self._row: dict[str, Any] = {}
        self._context: dict[str, str] = {}
        self._delete_ready = False

        controls = load_ui(
            self,
            "admin_structure_details",
            required=(
                "AdminStructureEntityIcon",
                "AdminStructureEntityTitle",
                "AdminStructureStatusBadge",
                "AdminStructureEntityBreadcrumb",
                "AdminStructureEditButton",
                "AdminStructureMoveButton",
                "AdminStructureDeleteButton",
                "AdminStructureEntityHeader_layout",
                "AdminStructureInfoCard",
                "AdminStructureInfoHost",
                "admin_structure_info_grid",
                "AdminDeletionReadinessCard",
                "AdminDeletionReadinessSummary",
                "admin_readiness_permission_host",
                "admin_readiness_children_host",
                "admin_readiness_users_host",
                "AdminStructureDeletePrimaryButton",
                "AdminStructureAssignedTable",
                "AdminStructureRelatedTable",
                "AdminStructureActivityTable",
                "admin_structure_dashboard_grid",
            ),
        )
        self.entity_icon: QLabel = controls["AdminStructureEntityIcon"]
        self.title: QLabel = controls["AdminStructureEntityTitle"]
        self.status: QLabel = controls["AdminStructureStatusBadge"]
        self.breadcrumb: QLabel = controls["AdminStructureEntityBreadcrumb"]
        self.entity_icon.setAlignment(Qt.AlignCenter)
        self.title.setText(_("Structure"))
        self.status.setText(_("Active"))
        self.edit: QPushButton = controls["AdminStructureEditButton"]
        self.move: QPushButton = controls["AdminStructureMoveButton"]
        self.delete: QPushButton = controls["AdminStructureDeleteButton"]
        self.header_grid: QGridLayout = controls["AdminStructureEntityHeader_layout"]
        self.identity: QWidget = self.findChild(QWidget, "admin_structure_identity")
        for button, caption, variant, slot in (
            (self.edit, _("Edit"), "secondary", self.edit_requested),
            (self.move, _("Move"), "secondary", self.move_requested),
            (self.delete, _("Remove"), "dangerPrimary", self.delete_requested),
        ):
            button.setText(caption)
            button.setProperty("variant", variant)
            button.clicked.connect(slot)
        self.dashboard_body = self.findChild(QWidget, "AdminStructureDashboardBody")
        self.dashboard_grid: QGridLayout = controls["admin_structure_dashboard_grid"]
        self.dashboard_grid.setColumnStretch(0, 3)
        self.dashboard_grid.setColumnStretch(1, 2)
        self.dashboard_grid.setRowStretch(0, 0)
        self.dashboard_grid.setRowStretch(1, 1)
        self.details_card: QFrame = controls["AdminStructureInfoCard"]
        self.info_title = self.findChild(QLabel, "AdminStructureInfoTitle")
        self.info_title.setText(_("Details"))
        self.info_host: QWidget = controls["AdminStructureInfoHost"]
        self.info_grid: QGridLayout = controls["admin_structure_info_grid"]
        self.info_grid.setColumnStretch(1, 1)
        self.readiness: QFrame = controls["AdminDeletionReadinessCard"]
        self.readiness_summary: QLabel = controls["AdminDeletionReadinessSummary"]
        for attribute, host_name, caption in (
            ("ready_permission", "admin_readiness_permission_host", _("Permission granted")),
            ("ready_children", "admin_readiness_children_host", _("Linked child structure")),
            ("ready_users", "admin_readiness_users_host", _("Linked users")),
        ):
            host = controls[host_name]
            row = _ReadinessRow(caption, host)
            host.layout().addWidget(row)
            setattr(self, attribute, row)
        self.delete_large: QPushButton = controls["AdminStructureDeletePrimaryButton"]
        self.delete_large.setText(_("Remove"))
        self.delete_large.setProperty("variant", "dangerPrimary")
        self.delete_large.clicked.connect(self.delete_requested)
        self.assigned_card = self.findChild(QFrame, "AdminStructureAssignedCard")
        self.related_card = self.findChild(QFrame, "AdminStructureRelatedCard")
        self.activity_card = self.findChild(QFrame, "AdminStructureActivityCard")
        self.findChild(QLabel, "AdminStructureAssignedTitle").setText(_("Assigned Users"))
        self.related_title = self.findChild(QLabel, "AdminStructureRelatedTitle")
        self.related_title.setText(_("Regions"))
        self.findChild(QLabel, "AdminStructureActivityTitle").setText(_("Activity Log"))
        self.assigned_table: QTableWidget = controls["AdminStructureAssignedTable"]
        self.related_table: QTableWidget = controls["AdminStructureRelatedTable"]
        self.activity_table: QTableWidget = controls["AdminStructureActivityTable"]
        self._configure_table(self.assigned_table, (_("User"), _("Role"), _("Status")))
        self._configure_table(
            self.related_table, (_("Name"), _("Context"), _("Status"), _("Updated"))
        )
        self._configure_table(self.activity_table, (_("Action"), _("User"), _("Date & Time")))
        # Keep the three peer data grids balanced. Their previous unrelated
        # 130/220/220 minimums made the lower grid dominate smaller work areas.
        grid_min_height = 32 + (3 * 28) + 16
        for table in (self.assigned_table, self.related_table, self.activity_table):
            table.setMinimumHeight(grid_min_height)

    def set_compact_mode(self, compact: bool) -> None:
        compact = bool(compact)
        if getattr(self, "_compact_header", None) == compact:
            return
        self._compact_header = compact

        for widget in (
            self.entity_icon,
            self.identity,
            self.edit,
            self.move,
            self.delete,
        ):
            self.header_grid.removeWidget(widget)

        if compact:
            self.header_grid.addWidget(self.entity_icon, 0, 0)
            self.header_grid.addWidget(self.identity, 0, 1, 1, 2)
            self.header_grid.addWidget(self.edit, 1, 0)
            self.header_grid.addWidget(self.move, 1, 1)
            self.header_grid.addWidget(self.delete, 1, 2)
            for column in range(3):
                self.header_grid.setColumnStretch(column, 1)
        else:
            self.header_grid.addWidget(self.entity_icon, 0, 0)
            self.header_grid.addWidget(self.identity, 0, 1)
            self.header_grid.addWidget(self.edit, 0, 2)
            self.header_grid.addWidget(self.move, 0, 3)
            self.header_grid.addWidget(self.delete, 0, 4)
            self.header_grid.setColumnStretch(0, 0)
            self.header_grid.setColumnStretch(1, 1)
            for column in (2, 3, 4):
                self.header_grid.setColumnStretch(column, 0)

    def _configure_table(self, table: QTableWidget, headers: tuple[str, ...]) -> None:
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(list(headers))
        for column, header_text in enumerate(headers):
            item = table.horizontalHeaderItem(column)
            if item is not None:
                item.setToolTip(str(header_text))
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setSelectionBehavior(QTableWidget.SelectRows)
        table.setSelectionMode(QTableWidget.SingleSelection)
        table.setAlternatingRowColors(True)
        table.verticalHeader().setVisible(False)
        table.verticalHeader().setDefaultSectionSize(32)
        header = table.horizontalHeader()
        header.setHighlightSections(False)
        header.setMinimumSectionSize(1)
        header.setStretchLastSection(False)
        table.setShowGrid(False)
        table.setWordWrap(False)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        for column in range(len(headers)):
            header.setSectionResizeMode(column, QHeaderView.Stretch)
        configure_sortable_table(table, enabled=True)

    def _clear_grid(self) -> None:
        while self.info_grid.count():
            item = self.info_grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()

    def _add_info_row(self, row_index: int, label: str, value: str) -> None:
        name = QLabel(label, self.info_host)
        name.setObjectName("AdminStructureFieldLabel")
        rendered = QLabel(value or "—", self.info_host)
        rendered.setObjectName("AdminStructureFieldValue")
        rendered.setTextInteractionFlags(Qt.TextSelectableByMouse)
        rendered.setWordWrap(True)
        self.info_grid.addWidget(name, row_index, 0)
        self.info_grid.addWidget(rendered, row_index, 1)

    def _lookup(self, kind: str, ident: str) -> dict[str, Any]:
        key = {"region": "regions", "area": "areas", "branch": "branches"}.get(
            kind, "organizations"
        )
        id_key = f"{kind}_id" if kind != "organization" else "organization_id"
        for row in self._snapshot.get(key) or []:
            if isinstance(row, dict) and clean_text(row.get(id_key)) == ident:
                return dict(row)
        return {}

    def _context_for(self, kind: str, ident: str, row: dict[str, Any]) -> dict[str, str]:
        result = {"organization": "", "region": "", "area": "", "branch": ""}
        if kind == "organization":
            result["organization"] = ident
        elif kind == "region":
            result.update(organization=clean_text(row.get("organization_id")), region=ident)
        elif kind == "area":
            rid = clean_text(row.get("region_id"))
            region = self._lookup("region", rid)
            result.update(
                organization=clean_text(region.get("organization_id")), region=rid, area=ident
            )
        elif kind == "branch":
            aid = clean_text(row.get("area_id"))
            area = self._lookup("area", aid)
            rid = clean_text(area.get("region_id"))
            region = self._lookup("region", rid)
            result.update(
                organization=clean_text(region.get("organization_id")),
                region=rid,
                area=aid,
                branch=ident,
            )
        return result

    def _linked_users(self, kind: str, ident: str) -> list[dict[str, Any]]:
        result = []
        for user in self._snapshot.get("users") or []:
            if not isinstance(user, dict):
                continue
            for assignment in AdministrationPresenter.user_direct_assignments(user):
                if assignment.get("scope_type") == kind and assignment.get("scope_id") == ident:
                    result.append(dict(user))
                    break
        return result

    def _manager_text(self, kind: str, ident: str) -> str:
        role = {
            "region": "operations_manager",
            "area": "operations_consultant",
            "branch": "store_manager",
        }.get(kind, "")
        if not role:
            return "—"
        names = []
        for user in self._linked_users(kind, ident):
            if normalize_role(clean_text(user.get("role"))) != role:
                continue
            label = clean_text(user.get("display_name")) or clean_text(user.get("username"))
            if label:
                names.append(label)
        return ", ".join(sorted(set(names))) or "—"

    def _child_rows(self) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        if self._kind == "organization":
            regions = [
                dict(x)
                for x in self._snapshot.get("regions") or []
                if isinstance(x, dict) and clean_text(x.get("organization_id")) == self._ident
            ]
            return regions, []
        if self._kind == "region":
            areas = [
                dict(x)
                for x in self._snapshot.get("areas") or []
                if isinstance(x, dict) and clean_text(x.get("region_id")) == self._ident
            ]
            area_ids = {clean_text(x.get("area_id")) for x in areas}
            branches = [
                dict(x)
                for x in self._snapshot.get("branches") or []
                if isinstance(x, dict) and clean_text(x.get("area_id")) in area_ids
            ]
            return areas, branches
        if self._kind == "area":
            branches = [
                dict(x)
                for x in self._snapshot.get("branches") or []
                if isinstance(x, dict) and clean_text(x.get("area_id")) == self._ident
            ]
            return [], branches
        return [], []

    def _breadcrumb_text(self) -> str:
        parts = []
        for key in ("organization", "region", "area", "branch"):
            value = clean_text(self._context.get(key))
            if value:
                parts.append(value)
        return "   ›   ".join(parts)

    def set_entity(
        self,
        snapshot: dict[str, Any],
        kind: str,
        ident: str,
        row: dict[str, Any],
        *,
        can_edit: bool,
        can_move: bool,
        can_delete: bool,
    ) -> None:
        self._snapshot = dict(snapshot or {})
        self._kind = str(kind or "")
        self._ident = str(ident or "")
        self._row = dict(row or {})
        self._context = self._context_for(self._kind, self._ident, self._row)

        title = clean_text(self._row.get("name")) or self._ident
        self.title.setText(title)
        active = bool(self._row.get("is_active", True))
        self.status.setText(_("Active") if active else _("Disabled"))
        self.status.setProperty("active", active)
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.breadcrumb.setText(self._breadcrumb_text())
        self.entity_icon.setProperty("entityKind", self._kind)
        self.entity_icon.style().unpolish(self.entity_icon)
        self.entity_icon.style().polish(self.entity_icon)

        self.edit.setVisible(self._kind != "organization")
        self.edit.setEnabled(bool(can_edit))
        self.move.setVisible(self._kind == "branch")
        self.move.setEnabled(bool(can_move))
        self.delete.setVisible(self._kind != "organization")
        self.delete.setEnabled(bool(can_delete))

        self._render_info()
        self._render_assigned_users()
        self._render_related()
        self._render_activity()
        self._render_deletion_readiness(bool(can_delete))

    def set_action_permissions(self, *, can_edit: bool, can_move: bool, can_delete: bool) -> None:
        self.edit.setVisible(self._kind != "organization")
        self.edit.setEnabled(bool(can_edit))
        self.move.setVisible(self._kind == "branch")
        self.move.setEnabled(bool(can_move))
        self.delete.setVisible(self._kind != "organization")
        self.delete.setEnabled(bool(can_delete))
        self._render_deletion_readiness(bool(can_delete))

    def _render_info(self) -> None:
        self._clear_grid()
        self.info_title.setText(_("Details"))
        rows: list[tuple[str, str]] = [
            (_("Code"), self._ident),
            (_("Name"), clean_text(self._row.get("name")) or self._ident),
            (
                _("Type"),
                {
                    "organization": _("Organization"),
                    "region": _("Region"),
                    "area": _("Area"),
                    "branch": _("Branch"),
                }.get(self._kind, _("Structure")),
            ),
            (_("Status"), _("Active") if self._row.get("is_active", True) else _("Disabled")),
        ]
        if self._kind == "region":
            rows.append((_("Manager"), self._manager_text("region", self._ident)))
        elif self._kind == "area":
            rows.append((_("Manager"), self._manager_text("area", self._ident)))
        elif self._kind == "branch":
            rows.append((_("Manager"), self._manager_text("branch", self._ident)))
        created = format_display_datetime(self._row.get("created_at"), fallback="")
        updated = format_display_datetime(
            self._row.get("updated_at") or self._row.get("modified_at"), fallback=""
        )
        if created:
            rows.append((_("Created"), created))
        if updated:
            rows.append((_("Last Update"), updated))
        for index, (label, value) in enumerate(rows):
            self._add_info_row(index, label, value)

    def _render_assigned_users(self) -> None:
        users = self._linked_users(self._kind, self._ident)
        sorting_enabled = self.assigned_table.isSortingEnabled()
        self.assigned_table.setSortingEnabled(False)
        self.assigned_table.setRowCount(len(users))
        for row_index, user in enumerate(users):
            values = (
                clean_text(user.get("display_name")) or clean_text(user.get("username")),
                AdministrationPresenter.role_label(clean_text(user.get("role"))),
                _("Active") if user.get("is_active", True) else _("Disabled"),
            )
            for column, value in enumerate(values):
                self.assigned_table.setItem(row_index, column, QTableWidgetItem(value))
        self.assigned_table.setSortingEnabled(sorting_enabled)

    def _render_related(self) -> None:
        rows: list[tuple[str, str, str, str]] = []
        first, second = self._child_rows()
        related_kind = "region"
        related_label = _("Regions")
        values = first
        if self._kind == "region":
            related_kind = "branch"
            related_label = _("Branches")
            values = second
        elif self._kind == "area":
            related_kind = "branch"
            related_label = _("Branches")
            values = second
        elif self._kind == "branch":
            related_label = _("Products")
            values = []
        self.related_title.setText(related_label)

        id_key = f"{related_kind}_id"
        for item in values:
            ident = clean_text(item.get(id_key))
            rows.append(
                (
                    clean_text(item.get("name")) or ident,
                    " · ".join(
                        (
                            _("Region") if related_kind == "region" else _("Branch"),
                            ident,
                        )
                    ),
                    " · ".join(
                        (
                            _("Active") if item.get("is_active", True) else _("Disabled"),
                            _("{count} users").format(
                                count=len(self._linked_users(related_kind, ident))
                            ),
                        )
                    ),
                    format_display_datetime(
                        item.get("updated_at") or item.get("modified_at"), fallback="—"
                    ),
                )
            )
        sorting_enabled = self.related_table.isSortingEnabled()
        self.related_table.setSortingEnabled(False)
        self.related_table.setRowCount(len(rows))
        for row_index, values in enumerate(rows):
            for column, value in enumerate(values):
                self.related_table.setItem(row_index, column, QTableWidgetItem(value))
        self.related_table.setSortingEnabled(sorting_enabled)

    def _render_activity(self) -> None:
        events = []
        for event in self._snapshot.get("audit_events") or []:
            if not isinstance(event, dict):
                continue
            target_type = clean_text(event.get("target_type")).rstrip("s").lower()
            target_id = clean_text(event.get("target_id"))
            if target_type == self._kind and target_id == self._ident:
                events.append(dict(event))
        events.sort(key=lambda row: clean_text(row.get("created_at")), reverse=True)
        events = events[:8]
        sorting_enabled = self.activity_table.isSortingEnabled()
        self.activity_table.setSortingEnabled(False)
        self.activity_table.setRowCount(len(events))
        for row_index, event in enumerate(events):
            values = (
                clean_text(event.get("action")) or "—",
                clean_text(event.get("actor_user_id")) or "—",
                format_display_datetime(event.get("created_at"), fallback="—"),
            )
            for column, value in enumerate(values):
                self.activity_table.setItem(row_index, column, QTableWidgetItem(value))
        self.activity_table.setSortingEnabled(sorting_enabled)

    def _render_deletion_readiness(self, can_delete: bool) -> None:
        permission_ok = bool(can_delete)
        if self._kind not in {"region", "area"}:
            self.readiness.hide()
            self.delete.setEnabled(permission_ok if self._kind == "branch" else False)
            return

        self.readiness.show()
        first, second = self._child_rows()
        children = first if self._kind == "region" else second
        linked = self._linked_users(self._kind, self._ident)
        blocked_users = []
        detachable_users = []
        for user in linked:
            assignments = AdministrationPresenter.user_direct_assignments(user)
            if normalize_role(clean_text(user.get("role"))) == "system" or len(assignments) > 1:
                detachable_users.append(user)
            else:
                blocked_users.append(user)

        children_ok = not children
        users_ok = not blocked_users
        self._delete_ready = permission_ok and children_ok and users_ok
        self.ready_permission.set_state(
            permission_ok,
            (
                _("You have permission to remove this item")
                if permission_ok
                else _("Delete permission is not granted")
            ),
        )
        child_label = (
            _("0 areas")
            if self._kind == "region" and children_ok
            else (
                _("0 branches")
                if self._kind == "area" and children_ok
                else _(
                    "{count} linked child item(s) will be preserved under the disabled parent"
                ).format(count=len(children))
            )
        )
        self.ready_children.set_state(children_ok, child_label)
        if blocked_users:
            users_label = _("{count} user(s) require this item as their last direct scope").format(
                count=len(blocked_users)
            )
        elif detachable_users:
            users_label = _(
                "{count} linked user scope(s) will be detached on permanent deletion"
            ).format(count=len(detachable_users))
        else:
            users_label = _("0 linked users")
        self.ready_users.set_state(users_ok, users_label)

        if not permission_ok:
            summary = _("Delete permission is not granted")
        elif self._delete_ready:
            summary = _("{id} is ready for permanent deletion.").format(id=self._ident)
        else:
            summary = _(
                "{id} has dependencies; Remove will disable it and preserve linked hierarchy/scopes."
            ).format(id=self._ident)
        self.readiness_summary.setText(summary)
        self.readiness_summary.setProperty("ready", self._delete_ready)
        self.readiness_summary.style().unpolish(self.readiness_summary)
        self.readiness_summary.style().polish(self.readiness_summary)
        self.delete.setEnabled(permission_ok)
        self.delete_large.setEnabled(permission_ok)
        self.delete_large.setText(_("Remove {id}").format(id=self._ident))


class AdministrationWorkspaceHeader(QFrame):
    """Single operational toolbar for the Administration workspace."""

    refresh_requested = Signal()
    route_requested = Signal(str)

    _ROUTE_COPY = {
        "overview": (
            "Administration workspace",
            "Live organization health, authority and operational activity.",
        ),
        "structure": (
            "Organization structure",
            "Explore regions, areas and branches with their operational context.",
        ),
        "employees": (
            "People and roles",
            "Review employee identities, authority, direct scopes and account security.",
        ),
        "branch_accounts": (
            "Branch accounts",
            "Review branch-linked identities and their operating scope.",
        ),
        "assignments": (
            "Scope assignments",
            "Manage direct scope assignments with server-authorized controls.",
        ),
        "permissions": (
            "Permission catalogue",
            "Review role permissions and effective administrative access.",
        ),
        "catalogs": (
            "Product catalogs",
            "Maintain the server-authorized products used by tracking and usage.",
        ),
        "audit": ("Audit trail", "Trace administrative actions and recent changes."),
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdministrationWorkspaceHeader")

        controls = load_ui(
            self,
            "administration_header",
            required=(
                "AdminWorkspaceRouteHint",
                "AdminWorkspaceStateBadge",
                "AdminWorkspaceActivity",
                "AdminWorkspaceRefresh",
                "AdminWorkspaceRouteSelector",
            ),
        )
        self.page_toolbar: QWidget = self
        self.page_toolbar.setProperty("uiRole", "standardToolbar")
        self.layout().setSpacing(UI_METRICS.toolbar_horizontal_gap)
        self.state_badge: QLabel = controls["AdminWorkspaceStateBadge"]
        self.activity: QLabel = controls["AdminWorkspaceActivity"]
        self.refresh: QPushButton = controls["AdminWorkspaceRefresh"]
        self._busy = False
        self._compact = False
        self.route_selector: QComboBox = controls["AdminWorkspaceRouteSelector"]
        self.route_hint: QLabel = controls["AdminWorkspaceRouteHint"]
        self.route_hint.setProperty("textRole", "mutedStatus")
        self.route_selector.setAccessibleName(_("Administration section"))
        self.route_selector.setToolTip(_("Administration section"))
        self.route_selector.setMinimumWidth(0)
        self.route_selector.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.route_selector.show()
        apply_toolbar_control_metrics(
            self.page_toolbar,
            (self.route_selector, self.activity, self.refresh),
            self.page_toolbar.width(),
        )
        self.route_selector.currentIndexChanged.connect(self._route_selector_changed)
        self.state_badge.setText(_("Live data"))
        self.activity.hide()
        self.refresh.setText(_("Refresh data"))
        self.refresh.setProperty("variant", "secondary")
        self.refresh.clicked.connect(self.refresh_requested)
        # The authority workspace is reconciled from the server's realtime
        # stream and automatic fallback pull.  Do not present a manual refresh
        # action as a required part of normal operation.
        self.refresh.hide()

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        apply_toolbar_control_metrics(
            self.page_toolbar,
            (self.route_selector, self.activity, self.refresh),
            self.page_toolbar.width(),
        )

    def set_modules(self, modules, current: str = "") -> None:
        current_route = str(current or "")
        self.route_selector.blockSignals(True)
        try:
            self.route_selector.clear()
            for route in modules or ():
                route_key = str(route or "").strip()
                if not route_key:
                    continue
                self.route_selector.addItem(
                    AdministrationPresenter.module_label(route_key),
                    route_key,
                )
            index = self.route_selector.findData(current_route)
            if index >= 0:
                self.route_selector.setCurrentIndex(index)
        finally:
            self.route_selector.blockSignals(False)
        self.route_selector.setVisible(bool(self.route_selector.count()))

    def set_compact(self, compact: bool) -> None:
        self._compact = bool(compact)
        self.route_selector.setVisible(bool(self.route_selector.count()))
        self.activity.setVisible(bool(self.activity.text().strip()) and not compact)
        self.route_hint.setVisible(not self._compact)
        root_layout = self.layout()
        if root_layout is None:
            raise RuntimeError("AdministrationWorkspaceHeader must have a Designer-owned layout")
        root_layout.invalidate()
        root_layout.activate()

    def _route_selector_changed(self, index: int) -> None:
        route = str(self.route_selector.itemData(index) or "").strip()
        if route:
            self.route_requested.emit(route)

    def set_route(self, route: str) -> None:
        active = str(route or "")
        self.route_hint.setText(_(AdministrationPresenter.module_label(active)))
        index = self.route_selector.findData(active)
        if index >= 0 and index != self.route_selector.currentIndex():
            self.route_selector.blockSignals(True)
            try:
                self.route_selector.setCurrentIndex(index)
            finally:
                self.route_selector.blockSignals(False)

    def set_busy(self, busy: bool, text: str = "") -> None:
        active = bool(busy)
        self._busy = active
        self.activity.setText(str(text or _("Working...")) if active else "")
        self.activity.setVisible(active and not self._compact)
        self.refresh.setEnabled(not active)
        if active:
            self.state_badge.setText(_("Syncing"))
            self.state_badge.setProperty("state", "busy")
            refresh_widget_style(self.state_badge)
        else:
            self.set_online(self.property("online") is not False)

    def set_online(self, online: bool) -> None:
        self.refresh.setEnabled(not self._busy)
        self.setProperty("online", bool(online))
        self.state_badge.setText(_("Live data") if online else _("Offline cache"))
        self.state_badge.setProperty("state", "online" if online else "offline")
        refresh_widget_style(self.state_badge)


# Administration editors


def _key(row: dict[str, str]) -> tuple[str, str]:
    return (
        str(row.get("scope_type") or ""),
        str(row.get("scope_id") or ""),
    )


def submit_reviewed_assignments(
    parent,
    controller,
    targets,
    assignments,
) -> str:
    """Start one user's direct-scope replacement and return its server id.

    The deployed server exposes only a per-user replacement contract.  Do not
    emulate a batch mutation with a client-side HTTP loop because that would
    lose transaction semantics and can leave a partially applied assignment.
    """
    rows = [dict(item) for item in targets or [] if isinstance(item, dict)]
    if len(rows) != 1:
        show_warning_message(
            parent,
            _("Assignments"),
            _(
                "Select exactly one employee. Multi-user assignment changes require a server batch contract and are not applied user by user."
            ),
        )
        return ""
    uid = str(rows[0].get("user_id") or "").strip()
    if not uid:
        show_warning_message(
            parent,
            _("Assignments"),
            _("The selected employee has no server user identifier."),
        )
        return ""
    worker = controller.apply_assignments(rows, list(assignments or []))
    return uid if worker is not None else ""


class AssignmentEditorDialog(QFrame):
    apply_requested = Signal(object, object)
    cancel_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminAssignmentEditorPanel")
        self._target: dict[str, Any] | None = None
        self._snapshot: dict[str, Any] = {}
        self._initial: set[tuple[str, str]] = set()

        controls = load_ui(
            self,
            "admin_assignment_editor",
            required=(
                "admin_assignment_scope_host",
                "AdminScopeDiffText",
                "admin_assignment_cancel",
                "admin_assignment_apply",
            ),
        )
        self.findChild(QLabel, "admin_assignment_title").setText(_("Direct scope"))
        self.findChild(QLabel, "admin_assignment_diff_title").setText(_("Scope changes"))
        self.picker = ScopePicker(controls["admin_assignment_scope_host"])
        controls["admin_assignment_scope_host"].layout().addWidget(self.picker)
        self.diff: QLabel = controls["AdminScopeDiffText"]
        self.diff.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.cancel: QPushButton = controls["admin_assignment_cancel"]
        self.apply: QPushButton = controls["admin_assignment_apply"]
        self.cancel.setText(_("Cancel"))
        self.apply.setText(_("Apply"))
        self.cancel.setProperty("variant", "secondary")
        self.apply.setProperty("variant", "primary")

        self.cancel.clicked.connect(self.cancel_requested)
        self.apply.clicked.connect(self._emit_apply)
        self.picker.selection_changed.connect(self._update)

    def configure(
        self,
        snapshot: dict[str, Any],
        targets: list[dict[str, Any]],
    ) -> None:
        rows = [dict(item) for item in targets or [] if isinstance(item, dict)]
        if len(rows) != 1:
            self.setWindowTitle(_("Edit assignments"))
            self._target = None
            self._initial = set()
            self.picker.configure(snapshot, [])
            self.diff.setText(_("Select exactly one employee to edit direct scope."))
            self.apply.setEnabled(False)
            return

        self._snapshot = dict(snapshot or {})
        self._target = rows[0]
        assignments = AdministrationPresenter.user_direct_assignments(self._target)
        self._initial = {_key(item) for item in assignments}
        self.picker.configure(snapshot, assignments)
        identity = str(
            self._target.get("display_name")
            or self._target.get("username")
            or self._target.get("user_id")
            or ""
        ).strip()
        self.setWindowTitle(
            _("Edit assignments")
            if not identity
            else _("Edit assignments — {employee}").format(employee=identity)
        )
        self._update()

    def _emit_apply(self) -> None:
        if not self._target or not self.is_dirty():
            return
        self.apply_requested.emit(
            [dict(self._target)],
            self.picker.selected_assignments(),
        )

    def _diff_lines(self) -> list[str]:
        current = {_key(item) for item in self.picker.selected_assignments()}
        added = sorted(current - self._initial)
        removed = sorted(self._initial - current)
        lines: list[str] = []
        if added:
            lines.append("+ " + ", ".join(f"{kind}:{scope_id}" for kind, scope_id in added))
        if removed:
            lines.append("- " + ", ".join(f"{kind}:{scope_id}" for kind, scope_id in removed))
        return lines

    def _update(self, *_args) -> None:
        dirty = self.is_dirty()
        self.apply.setEnabled(bool(self._target and dirty))
        lines = self._diff_lines() if self._target else []
        self.diff.setText("\n".join(lines) if lines else _("No direct scope changes."))

    def is_dirty(self) -> bool:
        if not self._target:
            return False
        current = {_key(item) for item in self.picker.selected_assignments()}
        return current != self._initial

    def reject(self) -> None:
        self.cancel_requested.emit()


class StructureEditorDialog(QFrame):
    save_requested = Signal(str, dict)
    cancel_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminStructureEditorPanel")
        self._kind = ""
        self._original: dict[str, Any] = {}
        self._initial: dict[str, Any] = {}
        self._snapshot: dict[str, Any] = {}

        controls = load_ui(
            self,
            "admin_structure_editor",
            required=(
                "admin_structure_code",
                "admin_structure_name",
                "admin_structure_status",
                "admin_structure_parent",
                "admin_structure_cancel",
                "admin_structure_save",
            ),
        )
        self.code: QLineEdit = controls["admin_structure_code"]
        self.name: QLineEdit = controls["admin_structure_name"]
        self.status: QComboBox = controls["admin_structure_status"]
        self.parent_scope: QComboBox = controls["admin_structure_parent"]
        self.status.addItem(_("Active"), True)
        self.status.addItem(_("Disabled"), False)
        self._code_label = self.findChild(QLabel, "label_admin_structure_code")
        self._name_label = self.findChild(QLabel, "label_admin_structure_name")
        self._status_label = self.findChild(QLabel, "label_admin_structure_status")
        self._parent_label = self.findChild(QLabel, "label_admin_structure_parent")
        self.findChild(QLabel, "AdminEditorCardTitle").setText(_("Structure details"))
        self.cancel: QPushButton = controls["admin_structure_cancel"]
        self.save: QPushButton = controls["admin_structure_save"]
        self.cancel.setText(_("Cancel"))
        self.save.setText(_("Apply"))
        self.cancel.setProperty("variant", "secondary")
        self.save.setProperty("variant", "primary")

        self.cancel.clicked.connect(self.cancel_requested)
        self.save.clicked.connect(self._emit)
        self.code.textChanged.connect(self._sync_save_state)
        self.name.textChanged.connect(self._sync_save_state)
        self.status.currentIndexChanged.connect(self._sync_save_state)
        self.parent_scope.currentIndexChanged.connect(self._sync_save_state)

    @staticmethod
    def _organization_options(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
        return AdministrationPresenter.structure_organizations(snapshot)

    def configure(
        self,
        kind: str,
        snapshot: dict[str, Any],
        row: dict[str, Any] | None = None,
        *,
        parent_id: str = "",
    ) -> None:
        label = _(str(kind or "").replace("_", " ").title())
        self.setWindowTitle(
            _("Add {entity}").format(entity=label)
            if row is None
            else _("Edit {entity}").format(entity=label)
        )
        self._kind = str(kind or "")
        self._snapshot = dict(snapshot or {})
        self._original = dict(row or {})
        self.parent_scope.blockSignals(True)
        self.parent_scope.clear()

        id_key = f"{self._kind}_id"
        self.code.blockSignals(True)
        self.code.setText(str(self._original.get(id_key) or ""))
        self.code.setReadOnly(bool(row))
        self.code.blockSignals(False)
        self.name.blockSignals(True)
        self.name.setText(str(self._original.get("name") or ""))
        self.name.blockSignals(False)
        self.status.blockSignals(True)
        active_index = self.status.findData(bool(self._original.get("is_active", True)))
        self.status.setCurrentIndex(active_index if active_index >= 0 else 0)
        self.status.blockSignals(False)

        parent_key = {
            "region": "organization_id",
            "area": "region_id",
            "branch": "area_id",
        }.get(self._kind, "")
        if self._kind == "region":
            for item in self._organization_options(self._snapshot):
                ident = str(item.get("organization_id") or "").strip()
                if ident:
                    self.parent_scope.addItem(str(item.get("name") or ident), ident)
        elif self._kind == "area":
            for item in self._snapshot.get("regions") or []:
                if isinstance(item, dict):
                    ident = str(item.get("region_id") or "").strip()
                    if ident:
                        self.parent_scope.addItem(str(item.get("name") or ident), ident)
        elif self._kind == "branch":
            for item in self._snapshot.get("areas") or []:
                if isinstance(item, dict):
                    ident = str(item.get("area_id") or "").strip()
                    if ident:
                        self.parent_scope.addItem(str(item.get("name") or ident), ident)

        current = str(self._original.get(parent_key) or parent_id or "")
        index = self.parent_scope.findData(current)
        if current and index < 0:
            # The selected/recorded parent id is authoritative.  A partially
            # visible hierarchy must never make the combo silently fall back to
            # a different first parent and create/move under the wrong node.
            self.parent_scope.addItem(current, current)
            index = self.parent_scope.findData(current)
        self.parent_scope.setCurrentIndex(
            index if index >= 0 else (0 if self.parent_scope.count() else -1)
        )
        self.parent_scope.blockSignals(False)
        self.parent_scope.setVisible(bool(parent_key))
        # Parent selection is contextual, not a second hierarchy editor.  New
        # entities are created under the node selected in Structure, while
        # existing relationships are immutable in the generic edit form.
        # Branch movement has its own revision-aware transfer contract.
        self.parent_scope.setEnabled(
            self._kind != "region" and not bool(row) and not bool(parent_id)
        )
        parent_label = {
            "region": _("Organization"),
            "area": _("Region"),
            "branch": _("Area"),
        }.get(self._kind, _("Parent"))
        if self._code_label is not None:
            self._code_label.setText(_("Code"))
        if self._name_label is not None:
            self._name_label.setText(_("Name"))
        if self._status_label is not None:
            self._status_label.setText(_("Status"))
        if self._parent_label is not None:
            self._parent_label.setText(parent_label)
            self._parent_label.setVisible(bool(parent_key))

        self._initial = self.values()
        self._sync_save_state()

    def values(self) -> dict[str, Any]:
        code = self.code.text().strip()
        return {
            "code": code,
            "name": self.name.text().strip() or code,
            "is_active": bool(self.status.currentData()),
            "parent": str(self.parent_scope.currentData() or "").strip(),
        }

    def is_dirty(self) -> bool:
        return self.values() != self._initial

    def _sync_save_state(self, *_args) -> None:
        values = self.values()
        parent_required = self._kind in {"area", "branch"} and not bool(self._original)
        ready = bool(values["code"] and (values["parent"] or not parent_required))
        self.save.setEnabled(ready and self.is_dirty())

    def _emit(self) -> None:
        payload = self.values()
        if not payload["code"]:
            return
        if self._original:
            parent_key = {
                "region": "organization_id",
                "area": "region_id",
                "branch": "area_id",
            }.get(self._kind, "")
            payload["original_parent"] = str(self._original.get(parent_key) or "")
            payload["base_revision"] = int(self._original.get("revision") or 0)
        self.save_requested.emit(self._kind, payload)

    def reject(self) -> None:
        self.cancel_requested.emit()


class UserEditorDialog(QFrame):
    save_requested = Signal(dict)
    cancel_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminUserEditorPanel")
        self._snapshot: dict[str, Any] = {}
        self._original: dict[str, Any] | None = None

        controls = load_ui(
            self,
            "admin_user_editor",
            required=(
                "AdminEditorHeaderTitle",
                "AdminEditorHeaderSubtitle",
                "admin_user_name",
                "admin_display_name",
                "admin_role",
                "admin_password",
                "admin_user_scope_host",
                "AdminEditorHint",
                "admin_user_cancel",
                "admin_user_save",
            ),
        )
        self.editor_header = self.findChild(QFrame, "AdminEditorHeader")
        self.editor_title: QLabel = controls["AdminEditorHeaderTitle"]
        self.editor_subtitle: QLabel = controls["AdminEditorHeaderSubtitle"]
        self.scope_card = self.findChild(QFrame, "AdminEditorScopeCard")
        self.scope_hint: QLabel = controls["AdminEditorHint"]
        self.username: QLineEdit = controls["admin_user_name"]
        self.display_name: QLineEdit = controls["admin_display_name"]
        self.role: QComboBox = controls["admin_role"]
        self.password: QLineEdit = controls["admin_password"]
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setPlaceholderText(_("Temporary password"))
        self.scope = ScopePicker(controls["admin_user_scope_host"])
        controls["admin_user_scope_host"].layout().addWidget(self.scope)
        self.cancel: QPushButton = controls["admin_user_cancel"]
        self.save: QPushButton = controls["admin_user_save"]
        self.editor_title.setText(_("Employee profile"))
        self.findChild(QLabel, "AdminEditorCardTitle").setText(_("Account profile"))
        self.findChild(QLabel, "AdminUserScopeTitle").setText(_("Direct scope"))
        for key, caption in (
            ("admin_user_name", _("Username")),
            ("admin_display_name", _("Display name")),
            ("admin_role", _("Role")),
            ("admin_password", _("Initial password")),
        ):
            self.findChild(QLabel, "label_" + key).setText(caption)
        self.cancel.setText(_("Cancel"))
        self.save.setText(_("Apply"))
        self.cancel.setProperty("variant", "secondary")
        self.save.setProperty("variant", "primary")

        self.cancel.clicked.connect(self.cancel_requested)
        self.save.clicked.connect(self._emit_save)
        self.username.textChanged.connect(self._sync_save_state)
        self.display_name.textChanged.connect(self._sync_save_state)
        self.password.textChanged.connect(self._sync_save_state)
        self.role.currentIndexChanged.connect(self._sync_save_state)
        self.scope.selection_changed.connect(lambda _rows: self._sync_save_state())

    def configure(
        self,
        snapshot: dict[str, Any],
        user: dict[str, Any] | None = None,
        *,
        allowed_roles: list[str] | None = None,
    ) -> None:
        self.setWindowTitle(_("Add employee") if user is None else _("Edit employee"))
        self._snapshot = dict(snapshot or {})
        self._original = dict(user) if isinstance(user, dict) else None

        roles = (
            list(allowed_roles)
            if allowed_roles is not None
            else AdministrationPresenter.manageable_roles(snapshot)
        )
        existing = str((user or {}).get("role") or "")
        if existing and existing not in roles:
            roles.insert(0, existing)

        self.role.blockSignals(True)
        self.role.clear()
        for role in roles:
            self.role.addItem(AdministrationPresenter.role_label(role), role)
        self.role.blockSignals(False)

        self.username.blockSignals(True)
        self.username.setText(str((user or {}).get("username") or ""))
        self.username.setReadOnly(bool(user))
        self.username.blockSignals(False)
        self.display_name.blockSignals(True)
        self.display_name.setText(str((user or {}).get("display_name") or ""))
        self.display_name.blockSignals(False)
        self.password.clear()

        index = self.role.findData(existing)
        self.role.setCurrentIndex(index if index >= 0 else (0 if self.role.count() else -1))

        creating = not bool(user)
        self.editor_title.setText(_("Add employee") if creating else _("Edit employee"))
        self.editor_subtitle.setText(
            _("Create an account, role and initial direct scope.")
            if creating
            else _("Update identity and role without replacing the employee's direct scope.")
        )
        self.password.setVisible(creating)
        label = self.password.parentWidget().layout().labelForField(self.password)
        if label is not None:
            label.setVisible(creating)
        self.scope_card.setVisible(creating)

        if user:
            self.scope_hint.setText(
                _(
                    "Direct scopes are edited separately in Assignments so changing profile fields never silently replaces authority."
                )
            )
        else:
            self.scope.configure(snapshot, [])
            self.scope_hint.setText(
                _(
                    "Optional initial direct scopes. Mixed Region/Area/Branch assignments are accepted only when the server scope policy allows them."
                )
            )

        self._sync_save_state()

    def _emit_save(self) -> None:
        username = self.username.text().strip()
        role = str(self.role.currentData() or "")
        display = self.display_name.text().strip()
        if not username or not role:
            return

        payload: dict[str, Any] = {
            "username": username,
            "display_name": display or username,
            "role": role,
        }
        if self._original:
            payload["user_id"] = str(self._original.get("user_id") or "")
            payload["base_authority_revision"] = int(self._original.get("authority_revision") or 0)
        else:
            payload["assignments"] = self.scope.selected_assignments()
            password = self.password.text()
            if password:
                payload["password"] = password
        self.save_requested.emit(payload)

    def _sync_save_state(self, *_args) -> None:
        ready = bool(self.username.text().strip() and str(self.role.currentData() or ""))
        self.save.setEnabled(ready and self.is_dirty())

    def is_dirty(self) -> bool:
        if self._original is None:
            return bool(
                self.username.text().strip()
                or self.display_name.text().strip()
                or self.password.text()
                or self.scope.selected_assignments()
            )
        return self.display_name.text().strip() != str(
            self._original.get("display_name") or ""
        ).strip() or str(self.role.currentData() or "") != str(self._original.get("role") or "")

    def reject(self) -> None:
        self.cancel_requested.emit()
