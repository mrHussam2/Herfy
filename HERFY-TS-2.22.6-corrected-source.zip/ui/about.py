from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QApplication, QFrame, QGridLayout, QLabel, QVBoxLayout, QWidget

from core.settings import (
    APP_DEVELOPER_NAME,
    APP_DISPLAY_NAME,
    _,
    get_updates_base_url,
)
from ui.designer import load_ui
from ui.responsive_events import responsive_resize_event
from ui.theme import ResponsiveProfile, apply_profile_properties, make_scaler, profile_for_widget
from ui.widgets import build_logo_label
from version import __version__ as APP_VERSION


class AboutPage(QWidget):
    """Integrated application-information page owned by the main ContentStack."""

    def __init__(
        self,
        *,
        latest_version: str = "",
        update_status: str = "",
        check_for_updates=None,
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self._latest_version = str(latest_version or APP_VERSION)
        self._update_status = str(update_status or _("Up to date"))
        self._check_for_updates = check_for_updates
        self._S = make_scaler(QApplication.instance())
        self.setObjectName("AboutPage")
        self.setProperty("uiScope", "about")
        self.setProperty("nativeWorkspace", True)
        self.setMinimumWidth(self._S(320))
        self._build_ui()

    def _build_ui(self) -> None:
        controls = load_ui(
            self,
            "about_page",
            required=(
                "AboutPlainShell",
                "about_content_layout",
                "AboutCenteredLogo",
                "AboutAppName",
                "AboutProductSubtitle",
                "AboutVersionBadge",
                "AboutDeveloperText",
                "AboutDescription",
                "AboutUpdateInfo",
                "AboutStatusText",
                "AboutCheckUpdates",
                "about_feature_grid",
            ),
        )
        S = self._S
        self._content_layout: QVBoxLayout = controls["about_content_layout"]
        self._content_layout.setContentsMargins(S(20), S(18), S(20), S(18))
        self._content_layout.setSpacing(S(9))
        logo: QLabel = controls["AboutCenteredLogo"]
        image = build_logo_label(
            width=S(150),
            height=S(92),
            object_name="AboutCenteredLogo",
            ui_role="logoMissing",
        )
        self._logo_source_pixmap = QPixmap(image.pixmap())
        logo.setPixmap(self._logo_source_pixmap)
        logo.setText(image.text())
        logo.setProperty("uiRole", image.property("uiRole"))
        logo.setAlignment(Qt.AlignCenter)
        logo.setAttribute(Qt.WA_TranslucentBackground, True)
        self.app_name_label: QLabel = controls["AboutAppName"]
        self.product_label: QLabel = controls["AboutProductSubtitle"]
        self.version_label: QLabel = controls["AboutVersionBadge"]
        self.developer_label: QLabel = controls["AboutDeveloperText"]
        self.idea_label: QLabel = controls["AboutDescription"]
        self.update_info_label: QLabel = controls["AboutUpdateInfo"]
        self.update_status_label: QLabel = controls["AboutStatusText"]
        self.check_updates_button = controls["AboutCheckUpdates"]
        self.app_name_label.setText(_(APP_DISPLAY_NAME))
        self.product_label.setText(_("Food Safety Tracking Products"))
        self.version_label.setText(_("Version {version}").format(version=APP_VERSION))
        self.developer_label.setText(
            _("Developer: {developer}").format(developer=APP_DEVELOPER_NAME)
        )
        self.idea_label.setText(
            _(
                "Track product shelf life, monitor expiry risk, review branch activity, and analyze daily usage from one controlled desktop workspace."
            )
        )
        self.set_update_summary(self._latest_version, self._update_status)
        self.check_updates_button.setText(_("Check for Updates"))
        self.check_updates_button.setProperty("variant", "secondary")
        self.check_updates_button.clicked.connect(self._request_update_check)
        for widget in (
            self.app_name_label,
            self.product_label,
            self.version_label,
            self.idea_label,
            self.update_info_label,
        ):
            widget.setAlignment(Qt.AlignCenter)
        for widget in (self.version_label, self.developer_label, self.update_info_label):
            widget.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.idea_label.setMaximumWidth(S(720))
        self.feature_grid: QGridLayout = controls["about_feature_grid"]
        self.feature_cards: list[QFrame] = []
        for color, icon, title in (
            ("Green", "◷", _("Shelf Life Tracking")),
            ("Blue", "◇", _("Expiry Risk Monitoring")),
            ("Purple", "⌂", _("Branch Activity")),
            ("Orange", "▥", _("Daily Usage Reports")),
        ):
            card = self.findChild(QFrame, "AboutFeatureCard" + color)
            if card is not None:
                self.feature_cards.append(card)
            self.findChild(QLabel, "AboutFeatureIcon" + color).setText(icon)
            self.findChild(QLabel, "AboutFeatureTitle" + color).setText(title)
            self.findChild(QLabel, "AboutFeatureIcon" + color).setAlignment(Qt.AlignCenter)
            self.findChild(QLabel, "AboutFeatureTitle" + color).setAlignment(Qt.AlignCenter)
        self.findChild(QLabel, "AboutStatusIcon").setAlignment(Qt.AlignCenter)

    def set_update_summary(self, latest_version: str, status: str) -> None:
        latest = str(latest_version or APP_VERSION)
        self._latest_version = latest
        self._update_status = str(status or _("Up to date"))
        runtime_mode = _("Packaged EXE") if getattr(sys, "frozen", False) else _("Source mode")
        self.update_info_label.setText(
            _(
                "Current version: {current}\nLatest available: {latest}\nUpdate channel: {server}\nRuntime: {runtime}"
            ).format(
                current=APP_VERSION,
                latest=latest,
                server=get_updates_base_url(),
                runtime=runtime_mode,
            )
        )
        self.update_status_label.setText(_("Status: {status}").format(status=self._update_status))

    def _request_update_check(self) -> None:
        self.set_update_summary(self._latest_version, _("Checking"))
        if callable(self._check_for_updates):
            self._check_for_updates()

    resizeEvent = responsive_resize_event  # noqa: N815 - Qt callback alias

    def apply_responsive_profile(self, profile: ResponsiveProfile | None = None) -> None:
        profile = profile or profile_for_widget(self)
        apply_profile_properties(self, profile)
        compact = profile.name in {"small", "compact", "narrow"}
        margin = self._S(4 if profile.name in {"small", "narrow"} else 12 if compact else 20)
        spacing = self._S(2 if profile.name in {"small", "narrow"} else 7 if compact else 9)
        self._content_layout.setContentsMargins(margin, margin, margin, margin)
        self._content_layout.setSpacing(spacing)

        logo = self.findChild(QLabel, "AboutCenteredLogo")
        logo_width, logo_height = (
            (108, 48)
            if profile.name in {"small", "narrow"}
            else (132, 78)
            if profile.name == "compact"
            else (150, 92)
        )
        logo.setPixmap(
            self._logo_source_pixmap.scaled(
                self._S(logo_width),
                self._S(logo_height),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation,
            )
        )

        for card in self.feature_cards:
            self.feature_grid.removeWidget(card)
        columns = 4
        for index, card in enumerate(self.feature_cards):
            self.feature_grid.addWidget(card, index // columns, index % columns)
        self.feature_grid.setVerticalSpacing(self._S(3 if compact else 6))
        for column in range(max(4, self.feature_grid.columnCount())):
            self.feature_grid.setColumnStretch(column, 1 if column < columns else 0)


