from __future__ import annotations

import logging
from collections.abc import Callable, Iterable
from typing import Any

from PySide6.QtCore import QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QColor, QFont, QFontMetrics, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QStackedWidget,
    QStyle,
    QVBoxLayout,
    QWidget,
)

from core.errors import SERVICE_OPERATION_EXCEPTIONS, UI_OPERATION_EXCEPTIONS
from core.models import call_if_callable
from core.settings import (
    APP_ICON_RELATIVE_PATH,
    LOGO_RELATIVE_PATH,
    _,
    existing_asset_path,
    resource_path,
)
from core.signals import safe_disconnect
from ui.theme_responsive import dispatch_reflow_callback, ensure_layout_mode_controller

BUTTON_ROLES = {"primary", "secondary", "danger", "ghost", "toolbar", "navigation"}


def _safe_ui(action: Callable[[], None]) -> None:
    try:
        action()
    except UI_OPERATION_EXCEPTIONS:
        return


def call_if_supported(widget: Any, method_name: str, *args) -> None:
    method = getattr(widget, method_name, None)
    if callable(method):
        method(*args)


_call_if_supported = call_if_supported


def _set_if_supported(widget: Any, method_name: str, value: Any) -> None:
    if value is not None:
        _call_if_supported(widget, method_name, value)


def _iter_widgets(widgets: Iterable[Any] | None) -> Iterable[Any]:
    return widgets or []


def direction_for_rtl(rtl: bool) -> Qt.LayoutDirection:
    return Qt.RightToLeft if bool(rtl) else Qt.LeftToRight


def leading_alignment(rtl: bool) -> Qt.Alignment:
    return Qt.AlignRight if bool(rtl) else Qt.AlignLeft


def trailing_alignment(rtl: bool) -> Qt.Alignment:
    return Qt.AlignLeft if bool(rtl) else Qt.AlignRight


def set_accessibility(widget: Any, *, name: str = "", description: str = "") -> None:
    if widget is None:
        return
    if name and hasattr(widget, "setAccessibleName"):
        widget.setAccessibleName(name)
    if description and hasattr(widget, "setAccessibleDescription"):
        widget.setAccessibleDescription(description)


def set_tab_order(parent: Any, widgets: list[Any]) -> None:
    if parent is None:
        return
    valid = [item for item in widgets if item is not None]
    for left, right in zip(valid, valid[1:], strict=False):
        if hasattr(parent, "setTabOrder"):
            parent.setTabOrder(left, right)


def clear_layout(layout: Any) -> None:
    if layout is None:
        return
    while layout.count():
        item = layout.takeAt(0)
        widget = item.widget() if item is not None else None
        if widget is not None:
            widget.setParent(None)
        child_layout = item.layout() if item is not None else None
        if child_layout is not None:
            clear_layout(child_layout)


def set_widget_visible(widget, visible: bool) -> None:
    _set_if_supported(widget, "setVisible", bool(visible))


def set_widget_enabled(widget, enabled: bool) -> None:
    _set_if_supported(widget, "setEnabled", bool(enabled))


def normalize_button_role(role: str | None) -> str:
    key = str(role or "secondary").strip().lower()
    return key if key in BUTTON_ROLES else "secondary"


def polish_button(
    button: Any,
    *,
    role: str = "secondary",
    min_width: int | None = None,
    min_height: int | None = None,
    tooltip: str | None = None,
    cursor: Any | None = None,
) -> None:
    if button is None:
        return

    def _apply_polish_button() -> None:
        _call_if_supported(button, "setProperty", "variant", normalize_button_role(role))
        button.setMinimumWidth(int(min_width)) if min_width is not None else None
        button.setMinimumHeight(int(min_height)) if min_height is not None else None
        if tooltip:
            _call_if_supported(button, "setToolTip", str(tooltip))
        _set_if_supported(button, "setCursor", cursor)

    _safe_ui(_apply_polish_button)


def polish_input(
    widget: Any,
    *,
    min_height: int | None = None,
    tooltip: str | None = None,
    placeholder: str | None = None,
) -> None:
    if widget is None:
        return

    def _apply_polish_input() -> None:
        widget.setMinimumHeight(int(min_height)) if min_height is not None else None
        if tooltip:
            _call_if_supported(widget, "setToolTip", str(tooltip))
        if placeholder:
            _call_if_supported(widget, "setPlaceholderText", str(placeholder))

    _safe_ui(_apply_polish_input)


def polish_form_layout(
    form: Any,
    *,
    label_alignment: Any | None = None,
    field_growth_policy: Any | None = None,
    horizontal_spacing: int | None = None,
    vertical_spacing: int | None = None,
) -> None:
    if form is None:
        return

    def _apply_polish_form_layout() -> None:
        _set_if_supported(form, "setLabelAlignment", label_alignment)
        _set_if_supported(form, "setFieldGrowthPolicy", field_growth_policy)
        _set_if_supported(
            form,
            "setHorizontalSpacing",
            None if horizontal_spacing is None else int(horizontal_spacing),
        )
        _set_if_supported(
            form,
            "setVerticalSpacing",
            None if vertical_spacing is None else int(vertical_spacing),
        )

    _safe_ui(_apply_polish_form_layout)


def polish_dialog_action_buttons(
    primary: Any | None = None,
    secondary: Any | None = None,
    tertiary: Any | None = None,
    *,
    min_height: int | None = None,
) -> None:
    polish_button(primary, role="primary", min_height=min_height)
    polish_button(secondary, role="secondary", min_height=min_height)
    polish_button(tertiary, role="ghost", min_height=min_height)


def polish_line_edits(
    widgets: list[Any] | tuple[Any, ...], *, min_height: int | None = None
) -> None:
    for widget in _iter_widgets(widgets):
        polish_input(widget, min_height=min_height)


def polish_status_label(label: Any, *, role: str = "muted") -> None:
    if label is None:
        return

    def _apply_polish_status_label() -> None:
        _call_if_supported(label, "setObjectName", "StatusLabel")
        _call_if_supported(label, "setProperty", "statusRole", str(role or "muted").lower())

    _safe_ui(_apply_polish_status_label)


def _safe_repolish(widget: Any) -> None:
    if widget is None or not hasattr(widget, "style"):
        return

    def _apply_safe_repolish() -> None:
        style = widget.style()
        if style is not None:
            style.unpolish(widget)
            style.polish(widget)
        _call_if_supported(widget, "update")

    _safe_ui(_apply_safe_repolish)


def set_input_state(widget: Any, state: str = "", *, tooltip: str | None = None) -> None:
    if widget is None:
        return
    normalized = str(state or "").strip().lower()

    def _apply_set_input_state() -> None:
        _call_if_supported(widget, "setProperty", "inputState", normalized)
        if tooltip is not None:
            _call_if_supported(widget, "setToolTip", str(tooltip or ""))
        _safe_repolish(widget)

    _safe_ui(_apply_set_input_state)


def clear_input_state(widget: Any, *, tooltip: str | None = None) -> None:
    set_input_state(widget, "", tooltip=tooltip)


_APP_ICON_CANDIDATES: tuple[tuple[str, ...], ...] = (
    APP_ICON_RELATIVE_PATH,
    LOGO_RELATIVE_PATH,
)


def qt_file_image_loading_enabled() -> bool:
    """Allow packaged raster assets on every Qt platform plugin.

    Qt's offscreen plugin supports ``QPixmap`` file loading.  Treating it as
    unsupported made visual QA render a textual fallback in the sidebar and
    hid the same branded icons from menus.  Asset availability is determined
    by the loader itself, not by whether a window server is present.
    """
    try:
        return QApplication.instance() is not None
    except UI_OPERATION_EXCEPTIONS:
        return False


def load_asset_icon(*parts: str, fallback_to_app: bool = False) -> QIcon:
    if not qt_file_image_loading_enabled():
        return app_icon() if fallback_to_app else QIcon()
    path = existing_asset_path(*parts)
    if path:
        icon = QIcon(path)
        if not icon.isNull():
            return icon
    return app_icon() if fallback_to_app else QIcon()


def app_icon() -> QIcon:
    for candidate in _APP_ICON_CANDIDATES:
        icon = load_asset_icon(*candidate, fallback_to_app=False)
        if not icon.isNull():
            return icon
    return QIcon()


def apply_application_icon(app: QApplication | None) -> None:
    if app is None:
        return
    try:
        icon = app_icon()
        if not icon.isNull():
            app.setWindowIcon(icon)
    except UI_OPERATION_EXCEPTIONS:
        return


def apply_window_icon(widget: Any) -> None:
    if widget is None or not hasattr(widget, "setWindowIcon"):
        return
    try:
        icon = app_icon()
        if not icon.isNull():
            widget.setWindowIcon(icon)
    except UI_OPERATION_EXCEPTIONS:
        return


def apply_button_icon(
    button: Any,
    icon_name: str,
    *,
    size: int | QSize | None = None,
    fallback_standard_icon: QStyle.StandardPixmap | None = None,
) -> None:
    if button is None:
        return
    try:
        icon = load_asset_icon("resources", "images", icon_name)
        if icon.isNull() and fallback_standard_icon is not None:
            style = button.style() if hasattr(button, "style") else None
            if style is not None:
                icon = style.standardIcon(fallback_standard_icon)
        if not icon.isNull() and hasattr(button, "setIcon"):
            button.setIcon(icon)
        if size is not None and hasattr(button, "setIconSize"):
            if isinstance(size, QSize):
                button.setIconSize(size)
            else:
                px = max(1, int(size))
                button.setIconSize(QSize(px, px))
    except UI_OPERATION_EXCEPTIONS:
        return


def set_menu_action_icon(action: Any, icon_name: str) -> None:
    if action is None:
        return
    try:
        icon = load_asset_icon("resources", "images", icon_name)
        if not icon.isNull() and hasattr(action, "setIcon"):
            action.setIcon(icon)
    except UI_OPERATION_EXCEPTIONS:
        return


def tray_icon_or_fallback(owner: Any) -> QIcon:
    icon = app_icon()
    if not icon.isNull():
        return icon
    try:
        if owner is not None and hasattr(owner, "style"):
            return owner.style().standardIcon(QStyle.SP_DesktopIcon)
    except UI_OPERATION_EXCEPTIONS:
        return QIcon()
    return QIcon()


logger = logging.getLogger(__name__)


def widget_alive(widget) -> bool:
    if widget is None:
        return False
    try:
        from shiboken6 import isValid
    except ImportError:
        return True
    try:
        return bool(isValid(widget))
    except UI_OPERATION_EXCEPTIONS:
        return True


def should_refresh_widget(widget) -> bool:
    if not widget_alive(widget):
        return False
    try:
        if bool(getattr(widget, "_disposed", False)):
            return False
        is_visible = getattr(widget, "isVisible", None)
        return bool(is_visible()) if callable(is_visible) else True
    except UI_OPERATION_EXCEPTIONS:
        return False


class ControllerLifecycleMixin:
    def _on_destroyed(self, *_args) -> None:
        self._disposed = True
        try:
            bind_app_state = getattr(self, "bind_app_state", None)
            if callable(bind_app_state):
                call_if_callable(bind_app_state, None)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("ControllerLifecycleMixin._on_destroyed cleanup failed", exc_info=True)

    def _is_alive(self) -> bool:
        return widget_alive(self)

    def _should_refresh_now(self) -> bool:
        return should_refresh_widget(self)

    def _schedule_session_callback(self, delay_ms: int, callback) -> bool:
        """Run deferred page work only while this widget still belongs to an active session."""
        if not callable(callback):
            return False

        def _guarded() -> None:
            if not self._is_alive() or bool(getattr(self, "_disposed", False)):
                return
            state = getattr(self, "_bound_app_state", None)
            if state is None or not bool(getattr(state, "session", None)):
                return
            callback()

        try:
            QTimer.singleShot(max(0, int(delay_ms or 0)), _guarded)
            return True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Session-scoped deferred callback scheduling failed", exc_info=True)
            return False


class ResizeCallbackMixin:
    """Dispatch resize callbacks only on semantic layout/profile changes."""

    resize_callback_name = ""

    def _ensure_resize_callback_controller(self):
        """Return the shared event-driven resize controller for this widget."""
        controller = ensure_layout_mode_controller(
            self,
            attr_name="_resize_callback_mode_controller",
        )
        if not bool(getattr(self, "_resize_callback_mode_connected", False)):
            controller.reflowRequested.connect(self._on_resize_callback_reflow_requested)
            self._resize_callback_mode_connected = True
        return controller

    def _on_resize_callback_reflow_requested(self, mode, profile) -> None:
        """Dispatch the configured resize callback after a semantic layout/profile transition."""
        dispatch_reflow_callback(
            self,
            str(self.resize_callback_name or ""),
            mode=str(mode or ""),
            profile=profile,
            force=True,
        )

    def resizeEvent(self, event):
        """Schedule an adaptive resize callback without reflowing on unchanged semantic profiles."""
        super().resizeEvent(event)
        self._ensure_resize_callback_controller().schedule()

    def showEvent(self, event):
        """Force one callback after the widget receives a real visible size."""
        super().showEvent(event)
        self._ensure_resize_callback_controller().schedule(force=True)


def _safe_common_ui(action: Callable[[], None], message: str) -> None:
    try:
        action()
    except UI_OPERATION_EXCEPTIONS:
        logger.debug(message, exc_info=True)


def refresh_widget_style(widget: QWidget) -> None:
    if widget is None:
        return

    def _apply_refresh_widget_style() -> None:
        style = widget.style()
        style.unpolish(widget)
        style.polish(widget)
        widget.update()

    _safe_common_ui(_apply_refresh_widget_style, "refresh_widget_style fallback failed")


def apply_notice(widget: QWidget, text: str, kind: str = "info") -> None:
    """Apply the canonical inline-notice presentation state to a widget."""
    widget.setText(str(text or ""))
    widget.setProperty("noticeKind", str(kind))
    widget.setVisible(bool(text))
    style = widget.style()
    style.unpolish(widget)
    style.polish(widget)


class InlineNoticeMixin:
    """Provide the canonical page-level inline-notice entry point."""

    def _show_notice(self, text: str, kind: str = "info") -> None:
        apply_notice(self.notice, text, kind)


DEFAULT_DATA_SIGNALS = ("data_changed", "item_updated", "item_deleted")
SignalCallback = tuple[str, Any]


def _owner_is_alive(owner: Any) -> bool:
    checker = getattr(owner, "_is_alive", None)
    if callable(checker):
        try:
            return bool(checker())
        except UI_OPERATION_EXCEPTIONS:
            return False
    return True


def disconnect_app_state_callbacks(
    owner: Any,
    signal_callbacks: Iterable[SignalCallback],
    *,
    logger_=None,
    context: str = "app_state disconnect",
) -> None:
    old_state = getattr(owner, "_bound_app_state", None)
    if old_state is None:
        return
    for signal_name, callback in signal_callbacks:
        signal = getattr(old_state, signal_name, None)
        if signal is not None:
            safe_disconnect(signal, callback, logger_=logger_, context=context)
    owner._bound_app_state = None


def bind_app_state_callbacks(
    owner: Any,
    app_state: Any,
    signal_callbacks: Iterable[SignalCallback],
    *,
    logger_=None,
    context: str = "app_state bind",
) -> bool:
    if app_state is None:
        owner._bound_app_state = None
        return False
    callbacks = tuple(signal_callbacks)
    try:
        for signal_name, callback in callbacks:
            getattr(app_state, signal_name).connect(callback)
        owner._bound_app_state = app_state
        return True
    except UI_OPERATION_EXCEPTIONS:
        for signal_name, callback in callbacks:
            safe_disconnect(
                getattr(app_state, signal_name, None),
                callback,
                logger_=logger_,
                context=context,
            )
        owner._bound_app_state = None
        if logger_ is not None:
            logger_.debug("%s failed", context, exc_info=True)
        return False


def rebind_app_state_callbacks_if_alive(
    owner: Any,
    app_state: Any,
    signal_callbacks: Iterable[SignalCallback],
    *,
    logger_=None,
    disconnect_context: str = "app_state disconnect",
    bind_context: str = "app_state bind",
) -> bool:
    callbacks = tuple(signal_callbacks)
    disconnect_app_state_callbacks(owner, callbacks, logger_=logger_, context=disconnect_context)
    if app_state is None or not _owner_is_alive(owner):
        return False
    return bind_app_state_callbacks(
        owner, app_state, callbacks, logger_=logger_, context=bind_context
    )


def rebind_domain_app_state_signal_if_alive(
    owner: Any,
    app_state: Any,
    callback: Any,
    *,
    page_name: str,
    logger_=None,
    signal_names: Iterable[str] = DEFAULT_DATA_SIGNALS,
) -> bool:
    callbacks = tuple(((signal_name, callback) for signal_name in signal_names))
    return rebind_app_state_callbacks_if_alive(
        owner,
        app_state,
        callbacks,
        logger_=logger_,
        disconnect_context=f"{page_name}.bind_app_state disconnect",
        bind_context=f"{page_name}.bind_app_state",
    )


class DomainAppStateBindingMixin:
    app_state_page_name = "Page"
    app_state_callback_name = ""
    app_state_signal_names = DEFAULT_DATA_SIGNALS

    def bind_app_state(self, app_state: Any) -> bool:
        callback = getattr(self, str(self.app_state_callback_name or ""), None)
        if callback is None:
            return False
        module_logger = None
        try:
            import logging

            module_logger = logging.getLogger(self.__class__.__module__)
        except UI_OPERATION_EXCEPTIONS:
            module_logger = None
        return rebind_domain_app_state_signal_if_alive(
            self,
            app_state,
            callback,
            page_name=str(self.app_state_page_name or self.__class__.__name__),
            signal_names=self.app_state_signal_names,
            logger_=module_logger,
        )


logger = logging.getLogger(__name__)


def _iter_widget_tree(widget) -> Iterable:
    if widget is None:
        return []
    try:
        return [widget, *list(widget.findChildren(QWidget))]
    except SERVICE_OPERATION_EXCEPTIONS:
        return [widget]


def repolish_widget_tree(widget) -> None:
    for item in _iter_widget_tree(widget):
        try:
            if item is None or not hasattr(item, "style"):
                continue
            style = item.style()
            if style is None:
                continue
            style.unpolish(item)
            style.polish(item)
            if hasattr(item, "update"):
                item.update()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("repolish_widget_tree fallback failed", exc_info=True)


class DataSurface(QStackedWidget):
    """Canonical state surface for one data view.

    One dataset owns one content widget and one operational feedback surface.
    An empty result deliberately leaves its table/tree in place: headers,
    filters and authorised actions remain available without a full-page
    instructional placeholder. Loading and error states remain explicit.
    """

    _STATES = frozenset({"content", "loading", "error"})

    @staticmethod
    def _default_feedback_title(state: str) -> str:
        return {
            "loading": _("Loading"),
            "error": _("Unable to load data"),
        }.get(str(state or ""), "")

    def __init__(self, content: QWidget, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("DataSurface")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.content = content

        self.feedback_page = QWidget(self)
        self.feedback_page.setObjectName("DataSurfaceFeedbackPage")
        layout = QVBoxLayout(self.feedback_page)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(6)
        layout.addStretch(1)

        self.feedback_marker = QLabel("—", self.feedback_page)
        self.feedback_marker.setObjectName("DataSurfaceFeedbackMarker")
        self.feedback_marker.setAlignment(Qt.AlignCenter)
        self.feedback_marker.setAccessibleName(_("Loading"))
        layout.addWidget(self.feedback_marker, 0, Qt.AlignHCenter)

        self.busy_indicator = QProgressBar(self.feedback_page)
        self.busy_indicator.setObjectName("DataSurfaceBusyIndicator")
        self.busy_indicator.setRange(0, 0)
        self.busy_indicator.setTextVisible(False)
        self.busy_indicator.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.busy_indicator.setAccessibleName(_("Loading"))
        self.busy_indicator.hide()
        layout.addWidget(self.busy_indicator, 0, Qt.AlignHCenter)

        self.feedback_title = QLabel(self.feedback_page)
        self.feedback_title.setObjectName("DataSurfaceFeedbackTitle")
        self.feedback_title.setWordWrap(True)
        self.feedback_title.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.feedback_title, 0, Qt.AlignHCenter)

        self.feedback_message = QLabel(self.feedback_page)
        self.feedback_message.setObjectName("DataSurfaceFeedbackMessage")
        self.feedback_message.setWordWrap(True)
        self.feedback_message.setAlignment(Qt.AlignCenter)
        self.feedback_message.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        layout.addWidget(self.feedback_message, 0, Qt.AlignHCenter)
        layout.addStretch(1)

        self.addWidget(content)
        self.addWidget(self.feedback_page)
        self.set_state("content")

    def set_state(
        self,
        state: str,
        *,
        title: str | None = None,
        message: str | None = None,
    ) -> None:
        value = str(state or "").strip().lower()
        if value not in self._STATES:
            raise ValueError(f"Unsupported data-surface state: {state}")

        if value == "content":
            self.setCurrentWidget(self.content)
        else:
            if value == "loading":
                resolved_title = (
                    self._default_feedback_title(value) if title is None else str(title or "")
                )
                resolved_message = "" if message is None else str(message or "")
                marker = "…"
            else:
                resolved_title = (
                    self._default_feedback_title(value) if title is None else str(title or "")
                )
                resolved_message = "" if message is None else str(message or "")
                marker = "!"

            self.feedback_marker.setText(marker)
            self.feedback_marker.setAccessibleName(resolved_title or resolved_message)
            self.feedback_marker.setVisible(value != "loading")
            self.busy_indicator.setVisible(value == "loading")
            self.busy_indicator.setAccessibleDescription(
                " ".join(part for part in (resolved_title, resolved_message) if part).strip()
            )
            self.feedback_title.setText(resolved_title)
            self.feedback_message.setText(resolved_message)
            self.feedback_title.setVisible(bool(resolved_title.strip()))
            self.feedback_message.setVisible(bool(resolved_message.strip()))
            self.setCurrentWidget(self.feedback_page)

        if value == "content":
            self.busy_indicator.hide()
            self.feedback_marker.show()

        self.setProperty("surfaceState", value)
        self.feedback_page.setProperty("surfaceState", value)
        self.feedback_marker.setProperty("surfaceState", value)
        self.feedback_title.setProperty("surfaceState", value)
        self.feedback_message.setProperty("surfaceState", value)
        refresh_widget_style(self.feedback_page)


__all__ = ["DataSurface"]


logger = logging.getLogger(__name__)


def build_logo_label(
    *,
    width: int,
    height: int | None = None,
    object_name: str = "",
    ui_role: str = "logoMissing",
    alignment: int = Qt.AlignCenter,
) -> QLabel:
    label = QLabel()
    if object_name:
        label.setObjectName(object_name)
    logo_path = resource_path(*LOGO_RELATIVE_PATH)
    target_height = int(height if height is not None else width)
    if not qt_file_image_loading_enabled():
        label.setText("HERFY")
        label.setProperty("uiRole", ui_role)
    else:
        pixmap = QPixmap(logo_path)
        if pixmap.isNull():
            label.setText(_("Logo Not Found"))
            label.setProperty("uiRole", ui_role)
        else:
            label.setPixmap(
                pixmap.scaled(
                    int(width),
                    target_height,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation,
                )
            )
    label.setAlignment(alignment)
    label.setAttribute(Qt.WA_TranslucentBackground, True)
    label.setAutoFillBackground(False)
    return label


class NotificationBadgeButton(QPushButton):
    """Clickable notification action with a DPI-friendly painted unread badge."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.notification_count = 0
        self.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self.setMinimumSize(40, 40)
        self.setAccessibleName("Notifications")
        self.setAccessibleDescription("No unread notifications")

    def set_count(self, count: int) -> None:
        try:
            value = int(count or 0)
        except (TypeError, ValueError):
            value = 0
        value = max(0, value)
        if value == self.notification_count:
            return
        self.notification_count = value
        self.setProperty("hasUnreadNotifications", value > 0)
        self.setAccessibleDescription(
            "No unread notifications"
            if value == 0
            else f"{value} unread notification{'s' if value != 1 else ''}"
        )
        self.setToolTip(self.accessibleDescription())
        self.update()

    def badge_text(self) -> str:
        if self.notification_count <= 0:
            return ""
        return "99+" if self.notification_count >= 100 else str(self.notification_count)

    @staticmethod
    def badge_font() -> QFont:
        return QFont("Segoe UI", 8, QFont.Bold)

    def badge_rect(self) -> QRectF:
        text = self.badge_text()
        height = float(max(16, QFontMetrics(self.badge_font()).height() + 4))
        text_width = QFontMetrics(self.badge_font()).horizontalAdvance(text)
        width = max(height, float(text_width + 8))
        return QRectF(self.width() - width - 3.0, 3.0, width, height)

    def paintEvent(self, event) -> None:
        super().paintEvent(event)
        text = self.badge_text()
        if not text:
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        badge_rect = self.badge_rect()
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor("#EF4444"))
        if badge_rect.width() > badge_rect.height():
            painter.drawRoundedRect(badge_rect, badge_rect.height() / 2, badge_rect.height() / 2)
        else:
            painter.drawEllipse(badge_rect)
        painter.setPen(QColor("#FFFFFF"))
        painter.setFont(self.badge_font())
        painter.drawText(badge_rect, Qt.AlignCenter, text)
        painter.end()


__all__ = ["NotificationBadgeButton"]
