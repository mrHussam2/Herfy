from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from PySide6.QtCore import (
    QModelIndex,
    QObject,
    QSortFilterProxyModel,
    Qt,
    QTimer,
    Signal,
)
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QFrame,
    QGridLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSizePolicy,
    QSplitter,
    QStackedWidget,
    QTableView,
    QWidget,
)

from ui.dialogs import show_question_message
from core.settings import _
from ui.designer import load_ui
from ui.tables import (
    RowListTableModel,
    configure_sortable_table,
    configure_table_layout,
    horizontal_header_value,
)
from ui.theme import (
    UI_METRICS,
    apply_profile_properties,
    ensure_layout_mode_controller,
)
from ui.widgets import DataSurface, DomainAppStateBindingMixin, InlineNoticeMixin


class CatalogTableModel(RowListTableModel):
    """Read-only operational projection for a server-authoritative catalog.

    Revision/category/shelf-life remain server DTO details but are not primary
    operator columns.  Stored products show material/name/status; usage items
    additionally expose UOM.
    """

    COLUMNS_BY_KIND = {
        "stored": (
            ("material_number", "Material number"),
            ("name", "Name"),
            ("is_active", "Status"),
        ),
        "usage": (
            ("material_number", "Material number"),
            ("name", "Name"),
            ("uom", "Unit"),
            ("is_active", "Status"),
        ),
    }

    def __init__(self, kind: str = "stored", parent=None):
        super().__init__(parent)
        self.kind = "usage" if str(kind or "").strip().lower() == "usage" else "stored"
        self.COLUMNS = self.COLUMNS_BY_KIND[self.kind]
        self._rows: list[dict[str, Any]] = []

    def columnCount(self, parent=QModelIndex()):  # noqa: N802 - Qt API
        return 0 if parent.isValid() else len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):  # noqa: N802 - Qt API
        matches, label = horizontal_header_value(
            self.COLUMNS,
            section,
            orientation,
            role,
            label_index=1,
            translate=True,
        )
        if matches:
            return label
        return super().headerData(section, orientation, role)

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._rows)):
            return None
        row = self._rows[index.row()]
        key = self.COLUMNS[index.column()][0]
        if role == Qt.DisplayRole:
            value = row.get(key)
            if key == "is_active":
                return _("Active") if bool(value) else _("Inactive")
            return "" if value is None else str(value)
        if role == Qt.UserRole:
            return row
        return None

    def row(self, source_row: int) -> dict[str, Any]:
        if 0 <= source_row < len(self._rows):
            return dict(self._rows[source_row])
        return {}


class CatalogSortFilterProxyModel(QSortFilterProxyModel):
    """Filter all display columns and keep numeric catalog columns numerically sorted."""

    def lessThan(self, left: QModelIndex, right: QModelIndex) -> bool:  # noqa: N802 - Qt API
        model = self.sourceModel()
        if not isinstance(model, CatalogTableModel):
            return super().lessThan(left, right)
        key = model.COLUMNS[left.column()][0]
        left_value = model.row(left.row()).get(key)
        right_value = model.row(right.row()).get(key)
        if key == "is_active":
            return bool(left_value) < bool(right_value)
        return str(left_value or "").casefold() < str(right_value or "").casefold()


@dataclass
class CatalogSectionState:
    kind: str
    rows: list[dict[str, Any]] = field(default_factory=list)
    selected_material: str = ""
    loading: bool = False
    error: str = ""
    loaded: bool = False

    def replace(self, rows: list[dict[str, Any]] | None) -> None:
        self.rows = [dict(row) for row in (rows or [])]
        self.loaded = True
        if self.selected_material and not any(
            str(row.get("material_number")) == self.selected_material for row in self.rows
        ):
            self.selected_material = ""

    def apply(self, product: dict[str, Any]) -> None:
        row = dict(product or {})
        material = str(row.get("material_number") or "")
        if not material:
            return
        for index, current in enumerate(self.rows):
            if str(current.get("material_number") or "") == material:
                self.rows[index] = row
                break
        else:
            self.rows.append(row)
        self.rows.sort(key=lambda item: str(item.get("material_number") or ""))
        self.selected_material = material


@dataclass
class CatalogManagementState:
    stored: CatalogSectionState = field(default_factory=lambda: CatalogSectionState("stored"))
    usage: CatalogSectionState = field(default_factory=lambda: CatalogSectionState("usage"))
    online: bool = False

    def section(self, kind: str) -> CatalogSectionState:
        if kind not in {"stored", "usage"}:
            raise ValueError(kind)
        return getattr(self, kind)


class CatalogManagementController(QObject):
    loaded = Signal(str, object)
    mutated = Signal(str, object)
    error = Signal(str, str)
    busy = Signal(str, bool)

    def __init__(self, catalog_service: Any, worker_registry, parent=None):
        super().__init__(parent)
        if catalog_service is None:
            raise RuntimeError(
                "CatalogManagementController requires composed catalog management service"
            )
        self.catalog_service = catalog_service
        self.state = CatalogManagementState()
        if worker_registry is None:
            raise RuntimeError("CatalogManagementController requires a worker registry")
        self.workers = worker_registry

    def close(self):
        self.workers.close()

    def _online(self) -> bool:
        return bool(self.catalog_service.online())

    def _require_online(self) -> None:
        if not self._online():
            raise RuntimeError(_("Server connection is required for catalog administration."))

    def load(self, kind: str, *, force: bool = False) -> None:
        section = self.state.section(kind)
        if section.loaded and not force:
            self.state.online = self._online()
            self.loaded.emit(kind, list(section.rows))
            return
        operation_key = f"catalog:{kind}:load"
        if self.workers.has_active_key(operation_key):
            return
        online = self._online()
        self.state.online = online
        self.busy.emit(kind, True)
        catalog_service = self.catalog_service

        def _work():
            return catalog_service.list(kind)

        worker = self.workers.start(
            _work,
            on_result=lambda rows: self._on_loaded(kind, rows),
            on_error=lambda msg: self._on_error(kind, msg),
            on_finished=lambda: self.busy.emit(kind, False),
            operation_key=operation_key,
            log_exceptions=False,
        )
        if worker is None:
            self.busy.emit(kind, False)

    def invalidate(self, kind: str) -> None:
        """Mark one server-owned projection stale without issuing a UI-thread call."""
        self.state.section(kind).loaded = False

    def _on_loaded(self, kind: str, rows: object):
        data = [dict(r) for r in rows] if isinstance(rows, list) else []
        self.state.section(kind).replace(data)
        self.loaded.emit(kind, data)

    def _on_error(self, kind: str, msg: object):
        self.error.emit(kind, str(msg))

    def create(self, kind: str, payload: dict[str, Any]):
        catalog_service = self.catalog_service
        self._mutate(kind, "create", lambda: catalog_service.create(kind, payload))

    def update(self, kind: str, material: str, payload: dict[str, Any]):
        catalog_service = self.catalog_service
        self._mutate(
            kind,
            "update",
            lambda: catalog_service.update(kind, material, payload),
        )

    def delete(self, kind: str, material: str, revision: int):
        catalog_service = self.catalog_service
        self._mutate(
            kind,
            "delete",
            lambda: catalog_service.delete(kind, material, revision),
        )

    def _mutate(self, kind: str, action: str, fn):
        if not self._online():
            self.error.emit(kind, _("Server connection is required to modify catalogs."))
            return
        operation_key = f"catalog:{kind}:{action}"
        if self.workers.has_active_key(operation_key):
            return
        self.busy.emit(kind, True)
        worker = self.workers.start(
            fn,
            on_result=lambda row: self._on_mutated(kind, row),
            on_error=lambda msg: self._on_error(kind, msg),
            on_finished=lambda: self.busy.emit(kind, False),
            operation_key=operation_key,
            log_exceptions=False,
        )
        if worker is None:
            self.busy.emit(kind, False)

    def _on_mutated(self, kind: str, row: object):
        data = dict(row) if isinstance(row, dict) else {}
        self.state.section(kind).apply(data)
        self.mutated.emit(kind, data)


class CatalogPage(InlineNoticeMixin, QWidget):
    """One catalog section. All mutations remain delegated to the controller/server."""

    def __init__(
        self,
        kind: str,
        controller: CatalogManagementController,
        editable: bool,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.kind = str(kind)
        self.controller = controller
        self._permission_editable = bool(editable)
        self.editable = bool(editable)
        self._busy = False
        self._compact = False
        self.setObjectName("CatalogPage")
        self.setProperty("nativeWorkspace", True)
        self._build()

    @property
    def section_title(self) -> str:
        return _("Stored Products") if self.kind == "stored" else _("Usage Products")

    def _build(self) -> None:
        controls = load_ui(
            self,
            "catalog_page",
            required=(
                "CatalogCountBadge",
                "CatalogSearch",
                "CatalogRefreshButton",
                "CatalogAddButton",
                "CatalogSplitter",
                "CatalogCollectionStatus",
                "catalog_toolbar_layout",
                "CatalogTable",
                "catalog_table_host",
                "CatalogMaterialInput",
                "CatalogNameInput",
                "CatalogUomInput",
                "CatalogActiveInput",
                "CatalogNotice",
                "CatalogDeleteButton",
                "CatalogSaveButton",
            ),
        )
        self.count_badge: QLabel = controls["CatalogCountBadge"]
        self.count_badge.setAlignment(Qt.AlignCenter)
        self.search: QLineEdit = controls["CatalogSearch"]
        self.search.setPlaceholderText(_("Search..."))
        self.search.setClearButtonEnabled(True)
        self.refresh_btn: QPushButton = controls["CatalogRefreshButton"]
        self.add_btn: QPushButton = controls["CatalogAddButton"]
        self.toolbar_grid: QGridLayout = controls["catalog_toolbar_layout"]
        self.refresh_btn.setText(_("Refresh"))
        self.add_btn.setText(_("New product"))
        self.refresh_btn.setProperty("variant", "secondary")
        # Catalog projections are updated by the application sync runtime.
        # Keep the legacy command wired for accessibility/automation, but do
        # not make an operator depend on a manual refresh control.
        self.refresh_btn.hide()
        self.add_btn.setProperty("variant", "primary")
        self.splitter: QSplitter = controls["CatalogSplitter"]
        self.splitter.setChildrenCollapsible(False)
        self.findChild(QLabel, "CatalogCollectionTitle").setText(_("Catalog items"))
        self.collection_status: QLabel = controls["CatalogCollectionStatus"]
        self.model = CatalogTableModel(self.kind, self)
        self.proxy = CatalogSortFilterProxyModel(self)
        self.proxy.setSourceModel(self.model)
        self.proxy.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.proxy.setFilterKeyColumn(-1)
        self.proxy.setDynamicSortFilter(True)
        self.table: QTableView = controls["CatalogTable"]
        self.table.setModel(self.proxy)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        configure_table_layout(self.table, show_grid=False)
        configure_sortable_table(self.table, enabled=True)
        self._configure_columns()
        collection = self.findChild(QFrame, "CatalogCollectionCard")
        self.collection_surface = DataSurface(self.table, collection)
        controls["catalog_table_host"].layout().addWidget(self.collection_surface)
        editor = self.findChild(QFrame, "CatalogEditorCard")
        editor.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        self.editor_title: QLabel = self.findChild(QLabel, "CatalogEditorTitle")
        self.editor_hint: QLabel = self.findChild(QLabel, "CatalogEditorHint")
        self.editor_hint.hide()
        self.editor_title.setText(_("Add product"))
        self.material: QLineEdit = controls["CatalogMaterialInput"]
        self.name: QLineEdit = controls["CatalogNameInput"]
        self.uom: QLineEdit = controls["CatalogUomInput"]
        self.active: QCheckBox = controls["CatalogActiveInput"]
        self._revision = 0
        self._original_payload: dict[str, Any] = {}
        self.material.setPlaceholderText(_("Material number"))
        self.name.setPlaceholderText(_("Name"))
        self.uom.setPlaceholderText(_("Unit"))
        self.active.setText(_("Active"))
        for name, caption in (
            ("CatalogMaterialInput", _("Material number")),
            ("CatalogNameInput", _("Name")),
            ("CatalogUomInput", _("Unit")),
            ("CatalogActiveInput", _("Status")),
        ):
            label = self.findChild(QLabel, "label_" + name)
            label.setText(caption)
            label.setProperty("textRole", "fieldLabel")
        if self.kind != "usage":
            self.uom.hide()
            self.findChild(QLabel, "label_CatalogUomInput").hide()
        self.notice: QLabel = controls["CatalogNotice"]
        self.notice.hide()
        self.delete_btn: QPushButton = controls["CatalogDeleteButton"]
        self.save_btn: QPushButton = controls["CatalogSaveButton"]
        self.delete_btn.setText(_("Disable"))
        self.save_btn.setText(_("Save"))
        self.delete_btn.setProperty("variant", "danger")
        self.save_btn.setProperty("variant", "primary")
        self.splitter.setStretchFactor(0, 5)
        self.splitter.setStretchFactor(1, 3)

        self.search.textChanged.connect(self._on_search_changed)
        self.refresh_btn.clicked.connect(lambda: self.controller.load(self.kind, force=True))
        self.add_btn.clicked.connect(self.begin_create)
        self.table.selectionModel().selectionChanged.connect(self._selection_changed)
        self.save_btn.clicked.connect(self._save)
        self.delete_btn.clicked.connect(self._delete)
        self._set_editable(self.editable)
        self.begin_create()
        self._refresh_collection_state()

    def _configure_columns(self) -> None:
        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.Interactive)
        self.table.setColumnWidth(0, 150)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        if self.kind == "usage":
            header.setSectionResizeMode(2, QHeaderView.Interactive)
            self.table.setColumnWidth(2, 90)
            header.setSectionResizeMode(3, QHeaderView.Fixed)
            self.table.setColumnWidth(3, 88)
        else:
            header.setSectionResizeMode(2, QHeaderView.Fixed)
            self.table.setColumnWidth(2, 88)

    def _set_editable(self, editable: bool) -> None:
        self.editable = bool(editable)
        controls = (
            self.add_btn,
            self.save_btn,
            self.material,
            self.name,
            self.uom,
            self.active,
        )
        for widget in controls:
            widget.setEnabled(self.editable and not self._busy)
        self.delete_btn.setEnabled(
            self.editable and not self._busy and int(self._revision or 0) > 0
        )
        self.refresh_btn.setEnabled(not self._busy)
        if not self.editable:
            self._show_notice(
                _(
                    "Offline or read-only: server connection and permission are required for changes."
                ),
                "warning",
            )
        elif self.notice.property("noticeKind") == "warning":
            self._show_notice("")

    def set_online(self, online: bool) -> None:
        self._set_editable(bool(online and self._permission_editable))

    def set_rows(self, rows) -> None:
        data = list(rows or [])
        self.model.replace_rows(data)
        self.count_badge.setText(str(len(data)))
        self._refresh_collection_state()

    def _on_search_changed(self, text: str) -> None:
        self.proxy.setFilterFixedString(str(text or ""))
        self._refresh_collection_state()

    def _refresh_collection_state(self) -> None:
        visible = self.proxy.rowCount()
        total = self.model.rowCount()
        self.collection_status.setText(f"{visible}/{total}")
        (
            self.collection_surface.set_state("content")
            if visible
            else self.collection_surface.set_state(
                "empty",
                title=(
                    _("No catalog items match the current search.")
                    if total
                    else _("No catalog items")
                ),
                message=(
                    _("Change or clear the search text to show catalog items.")
                    if total
                    else _(
                        "Catalog data syncs automatically. Create a catalog item when permitted."
                    )
                ),
            )
        )

    def _selection_changed(self, *_args) -> None:
        indexes = self.table.selectionModel().selectedRows()
        if not indexes:
            return
        source = self.proxy.mapToSource(indexes[0])
        self.load_row(self.model.row(source.row()))

    def load_row(self, row) -> None:
        data = dict(row or {})
        self.material.setText(str(data.get("material_number") or ""))
        self.material.setReadOnly(True)
        self.name.setText(str(data.get("name") or ""))
        self.uom.setText(str(data.get("uom") or ""))
        self.active.setChecked(bool(data.get("is_active", True)))
        self._revision = int(data.get("revision") or 0)
        self._original_payload = self._payload()
        self.editor_title.setText(_("Edit product"))
        self.save_btn.setText(_("Save changes"))
        self.delete_btn.setEnabled(bool(self.editable and not self._busy and self._revision > 0))
        if self.editable:
            self._show_notice("")

    def begin_create(self) -> None:
        self.table.clearSelection()
        self.material.setReadOnly(False)
        self.material.clear()
        self.name.clear()
        self.uom.clear()
        self.active.setChecked(True)
        self._revision = 0
        self._original_payload = {}
        self.editor_title.setText(_("Add product"))
        self.save_btn.setText(_("Create product"))
        self.delete_btn.setEnabled(False)
        if self.editable:
            self._show_notice("")
        self.material.setFocus(Qt.OtherFocusReason)

    # Backward-compatible local helper name used by older tests/callers.
    def clear_editor(self) -> None:
        self.begin_create()

    def is_dirty(self) -> bool:
        current = self._payload()
        if self._revision > 0:
            return current != self._original_payload
        return bool(
            current.get("material_number")
            or current.get("name")
            or (self.kind == "usage" and current.get("uom"))
            or not bool(current.get("is_active", True))
        )

    def _payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "material_number": self.material.text().strip(),
            "name": self.name.text().strip(),
            "is_active": self.active.isChecked(),
        }
        if self.kind == "usage":
            payload["uom"] = self.uom.text().strip()
        return payload

    def _save(self) -> None:
        payload = self._payload()
        if not payload["material_number"] or not payload["name"]:
            self._show_notice(_("Material number and name are required."), "warning")
            return
        revision = int(self._revision or 0)
        if revision > 0:
            payload.pop("material_number", None)
            payload["base_revision"] = revision
            self.controller.update(self.kind, self.material.text().strip(), payload)
        else:
            self.controller.create(self.kind, payload)

    def _delete(self) -> None:
        revision = int(self._revision or 0)
        material = self.material.text().strip()
        if revision <= 0 or not material:
            return
        answer = show_question_message(
            self,
            _("Confirm"),
            _("Disable this catalog item?")
        )
        if answer:
            self.controller.delete(self.kind, material, revision)

    def set_busy(self, busy: bool) -> None:
        self._busy = bool(busy)
        self.collection_status.setProperty("busy", self._busy)
        self.collection_status.style().unpolish(self.collection_status)
        self.collection_status.style().polish(self.collection_status)
        self.refresh_btn.setEnabled(not self._busy)
        self.save_btn.setEnabled(not self._busy and self.editable)
        self.delete_btn.setEnabled(
            not self._busy and self.editable and int(self._revision or 0) > 0
        )
        self.add_btn.setEnabled(not self._busy and self.editable)

    def set_compact(self, compact: bool) -> None:
        compact = False  # Preserve the desktop editor beside its collection.
        if compact == self._compact:
            return
        self._compact = compact
        for widget in (self.search, self.refresh_btn, self.add_btn):
            self.toolbar_grid.removeWidget(widget)
        for column in range(3):
            self.toolbar_grid.setColumnStretch(column, 0)
        if compact:
            self.toolbar_grid.addWidget(self.search, 0, 0, 1, 2)
            self.toolbar_grid.addWidget(self.refresh_btn, 1, 0)
            self.toolbar_grid.addWidget(self.add_btn, 1, 1)
            self.toolbar_grid.setColumnStretch(0, 1)
            self.toolbar_grid.setColumnStretch(1, 1)
        else:
            self.toolbar_grid.addWidget(self.search, 0, 0)
            self.toolbar_grid.addWidget(self.refresh_btn, 0, 1)
            self.toolbar_grid.addWidget(self.add_btn, 0, 2)
            self.toolbar_grid.setColumnStretch(0, 1)

        self.splitter.setOrientation(Qt.Vertical if compact else Qt.Horizontal)
        self.splitter.setStretchFactor(0, 1)
        self.splitter.setStretchFactor(1, 0)
        editor = self.findChild(QFrame, "CatalogEditorCard")
        if editor is not None:
            editor.setMinimumWidth(0 if compact else UI_METRICS.catalog_editor_min_width)
            editor.setMaximumWidth(
                UI_METRICS.widget_maximum_extent if compact else UI_METRICS.catalog_editor_max_width
            )
            editor.setSizePolicy(
                QSizePolicy.Expanding if compact else QSizePolicy.Preferred,
                QSizePolicy.Expanding,
            )

        # Seed the splitter from its live extent; QSplitter then preserves the
        # ratio naturally while the window continues to resize.
        extent = int(self.splitter.height() if compact else self.splitter.width())
        if extent <= 1:
            extent = int(self.height() if compact else self.width())
        if extent <= 1:
            extent = 700 if compact else 1020
        primary = max(1, int(extent * (0.46 if compact else 0.66)))
        self.splitter.setSizes([primary, max(1, extent - primary)])


class ProductCatalogPage(DomainAppStateBindingMixin, QWidget):
    """Integrated catalog workspace, gated by server-derived authority."""

    app_state_page_name = "ProductCatalogPage"
    app_state_callback_name = "_on_app_state_catalog_changed"

    def __init__(self, catalog_service: Any, worker_registry, parent=None) -> None:
        super().__init__(parent)
        self.catalog_service = catalog_service
        self.controller = CatalogManagementController(catalog_service, worker_registry, self)
        self.pages: dict[str, CatalogPage] = {}
        self._busy_sections: set[str] = set()
        self._closed = False
        self._pending_catalog_kinds: set[str] = set()
        self._catalog_sync_timer = QTimer(self)
        self._catalog_sync_timer.setSingleShot(True)
        self._catalog_sync_timer.timeout.connect(self._refresh_synchronized_catalogs)

        self.setObjectName("ProductCatalogPage")
        self.setProperty("uiScope", "catalogManagement")
        self.setProperty("nativeWorkspace", True)
        self.setMinimumWidth(UI_METRICS.catalog_navigation_min_width)

        self._build()
        self._responsive_controller = ensure_layout_mode_controller(self)
        self._responsive_controller.reflowRequested.connect(self._apply_responsive_layout)
        self._responsive_controller.schedule(force=True)
        self._bind()
        self._load_initial()

    def _permissions(self) -> dict[str, bool]:
        return dict(self.catalog_service.permissions())

    def _build(self) -> None:
        controls = load_ui(
            self,
            "product_catalog_page",
            required=(
                "CatalogConnectionStatus",
                "CatalogNavigation",
                "CatalogStack",
                "CatalogManagementTitle",
                "catalog_header_layout",
            ),
        )
        self.header_title: QLabel = controls["CatalogManagementTitle"]
        self.header_title.setText(_("Catalog Management"))
        self.header_grid: QGridLayout = controls["catalog_header_layout"]
        self.status_label: QLabel = controls["CatalogConnectionStatus"]
        self.status_label.setText(_("Connecting to server..."))
        self.status_label.setProperty("status", "busy")
        self.status_label.setAccessibleName(_("Catalog synchronization status"))
        self.nav: QListWidget = controls["CatalogNavigation"]
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.nav.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.nav.setMinimumWidth(UI_METRICS.catalog_navigation_min_width)
        self.nav.setMaximumWidth(UI_METRICS.catalog_navigation_max_width)
        self.nav.setSpacing(UI_METRICS.catalog_navigation_spacing)
        self.stack: QStackedWidget = controls["CatalogStack"]

        permissions = self._permissions()
        for kind, label in (
            ("stored", _("Stored Products")),
            ("usage", _("Usage Products")),
        ):
            allowed = permissions[kind]
            if not allowed:
                continue
            item = QListWidgetItem(label)
            item.setData(Qt.UserRole, kind)
            self.nav.addItem(item)
            page = CatalogPage(kind, self.controller, allowed, self.stack)
            self.pages[kind] = page
            self.stack.addWidget(page)

        self.nav.currentRowChanged.connect(self._on_navigation_changed)
        if not self.nav.count():
            no_access = QFrame(self.stack)
            load_ui(
                no_access,
                "catalog_no_access",
                required=("CatalogNoAccessTitle", "CatalogNoAccessMessage"),
            )
            title = no_access.findChild(QLabel, "CatalogNoAccessTitle")
            title.setText(_("Catalog Management"))
            title.setAlignment(Qt.AlignCenter)
            message = no_access.findChild(QLabel, "CatalogNoAccessMessage")
            message.setText(_("You do not have permission to manage catalogs."))
            message.setAlignment(Qt.AlignCenter)
            message.setWordWrap(True)
            self.stack.addWidget(no_access)
            self.stack.setCurrentWidget(no_access)
            self._set_connection_status("readonly", _("Read-only"))

    def _bind(self) -> None:
        self.controller.loaded.connect(self._on_loaded)
        self.controller.mutated.connect(self._on_mutated)
        self.controller.error.connect(self._on_error)
        self.controller.busy.connect(self._on_busy)

    def _load_initial(self) -> None:
        if self.nav.count():
            # Select only after controller signals are bound. The row-change handler
            # owns the initial load so there is one request, not a duplicate.
            self.nav.setCurrentRow(0)

    def _on_navigation_changed(self, row: int) -> None:
        if row < 0 or row >= self.nav.count():
            return
        self.stack.setCurrentIndex(row)
        kind = str(self.nav.item(row).data(Qt.UserRole) or "")
        if kind:
            force = kind in self._pending_catalog_kinds
            self._pending_catalog_kinds.discard(kind)
            self.controller.load(kind, force=force)

    def _on_app_state_catalog_changed(self, domain, _payload=None) -> None:
        """Refresh catalog pages from the common sync signal, never a click."""
        domain_name = str(domain or "").strip().lower()
        kind = {"tracking": "stored", "usage": "usage"}.get(domain_name)
        if kind not in self.pages:
            return
        self.controller.invalidate(kind)
        self._pending_catalog_kinds.add(kind)
        if self.isVisible() and not self._catalog_sync_timer.isActive():
            self._catalog_sync_timer.start(150)

    def _refresh_synchronized_catalogs(self) -> None:
        if self._closed or not self.isVisible():
            return
        for kind in tuple(self._pending_catalog_kinds):
            self._pending_catalog_kinds.discard(kind)
            self.controller.load(kind, force=True)

    def showEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().showEvent(event)
        if self._pending_catalog_kinds and not self._catalog_sync_timer.isActive():
            self._catalog_sync_timer.start(0)

    def _set_connection_status(self, status: str, text: str) -> None:
        label = str(text or "")
        self.status_label.setProperty("status", str(status))
        self.status_label.setText(label)
        self.status_label.setToolTip(label)
        self.status_label.setAccessibleDescription(label)
        self.status_label.style().unpolish(self.status_label)
        self.status_label.style().polish(self.status_label)

    def _on_busy(self, kind: str, busy: bool) -> None:
        page = self.pages.get(kind)
        if page is not None:
            page.set_busy(busy)
        if busy:
            self._busy_sections.add(str(kind))
        else:
            self._busy_sections.discard(str(kind))
        if self._busy_sections:
            self._set_connection_status("busy", _("Syncing"))
        else:
            self._sync_connection_status()

    def _sync_connection_status(self) -> None:
        if self.controller.state.online:
            self._set_connection_status("ready", _("Live sync active"))
        else:
            self._set_connection_status("offline", _("Offline"))

    def _on_loaded(self, kind: str, rows) -> None:
        page = self.pages.get(kind)
        if page is not None:
            page.set_rows(rows)
            page.set_online(self.controller.state.online)
        self._sync_connection_status()

    def _on_mutated(self, kind: str, row) -> None:
        page = self.pages.get(kind)
        if page is not None:
            # A successful mutation contains the authoritative server revision.
            # Project it immediately; reconciliation is owned by SyncCoordinator.
            page.set_rows(self.controller.state.section(kind).rows)
            page.load_row(dict(row or {}))
            page._show_notice(_("Saved."), "success")
        # The mutation response is already the authoritative DTO for this row.
        # Reconciliation arrives through SyncCoordinator; do not add a second
        # full catalog request after every save.

    def _on_error(self, kind: str, message: str) -> None:
        page = self.pages.get(kind)
        if page is not None:
            page._show_notice(str(message), "error")
        self._sync_connection_status()

    def open_section(self, kind: str) -> None:
        for row in range(self.nav.count()):
            if self.nav.item(row).data(Qt.UserRole) == kind:
                if self.nav.currentRow() != row:
                    self.nav.setCurrentRow(row)
                return

    def _apply_responsive_layout(self, mode: str, profile) -> None:
        apply_profile_properties(self, profile)
        compact = False
        self.nav.setMinimumWidth(0 if compact else UI_METRICS.catalog_navigation_min_width)
        self.nav.setMaximumWidth(
            UI_METRICS.catalog_navigation_compact_max_width
            if compact
            else UI_METRICS.catalog_navigation_max_width
        )

        for widget in (self.header_title, self.status_label):
            self.header_grid.removeWidget(widget)
        for column in range(3):
            self.header_grid.setColumnStretch(column, 0)
        if compact:
            self.header_grid.addWidget(self.header_title, 0, 0)
            self.header_grid.addWidget(self.status_label, 0, 1, Qt.AlignRight)
            self.header_grid.setColumnStretch(0, 1)
        else:
            self.header_grid.addWidget(self.header_title, 0, 0)
            self.header_grid.addWidget(self.status_label, 0, 1)
            self.header_grid.setColumnStretch(0, 1)

        for page in self.pages.values():
            page.set_compact(compact)

    def dispose(self) -> None:
        """Release the page-owned worker scope when ContentStack disposes it."""
        if not self._closed:
            self._closed = True
            self.controller.close()


