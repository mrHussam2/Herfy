from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from PySide6.QtCore import QObject, Signal

from core.presentation import SettingsState


@dataclass
class SettingsDialogState:
    original: dict[str, Any] = field(default_factory=dict)
    current: dict[str, Any] = field(default_factory=dict)
    password_policy: dict[str, Any] = field(default_factory=dict)
    online: bool = True
    busy: bool = False

    def load(self, settings: SettingsState) -> None:
        self.original = asdict(settings)
        self.current = dict(self.original)

    @property
    def dirty(self) -> bool:
        ignored = {"expiry_runtime_snapshot"}
        return any(
            self.current.get(key) != self.original.get(key)
            for key in self.current
            if key not in ignored
        )

    def discard(self) -> None:
        self.current = dict(self.original)

    def commit(self) -> None:
        self.original = dict(self.current)


class SettingsController(QObject):
    loaded = Signal(object)
    saved = Signal(object)
    policy_loaded = Signal(object)
    password_changed = Signal(object)
    error = Signal(str)
    busy_changed = Signal(bool, str)

    def __init__(
        self,
        settings_service: Any,
        presentation_preferences: Any,
        account_security_service: Any,
        worker_registry,
        parent: QObject | None = None,
    ) -> None:
        super().__init__(parent)
        if settings_service is None:
            raise RuntimeError("SettingsController requires a composed settings service")
        if presentation_preferences is None:
            raise RuntimeError("SettingsController requires composed presentation preferences")
        self._service = settings_service
        if account_security_service is None:
            raise RuntimeError("SettingsController requires composed account security service")
        self._account_security = account_security_service
        self._presentation_preferences = presentation_preferences
        self.state = SettingsDialogState()
        if worker_registry is None:
            raise RuntimeError("SettingsController requires a worker registry")
        self.workers = worker_registry

    def _settings_service(self):
        return self._service

    def close(self) -> None:
        self.workers.close()

    def load(self) -> None:
        operation_key = "settings:state"
        if self.workers.has_active_key(operation_key):
            return
        self.busy_changed.emit(True, "loading")
        settings_service = self._settings_service()

        def _work():
            return settings_service.load()

        def _loaded(settings) -> None:
            self.state.load(settings)
            self.loaded.emit(settings)
            self.load_password_policy()

        worker = self.workers.start(
            _work,
            on_result=_loaded,
            on_error=lambda msg: self.error.emit(str(msg)),
            on_finished=lambda: self.busy_changed.emit(False, ""),
            operation_key="settings:state",
            log_exceptions=False,
        )
        if worker is None:
            self.busy_changed.emit(False, "")

    def save(self, values: dict[str, Any]) -> None:
        operation_key = "settings:state"
        if self.workers.has_active_key(operation_key):
            return
        self.busy_changed.emit(True, "saving")
        values_snapshot = dict(values or {})
        original_expiry_snapshot = dict(self.state.original.get("expiry_runtime_snapshot") or {})
        settings_service = self._settings_service()
        presentation_preferences = self._presentation_preferences

        def _work():
            service = settings_service
            result = service.save(
                values_snapshot,
                original_expiry_runtime_snapshot=original_expiry_snapshot,
            )
            settings = service.load()
            presentation_preferences.refresh()
            return result, settings

        def _saved(payload) -> None:
            result, settings = payload
            self.state.load(settings)
            self.saved.emit(result)
            self.loaded.emit(settings)

        worker = self.workers.start(
            _work,
            on_result=_saved,
            on_error=lambda msg: self.error.emit(str(msg)),
            on_finished=lambda: self.busy_changed.emit(False, ""),
            operation_key="settings:state",
            log_exceptions=False,
        )
        if worker is None:
            self.busy_changed.emit(False, "")

    def load_password_policy(self) -> None:
        security = self._account_security
        if not security.online():
            self.state.online = False
            self.policy_loaded.emit({})
            return
        self.state.online = True
        self.workers.start(
            security.password_policy,
            on_result=self._on_policy,
            on_error=lambda msg: self.error.emit(str(msg)),
            operation_key="settings:password-policy",
            log_exceptions=False,
        )

    def _on_policy(self, payload: object) -> None:
        data = dict(payload) if isinstance(payload, dict) else {}
        self.state.password_policy = data
        self.policy_loaded.emit(data)

    def change_password(self, current_password: str, new_password: str) -> None:
        security = self._account_security
        if not security.online():
            self.error.emit("Server connection is required to change the password.")
            return
        self.busy_changed.emit(True, "password")
        self.workers.start(
            lambda: security.change_password(current_password, new_password),
            on_result=lambda result: self.password_changed.emit(result),
            on_error=lambda msg: self.error.emit(str(msg)),
            on_finished=lambda: self.busy_changed.emit(False, ""),
            operation_key="settings:change-password",
            log_exceptions=False,
        )
