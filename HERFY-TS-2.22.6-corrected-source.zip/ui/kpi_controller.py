"""Presentation controller for local KPI dashboard filters."""

from __future__ import annotations

from PySide6 import QtCore

from services.kpi_analytics import SalesAnalyticsModel
from services.kpi_validation import ValidationReport
from ui.kpi_dashboard import InteractiveDashboard


class KpiDashboardController(QtCore.QObject):
    activity_logged = QtCore.Signal(str)

    def __init__(self, view: InteractiveDashboard, parent: QtCore.QObject | None = None) -> None:
        super().__init__(parent)
        self._view = view
        self._model: SalesAnalyticsModel | None = None
        self._branch: str | None = None
        self._current_year: int | None = None
        self._compare_year: int | None = None
        self._channel_filter = ""
        self._view.channelFilterChanged.connect(self._set_channel_filter)
        self._view.channelSelected.connect(self.select_channel)

    def set_report(self, report: ValidationReport | None) -> None:
        self._model = SalesAnalyticsModel(report) if report is not None else None
        self._view.set_channels(self._model.available_channels() if self._model is not None else ())
        if report is None:
            self._view.set_snapshot(None)
            return
        self.activity_logged.emit(
            f"Loaded local KPI data for {len(report.outlets)} authorized branches and {len(report.years)} years."
        )
        self.refresh()

    def set_filters(
        self, *, branch: str | None, current_year: int | None, compare_year: int | None
    ) -> None:
        self._branch = branch
        self._current_year = current_year
        self._compare_year = compare_year
        self.refresh()

    def refresh(self) -> None:
        if self._model is None or self._current_year is None:
            self._view.set_snapshot(None)
            return
        self._view.set_snapshot(
            self._model.snapshot(
                branch=self._branch,
                current_year=self._current_year,
                compare_year=self._compare_year,
            ),
            self._channel_filter,
        )

    @QtCore.Slot(str)
    def _set_channel_filter(self, channel: str) -> None:
        self._channel_filter = channel
        self.refresh()

    @QtCore.Slot(str)
    def select_channel(self, channel: str) -> None:
        self._channel_filter = channel
        self._view.select_channel(channel)
        self.refresh()
        self.activity_logged.emit(f"Filtered local KPI data by {channel}.")
