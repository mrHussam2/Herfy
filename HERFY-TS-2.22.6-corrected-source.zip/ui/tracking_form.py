from __future__ import annotations

import logging

from PySide6.QtCore import QDate, Qt
from PySide6.QtGui import QIntValidator
from PySide6.QtWidgets import QAbstractSpinBox, QApplication, QSizePolicy

from core.models import DISPLAY_DATE_FORMAT
from core.settings import _
from ui.theme import UI_METRICS, profile_for_widget
from ui.widgets import polish_button, polish_status_label

logger = logging.getLogger(__name__)


"""Tracking form construction and input behavior."""


class TrackingFormBuilderMixin:
    def _build_controls_card(self) -> None:
        S = self._S
        self.controls_card.setProperty("uiRole", "gridPanel")
        self.controls_card.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Minimum)
        controls_layout = self.tracking_controls_layout
        controls_layout.setContentsMargins(
            S(UI_METRICS.toolbar_horizontal_padding),
            S(UI_METRICS.toolbar_vertical_padding),
            S(UI_METRICS.toolbar_horizontal_padding),
            S(UI_METRICS.toolbar_vertical_padding),
        )
        controls_layout.setHorizontalSpacing(S(UI_METRICS.toolbar_horizontal_gap))
        controls_layout.setVerticalSpacing(S(UI_METRICS.toolbar_horizontal_gap))
        controls_layout.setColumnStretch(0, 1)
        self._build_status_label()
        self._build_toolbar()

    def _build_status_label(self) -> None:
        self._status_lbl = self._designer_controls["tracking_status"]
        self._status_lbl.setProperty("textRole", "mutedStatus")
        self._status_lbl.setWordWrap(True)
        self._status_lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self._status_lbl.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._status_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        polish_status_label(self._status_lbl, role="muted")

    def _build_toolbar(self) -> None:
        S = self._S
        # The complete form stays in one toolbar row.  Individual field groups
        # contain their label and input vertically, but the groups themselves
        # are never moved into a second toolbar row.
        self.toolbar_frame.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Minimum)
        self.toolbar_frame.setProperty("uiRole", "standardToolbar")
        self.toolbar_lay.setContentsMargins(0, 0, 0, 0)
        self.toolbar_lay.setHorizontalSpacing(S(UI_METRICS.toolbar_horizontal_gap))
        self.toolbar_lay.setVerticalSpacing(S(UI_METRICS.toolbar_horizontal_gap))
        self._build_form_widgets()
        self._build_toolbar_fields()
        self._tracking_toolbar_mode = ""
        self._apply_responsive_toolbar(force=True)

    def _build_form_widgets(self) -> None:
        self.branch_selector = self._designer_controls["tracking_branch"]
        self.product_entry = self._designer_controls["tracking_product"]
        self.qty_entry = self._designer_controls["tracking_quantity"]
        self.branch_selector.setObjectName("TrackingBranchInput")
        self.branch_selector.setAccessibleName(_("Branch"))
        self.branch_selector.setToolTip(_("Select the branch where this product will be tracked"))
        self.branch_selector.setMinimumWidth(self._S(UI_METRICS.tracking_branch_input_min_width))
        self.branch_selector.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
        self.product_entry.setToolTip(_("Material number or material name"))
        self.product_entry.setPlaceholderText(_("Search by material number or material name"))
        self.product_entry.setAccessibleName(_("Material number or material name"))
        self.product_entry.setClearButtonEnabled(True)
        # Keep one canonical minimum for the product control.  The field is
        # intentionally wide enough for a material number and its suggested
        # product name without squeezing the branch-specific completer.
        self.product_entry.setMinimumWidth(self._S(UI_METRICS.tracking_product_field_min_width))
        self.product_entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.qty_entry.setToolTip(_("Quantity"))
        self.qty_entry.setAccessibleName(_("Quantity"))
        self.qty_entry.setValidator(QIntValidator(1, 999999))
        self.qty_entry.setPlaceholderText(_("Qty"))
        self.qty_entry.setClearButtonEnabled(True)
        self.qty_entry.setMinimumWidth(self._S(UI_METRICS.tracking_quantity_input_min_width))
        self.qty_entry.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        date_format = DISPLAY_DATE_FORMAT
        self.prod_edit = self._designer_controls["tracking_production"]
        self.exp_edit = self._designer_controls["tracking_expiry"]
        for edit, label in (
            (self.prod_edit, _("Production date")),
            (self.exp_edit, _("Expiry date")),
        ):
            edit.setToolTip(label)
            edit.setAccessibleName(label)
            edit.setCalendarPopup(True)
            # Calendar-popup date editors should behave as one familiar
            # dropdown control, not as a miniature spinner with competing
            # arrows.  Qt keeps its native Windows calendar affordance while
            # the up/down spin buttons are removed.
            edit.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
            edit.setDisplayFormat(date_format)
            edit.setDate(QDate.currentDate())
            edit.setMinimumWidth(self._S(UI_METRICS.tracking_date_input_min_width))
            edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.btn_add = self._designer_controls["tracking_save"]
        self.btn_add.setText(_("Add item"))
        self.btn_add.setAccessibleName(_("Save item"))
        self.btn_add.setAccessibleDescription(_("Add or update tracked product"))
        self.btn_add.setShortcut("Ctrl+Return")
        polish_button(
            self.btn_add,
            role="primary",
            min_width=self._S(UI_METRICS.compact_button_min_width),
            min_height=self._S(UI_METRICS.toolbar_control_height),
            cursor=Qt.PointingHandCursor,
        )

    def _build_toolbar_fields(self) -> None:
        for label_name in (
            "tracking_branch_label",
            "tracking_product_label",
            "tracking_production_label",
            "tracking_expiry_label",
            "tracking_quantity_label",
        ):
            label = self._designer_controls[label_name]
            label.setWordWrap(True)
            label.setProperty("textRole", "fieldLabel")
        self.product_entry.setObjectName("TrackingProductInput")
        self.prod_edit.setProperty("uiRole", "trackingDateInput")
        self.exp_edit.setProperty("uiRole", "trackingDateInput")
        self.qty_entry.setObjectName("TrackingQuantityInput")
        self.btn_add.setProperty("variant", "primary")
        self.branch_field = self._designer_controls["tracking_branch_field"]
        self.product_field = self._designer_controls["tracking_product_field"]
        self.production_field = self._designer_controls["tracking_production_field"]
        self.expiry_field = self._designer_controls["tracking_expiry_field"]
        self.quantity_field = self._designer_controls["tracking_quantity_field"]
        for field in (
            self.branch_field,
            self.product_field,
            self.production_field,
            self.expiry_field,
            self.quantity_field,
        ):
            field.setObjectName("TrackingFieldGroup")
            field.setProperty("innerPanel", True)
            field.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.action_field = self.btn_add
        self._tracking_fields = [
            self.branch_field,
            self.product_field,
            self.production_field,
            self.expiry_field,
            self.quantity_field,
            self.action_field,
        ]
        self._tracking_inputs = [
            self.branch_selector,
            self.product_entry,
            self.prod_edit,
            self.exp_edit,
            self.qty_entry,
            self.btn_add,
        ]
        self._apply_control_size_policies(
            "wide", profile_for_widget(self, app=QApplication.instance())
        )

    def _selected_create_branch(self) -> str:
        return str(self.branch_selector.currentData() or "").strip()

    def _refresh_create_branch_selector(self) -> None:
        branches = [
            str(branch or "").strip()
            for branch in self._tracking_controller.branch_options()
            if str(branch or "").strip()
        ]
        current = self._selected_create_branch()
        self.branch_selector.blockSignals(True)
        self.branch_selector.clear()
        if len(branches) > 1:
            self.branch_selector.addItem(_("Select branch"), "")
        for branch in branches:
            self.branch_selector.addItem(branch, branch)
        if len(branches) == 1:
            self.branch_selector.setCurrentIndex(0)
        elif current:
            current_key = current.casefold()
            wanted = next(
                (
                    index
                    for index, branch in enumerate(branches)
                    if branch.casefold() == current_key
                ),
                -1,
            )
            # Account for the leading "Select branch" prompt in multi-branch
            # scope.  Keeping the displayed server spelling avoids a needless
            # scope error when identifiers differ only by case.
            self.branch_selector.setCurrentIndex(
                (wanted + 1) if wanted >= 0 and len(branches) > 1 else max(0, wanted)
            )
        else:
            self.branch_selector.setCurrentIndex(0 if self.branch_selector.count() else -1)
        self.branch_selector.setEnabled(len(branches) > 1)
        self.branch_selector.setProperty("branchCount", len(branches))
        self.branch_selector.blockSignals(False)
        self.branch_selector.style().unpolish(self.branch_selector)
        self.branch_selector.style().polish(self.branch_selector)
