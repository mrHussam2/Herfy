"""Windows toast and Qt system-tray notification delivery adapter."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

from PySide6.QtWidgets import QSystemTrayIcon

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.notifications import build_notification_activation_uri
from core.runtime_ports import desktop_notification_capability, send_windows_toast
from core.settings import APP_DISPLAY_NAME
from ui.widgets import app_icon

logger = logging.getLogger(__name__)


class DesktopNotifier:
    """Display branded notifications through the Windows system-tray adapter."""

    def __init__(self, main_window: Any, worker_registry) -> None:
        self._main_window = main_window
        self._last_tray_payload: dict[str, Any] = {}
        if worker_registry is None:
            raise RuntimeError("DesktopNotifier requires a worker registry")
        self._worker_registry = worker_registry
        destroyed = getattr(main_window, "destroyed", None)
        if destroyed is not None:
            try:
                destroyed.connect(lambda *_args: self.close())
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Desktop notifier close binding skipped", exc_info=True)

    def close(self) -> None:
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            try:
                registry.close()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Desktop notifier worker close skipped", exc_info=True)

    @staticmethod
    def _popup_title(title: str) -> str:
        # Windows displays the title as the notification's application identity.
        # Keep it stable and branded; alert-specific detail belongs in the body.
        del title
        return APP_DISPLAY_NAME

    def _show_qt_tray_fallback(
        self,
        title: str,
        message: str,
        duration_s: int,
    ) -> bool:
        tray = getattr(self._main_window, "tray_icon", None)
        if tray is None and hasattr(self._main_window, "_show_tray_icon"):
            try:
                self._main_window._show_tray_icon()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Unable to create tray icon for notification", exc_info=True)
            tray = getattr(self._main_window, "tray_icon", None)
        if tray is None:
            return False

        if not bool(getattr(tray, "_herfy_message_restore_connected", False)):
            try:
                tray.messageClicked.connect(self._activate_last_tray_payload)
                setattr(tray, "_herfy_message_restore_connected", True)
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Tray message restore binding failed", exc_info=True)

        try:
            if not QSystemTrayIcon.isSystemTrayAvailable():
                return False
            if not tray.supportsMessages():
                return False
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Tray notification capability check failed", exc_info=True)

        icon = app_icon()
        adapter = getattr(self._main_window, "_tray_adapter", None)
        if adapter is None and not icon.isNull():
            tray.setIcon(icon)
        if not tray.isVisible():
            tray.show()
            tray.setVisible(True)
        msecs = max(1800, int(duration_s) * 1000)
        try:
            if not icon.isNull():
                tray.showMessage(self._popup_title(title), message, icon, msecs)
            else:
                tray.showMessage(self._popup_title(title), message, tray.Information, msecs)
        except TypeError:
            tray.showMessage(self._popup_title(title), message, tray.Information, msecs)
        return True

    def show_tray_message(
        self,
        title: str,
        message: str,
        duration_s: int,
        payload: dict | None = None,
        on_result: Callable[[bool, str], None] | None = None,
    ) -> bool:
        try:
            self._last_tray_payload = dict(payload or {})
            activation_uri = build_notification_activation_uri(self._last_tray_payload)

            def _report(delivered: bool, backend: str) -> None:
                if callable(on_result):
                    on_result(bool(delivered), str(backend))

            capability = self.capability_snapshot()
            capability_known = any(
                key in capability for key in ("windows", "winrt_registered", "powershell")
            )
            native_available = bool(
                capability.get("windows")
                and capability.get("winrt_registered")
                and (capability.get("win11toast") or capability.get("powershell"))
            )
            logger.info(
                "WINDOWS_NOTIFICATION_PREFLIGHT native_available=%s winrt=%s win11toast=%s powershell=%s",
                native_available,
                bool(capability.get("winrt_registered")),
                bool(capability.get("win11toast")),
                bool(capability.get("powershell")),
            )
            if capability_known and not native_available:
                fallback_ok = self._show_qt_tray_fallback(title, message, duration_s)
                _report(fallback_ok, "TRAY_FALLBACK" if fallback_ok else "FAILED")
                return fallback_ok

            def _native_work():
                return send_windows_toast(
                    title=self._popup_title(title),
                    message=message,
                    activation_uri=activation_uri,
                )

            def _finish(delivered: bool, backend: str) -> None:
                if callable(on_result):
                    on_result(bool(delivered), str(backend))

            def _native_result(native) -> None:
                if native is not None and bool(getattr(native, "delivered", False)):
                    logger.info(
                        "WINDOWS_NOTIFICATION_DELIVERED backend=%s",
                        getattr(native, "backend", "windows_toast"),
                    )
                    backend = str(
                        getattr(native, "backend", "windows_notification") or "windows_notification"
                    ).upper()
                    _finish(True, backend)
                    return
                logger.warning(
                    "Windows toast unavailable; using Qt tray fallback detail=%s",
                    getattr(native, "detail", "adapter_not_configured"),
                )
                fallback_ok = self._show_qt_tray_fallback(title, message, duration_s)
                _finish(fallback_ok, "TRAY_FALLBACK" if fallback_ok else "FAILED")

            def _native_error(message_text: str) -> None:
                logger.warning("Windows toast worker failed: %s", message_text)
                fallback_ok = self._show_qt_tray_fallback(title, message, duration_s)
                _finish(fallback_ok, "TRAY_FALLBACK" if fallback_ok else "FAILED")

            worker = self._worker_registry.start(
                _native_work,
                on_result=_native_result,
                on_error=_native_error,
                operation_key="notifications:native_toast",
                scope_checker=lambda: getattr(self, "_main_window", None) is not None,
                log_exceptions=False,
            )
            if worker is not None:
                # Accepted for asynchronous visual delivery.  The result/error
                # callback performs the Qt fallback if native toast is unavailable.
                return True

            # Duplicate submission/closed registry/start failure: use the
            # non-blocking Qt tray path immediately and report the real result.
            fallback_ok = self._show_qt_tray_fallback(title, message, duration_s)
            _finish(fallback_ok, "TRAY_FALLBACK" if fallback_ok else "FAILED")
            return fallback_ok
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Tray notification failed")
            return False

    def capability_snapshot(self) -> dict[str, object]:
        try:
            return dict(desktop_notification_capability())
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Windows notification capability check failed", exc_info=True)
            return {"windows": False, "winrt_registered": False, "powershell": False}

    def _activate_last_tray_payload(self) -> None:
        handler = getattr(self._main_window, "_activate_notification_payload", None)
        if callable(handler):
            handler(dict(self._last_tray_payload))

    # close() is defined once near __init__ and owns WorkerRegistry cleanup.
