"""One-shot desktop-notification delivery queue."""

from __future__ import annotations

import logging
from collections import deque
from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QTimer

from core.errors import SERVICE_OPERATION_EXCEPTIONS, UI_OPERATION_EXCEPTIONS
from core.models import normalize_int
from core.settings import APP_DISPLAY_NAME, _
from ui.notification_presentation import NotificationMessageFormatter

logger = logging.getLogger(__name__)


class DesktopNotificationQueue:
    """Single-shot Qt delivery queue for desktop notifications.

    The queue never polls.  Failed desktop delivery is retried from the exact
    payload with bounded, increasing one-shot delays.  Delivery state is
    committed by the owner only after a payload is actually handled.
    """

    _RETRY_DELAYS_MS = (2_000, 5_000, 15_000, 30_000, 60_000, 180_000)

    def __init__(
        self,
        main_window: Any,
        *,
        get_bool: Callable[[str, bool], bool],
        show_tray_message: Callable[..., bool],
        play_sound: Callable[[dict], None],
        on_delivered: Callable[[dict], None] | None = None,
        on_delivery_failed: Callable[[dict], None] | None = None,
        max_queue_size: int = 0,
    ) -> None:
        self.main_window = main_window
        self._get_bool = get_bool
        self._show_tray_message = show_tray_message
        self._play_sound = play_sound
        self._on_delivered = on_delivered
        self._on_delivery_failed = on_delivery_failed
        self._queue = deque()
        self._busy = False
        # Zero is intentional: alert payloads must not be silently discarded.
        self._max_queue_size = max(0, int(max_queue_size))
        self._formatter = NotificationMessageFormatter()
        self._timer = QTimer(self.main_window)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.drain)

    def enqueue(
        self,
        *,
        title: str,
        message: str,
        duration_s: int,
        status: str = "",
        entry: dict | None = None,
    ) -> bool:
        payload = self._build_payload(
            title=title,
            message=message,
            duration_s=duration_s,
            status=status,
            entry=entry,
        )
        self._queue.append(payload)
        if self._max_queue_size and len(self._queue) > self._max_queue_size:
            # A configured finite cap must fail explicitly; never discard the
            # oldest (and potentially most severe) notification silently.
            rejected = self._queue.pop()
            self._notify_delivery_failed(rejected)
            return False
        self.schedule(0)
        return True

    def schedule(self, delay_ms: int = 0) -> None:
        try:
            delay_ms = max(0, int(delay_ms))
            if self._timer.isActive():
                return
            self._timer.start(max(10, delay_ms))
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to schedule desktop notifications")

    def _build_payload(
        self,
        *,
        title: str,
        message: str,
        duration_s: int,
        status: str = "",
        entry: dict | None = None,
    ) -> dict:
        payload = {
            "title": str(title or _("Notification")),
            "app_title": APP_DISPLAY_NAME,
            "message": str(message or "").strip(),
            "duration_s": max(4, int(duration_s or 4)),
            "status": str(status or "").strip(),
            "_delivery_attempts": 0,
        }
        if entry:
            payload.update(
                {key: value for key, value in dict(entry).items() if value not in (None, "")}
            )
        return payload

    def _take_dispatch_batch(self) -> list[dict]:
        """Deliver one explicit alert at a time."""
        return [self._queue.popleft()]

    def clear(self) -> None:
        try:
            self._queue.clear()
            self._busy = False
            if self._timer.isActive():
                self._timer.stop()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to clear desktop notification queue")

    def _notify_delivered(self, payload: dict, backend: str = "") -> None:
        if callable(self._on_delivered):
            try:
                delivered_payload = dict(payload)
                delivered_payload["_desktop_backend"] = str(backend or "")
                self._on_delivered(delivered_payload)
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Failed to commit desktop notification delivery")

    def _notify_delivery_failed(self, payload: dict) -> None:
        if callable(self._on_delivery_failed):
            try:
                self._on_delivery_failed(dict(payload))
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Failed to record desktop notification delivery failure")

    def _payload_is_current_runtime(self, payload: dict) -> bool:
        try:
            generation = normalize_int(payload.get("runtime_generation"), 0)
            current_generation = int(self.main_window._runtime_generation_value())
            if generation and generation != current_generation:
                return False
            sync = getattr(self.main_window, "cloud_sync_runtime_service", None)
            if sync is None or not sync.context_attached():
                return False
            identity = sync.sync_identity_metadata()
            event_user = str(payload.get("user_identity") or "").strip().casefold()
            event_server = str(payload.get("server_identity") or "").strip().casefold()
            if event_user and event_user != str(identity.get("user_identity") or "").casefold():
                return False
            if (
                event_server
                and event_server != str(identity.get("server_identity") or "").casefold()
            ):
                return False
            event_revision = normalize_int(payload.get("authority_revision"), 0)
            if event_revision and event_revision != int(sync.authority_revision()):
                return False
            return True
        except Exception:
            logger.exception("Notification runtime identity validation failed")
            return False

    def _retry_failed_payload(self, payload: dict) -> int | None:
        attempts = max(0, normalize_int(payload.get("_delivery_attempts"), 0)) + 1
        payload["_delivery_attempts"] = attempts
        if attempts > len(self._RETRY_DELAYS_MS):
            logger.error(
                "Desktop notification delivery exhausted retries status=%s",
                payload.get("status_kind") or payload.get("status") or "",
            )
            self._notify_delivery_failed(payload)
            return None
        self._queue.appendleft(payload)
        return self._RETRY_DELAYS_MS[attempts - 1]

    def drain(self) -> None:
        if self._busy or not self._queue:
            return
        self._busy = True
        payload = self._take_dispatch_batch()[0]
        duration_s = max(4, min(60, normalize_int(payload.get("duration_s"), 4)))

        def finish_queue(delay_ms: int | None = None) -> None:
            self._busy = False
            if self._queue:
                next_delay = (
                    delay_ms
                    if delay_ms is not None
                    else max(900, min(duration_s * 1000 + 500, 2800))
                )
                self._timer.start(max(10, int(next_delay)))

        if not self._payload_is_current_runtime(payload):
            logger.info(
                "NOTIFICATION_DISCARDED_STALE_RUNTIME key=%s", payload.get("notification_key") or ""
            )
            self._notify_delivery_failed(payload)
            finish_queue(10)
            return

        try:
            title = str(payload.get("title") or _("Notification"))
            if (
                payload.get("product")
                or payload.get("product_name")
                or payload.get("branch")
                or payload.get("status_kind")
            ):
                title = _("Products expiration tracking")
            message = self._formatter.format_message(payload)
            visual_payload = dict(payload)
            visual_payload["message"] = message

            desktop_enabled = self._get_bool("enable_desktop_notifications", True)
            if not desktop_enabled:
                logger.info("WINDOWS_NOTIFICATION_DELIVERY=DISABLED")
                self._notify_delivery_failed(payload)
                finish_queue(10)
                return

            def visual_result(delivered: bool, backend: str) -> None:
                try:
                    if delivered:
                        logger.info("WINDOWS_NOTIFICATION_DELIVERY=%s", backend)
                        # Sound follows confirmed visual delivery, not the first
                        # attempt. A toast that succeeds on retry must still get
                        # its one sound, while a defensive flag prevents a
                        # duplicate backend callback from playing twice.
                        if not bool(payload.get("_sound_played")):
                            self._play_sound(
                                {
                                    "status_kind": payload.get("status_kind")
                                    or payload.get("kind")
                                    or "",
                                    "severity_rank": payload.get("severity_rank"),
                                }
                            )
                            payload["_sound_played"] = True
                        self._notify_delivered(payload, backend)
                        finish_queue()
                        return
                    delay = self._retry_failed_payload(payload)
                    finish_queue(delay)
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.exception("Notification visual result handling failed")
                    delay = self._retry_failed_payload(payload)
                    finish_queue(delay)

            accepted = bool(
                self._show_tray_message(
                    title, message, duration_s, visual_payload, on_result=visual_result
                )
            )
            if not accepted:
                # Some platform adapters may reject synchronously without invoking
                # the result callback.  Do not leave the queue busy forever.
                logger.warning("Desktop notification adapter rejected delivery request")
                delay = self._retry_failed_payload(payload)
                finish_queue(delay)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Notification queue dispatch failed")
            delay = self._retry_failed_payload(payload)
            finish_queue(delay)

    def health_snapshot(self) -> dict:
        """Return queue health for settings/status diagnostics and tests."""
        try:
            return {
                "queued": len(self._queue),
                "busy": bool(self._busy),
                "timer_active": bool(self._timer.isActive()),
                "max_queue_size": int(self._max_queue_size),
            }
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Notification queue health snapshot failed", exc_info=True)
            return {
                "queued": 0,
                "busy": False,
                "timer_active": False,
                "max_queue_size": int(self._max_queue_size),
            }

    def close(self) -> None:
        try:
            self._queue.clear()
            self._busy = False
            if self._timer.isActive():
                self._timer.stop()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Notification queue shutdown failed", exc_info=True)
