"""Pure presentation helpers for desktop notification payloads."""

from __future__ import annotations

from core.models import normalize_int
from core.presentation import format_display_date
from core.settings import _


class NotificationMessageFormatter:
    """Build user-facing notification text outside Qt widget classes."""

    @staticmethod
    def clean_product_name(value: str) -> str:
        text = str(value or "").strip()
        if text.startswith("[") and "]" in text:
            text = text.split("]", 1)[1].strip()
        return text

    @staticmethod
    def explicit_store(payload: dict) -> str:
        return str(payload.get("store_name") or payload.get("store") or "").strip()

    @staticmethod
    def branch_label(payload: dict) -> str:
        value = str(payload.get("branch") or "").strip()
        named_branch = str(payload.get("branch_label") or payload.get("branch_name") or "").strip()
        if not value:
            value = named_branch
        if not value:
            return ""
        compact = value.replace(" ", "")
        if compact.upper().startswith("H") and compact[1:].isdigit():
            value = compact[1:]
            compact = value
        if compact.isdigit():
            value = f"#{compact}"
        if named_branch and named_branch.casefold() != value.casefold():
            value = f"{value} — {named_branch}"
        region = str(payload.get("region") or payload.get("area") or "").strip()
        return f"{value} ({region})" if value and region else value

    @staticmethod
    def int_or_none(value) -> int | None:
        try:
            if value in (None, ""):
                return None
            return int(value)
        except (TypeError, ValueError):
            return None

    def days_line(self, payload: dict) -> tuple[str, str]:
        days_expired = self.int_or_none(payload.get("days_expired"))
        days_remaining = self.int_or_none(payload.get("days_remaining"))
        kind = str(payload.get("status_kind") or payload.get("kind") or "").lower()
        days_text = str(payload.get("days_text") or "").strip()
        is_overdue = bool(days_expired and days_expired > 0) or kind == "expired"
        if days_remaining is not None and days_remaining < 0:
            is_overdue = True
            days_expired = abs(days_remaining)
        if is_overdue:
            count = days_expired if days_expired is not None else None
            value = (
                f"{count} {(_('Day') if count == 1 else _('Days'))}"
                if count is not None
                else days_text
            )
            return (_("Overdue"), value.strip())
        if days_remaining is not None:
            value = f"{days_remaining} {(_('Day') if days_remaining == 1 else _('Days'))}"
            return (_("Days Remaining"), value.strip())
        return (_("Days Remaining"), days_text) if days_text else ("", "")

    @staticmethod
    def status_display(payload: dict) -> str:
        kind = str(payload.get("status_kind") or payload.get("kind") or "").strip().lower()
        mapping = {
            "expired": _("Expired"),
            "expires_today": _("Expires today"),
            "expires_tomorrow": _("Expires tomorrow"),
            "expiring_high": _("Critical"),
            "expiring_soon": _("Expiring Soon"),
            "valid": _("Valid"),
        }
        if kind in mapping:
            return str(mapping[kind])
        # Unknown legacy/display text may be shown, but it never determines
        # the domain status or severity.
        return str(payload.get("status_label") or payload.get("status") or "").strip()

    def format_message(self, payload: dict) -> str:
        product = self.clean_product_name(
            str(
                payload.get("product")
                or payload.get("product_name")
                or payload.get("item_name")
                or ""
            )
        )
        status = self.status_display(payload)
        store = self.explicit_store(payload)
        branch = self.branch_label(payload)
        material = str(payload.get("material_number") or "").strip()
        expiry_date = format_display_date(payload.get("expiry_date"), fallback="")
        fallback = str(payload.get("message") or "").strip()
        quantity = self.int_or_none(payload.get("quantity"))
        lines: list[str] = []
        # Keep the first five lines stable for Windows balloon notifications.  They are
        # deliberately the fields operators need without opening the application.
        lines.append(f"{_('Branch')}: {branch or store or '-'}")
        lines.append(f"{_('Item Name')}: {product or '-'}")
        lines.append(f"{_('Expiry Date')}: {expiry_date or '-'}")
        lines.append(f"{_('Quantity')}: {quantity if quantity is not None else '-'}")
        lines.append(f"{_('Status')}: {status or '-'}")
        days_label, days_value = self.days_line(payload)
        if days_label and days_value:
            lines.append(f"{days_label}: {days_value}")
        if material:
            lines.append(f"{_('Material number')}: {material}")
        body = "\n".join(lines).strip()
        return body or fallback

    @staticmethod
    def severity_rank(payload: dict) -> int:
        return normalize_int(payload.get("severity_rank"), 0)
