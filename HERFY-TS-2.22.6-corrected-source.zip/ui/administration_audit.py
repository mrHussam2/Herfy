"""Server-authoritative administrative audit presentation."""

from __future__ import annotations

from typing import Any

from PySide6.QtCore import QSortFilterProxyModel, Qt, Signal
from PySide6.QtWidgets import (
    QGridLayout,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QWidget,
)

from core.presentation import format_display_datetime
from core.settings import _
from ui.administration_components import AdminTableModel, AdminTableView, DetailsPanel
from ui.administration_controller import AdministrationPresenter
from ui.designer import load_ui
from ui.widgets import DataSurface


class AuditFilter(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.needle = ""
        self.setDynamicSortFilter(True)
        self.setSortCaseSensitivity(Qt.CaseInsensitive)

    def set_needle(self, text):
        self.needle = str(text or "").casefold()
        self.beginFilterChange()
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)

    def filterAcceptsRow(self, row, parent):
        if not self.needle:
            return True
        data = self.sourceModel().data(self.sourceModel().index(row, 0, parent), Qt.UserRole) or {}
        return self.needle in str(data).casefold()


class AuditSection(QWidget):
    entity_requested = Signal(str, str)

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller

        controls = load_ui(
            self,
            "admin_audit_section",
            required=(
                "AdminCountBadge",
                "admin_audit_back",
                "admin_audit_view",
                "admin_audit_more",
                "AdminFilterSearch",
                "AdminFilterCount",
                "admin_audit_collection",
                "admin_audit_table_host",
                "admin_audit_details_host",
                "admin_audit_master_grid",
                "admin_audit_header_layout",
            ),
        )
        self.count_badge: QLabel = controls["AdminCountBadge"]
        self.header_grid: QGridLayout = controls["admin_audit_header_layout"]
        self.back: QPushButton = controls["admin_audit_back"]
        self.view_event: QPushButton = controls["admin_audit_view"]
        self.load_more: QPushButton = controls["admin_audit_more"]
        self.back.setText(_("Back to audit log"))
        self.back.setProperty("variant", "secondary")
        self.back.hide()
        self.view_event.setText(_("View event"))
        self.view_event.setProperty("variant", "primary")
        self.view_event.setEnabled(False)
        self.load_more.setText(_("Load more"))
        self.load_more.setProperty("variant", "secondary")
        self.load_more.hide()
        self.load_more.clicked.connect(self.controller.load_more_audit)
        self.collection: QWidget = controls["admin_audit_collection"]
        self.search: QLineEdit = controls["AdminFilterSearch"]
        self.search.setPlaceholderText(_("Search audit..."))
        self.search.setClearButtonEnabled(True)
        self.filter_count: QLabel = controls["AdminFilterCount"]
        self.model = AdminTableModel(
            [
                (
                    _("Timestamp"),
                    lambda row: format_display_datetime(row.get("created_at"), fallback=""),
                    "created_at",
                ),
                (_("Actor"), "actor_user_id"),
                (_("Action"), "action"),
                (_("Target type"), "target_type"),
                (_("Target"), "target_id"),
                (_("Scope"), lambda row: self._scope_text(row)),
                (
                    _("Result"),
                    lambda row: str(
                        row.get("result") or (row.get("details") or {}).get("result") or "—"
                    ),
                ),
            ],
            self,
        )
        self.proxy = AuditFilter(self)
        self.proxy.setSourceModel(self.model)
        self.table = AdminTableView(self.collection)
        self.table.setModel(self.proxy)
        self.table.sortByColumn(0, Qt.DescendingOrder)
        self.table_surface = DataSurface(self.table, self.collection)
        controls["admin_audit_table_host"].layout().addWidget(self.table_surface)
        self.details_host: QWidget = controls["admin_audit_details_host"]
        self.details = DetailsPanel(self.details_host)
        self.details_host.layout().addWidget(self.details)
        self.details.hide()
        self.master_detail_layout: QGridLayout = controls["admin_audit_master_grid"]
        self.master_detail_layout.setColumnStretch(0, 3)
        self.master_detail_layout.setColumnStretch(1, 2)
        self._master_detail_compact = False

        self.search.textChanged.connect(self._filter_changed)
        self.table.selectionModel().selectionChanged.connect(self._selected)
        self.table.doubleClicked.connect(lambda _index: self._show_current_event())
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.view_event.clicked.connect(self._show_current_event)
        self.back.clicked.connect(self._show_collection)
        self._show_collection_layout()

    def set_compact_mode(self, compact: bool) -> None:
        compact = bool(compact)
        for column in range(self.model.columnCount()):
            self.table.setColumnHidden(column, False)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)

        for widget in (self.count_badge, self.back, self.view_event, self.load_more):
            self.header_grid.removeWidget(widget)
        for column in range(6):
            self.header_grid.setColumnStretch(column, 0)
        if compact:
            self.header_grid.addWidget(self.count_badge, 1, 0)
            self.header_grid.addWidget(self.back, 1, 1)
            self.header_grid.addWidget(self.view_event, 1, 2)
            self.header_grid.addWidget(self.load_more, 1, 3)
            for column in range(4):
                self.header_grid.setColumnStretch(column, 1)
        else:
            self.header_grid.addWidget(self.count_badge, 0, 2)
            self.header_grid.addWidget(self.back, 0, 3)
            self.header_grid.addWidget(self.view_event, 0, 4)
            self.header_grid.addWidget(self.load_more, 0, 5)
            self.header_grid.setColumnStretch(0, 1)

        if self._master_detail_compact == compact:
            return
        self._master_detail_compact = compact
        if self.details.isHidden():
            self._show_collection_layout()
        else:
            self._show_split_layout()

    def _show_split_layout(self) -> None:
        self.master_detail_layout.removeWidget(self.collection)
        self.master_detail_layout.removeWidget(self.details_host)
        if self._master_detail_compact:
            self.master_detail_layout.addWidget(self.collection, 0, 0, 1, 2)
            self.master_detail_layout.addWidget(self.details_host, 1, 0, 1, 2)
            self.master_detail_layout.setColumnStretch(0, 1)
            self.master_detail_layout.setColumnStretch(1, 0)
            self.master_detail_layout.setRowStretch(0, 3)
            self.master_detail_layout.setRowStretch(1, 2)
        else:
            self.master_detail_layout.addWidget(self.collection, 0, 0)
            self.master_detail_layout.addWidget(self.details_host, 0, 1)
            self.master_detail_layout.setColumnStretch(0, 3)
            self.master_detail_layout.setColumnStretch(1, 2)
            self.master_detail_layout.setRowStretch(0, 1)
            self.master_detail_layout.setRowStretch(1, 0)

    def _show_collection_layout(self) -> None:
        """Give the event table the workspace until an inspector is requested."""
        self.master_detail_layout.removeWidget(self.collection)
        self.master_detail_layout.removeWidget(self.details_host)
        self.master_detail_layout.addWidget(self.collection, 0, 0, 1, 2)
        self.master_detail_layout.setColumnStretch(0, 1)
        self.master_detail_layout.setColumnStretch(1, 0)
        self.master_detail_layout.setRowStretch(0, 1)
        self.master_detail_layout.setRowStretch(1, 0)

    @staticmethod
    def _scope_text(row: dict[str, Any]) -> str:
        scope = row.get("scope") if isinstance(row.get("scope"), dict) else {}
        kind = str(scope.get("type") or "")
        ids = [str(value) for value in scope.get("ids") or [] if str(value)]
        if not kind and not ids:
            return "—"
        return f"{kind}: {', '.join(ids)}" if ids else kind

    def set_events(self, rows: list[dict[str, Any]]) -> None:
        values = [dict(item) for item in rows if isinstance(item, dict)]
        self.model.replace_rows(values)
        self.count_badge.setText(str(len(values)))
        self.table.sortByColumn(0, Qt.DescendingOrder)
        self._filter_changed(self.search.text())
        self._selected()

    def set_has_more(self, has_more: bool) -> None:
        self.load_more.setVisible(bool(has_more) and self.details.isHidden())
        self.load_more.setEnabled(bool(has_more))

    def _filter_changed(self, text: str) -> None:
        self.proxy.set_needle(text)
        shown = self.proxy.rowCount()
        total = self.model.rowCount()
        self.filter_count.setText(f"{shown}/{total}")
        self.table_surface.set_state("content")

    def _current(self):
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return None
        source = self.proxy.mapToSource(rows[0])
        return self.model.row_payload(source.row())

    def _selected(self, *_args) -> None:
        row = self._current()
        self.view_event.setEnabled(row is not None)
        if row is not None and self.details.isHidden():
            self._show_current_event()

    def _show_current_event(self) -> None:
        row = self._current()
        if not row:
            return
        details = row.get("details") if isinstance(row.get("details"), dict) else {}
        diff = AdministrationPresenter.audit_diff(details)
        self.details.set_details(
            _("Audit event"),
            [
                (_("Timestamp"), format_display_datetime(row.get("created_at"), fallback="")),
                (_("Actor"), str(row.get("actor_user_id") or "")),
                (_("Action"), str(row.get("action") or "")),
                (
                    _("Target"),
                    f"{row.get('target_type', '')} • {row.get('target_id', '')}",
                ),
                (_("Scope"), self._scope_text(row)),
                (_("Result"), str(row.get("result") or details.get("result") or "—")),
                (_("Changes"), diff or str(details)),
            ],
            subtitle=format_display_datetime(row.get("created_at"), fallback=""),
        )
        self.details.show()
        self._show_split_layout()
        self.back.show()
        self.view_event.hide()
        self.load_more.hide()

    def _show_collection(self) -> None:
        self.details.hide()
        self._show_collection_layout()
        self.back.hide()
        self.view_event.show()
        self.view_event.setEnabled(self._current() is not None)
        self.load_more.setVisible(bool(self.load_more.isEnabled()))

    def _open_target(self) -> None:
        row = self._current()
        if row:
            self.entity_requested.emit(
                str(row.get("target_type") or ""), str(row.get("target_id") or "")
            )

    def _open_actor(self) -> None:
        row = self._current()
        if row and row.get("actor_user_id"):
            self.entity_requested.emit("user", str(row.get("actor_user_id")))

    def _context_menu(self, pos) -> None:
        index = self.table.indexAt(pos)
        if index.isValid() and not self.table.selectionModel().isSelected(index):
            self.table.selectRow(index.row())
        row = self._current()
        if not row:
            return
        menu = QMenu(self)
        menu.addAction(_("View event"), self._show_current_event)
        if row.get("target_id"):
            menu.addAction(_("Open target"), self._open_target)
        if row.get("actor_user_id"):
            menu.addAction(_("Open actor"), self._open_actor)
        menu.exec(self.table.viewport().mapToGlobal(pos))
