"""Window activation presentation helper, independent from application runtime."""

from __future__ import annotations

import logging
import sys

logger = logging.getLogger(__name__)


def _activate_native_window(window: object) -> None:
    """Best-effort Windows foreground activation without changing Qt state."""
    if not sys.platform.startswith("win"):
        return
    try:
        import win32gui

        win_id = getattr(window, "winId", None)
        if not callable(win_id):
            return
        hwnd = int(win_id())
        if hwnd > 0:
            win32gui.BringWindowToTop(hwnd)
            win32gui.SetForegroundWindow(hwnd)
    except (ImportError, AttributeError, OSError, TypeError, ValueError):
        logger.debug("Native window activation was unavailable", exc_info=True)
    except Exception:
        logger.debug("Windows rejected native foreground activation", exc_info=True)


def reveal_window(window: object) -> None:
    """Reveal and activate a QWidget-like window without resetting its state."""
    maximized = (
        bool(window.isMaximized()) if callable(getattr(window, "isMaximized", None)) else False
    )
    minimized = (
        bool(window.isMinimized()) if callable(getattr(window, "isMinimized", None)) else False
    )
    if maximized and callable(getattr(window, "showMaximized", None)):
        window.showMaximized()
    elif minimized and callable(getattr(window, "showNormal", None)):
        window.showNormal()
    elif callable(getattr(window, "show", None)):
        window.show()
    if callable(getattr(window, "raise_", None)):
        window.raise_()
    if callable(getattr(window, "activateWindow", None)):
        window.activateWindow()
    _activate_native_window(window)
