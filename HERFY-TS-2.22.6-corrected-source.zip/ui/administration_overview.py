"""Server-authoritative overview presentation for Administration."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFrame, QGridLayout, QLabel, QPushButton, QWidget

from core.settings import _
from ui.administration_controller import AdministrationPresenter
from ui.designer import load_ui


class _Metric(QFrame):
    clicked = Signal(str)

    def __init__(self, label: str, route: str, parent=None, *, tone: str = "blue"):
        super().__init__(parent)
        self._route = str(route or "")
        self.setCursor(Qt.PointingHandCursor)
        self.setProperty("interactive", True)
        self.setProperty("metricTone", str(tone or "blue"))
        self.setObjectName("AdminOverviewMetric")
        controls = load_ui(
            self,
            "admin_overview_metric",
            required=("AdminMetricValue", "AdminMetricLabel"),
        )
        self.value: QLabel = controls["AdminMetricValue"]
        self.label: QLabel = controls["AdminMetricLabel"]
        self.label.setText(label)
        self.value.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.label.setAttribute(Qt.WA_TransparentForMouseEvents, True)

    def set_value(self, value) -> None:
        self.value.setText("—" if value is None else str(value))

    def mouseReleaseEvent(self, event) -> None:
        super().mouseReleaseEvent(event)
        if event.button() == Qt.LeftButton and self._route:
            self.clicked.emit(self._route)


class _AuthorityFact(QFrame):
    def __init__(self, label: str, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminAuthorityFact")
        controls = load_ui(
            self,
            "admin_authority_fact",
            required=("AdminAuthorityFactLabel", "AdminAuthorityFactValue"),
        )
        self.label: QLabel = controls["AdminAuthorityFactLabel"]
        self.value: QLabel = controls["AdminAuthorityFactValue"]
        self.label.setText(label)

    def set_value(self, value: str, state: str = "neutral") -> None:
        self.value.setText(str(value or "—"))
        self.value.setProperty("factState", state)
        self.value.style().unpolish(self.value)
        self.value.style().polish(self.value)


class OverviewSection(QWidget):
    """Administration control centre built from server-authoritative summaries."""

    route_requested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminOverviewSection")
        self.setMinimumWidth(0)
        controls = load_ui(
            self,
            "admin_overview_section",
            required=(
                "AdminHeroRevisionBadge",
                "AdminAuthorityRevisionBadge",
                "admin_overview_open_structure",
                "admin_metrics_grid",
                "admin_facts_grid",
                "admin_overview_hero_layout",
            ),
        )
        self.findChild(QLabel, "AdminOverviewHeroTitle").setText(_("Operational control centre"))
        self.hero_subtitle: QLabel = self.findChild(QLabel, "AdminOverviewHeroSubtitle")
        self.hero_subtitle.setText(
            _("Review organization health, people, access and branch readiness.")
        )
        self.findChild(QLabel, "AdminOverviewSectionTitle").setText(_("Workspace snapshot"))
        self.findChild(QLabel, "AdminCardTitle").setText(_("Authority & scope model"))
        self.hero_layout: QGridLayout = controls["admin_overview_hero_layout"]
        self.hero_copy: QWidget = self.findChild(QWidget, "AdminOverviewHeroCopy")
        self.hero_revision_badge: QLabel = controls["AdminHeroRevisionBadge"]
        self.authority_revision_badge: QLabel = controls["AdminAuthorityRevisionBadge"]
        self.open_structure: QPushButton = controls["admin_overview_open_structure"]
        self.open_structure.setText(_("Open structure"))
        self.open_structure.setProperty("variant", "primary")
        self.open_structure.clicked.connect(lambda: self.route_requested.emit("structure"))
        self.metrics_grid: QGridLayout = controls["admin_metrics_grid"]
        self.facts: QGridLayout = controls["admin_facts_grid"]
        self.employees = _Metric(_("Employees"), "employees", self, tone="blue")
        self.branch_accounts = _Metric(_("Branch Accounts"), "branch_accounts", self, tone="cyan")
        self.regions = _Metric(_("Regions"), "structure", self, tone="violet")
        self.areas = _Metric(_("Areas"), "structure", self, tone="amber")
        self.branches = _Metric(_("Branches"), "structure", self, tone="green")
        self._metrics = [
            self.employees,
            self.branch_accounts,
            self.regions,
            self.areas,
            self.branches,
        ]
        self._compact = False
        for metric in self._metrics:
            metric.clicked.connect(self.route_requested)
        self._layout_metrics()
        authority = self.findChild(QFrame, "AdminAuthorityCard")
        self.mixed = _AuthorityFact(_("Mixed scope types"), authority)
        self.multiple = _AuthorityFact(_("Multiple direct scopes"), authority)
        self.inheritance = _AuthorityFact(_("Inheritance"), authority)
        self.scope_types = _AuthorityFact(_("Allowed scope types"), authority)
        self._facts = [self.mixed, self.multiple, self.inheritance, self.scope_types]
        self._layout_facts()

    def _layout_metrics(self) -> None:
        while self.metrics_grid.count():
            self.metrics_grid.takeAt(0)
        # This page lives inside the fixed desktop workspace.  Comparing this
        # *inner* width with a top-level window breakpoint used to collapse
        # the grid whenever the user merely resized the shell.  Preserve the
        # five visual landmarks and let the shell's desktop minimum guard the
        # available space instead.
        columns = 5
        for column in range(5):
            self.metrics_grid.setColumnStretch(column, 1 if column < columns else 0)
        for index, metric in enumerate(self._metrics):
            self.metrics_grid.addWidget(metric, index // columns, index % columns)

    def _layout_facts(self) -> None:
        while self.facts.count():
            self.facts.takeAt(0)
        columns = 2
        self.facts.setColumnStretch(0, 1)
        self.facts.setColumnStretch(1, 1 if columns == 2 else 0)
        for index, fact in enumerate(self._facts):
            self.facts.addWidget(fact, index // columns, index % columns)

    def set_compact_mode(self, compact: bool) -> None:
        compact = bool(compact)
        self._compact = compact
        self.hero_subtitle.setVisible(not compact)
        self.hero_revision_badge.hide()  # Revision remains in the authority card.
        self.hero_layout.removeWidget(self.open_structure)
        self.hero_layout.addWidget(self.open_structure, 1 if compact else 0, 0 if compact else 2)
        self.hero_layout.setColumnStretch(0, 1)
        self.hero_layout.setColumnStretch(1, 0)
        self.hero_layout.setColumnStretch(2, 0)
        self._layout_metrics()
        self._layout_facts()

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        if hasattr(self, "_facts"):
            # The surrounding Administration page owns the desktop layout
            # contract.  A child viewport must not independently move the
            # hero action, hide copy, or stack facts during a resize.
            self.set_compact_mode(False)

    @staticmethod
    def _supported(value: bool) -> tuple[str, str]:
        return (_("Supported"), "positive") if value else (_("Not supported"), "neutral")

    @staticmethod
    def _inheritance_label(value: str) -> str:
        if value == "parent_expands_effective_scope_only":
            return _("Parent expands effective scope only")
        return str(value or "—").replace("_", " ").strip().capitalize() or "—"

    def set_snapshot(self, snapshot):
        summary = snapshot.get("summary") if isinstance(snapshot.get("summary"), dict) else {}
        users_available = "users" in snapshot
        users = [item for item in snapshot.get("users") or [] if isinstance(item, dict)]
        self.employees.set_value(
            sum(1 for item in users if not AdministrationPresenter.is_branch_account(item))
            if users_available
            else None
        )
        self.branch_accounts.set_value(
            sum(1 for item in users if AdministrationPresenter.is_branch_account(item))
            if users_available
            else None
        )
        self.regions.set_value(summary.get("regions"))
        self.areas.set_value(summary.get("areas"))
        self.branches.set_value(summary.get("branches"))

        model = AdministrationPresenter.scope_model(snapshot)
        revision_text = _("Revision {revision}").format(
            revision=snapshot.get("authority_revision", "—")
        )
        self.hero_revision_badge.setText(revision_text)
        self.authority_revision_badge.setText(revision_text)
        text, state = self._supported(bool(model.get("allow_mixed_types")))
        self.mixed.set_value(text, state)
        text, state = self._supported(bool(model.get("allow_multiple")))
        self.multiple.set_value(text, state)
        self.inheritance.set_value(
            self._inheritance_label(str(model.get("inheritance_mode") or ""))
        )
        allowed = [
            _(str(kind).replace("_", " ").title())
            for kind in model.get("allowed_types") or []
            if str(kind)
        ]
        self.scope_types.set_value(" • ".join(allowed) if allowed else "—")
