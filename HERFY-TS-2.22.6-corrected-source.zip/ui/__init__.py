"""HERFY-TS UI package."""

from __future__ import annotations

import importlib.util

if importlib.util.find_spec("PySide6") is not None:
    import infra.bootstrap as _qt6_bootstrap  # noqa: F401
