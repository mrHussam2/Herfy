"""Notification lifecycle orchestration and in-app badge updates."""

from __future__ import annotations

import logging
import time
from typing import Any

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import business_now, normalize_int, parse_bool
from core.settings import _
from ui.notification_desktop import DesktopNotifier
from ui.notification_queue import DesktopNotificationQueue
from ui.notification_sound import SoundNotifier

logger = logging.getLogger(__name__)
# Delivery presentation policy and expiry classification are not user-configurable.
NOTIFICATION_DURATION_SECONDS = 8


class NotificationBadgeUpdater:
    def __init__(self, main_window: Any) -> None:
        self.main_window = main_window

    def update(self) -> None:
        mw = self.main_window
        try:
            unread_count = sum(
                1
                for item in mw.notifications_list or []
                if not parse_bool((item or {}).get("read"), False)
            )
            mw.unread_notifications = int(unread_count)
            button = getattr(mw, "btn_notifications", None)
            set_count = getattr(button, "set_count", None)
            if callable(set_count):
                set_count(unread_count)
            mw.btn_notifications.setToolTip(
                _("Notifications") + (f" ({unread_count})" if unread_count else "")
            )
            mw.lbl_notif_count.hide()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Failed to update notifications badge", exc_info=True)


class NotificationService:
    def __init__(self, main_window, *, worker_registry, notification_runtime):
        self.main_window = main_window
        self.runtime = notification_runtime
        # Notification persistence/evaluation has its own lifetime.  It is
        # cancelled with the runtime generation by UiWorkerScopeFactory, not
        # when a page-level worker registry is recreated during navigation.
        self._worker_registry = worker_registry
        self.desktop_notifier = DesktopNotifier(main_window, self._worker_registry)
        self.sound_notifier = SoundNotifier(self.runtime)
        self.badge_updater = NotificationBadgeUpdater(main_window)
        self._pending_delivery: dict[str, tuple[str, int]] = {}
        self._pending_alert_evaluation: list[dict] = []
        self._pending_delivery_commit: list[dict] = []
        self._last_health_check_at = 0.0
        capability = self.desktop_notifier.capability_snapshot()
        logger.info(
            "NOTIFICATION_ENGINE_STARTED=PASS backend=winrt_with_qt_tray_fallback windows=%s winrt_registered=%s powershell=%s",
            bool(capability.get("windows")),
            bool(capability.get("winrt_registered")),
            bool(capability.get("powershell")),
        )
        self.desktop_queue = DesktopNotificationQueue(
            main_window,
            get_bool=self._get_bool,
            show_tray_message=self.desktop_notifier.show_tray_message,
            play_sound=self.sound_notifier.play,
            on_delivered=self._mark_desktop_payload_delivered,
            on_delivery_failed=self._mark_desktop_payload_failed,
        )

    def _start_background_worker(
        self,
        work,
        *,
        on_result=None,
        on_finished=None,
        warning_message: str,
        operation_key: str,
    ):
        """Run notification lifecycle I/O in the service-owned worker scope."""
        try:
            generation = int(self.main_window._runtime_generation_value())
        except SERVICE_OPERATION_EXCEPTIONS:
            generation = None

        def _scope_is_current() -> bool:
            if generation is None:
                return True
            try:
                return bool(self.main_window._runtime_generation_is_current(generation))
            except SERVICE_OPERATION_EXCEPTIONS:
                return False

        return self._worker_registry.start(
            work,
            on_result=on_result,
            on_finished=on_finished,
            on_error=lambda message: logger.warning("%s: %s", warning_message, message),
            operation_key=operation_key,
            scope_checker=_scope_is_current,
            log_exceptions=False,
        )

    def alert_key(self, event: dict) -> str:
        """Expose canonical alert identity without leaking the policy engine to views."""
        return self.runtime.alert_key(event)

    def _get_setting(self, key: str, default=None):
        try:
            return self.runtime.get_setting(key, default)
        except SERVICE_OPERATION_EXCEPTIONS:
            return default

    def _get_bool(self, key: str, default: bool = False) -> bool:
        try:
            return self.runtime.get_bool(key, default)
        except SERVICE_OPERATION_EXCEPTIONS:
            return bool(default)

    def _enqueue_desktop_notification(
        self,
        *,
        title: str,
        message: str,
        duration_s: int,
        status: str = "",
        entry: dict | None = None,
    ) -> bool:
        return bool(
            self.desktop_queue.enqueue(
                title=title,
                message=message,
                duration_s=duration_s,
                status=status,
                entry=entry,
            )
        )

    def test_local_notification(self, on_result=None) -> bool:
        """Exercise the real desktop path: native Windows Toast, then tray fallback."""
        duration_s = NOTIFICATION_DURATION_SECONDS
        test_key = f"expiry-notification-test|{time.time_ns()}"
        payload = {
            "source": "local-expiry-test",
            "product_name": "HERFY-TS",
            "status": _("Expiring Soon"),
            "severity_rank": 3,
            "notification_key": test_key,
        }
        recorded_at = business_now().isoformat(timespec="seconds")
        self._record_history_entries(
            [
                {
                    "title": _("Products expiration tracking"),
                    "product": "HERFY-TS",
                    "status": _("Expiring Soon"),
                    "message": _("Windows notification test"),
                    "notification_key": test_key,
                    "lifecycle": "IN_APP_RECORDED",
                    "in_app_recorded": True,
                    "in_app_recorded_at": recorded_at,
                    "desktop_delivered": False,
                    "desktop_backend": "",
                    "read": False,
                }
            ]
        )
        item_name_label = _("Item Name")
        status_label = _("Status")
        expiring_soon_text = _("Expiring Soon")
        message = "\n".join(
            (
                _("Windows notification test"),
                f"{item_name_label}: HERFY-TS",
                f"{status_label}: {expiring_soon_text}",
            )
        )

        def _test_delivery_result(delivered: bool, backend: str) -> None:
            logger.info(
                "EXPIRY_NOTIFICATION_TEST_DELIVERY=%s backend=%s",
                "PASS" if delivered else "FAIL",
                backend,
            )
            timestamp = business_now().isoformat(timespec="seconds")
            changed = False
            for item in list(getattr(self.main_window, "notifications_list", []) or []):
                if str(item.get("notification_key") or "") != test_key:
                    continue
                item["desktop_delivered"] = bool(delivered)
                item["desktop_backend"] = str(backend or "")
                item["lifecycle"] = "PRESENTED" if delivered else "IN_APP_RECORDED_DESKTOP_FAILED"
                if delivered:
                    item["desktop_delivered_at"] = timestamp
                    item["presented_at"] = timestamp
                changed = True
            if changed:
                queue_persist = getattr(self.main_window, "_queue_notification_persist", None)
                if callable(queue_persist):
                    queue_persist(list(getattr(self.main_window, "notifications_list", []) or []))
                self.badge_updater.update()
                refresh = getattr(self.main_window, "_refresh_notifications_ui", None)
                if callable(refresh):
                    try:
                        refresh(list(getattr(self.main_window, "notifications_list", []) or []))
                    except SERVICE_OPERATION_EXCEPTIONS:
                        logger.exception("Failed to refresh notification test history")
            if delivered and self._get_bool("enable_sounds", True):
                try:
                    self.sound_notifier.play({"status_kind": "expiring_soon"})
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Notification test sound failed", exc_info=True)
            if callable(on_result):
                try:
                    on_result(bool(delivered), str(backend or ""))
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Notification test result callback failed", exc_info=True)

        accepted = self.desktop_notifier.show_tray_message(
            _("Products expiration tracking"),
            message,
            duration_s,
            payload=payload,
            on_result=_test_delivery_result,
        )
        logger.info("EXPIRY_NOTIFICATION_TEST_ACCEPTED=%s", "PASS" if accepted else "FAIL")
        return bool(accepted)

    def _register_pending_delivery(self, records: list[dict]) -> None:
        for record in records:
            key = str(record.get("key") or "")
            if not key:
                continue
            self._pending_delivery[key] = (
                str(record.get("fingerprint") or ""),
                normalize_int(record.get("severity_rank"), 0),
            )

    def _release_pending_delivery(self, records: list[dict]) -> None:
        for record in records:
            key = str(record.get("key") or "")
            current = self._pending_delivery.get(key)
            if current is None:
                continue
            if current[0] == str(record.get("fingerprint") or ""):
                self._pending_delivery.pop(key, None)

    @staticmethod
    def _payload_delivery_records(payload: dict) -> list[dict]:
        records = payload.get("_delivery_records") or []
        if isinstance(records, dict):
            records = [records]
        return [dict(record) for record in records if isinstance(record, dict)]

    def _queue_delivery_commit(self, records: list[dict], *, now_ts: float | None = None) -> None:
        """Commit successful desktop delivery state outside the Qt thread."""
        registry = self._worker_registry
        if registry is None:
            return
        stamp = float(now_ts or time.time())
        for record in records:
            if not isinstance(record, dict):
                continue
            item = dict(record)
            item["_commit_ts"] = stamp
            self._pending_delivery_commit.append(item)
        if registry.has_active_key("notifications:delivery-commit"):
            return
        current = list(self._pending_delivery_commit)
        self._pending_delivery_commit.clear()
        runtime = self.runtime

        def _work(progress_callback=None, cancel_callback=None):
            del progress_callback
            runtime.commit_delivery_records(current, cancel_callback=cancel_callback)
            return None

        def _finished():
            if self._pending_delivery_commit:
                self._queue_delivery_commit([])

        worker = self._start_background_worker(
            _work,
            on_finished=_finished,
            warning_message="Notification delivery state persistence failed",
            operation_key="notifications:delivery-commit",
        )
        if worker is None:
            self._pending_delivery_commit[0:0] = current

    def _mark_desktop_payload_delivered(self, payload: dict) -> None:
        records = self._payload_delivery_records(payload)
        if not records:
            return
        now_ts = time.time()
        self._queue_delivery_commit(records, now_ts=now_ts)
        self._release_pending_delivery(records)
        self._mark_history_lifecycle(
            records,
            "PRESENTED",
            now_ts,
            desktop_backend=str(payload.get("_desktop_backend") or ""),
            desktop_delivered=True,
        )

    def _mark_history_lifecycle(
        self,
        records: list[dict],
        lifecycle: str,
        now_ts: float | None = None,
        *,
        desktop_backend: str = "",
        desktop_delivered: bool | None = None,
    ) -> None:
        updated, changed = self.runtime.apply_delivery_lifecycle(
            list(getattr(self.main_window, "notifications_list", []) or []),
            records,
            lifecycle,
            now_ts=now_ts,
            desktop_backend=desktop_backend,
            desktop_delivered=desktop_delivered,
        )
        if changed:
            self.main_window.notifications_list = updated
            queue_persist = getattr(self.main_window, "_queue_notification_persist", None)
            if callable(queue_persist):
                queue_persist(updated)
            self.badge_updater.update()
            refresh = getattr(self.main_window, "_refresh_notifications_ui", None)
            if callable(refresh):
                try:
                    refresh(updated)
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.exception("Failed to refresh in-app notification lifecycle")

    def _mark_desktop_payload_failed(self, payload: dict) -> None:
        records = self._payload_delivery_records(payload)
        self._release_pending_delivery(records)
        if records:
            self._mark_history_lifecycle(
                records,
                "IN_APP_RECORDED_DESKTOP_FAILED",
                desktop_backend=str(payload.get("_desktop_backend") or "FAILED"),
                desktop_delivered=False,
            )
            logger.error(
                "Desktop notification was not delivered after retries keys=%s",
                ",".join(str(record.get("key") or "") for record in records),
            )
            # If desktop alerts are enabled but every Windows/tray attempt failed,
            # ask the expiry monitor for one later re-evaluation. The alert state
            # is intentionally still undelivered, so that recheck can try again.
            if self._get_bool("enable_desktop_notifications", True):
                monitor = getattr(self.main_window, "monitoring", None)
                retry = getattr(monitor, "retry", None)
                if callable(retry):
                    retry(300.0)

    def _dispatch_popup(
        self,
        title: str,
        short_msg: str,
        full_msg: str,
        status: str,
        dedupe_key: str,
        entry: dict | None = None,
        delivery_records: list[dict] | None = None,
    ) -> bool:
        dur_s = NOTIFICATION_DURATION_SECONDS
        username = self.runtime.active_username()
        if not username:
            return False
        scoped_key = self.runtime.scoped_alert_key(dedupe_key, username=username)
        if not self.runtime.mark_recent(f"popup|{scoped_key}", ttl_seconds=10.0):
            return False
        message = str(full_msg or short_msg or "").strip()
        payload_entry = dict(entry or {})
        records = [dict(record) for record in (delivery_records or []) if isinstance(record, dict)]
        if records:
            payload_entry["_delivery_records"] = records
            self._register_pending_delivery(records)
        accepted = self._enqueue_desktop_notification(
            title=title,
            message=message,
            duration_s=dur_s,
            status=status,
            entry=payload_entry,
        )
        if not accepted:
            self._release_pending_delivery(records)
        return accepted

    def _record_history_entries(self, entries: list[dict]) -> None:
        if not entries:
            return
        existing = list(getattr(self.main_window, "notifications_list", []) or [])
        merged, changed = self.runtime.merge_history(existing, list(entries or []))
        if changed:
            self.main_window.notifications_list = merged
            queue_persist = getattr(self.main_window, "_queue_notification_persist", None)
            if callable(queue_persist):
                queue_persist(merged)
            self.badge_updater.update()
            refresh = getattr(self.main_window, "_refresh_notifications_ui", None)
            if callable(refresh):
                try:
                    refresh(list(getattr(self.main_window, "notifications_list", []) or []))
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.exception("Failed to refresh in-app notifications after record")

    def _event_is_current_runtime(self, event: dict) -> bool:
        try:
            return self.runtime.event_is_current_runtime(
                event,
                runtime_generation=self.main_window._runtime_generation_value(),
            )
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Notification runtime authority validation failed")
            return False

    def _queue_alert_evaluation(self, alerts: list[dict]) -> None:
        """Coalesce alert persistence decisions onto a background worker."""
        registry = self._worker_registry
        username = self.runtime.active_username()
        if registry is None or not username:
            return
        for event in alerts:
            if isinstance(event, dict):
                self._pending_alert_evaluation.append(dict(event))
        if registry.has_active_key("notifications:evaluate"):
            return
        current = list(self._pending_alert_evaluation)
        self._pending_alert_evaluation.clear()
        pending_delivery = dict(self._pending_delivery)
        runtime = self.runtime

        def _work(progress_callback=None, cancel_callback=None):
            del progress_callback
            return runtime.evaluate_events(
                current,
                username=username,
                pending_delivery=pending_delivery,
                cancel_callback=cancel_callback,
            )

        def _apply(selected):
            self._publish_evaluated_alerts(
                [dict(event) for event in selected or [] if isinstance(event, dict)],
                username=username,
            )

        def _finished():
            if self._pending_alert_evaluation:
                self._queue_alert_evaluation([])

        worker = self._start_background_worker(
            _work,
            on_result=_apply,
            on_finished=_finished,
            warning_message="Notification alert evaluation failed",
            operation_key="notifications:evaluate",
        )
        if worker is None:
            self._pending_alert_evaluation[0:0] = current

    def _publish_evaluated_alerts(self, notify_candidates: list[dict], *, username: str) -> None:
        current = [
            dict(event)
            for event in notify_candidates
            if isinstance(event, dict) and self._event_is_current_runtime(event)
        ]
        if not current:
            return
        plan = self.runtime.build_presentation_plan(current, username=username)
        self._record_history_entries(list(plan.get("history_entries") or []))
        for item in list(plan.get("dispatch_items") or []):
            if not isinstance(item, dict):
                continue
            self._dispatch_popup(
                str(item.get("title") or ""),
                str(item.get("short_msg") or ""),
                str(item.get("full_msg") or ""),
                str(item.get("status") or ""),
                str(item.get("dedupe_key") or ""),
                entry=dict(item.get("entry") or {}),
                delivery_records=[
                    dict(record)
                    for record in list(item.get("delivery_records") or [])
                    if isinstance(record, dict)
                ],
            )

    def publish_alerts(self, alerts: list[dict]) -> None:
        username = self.runtime.active_username()
        if not username:
            return
        current = [
            dict(event)
            for event in alerts
            if isinstance(event, dict) and self._event_is_current_runtime(event)
        ]
        if current:
            self._queue_alert_evaluation(current)

    def build_event(
        self,
        product_name: str,
        qty: int,
        st_text: str,
        rd_: int,
        branch: str = "",
        material_number: str = "",
        production_date: str = "",
        expiry_date: str = "",
        severity: str | None = None,
        source: str = "local",
        severity_rank: int | None = None,
        store: str = "",
        store_name: str = "",
        branch_name: str = "",
        branch_label: str = "",
        region: str = "",
        area: str = "",
        *,
        user_identity: str = "",
        server_identity: str = "",
        authority_revision: int = 0,
        runtime_generation: int = 0,
        tracking_item_identity: str = "",
    ):
        return self.runtime.build_event(
            product_name=product_name,
            qty=qty,
            st_text=st_text,
            rd_=rd_,
            branch=branch,
            material_number=material_number,
            production_date=production_date,
            expiry_date=expiry_date,
            severity=severity,
            source=source,
            severity_rank=severity_rank,
            store=store,
            store_name=store_name,
            branch_name=branch_name,
            branch_label=branch_label,
            region=region,
            area=area,
            user_identity=user_identity,
            server_identity=server_identity,
            authority_revision=authority_revision,
            runtime_generation=runtime_generation,
            tracking_item_identity=tracking_item_identity,
        )

    def health_snapshot(self) -> dict:
        """Return a deterministic runtime health summary for monitoring/UI status."""
        queue_health = {}
        try:
            queue_health = self.desktop_queue.health_snapshot()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Desktop queue health unavailable", exc_info=True)
        capability = {}
        try:
            capability = self.desktop_notifier.capability_snapshot()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Desktop notification capability snapshot unavailable", exc_info=True)
        return {
            "enabled": self._get_bool("enable_desktop_notifications", True),
            "pending_delivery": len(self._pending_delivery),
            "history_count": len(list(getattr(self.main_window, "notifications_list", []) or [])),
            "queue": queue_health,
            "capability": capability,
        }

    def reconcile_delivery_state(self) -> None:
        """Release impossible stale pending records after queue shutdown/reset.

        This is a safety net for platform notification backends that terminate
        without calling a result callback during app shutdown or adapter failure.
        """
        try:
            queue = self.health_snapshot().get("queue") or {}
            if not bool(queue.get("busy")) and normalize_int(queue.get("queued"), 0) <= 0:
                self._pending_delivery.clear()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Notification delivery reconciliation failed", exc_info=True)

    def reset_runtime_state(self, *, clear_history: bool = True) -> None:
        try:
            self.runtime.clear_recent()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Failed to clear notification duplicate guard", exc_info=True)
        try:
            self.desktop_queue.clear()
            self._pending_delivery.clear()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Failed to clear notification desktop queue", exc_info=True)
        if clear_history:
            try:
                self.main_window.notifications_list = []
                queue_persist = getattr(self.main_window, "_queue_notification_persist", None)
                if callable(queue_persist):
                    queue_persist([])
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Failed to clear notification history", exc_info=True)
        self.update_badge()

    def close(self) -> None:
        """Stop all notification delivery resources owned by this service."""
        try:
            self.desktop_queue.close()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Desktop notification queue close failed", exc_info=True)
        try:
            self.desktop_notifier.close()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Desktop notifier close failed", exc_info=True)
        try:
            self.sound_notifier.stop()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Notification sound stop failed", exc_info=True)

    def update_badge(self):
        """Update badge."""
        self.badge_updater.update()
