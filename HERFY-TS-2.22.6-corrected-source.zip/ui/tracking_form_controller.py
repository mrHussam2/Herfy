"""Tracking form validation and mutations."""

from __future__ import annotations

import logging

from PySide6.QtCore import QDate

from core.errors import UI_OPERATION_EXCEPTIONS
from core.models import ISO_DATE_FORMAT
from core.settings import _
from ui.dialogs import show_error_message, show_warning_message
from ui.tracking_dialogs import EditTrackedProductDialog, confirm_tracked_product_delete
from ui.widgets import (
    clear_input_state,
    set_input_state,
)

logger = logging.getLogger(__name__)


class TrackingFormControllerMixin:
    _load_token = 0

    def _warn_missing_remote_id(self) -> None:
        show_warning_message(
            self,
            _("Error"),
            _("Server record id is missing. Refresh shelf-life data and try again."),
        )
        try:
            self.load_tracked_products(show_busy=True)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._warn_missing_remote_id failed", exc_info=True)

    def _selected_tracked_product(self, row: int, *, action: str) -> dict | None:
        product_id = self.model.get_product_id(row)
        if product_id is None:
            show_warning_message(self, _("Error"), _("Food item was not found."))
            return None
        selection = self._tracking_controller.select_record(
            product_id=product_id, rows=list(self.tracked_products or []), action=action
        )
        if selection.record is not None:
            return selection.record
        if selection.requires_refresh:
            self._warn_missing_remote_id()
            return None
        show_warning_message(self, _("Error"), selection.message or _("Food item was not found."))
        return None

    def tracking_action_error(self, row: int, *, action: str) -> str:
        """Return a row-specific capability error without opening a dialog."""
        rows = list(getattr(self, "tracked_products", []) or [])
        if not 0 <= int(row) < len(rows):
            return _("Food item was not found.")
        record = rows[int(row)]
        if not isinstance(record, dict):
            return _("Food item was not found.")
        return str(self._tracking_controller.record_action_error(record, action=action) or "")

    def explain_tracking_action_unavailable(self, row: int, *, action: str) -> None:
        message = self.tracking_action_error(row, action=action)
        if message:
            self._set_page_status(message, role="warning")

    def _clear_tracking_form_feedback(self, *args) -> None:
        del args
        fields = (
            (getattr(self, "branch_selector", None), _("Branch")),
            (
                getattr(self, "product_entry", None),
                _("Material number or material name"),
            ),
            (getattr(self, "qty_entry", None), _("Quantity")),
            (getattr(self, "prod_edit", None), _("Production date")),
            (getattr(self, "exp_edit", None), _("Expiry date")),
        )
        for widget, tooltip in fields:
            clear_input_state(widget, tooltip=tooltip)

    def _apply_tracking_form_error(self, message: str) -> None:
        text = str(message or "").strip()
        branch = self._selected_create_branch()
        product_text = str(self.product_entry.text() or "").strip()
        quantity_text = str(self.qty_entry.text() or "").strip()
        if not branch:
            self._mark_form_error(self.branch_selector, text, focus=True)
        if not product_text:
            self._mark_form_error(self.product_entry, text, focus=True)
        if not quantity_text or _("Quantity") in text:
            self._mark_form_error(self.qty_entry, text, focus=bool(product_text))
        if self._is_date_error(text):
            self._mark_form_error(self.prod_edit, text)
            self._mark_form_error(self.exp_edit, text, focus=True)
        if self._is_catalog_warning(text):
            set_input_state(self.product_entry, "warning", tooltip=text)
            self.product_entry.setFocus()

    @staticmethod
    def _mark_form_error(widget, text: str, *, focus: bool = False) -> None:
        set_input_state(widget, "error", tooltip=text)
        if focus:
            widget.setFocus()

    @staticmethod
    def _message_contains_any(text: str, *needles: str) -> bool:
        return any((str(needle or "") in text for needle in needles if needle))

    @classmethod
    def _is_date_error(cls, text: str) -> bool:
        return cls._message_contains_any(
            text,
            _("Production date cannot be after expiry date."),
            _("Invalid date format!"),
        )

    @classmethod
    def _is_catalog_warning(cls, text: str) -> bool:
        return cls._message_contains_any(
            text,
            _("product catalog"),
            _("This food item was not found in the product catalog."),
        )

    def _reset_tracking_form(self) -> None:
        self.product_entry.clear()
        self.qty_entry.clear()
        self.prod_edit.setDate(QDate.currentDate())
        self.exp_edit.setDate(QDate.currentDate())
        self._clear_tracking_form_feedback()

    def add_product(self) -> None:
        # Validate the destination first.  Without this ordering, a click made
        # before a branch is selected could start an unnecessary catalog fetch
        # and mask the actionable branch-selection message.
        branch = self._selected_create_branch()
        if not branch:
            self._reject_tracking_form(_("Please select a branch."))
            return
        # A catalogue refresh is informational, not a lock on the operator's
        # save action.  The domain service resolves the material again from
        # the authoritative server catalogue inside the background mutation.
        # Blocking here made a valid selected suggestion appear to do nothing
        # whenever an automatic refresh overlapped the click.
        prepared, error_message = self._tracking_controller.prepare_create(
            product_text=self.product_entry.text(),
            quantity_text=self.qty_entry.text(),
            production_date=self.prod_edit.date().toString(ISO_DATE_FORMAT),
            expiry_date=self.exp_edit.date().toString(ISO_DATE_FORMAT),
        )
        if error_message or prepared is None:
            self._reject_tracking_form(
                error_message or _("Food item details and quantity are required.")
            )
            return
        current_rows = [dict(row) for row in (self.tracked_products or []) if isinstance(row, dict)]
        logger.info(
            "TRACKING_CREATE_REQUEST branch=%s material=%s quantity=%s catalog_loading=%s",
            branch,
            prepared.material_number,
            prepared.quantity,
            bool(getattr(self, "_catalog_loading", False)),
        )

        def _save_logic():
            return self._tracking_controller.create_item(
                prepared,
                branch=branch,
                current_rows=current_rows,
            )

        try:
            self._run_tracking_action(
                label=_("Saving..."),
                worker_fn=_save_logic,
                success_message=_("Saved."),
                failure_message=_("Failed to save."),
                reset_form=True,
            )
        except UI_OPERATION_EXCEPTIONS as exc:
            logger.error("Failed to add product: %s", exc)
            show_error_message(self, _("Error"), _("Failed to save food item."))

    def _reject_tracking_form(self, message: str) -> None:
        self._set_page_status(message, role="error")
        self._apply_tracking_form_error(message)
        show_warning_message(self, _("Error"), message)

    def edit_tracked_product(self, row: int) -> None:
        product = self._selected_tracked_product(row, action="update")
        if not product:
            return
        dialog = EditTrackedProductDialog(product, self)
        if not dialog.exec():
            return
        values = dialog.values()
        prepared, error_message = self._tracking_controller.prepare_update(
            quantity_text=values["quantity_text"],
            production_date=values["production_date"],
            expiry_date=values["expiry_date"],
        )
        if error_message or prepared is None:
            show_warning_message(
                self, _("Error"), error_message or _("Quantity must be a positive integer.")
            )
            return

        def _update_logic():
            return self._tracking_controller.update_item(product, prepared)

        self._run_tracking_action(
            label=_("Updating..."),
            worker_fn=_update_logic,
            success_message=_("Updated."),
            failure_message=_("Failed to update."),
        )

    def delete_tracked_product(self, row: int) -> None:
        product = self._selected_tracked_product(row, action="delete")
        if not product:
            return
        if not confirm_tracked_product_delete(product, self):
            return
        self._run_tracking_action(
            label=_("Deleting..."),
            worker_fn=lambda: self._tracking_controller.delete_item(product),
            success_message=_("Deleted."),
            failure_message=_("Failed to delete."),
        )

    def reset_after_logout(self) -> None:
        try:
            self._load_token += 1
            self._action_token = int(getattr(self, "_action_token", 0) or 0) + 1
            self._catalog_load_token = int(getattr(self, "_catalog_load_token", 0) or 0) + 1
            self._loading = False
            self._load_pending = False
            self._load_pending_show_busy = False
            self._catalog_loading = False
            self._catalog_load_pending_force_network = False
            self._action_running = False
            registry = getattr(self, "_worker_registry", None)
            if registry is not None:
                registry.cancel_all()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage.reset_after_logout cleanup failed", exc_info=True)
        try:
            self.tracked_products = []
            self.model.load_data([])
            self._update_table_summary(loading=False)
            self._set_page_status("", role="muted")
            self.btn_add.setEnabled(False)
            self.btn_add.setToolTip(_("Login required"))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage.reset_after_logout failed", exc_info=True)


logger = logging.getLogger(__name__)
