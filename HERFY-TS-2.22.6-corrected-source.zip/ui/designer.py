"""Load checked Qt Designer forms without generated Python form classes.

The source application intentionally loads `.ui` resources at runtime.  This
makes a saved Designer change visible in the next development surface while
keeping controller logic outside files Designer can overwrite.
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path

from PySide6 import QtCore, QtUiTools
from PySide6.QtCore import QObject
from PySide6.QtWidgets import QWidget

from core.settings import bundled_or_source_path


class DesignerUiError(RuntimeError):
    """Raised when a Designer form cannot satisfy its widget contract."""


def ui_path(ui_name: str) -> Path:
    """Return the bundled/source path for a simple registered UI resource."""
    name = str(ui_name or "").strip()
    if not name or Path(name).name != name or Path(name).suffix:
        raise DesignerUiError(f"Invalid Designer UI name: {ui_name!r}")
    path = bundled_or_source_path("resources", "ui", f"{name}.ui")
    if not path.is_file():
        raise DesignerUiError(f"Designer UI resource is missing: {path}")
    return path


def load_ui(
    target: QWidget,
    ui_name: str,
    *,
    required: Iterable[str] = (),
) -> dict[str, QObject]:
    """Populate *target* and return explicitly required named child objects.

    A missing object name is a programming/design-time failure rather than a
    reason to reconstruct a stale layout in Python.
    """
    if not isinstance(target, QWidget):
        raise DesignerUiError("Designer UI target must be a QWidget")
    path = ui_path(ui_name)
    try:

        class _TargetUiLoader(QtUiTools.QUiLoader):
            def __init__(self, root):
                super().__init__()
                self._root = root
                self._claimed = False

            def createWidget(self, class_name, parent=None, name=""):
                # QUiLoader creates the document root with no parent. Reuse the
                # caller-owned widget only for that root; child creation must
                # always follow the .ui hierarchy.
                if not self._claimed and parent is None:
                    self._claimed = True
                    if name:
                        self._root.setObjectName(name)
                    return self._root
                return super().createWidget(class_name, parent, name)

        qfile = QtCore.QFile(str(path))
        if not qfile.open(QtCore.QIODevice.ReadOnly):
            raise DesignerUiError(f"Unable to open Designer UI: {path}")
        try:
            loader = _TargetUiLoader(target)
            loaded = loader.load(qfile)
            if loaded is not target:
                raise DesignerUiError(f"Designer UI root mismatch: {path}")
            target._designer_loader = loader
        finally:
            qfile.close()
    except Exception as exc:
        raise DesignerUiError(f"Unable to load Designer UI {path}: {exc}") from exc

    controls: dict[str, QObject] = {}
    missing: list[str] = []
    for name in tuple(required):
        control_name = str(name or "").strip()
        control = target.findChild(QObject, control_name) if control_name else None
        if control is None:
            missing.append(control_name or "<empty>")
        else:
            controls[control_name] = control
    if missing:
        rendered = ", ".join(missing)
        raise DesignerUiError(f"Designer UI {path} is missing required object names: {rendered}")
    return controls


__all__ = ["DesignerUiError", "load_ui", "ui_path"]
