"""Tracking data-table construction."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QComboBox,
    QGridLayout,
    QLabel,
    QLineEdit,
    QSizePolicy,
    QTableView,
)

from core.settings import _
from ui.tables import (
    ActionDelegate,
    ProgressBarDelegate,
    TrackedProductsTableModel,
    configure_responsive_table,
)
from ui.widgets import DataSurface


class TrackingTableBuilderMixin:
    def _build_table_card(self) -> None:
        S = self._S
        self.model = TrackedProductsTableModel([])
        self.table_view = self._designer_controls["TrackingProductsTable"]
        self.table_card = self._designer_controls["TrackingTableCard"]
        self.table_card.setObjectName("GridPanel")
        self.table_card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table_view.setModel(self.model)
        configure_responsive_table(self.table_view, window_width=self.width(), show_grid=False)
        self.table_view.setLayoutDirection(Qt.LeftToRight)
        self.table_view.horizontalHeader().setLayoutDirection(Qt.LeftToRight)
        self.table_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table_view.setMinimumHeight(0)
        self.table_view.setSelectionBehavior(QTableView.SelectRows)
        self.table_view.setSelectionMode(QTableView.SingleSelection)
        self.table_view.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table_view.setMouseTracking(True)
        self.table_view.setAlternatingRowColors(True)
        self.table_view.setItemDelegateForColumn(6, ProgressBarDelegate(self.table_view))
        self.table_view.setItemDelegateForColumn(7, ActionDelegate(self, self.table_view))
        self.table_view.horizontalHeader().setHighlightSections(False)
        self.table_view.horizontalHeader().setMinimumSectionSize(S(48))
        self.table_title: QLabel = self._designer_controls["TrackingTableTitle"]
        self.tracking_table_header_grid: QGridLayout = self._designer_controls[
            "tracking_table_header_layout"
        ]
        self.search_input = QLineEdit(self.table_card)
        self.search_input.setObjectName("TrackingTableSearch")
        self.search_input.setPlaceholderText(_("Search by material number or product name"))
        self.search_input.setClearButtonEnabled(True)
        self.search_input.setAccessibleName(_("Search tracked products"))
        self.status_filter = QComboBox(self.table_card)
        self.status_filter.setObjectName("TrackingStatusFilter")
        self.status_filter.setAccessibleName(_("Tracking status"))
        self.status_filter.addItem(_("All status"), "")
        self.status_filter.addItem(_("Active"), "active")
        self.status_filter.addItem(_("Expiring soon"), "expiring")
        self.status_filter.addItem(_("Expired"), "expired")
        self.search_input.textChanged.connect(self._apply_tracking_filters)
        self.status_filter.currentIndexChanged.connect(self._apply_tracking_filters)
        # Search and status filtering live inside the table card.  Keeping
        # them adjacent to the title makes the data workspace one coherent
        # surface instead of a toolbar separated from the table.
        self.tracking_table_header_grid.addWidget(self.search_input, 1, 0)
        self.tracking_table_header_grid.addWidget(self.status_filter, 1, 1)
        self.tracking_table_header_grid.setColumnStretch(0, 1)

        self.tracking_surface = DataSurface(self.table_view, self.table_card)
        self.tracking_table_host_layout.addWidget(self.tracking_surface, 1)

    def _configure_table(self) -> None:
        self._size_tracking_columns()
