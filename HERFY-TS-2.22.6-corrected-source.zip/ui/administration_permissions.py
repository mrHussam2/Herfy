"""Server-authoritative permission catalogue presentation."""

from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QGridLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from ui.dialogs import show_question_message
from core.settings import _
from ui.administration_controller import AdministrationPresenter
from ui.designer import load_ui
from ui.theme import (
    UI_METRICS,
    apply_toolbar_control_metrics,
    toolbar_breakpoint_for_width,
)
from ui.widgets import DataSurface, refresh_widget_style


class PermissionsSection(QWidget):
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self._snapshot: dict[str, Any] = {}
        self._checks: dict[str, QCheckBox] = {}
        self._initial_selected: set[str] = set()
        self._current_role = ""
        self._current_revision = 0
        self._changing_role = False
        self._compact = False
        self._toolbar_breakpoint: str | None = None

        controls = load_ui(
            self,
            "admin_permissions_section",
            required=(
                "AdminPermissionBadge",
                "permissions_save",
                "AdminPermissionRole",
                "AdminToolbarHint",
                "AdminPermissionsHost",
                "AdminPermissionsScrollArea",
                "permissions_surface_host",
            ),
        )
        self.selection_badge: QLabel = controls["AdminPermissionBadge"]
        self.selection_badge.setProperty("tone", "primary")
        self.selection_badge.setAlignment(Qt.AlignCenter)
        self.selection_badge.setMinimumWidth(UI_METRICS.admin_permissions_selection_badge_min_width)
        self.selection_badge.setToolTip(_("Selected permissions"))
        self.save: QPushButton = controls["permissions_save"]
        self.save.setText(_("Apply"))
        self.save.setProperty("variant", "primary")
        self.findChild(QLabel, "AdminToolbarLabel").setText(_("Role"))
        self.role: QComboBox = controls["AdminPermissionRole"]
        self.role.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        self.role.setMinimumWidth(UI_METRICS.admin_permissions_role_min_width)
        self.toolbar: QFrame = self.findChild(QFrame, "AdminSectionToolbar")
        self.role_hint: QLabel = controls["AdminToolbarHint"]
        self.role_hint.setText(_("Server-side enforcement remains the source of truth."))
        self.save.setProperty("toolbarControl", True)
        self.save.setMinimumHeight(UI_METRICS.toolbar_control_height)
        self.set_toolbar_width(self.width())
        self.host: QWidget = controls["AdminPermissionsHost"]
        self.groups: QGridLayout = self.host.layout()
        self.groups.setContentsMargins(2, 2, 2, 2)
        self.groups.setHorizontalSpacing(10)
        self.groups.setVerticalSpacing(10)
        self.groups.setAlignment(Qt.AlignTop)
        self.groups.setColumnStretch(0, 1)
        self.groups.setColumnStretch(1, 1)
        self.permissions_scroll: QScrollArea = controls["AdminPermissionsScrollArea"]
        self.permissions_scroll.setFrameShape(QFrame.NoFrame)
        self.permissions_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.permissions_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.content_surface = DataSurface(self.permissions_scroll, self)
        controls["permissions_surface_host"].layout().addWidget(self.content_surface)

        self.role.currentIndexChanged.connect(self._role_changed)
        self.save.clicked.connect(self._save)
        self.controller.permissions_saved.connect(self._on_permissions_saved)

    def set_compact_mode(self, compact: bool) -> None:
        compact = bool(compact)
        if compact == self._compact:
            return
        self._compact = compact
        self.role.setMinimumWidth(0 if compact else UI_METRICS.admin_permissions_role_min_width)
        self.role.setSizePolicy(
            QSizePolicy.Expanding if compact else QSizePolicy.Preferred,
            QSizePolicy.Fixed,
        )
        self.role_hint.setVisible(not compact)
        if self._checks:
            self._render_current(preserve_current=True)

    def set_toolbar_width(self, width: int) -> None:
        breakpoint = toolbar_breakpoint_for_width(width)
        if breakpoint == self._toolbar_breakpoint:
            return
        self._toolbar_breakpoint = breakpoint
        apply_toolbar_control_metrics(self.toolbar, (self.role,), width)

    def set_snapshot(self, snapshot: dict[str, Any]) -> None:
        preserve_dirty = self.is_dirty()
        current = self._current_role or str(self.role.currentData() or "")
        self._snapshot = dict(snapshot or {})
        self._changing_role = True
        try:
            self.role.clear()
            for row in snapshot.get("roles") or []:
                if isinstance(row, dict):
                    role = str(row.get("role") or "")
                    if role:
                        self.role.addItem(AdministrationPresenter.role_label(role), role)
            index = self.role.findData(current)
            self.role.setCurrentIndex(index if index >= 0 else (0 if self.role.count() else -1))
        finally:
            self._changing_role = False
        self.save.setVisible(AdministrationPresenter.has_capability(snapshot, "permissions.assign"))
        same_role = bool(current and self.role.findData(current) >= 0)
        self._render_current(preserve_current=bool(preserve_dirty and same_role))

    def _clear(self) -> None:
        while self.groups.count():
            item = self.groups.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
        self._checks = {}

    def _permissions_for_role(self, role: str) -> set[str]:
        if str(role or "") == "system":
            # Server authorization hard-codes system authority to the complete
            # canonical permission set.  Present that invariant directly rather
            # than the RolePermission rows, which are not authoritative for
            # system and may be empty.
            return {
                (
                    str(entry.get("code") or "").strip()
                    if isinstance(entry, dict)
                    else str(entry or "").strip()
                )
                for entry in self._snapshot.get("permission_catalog") or []
                if (
                    str(entry.get("code") or "").strip()
                    if isinstance(entry, dict)
                    else str(entry or "").strip()
                )
            }
        for row in self._snapshot.get("roles") or []:
            if isinstance(row, dict) and str(row.get("role") or "") == role:
                return {str(value) for value in row.get("permissions") or []}
        return set()

    def _revision_for_role(self, role: str) -> int:
        for row in self._snapshot.get("roles") or []:
            if isinstance(row, dict) and str(row.get("role") or "") == role:
                try:
                    return max(0, int(row.get("revision") or 0))
                except (TypeError, ValueError):
                    return 0
        return 0

    def _render_current(self, *, preserve_current: bool = False) -> None:
        previous_selection = self.selected_permissions() if preserve_current else None
        self._clear()
        role = str(self.role.currentData() or "")
        self._current_role = role
        self._current_revision = self._revision_for_role(role)
        if not preserve_current:
            self._initial_selected = self._permissions_for_role(role)
        selected = previous_selection if previous_selection is not None else self._initial_selected

        groups = AdministrationPresenter.permission_groups(
            self._snapshot.get("permission_catalog") or []
        )
        if not role or not groups:
            self.selection_badge.setText("0/0")
            self.content_surface.set_state("content")
            self._sync_save_state()
            return

        system_role = role == "system"
        can_assign = AdministrationPresenter.has_capability(self._snapshot, "permissions.assign")
        self.save.setVisible(can_assign and not system_role)
        editable = can_assign and not system_role
        self.role_hint.setText(
            _("System authority always has the full canonical permission set.")
            if system_role
            else _("Server-side enforcement remains the source of truth.")
        )
        # The server catalog quickly becomes unreadable when the workspace tries
        # to pack three dense permission groups into a single row. Keep a wider,
        # clearer rhythm: one column on compact workspaces and two columns on the
        # normal desktop administration surface.
        columns = 1 if self._compact else 2
        for group_index, (name, codes) in enumerate(groups.items()):
            box = QFrame(self.host)
            box.setObjectName("AdminPermissionGroup")
            box.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            group_layout = QVBoxLayout(box)
            group_layout.setContentsMargins(9, 8, 9, 7)
            group_layout.setSpacing(3)
            group_layout.setAlignment(Qt.AlignTop)
            group_title = QLabel(_(name.replace("_", " ").title()), box)
            group_title.setObjectName("AdminPermissionGroupTitle")
            group_layout.addWidget(group_title)
            for code in codes:
                label = AdministrationPresenter.permission_label(code)
                check = QCheckBox(f"{label}  ·  {code}", box)
                check.setObjectName("AdminPermissionCheck")
                check.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
                check.setToolTip(code)
                check.setChecked(code in selected)
                check.setEnabled(editable)
                check.toggled.connect(self._sync_save_state)
                group_layout.addWidget(check)
                self._checks[code] = check
            row = group_index // columns
            column = group_index % columns
            self.groups.addWidget(box, row, column)

        self.content_surface.set_state("content")
        self._sync_save_state()

    def _role_changed(self, _index: int) -> None:
        if self._changing_role:
            return
        new_role = str(self.role.currentData() or "")
        if self._current_role and new_role != self._current_role and self.is_dirty():
            answer = show_question_message(
                self,
                _("Unsaved changes"),
                _("There are unsaved permission changes. Discard them?")
            )
            if not answer:
                self._changing_role = True
                try:
                    index = self.role.findData(self._current_role)
                    self.role.setCurrentIndex(index)
                finally:
                    self._changing_role = False
                return
        self._render_current()

    def selected_permissions(self) -> set[str]:
        return {code for code, check in self._checks.items() if check.isChecked()}

    def is_dirty(self) -> bool:
        return self.selected_permissions() != self._initial_selected

    def _sync_save_state(self, *_args) -> None:
        selected = self.selected_permissions()
        total = len(self._checks)
        self.selection_badge.setText(f"{len(selected)}/{total}")
        self.save.setEnabled(
            bool(
                self._current_role
                and self._current_role != "system"
                and self.save.isVisible()
                and self.is_dirty()
            )
        )
        self.selection_badge.setProperty("tone", "warning" if self.is_dirty() else "primary")
        refresh_widget_style(self.selection_badge)

    def _save(self) -> None:
        if not self._current_role or not self.is_dirty():
            return
        self.controller.save_permissions(
            self._current_role,
            base_revision=self._current_revision,
            permissions=sorted(self.selected_permissions()),
        )

    def _on_permissions_saved(self, role: str, result: dict[str, Any]) -> None:
        if str(role or "") != self._current_role:
            return
        permissions = result.get("permissions") if isinstance(result, dict) else None
        if isinstance(result, dict):
            try:
                self._current_revision = max(
                    0, int(result.get("revision") or self._current_revision)
                )
            except (TypeError, ValueError):
                pass
        if isinstance(permissions, list):
            self._initial_selected = {str(code) for code in permissions if str(code)}
        else:
            # The mutation succeeded but the response omitted a normalized list.
            # Preserve the submitted UI state as clean only after success.
            self._initial_selected = self.selected_permissions()
        self._sync_save_state()
