from __future__ import annotations

import logging
from typing import ClassVar

from PySide6.QtCore import QEvent, QStringListModel, Qt, QTimer
from PySide6.QtWidgets import QApplication, QCompleter, QWidget

from core.errors import UI_OPERATION_EXCEPTIONS
from core.settings import _
from services.tracking import TrackingPageController
from ui.tables import ResponsiveDataPageResizeMixin
from ui.theme import apply_device_properties, make_scaler, polish_interface
from ui.tracking_composition import TrackingControllerMixin, TrackingUiBuilderMixin
from ui.tracking_responsive import (
    TrackingResponsiveLayoutMixin,
)

logger = logging.getLogger(__name__)


class TrackingPage(
    TrackingResponsiveLayoutMixin,
    TrackingUiBuilderMixin,
    ResponsiveDataPageResizeMixin,
    TrackingControllerMixin,
    QWidget,
):
    responsive_resize_callbacks = ("apply_responsive_profile",)
    responsive_table_attr = "table_view"
    responsive_table_size_callback = "_size_tracking_columns"
    responsive_table_min_height = None
    responsive_table_resize_after_callbacks = False
    status_label_attr = "_status_lbl"
    summary_surface_attr = "tracking_surface"
    summary_loading_text = "Loading..."
    summary_state_method = "tracking_state"
    TABLE_COL_RATIOS: ClassVar[tuple[int, ...]] = (5, 11, 40, 5, 10, 10, 14, 5)
    TABLE_COL_MIN_WIDTHS: ClassVar[tuple[int, ...]] = (54, 92, 220, 46, 88, 88, 118, 52)
    TABLET_COL_RATIOS: ClassVar[tuple[int, ...]] = (5, 10, 40, 5, 10, 10, 15, 5)
    TABLET_COL_MIN_WIDTHS: ClassVar[tuple[int, ...]] = (
        50,
        84,
        190,
        44,
        82,
        82,
        108,
        48,
    )
    COMPACT_COL_RATIOS: ClassVar[tuple[int, ...]] = (5, 10, 42, 5, 10, 10, 14, 4)
    COMPACT_COL_MIN_WIDTHS: ClassVar[tuple[int, ...]] = (
        46,
        74,
        150,
        40,
        72,
        72,
        90,
        40,
    )

    def __init__(
        self,
        parent=None,
        tracking_service=None,
        tracking_form_service=None,
        page_visible_state_service=None,
        worker_registry=None,
    ):
        super().__init__(parent)
        # This applies only to the right-hand page, never to the sidebar.
        self.setProperty("nativeWorkspace", True)
        if tracking_service is None:
            raise RuntimeError("TrackingPage requires the composed TrackingService")
        if tracking_form_service is None or page_visible_state_service is None:
            raise RuntimeError("TrackingPage requires composed presentation/application services")
        self._tracking_controller = TrackingPageController(tracking_service, tracking_form_service)
        self.page_visible_state_service = page_visible_state_service
        self.tracked_products = []
        self._product_catalog_rows: list = []
        if worker_registry is None:
            raise RuntimeError("TrackingPage requires a composed worker scope")
        self._worker_registry = worker_registry
        self._load_token = 0
        self._action_token = 0
        self._catalog_load_token = 0
        self._completer_cache_size = -1
        self._suppress_state_refresh_until = 0.0
        self._loading = False
        self._load_pending = False
        self._load_pending_show_busy = False
        self._catalog_loading = False
        self._catalog_load_pending_force_network = False
        self._action_running = False
        self._pending_state_payload = None
        self._bound_app_state = None
        self._disposed = False
        self._S = make_scaler(QApplication.instance())
        self._init_timers()
        self._build_ui()
        self._connect_signals()
        self._setup_page_state()

    def _init_timers(self) -> None:
        self._state_refresh_timer = QTimer(self)
        self._state_refresh_timer.setSingleShot(True)
        self._state_refresh_timer.timeout.connect(self._run_state_refresh)

    def _setup_page_state(self) -> None:
        apply_device_properties(self, self.width(), QApplication.instance())
        self._configure_table()
        self._refresh_create_branch_selector()
        self._update_branch_ui_state()
        # The form is immediately usable after a branch is resolved.  Load the
        # authoritative catalogue in the background now, rather than waiting
        # for a second navigation or an Add click to make suggestions work.
        if self._selected_create_branch():
            self.load_product_catalog(force_network=False)
        self.table_view.viewport().installEventFilter(self)
        self.destroyed.connect(self._close_tracking_workers)
        self.destroyed.connect(self._on_destroyed)
        self._set_page_table_summary(0, loading=False)
        polish_interface(self, window_width=self.width())
        self._apply_responsive_toolbar(force=True)

    def _connect_signals(self) -> None:
        self.btn_add.clicked.connect(self.add_product)
        self.branch_selector.currentIndexChanged.connect(self._on_create_branch_changed)
        self.product_entry.textChanged.connect(self._clear_tracking_form_feedback)
        self.product_entry.textEdited.connect(self._on_product_entry_edited)
        self.qty_entry.textChanged.connect(self._clear_tracking_form_feedback)
        self.prod_edit.dateChanged.connect(self._clear_tracking_form_feedback)
        self.exp_edit.dateChanged.connect(self._clear_tracking_form_feedback)
        self.product_entry.returnPressed.connect(self.qty_entry.setFocus)
        self.qty_entry.returnPressed.connect(self.add_product)

    def _close_tracking_workers(self, *_args) -> None:
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            try:
                registry.close()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Tracking worker registry close failed", exc_info=True)

    def refresh_current_branch(self) -> None:
        """Refresh authority-scoped branch options and the full tracking view."""
        self._refresh_create_branch_selector()
        self._update_branch_ui_state()
        self.load_tracked_products(show_busy=False)

    def focus_notification_target(self, *, branch: str = "", material_number: str = "") -> None:
        """Focus a notification target inside the full authorized tracking view."""
        branch = str(branch or "").strip()
        material_number = str(material_number or "").strip()
        if branch:
            self.load_tracked_products(show_busy=False)
        if not material_number:
            return

        def _select(attempts_left: int = 20) -> None:
            for row, item in enumerate(list(getattr(self, "tracked_products", []) or [])):
                current_material = str(
                    item.get("material_number") or item.get("material") or ""
                ).strip()
                current_branch = str(item.get("branch") or item.get("branch_id") or "").strip()
                if current_material != material_number:
                    continue
                if branch and current_branch and current_branch != branch:
                    continue
                self.table_view.selectRow(row)
                self.table_view.scrollTo(self.model.index(row, 0))
                return
            if attempts_left > 0:
                QTimer.singleShot(250, lambda: _select(attempts_left - 1))

        QTimer.singleShot(0, _select)

    def _on_create_branch_changed(self, _index: int = -1) -> None:
        self._clear_tracking_form_feedback()
        self._update_branch_ui_state()
        if self._selected_create_branch():
            self.load_product_catalog(force_network=False)

    def _on_product_entry_edited(self, text: str) -> None:
        """Load and present catalog choices at the point an operator needs them."""
        if not self._selected_create_branch() or not str(text or "").strip():
            return
        if not list(getattr(self, "_product_catalog_rows", []) or []):
            if not self._catalog_loading:
                self.load_product_catalog(force_network=True)
            return
        self._show_product_suggestions(text)

    def _show_product_suggestions(self, text: str | None = None) -> None:
        """Open the catalogue popup with a material-number or name match."""
        completer = getattr(self, "_product_completer", None)
        if (
            getattr(self, "_disposed", False)
            or not self.product_entry.isVisible()
            or not self.product_entry.isEnabled()
            or not self.product_entry.hasFocus()
            or not self._selected_create_branch()
        ):
            return
        prefix = str(self.product_entry.text() if text is None else text).strip()
        if completer is None or not prefix:
            return
        completer.setCompletionPrefix(prefix)
        completer.complete()

    def _on_product_suggestion_selected(self, value: str) -> None:
        self.product_entry.setText(str(value or "").strip())
        self.qty_entry.setFocus()

    def _update_branch_ui_state(self) -> None:
        try:
            options = [
                str(branch or "").strip()
                for branch in self._tracking_controller.branch_options()
                if str(branch or "").strip()
            ]
            selected = self._selected_create_branch()
            can_create = bool(
                selected
                and any(selected.casefold() == option.casefold() for option in options)
            )
            action_running = bool(getattr(self, "_action_running", False))

            # Branch is the first step. Downstream inputs are intentionally
            # unavailable until an authorized branch has been selected.
            for widget in (
                self.product_entry,
                self.prod_edit,
                self.exp_edit,
                self.qty_entry,
            ):
                widget.setEnabled(can_create and not action_running)
            self.btn_add.setEnabled(can_create and not action_running)

            if can_create:
                self.product_entry.setPlaceholderText(
                    _("Search by material number or material name")
                )
                self.product_entry.setToolTip(
                    _("Search material for branch: {branch}").format(branch=selected)
                )
            else:
                self.product_entry.clear()
                self.qty_entry.clear()
                self.product_entry.setPlaceholderText(_("Select a branch first"))
                self.product_entry.setToolTip(_("Select a branch before choosing a material"))

            if not options:
                if not self._tracking_controller.has_create_permission():
                    status = _("Your account can view tracking but cannot add tracked products.")
                else:
                    status = _("No authorized branch is available for adding tracked products.")
                tooltip = status
            elif len(options) > 1 and not selected:
                status = _("Select a branch in the add-product form.")
                tooltip = _("Choose the destination branch before saving the item.")
            else:
                status = _("New tracked products will be saved to branch: {branch}").format(
                    branch=selected or options[0]
                )
                tooltip = _("Add or update food shelf-life item")
            self._set_page_status(status, role="muted")
            self._status_lbl.setToolTip(tooltip)
            self.btn_add.setToolTip(tooltip)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._update_branch_ui_state failed", exc_info=True)

    def update_completer(self, stored_products: list | None = None) -> None:
        is_alive = getattr(self, "_is_alive", None)
        if callable(is_alive) and (not is_alive()):
            return
        if stored_products is None:
            products = list(getattr(self, "_product_catalog_rows", []) or [])
        else:
            products = list(stored_products)
        self._product_catalog_rows = list(products or [])
        suggestions = self._tracking_controller.completer_suggestions(self._product_catalog_rows)
        completer = getattr(self, "_product_completer", None)
        if completer is None:
            completer = QCompleter(self.product_entry)
            completer.setModel(QStringListModel(completer))
            completer.setCaseSensitivity(Qt.CaseInsensitive)
            completer.setFilterMode(Qt.MatchContains)
            completer.setCompletionMode(QCompleter.PopupCompletion)
            completer.setMaxVisibleItems(12)
            completer.setWrapAround(False)
            completer.activated[str].connect(self._on_product_suggestion_selected)
            self._product_completer = completer
            self.product_entry.setCompleter(completer)
        completer.model().setStringList(suggestions)
        # If the background fetch completes while the operator is typing,
        # present the matching choices without requiring another keystroke.
        if self.product_entry.hasFocus() and self.product_entry.text().strip():
            QTimer.singleShot(0, self._show_product_suggestions)
        self._reconcile_visible_rows_with_catalog(
            list(getattr(self, "_product_catalog_rows", []) or [])
        )

    def eventFilter(self, obj, event):
        if obj is self.table_view.viewport() and event.type() == QEvent.Resize:
            if not getattr(self, "_fitting_table_columns", False):
                self._fitting_table_columns = True
                try:
                    self._size_tracking_columns()
                finally:
                    self._fitting_table_columns = False
        return super().eventFilter(obj, event)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        try:
            # Opening a page only projects authorized local state. Sync owns
            # initial hydration and server reconciliation, never navigation.
            if self._tracking_controller.baseline_ready():
                self.load_tracked_products(show_busy=False)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage.showEvent cached projection failed", exc_info=True)

    def hideEvent(self, event) -> None:
        try:
            self._load_token += 1
            self._loading = False
            self._status_lbl.setText("")
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage.hideEvent cleanup failed", exc_info=True)
        super().hideEvent(event)


# --- package exports ---
__all__ = ["TrackingPage"]
