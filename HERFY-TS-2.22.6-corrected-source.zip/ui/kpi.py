from __future__ import annotations

import calendar
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from PySide6 import QtCore, QtGui, QtWidgets

from core.permissions import PermissionContext, PermissionService
from core.settings import canonical_error_message
from ui.dialogs import show_error_message
from services.kpi_channels import (
    COMPARISON_CHANNELS,
    comparison_channel_values,
)
from services.kpi_excel import export_branch_workbook
from services.kpi_analytics import export_interactive_dashboard
from services.kpi_totals import (
    sum_month_report_net_totals,
    sum_report_net_totals,
)
from services.kpi_validation import (
    ValidationReport,
    analyze_csv_files,
)
from services.kpi_validation import (
    format_integer as _format_count,
)
from services.kpi_validation import (
    format_money as _format_money,
)
from ui.kpi_controller import KpiDashboardController
from ui.kpi_dashboard import InteractiveDashboard
from ui.kpi_designer import load_kpi_ui, require_object, require_widget
from ui.kpi_models import TopLevelRowsTableModel
from ui.responsive_toolbar import configure_more_menu
from ui.theme_metrics import UI_METRICS

_KPI_ACTIVITY_WIDTH = 204


class _TableModel(TopLevelRowsTableModel):
    def __init__(self, headers: tuple[str, ...]) -> None:
        super().__init__()
        self._headers = headers
        self._rows: list[tuple[str, ...]] = []

    def columnCount(
        self,
        parent: QtCore.QModelIndex | QtCore.QPersistentModelIndex | None = None,
    ) -> int:
        return 0 if parent is not None and parent.isValid() else len(self._headers)

    def data(
        self,
        index: QtCore.QModelIndex | QtCore.QPersistentModelIndex,
        role: int = QtCore.Qt.ItemDataRole.DisplayRole,
    ) -> object | None:
        if not index.isValid():
            return None
        row = self._rows[index.row()]
        if role == QtCore.Qt.ItemDataRole.BackgroundRole:
            if "Grand Total" in row:
                return QtGui.QBrush(QtGui.QColor("#fff2b3"))
            if "Total Net sale & GCs" in row:
                return QtGui.QBrush(QtGui.QColor("#dcefe7"))
        if role == QtCore.Qt.ItemDataRole.BackgroundRole and "Branch Total" in row:
            return QtGui.QBrush(QtGui.QColor("#e4edf5"))
        if role == QtCore.Qt.ItemDataRole.FontRole and "Grand Total" in row:
            font = QtGui.QFont()
            font.setBold(True)
            return font
        if role == QtCore.Qt.ItemDataRole.FontRole and "Total Net sale & GCs" in row:
            font = QtGui.QFont()
            font.setBold(True)
            return font
        if role == QtCore.Qt.ItemDataRole.FontRole and "Branch Total" in row:
            font = QtGui.QFont()
            font.setBold(True)
            return font
        if role == QtCore.Qt.ItemDataRole.ForegroundRole and index.column() in (4, 5, 8, 9):
            value = row[index.column()]
            if value.startswith("-"):
                return QtGui.QBrush(QtGui.QColor("#b42318"))
            if value not in {"—", "N/A"}:
                return QtGui.QBrush(QtGui.QColor("#18794e"))
        if role == QtCore.Qt.ItemDataRole.TextAlignmentRole:
            if index.column() >= 2:
                return int(
                    QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter
                )
            return int(QtCore.Qt.AlignmentFlag.AlignVCenter)
        if role != QtCore.Qt.ItemDataRole.DisplayRole:
            return None
        return row[index.column()]

    def headerData(
        self,
        section: int,
        orientation: QtCore.Qt.Orientation,
        role: int = QtCore.Qt.ItemDataRole.DisplayRole,
    ) -> str | None:
        if role != QtCore.Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == QtCore.Qt.Orientation.Horizontal:
            return self._headers[section]
        return str(section + 1)

    def replace(
        self,
        headers: tuple[str, ...],
        rows: list[tuple[str, ...]],
    ) -> None:
        self.beginResetModel()
        self._headers = headers
        self._rows = rows
        self.endResetModel()


class _ResponsiveTableView(QtWidgets.QTableView):
    def __init__(self) -> None:
        super().__init__()
        self._preferred_column_widths: tuple[int, ...] = ()

    def set_preferred_column_widths(self, widths: tuple[int, ...]) -> None:
        self._preferred_column_widths = widths
        self._fit_columns()

    def resizeEvent(self, event: QtGui.QResizeEvent) -> None:
        super().resizeEvent(event)
        self._fit_columns()

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        super().showEvent(event)
        self._fit_columns()

    def _fit_columns(self) -> None:
        column_count = self.model().columnCount() if self.model() is not None else 0
        widths = self._preferred_column_widths[:column_count]
        if not widths:
            return
        available_width = self.viewport().width()
        preferred_width = sum(widths)
        scale = min(1.6, max(0.72, available_width / preferred_width))
        scaled_widths = [round(width * scale) for width in widths]
        last_column_width = scaled_widths[-1] + available_width - sum(scaled_widths)
        if last_column_width >= 40:
            scaled_widths[-1] = last_column_width
        for column, width in enumerate(scaled_widths):
            self.setColumnWidth(column, width)


class KpiPage(QtWidgets.QWidget):
    """Embedded local KPI workspace, scoped by the current server authority."""

    def __init__(self, *, scope_provider, worker_registry, parent=None) -> None:
        super().__init__(parent)
        self.setProperty("nativeWorkspace", True)
        self._scope_provider = scope_provider
        self._worker_registry = worker_registry
        self._paths: list[str] = []
        self._report: ValidationReport | None = None
        self._analysis_worker = None
        self._interactive_export_worker = None
        monthly_headers = (
            "Branch",
            "Channel",
            "Sales Current",
            "Sales Compare",
            "Sales Diff",
            "Sales %",
            "GC Current",
            "GC Compare",
            "GC Diff",
            "GC %",
            "APC Current",
            "APC Compare",
        )
        self.month_models: dict[int, _TableModel] = {
            month: _TableModel(monthly_headers) for month in range(1, 13)
        }
        self.annual_model = _TableModel(monthly_headers)
        self.month_tables: dict[int, _ResponsiveTableView] = {}
        self.channel_table_model = self.month_models[1]
        self._build_ui()

    def _build_ui(self) -> None:
        self.form = self
        load_kpi_ui(self.form, "kpi_page")
        self.workspace_scroll_area = require_widget(
            self.form,
            QtWidgets.QScrollArea,
            "workspaceScrollArea",
        )
        self.workspace_scroll_area.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.workspace_scroll_area.setVerticalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.workspace_scroll_area.widget().setMinimumWidth(0)
        workspace_layout = self.workspace_scroll_area.widget().layout()
        workspace_layout.setContentsMargins(8, 6, 8, 6)
        workspace_layout.setSpacing(6)
        self.workspace_scroll_area.widget().setSizePolicy(
            # The workspace owns responsive reflow.  Let the scroll area shrink
            # its content to the available viewport instead of allowing child
            # size hints (notably the report toolbar) to create page-level
            # horizontal scrolling at compact widths.
            QtWidgets.QSizePolicy.Policy.Ignored,
            QtWidgets.QSizePolicy.Policy.Preferred,
        )
        self.workspace_scroll_area.viewport().installEventFilter(self)
        self.toolbar_container = require_widget(self.form, QtWidgets.QWidget, "kpiToolbar")
        self.filters_container = require_widget(self.form, QtWidgets.QWidget, "kpiFilters")
        self.toolbar_container.setProperty("uiRole", "standardToolbar")
        self.toolbar_container.setMinimumWidth(0)
        self.toolbar_container.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed,
        )
        self.filters_container.setMinimumWidth(0)
        self.filters_container.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Fixed,
        )
        self.action_layout = require_object(self.form, QtWidgets.QGridLayout, "actionLayout")
        self.filters_layout = require_object(self.form, QtWidgets.QHBoxLayout, "filtersLayout")
        self.more_button = require_widget(self.form, QtWidgets.QToolButton, "kpiMoreButton")
        self.add_files_button = require_widget(self.form, QtWidgets.QPushButton, "addFilesButton")
        self.add_folder_button = require_widget(self.form, QtWidgets.QPushButton, "addFolderButton")
        self.remove_files_button = require_widget(
            self.form,
            QtWidgets.QPushButton,
            "clearFilesButton",
        )
        self.analyze_button = require_widget(self.form, QtWidgets.QPushButton, "analyzeButton")
        self.export_excel_button = require_widget(
            self.form,
            QtWidgets.QPushButton,
            "exportExcelButton",
        )
        self.export_button = require_widget(
            self.form,
            QtWidgets.QPushButton,
            "exportMarkdownButton",
        )
        self.export_interactive_button = require_widget(
            self.form,
            QtWidgets.QPushButton,
            "exportInteractiveButton",
        )
        self.analyze_button.setProperty("variant", "primary")
        for button in (
            self.add_files_button,
            self.add_folder_button,
            self.remove_files_button,
            self.export_excel_button,
            self.export_button,
            self.export_interactive_button,
        ):
            button.setProperty("variant", "secondary")
        self.branch_filter = require_widget(self.form, QtWidgets.QComboBox, "branchFilter")
        self.current_year_filter = require_widget(
            self.form,
            QtWidgets.QComboBox,
            "currentYearFilter",
        )
        self.compare_year_filter = require_widget(
            self.form,
            QtWidgets.QComboBox,
            "compareYearFilter",
        )
        self.month_tabs = require_widget(self.form, QtWidgets.QTabWidget, "monthTabs")
        self.channel_detail_tabs = self.month_tabs
        self.content_tabs = require_widget(self.form, QtWidgets.QTabWidget, "contentTabs")
        self.status_label = require_widget(self.form, QtWidgets.QLabel, "statusBar")
        self.activity_entries = require_widget(self.form, QtWidgets.QListWidget, "activityEntries")
        self.dashboard_layout = require_object(
            self.form,
            QtWidgets.QHBoxLayout,
            "dashboardLayout",
        )
        self.dashboard_host = require_widget(self.form, QtWidgets.QWidget, "dashboardHost")
        dashboard_host_layout = require_object(
            self.dashboard_host,
            QtWidgets.QVBoxLayout,
            "dashboardHostLayout",
        )

        self.analyze_button.setObjectName("primaryButton")
        self.export_button.setEnabled(False)
        self.export_excel_button.setEnabled(False)
        self.export_interactive_button.setEnabled(False)
        self._action_buttons = (
            self.add_files_button,
            self.add_folder_button,
            self.remove_files_button,
            self.analyze_button,
            self.export_excel_button,
            self.export_button,
            self.export_interactive_button,
        )
        for button in self._action_buttons:
            button.setMinimumWidth(0)
            button.setSizePolicy(
                # Actions stay compact and readable; the filter group owns
                # the expandable desktop space instead of producing oversized
                # command buttons in the Sales KPI workspace.
                QtWidgets.QSizePolicy.Policy.Minimum,
                QtWidgets.QSizePolicy.Policy.Minimum,
            )
            button.setProperty("toolbarActionAvailable", True)
        self.filters_layout.setSpacing(UI_METRICS.toolbar_horizontal_gap)
        for combo in (
            self.branch_filter,
            self.current_year_filter,
            self.compare_year_filter,
        ):
            combo.setMinimumWidth(0)
            combo.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Expanding,
                QtWidgets.QSizePolicy.Policy.Fixed,
            )
        configure_more_menu(
            self.more_button,
            (
                self.add_folder_button,
                self.remove_files_button,
                self.export_excel_button,
                self.export_button,
                self.export_interactive_button,
            ),
            before_show=self._refresh_more_action_availability,
        )
        self._toolbar_breakpoint = ""
        self._apply_stable_toolbar_layout()
        self._refresh_more_action_availability()
        self._build_month_pages()

        self.dashboard_view = InteractiveDashboard()
        self.dashboard_view.setMinimumWidth(0)
        self.dashboard_view.table.setMinimumHeight(280)
        self.dashboard_view.table.horizontalHeader().setStretchLastSection(True)
        dashboard_host_layout.addWidget(self.dashboard_view)
        self._dashboard_is_compact = False
        for card_name in (
            "salesCard",
            "growthCard",
            "guestsCard",
            "averageCard",
            "mixCard",
            "differenceCard",
        ):
            card = require_widget(self.form, QtWidgets.QFrame, card_name)
            card.setProperty("uiRole", "card")
            for label in card.findChildren(QtWidgets.QLabel):
                label.setWordWrap(True)

        self.sidebar_logs = require_widget(self.form, QtWidgets.QFrame, "sidebarLogs")
        self.sidebar_logs.setProperty("uiRole", "card")
        require_widget(self.form, QtWidgets.QLabel, "activityTitle").setProperty(
            "textRole", "sectionTitle"
        )
        require_widget(self.form, QtWidgets.QLabel, "activityDescription").setProperty(
            "textRole", "mutedStatus"
        )
        self.sidebar_logs.setMinimumWidth(_KPI_ACTIVITY_WIDTH)
        self.sidebar_logs.setMaximumWidth(_KPI_ACTIVITY_WIDTH)
        self.sidebar_logs.setSizePolicy(
            QtWidgets.QSizePolicy.Policy.Expanding,
            QtWidgets.QSizePolicy.Policy.Minimum,
        )
        self.activity_toggle = QtWidgets.QToolButton(self)
        self.activity_toggle.setText("Activity")
        self.activity_toggle.setCheckable(True)
        self.activity_toggle.setToolTip("Show or hide import activity and validation details")
        self.activity_toggle.toggled.connect(self._apply_responsive_dashboard)
        self.content_tabs.setCornerWidget(self.activity_toggle)
        for table in (*self.month_tables.values(), self.annual_table):
            table.setMinimumHeight(180)
            table.setSizePolicy(
                QtWidgets.QSizePolicy.Policy.Expanding,
                QtWidgets.QSizePolicy.Policy.Expanding,
            )
            table.horizontalHeader().setStretchLastSection(True)

        self.dashboard_layout.setDirection(QtWidgets.QBoxLayout.Direction.LeftToRight)
        self.dashboard_layout.setStretch(0, 1)
        self.dashboard_layout.setStretch(1, 0)

        self.dashboard_controller = KpiDashboardController(self.dashboard_view, self)
        self.dashboard_controller.activity_logged.connect(self._append_activity)
        self._clear_report_tables()

        self.add_files_button.clicked.connect(self._select_files)
        self.add_folder_button.clicked.connect(self._select_folder)
        self.remove_files_button.clicked.connect(self._clear_files)
        self.analyze_button.clicked.connect(self._analyze)
        self.export_button.clicked.connect(self._export_report)
        self.export_excel_button.clicked.connect(self._export_excel_report)
        self.export_interactive_button.clicked.connect(self._export_interactive_dashboard)
        self.branch_filter.currentIndexChanged.connect(self._refresh_report_tables)
        self.branch_filter.currentIndexChanged.connect(self._refresh_dashboard)
        self.current_year_filter.currentIndexChanged.connect(self._current_year_changed)
        self.compare_year_filter.currentIndexChanged.connect(self._refresh_report_tables)
        self.compare_year_filter.currentIndexChanged.connect(self._refresh_dashboard)
        self.month_tabs.currentChanged.connect(self._month_tab_changed)

    def _available_toolbar_width(self) -> int:
        workspace_layout = self.workspace_scroll_area.widget().layout()
        margins = workspace_layout.contentsMargins()
        return max(
            0,
            self.workspace_scroll_area.viewport().width() - margins.left() - margins.right(),
        )

    def eventFilter(self, watched, event):  # noqa: N802 - Qt API
        if event.type() == QtCore.QEvent.Type.Resize and hasattr(self, "activity_toggle"):
            self._apply_stable_toolbar_layout()
            self._apply_responsive_dashboard()
        return super().eventFilter(watched, event)

    def _apply_responsive_dashboard(self) -> None:
        """Give report content priority; activity is an on-demand inspector."""
        if not hasattr(self, "activity_toggle"):
            return
        compact = False
        self._dashboard_is_compact = compact
        self.dashboard_layout.setDirection(
            QtWidgets.QBoxLayout.Direction.TopToBottom
            if compact
            else QtWidgets.QBoxLayout.Direction.LeftToRight
        )
        # Do not reserve a permanent empty card beside the report.  Activity
        # remains directly available from the tab-corner control and opens as
        # soon as a meaningful import/validation event is logged.
        self.sidebar_logs.setVisible(self.activity_toggle.isChecked())
        self.sidebar_logs.setMinimumWidth(0 if compact else _KPI_ACTIVITY_WIDTH)
        self.sidebar_logs.setMaximumWidth(16777215 if compact else _KPI_ACTIVITY_WIDTH)
        self.sidebar_logs.setMaximumHeight(140 if compact else 16777215)
        self.activity_toggle.setVisible(True)
        self.dashboard_layout.setStretch(0, 1)
        self.dashboard_layout.setStretch(1, 0)

    def _build_month_pages(self) -> None:
        self.month_names: dict[int, str] = {}
        for month in range(1, 13):
            month_name = calendar.month_name[month]
            self.month_names[month] = month_name
            table = _ResponsiveTableView()
            table.setModel(self.month_models[month])
            self._configure_data_table(table, "monthly")
            self.month_tables[month] = table
            self.month_tabs.addTab(table, month_name[:3])
            self.month_tabs.setTabToolTip(month - 1, month_name)

        self.annual_table = _ResponsiveTableView()
        self.annual_table.setModel(self.annual_model)
        self._configure_data_table(self.annual_table, "monthly")
        self.month_tabs.addTab(self.annual_table, "Annual")
        self.month_tabs.setTabToolTip(12, "Annual channel comparison")
        self.channel_table = self.month_tables[1]

    def showEvent(self, event: QtGui.QShowEvent) -> None:
        super().showEvent(event)
        if hasattr(self, "toolbar_container"):
            self.layout().activate()
            self._apply_stable_toolbar_layout()
            self.workspace_scroll_area.widget().layout().activate()
            self._apply_responsive_dashboard()

    def resizeEvent(self, event: QtGui.QResizeEvent) -> None:
        super().resizeEvent(event)
        if not hasattr(self, "dashboard_layout"):
            return
        self.layout().activate()
        self._apply_stable_toolbar_layout()
        self.workspace_scroll_area.widget().layout().activate()
        self._apply_responsive_dashboard()

    def _apply_stable_toolbar_layout(self) -> None:
        """Keep desktop commands and filters in their original row."""
        compact = False
        breakpoint = "compact" if compact else "wide"
        if self._toolbar_breakpoint == breakpoint:
            return
        self._toolbar_breakpoint = breakpoint
        self.toolbar_container.setProperty("toolbarBreakpoint", breakpoint)
        for widget in (*self._action_buttons, self.more_button, self.filters_container):
            self.action_layout.removeWidget(widget)
        for column in range(8):
            self.action_layout.setColumnStretch(column, 0)
        visible = (self.add_files_button, self.analyze_button) if compact else self._action_buttons
        for button in self._action_buttons:
            button.setVisible(button in visible)
        for column, button in enumerate(visible):
            self.action_layout.addWidget(button, 0, column)
            self.action_layout.setColumnStretch(column, 0)
        self.more_button.setVisible(compact)
        self.action_layout.addWidget(self.more_button, 0, len(visible))
        if compact:
            # Narrow workspaces keep the primary actions discoverable and
            # give the filters their own usable row instead of clipping them.
            self.action_layout.addWidget(self.filters_container, 1, 0, 1, len(visible) + 1)
        else:
            # Desktop has one practical horizontal toolbar: actions, then the
            # expanding filters.  This reclaims the old empty second row.
            filter_column = len(visible) + 1
            self.action_layout.addWidget(self.filters_container, 0, filter_column)
            self.action_layout.setColumnStretch(filter_column, 3)
        self.toolbar_container.setProperty("toolbarSingleRow", not compact)

    @QtCore.Slot(int)
    def _month_tab_changed(self, index: int) -> None:
        if index < 12:
            month = index + 1
            self.channel_table_model = self.month_models[month]
            self.channel_table = self.month_tables[month]
        elif index == 12:
            self.channel_table_model = self.annual_model
            self.channel_table = self.annual_table

    @staticmethod
    def _configure_data_table(table: _ResponsiveTableView, table_kind: str) -> None:
        table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        table.setAlternatingRowColors(True)
        table.setSortingEnabled(False)
        table.verticalHeader().setVisible(False)
        header = table.horizontalHeader()
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        table.verticalHeader().setDefaultSectionSize(25)
        table.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        widths = {
            "monthly": (82, 112, 78, 78, 74, 56, 62, 62, 60, 52, 76, 76, 92, 92),
        }[table_kind]
        table.set_preferred_column_widths(widths)

    def _select_files(self) -> None:
        paths, _ = QtWidgets.QFileDialog.getOpenFileNames(
            self,
            "Select Tabwise and Sourcewise CSV reports",
            str(Path.home()),
            "CSV files (*.csv);;All files (*)",
        )
        self._import_paths(paths)

    def _select_folder(self) -> None:
        folder = QtWidgets.QFileDialog.getExistingDirectory(
            self,
            "Select folder containing sales CSV reports",
            str(Path.home()),
        )
        if not folder:
            return
        paths = sorted(str(path) for path in Path(folder).glob("*.csv"))
        if not paths:
            message = "The selected folder does not contain CSV files."
            self.status_label.setText(message)
            self._append_activity(message)
            return
        self._import_paths(paths)

    def _import_paths(self, paths: list[str]) -> None:
        if not paths:
            return
        new_paths = list(dict.fromkeys(str(path) for path in paths))
        self._paths = list(dict.fromkeys([*self._paths, *new_paths]))
        self._report = None
        self._refresh_more_action_availability()
        self.export_button.setEnabled(False)
        self.export_excel_button.setEnabled(False)
        self.export_interactive_button.setEnabled(False)
        self._clear_report_tables()
        self.status_label.setText(
            f"Checking {len(new_paths)} selected file(s) locally; unsupported reports "
            "will be listed in Activity."
        )
        self._analyze()

    def _clear_files(self) -> None:
        self._paths.clear()
        self._report = None
        self._refresh_more_action_availability()
        self._clear_report_tables()
        self.export_button.setEnabled(False)
        self.export_excel_button.setEnabled(False)
        self.export_interactive_button.setEnabled(False)
        self.status_label.setText("Selection cleared.")

    def _analyze(self) -> None:
        if self._analysis_worker is not None:
            return
        if not self._paths:
            message = "Add Tabwise or Sourcewise CSV files before analyzing."
            self.status_label.setText(message)
            self._append_activity(message)
            return
        self._report = None
        self._refresh_more_action_availability()
        self.export_button.setEnabled(False)
        self.export_excel_button.setEnabled(False)
        self.export_interactive_button.setEnabled(False)
        self._clear_report_tables()
        self._set_busy(True)
        self.status_label.setText(
            "Reading and extracting CSV data locally; daily reconciliation runs when "
            "both report types are selected…"
        )
        allowed_outlets = self._authorized_outlets()

        def _work(progress_callback=None):
            del progress_callback
            return analyze_csv_files(self._paths.copy(), allowed_outlets=allowed_outlets)

        self._analysis_worker = self._worker_registry.start(
            _work,
            on_result=self._analysis_completed,
            on_error=self._analysis_failed,
            on_finished=self._analysis_finished,
            operation_key="kpi:local-analysis",
        )

    def _authorized_outlets(self) -> set[str] | None:
        """Return only branch names granted by the current server authority."""
        context, branches = self._scope_provider()
        if not isinstance(context, PermissionContext):
            return set()
        if PermissionService.can_view_all(permission_context=context):
            return None
        return {str(branch).strip() for branch in branches or () if str(branch).strip()}

    @QtCore.Slot(object)
    def _analysis_completed(self, result: object) -> None:
        if not isinstance(result, ValidationReport):
            self._analysis_failed("The validator returned an unexpected result.")
            return
        self._report = result
        self._refresh_more_action_availability()
        partial_count = sum(bool(file.skipped_rows) for file in result.files)
        skipped_count = len(result.skipped_files)
        for skipped in result.skipped_files:
            self._append_activity(f"Skipped {skipped.path.name}: {skipped.reason}")
        for file in result.files:
            if file.skipped_rows:
                self._append_activity(
                    f"Partial {file.path.name}: skipped {file.skipped_rows} rows with "
                    "missing or invalid outlet/date values."
                )
        if not result.files:
            if result.skipped_files:
                self.status_label.setText(
                    f"Import failed: 0 processed, {skipped_count} skipped; "
                    "no supported sales data was found."
                )
            else:
                self.status_label.setText(
                    "No sales rows matched the restaurant branches assigned to your account."
                )
            self._clear_report_tables()
            return
        self._populate_report_tables(result)
        self.export_button.setEnabled(True)
        self.export_excel_button.setEnabled(True)
        self.export_interactive_button.setEnabled(self.dashboard_view.snapshot is not None)
        import_summary = (
            f"Import completed: {len(result.files)} processed, {skipped_count} skipped, "
            f"{partial_count} partial."
        )
        if result.comparison_available:
            self.status_label.setText(
                f"{import_summary} Extracted {result.branch_days_extracted:,} outlet-days; "
                f"{result.branch_days_reconciled:,}/{result.branch_days_checked:,} "
                f"reconciled; {len(result.issues):,} issue(s) surfaced."
            )
        else:
            report_kind = result.files[0].report_kind
            missing_kind = "Sourcewise" if report_kind == "Tabwise" else "Tabwise"
            self.status_label.setText(
                f"{import_summary} {len(result.outlets)} branches and "
                f"{result.branch_days_extracted:,} outlet-days discovered from "
                f"{report_kind}; add a {missing_kind} report to reconcile."
            )

    def _clear_report_tables(self) -> None:
        self.dashboard_controller.set_report(None)
        for month in range(1, 13):
            self.month_models[month].replace(
                (
                    "Branch",
                    "Channel",
                    "Sales Current",
                    "Sales Compare",
                    "Sales Diff",
                    "Sales %",
                    "GC Current",
                    "GC Compare",
                    "GC Diff",
                    "GC %",
                    "APC Current",
                    "APC Compare",
                ),
                [],
            )
            self.month_tabs.setTabEnabled(month - 1, False)
        self.annual_model.replace(
            (
                "Branch",
                "Channel",
                "Sales Current",
                "Sales Compare",
                "Sales Diff",
                "Sales %",
                "GC Current",
                "GC Compare",
                "GC Diff",
                "GC %",
                "APC Current",
                "APC Compare",
            ),
            [],
        )
        self.month_tabs.setTabEnabled(12, False)
        for control in (
            self.branch_filter,
            self.current_year_filter,
            self.compare_year_filter,
        ):
            control.blockSignals(True)
            control.clear()
            control.setEnabled(False)
            control.blockSignals(False)

    def _populate_report_tables(self, report: ValidationReport) -> None:
        self.branch_filter.blockSignals(True)
        self.branch_filter.clear()
        self.branch_filter.addItem("All branches", None)
        for outlet in sorted(report.outlets):
            self.branch_filter.addItem(outlet, outlet)
        self.branch_filter.setEnabled(bool(report.outlets))
        self.branch_filter.blockSignals(False)

        years = sorted(report.years, reverse=True)
        self.current_year_filter.blockSignals(True)
        self.current_year_filter.clear()
        for year in years:
            self.current_year_filter.addItem(str(year), year)
        self.current_year_filter.setEnabled(bool(years))
        self.current_year_filter.blockSignals(False)

        self._populate_compare_years(years, years[0] if years else None)
        self.dashboard_controller.set_report(report)
        self.month_tabs.setTabEnabled(12, True)
        self._refresh_report_tables()
        self._refresh_dashboard()

    def _populate_compare_years(self, years: list[int], current_year: int | None) -> None:
        old_compare = self.compare_year_filter.currentData()
        self.compare_year_filter.blockSignals(True)
        self.compare_year_filter.clear()
        self.compare_year_filter.addItem("No comparison", None)
        for year in years:
            if year != current_year:
                self.compare_year_filter.addItem(str(year), year)
        preferred = old_compare if old_compare != current_year else None
        if preferred is None and current_year is not None:
            preferred = next((year for year in years if year < current_year), None)
        self.compare_year_filter.setCurrentIndex(
            max(0, self.compare_year_filter.findData(preferred))
        )
        self.compare_year_filter.setEnabled(self.compare_year_filter.count() > 1)
        self.compare_year_filter.blockSignals(False)

    @QtCore.Slot()
    def _current_year_changed(self) -> None:
        if self._report is not None:
            years = sorted(self._report.years, reverse=True)
            self._populate_compare_years(years, self.current_year_filter.currentData())
        self._refresh_report_tables()
        self._refresh_dashboard()

    @QtCore.Slot()
    def _refresh_dashboard(self) -> None:
        branch = self.branch_filter.currentData()
        current_year = self.current_year_filter.currentData()
        compare_year = self.compare_year_filter.currentData()
        self.dashboard_controller.set_filters(
            branch=str(branch) if branch is not None else None,
            current_year=current_year if isinstance(current_year, int) else None,
            compare_year=compare_year if isinstance(compare_year, int) else None,
        )

    @QtCore.Slot()
    def _refresh_report_tables(self) -> None:
        report = self._report
        if report is None:
            return
        branch_value = self.branch_filter.currentData()
        outlets = [str(branch_value)] if branch_value is not None else sorted(report.outlets)
        current_year = self.current_year_filter.currentData()
        compare_year = self.compare_year_filter.currentData()
        selected_years = [year for year in (current_year, compare_year) if isinstance(year, int)]
        current_label = str(current_year) if isinstance(current_year, int) else "Current"
        compare_label = str(compare_year) if isinstance(compare_year, int) else "Compare"
        headers = (
            "Branch",
            "Channel",
            f"Sales {current_label}",
            f"Sales {compare_label}",
            "Sales Diff",
            "Sales %",
            f"GC {current_label}",
            f"GC {compare_label}",
            "GC Diff",
            "GC %",
            f"APC {current_label}",
            f"APC {compare_label}",
        )
        available_months = {
            month
            for kind_totals in report.monthly_totals.values()
            for (outlet, year, month) in kind_totals
            if outlet in outlets and year in selected_years
        }
        enabled_months: set[int] = set()
        for month in range(1, 13):
            rows: list[tuple[str, ...]] = []
            if month in available_months:
                enabled_months.add(month)
            groups = (
                [("All branches", outlets)] if branch_value is None else [(outlets[0], outlets)]
            )
            for group_name, group_outlets in groups:
                group_has_data = any(
                    (outlet, year, month) in report.monthly_totals[kind]
                    for outlet in group_outlets
                    for year in selected_years
                    for kind in ("Tabwise", "Sourcewise")
                )
                if month not in available_months or not group_has_data:
                    continue
                current_channel_values = {
                    channel_row: self._aggregate_channel_value(
                        report, group_outlets, current_year, month, channel_row
                    )
                    for channel_row, _ in COMPARISON_CHANNELS
                }
                compare_channel_values = {
                    channel_row: self._aggregate_channel_value(
                        report, group_outlets, compare_year, month, channel_row
                    )
                    for channel_row, _ in COMPARISON_CHANNELS
                }
                for channel_row, channel_name in COMPARISON_CHANNELS:
                    current_pair = current_channel_values[channel_row]
                    compare_pair = compare_channel_values[channel_row]
                    current_sales = current_pair[0] if current_pair is not None else None
                    compare_sales = compare_pair[0] if compare_pair is not None else None
                    current_bills = current_pair[1] if current_pair is not None else None
                    compare_bills = compare_pair[1] if compare_pair is not None else None
                    sales_difference = (
                        current_sales - compare_sales
                        if current_sales is not None and compare_sales is not None
                        else None
                    )
                    gc_difference = (
                        current_bills - compare_bills
                        if current_bills is not None and compare_bills is not None
                        else None
                    )
                    rows.append(
                        (
                            group_name,
                            channel_name,
                            _format_money(current_sales),
                            _format_money(compare_sales),
                            _format_money(sales_difference),
                            _format_percent(sales_difference, compare_sales),
                            _format_count(current_bills),
                            _format_count(compare_bills),
                            _format_count(gc_difference),
                            _format_percent(gc_difference, compare_bills),
                            _format_average_check(current_sales, current_bills),
                            _format_average_check(compare_sales, compare_bills),
                        )
                    )
                current_pairs = list(current_channel_values.values())
                compare_pairs = list(compare_channel_values.values())
                current_total_sales = sum(
                    (pair[0] for pair in current_pairs if pair is not None),
                    Decimal(0),
                )
                compare_total_sales = sum(
                    (pair[0] for pair in compare_pairs if pair is not None),
                    Decimal(0),
                )
                current_total_gc = sum(pair[1] for pair in current_pairs if pair is not None)
                compare_total_gc = sum(pair[1] for pair in compare_pairs if pair is not None)
                current_exists = any(pair is not None for pair in current_pairs)
                compare_exists = any(pair is not None for pair in compare_pairs)
                sales_difference = (
                    current_total_sales - compare_total_sales
                    if current_exists and compare_exists
                    else None
                )
                gc_difference = (
                    current_total_gc - compare_total_gc
                    if current_exists and compare_exists
                    else None
                )
                rows.append(
                    (
                        group_name,
                        "Grand Total",
                        _format_money(current_total_sales if current_exists else None),
                        _format_money(compare_total_sales if compare_exists else None),
                        _format_money(sales_difference),
                        _format_percent(sales_difference, compare_total_sales),
                        _format_count(current_total_gc if current_exists else None),
                        _format_count(compare_total_gc if compare_exists else None),
                        _format_count(gc_difference),
                        _format_percent(gc_difference, compare_total_gc),
                        _format_average_check(
                            current_total_sales if current_exists else None,
                            current_total_gc if current_exists else None,
                        ),
                        _format_average_check(
                            compare_total_sales if compare_exists else None,
                            compare_total_gc if compare_exists else None,
                        ),
                    )
                )
                current_net_total = self._sum_month_net_totals(
                    report, group_outlets, current_year, month
                )
                compare_net_total = self._sum_month_net_totals(
                    report, group_outlets, compare_year, month
                )
                net_sales_difference = (
                    current_net_total[0] - compare_net_total[0]
                    if current_net_total is not None and compare_net_total is not None
                    else None
                )
                net_gc_difference = (
                    current_net_total[1] - compare_net_total[1]
                    if current_net_total is not None and compare_net_total is not None
                    else None
                )
                rows.append(
                    (
                        group_name,
                        "Total Net sale & GCs",
                        _format_money(
                            current_net_total[0] if current_net_total is not None else None
                        ),
                        _format_money(
                            compare_net_total[0] if compare_net_total is not None else None
                        ),
                        _format_money(net_sales_difference),
                        _format_percent(
                            net_sales_difference,
                            compare_net_total[0] if compare_net_total is not None else None,
                        ),
                        _format_count(
                            current_net_total[1] if current_net_total is not None else None
                        ),
                        _format_count(
                            compare_net_total[1] if compare_net_total is not None else None
                        ),
                        _format_count(net_gc_difference),
                        _format_percent(
                            net_gc_difference,
                            compare_net_total[1] if compare_net_total is not None else None,
                        ),
                        _format_average_check(
                            current_net_total[0] if current_net_total is not None else None,
                            current_net_total[1] if current_net_total is not None else None,
                        ),
                        _format_average_check(
                            compare_net_total[0] if compare_net_total is not None else None,
                            compare_net_total[1] if compare_net_total is not None else None,
                        ),
                    )
                )
            self.month_models[month].replace(headers, rows)
            self.month_tabs.setTabEnabled(month - 1, month in enabled_months)

        annual_values: dict[int, dict[int, tuple[Decimal, int]]] = {}
        for year in (current_year, compare_year):
            if not isinstance(year, int):
                continue
            year_values: dict[int, tuple[Decimal, int]] = {}
            for outlet in outlets:
                year_months = {
                    month
                    for kind in ("Tabwise", "Sourcewise")
                    for candidate_outlet, candidate_year, month in report.monthly_totals[kind]
                    if candidate_outlet == outlet and candidate_year == year
                }
                for month in year_months:
                    channel_values = comparison_channel_values(report, outlet, year, month)
                    for channel_row, _ in COMPARISON_CHANNELS:
                        pair = self._channel_value(
                            report, outlet, year, month, channel_row, channel_values
                        )
                        if pair is None:
                            continue
                        previous = year_values.get(channel_row, (Decimal(0), 0))
                        year_values[channel_row] = (
                            previous[0] + pair[0],
                            previous[1] + pair[1],
                        )
            annual_values[year] = year_values

        annual_branch = "All branches" if branch_value is None else str(branch_value)
        current_annual = (
            annual_values.get(current_year, {}) if isinstance(current_year, int) else {}
        )
        compare_annual = (
            annual_values.get(compare_year, {}) if isinstance(compare_year, int) else {}
        )
        annual_rows: list[tuple[str, ...]] = []
        for channel_row, channel_name in COMPARISON_CHANNELS:
            current_pair = current_annual.get(channel_row)
            compare_pair = compare_annual.get(channel_row)
            current_sales = current_pair[0] if current_pair is not None else None
            compare_sales = compare_pair[0] if compare_pair is not None else None
            current_gc = current_pair[1] if current_pair is not None else None
            compare_gc = compare_pair[1] if compare_pair is not None else None
            sales_difference = (
                current_sales - compare_sales
                if current_sales is not None and compare_sales is not None
                else None
            )
            gc_difference = (
                current_gc - compare_gc
                if current_gc is not None and compare_gc is not None
                else None
            )
            annual_rows.append(
                (
                    annual_branch,
                    channel_name,
                    _format_money(current_sales),
                    _format_money(compare_sales),
                    _format_money(sales_difference),
                    _format_percent(sales_difference, compare_sales),
                    _format_count(current_gc),
                    _format_count(compare_gc),
                    _format_count(gc_difference),
                    _format_percent(gc_difference, compare_gc),
                    _format_average_check(current_sales, current_gc),
                    _format_average_check(compare_sales, compare_gc),
                )
            )

        current_annual_exists = bool(current_annual)
        compare_annual_exists = bool(compare_annual)
        current_total_sales = sum((pair[0] for pair in current_annual.values()), Decimal(0))
        compare_total_sales = sum((pair[0] for pair in compare_annual.values()), Decimal(0))
        current_total_gc = sum(pair[1] for pair in current_annual.values())
        compare_total_gc = sum(pair[1] for pair in compare_annual.values())
        annual_sales_difference = (
            current_total_sales - compare_total_sales
            if current_annual_exists and compare_annual_exists
            else None
        )
        annual_gc_difference = (
            current_total_gc - compare_total_gc
            if current_annual_exists and compare_annual_exists
            else None
        )
        annual_rows.append(
            (
                annual_branch,
                "Grand Total",
                _format_money(current_total_sales if current_annual_exists else None),
                _format_money(compare_total_sales if compare_annual_exists else None),
                _format_money(annual_sales_difference),
                _format_percent(annual_sales_difference, compare_total_sales),
                _format_count(current_total_gc if current_annual_exists else None),
                _format_count(compare_total_gc if compare_annual_exists else None),
                _format_count(annual_gc_difference),
                _format_percent(annual_gc_difference, compare_total_gc),
                _format_average_check(
                    current_total_sales if current_annual_exists else None,
                    current_total_gc if current_annual_exists else None,
                ),
                _format_average_check(
                    compare_total_sales if compare_annual_exists else None,
                    compare_total_gc if compare_annual_exists else None,
                ),
            )
        )
        current_net_annual = self._sum_net_totals(
            report, outlets, current_year if isinstance(current_year, int) else None
        )
        compare_net_annual = self._sum_net_totals(
            report, outlets, compare_year if isinstance(compare_year, int) else None
        )
        annual_net_sales_difference = (
            current_net_annual[0] - compare_net_annual[0]
            if current_net_annual is not None and compare_net_annual is not None
            else None
        )
        annual_net_gc_difference = (
            current_net_annual[1] - compare_net_annual[1]
            if current_net_annual is not None and compare_net_annual is not None
            else None
        )
        annual_rows.append(
            (
                annual_branch,
                "Total Net sale & GCs",
                _format_money(current_net_annual[0] if current_net_annual else None),
                _format_money(compare_net_annual[0] if compare_net_annual else None),
                _format_money(annual_net_sales_difference),
                _format_percent(
                    annual_net_sales_difference,
                    compare_net_annual[0] if compare_net_annual else None,
                ),
                _format_count(current_net_annual[1] if current_net_annual else None),
                _format_count(compare_net_annual[1] if compare_net_annual else None),
                _format_count(annual_net_gc_difference),
                _format_percent(
                    annual_net_gc_difference,
                    compare_net_annual[1] if compare_net_annual else None,
                ),
                _format_average_check(
                    current_net_annual[0] if current_net_annual else None,
                    current_net_annual[1] if current_net_annual else None,
                ),
                _format_average_check(
                    compare_net_annual[0] if compare_net_annual else None,
                    compare_net_annual[1] if compare_net_annual else None,
                ),
            )
        )
        self.annual_model.replace(headers, annual_rows)
        self.month_tabs.setTabEnabled(12, bool(annual_rows))
        if enabled_months and not self.month_tabs.isTabEnabled(self.month_tabs.currentIndex()):
            self.month_tabs.setCurrentIndex(min(enabled_months) - 1)
        elif not enabled_months:
            self.month_tabs.setCurrentIndex(12)

    @classmethod
    def _sum_net_totals(
        cls,
        report: ValidationReport,
        outlets: list[str],
        year: int | None,
    ) -> tuple[Decimal, int] | None:
        return sum_report_net_totals(report, outlets, year)

    @classmethod
    def _sum_month_net_totals(
        cls,
        report: ValidationReport,
        outlets: list[str],
        year: int | None,
        month: int,
    ) -> tuple[Decimal, int] | None:
        return sum_month_report_net_totals(report, outlets, year, month)

    @classmethod
    def _aggregate_channel_value(
        cls,
        report: ValidationReport,
        outlets: list[str],
        year: int | None,
        month: int,
        channel_row: int,
    ) -> tuple[Decimal, int] | None:
        if year is None:
            return None
        pairs = []
        for outlet in outlets:
            values = comparison_channel_values(report, outlet, year, month)
            pair = cls._channel_value(report, outlet, year, month, channel_row, values)
            if pair is not None:
                pairs.append(pair)
        if not pairs:
            return None
        return (
            sum((pair[0] for pair in pairs), Decimal(0)),
            sum(pair[1] for pair in pairs),
        )

    @staticmethod
    def _channel_value(
        report: ValidationReport,
        outlet: str,
        year: int | None,
        month: int,
        channel_row: int,
        values: dict[int, tuple[Decimal, int]],
    ) -> tuple[Decimal, int] | None:
        if year is None:
            return None
        branch_month = (outlet, year, month)
        tabwise_exists = branch_month in report.monthly_totals["Tabwise"]
        sourcewise_exists = branch_month in report.monthly_totals["Sourcewise"]
        if 3 <= channel_row <= 7 and not tabwise_exists:
            return None
        if channel_row == 9 and not (tabwise_exists or sourcewise_exists):
            return None
        if channel_row == 17 and not tabwise_exists:
            return None
        if 10 <= channel_row <= 16 and not sourcewise_exists:
            return None
        return values.get(channel_row, (Decimal(0), 0))

    @QtCore.Slot(str)
    def _analysis_failed(self, message: str) -> None:
        text = str(message or "Sales analysis failed.")
        self.status_label.setText(f"Analysis failed: {text}")
        self._append_activity(f"Sales analysis failed: {text}")

    @QtCore.Slot(str)
    def _append_activity(self, message: str) -> None:
        timestamp = datetime.now().astimezone().strftime("%H:%M")
        item = QtWidgets.QListWidgetItem(f"{timestamp}  {message}")
        item.setToolTip(message)
        self.activity_entries.insertItem(0, item)
        while self.activity_entries.count() > 80:
            self.activity_entries.takeItem(self.activity_entries.count() - 1)
        if not self.activity_toggle.isChecked():
            self.activity_toggle.setChecked(True)

    def _export_report(self) -> None:
        if self._report is None:
            return
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save validation report",
            str(Path.home() / "herfy-sales-validation.md"),
            "Markdown files (*.md)",
        )
        if not path:
            return
        try:
            Path(path).write_text(self._report.to_markdown(), encoding="utf-8")
        except OSError as exc:
            show_error_message(self, "Could not save report", canonical_error_message("operation_failed"))
            return
        self.status_label.setText(f"Report saved to {path}")

    def _export_excel_report(self) -> None:
        if self._report is None:
            return
        years = sorted(self._report.years, reverse=True)
        year_suffix = (
            f"{years[0]} vs {years[1]}" if len(years) > 1 else str(years[0]) if years else "Report"
        )
        default_name = Path.home() / f"Herfy Branch Sales {year_suffix}.xlsx"
        output_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Export branch worksheets",
            str(default_name),
            "Excel workbooks (*.xlsx)",
        )
        if not output_path:
            return
        if not output_path.lower().endswith(".xlsx"):
            output_path += ".xlsx"
        try:
            saved_path = export_branch_workbook(self._report, output_path)
        except (OSError, ValueError) as exc:
            show_error_message(self, "Excel export failed", canonical_error_message("operation_failed"))
            return
        self.status_label.setText(f"Excel workbook saved to {saved_path}")

    def _export_interactive_dashboard(self) -> None:
        snapshot = self.dashboard_view.snapshot
        if self._report is None or snapshot is None or self._interactive_export_worker is not None:
            return
        default_name = Path.home() / f"HERFY Sales KPI {snapshot.current_year}.html"
        output_path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Export interactive dashboard",
            str(default_name),
            "Interactive dashboards (*.html)",
        )
        if not output_path:
            return
        self._set_busy(True)
        self.status_label.setText("Preparing interactive KPI dashboard…")

        def _work() -> str:
            return str(export_interactive_dashboard(snapshot, output_path))

        self._interactive_export_worker = self._worker_registry.start(
            _work,
            on_result=self._interactive_export_completed,
            on_error=self._interactive_export_failed,
            on_finished=self._interactive_export_finished,
            operation_key="kpi:interactive-export",
            log_exceptions=False,
        )
        if self._interactive_export_worker is None:
            self._set_busy(False)
            self.status_label.setText("Interactive export could not be started.")

    @QtCore.Slot(object)
    def _interactive_export_completed(self, output_path: object) -> None:
        saved_path = str(output_path or "").strip()
        if not saved_path:
            self._interactive_export_failed("The interactive export returned no file.")
            return
        self.status_label.setText(f"Interactive dashboard saved to {saved_path}")
        self._append_activity(f"Exported interactive KPI dashboard to {saved_path}.")

    @QtCore.Slot(str)
    def _interactive_export_failed(self, message: str) -> None:
        safe_text = canonical_error_message("operation_failed")
        self.status_label.setText("Interactive export failed")
        show_error_message(self, "Interactive export failed", safe_text)

    @QtCore.Slot()
    def _interactive_export_finished(self) -> None:
        self._interactive_export_worker = None
        self._set_busy(False)

    def _set_busy(self, busy: bool) -> None:
        self.add_files_button.setEnabled(not busy)
        self.add_folder_button.setEnabled(not busy)
        self.remove_files_button.setEnabled(not busy)
        self.analyze_button.setEnabled(not busy)
        self.export_excel_button.setEnabled(not busy and self._report is not None)
        self.export_button.setEnabled(not busy and self._report is not None)
        self.export_interactive_button.setEnabled(
            not busy and self._report is not None and self.dashboard_view.snapshot is not None
        )

    def _refresh_more_action_availability(self) -> None:
        context, _branches = self._scope_provider()
        can_open_kpi = PermissionService.has_permission(
            "kpi.view",
            permission_context=context if isinstance(context, PermissionContext) else None,
        )
        self.add_folder_button.setProperty("toolbarActionAvailable", can_open_kpi)
        self.remove_files_button.setProperty(
            "toolbarActionAvailable",
            can_open_kpi and bool(self._paths),
        )
        self.export_button.setProperty(
            "toolbarActionAvailable",
            can_open_kpi and self._report is not None and bool(self._report.files),
        )
        self.export_interactive_button.setProperty(
            "toolbarActionAvailable",
            can_open_kpi and self.dashboard_view.snapshot is not None,
        )

    @QtCore.Slot()
    def _analysis_finished(self) -> None:
        self._set_busy(False)
        self._analysis_worker = None

    def dispose(self) -> None:
        self._worker_registry.close()


def _format_percent(
    difference: Decimal | int | None,
    baseline: Decimal | int | None,
) -> str:
    if difference is None or baseline is None:
        return "—"
    if baseline == 0:
        return "N/A"
    percentage = Decimal(difference) / Decimal(baseline) * Decimal(100)
    return f"{percentage:.1f}%"


def _format_average_check(sales: Decimal | None, bills: int | None) -> str:
    if sales is None or bills is None or bills == 0:
        return "—"
    return f"{sales / bills:,.2f}"
