"""Stable, single-row Tracking toolbar and data-table sizing.

Tracking keeps its complete create/edit form in one horizontal toolbar. Width
pressure is handled by compact control metrics and the window's sensible
minimum size; form controls are never silently moved to another toolbar row.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QAbstractItemView, QApplication, QHeaderView, QSizePolicy

from core.errors import UI_OPERATION_EXCEPTIONS
from ui.responsive_toolbar import apply_toolbar_control_metrics
from ui.tables import COL_NAME, COL_STATUS, configure_sortable_table, fit_table_columns
from ui.theme import (
    UI_METRICS,
    ResponsiveProfile,
    apply_profile_properties,
    profile_for_widget,
)
from ui.widgets import refresh_widget_style

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class ToolbarItemPlacement:
    name: str
    row: int
    column: int
    row_span: int = 1
    column_span: int = 1


@dataclass(frozen=True, slots=True)
class ToolbarLayoutSpec:
    mode: str
    placements: tuple[ToolbarItemPlacement, ...]
    column_stretches: tuple[int, ...]


TOOLBAR_MODES = frozenset({"wide", "regular", "compact", "narrow", "small"})
_STABLE_WORKSPACE_PLACEMENTS = (
    ToolbarItemPlacement("branch_field", 0, 0),
    ToolbarItemPlacement("product_field", 0, 1),
    ToolbarItemPlacement("production_field", 0, 2),
    ToolbarItemPlacement("expiry_field", 0, 3),
    ToolbarItemPlacement("quantity_field", 0, 4),
    ToolbarItemPlacement("btn_add", 0, 5),
)
_STABLE_WORKSPACE_STRETCHES = (0, 1, 0, 0, 0, 0)
_LAYOUTS = {
    mode: ToolbarLayoutSpec(mode, _STABLE_WORKSPACE_PLACEMENTS, _STABLE_WORKSPACE_STRETCHES)
    for mode in TOOLBAR_MODES
}


def normalize_toolbar_mode(mode: str | None) -> str:
    value = str(mode or "wide").strip().lower()
    value = {
        "stacked": "small",
        "tablet": "compact",
        "desktop": "regular",
        "extra_wide": "wide",
    }.get(value, value)
    return value if value in TOOLBAR_MODES else "wide"


def toolbar_layout_spec(mode: str | None) -> ToolbarLayoutSpec:
    return _LAYOUTS[normalize_toolbar_mode(mode)]


class TrackingResponsiveLayoutMixin:
    def _apply_control_size_policies(self, mode: str, profile: ResponsiveProfile) -> None:
        """Keep the desktop command strip intact at every window size."""
        try:
            height = UI_METRICS.toolbar_control_height
            minimums = {
                self.branch_selector: UI_METRICS.tracking_branch_input_min_width,
                self.product_entry: UI_METRICS.tracking_product_field_min_width,
                self.prod_edit: UI_METRICS.tracking_date_input_min_width,
                self.exp_edit: UI_METRICS.tracking_date_input_min_width,
                self.qty_entry: UI_METRICS.tracking_quantity_input_min_width,
                self.btn_add: UI_METRICS.tracking_action_min_width,
            }
            for widget in self._tracking_inputs:
                widget.setMinimumHeight(height)
                widget.setMinimumWidth(self._S(minimums[widget]))
                widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            del mode, profile
            for widget, policy in (
                (self.branch_selector, QSizePolicy.Expanding),
                (self.product_entry, QSizePolicy.Expanding),
                (self.prod_edit, QSizePolicy.Expanding),
                (self.exp_edit, QSizePolicy.Expanding),
                (self.qty_entry, QSizePolicy.Expanding),
                (self.btn_add, QSizePolicy.MinimumExpanding),
            ):
                widget.setMaximumWidth(UI_METRICS.widget_maximum_extent)
                widget.setSizePolicy(policy, QSizePolicy.Preferred)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage control sizing failed", exc_info=True)

    def apply_responsive_profile(
        self, profile: ResponsiveProfile | None = None, mode: str | None = None
    ) -> None:
        profile = profile or profile_for_widget(self, app=QApplication.instance())
        apply_profile_properties(self, profile)
        self._apply_responsive_toolbar(profile=profile, semantic_mode=mode)
        self._size_tracking_columns()

    def _apply_responsive_toolbar(
        self,
        *,
        force: bool = False,
        profile: ResponsiveProfile | None = None,
        semantic_mode: str | None = None,
    ) -> None:
        try:
            profile = profile or profile_for_widget(self, app=QApplication.instance())
            available_width = int(self.content_host.viewport().width())
            if available_width <= 1:
                available_width = int(profile.width or self.width() or 1)
            breakpoint = apply_toolbar_control_metrics(
                self.toolbar_frame, self._tracking_inputs, available_width
            )
            mode = {
                "large": "wide",
                "medium": "regular",
                "compact": "compact",
                "small": "small",
            }[breakpoint]
            self.toolbar_frame.setProperty("toolbarSingleRow", True)
            if not force and mode == getattr(self, "_tracking_toolbar_mode", ""):
                return
            self._tracking_toolbar_mode = mode
            self._tracking_semantic_mode = str(semantic_mode or breakpoint).lower()
            self._apply_control_size_policies(mode, profile)
            spec = toolbar_layout_spec(mode)
            for widget in self._tracking_fields:
                self.toolbar_lay.removeWidget(widget)
            for column in range(max(8, self.toolbar_lay.columnCount())):
                self.toolbar_lay.setColumnStretch(column, 0)
            for placement in spec.placements:
                widget = getattr(self, placement.name)
                if placement.name == "btn_add":
                    self.toolbar_lay.addWidget(
                        widget,
                        placement.row,
                        placement.column,
                        placement.row_span,
                        placement.column_span,
                        Qt.AlignBottom,
                    )
                else:
                    self.toolbar_lay.addWidget(
                        widget,
                        placement.row,
                        placement.column,
                        placement.row_span,
                        placement.column_span,
                    )
            for column, stretch in enumerate(spec.column_stretches):
                self.toolbar_lay.setColumnStretch(column, stretch)
            self.toolbar_frame.setProperty("toolbarMode", mode)
            self.toolbar_frame.setProperty("touchUi", profile.touch_mode)
            self._layout_tracking_table_header(mode)
            self.toolbar_lay.invalidate()
            self.toolbar_frame.updateGeometry()
            refresh_widget_style(self.toolbar_frame)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage responsive toolbar layout failed", exc_info=True)

    def _layout_tracking_table_header(self, mode: str) -> None:
        layout = getattr(self, "tracking_table_header_grid", None)
        if layout is None:
            return
        for widget in (
            getattr(self, "table_title", None),
        ):
            if widget is not None:
                layout.removeWidget(widget)
        for column in range(2):
            layout.setColumnStretch(column, 0)

        # Keep the title and filtering controls inside one table surface.
        # Width pressure stays within the table instead of creating a second
        # header row or moving controls elsewhere.
        layout.addWidget(self.table_title, 0, 0)
        layout.setColumnStretch(0, 1)

    def _apply_responsive_table_visibility(self) -> bool:
        for column in range(self.model.columnCount()):
            self.table_view.setColumnHidden(column, False)
        self.table_view.setProperty("portraitSummary", False)
        return False

    def _size_tracking_columns(self) -> None:
        profile = profile_for_widget(self, app=QApplication.instance())
        self._apply_responsive_table_visibility()
        if profile.is_narrow:
            ratios = self.COMPACT_COL_RATIOS
            minimums = self.COMPACT_COL_MIN_WIDTHS
        elif profile.is_tablet:
            ratios = self.TABLET_COL_RATIOS
            minimums = self.TABLET_COL_MIN_WIDTHS
        else:
            ratios = self.TABLE_COL_RATIOS
            minimums = self.TABLE_COL_MIN_WIDTHS
        allow_overflow = bool(profile.is_narrow)
        fit_table_columns(
            self.table_view,
            ratios,
            min_widths=[self._S(value) for value in minimums],
            stretch_columns=(COL_NAME, COL_STATUS),
            allow_overflow=allow_overflow,
        )
        self._lock_tracking_table_layout()

    def _lock_tracking_table_layout(self) -> None:
        try:
            header = self.table_view.horizontalHeader()
            header.setSectionsMovable(False)
            header.setStretchLastSection(False)
            header.setCascadingSectionResizes(False)
            available = max(1, int(self.table_view.viewport().width()))
            total_width = sum(
                (
                    max(1, int(self.table_view.columnWidth(column)))
                    for column in range(self.model.columnCount())
                )
            )
            for column in range(self.model.columnCount()):
                header.setSectionResizeMode(column, QHeaderView.Interactive)
            if total_width <= available:
                for column in (COL_NAME, COL_STATUS):
                    header.setSectionResizeMode(column, QHeaderView.Stretch)
            self.table_view.setDragDropMode(QAbstractItemView.NoDragDrop)
            configure_sortable_table(self.table_view, enabled=True)
            self.table_view.setHorizontalScrollBarPolicy(
                Qt.ScrollBarAsNeeded
                if profile_for_widget(self.table_view).is_narrow
                else Qt.ScrollBarAlwaysOff
            )
            self.table_view.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
            self.table_view.setEditTriggers(QAbstractItemView.NoEditTriggers)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._lock_tracking_table_layout failed", exc_info=True)
