from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QDialog, QGridLayout, QProgressBar

from core.settings import _, resource_path
from ui.designer import load_ui
from ui.dialogs import apply_popup_contract
from ui.window_activation import reveal_window


class UpdateState(str, Enum):
    CHECKING = "CHECKING"
    UP_TO_DATE = "UP_TO_DATE"
    UPDATE_AVAILABLE = "UPDATE_AVAILABLE"
    DOWNLOADING = "DOWNLOADING"
    VERIFYING = "VERIFYING"
    PREPARING_INSTALL = "PREPARING_INSTALL"
    COMPLETED = "COMPLETED"
    HANDOFF_TO_INSTALLER = "HANDOFF_TO_INSTALLER"
    ERROR = "ERROR"


@dataclass
class UpdateDialogState:
    state: UpdateState = UpdateState.CHECKING
    kind: str = ""
    info: Any = None
    mandatory: bool = False
    progress_percent: int | None = None
    downloaded: int = 0
    total: int = 0
    download_path: Path | None = None
    error: str = ""

    def transition(self, state: UpdateState, *, percent: int | None = None, **changes: Any) -> None:
        self.state = state
        self.progress_percent = None if percent is None else max(0, min(100, int(percent)))
        for key, value in changes.items():
            if hasattr(self, key):
                setattr(self, key, value)


class UpdateDialog(QDialog):
    """Non-modal presentation for the verified update workflow.

    Networking, package verification and installer preparation remain owned by
    the update service and scoped worker registry.  This class only presents
    state and user decisions.
    """

    handoff_requested = Signal()
    mandatory_exit_requested = Signal()
    retry_requested = Signal()

    def __init__(
        self, update_manager_factory: Any, current_version: str, worker_registry, parent=None
    ) -> None:
        super().__init__(parent)
        if worker_registry is None:
            raise RuntimeError("UpdateDialog requires a worker registry")
        self.update_manager_factory = update_manager_factory
        self.current_version = str(current_version)
        self.state_model = UpdateDialogState()
        self.workers = worker_registry
        self._manager: Any = None
        self._closed = False

        self.setProperty("uiScope", "update")
        self.setWindowTitle(_("HERFY-TS Update"))
        self._build()
        apply_popup_contract(
            self,
            object_name="UpdateDialog",
            modal=False,
            size_grip=True,
            min_width=440,
            min_height=240,
        )
        self.set_state(UpdateState.CHECKING)

    def _build(self) -> None:
        controls = load_ui(
            self,
            "update_dialog",
            required=(
                "UpdateLogo",
                "UpdateStateBadge",
                "UpdateTitle",
                "UpdateDetail",
                "UpdateProgressBar",
                "UpdateProgressCaption",
                "UpdateCurrentVersion",
                "update_current_caption",
                "UpdateTargetCaption",
                "UpdateTargetVersion",
                "UpdateBytes",
                "update_skip",
                "update_secondary",
                "update_primary",
                "update_action_layout",
            ),
        )
        self.logo = controls["UpdateLogo"]
        self.state_badge = controls["UpdateStateBadge"]
        self.title = controls["UpdateTitle"]
        self.detail = controls["UpdateDetail"]
        self.progress_bar: QProgressBar = controls["UpdateProgressBar"]
        self.progress_caption = controls["UpdateProgressCaption"]
        self.current_version_label = controls["UpdateCurrentVersion"]
        self.current_caption = controls["update_current_caption"]
        self.target_caption = controls["UpdateTargetCaption"]
        self.target_version_label = controls["UpdateTargetVersion"]
        self.bytes_label = controls["UpdateBytes"]
        self.skip = controls["update_skip"]
        self.secondary = controls["update_secondary"]
        self.primary = controls["update_primary"]
        self.action_grid: QGridLayout = controls["update_action_layout"]
        self.current_version_label.setText(self.current_version)
        self.logo.setAlignment(Qt.AlignCenter)
        for label in (
            self.title,
            self.detail,
            self.progress_caption,
            self.current_caption,
            self.current_version_label,
            self.target_caption,
            self.target_version_label,
            self.bytes_label,
        ):
            label.setAlignment(Qt.AlignLeading | Qt.AlignVCenter)
        pixmap = QPixmap(resource_path("resources", "images", "logo.png"))
        if not pixmap.isNull():
            self.logo.setPixmap(pixmap.scaled(26, 26, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.bytes_label.hide()
        self.skip.setText(_("Details"))
        self.skip.setProperty("variant", "secondary")
        self.secondary.setText(_("Later"))
        self.secondary.setProperty("variant", "secondary")
        self.primary.setText(_("Update Now"))
        self.primary.setProperty("variant", "primary")
        self.primary.clicked.connect(self._primary)
        self.secondary.clicked.connect(self.close)
        self.skip.clicked.connect(self._show_details)
        self._apply_responsive_actions()

    def _apply_responsive_actions(self) -> None:
        for button in (self.skip, self.secondary, self.primary):
            self.action_grid.removeWidget(button)
        for column in range(3):
            self.action_grid.setColumnStretch(column, 0)
        self.action_grid.addWidget(self.skip, 0, 0)
        self.action_grid.addWidget(self.secondary, 0, 1)
        self.action_grid.addWidget(self.primary, 0, 2)
        self.action_grid.setColumnStretch(0, 1)

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        self._apply_responsive_actions()

    def bring_to_front(self) -> None:
        reveal_window(self)

    def set_checking(self, *, mandatory: bool = False) -> None:
        self.state_model.mandatory = bool(mandatory)
        self.set_state(UpdateState.CHECKING)

    def set_available(self, kind: str, info: Any, *, mandatory: bool = False) -> None:
        if str(kind) != "installer":
            raise RuntimeError("Production remote updates require the signed installer path")
        self.state_model.kind = "installer"
        self.state_model.info = info
        self.state_model.mandatory = bool(mandatory)
        self.state_model.download_path = None
        self.state_model.error = ""
        self.set_state(UpdateState.UPDATE_AVAILABLE)

    def set_up_to_date(self) -> None:
        self.set_state(UpdateState.UP_TO_DATE)

    def set_error(self, message: str, *, mandatory: bool | None = None) -> None:
        if mandatory is not None:
            self.state_model.mandatory = bool(mandatory)
        if self.state_model.state == UpdateState.VERIFYING:
            self.state_model.error = _("Update verification failed")
        else:
            self.state_model.error = str(message or _("The update could not be completed."))
        self.set_state(UpdateState.ERROR)

    def _target_version(self) -> str:
        info = self.state_model.info
        if info is None:
            return ""
        return str(getattr(info, "target_version", "") or getattr(info, "latest", "") or "").strip()

    @staticmethod
    def _format_bytes(value: int) -> str:
        amount = max(0, int(value))
        for unit in ("B", "KB", "MB", "GB"):
            if amount < 1024 or unit == "GB":
                return f"{amount:.0f} {unit}" if unit == "B" else f"{amount:.1f} {unit}"
            amount /= 1024
        return "0 B"

    @staticmethod
    def _state_label(state: UpdateState) -> str:
        return {
            UpdateState.CHECKING: _("Checking"),
            UpdateState.UP_TO_DATE: _("Up to date"),
            UpdateState.UPDATE_AVAILABLE: _("Available"),
            UpdateState.DOWNLOADING: _("Downloading"),
            UpdateState.VERIFYING: _("Verifying"),
            UpdateState.PREPARING_INSTALL: _("Preparing"),
            UpdateState.COMPLETED: _("Ready to install"),
            UpdateState.HANDOFF_TO_INSTALLER: _("Installing"),
            UpdateState.ERROR: _("Error"),
        }[state]

    def _refresh_state_badge(self, state: UpdateState) -> None:
        self.state_badge.setText(self._state_label(state))
        self.state_badge.setProperty("updateState", state.value)
        self.state_badge.style().unpolish(self.state_badge)
        self.state_badge.style().polish(self.state_badge)

    def _set_progress_state(self, state: UpdateState, percent: int | None) -> None:
        """Keep numeric progress separate from the HERFY mark.

        A determinate value is shown only when the download transport reports
        its verified byte total. Verification and installation are intentionally
        busy states: inventing a percentage there would be misleading.
        """
        indeterminate = state in {
            UpdateState.CHECKING,
            UpdateState.VERIFYING,
            UpdateState.PREPARING_INSTALL,
            UpdateState.HANDOFF_TO_INSTALLER,
        } or (state == UpdateState.DOWNLOADING and percent is None)
        if indeterminate:
            self.progress_bar.setRange(0, 0)
            return
        self.progress_bar.setRange(0, 100)
        if state == UpdateState.COMPLETED:
            self.progress_bar.setValue(100)
        elif state == UpdateState.DOWNLOADING:
            self.progress_bar.setValue(percent or 0)
        else:
            self.progress_bar.setValue(0)

    def set_state(self, state: UpdateState, *, percent: int | None = None) -> None:
        self.state_model.transition(state, percent=percent)
        mandatory = self.state_model.mandatory
        self._refresh_state_badge(state)
        self._set_progress_state(state, percent)

        target = self._target_version()
        self.target_version_label.setText(target or "—")
        self.target_caption.setVisible(bool(target))
        self.target_version_label.setVisible(bool(target))

        if state == UpdateState.CHECKING:
            title = _("Checking for updates")
            detail = _("Checking the signed HERFY-TS update manifest.")
            progress_caption = _("Contacting the update service")
        elif state == UpdateState.UP_TO_DATE:
            title = _("HERFY-TS is up to date")
            detail = _("You are using the latest published version.")
            progress_caption = _("No action is required")
        elif state == UpdateState.UPDATE_AVAILABLE:
            title = _("Update available")
            detail = _("Version {version} is available.").format(version=target)
            progress_caption = _("Ready to download the signed update")
        elif state == UpdateState.DOWNLOADING:
            title = _("Downloading update")
            detail = _("Downloading the verified update package.")
            progress_caption = (
                _("Download progress: {percent}%").format(percent=percent)
                if percent is not None
                else _("Starting secure download")
            )
        elif state == UpdateState.VERIFYING:
            title = _("Verifying update")
            detail = _("Checking package size, SHA-256 and package integrity.")
            progress_caption = _("Verifying downloaded files")
        elif state == UpdateState.PREPARING_INSTALL:
            title = _("Preparing installation")
            detail = _("Preparing the verified package for installation.")
            progress_caption = _("Preparing a safe installation handoff")
        elif state == UpdateState.COMPLETED:
            title = _("Update ready")
            detail = _("The update is ready to install. HERFY will close and finish the update.")
            progress_caption = _("Verified download is ready")
        elif state == UpdateState.HANDOFF_TO_INSTALLER:
            title = _("Starting installer")
            detail = _("Installation can only be confirmed after the installer finishes and the app restarts.")
            progress_caption = _("Handing over the verified installer")
        else:
            title = _("Update error")
            detail = self.state_model.error or _("The update could not be completed.")
            progress_caption = _("No changes were installed")
        self.title.setText(title)
        self.detail.setText(detail)
        self.detail.setVisible(bool(detail))
        self.progress_caption.setText(progress_caption)

        if state == UpdateState.DOWNLOADING:
            self.bytes_label.setVisible(True)
        elif state == UpdateState.UPDATE_AVAILABLE and self.state_model.info is not None:
            size = int(getattr(self.state_model.info, "size", 0) or 0)
            self.bytes_label.setVisible(size > 0)
            self.bytes_label.setText(_("Update size: {size}").format(size=self._format_bytes(size)))
        else:
            self.bytes_label.hide()

        self.primary.setVisible(
            state in {UpdateState.UPDATE_AVAILABLE, UpdateState.COMPLETED, UpdateState.ERROR}
        )
        if state == UpdateState.UPDATE_AVAILABLE:
            self.primary.setText(_("Update Now"))
        elif state == UpdateState.COMPLETED:
            self.primary.setText(_("Install and Restart"))
        else:
            self.primary.setText(_("Exit") if mandatory else _("Retry"))
        self.secondary.setVisible(
            state in {UpdateState.UPDATE_AVAILABLE, UpdateState.UP_TO_DATE, UpdateState.ERROR}
            and not mandatory
        )
        self.secondary.setText(_("Later") if state == UpdateState.UPDATE_AVAILABLE else _("Close"))
        self.skip.setVisible(state == UpdateState.UPDATE_AVAILABLE and not mandatory)

    def _show_details(self) -> None:
        target = self._target_version()
        size = int(getattr(self.state_model.info, "size", 0) or 0)
        size_text = self._format_bytes(size) if size else _("Size unavailable")
        self.detail.setText(
            _("Signed HERFY update {version}. Package size: {size}.").format(
                version=target,
                size=size_text,
            )
        )

    def _primary(self) -> None:
        if self.state_model.state == UpdateState.UPDATE_AVAILABLE:
            self.start_download()
        elif self.state_model.state == UpdateState.COMPLETED:
            self._handoff_installer()
        elif self.state_model.state == UpdateState.ERROR:
            if self.state_model.mandatory:
                self.mandatory_exit_requested.emit()
            else:
                self.set_state(UpdateState.CHECKING)
                self.retry_requested.emit()

    def start_download(self) -> None:
        if self.workers.has_active_key("update:download"):
            return
        kind = self.state_model.kind
        info = self.state_model.info
        if not kind or info is None:
            return
        if kind != "installer":
            self.set_error(_("The update package type is not supported by this release."))
            return
        self._manager = self.update_manager_factory(self.current_version)
        self.set_state(UpdateState.DOWNLOADING, percent=None)

        manager = self._manager

        def work(progress_callback=None, cancel_callback=None):
            return str(manager.download_installer(
                info, progress_callback=progress_callback, cancel_callback=cancel_callback
            ))

        worker = self.workers.start(
            work,
            on_progress=self._progress,
            on_result=lambda path: self._prepare_installer(Path(path)),
            on_error=self.set_error,
            operation_key="update:download",
            log_exceptions=False,
        )
        if worker is None:
            self.set_error(_("The update could not be completed."))

    def _progress(self, payload: object) -> None:
        data = dict(payload) if isinstance(payload, dict) else {}
        if str(data.get("stage") or "") == "verifying":
            self.set_state(UpdateState.VERIFYING)
            return
        total = int(data.get("total") or 0)
        downloaded = int(data.get("downloaded") or 0)
        raw_percent = data.get("percent")
        percent = int(raw_percent) if raw_percent is not None and total > 0 else None
        self.state_model.downloaded = downloaded
        self.state_model.total = total
        self.set_state(UpdateState.DOWNLOADING, percent=percent)
        if total > 0:
            self.bytes_label.setText(
                _("{done} of {total} bytes ({percent}%)").format(
                    done=self._format_bytes(downloaded),
                    total=self._format_bytes(total),
                    percent=percent if percent is not None else "—",
                )
            )
        else:
            self.bytes_label.setText(
                _("{done} bytes downloaded").format(done=self._format_bytes(downloaded))
            )

    def _prepare_installer(self, path: Path) -> None:
        self.state_model.download_path = path
        self.set_state(UpdateState.COMPLETED)

    def _handoff_installer(self) -> None:
        path = self.state_model.download_path
        info = self.state_model.info
        manager = self._manager
        if path is None or info is None or manager is None:
            self.set_error(_("The verified update package is no longer available."))
            return
        self.set_state(UpdateState.HANDOFF_TO_INSTALLER)

        def work():
            started = manager.launch_installer(
                path,
                expected_sha256=str(getattr(info, "sha256", "") or ""),
                expected_size=int(getattr(info, "size", 0) or 0),
            )
            if not started:
                raise RuntimeError(_("Downloaded installer could not be started"))
            return True

        worker = self.workers.start(
            work,
            on_result=lambda _: self.handoff_requested.emit(),
            on_error=self.set_error,
            operation_key="update:handoff",
            log_exceptions=False,
        )
        if worker is None:
            self.set_error(_("Downloaded installer could not be started"))

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API
        if self._update_in_progress():
            self.hide()
            event.ignore()
            return
        if self.state_model.mandatory and self.state_model.state not in {
            UpdateState.HANDOFF_TO_INSTALLER,
            UpdateState.UP_TO_DATE,
        }:
            self.mandatory_exit_requested.emit()
        self.workers.close()
        self._closed = True
        super().closeEvent(event)

    def _update_in_progress(self) -> bool:
        return self.state_model.state in {
            UpdateState.DOWNLOADING, UpdateState.VERIFYING,
            UpdateState.PREPARING_INSTALL, UpdateState.HANDOFF_TO_INSTALLER,
        }

    def reject(self) -> None:
        # Escape follows the same background policy as the window close button.
        if self._update_in_progress():
            self.hide()
            return
        super().reject()
