"""Designer helpers for the embedded local KPI workspace."""

from __future__ import annotations

from typing import TypeVar

from PySide6.QtCore import QObject
from PySide6.QtWidgets import QWidget

from ui.designer import load_ui

T = TypeVar("T", bound=QObject)


def load_kpi_ui(target: QWidget, ui_name: str) -> QWidget:
    """Load a KPI form into its caller-owned widget."""
    load_ui(target, ui_name)
    return target


def require_object(root: QObject, kind: type[T], name: str) -> T:
    value = root.findChild(kind, name)
    if value is None:
        raise RuntimeError(f"KPI form is missing required object: {name}")
    return value


def require_widget(root: QObject, kind: type[T], name: str) -> T:
    return require_object(root, kind, name)
