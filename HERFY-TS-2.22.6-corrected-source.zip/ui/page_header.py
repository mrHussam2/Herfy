"""Shared configuration for Designer-owned operational page headers."""

from __future__ import annotations

from PySide6.QtWidgets import QLabel, QLayout, QWidget

from ui.theme_metrics import UI_METRICS


def configure_page_header(
    header: QWidget,
    title: QLabel,
    description: QLabel,
    *,
    text_layout: QLayout | None = None,
) -> None:
    """Apply shared header roles and metrics without rebuilding its Designer layout."""
    header_layout = header.layout()
    if header_layout is None:
        raise RuntimeError(f"{header.objectName()} must have a Designer-owned layout")

    header.setProperty("uiRole", "pageHeader")
    header.setMinimumHeight(UI_METRICS.page_header_min_height)
    header_layout.setContentsMargins(
        UI_METRICS.page_header_padding,
        UI_METRICS.page_header_padding,
        UI_METRICS.page_header_padding,
        UI_METRICS.page_header_padding,
    )
    header_layout.setSpacing(UI_METRICS.page_header_gap)

    title.setProperty("uiRole", "pageTitle")
    description.setProperty("uiRole", "pageDescription")

    if text_layout is not None:
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(UI_METRICS.page_header_text_gap)

    for widget in (header, title, description):
        widget.style().unpolish(widget)
        widget.style().polish(widget)
