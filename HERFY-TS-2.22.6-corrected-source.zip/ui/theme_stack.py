from __future__ import annotations

from PySide6.QtCore import QSize
from PySide6.QtWidgets import QLayout, QSizePolicy, QStackedWidget

from ui.theme_animation import fade_in

"""Stable page-stack behavior for the main desktop shell."""


class PageStack(QStackedWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._compact_minimum = False
        self.layout().setSizeConstraint(QLayout.SetNoConstraint)
        self.currentChanged.connect(self._page_changed)

    def _page_changed(self, *_):
        for index in range(self.count()):
            page = self.widget(index)
            if page is self.currentWidget():
                page.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            else:
                page.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.updateGeometry()
        page = self.currentWidget()
        if page is not None and page.isVisible():
            fade_in(page, duration=170, start=0.18)

    def addWidget(self, widget):
        index = super().addWidget(widget)
        self._page_changed()
        return index

    def insertWidget(self, index, widget):
        result = super().insertWidget(index, widget)
        self._page_changed()
        return result

    def minimumSizeHint(self):
        if self._compact_minimum:
            return QSize(0, 0)
        page = self.currentWidget()
        if page is None:
            return QSize(0, 0)
        return page.minimumSizeHint().expandedTo(page.minimumSize())

    def set_compact_minimum(self, enabled: bool) -> None:
        """Permit a scrollable workspace to own narrow-window adaptation."""
        self._compact_minimum = bool(enabled)
        self.updateGeometry()

    def sizeHint(self):
        page = self.currentWidget()
        return page.sizeHint() if page is not None else QSize(0, 0)
