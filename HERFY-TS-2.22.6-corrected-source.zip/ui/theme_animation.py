from __future__ import annotations

from PySide6.QtWidgets import QWidget


def _clear_effect(widget: QWidget) -> None:
    """Keep workspace controls deterministic; no opacity/motion effects."""
    old = widget.graphicsEffect()
    widget.setGraphicsEffect(None)
    if old is not None:
        old.deleteLater()


def fade_in(widget: QWidget, *, duration: int = 180, start: float = 0.0) -> None:
    """Compatibility hook retained without a visual transition."""
    del duration, start
    _clear_effect(widget)


def slide_fade_in(
    widget: QWidget,
    *,
    distance: int = 14,
    duration: int = 220,
) -> None:
    """Compatibility hook retained without moving pages or cards."""
    del distance, duration
    _clear_effect(widget)


def operation_pulse(widget: QWidget, *, duration: int = 260) -> None:
    """Keep completed actions still; state is communicated by notices instead."""
    del duration
    _clear_effect(widget)
