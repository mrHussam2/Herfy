"""Server-authoritative direct-scope assignment presentation."""

from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QMenu, QPushButton, QStackedWidget, QWidget

from core.settings import _
from ui.administration_components import (
    AdminTableModel,
    AdminTableView,
    AssignmentEditorDialog,
    submit_reviewed_assignments,
)
from ui.administration_controller import AdministrationPresenter
from ui.administration_shared import _ActiveEditorDirtyMixin
from ui.designer import load_ui
from ui.widgets import DataSurface


class AssignmentsSection(_ActiveEditorDirtyMixin, QWidget):
    """Single-workspace direct-scope administration.

    The current server contract replaces direct scope for one user at a time.
    The UI therefore uses single selection and never emulates a bulk transaction
    by issuing a sequence of independent HTTP mutations.
    """

    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self._snapshot: dict[str, Any] = {}
        self._pending_assignment_uid = ""

        controls = load_ui(
            self,
            "admin_assignments_section",
            required=(
                "AdminCountBadge",
                "admin_assignments_edit",
                "admin_assignments_collection",
                "admin_assignments_table_host",
                "AdminSelectionSummary",
                "AdminAssignmentsWorkspace",
            ),
        )
        self.count_badge: QLabel = controls["AdminCountBadge"]
        self.edit: QPushButton = controls["admin_assignments_edit"]
        self.edit.setText(_("Edit assignments"))
        self.edit.setProperty("variant", "primary")
        self.collection: QWidget = controls["admin_assignments_collection"]
        self.model = AdminTableModel(
            [
                (_("Username"), "username"),
                (
                    _("Role"),
                    lambda row: AdministrationPresenter.role_label(str(row.get("role") or "")),
                ),
                (_("Direct scope"), lambda row: AdministrationPresenter.direct_scope_summary(row)),
                (
                    _("Effective scope"),
                    lambda row: AdministrationPresenter.scope_summary(row.get("scope")),
                ),
            ],
            self,
        )
        self.table = AdminTableView(self.collection, multi_select=False)
        self.table.setModel(self.model)
        self.table.sortByColumn(0, Qt.AscendingOrder)
        self.table_surface = DataSurface(self.table, self.collection)
        controls["admin_assignments_table_host"].layout().addWidget(self.table_surface)
        self.selection_summary: QLabel = controls["AdminSelectionSummary"]
        self.selection_summary.setText(
            _("Select an employee to review direct and effective scope.")
        )
        self.editor = AssignmentEditorDialog(self)
        self.workspace_stack: QStackedWidget = controls["AdminAssignmentsWorkspace"]
        self.workspace_panel = self.workspace_stack
        self.workspace_stack.addWidget(self.editor)

        self.edit.clicked.connect(self._open)
        self.table.selectionModel().selectionChanged.connect(self._selection)
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.table.doubleClicked.connect(lambda _index: self._open())
        self.editor.cancel_requested.connect(self._request_close_editor)
        self.editor.apply_requested.connect(self._submit_assignments)
        self.controller.assignments_saved.connect(self._on_assignments_saved)
        self.controller.operation_failed.connect(self._on_operation_failed)

    def set_compact_mode(self, compact: bool) -> None:
        del compact
        for column in range(self.model.columnCount()):
            self.table.setColumnHidden(column, False)
        self.table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)

    def set_snapshot(self, snapshot: dict[str, Any]) -> None:
        self._snapshot = dict(snapshot or {})
        rows = [
            dict(item)
            for item in snapshot.get("users") or []
            if isinstance(item, dict) and not AdministrationPresenter.is_branch_account(item)
        ]
        self.model.replace_rows(rows)
        self.count_badge.setText(str(len(rows)))
        self.table_surface.set_state("content")
        self.edit.setVisible(
            AdministrationPresenter.has_capability(snapshot, "users.scopes.assign")
        )
        self._selection()

    def _selected(self) -> list[dict[str, Any]]:
        rows = self.table.selectionModel().selectedRows()
        if not rows:
            return []
        payload = self.model.row_payload(rows[0].row())
        return [payload] if payload else []

    def _selection(self, *_args) -> None:
        rows = self._selected()
        target = rows[0] if len(rows) == 1 else None
        manageable = bool(
            target and AdministrationPresenter.target_manageable(self._snapshot, target)
        )
        self.edit.setEnabled(self.edit.isVisible() and manageable)
        if not rows:
            self.selection_summary.setText(
                _("Select an employee to review direct and effective scope.")
            )
            return
        row = rows[0]
        self.selection_summary.setText(
            _("Direct scope: {direct}   •   Effective scope: {effective}").format(
                direct=AdministrationPresenter.direct_scope_summary(row),
                effective=AdministrationPresenter.scope_summary(row.get("scope")),
            )
        )

    def _open(self) -> None:
        rows = self._selected()
        if (
            len(rows) != 1
            or not self.edit.isVisible()
            or not AdministrationPresenter.target_manageable(self._snapshot, rows[0])
        ):
            return
        self.editor.configure(self._snapshot, rows)
        self.workspace_stack.setCurrentWidget(self.editor)
        self.editor.show()

    def _submit_assignments(self, targets, ids) -> None:
        uid = submit_reviewed_assignments(self, self.controller, targets, ids)
        if uid:
            self._pending_assignment_uid = uid

    def _on_operation_failed(self, operation_key: str, _failure: object) -> None:
        if str(operation_key or "").startswith("admin.assignment.save:"):
            self._pending_assignment_uid = ""

    def _on_assignments_saved(self, user_id: str) -> None:
        if str(user_id or "") != self._pending_assignment_uid:
            return
        self._pending_assignment_uid = ""
        self.editor.hide()
        self.workspace_stack.setCurrentWidget(self.collection)
        self._selection()

    def _request_close_editor(self) -> None:
        if not self._confirm_editor_discard(
            dirty=self.is_dirty(),
            message=_("Discard the unsaved assignment changes?"),
        ):
            return
        self.editor.hide()
        self.workspace_stack.setCurrentWidget(self.collection)
        self._selection()

    def _context_menu(self, pos) -> None:
        index = self.table.indexAt(pos)
        if index.isValid() and not self.table.selectionModel().isSelected(index):
            self.table.selectRow(index.row())
        selected = self._selected()
        if (
            len(selected) != 1
            or not self.edit.isVisible()
            or not AdministrationPresenter.target_manageable(self._snapshot, selected[0])
        ):
            return
        menu = QMenu(self)
        menu.addAction(_("Edit assignments"), self._open)
        menu.exec(self.table.viewport().mapToGlobal(pos))
