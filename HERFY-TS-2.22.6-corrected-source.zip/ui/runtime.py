from __future__ import annotations

import hashlib
import inspect
import logging
import os
import secrets
import socket
import sys
import threading
import time
import weakref
from contextlib import suppress
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

from PySide6.QtCore import (
    QLocale,
    QObject,
    QRunnable,
    Qt,
    QThreadPool,
    QTimer,
    Signal,
    Slot,
)
from PySide6.QtWidgets import QApplication

from core.errors import (
    SERVICE_OPERATION_EXCEPTIONS,
    STATE_OPERATION_EXCEPTIONS,
    UI_OPERATION_EXCEPTIONS,
)
from core.models import parse_bool
from core.notifications import activation_uri_from_arguments
from core.settings import (
    APP_DESKTOP_APP_ID,
    APP_DISPLAY_NAME,
    APP_ORGANIZATION_DOMAIN,
    APP_ORGANIZATION_NAME,
    install_exception_hooks,
)
from core.signals import SignalRateGate
from services.runtime_timers import RuntimeTimerScheduler
from ui.notification_service import NotificationService
from ui.printing import UsagePrintService
from ui.theme import ThemeManager
from ui.usage_controller import UsageComputeService
from ui.window_activation import reveal_window


class QtPresentationFactory:
    """Qt-only composition boundary for presentation coordinators.

    Widgets receive already-created coordinators. Worker scope ownership remains
    centralized in UiWorkerScopeFactory so views never construct thread/runtime
    adapters themselves.
    """

    def __init__(self, worker_scopes: Any) -> None:
        if worker_scopes is None:
            raise RuntimeError("QtPresentationFactory requires worker scopes")
        self.worker_scopes = worker_scopes

    def create_notification_service(self, main_window: Any, notification_runtime: Any):
        return NotificationService(
            main_window,
            worker_registry=self.worker_scopes.create(),
            notification_runtime=notification_runtime,
        )

    @staticmethod
    def create_runtime_scheduler(owner: Any):
        return RuntimeTimerScheduler(owner)

    def create_usage_compute_service(
        self,
        *,
        usage_service: Any,
        workspace_service: Any,
        parent: Any = None,
    ):
        return UsageComputeService(
            usage_service=usage_service,
            workspace_service=workspace_service,
            worker_registry=self.worker_scopes.create(),
            parent=parent,
        )

    @staticmethod
    def create_usage_print_service():
        return UsagePrintService()


logger = logging.getLogger(__name__)


# Progress is feedback, not a data stream.  Keeping this modest cap prevents
# several concurrent workers from flooding the Qt event queue while remaining
# visually immediate to an operator.
_WORKER_PROGRESS_INTERVAL_SECONDS = 0.15

_PROTOCOL_NAME = "HERFY/1"
_MAX_ACTIVATION_ARGUMENT = 2048
_SOCKET_TIMEOUT_SECONDS = 0.5


class _ActivationRelay(QObject):
    activate_requested = Signal(str)

    def __init__(self, callback: Callable[[str], None]) -> None:
        super().__init__()
        self.activate_requested.connect(callback, Qt.QueuedConnection)


@dataclass(frozen=True, slots=True)
class SingleInstanceResult:
    primary: bool
    notified_existing: bool = False


@dataclass(slots=True)
class RuntimeAcquisition:
    """Application-level ownership of the single-instance socket guard.

    If the well-known activation port is occupied but does not accept a HERFY
    activation message, the client starts normally instead of exiting silently.
    This prevents stale/non-HERFY socket ownership from hiding the UI.
    """

    acquired: bool
    lock: "SingleInstanceGuard"
    notified_existing: bool = False
    _activation_relay: _ActivationRelay | None = field(default=None, init=False, repr=False)

    def start_server(self, window: object) -> None:
        """Route a second launch/deep-link to the existing Qt UI thread."""

        def _activate(argument: str) -> None:
            value = str(argument or "").strip()
            handler = getattr(window, "_activate_notification_uri", None)
            if value and callable(handler):
                handler(value)
                return
            restore = getattr(window, "_restore_from_tray", None)
            if callable(restore):
                restore()
            else:
                reveal_window(window)

        relay = _ActivationRelay(_activate)
        self._activation_relay = relay
        self.lock.set_activation_callback(relay.activate_requested.emit)


class SingleInstanceGuard:
    """Cross-platform process guard; localhost traffic never leaves the machine."""

    def __init__(
        self,
        app_id: str,
        *,
        on_activate: Callable[[str], None] | None = None,
        host: str = "127.0.0.1",
    ) -> None:
        app_id = str(app_id or "").strip()
        if not app_id:
            raise ValueError("app_id is required")
        digest = hashlib.sha256(app_id.encode("utf-8")).digest()
        self.host = host
        self.port = 42000 + int.from_bytes(digest[:2], "big") % 20000
        self._on_activate = on_activate or (lambda _argument="": None)
        self._socket: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

    def acquire(self, activation_argument: str = "") -> SingleInstanceResult:
        self._stop.clear()
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            server.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            server.bind((self.host, self.port))
            server.listen(4)
            server.settimeout(0.2)
            self._socket = server
            self._thread = threading.Thread(
                target=self._serve,
                name="herfy-single-instance",
                daemon=True,
            )
            self._thread.start()
            return SingleInstanceResult(primary=True)
        except OSError:
            server.close()
            return SingleInstanceResult(
                primary=False,
                notified_existing=self.notify_existing(activation_argument),
            )

    def notify_existing(self, activation_argument: str = "") -> bool:
        try:
            value = str(activation_argument or "").strip()
            if len(value) > _MAX_ACTIVATION_ARGUMENT:
                value = ""
            nonce = secrets.token_hex(8)
            message = f"{_PROTOCOL_NAME}\tACTIVATE\t{nonce}\t{value}\n".encode("utf-8")
            expected_ack = f"{_PROTOCOL_NAME}\tOK\t{nonce}\n".encode("utf-8")
            with socket.create_connection(
                (self.host, self.port),
                timeout=_SOCKET_TIMEOUT_SECONDS,
            ) as client:
                client.settimeout(_SOCKET_TIMEOUT_SECONDS)
                client.sendall(message)
                ack = client.recv(128)
            return ack == expected_ack
        except OSError:
            return False

    def close(self) -> None:
        """Stop the accept loop before closing its listening socket.

        On Windows, closing a listening socket from the GUI thread while a
        daemon thread is inside ``accept()`` can race interpreter shutdown.
        Wake the loop first, join it, then release the socket.
        """
        self._stop.set()
        sock = self._socket
        thread = self._thread

        if sock is not None and thread is not None and thread is not threading.current_thread():
            try:
                with socket.create_connection(
                    (self.host, self.port),
                    timeout=0.25,
                ):
                    pass
            except OSError:
                # The accept timeout will still let the worker observe _stop.
                pass

            thread.join(1.0)

        if sock is not None:
            try:
                sock.close()
            except OSError:
                logger.debug(
                    "Single-instance listening socket was already closed",
                    exc_info=True,
                )

        if thread is not None and thread is not threading.current_thread() and thread.is_alive():
            # A final bounded join happens after close, which interrupts accept.
            thread.join(0.75)

        if thread is not None and thread.is_alive():
            logger.warning("SINGLE_INSTANCE_THREAD_STOP=TIMEOUT")
        else:
            logger.debug("SINGLE_INSTANCE_THREAD_STOP=PASS")

        self._socket = None
        self._thread = None

    def set_activation_callback(self, callback: Callable[[str], None]) -> None:
        self._on_activate = callback

    def wait(self, timeout_seconds: float = 1.0) -> bool:
        thread = self._thread
        if thread is None:
            return True
        requested = max(0.0, float(timeout_seconds or 0.0))
        effective = (
            min(requested, 0.15)
            if threading.current_thread() is threading.main_thread()
            else requested
        )
        thread.join(effective)
        return not thread.is_alive()

    def _serve(self) -> None:
        sock = self._socket
        if sock is None:
            return
        while not self._stop.is_set():
            try:
                client, _ = sock.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            if self._stop.is_set():
                try:
                    client.close()
                except OSError:
                    pass
                break
            with client:
                try:
                    client.settimeout(_SOCKET_TIMEOUT_SECONDS)
                    message = client.recv(4096)
                except OSError:
                    continue
                if not message.startswith((_PROTOCOL_NAME + "\tACTIVATE\t").encode("utf-8")):
                    continue
                try:
                    decoded = message.decode("utf-8", errors="strict").strip()
                    parts = decoded.split("\t", 3)
                    if len(parts) < 3 or parts[0] != _PROTOCOL_NAME or parts[1] != "ACTIVATE":
                        continue
                    nonce = parts[2].strip()
                    if len(nonce) != 16 or any(ch not in "0123456789abcdef" for ch in nonce):
                        continue
                    argument = parts[3].strip() if len(parts) > 3 else ""
                    try:
                        client.sendall(f"{_PROTOCOL_NAME}\tOK\t{nonce}\n".encode("utf-8"))
                    except OSError:
                        continue
                    try:
                        self._on_activate(argument)
                    except Exception:
                        # Activation is a boundary callback.  A handler failure
                        # must not terminate the listener thread permanently.
                        logger.exception("Single-instance activation dispatch failed")
                except (UnicodeDecodeError, ValueError):
                    logger.debug("Invalid single-instance activation frame", exc_info=True)


def acquire_runtime(_argv: list[str] | None = None) -> RuntimeAcquisition:
    from core.notifications import activation_uri_from_arguments

    activation_argument = activation_uri_from_arguments(_argv)
    guard = SingleInstanceGuard(APP_DESKTOP_APP_ID)
    result = guard.acquire(activation_argument)

    # A just-closed process can leave the well-known port unavailable for a
    # short interval. Never continue without owning the guard: doing so permits
    # two UI/runtime generations to run concurrently. Retry a bounded number of
    # times, while still relaying activation to a real existing instance.
    if not result.primary and not result.notified_existing:
        for attempt in range(3):
            time.sleep(0.15 * (attempt + 1))
            guard.close()
            guard = SingleInstanceGuard(APP_DESKTOP_APP_ID)
            result = guard.acquire(activation_argument)
            if result.primary or result.notified_existing:
                break

    acquired = bool(result.primary)
    if not result.primary and not result.notified_existing:
        logger.error(
            "SINGLE_INSTANCE_ACQUIRE=FAIL port=%s reason=port_busy_without_protocol_ack",
            guard.port,
        )
    elif result.notified_existing:
        logger.info("SINGLE_INSTANCE_ACTIVATION_RELAY=PASS port=%s", guard.port)
    return RuntimeAcquisition(
        acquired=acquired,
        lock=guard,
        notified_existing=result.notified_existing,
    )


def cleanup(_window: object, lock: SingleInstanceGuard) -> None:
    lock.close()


class UiWorkerScopeFactory:
    """Single Qt async composition point for presentation worker scopes.

    Views/controllers receive WorkerRegistry instances; they never construct or
    configure QThreadPool/QRunnable primitives themselves.
    """

    def __init__(self) -> None:
        self._pool = client_thread_pool()
        self._registries: weakref.WeakSet[WorkerRegistry] = weakref.WeakSet()
        self._lock = threading.RLock()
        self._closed = False

    def create(self) -> WorkerRegistry:
        with self._lock:
            if self._closed:
                raise RuntimeError("Worker scope factory is closed")
            registry = WorkerRegistry(self._pool)
            self._registries.add(registry)
            return registry

    def _snapshot(self) -> list[WorkerRegistry]:
        with self._lock:
            return list(self._registries)

    def cancel_all(self) -> None:
        """Invalidate every presentation worker scope for the current runtime generation."""
        for registry in self._snapshot():
            registry.cancel_all()

    def close_all(self) -> None:
        """Permanently close every presentation worker scope during app shutdown."""
        with self._lock:
            self._closed = True
            registries = list(self._registries)
        for registry in registries:
            registry.close()

    def drain(self, timeout_ms: int = 2500, *, bounded_main_thread: bool = False) -> bool:
        self._pool.clear()
        timeout = max(0, int(timeout_ms or 0))
        if bounded_main_thread:
            timeout = min(timeout, 250)
        return bool(self._pool.waitForDone(timeout))


logger = logging.getLogger(__name__)


def client_thread_pool() -> QThreadPool:
    """Return the shared client thread pool with a safe bounded capacity.

    The client performs network pulls, catalog reads, expiry checks, and usage
    calculations from the UI.  Leaving the global QThreadPool unbounded on a
    large CPU machine can allow repeated refresh/realtime events to compete
    with user actions.  A small bounded pool keeps the UI responsive while
    preserving enough parallelism for background sync.
    """
    pool = QThreadPool.globalInstance()
    try:
        cpu_count = int(os.cpu_count() or 4)
    except (TypeError, ValueError):
        cpu_count = 4
    # Leave capacity for the Qt GUI thread and Windows itself.  The pool is
    # mostly network/I/O work, so two to four workers retain background sync
    # responsiveness without allowing refresh bursts to saturate the desktop.
    max_threads = max(2, min(4, max(2, cpu_count - 1)))
    try:
        if int(pool.maxThreadCount()) != max_threads:
            pool.setMaxThreadCount(max_threads)
        if hasattr(pool, "setExpiryTimeout"):
            pool.setExpiryTimeout(30000)
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Failed to configure bounded client QThreadPool", exc_info=True)
    return pool


class WorkerSignals(QObject):
    result = Signal(object)
    error = Signal(str)
    # Structured, sanitized failure metadata for callers that must distinguish
    # canonical server error codes (for example REVISION_CONFLICT) without
    # parsing localized/user-facing strings. Existing error(str) subscribers
    # remain supported.
    failure = Signal(object)
    finished = Signal()
    progress = Signal(object)


class UiCallbackDispatcher(QObject):
    """Marshal worker callbacks onto the Qt thread that owns this dispatcher.

    WorkerRegistry instances are created by UI controllers/widgets.  QRunnable
    code may emit from any pool thread, but no result/error/progress callback is
    allowed to touch presentation state from that worker thread.  The dispatcher
    is therefore the single explicit boundary back into the owning Qt thread.
    """

    invoke_requested = Signal(object, object)

    def __init__(self) -> None:
        super().__init__()
        self.invoke_requested.connect(self._invoke, Qt.QueuedConnection)

    def post(self, callback, *args, callback_name: str = "callback") -> None:
        if callback is None:
            return
        payload = (tuple(args), str(callback_name or "callback"))
        try:
            self.invoke_requested.emit(callback, payload)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "Qt callback dispatch skipped after receiver cleanup: %s",
                callback_name,
                exc_info=True,
            )

    @Slot(object, object)
    def _invoke(self, callback, payload) -> None:
        args = ()
        callback_name = "callback"
        if isinstance(payload, tuple) and len(payload) == 2:
            raw_args, raw_name = payload
            args = tuple(raw_args or ())
            callback_name = str(raw_name or "callback")
        try:
            callback(*args)
        except Exception:
            logger.exception("Background UI callback failed: %s", callback_name)


class Worker(QRunnable):
    def __init__(self, fn, *args, log_exceptions: bool = True, **kwargs):
        super().__init__()
        try:
            self.setAutoDelete(True)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Worker auto-delete configuration skipped", exc_info=True)
        self._cancel_event = threading.Event()
        self.fn = fn
        self.args = args
        self.kwargs = kwargs
        self.log_exceptions = bool(log_exceptions)
        self.signals = WorkerSignals()
        self._progress_gate = SignalRateGate(
            min_interval_seconds=_WORKER_PROGRESS_INTERVAL_SECONDS
        )

    @staticmethod
    def _supports_callback_argument(fn, argument_name: str) -> bool:
        """Return whether a worker function can accept a callback argument."""
        try:
            signature = inspect.signature(fn)
        except (TypeError, ValueError):
            return False
        for param in signature.parameters.values():
            if param.kind == inspect.Parameter.VAR_KEYWORD:
                return True
            if param.name == argument_name:
                return True
        return False

    def _emit_signal(self, signal_name: str, *args) -> bool:
        try:
            signal = getattr(self.signals, signal_name)
            signal.emit(*args)
            return True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "Worker signal emission skipped after receiver cleanup: %s",
                signal_name,
                exc_info=True,
            )
            return False

    def cancel(self) -> None:
        """Request cooperative cancellation for long-running work."""
        self._cancel_event.set()

    def is_cancel_requested(self) -> bool:
        """Return whether cooperative cancellation was requested."""
        return bool(self._cancel_event.is_set())

    def _progress_callback(self, message) -> None:
        """Emit bounded progress while the worker is still current."""
        if self.is_cancel_requested():
            return
        if not self._progress_gate.allow(message):
            return
        self._emit_signal("progress", message)

    @staticmethod
    def _failure_payload(exc: Exception) -> dict:
        details = getattr(exc, "details", None)
        return {
            "message": str(exc or ""),
            "exception_type": type(exc).__name__,
            "status_code": getattr(exc, "status_code", None),
            "error_code": str(getattr(exc, "error_code", "") or "").strip(),
            "request_id": str(getattr(exc, "request_id", "") or "").strip(),
            "retryable": bool(getattr(exc, "retryable", False)),
            "details": dict(details) if isinstance(details, dict) else {},
        }

    def run(self):
        try:
            kwargs = dict(self.kwargs)
            if "progress_callback" not in kwargs and self._supports_callback_argument(
                self.fn, "progress_callback"
            ):
                kwargs["progress_callback"] = self._progress_callback
            if "cancel_callback" not in kwargs and self._supports_callback_argument(
                self.fn, "cancel_callback"
            ):
                kwargs["cancel_callback"] = self.is_cancel_requested
            if "is_cancelled" not in kwargs and self._supports_callback_argument(
                self.fn, "is_cancelled"
            ):
                kwargs["is_cancelled"] = self.is_cancel_requested
            if self.is_cancel_requested():
                return
            result = self.fn(*self.args, **kwargs)
            if not self.is_cancel_requested():
                self._emit_signal("result", result)
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            if self.is_cancel_requested():
                logger.debug("Cancelled worker suppressed service error: %s", exc)
            elif self.log_exceptions:
                logger.exception("Background worker failed")
            else:
                logger.warning("Background worker failed: %s", exc)
            if not self.is_cancel_requested():
                self._emit_signal("failure", self._failure_payload(exc))
                self._emit_signal("error", str(exc))
        except Exception as exc:
            if self.is_cancel_requested():
                logger.debug("Cancelled worker suppressed error: %s", exc)
            elif self.log_exceptions:
                logger.exception("Background worker failed")
            else:
                logger.warning("Background worker failed: %s", exc)
            if not self.is_cancel_requested():
                self._emit_signal("failure", self._failure_payload(exc))
                self._emit_signal("error", str(exc))
        finally:
            self._emit_signal("finished")


class WorkerRegistry:
    """Own background workers and operation keys for one UI component."""

    def __init__(self, pool: QThreadPool | None = None):
        self.pool = pool or client_thread_pool()
        self._workers: set[Worker] = set()
        self._active_keys: set[str] = set()
        self._generation = 0
        self._closed = False
        self._lock = threading.RLock()
        # Constructed by the UI owner; its QObject affinity is therefore the
        # presentation thread and remains the only path for worker callbacks.
        self._dispatcher = UiCallbackDispatcher()

    def has_active_key(self, key: str | None) -> bool:
        clean_key = str(key or "").strip()
        with self._lock:
            return bool(clean_key and clean_key in self._active_keys)

    @staticmethod
    def _operation_priority(operation_key: str) -> int:
        """Prefer an operator action over maintenance already queued in the pool."""
        key = str(operation_key or "").strip().casefold()
        if key in {"login:submit", "tracking:action", "tracking:catalog", "usage:compute", "update:download", "update:handoff"} or key.startswith(
            ("administration:", "settings:change", "mandatory-password:")
        ):
            return 1
        if key in {"expiry_check", "token_refresh", "update_check"} or key.startswith(
            (
                "cloud_snapshot:",
                "monitoring:",
                "notifications:",
                "runtime-setting:",
                "startup:",
                "preferences:",
                "tracking:delta-",
                "tracking:cached-",
            )
        ):
            return -1
        return 0

    def cancel_all(self) -> None:
        """Cancel all owned work and invalidate callbacks from old workers."""
        with self._lock:
            self._generation += 1
            workers = list(self._workers)
            self._active_keys.clear()
        for worker in workers:
            try:
                worker.cancel()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Worker cancellation skipped", exc_info=True)

    def close(self) -> None:
        """Permanently stop this registry for a closing UI component."""
        with self._lock:
            self._closed = True
        self.cancel_all()

    def start(
        self,
        work,
        *,
        on_result=None,
        on_error=None,
        on_failure=None,
        on_progress=None,
        on_finished=None,
        operation_key: str | None = None,
        scope_checker=None,
        log_exceptions: bool = True,
    ):
        clean_key = str(operation_key or "").strip()
        with self._lock:
            if self._closed:
                logger.debug(
                    "Skipping background operation on closed registry: %s",
                    operation_key,
                )
                return None
            if clean_key and clean_key in self._active_keys:
                logger.debug("Skipping duplicate background operation: %s", clean_key)
                return None
            generation = self._generation
            worker = Worker(work, log_exceptions=log_exceptions)
            self._workers.add(worker)
            if clean_key:
                self._active_keys.add(clean_key)

        def _scope_ok() -> bool:
            with self._lock:
                registry_stale = self._closed or generation != self._generation
            if registry_stale:
                return False
            if scope_checker is None:
                return True
            try:
                return bool(scope_checker())
            except Exception:
                # Scope predicates are UI-owned callbacks and can fail because
                # their QObject/page was already destroyed or its state changed.
                # Never let that exception escape the queued Qt signal.
                logger.exception("Worker scope check failed")
                return False

        def _deliver_result(payload):
            if _scope_ok() and on_result is not None:
                on_result(payload)

        def _deliver_error(message):
            if _scope_ok() and on_error is not None:
                on_error(message)

        def _deliver_failure(payload):
            if _scope_ok() and on_failure is not None:
                on_failure(payload)

        def _deliver_progress(message):
            if _scope_ok() and on_progress is not None:
                on_progress(message)

        def _release():
            # This function is invoked by UiCallbackDispatcher on the owning Qt
            # thread. Release ownership/key before a finished callback so that
            # the callback can safely schedule the next generation.
            with self._lock:
                self._workers.discard(worker)
                if clean_key and generation == self._generation:
                    self._active_keys.discard(clean_key)
            if _scope_ok() and on_finished is not None:
                on_finished()

        def _queue_result(payload):
            self._dispatcher.post(
                _deliver_result,
                payload,
                callback_name=f"worker:result:{clean_key or '<anonymous>'}",
            )

        def _queue_error(message):
            self._dispatcher.post(
                _deliver_error, message, callback_name=f"worker:error:{clean_key or '<anonymous>'}"
            )

        def _queue_failure(payload):
            self._dispatcher.post(
                _deliver_failure,
                payload,
                callback_name=f"worker:failure:{clean_key or '<anonymous>'}",
            )

        def _queue_progress(message):
            self._dispatcher.post(
                _deliver_progress,
                message,
                callback_name=f"worker:progress:{clean_key or '<anonymous>'}",
            )

        def _queue_release():
            self._dispatcher.post(
                _release, callback_name=f"worker:finished:{clean_key or '<anonymous>'}"
            )

        if on_result is not None:
            worker.signals.result.connect(_queue_result, Qt.DirectConnection)
        if on_error is not None:
            worker.signals.error.connect(_queue_error, Qt.DirectConnection)
        if on_failure is not None:
            worker.signals.failure.connect(_queue_failure, Qt.DirectConnection)
        if on_progress is not None:
            worker.signals.progress.connect(_queue_progress, Qt.DirectConnection)
        worker.signals.finished.connect(_queue_release, Qt.DirectConnection)
        try:
            self.pool.start(worker, self._operation_priority(clean_key))
        except UI_OPERATION_EXCEPTIONS:
            with self._lock:
                self._workers.discard(worker)
                if clean_key:
                    self._active_keys.discard(clean_key)
            try:
                logger.exception(
                    "Failed to submit background worker: %s",
                    clean_key or "<anonymous>",
                )
            except Exception:
                pass
            return None
        return worker


logger = logging.getLogger(__name__)


"""Desktop Qt bootstrap helpers.

This module keeps the windowing layer explicit and acts as the single place for
application identity, DPI configuration, stylesheet integration, and runtime
startup preferences.
"""


def configure_high_dpi() -> None:
    """Apply the remaining Qt 6 HiDPI preference before app construction."""
    # Qt 6 enables high-DPI scaling and high-DPI pixmaps by default.  The Qt 5
    # compatibility flags are deprecated and emit warnings on every startup.
    if hasattr(Qt, "HighDpiScaleFactorRoundingPolicy") and hasattr(
        QApplication, "setHighDpiScaleFactorRoundingPolicy"
    ):
        QApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )


def configure_presentation_locale() -> None:
    """Use the Gregorian calendar and ASCII decimal digits for all Qt widgets."""
    QLocale.setDefault(QLocale.c())


def configure_windows_identity() -> None:
    """Register the Windows app model identity when running on Windows."""
    if not sys.platform.startswith("win"):
        return
    try:
        import ctypes

        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_DESKTOP_APP_ID)
    except (AttributeError, ImportError, OSError, ValueError):
        return


def apply_qt_visual_identity(app: QApplication) -> None:
    """Bind the application name, icon, and stylesheet without touching business logic."""
    try:
        from PySide6.QtCore import QDir

        theme = ThemeManager()
        resources_dir = theme.resource_directory
        QDir.addSearchPath("herfy", str(resources_dir))
        app.setStyle("Fusion")
        theme.apply(app)
        if hasattr(app, "setApplicationDisplayName"):
            app.setApplicationDisplayName(APP_DISPLAY_NAME)
        if hasattr(app, "setDesktopFileName"):
            app.setDesktopFileName(APP_DESKTOP_APP_ID)
    except SERVICE_OPERATION_EXCEPTIONS:
        return

    try:
        from ui.widgets import apply_application_icon

        apply_application_icon(app)
    except SERVICE_OPERATION_EXCEPTIONS:
        return


def _startup_language_for(runtime: Any | None) -> str:
    preferences = getattr(runtime, "presentation_preferences", None)
    if preferences is None:
        return "en"
    try:
        language = preferences.language()
    except STATE_OPERATION_EXCEPTIONS:
        return "en"
    return str(language or "en")


def apply_runtime_startup_language(app: QApplication, runtime: Any | None = None) -> None:
    """Align Qt direction and localization with the runtime presentation settings."""
    try:
        from PySide6.QtCore import Qt as QtCoreQt

        language = _startup_language_for(runtime)
        app.setLayoutDirection(QtCoreQt.RightToLeft if language == "ar" else QtCoreQt.LeftToRight)
    except STATE_OPERATION_EXCEPTIONS:
        return


def build_qt_application(
    argv: Sequence[str] | None = None, *, runtime: Any | None = None
) -> QApplication:
    """Create the singleton Qt application and apply desktop-level identity.

    The caller passes runtime details when startup language or app preferences are
    available; otherwise a default neutral desktop configuration is used.
    """
    existing = QApplication.instance()
    if existing is not None:
        apply_qt_visual_identity(existing)
        if runtime is not None and hasattr(existing, "setLayoutDirection"):
            apply_runtime_startup_language(existing, runtime)
        return existing

    configure_presentation_locale()
    configure_high_dpi()
    configure_windows_identity()
    app = QApplication(list(sys.argv if argv is None else argv))
    app.setDesktopSettingsAware(True)
    app.setApplicationName(APP_DISPLAY_NAME)
    app.setOrganizationName(APP_ORGANIZATION_NAME)
    if hasattr(app, "setOrganizationDomain"):
        app.setOrganizationDomain(APP_ORGANIZATION_DOMAIN)
    app.setQuitOnLastWindowClosed(False)
    apply_qt_visual_identity(app)
    apply_runtime_startup_language(app, runtime)
    return app


__all__ = [
    "apply_qt_visual_identity",
    "apply_runtime_startup_language",
    "build_qt_application",
    "configure_high_dpi",
    "configure_presentation_locale",
    "configure_windows_identity",
]


"""Qt desktop lifecycle helpers for startup, tray behavior, and shutdown."""


logger = logging.getLogger(__name__)


def _presentation_preferences(runtime: Any):
    return getattr(runtime, "presentation_preferences", None)


def _startup_setting(runtime: Any, key: str, default: str = "True") -> bool:
    try:
        preferences = _presentation_preferences(runtime)
        if preferences is None:
            return parse_bool(default, parse_bool(default, True))
        return preferences.get_bool(key, parse_bool(default, True))
    except STATE_OPERATION_EXCEPTIONS:
        return parse_bool(default, parse_bool(default, True))


def start_minimized(window: Any) -> None:
    """Launch the app in tray mode while preserving the user preference state."""
    persist_runtime_setting = getattr(window, "_persist_runtime_setting_async", None)
    if callable(persist_runtime_setting):
        persist_runtime_setting("enable_tray_background", "True")
    else:
        logger.debug("Async runtime-setting persistence is unavailable during minimized startup")
    try:
        if not window._minimize_to_tray(show_message=False):
            window.hide()
    except UI_OPERATION_EXCEPTIONS:
        logger.exception("Failed to start minimized to tray")
        window.hide()
    if not _startup_setting(
        getattr(window, "runtime", None), "reveal_login_after_tray_startup", "False"
    ):
        return

    def reveal_login_if_needed() -> None:
        try:
            if getattr(window, "session", None) is None:
                window._restore_from_tray()
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Failed to reveal login window after tray startup")

    _qt_timer_class().singleShot(5000, reveal_login_if_needed)


def ensure_background_runtime(window: Any) -> None:
    """Keep the tray/background runtime enabled for the single app process."""
    try:
        persist_runtime_setting = getattr(window, "_persist_runtime_setting_async", None)
        if callable(persist_runtime_setting):
            persist_runtime_setting("enable_tray_background", "True")
        refresh_tray = getattr(window, "refresh_tray_icon", None)
        if callable(refresh_tray):
            refresh_tray()
    except STATE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to enable the background runtime")


def show_startup_window(window: Any) -> None:
    """Reveal a normal startup window while keeping background services alive."""
    try:
        window.show()
        reveal_window(window)
    except UI_OPERATION_EXCEPTIONS:
        logger.exception("Failed to reveal the startup window")
        with suppress(UI_OPERATION_EXCEPTIONS):
            window.show()


def shutdown_cleanup(window: Any, lock: Any) -> None:
    """Finalize workers, runtime services, tray resources, and the instance guard."""
    worker_scopes = getattr(window, "worker_scopes", None)
    if worker_scopes is not None:
        try:
            worker_scopes.close_all()
            worker_scopes.drain(900, bounded_main_thread=True)
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Worker cleanup during shutdown failed")

    lifecycle = getattr(getattr(window, "runtime", None), "lifecycle", None)
    if lifecycle is not None:
        try:
            report = lifecycle.shutdown()
            if not report.successful:
                logger.error("Lifecycle cleanup reported errors: %s", report.errors)
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Runtime cleanup during shutdown failed")
    else:
        destroy_tray = getattr(window, "_destroy_tray_icon", None)
        if callable(destroy_tray):
            try:
                destroy_tray()
            except UI_OPERATION_EXCEPTIONS:
                logger.exception("Tray cleanup during shutdown failed")
        cloud_runtime = getattr(window, "cloud_sync_runtime_service", None)
        if cloud_runtime is not None:
            try:
                cloud_runtime.stop_realtime()
            except STATE_OPERATION_EXCEPTIONS:
                logger.exception("Realtime shutdown cleanup failed")
    cleanup(window, lock)


__all__ = [
    "ensure_background_runtime",
    "shutdown_cleanup",
    "show_startup_window",
    "start_minimized",
]


"""Desktop runtime orchestration and Qt startup lifecycle.

The runtime layer is intentionally thin: it composes the Qt shell, startup
preferences, and single-instance desktop lifecycle while leaving the domain,
state, and service orchestration in the application layer.
"""


logger = logging.getLogger(__name__)


def _qt_timer_class():
    return QTimer


def _qt_application_class():
    from PySide6.QtWidgets import QApplication

    return QApplication


def _show_error_box(title: str, text: str) -> None:
    try:
        QApplication = _qt_application_class()
        from ui.dialogs import show_error_message

        if QApplication.instance() is not None:
            show_error_message(None, title, text)
    except (ModuleNotFoundError, *UI_OPERATION_EXCEPTIONS):
        logger.debug("Unable to show fatal error dialog", exc_info=True)


def _configure_high_dpi() -> None:
    configure_high_dpi()


def _configure_windows_identity() -> None:
    configure_windows_identity()


def _create_application():
    app = build_qt_application(sys.argv)
    try:
        app.setDesktopSettingsAware(True)
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Desktop settings awareness could not be enabled", exc_info=True)
    install_exception_hooks(_show_error_box)
    return app


def _apply_visual_identity(app: Any) -> None:
    apply_qt_visual_identity(app)


def _apply_startup_language(app: Any, runtime: Any) -> None:
    try:
        from PySide6.QtCore import Qt

        preferences = _presentation_preferences(runtime)
        language = preferences.language() if preferences is not None else "en"
        app.setLayoutDirection(Qt.RightToLeft if language == "ar" else Qt.LeftToRight)
    except STATE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to apply cached startup language")


def run_gui_application(runtime: Any) -> int:
    from ui.main_window import HerfyMainWindow

    _configure_high_dpi()
    _configure_windows_identity()
    app = _create_application()
    _apply_visual_identity(app)
    _apply_startup_language(app, runtime)
    single_instance = acquire_runtime(sys.argv[1:])
    if not single_instance.acquired:
        return 0

    window = None
    shutdown_done = False

    def _shutdown_once() -> None:
        nonlocal shutdown_done
        if shutdown_done:
            return
        shutdown_done = True
        if window is not None:
            shutdown_cleanup(window, single_instance.lock)
        else:
            cleanup(window, single_instance.lock)

    try:
        worker_scopes = UiWorkerScopeFactory()
        presentation_factory = QtPresentationFactory(worker_scopes)
        window = HerfyMainWindow(
            runtime,
            worker_scopes=worker_scopes,
            presentation_factory=presentation_factory,
        )
        ensure_background_runtime(window)
        single_instance.start_server(window)
        app.aboutToQuit.connect(_shutdown_once)
        activation_uri = activation_uri_from_arguments(sys.argv[1:])
        if activation_uri:
            handler = getattr(window, "_activate_notification_uri", None)
            if callable(handler):
                _qt_timer_class().singleShot(250, lambda uri=activation_uri: handler(uri))
        background_flags = {"--tray", "--background"}
        start_minimized_requested = any(
            str(argument).strip().lower() in background_flags for argument in sys.argv[1:]
        )
        if start_minimized_requested:
            start_minimized(window)
        else:
            show_startup_window(window)
        return app.exec()
    finally:
        _shutdown_once()


__all__ = ["run_gui_application"]
