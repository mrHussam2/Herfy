from __future__ import annotations

import logging
import os
from collections.abc import Callable
from dataclasses import dataclass
from inspect import Parameter, signature
from typing import Any

from PySide6.QtCore import QObject, QSize, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QAbstractSpinBox,
    QApplication,
    QComboBox,
    QLayout,
    QLineEdit,
    QPushButton,
    QTableView,
    QToolButton,
    QWidget,
)

from core.errors import SERVICE_OPERATION_EXCEPTIONS, UI_OPERATION_EXCEPTIONS
from core.models import call_if_callable
from ui.text_presentation import polish_text_visibility
from ui.theme_metrics import UI_METRICS

logger = logging.getLogger(__name__)


class ResponsiveResizeMixin:
    """Schedule the existing responsive controller after a native resize event."""

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        self._responsive_controller.schedule()


# Desktop startup fallback only. Live widgets use their own viewport dimensions;
# controls remain in logical pixels and are not globally zoomed with the window.
STABLE_LAYOUT_REFERENCE_WIDTH = 1440
STABLE_LAYOUT_REFERENCE_HEIGHT = 900


# Component geometry used by responsive desktop compositions.
ADMIN_MASTER_DETAIL_MIN_WIDTH = 1100
ADMIN_INSPECTOR_MIN_WIDTH = 300
ADMIN_INSPECTOR_PREFERRED_WIDTH = 340
ADMIN_INSPECTOR_MAX_WIDTH = 400
ADMIN_STRUCTURE_COLLAPSED_WIDTH = 44
ADMIN_STRUCTURE_MIN_WIDTH = 180
ADMIN_STRUCTURE_PREFERRED_WIDTH = 260


def admin_filter_stacks(width: int | None) -> bool:
    """Desktop filters retain their row inside the scrollable workspace."""
    del width
    return False


def dashboard_lower_stacks(width: int | None, mode: str | None = None) -> bool:
    del width, mode
    return False


def supports_admin_master_detail(width: int | None, orientation: str = "landscape") -> bool:
    """Keep administration master/detail side-by-side at every live width.

    Dense administration pages are desktop workspaces.  Their tables and
    inspector already scroll internally, so stacking the inspector below the
    table loses the operator's fixed visual landmarks when a window narrows.
    """
    try:
        del orientation
        return int(width or 0) > 0
    except (TypeError, ValueError):
        return False


def layout_mode_for_width(width: int | None) -> str:
    """Return a semantic layout tier from the *live content width*.

    Control heights remain on the canonical desktop metrics; the tier only owns
    placement, wrapping, sidebar treatment, and data-surface behavior.
    """
    try:
        resolved = max(1, int(width or STABLE_LAYOUT_REFERENCE_WIDTH))
    except (TypeError, ValueError):
        resolved = STABLE_LAYOUT_REFERENCE_WIDTH
    if resolved <= 720:
        return "small"
    if resolved <= 900:
        return "narrow"
    if resolved <= 1180:
        return "compact"
    if resolved <= 1680:
        return "desktop"
    if resolved <= 2560:
        return "wide"
    return "extra_wide"


@dataclass(frozen=True, slots=True)
class ResponsiveProfile:
    name: str
    width: int
    height: int
    orientation: str
    density: str
    navigation_mode: str
    touch_mode: bool
    control_height: int
    touch_target: int
    page_margin: int
    gap: int
    dialog_margin: int
    visual_breakpoint: str = "generic"

    @property
    def is_narrow(self) -> bool:
        return self.name in {"small", "narrow", "compact"}

    @property
    def is_tablet(self) -> bool:
        return self.name in {"narrow", "compact"}

    @property
    def supports_split_admin_workspace(self) -> bool:
        return supports_admin_master_detail(self.width, self.orientation)


@dataclass(frozen=True, slots=True)
class ScreenDeviceProfile:
    """Describe the active screen/monitor used for adaptive layout decisions."""

    name: str
    width: int
    height: int
    available_width: int
    available_height: int
    logical_dpi: float
    device_pixel_ratio: float
    orientation: str
    visual_breakpoint: str

    @property
    def signature(self) -> str:
        """Return a stable readable signature for diagnostics and UI properties."""
        return f"{self.name}:{self.available_width}x{self.available_height}@{self.logical_dpi:.0f}dpi/{self.device_pixel_ratio:.2f}x"


def _screen_for_anchor(anchor=None, app: QApplication | None = None):
    """Return the Qt screen containing an anchor point, with robust fallback."""
    app = app or QApplication.instance()
    if app is None:
        return None
    try:
        if anchor is not None and hasattr(app, "screenAt"):
            screen = app.screenAt(anchor)
            if screen is not None:
                return screen
        return app.primaryScreen()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("screen lookup fallback failed", exc_info=True)
        return app.primaryScreen() if app is not None else None


def screen_for_widget(widget: QWidget | None = None, app: QApplication | None = None):
    """Return the Qt screen currently owning a widget, then fall back by geometry."""
    app = app or QApplication.instance()
    if widget is not None:
        try:
            window = widget.window() if hasattr(widget, "window") else widget
            handle = window.windowHandle() if hasattr(window, "windowHandle") else None
            screen = handle.screen() if handle is not None else None
            if screen is not None:
                return screen
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("window-handle screen lookup failed", exc_info=True)

    anchor = None
    try:
        if widget is not None and hasattr(widget, "frameGeometry"):
            anchor = widget.frameGeometry().center()
    except SERVICE_OPERATION_EXCEPTIONS:
        anchor = None
    return _screen_for_anchor(anchor, app)


def screen_device_profile(
    widget: QWidget | None = None,
    *,
    app: QApplication | None = None,
    width: int | None = None,
    height: int | None = None,
) -> ScreenDeviceProfile:
    """Detect the active screen geometry, DPI, scale, and adaptive breakpoint."""
    app = app or QApplication.instance()
    screen = screen_for_widget(widget, app)
    available = screen.availableGeometry() if screen is not None else None
    geometry = screen.geometry() if screen is not None else None
    available_width = int(width or (available.width() if available is not None else 1280))
    available_height = int(height or (available.height() if available is not None else 800))
    full_width = int(geometry.width() if geometry is not None else available_width)
    full_height = int(geometry.height() if geometry is not None else available_height)
    try:
        logical_dpi = float(screen.logicalDotsPerInch()) if screen is not None else 96.0
    except SERVICE_OPERATION_EXCEPTIONS:
        logical_dpi = 96.0
    try:
        ratio = float(screen.devicePixelRatio()) if screen is not None else 1.0
    except SERVICE_OPERATION_EXCEPTIONS:
        ratio = 1.0
    try:
        name = str(screen.name() or "screen") if screen is not None else "screen"
    except SERVICE_OPERATION_EXCEPTIONS:
        name = "screen"
    orientation = "portrait" if available_height > available_width else "landscape"
    breakpoint = visual_breakpoint_for_dimensions(available_width, available_height)
    return ScreenDeviceProfile(
        name=name,
        width=max(320, full_width),
        height=max(240, full_height),
        available_width=max(320, available_width),
        available_height=max(240, available_height),
        logical_dpi=logical_dpi,
        device_pixel_ratio=max(0.75, min(4.0, ratio)),
        orientation=orientation,
        visual_breakpoint=breakpoint,
    )


def apply_screen_device_properties(widget: QWidget | None, profile: ScreenDeviceProfile) -> None:
    """Expose detected device/screen facts as Qt dynamic properties for QSS and QA."""
    if widget is None:
        return
    for name, value in {
        "screenName": profile.name,
        "screenSignature": profile.signature,
        "screenWidth": profile.available_width,
        "screenHeight": profile.available_height,
        "screenDpi": round(profile.logical_dpi, 2),
        "screenScale": round(profile.device_pixel_ratio, 2),
        "screenOrientation": profile.orientation,
        "visualBreakpoint": profile.visual_breakpoint,
        "deviceAdaptiveContract": "live-viewport-responsive-native-dpi",
    }.items():
        widget.setProperty(name, value)


def visual_breakpoint_for_dimensions(width: int, height: int) -> str:
    """Return the adaptive visual breakpoint for any desktop screen size.

    The rules are not tied to a brand, panel vendor, or one laptop model. They
    use the real available width and height so the same build can run across
    mixed fleets: small POS terminals, 720p/768p laptops, FHD desktops, QHD,
    and 4K displays.  The named 1280x720, 1366x768, and 1920x1080 breakpoints
    remain explicit QA targets, but the surrounding tiers keep the UI adaptive
    for the rest of the 400-device fleet.
    """
    resolved_width = int(width or 0)
    resolved_height = int(height or 0)
    shortest = min(resolved_width, resolved_height)
    longest = max(resolved_width, resolved_height)
    if longest <= 1024 or shortest <= 600:
        return "small_terminal"
    if resolved_width <= 1280 or resolved_height <= 720:
        return "hd_720"
    if resolved_width <= 1366 or resolved_height <= 768:
        return "laptop_768"
    if resolved_width <= 1440 or resolved_height <= 900:
        return "hd_plus_900"
    if resolved_width <= 1920 or resolved_height <= 1080:
        return "fhd_1080"
    if resolved_width <= 2560 or resolved_height <= 1440:
        return "qhd_1440"
    if resolved_width <= 3840 or resolved_height <= 2160:
        return "uhd_2160"
    return "large_desktop"


def fluid_content_width(widget: QWidget | None = None, *, fallback: int = 1024) -> int:
    """Return the live content width available to a widget.

    This intentionally avoids brand/model/screen-size assumptions.  It uses the
    current widget viewport/contents rectangle first, then falls back to the
    supplied value.  The same rule works for resized windows, maximized windows,
    QScrollArea-hosted pages, and mixed-monitor setups.
    """
    if widget is None:
        return max(1, int(fallback or 1))
    try:
        viewport = getattr(widget, "viewport", None)
        if callable(viewport):
            vp = call_if_callable(viewport)
            if vp is not None and int(vp.width() or 0) > 0:
                return max(1, int(vp.width()))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("fluid_content_width viewport lookup failed", exc_info=True)
    try:
        rect = widget.contentsRect()
        if int(rect.width() or 0) > 0:
            return max(1, int(rect.width()))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("fluid_content_width contents lookup failed", exc_info=True)
    try:
        if int(widget.width() or 0) > 0:
            return max(1, int(widget.width()))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("fluid_content_width width lookup failed", exc_info=True)
    return max(1, int(fallback or 1))


def profile_for_dimensions(
    width: int | None = None,
    height: int | None = None,
    *,
    app: QApplication | None = None,
) -> ResponsiveProfile:
    """Return a fluid desktop profile derived from the live client area.

    HERFY remains a desktop/sidebar application, but density must follow the
    actual window instead of pretending every window is permanently 1440x900.
    This prevents controls/cards from looking oversized in a reduced window and
    avoids excessive expansion when maximized.
    """
    geometry = primary_screen_geometry(app)
    resolved_width = int(
        width or (geometry.width() if geometry is not None else STABLE_LAYOUT_REFERENCE_WIDTH)
    )
    resolved_height = int(
        height or (geometry.height() if geometry is not None else STABLE_LAYOUT_REFERENCE_HEIGHT)
    )
    resolved_width = max(640, resolved_width)
    resolved_height = max(480, resolved_height)
    breakpoint = visual_breakpoint_for_dimensions(resolved_width, resolved_height)

    mode = layout_mode_for_width(resolved_width)
    name = mode
    density = "compact"
    control_height = 32
    if resolved_height <= 600:
        margin, gap, dialog_margin = 4, 4, 6
    elif resolved_height <= 720:
        margin, gap, dialog_margin = 6, 6, 8
    elif mode in {"wide", "extra_wide"}:
        # Large windows gain breathing room, never proportionally giant controls.
        margin, gap, dialog_margin = 8, 8, 10
    else:
        margin, gap, dialog_margin = 6, 6, 8

    return ResponsiveProfile(
        name=name,
        width=resolved_width,
        height=resolved_height,
        orientation="portrait" if resolved_height > resolved_width else "landscape",
        density=density,
        navigation_mode="sidebar",
        touch_mode=False,
        control_height=control_height,
        touch_target=control_height,
        page_margin=margin,
        gap=gap,
        dialog_margin=dialog_margin,
        visual_breakpoint=breakpoint,
    )


def profile_for_widget(
    widget: QWidget | None, *, app: QApplication | None = None
) -> ResponsiveProfile:
    """Return a responsive profile from the widget's current usable viewport.

    Screen geometry is only a startup fallback. Once a widget has real geometry,
    resizing the application immediately changes the semantic layout profile.
    """
    app = app or QApplication.instance()
    if widget is None:
        return profile_for_dimensions(None, None, app=app)

    width, height = viewport_size(widget)
    if width <= 1 or height <= 1:
        geometry = active_screen_geometry(widget, app)
        if geometry is not None:
            width = int(geometry.width()) if width <= 1 else width
            height = int(geometry.height()) if height <= 1 else height

    return profile_for_dimensions(width, height, app=app)


def configure_page_layout(widget: QWidget, layout):
    """Apply the canonical page-root spacing contract."""
    widget.setProperty("pageRootManaged", True)
    profile = profile_for_widget(widget, app=QApplication.instance())
    margin = max(6, int(profile.page_margin))
    layout.setContentsMargins(margin, margin, margin, margin)
    layout.setSpacing(max(4, int(profile.gap)))
    return layout


def apply_profile_properties(widget: QWidget | None, profile: ResponsiveProfile) -> None:
    if widget is None:
        return
    properties = {
        "responsiveProfile": profile.name,
        "layoutMode": layout_mode_for_width(profile.width),
        "deviceClass": (
            "compact" if profile.is_narrow else "comfortable" if profile.is_tablet else "expanded"
        ),
        "density": profile.density,
        "touchUi": profile.touch_mode,
        "portraitUi": profile.orientation == "portrait",
        "navigationMode": profile.navigation_mode,
        "visualBreakpoint": profile.visual_breakpoint,
        "heightConstrainedUi": profile.visual_breakpoint
        in {"small_terminal", "hd_720", "laptop_768"},
        "deviceAdaptiveContract": "live-viewport-responsive-native-dpi",
        "compactUi": profile.is_narrow,
        "tabletUi": profile.is_tablet,
        "expandedUi": profile.name in {"desktop", "wide", "extra_wide"},
    }
    changed = False
    for name, value in properties.items():
        if widget.property(name) != value:
            widget.setProperty(name, value)
            changed = True
    if changed:
        try:
            style = widget.style()
            if style is not None:
                style.unpolish(widget)
                style.polish(widget)
            widget.update()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Responsive profile repolish failed", exc_info=True)


def primary_screen_geometry(app: QApplication | None = None):
    app = app or QApplication.instance()
    try:
        screen = app.primaryScreen() if app else None
        if screen is not None:
            return screen.availableGeometry()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("primary_screen_geometry fallback failed", exc_info=True)
    return None


def active_screen_geometry(widget: QWidget | None = None, app: QApplication | None = None):
    """Return available geometry for the screen where the widget currently lives.

    This supports mixed monitor fleets and windows moved between displays.
    """
    try:
        screen = screen_for_widget(widget, app)
        if screen is not None:
            return screen.availableGeometry()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("active_screen_geometry fallback failed", exc_info=True)
    return primary_screen_geometry(app)


def screen_size_tier(app: QApplication | None = None, *, widget: QWidget | None = None) -> str:
    geometry = active_screen_geometry(widget, app)
    width = int(geometry.width()) if geometry is not None else 1366
    height = int(geometry.height()) if geometry is not None else 768
    breakpoint = visual_breakpoint_for_dimensions(width, height)
    if breakpoint in {"small_terminal", "hd_720", "laptop_768"}:
        return "small"
    if breakpoint in {"hd_plus_900", "fhd_1080"}:
        return "medium"
    if breakpoint == "qhd_1440":
        return "large"
    return "ultra"


def tiered_window_ratio(
    width_ratio: float = 0.86,
    height_ratio: float = 0.88,
    *,
    app: QApplication | None = None,
    widget: QWidget | None = None,
) -> tuple[float, float]:
    tier = screen_size_tier(app, widget=widget)
    if tier == "small":
        return (min(width_ratio, 0.965), min(height_ratio, 0.935))
    if tier == "medium":
        return (min(width_ratio, 0.94), min(height_ratio, 0.92))
    return (width_ratio, height_ratio)


def resolved_window_width(
    window_width: int | None = None,
    app: QApplication | None = None,
    *,
    fallback: int = 1366,
) -> int:
    try:
        width = int(window_width or 0)
    except (TypeError, ValueError):
        width = 0
    if width <= 0:
        geometry = primary_screen_geometry(app)
        width = int(geometry.width()) if geometry is not None else int(fallback)
    return width


def device_size_class(window_width: int | None = None, app: QApplication | None = None) -> str:
    width = resolved_window_width(window_width, app)
    geometry = primary_screen_geometry(app)
    height = int(geometry.height()) if geometry is not None else 768
    profile = profile_for_dimensions(width, height, app=app)
    if profile.is_narrow:
        return "compact"
    if profile.is_tablet:
        return "comfortable"
    return "expanded"


# ---------------------------------------------------------------------------
# Canonical DPI scaling, window fitting, and adaptive reflow
# ---------------------------------------------------------------------------

_MIN_USER_SCALE = 0.85
_MAX_USER_SCALE = 1.25


def scale_factor(app: QApplication | None = None) -> float:
    """Return the optional user UI scale in Qt logical-pixel space.

    Qt's high-DPI pipeline already converts logical pixels for the active
    monitor. Multiplying by logical DPI again causes double-scaling when moving
    between 125%/150% Windows displays, so the default is deliberately 1.0.
    ``HERFY_UI_SCALE`` remains an explicit accessibility override.
    """
    del app
    raw = str(os.environ.get("HERFY_UI_SCALE", "") or "").strip()
    if not raw:
        return 1.0
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return 1.0
    return max(_MIN_USER_SCALE, min(_MAX_USER_SCALE, value))


def make_scaler(app: QApplication | None = None) -> Callable[[int], int]:
    """Return the canonical logical-pixel scaler for client UI metrics."""
    factor = scale_factor(app)

    def scale(px: int) -> int:
        try:
            return int(round(float(px) * factor))
        except (TypeError, ValueError):
            try:
                return int(px)
            except (TypeError, ValueError):
                return 0

    return scale


def clamp_size_to_screen(
    size: QSize,
    *,
    padding: int = 24,
    app: QApplication | None = None,
    widget: QWidget | None = None,
) -> QSize:
    geometry = active_screen_geometry(widget, app)
    if geometry is None:
        return size
    safe_width = max(1, int(geometry.width()) - int(padding))
    safe_height = max(1, int(geometry.height()) - int(padding))
    return QSize(
        min(int(size.width()), safe_width),
        min(int(size.height()), safe_height),
    )


def adaptive_page_margin(window_width: int | None = None, app: QApplication | None = None) -> int:
    return profile_for_dimensions(window_width, None, app=app).page_margin


def adaptive_dimension(
    window_width: int | None,
    app: QApplication | None,
    *,
    compact: int,
    comfortable: int,
    expanded: int,
) -> int:
    profile = profile_for_dimensions(window_width, None, app=app)
    value = compact if profile.is_narrow else comfortable if profile.is_tablet else expanded
    return make_scaler(app)(value)


def adaptive_control_height(
    window_width: int | None = None, app: QApplication | None = None
) -> int:
    return profile_for_dimensions(window_width, None, app=app).control_height


@dataclass(frozen=True, slots=True)
class LayoutModeState:
    mode: str
    width: int
    height: int
    profile: ResponsiveProfile


def viewport_size(widget: QWidget | None, *, fallback_width: int = 1024) -> tuple[int, int]:
    if widget is None:
        return max(1, int(fallback_width or 1)), 1
    try:
        viewport = getattr(widget, "viewport", None)
        if callable(viewport):
            area = viewport()
            if area is not None and int(area.width() or 0) > 0:
                return max(1, int(area.width())), max(1, int(area.height() or 1))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Unable to resolve viewport size", exc_info=True)
    try:
        rect = widget.contentsRect()
        if int(rect.width() or 0) > 0:
            return max(1, int(rect.width())), max(1, int(rect.height() or 1))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Unable to resolve widget contents size", exc_info=True)
    try:
        return (
            max(1, int(widget.width() or fallback_width)),
            max(1, int(widget.height() or 1)),
        )
    except UI_OPERATION_EXCEPTIONS:
        return max(1, int(fallback_width or 1)), 1


def layout_state_for_widget(widget: QWidget | None) -> LayoutModeState:
    width, height = viewport_size(widget)
    return LayoutModeState(
        mode=layout_mode_for_width(width),
        width=width,
        height=height,
        profile=profile_for_dimensions(width, height, app=QApplication.instance()),
    )


class LayoutModeController(QObject):
    """Emit a semantic reflow only when the effective adaptive profile changes."""

    modeChanged = Signal(str, object)
    reflowRequested = Signal(str, object)

    def __init__(self, owner: QWidget) -> None:
        super().__init__(owner)
        self._owner = owner
        self._current_mode = ""
        self._current_signature: tuple[object, ...] | None = None
        self._pending_force = False

    def schedule(self, *, force: bool = False) -> None:
        # Resize events are already delivered on the GUI thread. Reflow immediately
        # and only when the semantic signature changes; no polling/debounce timer.
        self._pending_force = bool(force or self._pending_force)
        self._flush()

    def _flush(self) -> None:
        owner = self._owner
        if owner is None:
            return
        state = layout_state_for_widget(owner)
        current = (
            state.mode,
            state.profile.name,
            state.profile.visual_breakpoint,
            state.profile.orientation,
            state.profile.touch_mode,
            max(1, int(state.width)) // 48,
            max(1, int(state.height)) // 40,
        )
        mode_changed = state.mode != self._current_mode
        profile_changed = current != self._current_signature
        if mode_changed:
            self._current_mode = state.mode
            self.modeChanged.emit(state.mode, state.profile)
        if profile_changed:
            self._current_signature = current
        if profile_changed or self._pending_force:
            self.reflowRequested.emit(state.mode, state.profile)
        self._pending_force = False


def ensure_layout_mode_controller(
    owner: QWidget, *, attr_name: str = "_layout_mode_controller"
) -> LayoutModeController:
    controller = getattr(owner, attr_name, None)
    if isinstance(controller, LayoutModeController):
        return controller
    controller = LayoutModeController(owner)
    setattr(owner, attr_name, controller)
    return controller


def _call_with_supported_args(
    callback: Callable[..., Any], *, mode: str, profile: Any, force: bool = False
) -> Any:
    try:
        params = signature(callback).parameters
    except (TypeError, ValueError):
        return callback()
    accepts_var_kw = any(param.kind == Parameter.VAR_KEYWORD for param in params.values())
    kwargs: dict[str, Any] = {}
    if accepts_var_kw or "mode" in params:
        kwargs["mode"] = mode
    if accepts_var_kw or "profile" in params:
        kwargs["profile"] = profile
    if accepts_var_kw or "force" in params:
        kwargs["force"] = force
    return callback(**kwargs)


def dispatch_reflow_callback(
    owner: Any, callback_name: str, *, mode: str, profile: Any, force: bool = False
) -> None:
    callback = getattr(owner, str(callback_name or ""), None)
    if callable(callback):
        _call_with_supported_args(callback, mode=mode, profile=profile, force=force)


# ---------------------------------------------------------------------------
# Canonical interface density pass
# ---------------------------------------------------------------------------


def apply_density_contract(
    root: QWidget | None,
    profile: ResponsiveProfile | None = None,
) -> None:
    """Apply one profile-aware density contract without creating a second theme."""
    if root is None:
        return
    profile = profile or profile_for_widget(root)
    if profile.name == "wide":
        margin_cap, gap_cap = 8, 6
    else:
        margin_cap, gap_cap = 6, 6

    layouts = [root.layout(), *root.findChildren(QLayout)]
    for layout in layouts:
        if layout is None:
            continue
        margins = layout.contentsMargins()
        layout.setContentsMargins(
            min(margin_cap, margins.left()),
            min(margin_cap, margins.top()),
            min(margin_cap, margins.right()),
            min(margin_cap, margins.bottom()),
        )
        if layout.spacing() >= 0:
            layout.setSpacing(min(gap_cap, layout.spacing()))

    control_height = int(profile.touch_target if profile.touch_mode else profile.control_height)
    action_height = max(
        control_height,
        (
            UI_METRICS.action_button_min_height
            if not profile.touch_mode
            else int(profile.touch_target)
        ),
    )
    for widget in [root, *root.findChildren(QWidget)]:
        if isinstance(widget, (QLineEdit, QComboBox, QAbstractSpinBox)):
            widget.setMinimumHeight(control_height)
            # Never cap native controls to one fixed height.  A forced maximum
            # clips translated text, large system fonts, and touch-friendly
            # styles after a window resize.  The layout may grow vertically;
            # the minimum remains the shared desktop density baseline.
            widget.setMaximumHeight(UI_METRICS.widget_maximum_extent)
            continue
        if not isinstance(widget, (QPushButton, QToolButton)):
            continue
        variant = str(widget.property("variant") or widget.property("role") or "")
        is_action = variant in {
            "primary",
            "dangerPrimary",
            "destructive",
        } or widget.objectName() in {"login_submit", "usage_recalculate"}
        target_height = action_height if is_action else control_height
        widget.setMinimumHeight(target_height)
        widget.setMaximumHeight(UI_METRICS.widget_maximum_extent)

    for table in root.findChildren(QTableView):
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setAlternatingRowColors(True)
        table.setWordWrap(False)
        table.setTextElideMode(Qt.ElideRight)
        if not bool(table.property("allowInlineEdit")):
            table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.verticalHeader().setVisible(False)
        header = table.horizontalHeader()
        header.setDefaultAlignment(Qt.AlignCenter)
        header.setHighlightSections(False)
        header.setSectionsMovable(False)
        sortable = bool(table.property("sortableTable")) or bool(table.isSortingEnabled())
        header.setSectionsClickable(sortable)
        header.setSortIndicatorShown(sortable)
        header.setCascadingSectionResizes(False)
        # Column sizing belongs to ui.tables and to each table's explicit
        # contract.  Do not flatten those strategies to Fixed here: doing so
        # prevents Stretch/Interactive columns from consuming available space
        # when the desktop window is resized.


def polish_interface(root: QWidget | None, *, window_width=None) -> None:
    """Apply the canonical profile, density, and text-visibility contracts."""
    del window_width
    if root is None:
        return
    profile = profile_for_widget(root)
    apply_profile_properties(root, profile)
    apply_density_contract(root, profile)
    polish_text_visibility(root)


"""Shared component defaults in logical pixels; Qt handles monitor DPI."""
