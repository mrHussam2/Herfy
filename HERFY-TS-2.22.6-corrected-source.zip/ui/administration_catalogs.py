"""Server-authorized product catalog workspace for Administration."""

from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QLabel, QTabWidget, QVBoxLayout, QWidget

from core.settings import _
from ui.theme import profile_for_widget


class CatalogServiceUnavailableSection(QWidget):
    """Visible fallback when catalog administration cannot be composed.

    A missing optional service must never leave an authorized Administration
    route as an empty workspace.  This section keeps the route explicit and
    non-mutating while the shell recovers its runtime services.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("AdminCatalogServiceUnavailable")
        self.setProperty("uiRole", "administrationSection")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)

        title = QLabel(_("Unavailable"), self)
        title.setObjectName("AdminCatalogServiceUnavailableTitle")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)

        detail = QLabel(
            _("Catalog administration is unavailable in this client session."), self
        )
        detail.setObjectName("AdminCatalogServiceUnavailableDetail")
        detail.setWordWrap(True)
        detail.setAlignment(Qt.AlignCenter)
        layout.addWidget(detail)

    def is_dirty(self) -> bool:
        return False

    def set_compact(self, _compact: bool) -> None:
        return


class AdministrationCatalogsSection(QWidget):
    """Embed catalog administration without owning its server authority."""

    def __init__(self, catalog_service: Any, worker_registry, parent=None, *, app_state=None):
        super().__init__(parent)
        if catalog_service is None:
            raise RuntimeError("Administration catalogs require the catalog management service")

        from ui.catalogs import CatalogManagementController, CatalogPage

        self.setObjectName("AdminCatalogsSection")
        self.setProperty("uiRole", "administrationSection")
        self.catalog_service = catalog_service
        self._app_state = app_state
        self.controller = CatalogManagementController(catalog_service, worker_registry, self)
        self.pages: dict[str, CatalogPage] = {}
        self._kind_by_index: list[str] = []
        self._pending_catalog_kinds: set[str] = set()
        self._sync_timer = QTimer(self)
        self._sync_timer.setSingleShot(True)
        self._sync_timer.timeout.connect(self._refresh_synchronized_catalogs)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        self.tabs = QTabWidget(self)
        self.tabs.setObjectName("AdminCatalogTabs")
        self.tabs.setDocumentMode(True)
        self.tabs.setMovable(False)
        self.tabs.setTabsClosable(False)
        self.tabs.setUsesScrollButtons(True)
        layout.addWidget(self.tabs, 1)

        permissions = dict(catalog_service.permissions() or {})
        for kind, label in (("stored", _("Stored Products")), ("usage", _("Usage Products"))):
            if not bool(permissions.get(kind)):
                continue
            page = CatalogPage(kind, self.controller, True, self.tabs)
            self.pages[kind] = page
            self._kind_by_index.append(kind)
            self.tabs.addTab(page, label)

        if not self.pages:
            empty = QLabel(_("You do not have permission to manage product catalogs."), self)
            empty.setObjectName("AdminCatalogNoAccess")
            empty.setWordWrap(True)
            empty.setAlignment(Qt.AlignCenter)
            layout.addWidget(empty, 1)

        self.controller.loaded.connect(self._on_loaded)
        self.controller.mutated.connect(self._on_mutated)
        self.controller.error.connect(self._on_error)
        self.controller.busy.connect(self._on_busy)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        signal = getattr(self._app_state, "data_changed", None)
        if signal is not None:
            signal.connect(self._on_app_state_catalog_changed)

        if self.tabs.count():
            self.tabs.setCurrentIndex(0)
            QTimer.singleShot(0, self.refresh)

    def _current_kind(self) -> str:
        index = int(self.tabs.currentIndex())
        return self._kind_by_index[index] if 0 <= index < len(self._kind_by_index) else ""

    def _on_tab_changed(self, _index: int) -> None:
        self.refresh()

    def refresh(self) -> None:
        kind = self._current_kind()
        if kind:
            force = kind in self._pending_catalog_kinds
            self._pending_catalog_kinds.discard(kind)
            self.controller.load(kind, force=force)

    def _on_app_state_catalog_changed(self, domain, _payload=None) -> None:
        kind = {"tracking": "stored", "usage": "usage"}.get(
            str(domain or "").strip().lower()
        )
        if kind not in self.pages:
            return
        self.controller.invalidate(kind)
        self._pending_catalog_kinds.add(kind)
        if self.isVisible() and not self._sync_timer.isActive():
            self._sync_timer.start(150)

    def _refresh_synchronized_catalogs(self) -> None:
        if not self.isVisible():
            return
        self.refresh()

    def showEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().showEvent(event)
        if self._pending_catalog_kinds and not self._sync_timer.isActive():
            self._sync_timer.start(0)

    def _on_loaded(self, kind: str, rows) -> None:
        page = self.pages.get(str(kind))
        if page is not None:
            page.set_rows(list(rows or []))
            page.set_online(self.controller.state.online)

    def _on_mutated(self, kind: str, row) -> None:
        page = self.pages.get(str(kind))
        if page is None:
            return
        page.set_rows(self.controller.state.section(kind).rows)
        page.load_row(dict(row or {}))
        page._show_notice(_("Saved."), "success")

    def _on_error(self, kind: str, message: str) -> None:
        page = self.pages.get(str(kind))
        if page is not None:
            page._show_notice(str(message or _("Unable to save product.")), "error")

    def _on_busy(self, kind: str, busy: bool) -> None:
        page = self.pages.get(str(kind))
        if page is not None:
            page.set_busy(bool(busy))

    def is_dirty(self) -> bool:
        page = self.pages.get(self._current_kind())
        return bool(page is not None and page.is_dirty())

    def set_compact(self, compact: bool) -> None:
        for page in self.pages.values():
            page.set_compact(bool(compact))

    def resizeEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().resizeEvent(event)
        self.set_compact(profile_for_widget(self).is_narrow)
