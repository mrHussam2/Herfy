from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Mapping

from core.settings import bundled_or_source_path

"""Single-source Qt theme loader for the Windows client."""


_TOKEN = re.compile(r"\{\{([A-Za-z][A-Za-z0-9_]*)\}\}")


class ThemeManager:
    """Load exactly one canonical stylesheet and resolve optional design tokens."""

    def __init__(
        self,
        *,
        tokens_path: Path | None = None,
        stylesheet_path: Path | None = None,
    ) -> None:
        self._tokens_path = tokens_path
        self._stylesheet_path = stylesheet_path or bundled_or_source_path("resources", "style.qss")
        self._tokens: dict[str, str] | None = None

    @property
    def tokens(self) -> Mapping[str, str]:
        if self._tokens is None:
            if self._tokens_path is None:
                self._tokens = {}
            else:
                data = json.loads(self._tokens_path.read_text(encoding="utf-8"))
                if not isinstance(data, dict):
                    raise ValueError("Theme tokens must be a JSON object")
                self._tokens = {
                    str(key): str(value)
                    for key, value in data.items()
                    if str(key).strip() and isinstance(value, (str, int, float))
                }
        return dict(self._tokens)

    @property
    def resource_directory(self) -> Path:
        return self._stylesheet_path.parent

    def stylesheet(self) -> str:
        source = self._stylesheet_path.read_text(encoding="utf-8")

        def replace(match: re.Match[str]) -> str:
            key = match.group(1)
            values = self.tokens
            if key not in values:
                raise ValueError(f"Theme token '{key}' is not defined")
            return values[key]

        return _TOKEN.sub(replace, source)

    def apply(self, application) -> None:
        application.setStyleSheet(self.stylesheet())
