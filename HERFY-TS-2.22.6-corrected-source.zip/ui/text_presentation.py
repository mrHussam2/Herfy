"""Shared presentation-only text visibility helpers."""

from __future__ import annotations

import logging
from typing import Any

from PySide6.QtWidgets import QLabel

from core.errors import UI_OPERATION_EXCEPTIONS

logger = logging.getLogger(__name__)


def _clean_text(value: Any) -> str:
    return " ".join(str(value or "").split())


def _tooltip_from_text(widget: Any, value: str | None = None) -> None:
    """Expose complete text only for labels that opt into an overflow tooltip."""
    text = _clean_text(value)
    if not text and hasattr(widget, "text"):
        try:
            text = _clean_text(widget.text())
        except UI_OPERATION_EXCEPTIONS:
            text = ""
    if not text:
        return
    try:
        if not _clean_text(widget.toolTip()):
            widget.setToolTip(text)
    except UI_OPERATION_EXCEPTIONS:
        return


def polish_text_visibility(root: Any) -> None:
    """Apply semantic text visibility without taking ownership of geometry."""
    if root is None or not hasattr(root, "findChildren"):
        return
    try:
        for label in root.findChildren(QLabel):
            wants_tooltip = bool(label.property("tooltipFromText")) or bool(
                str(label.property("elideMode") or "").strip()
            )
            if wants_tooltip:
                _tooltip_from_text(label, label.text())
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("polish_text_visibility failed", exc_info=True)
