from __future__ import annotations

import logging
import time
from dataclasses import replace

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QApplication

from core.errors import SERVICE_OPERATION_EXCEPTIONS, UI_OPERATION_EXCEPTIONS
from core.presentation import RuntimeVisibleStateService
from core.settings import _
from ui.app_updates import UpdateDialog
from ui.dialogs import show_info_message
from ui.login import LoginPage
from ui.theme import show_runtime_notice
from ui.widgets import widget_alive
from version import __version__ as APP_VERSION

logger = logging.getLogger(__name__)


"""Main-window authentication, session restoration, and update lifecycle."""


class SessionAuthControllerMixin:
    def _ensure_login_page(self):
        page = getattr(self, "login_page", None)
        try:
            if page is not None and widget_alive(page):
                is_ready = getattr(page, "is_runtime_ready", None)
                if callable(is_ready) and (not bool(is_ready())):
                    page = None
                else:
                    if (
                        getattr(self, "content_stack", None) is not None
                        and self.content_stack.indexOf(page) < 0
                    ):
                        self.content_stack.insertWidget(0, page)
                    return page
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowSessionMixin._ensure_login_page fallback failed",
                exc_info=True,
            )
        try:
            page = LoginPage(
                self,
                worker_registry=self._new_worker_registry(),
                authentication_service=self.authentication_service,
                session_persistence=self.session_persistence,
            )
            self.login_page = page
            if getattr(self, "content_stack", None) is not None:
                self.content_stack.insertWidget(0, page)
            return page
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Failed to recreate login page")
            return None

    def logout(self):
        self._advance_runtime_generation()
        self._set_runtime_lifecycle_state("DISCONNECTED")
        self._begin_ui_transition(_("Signing out..."), lock_navigation=True, keep_exit=True)
        try:
            try:
                self._dispose_administration_page()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Administration page disposal during logout failed", exc_info=True)
            try:
                self._dispose_product_catalog_page()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Catalog page disposal during logout failed", exc_info=True)
            for window_attr in ("_settings_dialog", "_update_dialog"):
                child_window = getattr(self, window_attr, None)
                if child_window is not None:
                    try:
                        child_window.close()
                    except UI_OPERATION_EXCEPTIONS:
                        logger.debug(
                            "Secondary window close during logout failed: %s",
                            window_attr,
                            exc_info=True,
                        )
                    setattr(self, window_attr, None)
            gate = getattr(self, "_mandatory_password_gate", None)
            if gate is not None:
                try:
                    gate._completed = True
                    gate.close()
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "Mandatory password gate close during logout failed", exc_info=True
                    )
                self._mandatory_password_gate = None
            try:
                self.cloud_sync_runtime_service.disconnect_session(clear_catalog=True)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout cloud shutdown failed", exc_info=True)
            self._clear_persistent_session_safely()
            monitor = getattr(self, "monitoring", None)
            stop_monitoring = getattr(monitor, "stop", None)
            if callable(stop_monitoring):
                stop_monitoring()
            for tname in (
                "token_refresh_timer",
                "_authority_reconcile_timer",
            ):
                t = getattr(self, tname, None)
                if t:
                    try:
                        t.stop()
                    except UI_OPERATION_EXCEPTIONS:
                        logger.debug(
                            "MainWindowSessionMixin.logout fallback failed",
                            exc_info=True,
                        )
            try:
                self.runtime.tracking_service.reset_baseline()
                self._monitoring_initialized = False
                if getattr(self, "notifications_service", None) is not None:
                    self.notifications_service.reset_runtime_state(clear_history=True)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            try:
                self._hide_notifications_popup()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            try:
                self._set_cloud_state(False, show_status_feedback=False)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            self._post_contract_update_check_pending = False
            self._login_hydrate_pending = False
            self._update_check_running = False
            try:
                if getattr(self, "app_state", None) is not None:
                    self.app_state.reset_identity()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            try:
                track_page = getattr(self, "track_page", None)
                if track_page is not None:
                    track_page.reset_after_logout()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            try:
                self.update_user_scope_ui(view_branch="")
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            try:
                page = self._ensure_login_page()
                if page is not None:
                    page.prepare_for_logout()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("MainWindowSessionMixin.logout fallback failed", exc_info=True)
            self._apply_logged_out_shell(reset_sidebar=True)
            self._safe_apply_cached_startup_contract()
        finally:
            self._end_ui_transition(restore_shell=False)
            self._refresh_tray_session_state()
            self._safe_show_login()

    def show_login(self):
        page = self._ensure_login_page()
        try:
            usage_page = getattr(self, "usage_page", None)
            if usage_page is not None:
                clear_workspace = getattr(usage_page, "clear_workspace", None)
                if callable(clear_workspace):
                    clear_workspace()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowSessionMixin.show_login usage clear failed", exc_info=True)
        try:
            # Login is deliberately shown without the inactive workspace
            # chrome.  This avoids an empty page with a disabled sidebar while
            # preserving the sign-in form as the only actionable surface.
            self.top_bar.setVisible(False)
            self.sidebar_host.setVisible(False)
            self._set_top_bar_session_actions_visible(False)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowSessionMixin.show_login fallback failed", exc_info=True)
        try:
            if (
                page is not None
                and getattr(self, "content_stack", None) is not None
                and widget_alive(self.content_stack)
            ):
                self.content_stack.setCurrentWidget(page)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowSessionMixin.show_login fallback failed", exc_info=True)
        try:
            if page is not None:
                page.prepare_for_logout()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowSessionMixin.show_login fallback failed", exc_info=True)
        try:
            if page is not None:
                page.restore_cached_input(clear_password=True)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowSessionMixin.show_login fallback failed", exc_info=True)
        self._bring_to_front(show_if_hidden=True)


class SessionRestoreControllerMixin:

    def _save_persistent_session(self):
        try:
            # Session persistence is opt-in.  Token refreshes and subsequent
            # cloud updates also flow through this method, so using a literal
            # ``True`` here would silently turn an ordinary sign-in into a
            # remembered session.
            remember = bool(getattr(self, "_remember_session", False))
            self.session_runtime_service.save_session(
                session=self.app_state.session,
                profile=self.app_state.current_user,
                remember=remember,
                saved_at=int(time.time()),
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowSessionMixin._save_persistent_session fallback failed",
                exc_info=True,
            )

    def _clear_persistent_session(self):
        try:
            self.session_runtime_service.clear_session()
        except (AttributeError, RuntimeError, TypeError, ValueError, OSError):
            logger.debug(
                "MainWindowSessionMixin._clear_persistent_session fallback failed",
                exc_info=True,
            )

    def try_restore_session_async(self):
        """Restore only after the server refreshes and authorizes the user.

        Secure-file reads belong to the same worker as refresh/pull so opening the
        login shell never blocks the Qt event loop on disk or credential storage.
        """
        if getattr(self, "_restore_session_running", False):
            return
        self._restore_session_running = True
        try:
            self.login_page.set_transition_busy(True, _("Restoring session..."))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Session restore busy-state failed", exc_info=True)
        self._begin_ui_transition(_("Restoring session..."), lock_navigation=True, keep_exit=True)
        session_runtime_service = self.session_runtime_service

        def _work(progress_callback=None):
            del progress_callback
            return session_runtime_service.restore_remembered_session()

        runtime_generation = self._runtime_generation_value()

        def _guarded_restore_result(payload):
            if self._runtime_generation_is_current(runtime_generation):
                self._on_restore_session_result(payload)

        def _guarded_restore_done():
            self._restore_session_running = False
            if not self._runtime_generation_is_current(runtime_generation):
                return
            try:
                self.login_page.set_transition_busy(False, "")
                self.login_page.restore_cached_input(clear_password=True)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("Session restore finish failed", exc_info=True)
            self._end_ui_transition(restore_shell=True)

        worker = self._start_logged_worker(
            _work,
            on_result=_guarded_restore_result,
            on_finished=_guarded_restore_done,
            warning_message="restore session failed",
            operation_key="restore_session",
        )
        if worker is None:
            self._restore_session_running = False
            try:
                self.login_page.set_transition_busy(False, "")
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Restore start-failure busy-state cleanup skipped", exc_info=True)
            self._end_ui_transition(restore_shell=True)

    def _on_restore_session_result(self, payload):
        payload = payload or {}
        try:
            if payload.get("clear"):
                self._clear_persistent_session_safely()
                return
            if payload.get("noop"):
                return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowSessionMixin._on_restore_session_result fallback failed",
                exc_info=True,
            )
        session = payload.get("session")
        profile = payload.get("profile")
        if session and profile:
            self.on_login_success(session, profile, remember=True, _restored=True)

    def _apply_cached_startup_contract(self):
        runtime_generation = self._runtime_generation_value()
        update_runtime_service = self.update_runtime_service

        def _work(progress_callback=None):
            del progress_callback
            return update_runtime_service.apply_cached_startup_contract()

        def _on_result(payload):
            if not self._runtime_generation_is_current(runtime_generation):
                return
            if isinstance(payload, dict) and payload:
                self._handle_startup_contract(payload)

        self._start_logged_worker(
            _work,
            on_result=_on_result,
            warning_message="cached startup contract apply failed",
            operation_key="startup_contract_cached",
        )

    def refresh_startup_contract_async(self):
        if getattr(self, "_startup_contract_running", False):
            return
        if not self.cloud_sync_runtime_service.connected():
            logger.debug("Startup bootstrap deferred until an authenticated API client exists")
            return
        self._startup_contract_running = True
        self._startup_contract_result_applied = False
        update_runtime_service = self.update_runtime_service

        def _work(progress_callback=None):
            del progress_callback
            return update_runtime_service.fetch_startup_contract(APP_VERSION)

        def _result(payload):
            try:
                self._handle_startup_contract(payload or {})
                self._startup_contract_result_applied = True
            except UI_OPERATION_EXCEPTIONS:
                logger.debug(
                    "MainWindowSessionMixin.refresh_startup_contract_async._result fallback failed",
                    exc_info=True,
                )

        runtime_generation = self._runtime_generation_value()

        def _guarded_contract_result(payload):
            if not self._runtime_generation_is_current(runtime_generation):
                return
            _result(payload)

        def _guarded_contract_done():
            self._startup_contract_running = False
            if not self._runtime_generation_is_current(runtime_generation):
                return
            if not getattr(self, "_startup_contract_result_applied", False):
                self._apply_runtime_update_flow(
                    self.update_runtime_service.after_startup_contract(
                        session_active=self.app_state.session is not None,
                        pending_optional_login_check=bool(
                            getattr(self, "_post_contract_update_check_pending", False)
                        ),
                        force_logout=False,
                        mandatory_update_required=False,
                    )
                )

        worker = self._start_logged_worker(
            _work,
            on_result=_guarded_contract_result,
            on_finished=_guarded_contract_done,
            error_handler=lambda _msg: None,
            operation_key="startup_contract_refresh",
        )
        if worker is None:
            self._startup_contract_running = False

    def _apply_runtime_update_flow(self, flow_decision, *, optional_delay_ms: int = 1500) -> None:
        if bool(getattr(flow_decision, "clear_pending_optional_check", False)):
            self._post_contract_update_check_pending = False
        if bool(getattr(flow_decision, "schedule_mandatory_check", False)):
            try:
                QTimer.singleShot(
                    1200,
                    lambda: self._maybe_check_updates(force=True, mandatory=True),
                )
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowSessionMixin._apply_runtime_update_flow fallback failed",
                    exc_info=True,
                )
            return
        if bool(getattr(flow_decision, "schedule_optional_check", False)):
            try:
                QTimer.singleShot(optional_delay_ms, self._maybe_check_updates)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowSessionMixin._apply_runtime_update_flow fallback failed",
                    exc_info=True,
                )

    def _handle_startup_contract(self, payload: dict):
        evaluation = self.update_runtime_service.evaluate_startup_contract(
            payload if isinstance(payload, dict) else {},
            session_active=self.app_state.session is not None,
            pending_optional_login_check=bool(
                getattr(self, "_post_contract_update_check_pending", False)
            ),
            current_version=APP_VERSION,
        )
        decision = evaluation.contract
        update_flow = evaluation.flow
        if decision.clear_cached_session:
            self._clear_persistent_session_safely()
        if decision.show_banner_message:
            try:
                self._show_shell_status_message(decision.show_banner_message, 10000)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowSessionMixin._handle_startup_contract fallback failed",
                    exc_info=True,
                )
        self._apply_runtime_update_flow(update_flow)
        if decision.force_logout:
            try:
                self.logout()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowSessionMixin._handle_startup_contract fallback failed",
                    exc_info=True,
                )
            return


logger = logging.getLogger(__name__)


class MainWindowUpdatesMixin:
    """Single-window, signed-manifest update flow."""

    def _show_pending_update_success(self) -> None:
        runtime_generation = self._runtime_generation_value()
        update_runtime_service = self.update_runtime_service

        def _work(progress_callback=None):
            del progress_callback
            return update_runtime_service.consume_update_success_marker(APP_VERSION)

        def _result(version: object) -> None:
            if not self._runtime_generation_is_current(runtime_generation):
                return
            clean_version = str(version or "").strip()
            if not clean_version:
                return
            show_info_message(
                self,
                _("Update completed"),
                _("HERFY-TS was updated successfully to version {version}.").format(
                    version=clean_version
                ),
            )

        self._start_logged_worker(
            _work,
            on_result=_result,
            warning_message="Update success marker consumption failed",
            operation_key="update:success-marker",
        )

    def _ensure_update_dialog(self) -> UpdateDialog:
        window = getattr(self, "_update_dialog", None)
        if window is None:
            window = UpdateDialog(
                self.runtime.update_manager_factory,
                APP_VERSION,
                self._new_worker_registry(),
                self,
            )
            window.setAttribute(Qt.WA_DeleteOnClose, True)
            window.destroyed.connect(self._on_update_dialog_closed)
            window.handoff_requested.connect(self.close_app_completely)
            window.mandatory_exit_requested.connect(self._quit_for_required_update)
            window.retry_requested.connect(
                lambda: self._maybe_check_updates(force=True, interactive=True)
            )
            self._update_dialog = window
        return window

    def _on_update_dialog_closed(self, *_args) -> None:
        self._update_dialog = None

    def _close_online_update_service(self) -> None:
        # Kept as the lifecycle hook name used by application shutdown. The
        # old multi-dialog service no longer exists.
        window = getattr(self, "_update_dialog", None)
        if window is not None:
            try:
                window.workers.close()
                window.close()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Update window shutdown failed", exc_info=True)
        self._update_dialog = None

    def _quit_for_required_update(self) -> None:
        app = QApplication.instance()
        if app is not None:
            self.close_app_completely()
            return
        raise SystemExit(0)

    @staticmethod
    def _update_menu_badge_text(base_text: str, *, available: bool, mandatory: bool = False) -> str:
        return f"{base_text}  1" if (available or mandatory) else base_text

    def _maybe_check_updates(
        self,
        *,
        force: bool = False,
        interactive: bool = False,
        mandatory: bool = False,
    ):
        if mandatory:
            force = True
        if getattr(self, "_update_check_running", False):
            window = getattr(self, "_update_dialog", None)
            if interactive and window is not None:
                window.bring_to_front()
            return
        self._update_check_running = True
        window = self._ensure_update_dialog() if (interactive or mandatory) else None
        if window is not None:
            window.set_checking(mandatory=mandatory)
            window.bring_to_front()
        start_message = RuntimeVisibleStateService.update_check_started(
            interactive=bool(interactive)
        )
        show_runtime_notice(self, start_message, logger_=logger, context="update check")
        runtime_generation = self._runtime_generation_value()
        update_runtime_service = self.update_runtime_service
        update_manager_factory = self.runtime.update_manager_factory

        def work(progress_callback=None):
            del progress_callback
            skipped_version, should_check = update_runtime_service.resolve_check(force=force)
            if not should_check:
                return {"disabled": True}
            # Production remote updates always use the stable-AppId signed
            # installer. This keeps Windows Installed Apps identity/version,
            # runtime replacement, installed self-check and restart in one
            # canonical transaction. No login/session API client is involved.
            manager = update_manager_factory(APP_VERSION)
            # A version skipped while it was optional must never suppress the
            # same release after server policy makes it mandatory. Mandatory
            # compatibility policy always overrides the local skip preference.
            effective_skipped_version = "" if mandatory else skipped_version
            info = manager.fetch(skipped_version=effective_skipped_version)
            update_runtime_service.mark_check_success()
            return {"disabled": False, "payload": ("installer", info)}

        def result(worker_payload):
            if not self._runtime_generation_is_current(runtime_generation):
                return
            data = worker_payload if isinstance(worker_payload, dict) else {}
            if bool(data.get("disabled")):
                if interactive:
                    disabled_message = RuntimeVisibleStateService.update_checks_disabled()
                    self._show_runtime_status_message(
                        disabled_message.text, disabled_message.timeout_ms
                    )
                    current_window = getattr(self, "_update_dialog", None) or window
                    if current_window is not None:
                        current_window.set_error(
                            _("Automatic update checks are disabled in Settings."),
                            mandatory=mandatory,
                        )
                return
            self._on_update_check_result(
                data.get("payload"),
                interactive=interactive,
                mandatory_override=mandatory,
            )

        def finished():
            self._finish_update_check()

        worker = self._start_logged_worker(
            work,
            on_result=result,
            on_finished=finished,
            warning_message="Update check failed",
            operation_key="update_check",
            error_handler=lambda msg: self._on_update_check_error(
                str(msg), mandatory=mandatory, interactive=interactive
            ),
        )
        if worker is None:
            self._finish_update_check()

    def _finish_update_check(self) -> None:
        self._update_check_running = False
        try:
            self._clear_shell_status_message()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to clear update-check shell status", exc_info=True)

    def _set_update_summary(self, latest_version: str, status: str) -> None:
        self._latest_server_update_version = str(latest_version or APP_VERSION)
        self._update_status_summary = str(status or _("Up to date"))
        about_page = getattr(self, "about_page", None)
        if about_page is not None:
            about_page.set_update_summary(
                self._latest_server_update_version,
                self._update_status_summary,
            )

    def _on_update_check_error(self, message: str, *, mandatory: bool, interactive: bool) -> None:
        logger.warning("Update check failed: %s", message)
        self._set_update_summary(APP_VERSION, _("Update check failed"))
        if interactive or mandatory:
            window = self._ensure_update_dialog()
            window.set_error(message, mandatory=mandatory)
            window.bring_to_front()

    def _set_update_action_badge(self, *, available: bool, mandatory: bool = False) -> None:
        base_text = _("Check for Updates")
        badge = self._update_menu_badge_text(base_text, available=available, mandatory=mandatory)
        action = getattr(self, "act_check_updates", None)
        if action is not None:
            action.setText(badge)
            action.setToolTip(
                _("Required update available")
                if mandatory
                else (_("Update available") if available else base_text)
            )
        menu_button = getattr(self, "btn_menu_file", None)
        if menu_button is not None:
            try:
                base = _("File")
                menu_button.setText(
                    self._update_menu_badge_text(base, available=available, mandatory=mandatory)
                )
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Update menu badge failed", exc_info=True)
        self._update_tray_badge()

    def check_for_updates_now(self):
        self._maybe_check_updates(force=True, interactive=True)

    def _on_update_check_result(
        self,
        payload,
        *,
        interactive: bool = False,
        mandatory_override: bool = False,
    ):
        try:
            kind, info = self.update_runtime_service.normalize_payload(payload)
            if mandatory_override and hasattr(info, "mandatory"):
                info = replace(info, mandatory=True)
            available = bool(getattr(info, "available", False))
            mandatory = bool(getattr(info, "mandatory", False) or mandatory_override)
            latest = str(
                getattr(info, "target_version", "") or getattr(info, "latest", "") or APP_VERSION
            )
            self._set_update_summary(
                latest, _("Update available") if available else _("Up to date")
            )
            self._set_update_action_badge(available=available, mandatory=mandatory)
            if not available:
                if interactive or mandatory:
                    window = self._ensure_update_dialog()
                    if mandatory:
                        window.set_error(
                            _("The required update package is not currently available."),
                            mandatory=True,
                        )
                    else:
                        window.set_up_to_date()
                    window.bring_to_front()
                return
            window = self._ensure_update_dialog()
            window.set_available(kind, info, mandatory=mandatory)
            window.bring_to_front()
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            logger.exception("Update result handling failed")
            self._on_update_check_error(str(exc), mandatory=mandatory_override, interactive=True)


logger = logging.getLogger(__name__)
