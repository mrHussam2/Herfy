from __future__ import annotations

import logging
from typing import Any

from PySide6.QtCore import QEvent, QObject, QPoint, QSize, Qt, QTimer
from PySide6.QtWidgets import (
    QApplication,
    QDialogButtonBox,
    QFrame,
    QLabel,
    QMessageBox,
    QVBoxLayout,
    QWidget,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.models import safe_get
from core.settings import user_error_message
from ui.theme_responsive import (
    apply_profile_properties,
    clamp_size_to_screen,
    polish_interface,
    profile_for_dimensions,
    profile_for_widget,
)
from ui.widgets import (
    apply_window_icon,
    direction_for_rtl,
    polish_button,
    refresh_widget_style,
)

logger = logging.getLogger(__name__)


class DialogCardMixin:
    def _card(
        self, object_name: str, title: str = "", subtitle: str = ""
    ) -> tuple[QFrame, QVBoxLayout]:
        card = QFrame()
        card.setObjectName(object_name)
        layout = QVBoxLayout(card)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(6)
        if title:
            title_label = QLabel(title)
            title_label.setProperty("textRole", "sectionTitle")
            layout.addWidget(title_label)
        if subtitle:
            subtitle_label = QLabel(subtitle)
            subtitle_label.setProperty("textRole", "mutedStatus")
            subtitle_label.setWordWrap(True)
            layout.addWidget(subtitle_label)
        return card, layout


def text_value(mapping: dict, *keys: str) -> str:
    for key in keys:
        value = str(safe_get(mapping, key, "") or "").strip()
        if value:
            return value
    return "-"


def create_dialog_root(dialog: Any) -> QVBoxLayout:
    """Create the canonical root layout for application dialogs.

    Dialogs that need the shared popup contract must not invent independent
    margins/spacing or replace an existing layout.  Keeping this constructor
    here gives every caller one ownership point for the root geometry.
    """
    if dialog is None:
        raise ValueError("dialog is required")
    existing = dialog.layout() if hasattr(dialog, "layout") else None
    if existing is not None:
        if not isinstance(existing, QVBoxLayout):
            raise RuntimeError("dialog already has a non-canonical root layout")
        return existing
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(10, 10, 10, 10)
    layout.setSpacing(12)
    return layout


class _PopupResponsiveFilter(QObject):
    """Apply the shared layout contract to every popup on real Qt geometry events."""

    def __init__(self, dialog: Any) -> None:
        # QObject parenting can emit a child event immediately. Keep the Python
        # reference available before Qt owns this filter, and treat a released
        # dialog as a normal terminal state in ``eventFilter`` below.
        self._dialog = dialog
        super().__init__(dialog)
        self._signature: tuple[str, int, int] | None = None

    def eventFilter(self, watched: Any, event: Any) -> bool:
        dialog = getattr(self, "_dialog", None)
        if dialog is None:
            return False
        event_types = {QEvent.Show, QEvent.Resize}
        screen_change = getattr(QEvent, "ScreenChangeInternal", None)
        if screen_change is not None:
            event_types.add(screen_change)
        if watched is dialog and event.type() in event_types:
            self._apply()
            if event.type() == screen_change:
                QTimer.singleShot(0, lambda: _finalize_dialog_placement(self._dialog))
        return False

    def _apply(self) -> None:
        dialog = getattr(self, "_dialog", None)
        if dialog is None:
            return
        try:
            width = max(1, int(dialog.width() or 0))
            height = max(1, int(dialog.height() or 0))
            profile = profile_for_dimensions(width, height, app=QApplication.instance())
            signature = (profile.name, width // 80, height // 80)
            if signature == self._signature:
                return
            self._signature = signature
            apply_profile_properties(dialog, profile)
            _apply_dialog_button_variants(dialog)
            polish_interface(dialog, window_width=width)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Popup responsive contract refresh failed", exc_info=True)


def _apply_dialog_button_variants(dialog: Any) -> None:
    try:
        for box in dialog.findChildren(QDialogButtonBox):
            for button in box.buttons():
                role = box.buttonRole(button)
                if role == QDialogButtonBox.DestructiveRole:
                    variant = "danger"
                elif role in {
                    QDialogButtonBox.AcceptRole,
                    QDialogButtonBox.YesRole,
                    QDialogButtonBox.ApplyRole,
                }:
                    variant = "primary"
                else:
                    variant = "secondary"
                if str(button.property("variant") or "") != variant:
                    button.setProperty("variant", variant)
                    button.style().unpolish(button)
                    button.style().polish(button)
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Dialog button variant normalization failed", exc_info=True)


def _install_popup_responsive_filter(dialog: Any) -> None:
    if dialog is None or not hasattr(dialog, "installEventFilter"):
        return
    current = getattr(dialog, "_herfy_popup_responsive_filter", None)
    if isinstance(current, _PopupResponsiveFilter):
        return
    controller = _PopupResponsiveFilter(dialog)
    dialog._herfy_popup_responsive_filter = controller
    dialog.installEventFilter(controller)


def fit_dialog_to_screen(dialog: Any, *, padding: int = 24) -> None:
    """Keep a dialog usable on the active work area, including small monitors."""
    if dialog is None or not hasattr(dialog, "resize"):
        return
    try:
        bounds = _available_screen_geometry(dialog)
        if bounds is None:
            return
        safe_width = max(1, int(bounds.width()) - 2 * int(padding))
        safe_height = max(1, int(bounds.height()) - 2 * int(padding))

        minimum_width = min(max(0, int(dialog.minimumWidth() or 0)), safe_width)
        minimum_height = min(max(0, int(dialog.minimumHeight() or 0)), safe_height)
        if hasattr(dialog, "setMinimumSize"):
            dialog.setMinimumSize(minimum_width, minimum_height)

        width = min(max(int(dialog.width() or 0), minimum_width), safe_width)
        height = min(max(int(dialog.height() or 0), minimum_height), safe_height)
        dialog.resize(QSize(max(1, width), max(1, height)))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Dialog screen-fit failed", exc_info=True)


def _finalize_dialog_placement(dialog: Any) -> None:
    fit_dialog_to_screen(dialog)
    center_dialog_over_parent(dialog)


def apply_dialog_basics(
    dialog: Any,
    *,
    object_name: str | None = None,
    modal: bool | None = None,
    size_grip: bool | None = None,
    rtl: bool | None = None,
) -> None:
    if dialog is None:
        return
    _install_popup_responsive_filter(dialog)
    try:
        if object_name and hasattr(dialog, "setObjectName"):
            dialog.setObjectName(str(object_name))
        set_dialog_app_icon(dialog)
        if hasattr(dialog, "windowFlags") and hasattr(dialog, "setWindowFlags"):
            # Keep the native system menu and X close button available on every
            # normal HERFY dialog. Individual dialogs may still confirm unsaved
            # changes in closeEvent, but the title-bar close action must work.
            flags = dialog.windowFlags() & ~Qt.WindowContextHelpButtonHint
            flags |= Qt.WindowSystemMenuHint | Qt.WindowCloseButtonHint
            dialog.setWindowFlags(flags)
        if hasattr(dialog, "setProperty"):
            if not str(dialog.property("uiScope") or "").strip():
                dialog.setProperty("uiScope", "dialog")
            dialog.setProperty("modernDialog", True)
            dialog.setProperty("popupContract", "screenAwareV2")
            apply_profile_properties(dialog, profile_for_widget(dialog))
        if modal is not None and hasattr(dialog, "setModal"):
            dialog.setModal(bool(modal))
        if size_grip is not None and hasattr(dialog, "setSizeGripEnabled"):
            dialog.setSizeGripEnabled(bool(size_grip))
        if hasattr(dialog, "setLayoutDirection"):
            if rtl is not None:
                dialog.setLayoutDirection(direction_for_rtl(bool(rtl)))
            else:
                parent = dialog.parentWidget() if hasattr(dialog, "parentWidget") else None
                if parent is not None and hasattr(parent, "layoutDirection"):
                    dialog.setLayoutDirection(parent.layoutDirection())
        QTimer.singleShot(0, lambda: _finalize_dialog_placement(dialog))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Applying dialog basics failed", exc_info=True)


def set_dialog_app_icon(dialog: Any) -> None:
    try:
        apply_window_icon(dialog)
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Applying dialog app icon failed", exc_info=True)


def _available_screen_geometry(dialog: Any):
    app = QApplication.instance()
    if app is None:
        return None
    parent = (
        dialog.parentWidget() if dialog is not None and hasattr(dialog, "parentWidget") else None
    )
    anchor = None
    if parent is not None and hasattr(parent, "frameGeometry"):
        try:
            anchor = parent.frameGeometry().center()
        except UI_OPERATION_EXCEPTIONS:
            anchor = None
    if anchor is None and dialog is not None and hasattr(dialog, "frameGeometry"):
        try:
            anchor = dialog.frameGeometry().center()
        except UI_OPERATION_EXCEPTIONS:
            anchor = None
    screen = app.screenAt(anchor) if anchor is not None and hasattr(app, "screenAt") else None
    if screen is None:
        screen = app.primaryScreen()
    return screen.availableGeometry() if screen is not None else None


def _effective_dialog_ratios(
    name: str, width_ratio: float, height_ratio: float
) -> tuple[float, float]:
    profile = str(name or "desktop")
    if profile == "compact":
        return (max(min(float(width_ratio), 0.98), 0.94), max(min(float(height_ratio), 0.94), 0.86))
    if profile == "tablet_portrait":
        return (max(min(float(width_ratio), 0.94), 0.72), max(min(float(height_ratio), 0.90), 0.62))
    if profile == "tablet_landscape":
        return (min(max(float(width_ratio), 0.34), 0.90), min(max(float(height_ratio), 0.30), 0.86))
    if profile == "wide":
        return (min(max(float(width_ratio), 0.24), 0.82), min(max(float(height_ratio), 0.18), 0.82))
    return (min(max(float(width_ratio), 0.24), 0.86), min(max(float(height_ratio), 0.18), 0.86))


def _popup_contract_size(
    dialog: Any,
    width_ratio: float,
    height_ratio: float,
    *,
    min_width: int,
    min_height: int,
    max_width: int | None,
    max_height: int | None,
    padding: int,
    constrain_to_parent: bool,
) -> QSize:
    """Resolve size from the active monitor without exceeding its work area."""
    app = QApplication.instance()
    bounds = _available_screen_geometry(dialog)
    if bounds is None:
        return clamp_size_to_screen(
            QSize(max(360, min_width), max(240, min_height)),
            padding=padding,
            app=app,
            widget=dialog,
        )

    profile = profile_for_dimensions(bounds.width(), bounds.height(), app=app)
    width_ratio, height_ratio = _effective_dialog_ratios(
        profile.name, float(width_ratio), float(height_ratio)
    )
    safe_width = max(1, bounds.width() - int(padding))
    safe_height = max(1, bounds.height() - int(padding))
    effective_min_width = min(max(320, int(min_width)), safe_width)
    effective_min_height = min(max(240, int(min_height)), safe_height)
    effective_max_width = safe_width
    effective_max_height = safe_height
    if max_width is not None:
        effective_max_width = min(effective_max_width, max(320, int(max_width)))
    if max_height is not None:
        effective_max_height = min(effective_max_height, max(240, int(max_height)))

    target_width = max(effective_min_width, int(round(bounds.width() * width_ratio)))
    target_height = max(effective_min_height, int(round(bounds.height() * height_ratio)))
    size = QSize(
        min(target_width, effective_max_width),
        min(target_height, effective_max_height),
    )

    parent = dialog.parentWidget() if hasattr(dialog, "parentWidget") else None
    if constrain_to_parent and parent is not None and hasattr(parent, "frameGeometry"):
        try:
            parent_frame = parent.frameGeometry()
            parent_safe_width = max(1, parent_frame.width() - int(padding))
            parent_safe_height = max(1, parent_frame.height() - int(padding))
            size.setWidth(min(size.width(), parent_safe_width, safe_width))
            size.setHeight(min(size.height(), parent_safe_height, safe_height))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Parent-aware popup contract fit failed", exc_info=True)
    return size


def apply_popup_contract(
    dialog: Any,
    *,
    object_name: str | None = None,
    modal: bool | None = True,
    size_grip: bool | None = False,
    width_ratio: float = 0.34,
    height_ratio: float = 0.26,
    min_width: int = 360,
    min_height: int = 220,
    max_width: int | None = 720,
    max_height: int | None = 520,
    padding: int = 28,
    constrain_to_parent: bool = True,
) -> None:
    """Apply the unified responsive popup/dialog contract.

    All user-facing popups pass through this helper so update prompts, busy
    indicators, message boxes, and form dialogs share sizing, centering, app
    icon, RTL, and screen-clamping behavior.
    """
    apply_dialog_basics(dialog, object_name=object_name, modal=modal, size_grip=size_grip)
    try:
        if dialog is None or not hasattr(dialog, "resize"):
            return
        size = _popup_contract_size(
            dialog,
            width_ratio,
            height_ratio,
            min_width=min_width,
            min_height=min_height,
            max_width=max_width,
            max_height=max_height,
            padding=padding,
            constrain_to_parent=constrain_to_parent,
        )

        # Enforce the same screen-aware limits used to calculate the initial size.
        # Previously the contract only called ``resize``. A user could then shrink a
        # complex dialog below its usable geometry, which caused labels, action rows,
        # and navigation controls to overlap. The limits are clamped to the active
        # monitor so small displays still remain usable.
        bounds = _available_screen_geometry(dialog)
        if bounds is not None:
            safe_width = max(1, int(bounds.width()) - int(padding))
            safe_height = max(1, int(bounds.height()) - int(padding))
        else:
            safe_width = max(320, int(size.width()))
            safe_height = max(240, int(size.height()))
        effective_min_width = min(max(320, int(min_width)), safe_width)
        effective_min_height = min(max(240, int(min_height)), safe_height)
        effective_max_width = (
            safe_width if max_width is None else min(safe_width, max(320, int(max_width)))
        )
        effective_max_height = (
            safe_height if max_height is None else min(safe_height, max(240, int(max_height)))
        )
        if hasattr(dialog, "setMinimumSize"):
            dialog.setMinimumSize(effective_min_width, effective_min_height)
        if hasattr(dialog, "setMaximumSize"):
            dialog.setMaximumSize(
                max(effective_min_width, effective_max_width),
                max(effective_min_height, effective_max_height),
            )
        dialog.resize(size)
        apply_profile_properties(
            dialog,
            profile_for_dimensions(
                int(size.width()), int(size.height()), app=QApplication.instance()
            ),
        )
        center_dialog_over_parent(dialog)
        if hasattr(dialog, "setProperty"):
            dialog.setProperty("popupContract", "screenAwareV2")
            refresh_widget_style(dialog)
        # Window decorations are not final until Qt has polished/shown the
        # dialog. Re-clamp once in the next event turn without changing size.
        QTimer.singleShot(0, lambda: center_dialog_over_parent(dialog))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Applying responsive popup contract failed", exc_info=True)


def _style_message_buttons(box: QMessageBox, *, danger: bool = False) -> None:
    for button in box.buttons():
        role = box.buttonRole(button)
        is_accept = role in (
            QMessageBox.AcceptRole,
            QMessageBox.YesRole,
            QMessageBox.ApplyRole,
        )
        polish_button(
            button,
            role=("danger" if danger and is_accept else "primary" if is_accept else "secondary"),
        )
        refresh_widget_style(button)


def _show_inline_runtime_message(
    parent: QWidget | None, title: str, message: str, *, duration_ms: int
) -> bool:
    text = " — ".join(
        part for part in (str(title or "").strip(), str(message or "").strip()) if part
    )
    if not text:
        return True
    candidates = [parent] if parent is not None else []
    if parent is not None:
        try:
            window = parent.window()
            if window is not parent:
                candidates.append(window)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Unable to resolve message parent window", exc_info=True)
    app = QApplication.instance()
    if app is not None:
        active = app.activeWindow()
        if active is not None:
            candidates.append(active)
    for candidate in candidates:
        try:
            handler = getattr(candidate, "_show_runtime_status_message", None)
            if callable(handler):
                handler(text, int(duration_ms))
                return True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Runtime message delivery failed", exc_info=True)
    return False


def _message_box(
    parent: QWidget | None, icon: QMessageBox.Icon, title: str, message: str
) -> QMessageBox:
    box = QMessageBox(parent)
    apply_dialog_basics(box, object_name="AppMessageBox", modal=True)
    box.setWindowModality(Qt.WindowModal)
    box.setTextFormat(Qt.PlainText)
    box.setTextInteractionFlags(Qt.TextSelectableByMouse)
    box.setIcon(icon)
    box.setWindowTitle(str(title or ""))
    box.setText(str(message or ""))
    box.setStandardButtons(QMessageBox.Ok)
    box.setLayoutDirection(parent.layoutDirection() if parent is not None else Qt.LeftToRight)
    _style_message_buttons(box)
    return box


def show_info_message(
    parent: QWidget | None, title: str, message: str, *, require_ack: bool = False
) -> None:
    # Temporary credentials and other sensitive messages must never be shown
    # in a disappearing status strip; they require an explicit acknowledgement.
    if require_ack or not _show_inline_runtime_message(parent, title, message, duration_ms=3500):
        _message_box(parent, QMessageBox.Information, title, message).exec()


def show_warning_message(parent: QWidget | None, title: str, message: str) -> None:
    _message_box(parent, QMessageBox.Warning, title, message).exec()


def show_error_message(parent: QWidget | None, title: str, message: str) -> None:
    resolved = user_error_message(message, context="general")
    _message_box(parent, QMessageBox.Critical, title, resolved).exec()


def show_question_message(
    parent: QWidget | None,
    title: str,
    message: str,
    *,
    default_no: bool = True,
    danger: bool = False,
) -> bool:
    box = _message_box(parent, QMessageBox.Question, title, message)
    box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
    # No is always the safe default; callers must never make a destructive
    # action the Enter-key default, including when an old caller passes False.
    box.setDefaultButton(QMessageBox.No)
    box.setEscapeButton(QMessageBox.No)
    _style_message_buttons(box, danger=danger)
    return box.exec() == QMessageBox.Yes


def center_dialog_over_parent(dialog: Any) -> None:
    """Center a dialog over its parent and keep the decorated frame on-screen."""
    if dialog is None or not hasattr(dialog, "move"):
        return
    try:
        bounds = _available_screen_geometry(dialog)
        if bounds is None:
            return

        width = max(int(dialog.width() or 0), int(dialog.minimumWidth() or 0), 1)
        height = max(int(dialog.height() or 0), int(dialog.minimumHeight() or 0), 1)
        width = min(width, max(1, int(bounds.width())))
        height = min(height, max(1, int(bounds.height())))

        parent = dialog.parentWidget() if hasattr(dialog, "parentWidget") else None
        if parent is not None and parent.isVisible():
            anchor = parent.frameGeometry().center()
        else:
            anchor = bounds.center()

        left = int(bounds.left())
        top = int(bounds.top())
        max_x = max(left, int(bounds.right()) - width + 1)
        max_y = max(top, int(bounds.bottom()) - height + 1)
        x = min(max(int(anchor.x()) - width // 2, left), max_x)
        y = min(max(int(anchor.y()) - height // 2, top), max_y)
        dialog.move(QPoint(x, y))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Dialog centering/clamping failed", exc_info=True)
