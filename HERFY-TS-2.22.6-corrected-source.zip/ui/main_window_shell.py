from __future__ import annotations

import logging

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QApplication, QFrame, QHBoxLayout, QScrollArea, QVBoxLayout, QWidget

from core.errors import UI_OPERATION_EXCEPTIONS
from ui.about import AboutPage
from ui.catalogs import ProductCatalogPage
from ui.designer import load_ui
from ui.home import create_home_page
from ui.kpi import KpiPage
from ui.theme import (
    PageStack,
    apply_device_properties,
    apply_responsive_shell_metrics,
    apply_window_constraints,
    build_sidebar,
    build_top_bar,
    ensure_window_on_screen,
    schedule_window_placement_save,
)
from ui.tracking import TrackingPage
from ui.usage import UsagePage

logger = logging.getLogger(__name__)


"""Main-window content-page lifecycle and Designer shell mounting."""


class MainWindowContentPagesMixin:
    def _bind_runtime_state(self, page: QWidget | None) -> None:
        if page is None:
            return
        binder = getattr(page, "bind_app_state", None)
        if callable(binder):
            try:
                binder(getattr(self, "app_state", None))
            except UI_OPERATION_EXCEPTIONS:
                logger.debug(
                    "MainWindowContentPagesMixin._bind_runtime_state failed",
                    exc_info=True,
                )

    def _insert_content_page(self, page: QWidget | None) -> None:
        stack = getattr(self, "content_stack", None)
        if stack is None or page is None:
            return
        try:
            if stack.indexOf(page) < 0:
                stack.addWidget(page)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowContentPagesMixin._insert_content_page failed", exc_info=True)

    def _create_home_page(self) -> QWidget:
        home_page = create_home_page(
            dashboard_service=self.runtime.home_dashboard_service,
            worker_registry=self._new_worker_registry(),
        )
        try:
            home_page.navigate_requested.connect(self._on_home_navigation_requested)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Home navigation signal connection failed", exc_info=True)
        self._bind_runtime_state(home_page)
        return home_page

    def _create_tracking_page(self) -> TrackingPage:
        track_page = TrackingPage(
            parent=self,
            tracking_service=self.runtime.tracking_service,
            tracking_form_service=self.runtime.tracking_form_service,
            page_visible_state_service=self.runtime.page_visible_state_service,
            worker_registry=self._new_worker_registry(),
        )
        self._bind_runtime_state(track_page)
        return track_page

    def _create_usage_page(self) -> UsagePage:
        usage_compute_service = self.presentation_factory.create_usage_compute_service(
            usage_service=self.runtime.usage_service,
            workspace_service=self.runtime.usage_workspace_service,
            parent=None,
        )
        usage_page = UsagePage(
            usage_service=self.runtime.usage_service,
            usage_print_service=self.presentation_factory.create_usage_print_service(),
            usage_workspace_service=self.runtime.usage_workspace_service,
            usage_row_presenter=self.runtime.usage_row_presenter,
            page_visible_state_service=self.runtime.page_visible_state_service,
            usage_compute_service=usage_compute_service,
            access_provider=lambda: self._shell_access_state().can_open_usage,
        )
        usage_compute_service.setParent(usage_page)
        self._bind_runtime_state(usage_page)
        return usage_page

    def _create_kpi_page(self) -> KpiPage:
        return KpiPage(
            scope_provider=lambda: (
                self.cloud_sync_runtime_service.permission_context(),
                self.cloud_sync_runtime_service.allowed_branches(),
            ),
            worker_registry=self._new_worker_registry(),
            parent=self,
        )

    def _create_about_page(self) -> AboutPage:
        return AboutPage(
            latest_version=getattr(self, "_latest_server_update_version", ""),
            update_status=getattr(self, "_update_status_summary", ""),
            check_for_updates=self.check_for_updates_now,
            parent=self,
        )

    def _create_product_catalog_page(self) -> ProductCatalogPage:
        page = ProductCatalogPage(
            self.runtime.catalog_management_service,
            self._new_worker_registry(),
            self,
        )
        # Catalog pages already know how to project the common runtime state
        # signal into their local sections.  Without this binding, a catalog
        # delta received in the background was only visible after navigating
        # away and back (or manually refreshing).  Keep it aligned with the
        # tracking, usage, home and administration workspaces.
        self._bind_runtime_state(page)
        return page

    def _create_administration_page(self) -> QWidget:
        from ui.administration import AdministrationPage

        page = AdministrationPage(
            self.runtime.admin_service,
            self.app_state,
            self._new_worker_registry(),
            self,
            catalog_service=self.runtime.catalog_management_service,
        )
        page.shell_route_requested.connect(self._on_administration_shell_route_requested)
        page.modules_changed.connect(self._set_administration_modules)
        page.route_changed.connect(self._set_administration_sidebar_route)
        self._bind_runtime_state(page)
        return page

    def _ensure_home_page(self) -> QWidget | None:
        if getattr(self, "home_page", None) is None:
            self.home_page = self._create_home_page()
        self._insert_content_page(self.home_page)
        return self.home_page

    def _ensure_track_page(self) -> TrackingPage | None:
        if getattr(self, "track_page", None) is None:
            self.track_page = self._create_tracking_page()
        self._insert_content_page(self.track_page)
        return self.track_page

    def _ensure_usage_page(self) -> UsagePage | None:
        if getattr(self, "usage_page", None) is None:
            self.usage_page = self._create_usage_page()
        self._insert_content_page(self.usage_page)
        return self.usage_page

    def _ensure_kpi_page(self) -> KpiPage | None:
        if getattr(self, "kpi_page", None) is None:
            self.kpi_page = self._create_kpi_page()
        self._insert_content_page(self.kpi_page)
        return self.kpi_page

    def _ensure_about_page(self) -> AboutPage | None:
        if getattr(self, "about_page", None) is None:
            self.about_page = self._create_about_page()
        self._insert_content_page(self.about_page)
        return self.about_page

    def _ensure_product_catalog_page(self) -> ProductCatalogPage | None:
        if getattr(self, "product_catalog_page", None) is None:
            self.product_catalog_page = self._create_product_catalog_page()
        self._insert_content_page(self.product_catalog_page)
        return self.product_catalog_page

    def _dispose_product_catalog_page(self) -> None:
        page = getattr(self, "product_catalog_page", None)
        if page is None:
            return
        stack = getattr(self, "content_stack", None)
        if stack is not None and stack.indexOf(page) >= 0:
            stack.removeWidget(page)
        dispose = getattr(page, "dispose", None)
        if callable(dispose):
            try:
                dispose()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Catalog page disposal failed", exc_info=True)
        page.deleteLater()
        self.product_catalog_page = None

    def _ensure_administration_page(self) -> QWidget | None:
        page = getattr(self, "administration_page", None)
        if page is None:
            try:
                page = self._create_administration_page()
            except UI_OPERATION_EXCEPTIONS:
                # The action layer converts this into an inline user-facing
                # message.  Never let an optional Administration dependency
                # escape the sidebar click and leave the shell on a blank page.
                logger.exception("Administration page creation failed")
                return None
            self.administration_page = page
        self._insert_content_page(page)
        return page

    def _dispose_administration_page(self) -> None:
        page = getattr(self, "administration_page", None)
        if page is None:
            return
        stack = getattr(self, "content_stack", None)
        if stack is not None and stack.indexOf(page) >= 0:
            stack.removeWidget(page)
        dispose = getattr(page, "dispose", None)
        if callable(dispose):
            try:
                dispose()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Administration page disposal failed", exc_info=True)
        page.deleteLater()
        self.administration_page = None
        self._set_administration_modules(tuple())
        self._set_administration_sidebar_expanded(False)

    def _content_pages_ready(self) -> bool:
        stack = getattr(self, "content_stack", None)
        pages = (
            getattr(self, "home_page", None),
            getattr(self, "track_page", None),
            getattr(self, "usage_page", None),
        )
        if stack is None or any((page is None for page in pages)):
            return False
        try:
            return all((stack.indexOf(page) >= 0 for page in pages))
        except UI_OPERATION_EXCEPTIONS:
            return False

    def _ensure_content_pages(self) -> None:
        self._ensure_home_page()
        self._ensure_track_page()
        self._ensure_usage_page()

    def _rebuild_content_pages(self, preserve_index: bool = False) -> None:
        old_index = self.content_stack.currentIndex() if preserve_index else 0
        login_page = getattr(self, "login_page", None)
        login_index = self.content_stack.indexOf(login_page) if login_page is not None else -1
        if login_index >= 0:
            self.content_stack.removeWidget(login_page)
        admin_page = getattr(self, "administration_page", None)
        if admin_page is not None:
            dispose = getattr(admin_page, "dispose", None)
            if callable(dispose):
                try:
                    dispose()
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "Administration page disposal during rebuild failed", exc_info=True
                    )
        while self.content_stack.count() > 0:
            widget = self.content_stack.widget(0)
            self.content_stack.removeWidget(widget)
            if widget is not admin_page:
                dispose = getattr(widget, "dispose", None)
                if callable(dispose):
                    try:
                        dispose()
                    except UI_OPERATION_EXCEPTIONS:
                        logger.debug("Content page disposal during rebuild failed", exc_info=True)
            binder = getattr(widget, "bind_app_state", None)
            if callable(binder):
                try:
                    binder(None)
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "MainWindowContentPagesMixin._rebuild_content_pages unbind failed",
                        exc_info=True,
                    )
            widget.deleteLater()
        if login_index >= 0:
            self.content_stack.insertWidget(0, login_page)
        self.home_page = None
        self.track_page = None
        self.usage_page = None
        self.kpi_page = None
        self.about_page = None
        self.product_catalog_page = None
        self.administration_page = None
        self._set_administration_modules(tuple())
        self._set_administration_sidebar_expanded(False)
        if self.app_state.session:
            self._ensure_content_pages()
        if preserve_index:
            self.content_stack.setCurrentIndex(
                min(max(old_index, 0), self.content_stack.count() - 1)
            )
        else:
            self._select_home_page()

    def init_ui(self):
        self._apply_root_theme()
        controls = load_ui(
            self,
            "main_window",
            required=(
                "app_root",
                "main_area_host",
                "shell_sidebar_host",
                "SidebarDrawerToggle",
                "shell_top_bar_host",
                "content_stack_host",
            ),
        )
        central = controls["app_root"]
        if not isinstance(central.layout(), QHBoxLayout):
            raise RuntimeError("Designer app_root requires a QHBoxLayout")
        if not isinstance(controls["main_area_host"].layout(), QVBoxLayout):
            raise RuntimeError("Designer main_area_host requires a QVBoxLayout")
        self._install_stable_shell(central)
        try:
            apply_device_properties(central, self.width(), QApplication.instance())
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowUiMixin.init_ui fallback failed", exc_info=True)
        self.home_page = None
        self.track_page = None
        self.usage_page = None
        self.kpi_page = None
        self.about_page = None
        self.product_catalog_page = None
        self.administration_page = None
        sidebar_host = controls["shell_sidebar_host"]
        top_bar_host = controls["shell_top_bar_host"]
        content_host = controls["content_stack_host"]

        self.sidebar_host = sidebar_host
        self.sidebar_host_layout = sidebar_host.layout()
        self.sidebar_drawer_toggle = controls["SidebarDrawerToggle"]
        sidebar = build_sidebar(self)

        # Resolve Designer-owned layouts from their host widgets. This keeps
        # ownership explicit and remains correct even if the central widget
        # implementation changes later.
        sidebar_layout = sidebar_host.layout()
        top_bar_layout = top_bar_host.layout()
        content_layout = content_host.layout()
        if not isinstance(sidebar_layout, QVBoxLayout):
            raise RuntimeError("Designer shell_sidebar_host requires a QVBoxLayout")
        if not isinstance(top_bar_layout, QVBoxLayout):
            raise RuntimeError("Designer shell_top_bar_host requires a QVBoxLayout")
        if not isinstance(content_layout, QVBoxLayout):
            raise RuntimeError("Designer content_stack_host requires a QVBoxLayout")

        sidebar_layout.addWidget(sidebar)
        top_bar_layout.addWidget(build_top_bar(self))
        self._build_content_shell(content_layout)


class MainWindowShellLayoutMixin:
    def _install_stable_shell(self, shell_root: QWidget) -> None:
        """Install the fluid desktop shell without globally scaling controls.

        The shell fills the client area and responsive page/layout policies own
        reflow. Logical control metrics stay canonical while available space is
        redistributed by Qt layouts.
        """
        if shell_root is None or bool(getattr(self, "_stable_shell_installed", False)):
            return

        current = self.centralWidget() if hasattr(self, "centralWidget") else None
        if current is not shell_root:
            if current is not None and hasattr(self, "takeCentralWidget"):
                self.takeCentralWidget()
            self.setCentralWidget(shell_root)

        self._stable_shell_installed = True
        self._stable_shell_root = shell_root

    def _scaled(self, value: int) -> int:
        try:
            return int(self.S(value))
        except UI_OPERATION_EXCEPTIONS:
            return int(value)

    def _apply_root_theme(self):
        """The process-level theme is installed once during application startup."""
        return None

    def _build_content_shell(self, content_layout: QVBoxLayout) -> None:
        self.content_layout = content_layout
        self.content_stack = PageStack()
        self.content_stack.setObjectName("ContentStack")
        # The outer window owns the desktop support boundary.  Content pages
        # never reflow into a different composition or introduce a competing
        # workspace scrollbar as the operator resizes the main window.
        self.content_stack.setMinimumSize(1100, 560)
        self.workspace_viewport = QScrollArea()
        self.workspace_viewport.setObjectName("StableWorkspaceViewport")
        self.workspace_viewport.setFrameShape(QFrame.NoFrame)
        self.workspace_viewport.setWidgetResizable(True)
        # The shell is a fixed desktop canvas.  Do not expose a second
        # page-level scrollbar when a monitor is smaller than the supported
        # footprint: pages retain their landmarks and each data view owns its
        # own intentional record scrolling.
        self.workspace_viewport.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.workspace_viewport.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.workspace_viewport.setWidget(self.content_stack)
        content_layout.addWidget(self.workspace_viewport)

    def _show_shell_status_message(self, message: str, timeout_ms: int = 0) -> None:
        text = str(message or "").strip()
        try:
            self.shell_status_message.setText(text)
            self.shell_status_message.setVisible(bool(text))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to show shell status message", exc_info=True)
        timer = getattr(self, "_shell_status_clear_timer", None)
        self._safe_stop_timer(timer)
        if text and int(timeout_ms or 0) > 0:
            try:
                if timer is None:
                    timer = QTimer(self)
                    timer.setSingleShot(True)
                    timer.timeout.connect(self._clear_shell_status_message)
                    self._shell_status_clear_timer = timer
                timer.start(int(timeout_ms))
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Failed to start shell status clear timer", exc_info=True)

    def _clear_shell_status_message(self) -> None:
        try:
            self.shell_status_message.clear()
            self.shell_status_message.hide()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to clear shell status message", exc_info=True)

    def _show_runtime_status_message(self, message: str, timeout_ms: int = 0) -> None:
        if int(getattr(self, "_ui_transition_depth", 0) or 0) > 0:
            return
        self._show_shell_status_message(message, timeout_ms)

    def _connect_screen_change_refresh(self) -> None:
        """Refresh adaptive layout when the window moves to another monitor."""
        if bool(getattr(self, "_screen_change_refresh_connected", False)):
            return
        handle = self.windowHandle() if hasattr(self, "windowHandle") else None
        if handle is None:
            return
        signal = getattr(handle, "screenChanged", None)
        if signal is None:
            return
        try:

            def _on_screen_changed(*_args) -> None:
                apply_window_constraints(self)
                ensure_window_on_screen(self)
                apply_responsive_shell_metrics(self)
                schedule_window_placement_save(self)

            signal.connect(_on_screen_changed)
            self._screen_change_refresh_connected = True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("screen change refresh connection failed", exc_info=True)

    def showEvent(self, event):
        """Apply stable shell metrics when the main window becomes visible."""
        super().showEvent(event)
        self._connect_screen_change_refresh()
        apply_responsive_shell_metrics(self)

    def moveEvent(self, event):
        """Persist placement without changing the fixed page composition."""
        super().moveEvent(event)
        schedule_window_placement_save(self)

    def resizeEvent(self, event):
        """Reflow the shell from the current client area, then persist placement."""
        super().resizeEvent(event)
        apply_responsive_shell_metrics(self)
        schedule_window_placement_save(self)


logger = logging.getLogger(__name__)
