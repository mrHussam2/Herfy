from __future__ import annotations

import logging
import time
from typing import Any

from PySide6.QtCore import QDateTime, Qt, QTimer

from core.errors import (
    SERVICE_OPERATION_EXCEPTIONS,
    STATE_OPERATION_EXCEPTIONS,
    UI_OPERATION_EXCEPTIONS,
)
from core.models import parse_bool
from core.presentation import CloudConnectionPresenter
from core.settings import _

logger = logging.getLogger(__name__)


class CloudSnapshotControllerMixin:
    _SYNC_PROGRESS_STEPS = {
        "starting": (12, "Checking for server changes…"),
        "receiving": (42, "Receiving server changes…"),
        "applying": (82, "Applying server changes…"),
        "complete": (100, "Server changes synchronized."),
        "error": (100, "Synchronization will retry automatically."),
    }

    def _set_automatic_sync_feedback(
        self,
        stage: str,
        *,
        operation_key: str = "",
        present: bool | None = None,
    ) -> None:
        """Present background synchronization without blocking the workspace.

        Snapshot work is intentionally single-flight and runs off the UI thread.
        This method only updates the shell affordance on Qt's owning thread; it
        never locks navigation, changes the active page, or starts a request.
        """
        stage_key = str(stage or "").strip().lower()
        active = getattr(self, "_automatic_sync_operations", None)
        if active is None:
            active = set()
            self._automatic_sync_operations = active
        failed = getattr(self, "_automatic_sync_failed_operations", None)
        if failed is None:
            failed = set()
            self._automatic_sync_failed_operations = failed
        visible = getattr(self, "_automatic_sync_visible_operations", None)
        if visible is None:
            visible = set()
            self._automatic_sync_visible_operations = visible
        if operation_key:
            if stage_key in {"complete", "error"}:
                active.discard(operation_key)
            else:
                active.add(operation_key)
                failed.discard(operation_key)
                # Routine reconciliation happens regularly in the background.
                # A new quiet check also clears a previous retry notice once it
                # actually starts, while an explicitly presented operation keeps
                # its compact progress affordance through completion.
                if present is False:
                    visible.discard(operation_key)
                else:
                    visible.add(operation_key)
            if stage_key == "error":
                failed.add(operation_key)
                # Failures must be actionable even when their originating pull
                # was intentionally quiet.
                visible.add(operation_key)

        # A worker emits ``finished`` after an error.  Preserve the truthful
        # retry state rather than briefly replacing it with a success message.
        effective_stage = "error" if stage_key == "complete" and failed else stage_key
        percent, message = self._SYNC_PROGRESS_STEPS.get(
            effective_stage, self._SYNC_PROGRESS_STEPS["starting"]
        )
        message = _(message)
        should_present = not operation_key or operation_key in visible

        state = getattr(self, "app_state", None)
        if state is not None:
            state.set_sync_state(
                "ERROR" if failed else "SYNCING" if active else "IDLE", message
            )

        progress = getattr(self, "transition_progress", None)
        if progress is not None and should_present:
            visual_state = "error" if failed else "syncing" if active else "idle"
            progress.setProperty(
                "syncState", visual_state
            )
            progress.setRange(0, 100)
            progress.setValue(percent)
            progress.setToolTip(message)
            progress.setAccessibleDescription(message)
            if effective_stage not in {"complete", "error"} or active:
                progress.show()
            elif not int(getattr(self, "_ui_transition_depth", 0) or 0):
                progress.hide()

        if should_present and (effective_stage not in {"complete", "error"} or active):
            self._show_runtime_status_message(message)
        elif should_present and not int(getattr(self, "_ui_transition_depth", 0) or 0):
            self._show_runtime_status_message(
                message, 5000 if effective_stage == "error" else 2500
            )
        if operation_key and stage_key == "complete" and not failed:
            visible.discard(operation_key)

    def _report_automatic_sync_progress(
        self,
        update,
        *,
        operation_key: str,
        present: bool | None = None,
    ) -> None:
        """Translate worker progress into the compact shell status language."""
        if isinstance(update, dict):
            stage = str(update.get("stage") or "").strip().lower()
        else:
            stage = str(update or "").strip().lower()
        if stage:
            self._set_automatic_sync_feedback(
                stage, operation_key=operation_key, present=present
            )

    def _apply_remote_catalog_to_local(self, snapshot: dict | None = None):
        try:
            self.cloud_sync_runtime_service.apply_catalog_snapshot(snapshot)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Remote catalog snapshot apply failed", exc_info=True)

    def _load_cloud_change_payload(self):
        return self.cloud_sync_runtime_service.load_change_payload()

    def _start_cloud_snapshot_worker(
        self,
        *,
        on_result,
        on_finished=None,
        warning_message: str,
        runtime_generation: int | None = None,
        prepare_initial: bool = False,
        present_feedback: bool | None = None,
    ):
        operation_key = "cloud_snapshot:initial" if prepare_initial else "cloud_snapshot:pull"
        if present_feedback is None:
            present_feedback = bool(prepare_initial)
        registry = getattr(self, "_worker_registry", None)
        if (
            registry is not None
            and hasattr(registry, "has_active_key")
            and registry.has_active_key(operation_key)
        ):
            if not prepare_initial:
                self._cloud_snapshot_pull_pending = True
            if on_finished is not None:
                try:
                    self._schedule_runtime_callback(0, on_finished, require_session=True)
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "Duplicate cloud snapshot finish scheduling failed",
                        exc_info=True,
                    )
            return None
        guarded_result = on_result
        cloud_sync_runtime_service = self.cloud_sync_runtime_service
        if runtime_generation is not None and on_result is not None:
            token = int(runtime_generation)

            def _guarded_result(payload, _on_result=on_result, _token=token):
                if self._runtime_generation_is_current(_token):
                    return _on_result(payload)
                return None

            guarded_result = _guarded_result

        self._set_automatic_sync_feedback(
            "starting", operation_key=operation_key, present=present_feedback
        )

        def _work(progress_callback=None):
            if progress_callback is not None:
                progress_callback({"stage": "receiving"})
            if prepare_initial:
                payload = cloud_sync_runtime_service.load_initial_payload()
                payload = dict(payload or {})
                payload["initial_hydrate_prepared"] = True
            else:
                payload = cloud_sync_runtime_service.load_change_payload()
            if progress_callback is not None:
                progress_callback({"stage": "applying"})
            return payload

        def _guarded_finished():
            self._set_automatic_sync_feedback(
                "complete", operation_key=operation_key, present=present_feedback
            )
            if on_finished is not None:
                on_finished()
            if prepare_initial:
                return
            if bool(getattr(self, "_cloud_snapshot_pull_pending", False)):
                self._cloud_snapshot_pull_pending = False
                try:
                    self._schedule_runtime_callback(
                        250, self._on_cloud_changed, require_session=True
                    )
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug("Pending cloud snapshot replay scheduling failed", exc_info=True)

        def _on_sync_error(message: str) -> None:
            logger.warning("%s: %s", warning_message, message)
            self._set_automatic_sync_feedback("error", operation_key=operation_key)

        return self._start_logged_worker(
            _work,
            on_result=guarded_result,
            on_progress=lambda update: self._report_automatic_sync_progress(
                update, operation_key=operation_key, present=present_feedback
            ),
            on_finished=_guarded_finished,
            warning_message=warning_message,
            error_handler=_on_sync_error,
            operation_key=operation_key,
        )

    def _on_cloud_changed(self):
        if getattr(self, "_cloud_change_running", False):
            self._cloud_change_pending = True
            return
        self._cloud_change_running = True
        self._cloud_change_pending = False
        runtime_generation = self._runtime_generation_value()

        def _guarded_cloud_change_finished():
            self._cloud_change_running = False
            if not self._runtime_generation_is_current(runtime_generation):
                self._cloud_change_pending = False
                return
            if getattr(self, "_cloud_change_pending", False):
                self._cloud_change_pending = False
                self._schedule_runtime_callback(250, self._on_cloud_changed, require_session=True)

        worker = self._start_cloud_snapshot_worker(
            on_result=self._on_cloud_changed_result,
            on_finished=_guarded_cloud_change_finished,
            warning_message="cloud change refresh failed",
            runtime_generation=runtime_generation,
        )
        if worker is None:
            self._cloud_change_running = False

    def _emit_app_state_data_changed(
        self,
        reason: str,
        preloaded=None,
        *,
        domains: set[str] | None = None,
        payload=None,
    ) -> None:
        state = getattr(self, "app_state", None)
        if state is None:
            return
        wanted = {
            str(item).strip().lower()
            for item in domains or {"tracking", "usage", "admin"}
            if str(item).strip()
        }
        base_payload = dict(payload or {}) if isinstance(payload, dict) else {}
        base_payload["reason"] = reason
        base_payload["preloaded"] = preloaded
        if "tracking" in wanted:
            state.emit_data_changed("tracking", dict(base_payload))
        if "usage" in wanted:
            state.emit_data_changed("usage", dict(base_payload))
        if "admin" in wanted:
            state.emit_data_changed("admin", dict(base_payload))

    def _domains_from_cloud_payload(self, payload) -> set[str]:
        data = payload if isinstance(payload, dict) else {}
        changes = data.get("changes") or []
        if not isinstance(changes, list):
            changes = []
        if data.get("preloaded") is not None or data.get("rows"):
            domains = {"tracking"}
        else:
            domains = set()
        if parse_bool(data.get("authority_reconcile_required"), False):
            domains.add("admin")
        for change in changes:
            if not isinstance(change, dict):
                continue
            entity = str(change.get("entity_type") or change.get("type") or "").strip().lower()
            if entity == "tracking_item":
                domains.add("tracking")
            elif entity == "stored_product":
                # Stored catalog changes affect catalog/admin surfaces and any
                # tracking selector sourced from the authoritative catalog.
                domains.update({"tracking", "admin"})
            elif entity == "usage_product":
                domains.add("usage")
            elif entity in {"authorization", "organization", "region", "area", "branch"}:
                domains.add("admin")
        if not domains and parse_bool(data.get("has_changes"), False):
            return {"tracking", "admin"}
        return domains

    def _on_cloud_changed_result(self, payload):
        if self._domains_from_cloud_payload(payload):
            self._set_automatic_sync_feedback(
                "applying", operation_key="cloud_snapshot:pull", present=True
            )
        self._apply_cloud_payload_result(
            payload,
            event_reason="server_push",
            log_context="CloudSnapshotControllerMixin._on_cloud_changed_result",
        )

    def _initial_cloud_hydrate_async(self):
        if not self.cloud_sync_runtime_service.connected():
            return
        runtime_generation = self._runtime_generation_value()

        def _guarded_initial_hydrate_finished():
            if not self._runtime_generation_is_current(runtime_generation):
                return
            self._on_initial_cloud_hydrate_finished()

        worker = self._start_cloud_snapshot_worker(
            on_result=self._on_initial_cloud_hydrate_result,
            on_finished=_guarded_initial_hydrate_finished,
            warning_message="initial cloud hydrate failed",
            runtime_generation=runtime_generation,
            prepare_initial=True,
        )
        if worker is None:
            self._login_hydrate_pending = False
            if bool(getattr(self, "_restart_realtime_after_authority_rehydrate", False)):
                self._restart_realtime_after_authority_rehydrate = False
                self._start_realtime_sync()

    def _on_initial_cloud_hydrate_result(self, payload):
        self._set_automatic_sync_feedback("applying", operation_key="cloud_snapshot:initial")
        payload = payload if isinstance(payload, dict) else {}
        self._apply_online_payload_state(payload, show_status_feedback=False)
        self._initial_sync_authorized = bool(payload.get("sync_authorized", True))
        preloaded = payload.get("preloaded")
        if preloaded is not None:
            self.runtime.tracking_service.publish_baseline(preloaded, source="initial_hydrate")
        self._emit_app_state_data_changed(
            "initial_hydrate",
            preloaded=preloaded,
            domains={"tracking", "usage", "admin"},
            payload=payload,
        )

    def _on_initial_cloud_hydrate_finished(self):
        self._login_hydrate_pending = False
        sync_authorized = bool(getattr(self, "_initial_sync_authorized", True))
        if not sync_authorized:
            # The server did not grant sync.pull. Catalog projections may still
            # be available through their own permissions; do not treat the
            # absence of a tracking baseline as a synchronization failure.
            self._set_runtime_lifecycle_state("MONITORING_READY")
            self._start_monitoring(restart=True)
            return

        snapshot = self.runtime.tracking_service.baseline_snapshot()
        if (
            bool(getattr(snapshot, "ready", False))
            or self.cloud_sync_runtime_service.has_tracking_baseline()
        ):
            self._set_runtime_lifecycle_state("BASELINE_READY")
        else:
            logger.error("Initial synchronization finished without an authorized tracking baseline")
            return
        restart_after_authority = bool(
            getattr(self, "_restart_realtime_after_authority_rehydrate", False)
        )
        self._restart_realtime_after_authority_rehydrate = False
        self._start_realtime_sync()
        self._set_runtime_lifecycle_state("REALTIME_READY")
        if restart_after_authority:
            self._schedule_change_driven_pull("authority_scope_reconciled", delay_ms=120)
        self._set_runtime_lifecycle_state("MONITORING_READY")
        self._start_monitoring(restart=True)


class CloudStatusControllerMixin:
    def _set_cloud_state(self, online: bool, *, show_status_feedback: bool = True) -> None:
        try:
            previous = bool(getattr(self, "_cloud_online", False))
            view_state = CloudConnectionPresenter.build(online=bool(online), previous=previous)
            state_changed = view_state.online != previous
            self._cloud_online = view_state.online
            if getattr(self, "app_state", None) is not None:
                self.app_state.set_connection_state(view_state.online, view_state.status_text)
            if getattr(self, "net_indicator", None) is not None:
                full_status = str(view_state.status_text or "")
                self.net_indicator.setProperty("fullText", full_status)
                self.net_indicator.setToolTip(full_status)
                rail_mode = bool(
                    getattr(self, "sidebar", None) and self.sidebar.property("railMode")
                )
                self.net_indicator.setText("●" if rail_mode else full_status)
                self.net_indicator.setProperty("net", view_state.indicator_property)
                try:
                    self.net_indicator.style().unpolish(self.net_indicator)
                    self.net_indicator.style().polish(self.net_indicator)
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "MainWindowCloudMixin._set_cloud_state style refresh failed",
                        exc_info=True,
                    )
            tray_icon = getattr(self, "tray_icon", None)
            if tray_icon is not None:
                try:
                    tray_icon.setToolTip(view_state.tray_tooltip)
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "MainWindowCloudMixin._set_cloud_state tray tooltip refresh failed",
                        exc_info=True,
                    )
            if not state_changed:
                return
            reconnect_flow = self.cloud_sync_runtime_service.reconnect_flow(
                online=view_state.online,
                previous_online=previous,
                session_active=bool(getattr(self.app_state, "session", None)),
                login_hydrate_pending=bool(getattr(self, "_login_hydrate_pending", False)),
            )
            if reconnect_flow.should_invalidate_cache:
                self._safe_invalidate_cloud_cache()
            if reconnect_flow.should_emit_data_refresh:
                try:
                    self._emit_app_state_data_changed("reconnected")
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "MainWindowCloudMixin._set_cloud_state app-state reconnect emission failed",
                        exc_info=True,
                    )
            try:
                self._show_runtime_status_message(view_state.status_message, 4000)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug(
                    "MainWindowCloudMixin._set_cloud_state shell status fallback failed",
                    exc_info=True,
                )
            self._show_connection_status(
                should_show=bool(show_status_feedback),
                title=view_state.status_title,
                message=view_state.status_message,
                level=view_state.status_level,
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowCloudMixin._set_cloud_state fallback failed", exc_info=True)

    def _show_connection_status(
        self, *, should_show: bool, title: str, message: str, level: str
    ) -> None:
        if not should_show:
            return
        try:
            now_ms = int(QDateTime.currentMSecsSinceEpoch())
            status_key = f"{level}:{message}"
            last_key = str(getattr(self, "_last_connection_status_key", "") or "")
            last_ms = int(getattr(self, "_last_connection_status_ms", 0) or 0)
            if status_key == last_key and last_ms and (now_ms - last_ms < 60000):
                return
            self._last_connection_status_key = status_key
            self._last_connection_status_ms = now_ms
            if hasattr(self, "_show_runtime_status_message"):
                self._show_runtime_status_message(str(message or title or ""), 4000)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowCloudMixin._show_connection_status failed", exc_info=True)


logger = logging.getLogger(__name__)


class CloudSessionControllerMixin:
    def on_login_success(
        self,
        session: Any,
        profile: Any,
        remember: bool = False,
        _restored: bool = False,
    ):
        self._advance_runtime_generation()
        self._token_refresh_running = False
        self.app_state.set_session(session)
        self.app_state.set_current_user(profile)
        self._refresh_tray_session_state()
        self._refresh_presentation_preferences_async()
        self._set_runtime_lifecycle_state("AUTHENTICATED")
        self._remember_session = bool(remember)
        self._post_contract_update_check_pending = True
        self._login_hydrate_pending = True
        self.cloud_sync_runtime_service.attach_session(id_token=session.id_token, profile=profile)
        self._update_cloud_service_identity(profile)
        self._set_runtime_lifecycle_state("AUTHORITY_READY")
        # A successful authenticated login is immediate proof that the configured production API is online.
        # Subsequent authenticated pull failures can explicitly switch this back
        # to Offline through _apply_online_payload_state().
        self._set_cloud_state(True, show_status_feedback=False)
        if bool(getattr(profile, "must_change_password", False)):
            # Restricted first-login sessions are valid server sessions, but no
            # application workspace may be hydrated until the password is
            # changed.  Keep the shell explicit and force the password dialog.
            self._login_hydrate_pending = False
            self._set_top_bar_visible(True)
            self._apply_password_change_required_shell()
            self._configure_token_refresh(session)
            self._clear_persistent_session_safely()

            login_page = getattr(self, "login_page", None)
            if login_page is not None:
                try:
                    login_page.set_transition_busy(
                        False,
                        _("Password change is required before using the application."),
                    )
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "Mandatory password-change login status update failed",
                        exc_info=True,
                    )

            logger.info(
                "MANDATORY_PASSWORD_CHANGE_REQUIRED=YES username=%s role=%s",
                str(getattr(profile, "username", "") or ""),
                str(getattr(profile, "role", "") or ""),
            )
            QTimer.singleShot(0, self.open_mandatory_password_gate)
            return
        self._prefetch_allowed_branches_async()
        self._set_runtime_lifecycle_state("INITIAL_SYNC")
        self._ensure_home_page()
        self._hydrate_login_state()
        self._schedule_login_followups()
        self._apply_logged_in_shell_state()
        self._configure_token_refresh(session)
        self._select_home_page()
        self._safe_save_persistent_session()
        restore_notifications = getattr(self, "_restore_notification_history_async", None)
        if callable(restore_notifications):
            restore_notifications(show_panel=False)
        consume_activation = getattr(self, "_consume_pending_notification_activation", None)
        if callable(consume_activation):
            self._schedule_runtime_callback(900, consume_activation, require_session=True)

    def _refresh_presentation_preferences_async(self) -> None:
        runtime_generation = self._runtime_generation_value()

        def _apply(_snapshot) -> None:
            if not self._runtime_generation_is_current(runtime_generation):
                return
            try:
                self._apply_root_theme()
                self.refresh_tray_icon()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Applying refreshed presentation preferences failed", exc_info=True)

        self._start_logged_worker(
            self.runtime.presentation_preferences.refresh,
            on_result=_apply,
            warning_message="presentation preference refresh failed",
            operation_key="preferences:presentation-refresh",
        )

    def _hydrate_login_state(self) -> None:
        try:
            self._sync_default_branch_context()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowCloudMixin._hydrate_login_state branch filter setup failed",
                exc_info=True,
            )
        self._safe_update_user_scope_ui()
        self._safe_refresh_startup_contract_async()
        self._set_top_bar_visible(True)

    def _prefetch_allowed_branches_async(self) -> None:
        """Hydrate all-branch scope without blocking the GUI thread.

        System/admin users may receive an all-branches permission context without
        an explicit branch list in the token.  Fetching /meta/branches directly
        during login used to block the main Qt event loop and could make Windows
        mark the app as "Not Responding" when the server or network was slow.
        """
        cloud_runtime = self.cloud_sync_runtime_service
        if not cloud_runtime.connected():
            return
        try:
            ctx = cloud_runtime.permission_context()
            explicit_branches = list(getattr(getattr(ctx, "scope", None), "branches", []) or [])
            if explicit_branches:
                cloud_runtime.set_allowed_branches(explicit_branches)
                return
            if not bool(getattr(getattr(ctx, "scope", None), "all_branches", False)):
                return
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Allowed branch prefetch eligibility check failed", exc_info=True)
            return
        runtime_generation = self._runtime_generation_value()

        def _work(progress_callback=None):
            del progress_callback
            return cloud_runtime.meta_branches()

        def _on_result(branches):
            if not self._runtime_generation_is_current(runtime_generation):
                return
            cleaned = [str(branch).strip() for branch in branches or [] if str(branch).strip()]
            if not cleaned:
                return
            try:
                cloud_runtime.set_allowed_branches(cleaned)
                self._safe_update_user_scope_ui()
                home_page = getattr(self, "home_page", None)
                if home_page is not None:
                    home_page.refresh_dashboard(
                        profile=getattr(self.app_state, "current_user", None),
                        permission_context=cloud_runtime.permission_context(),
                    )
                self._sync_default_branch_context()
                # A global authority context has no branch ids in its token.
                # Refresh the form after resolving the server-authorized list
                # so it becomes usable without navigation or a manual refresh.
                tracking_page = getattr(self, "track_page", None)
                if tracking_page is not None:
                    tracking_page.refresh_current_branch()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Allowed branch prefetch result apply failed", exc_info=True)

        self._start_logged_worker(
            _work,
            on_result=_on_result,
            warning_message="allowed branch prefetch failed",
            operation_key="allowed_branch_prefetch",
        )

    def _schedule_login_followups(self) -> None:
        self._schedule_runtime_callback(
            3600, self._initial_cloud_hydrate_async, require_session=True
        )

    def _apply_logged_in_shell_state(self) -> None:
        self._apply_logged_in_shell()
        self.apply_role_permissions()
        self._sync_notifications_popup_direction()

    def _configure_token_refresh(self, session: Any) -> None:
        try:
            self.token_refresh_timer.stop()
            refresh_token = str(getattr(session, "refresh_token", "") or "").strip()
            if not refresh_token:
                return
            expires = int(getattr(session, "expires_in", 3600))
            refresh_after = max(300, int(expires) - 600)
            self._token_refresh_due_monotonic = time.monotonic() + refresh_after
            self.token_refresh_timer.start(refresh_after * 1000)
        except (TypeError, ValueError):
            logger.debug("Invalid session expiry; token refresh was not scheduled", exc_info=True)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowCloudMixin._configure_token_refresh fallback failed",
                exc_info=True,
            )

    def _profile_cloud_user_payload(self, profile: Any | None = None) -> dict:
        try:
            return self.cloud_sync_runtime_service.profile_payload(
                profile or self.app_state.current_user
            )
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowCloudMixin._profile_cloud_user_payload fallback failed",
                exc_info=True,
            )
            return {}

    def _authority_signature(self) -> tuple[int, tuple[str, ...], bool, tuple[str, ...]]:
        """Return the complete server-authoritative revision/permission/branch signature."""
        try:
            context = self.cloud_sync_runtime_service.permission_context()
            scope = getattr(context, "scope", None)
            branches = tuple(
                sorted(
                    {
                        str(value).strip().casefold()
                        for value in getattr(scope, "branches", ()) or ()
                        if str(value).strip()
                    }
                )
            )
            permissions = tuple(
                sorted(
                    {
                        str(value).strip()
                        for value in getattr(context, "permissions", ()) or ()
                        if str(value).strip()
                    }
                )
            )
            return (
                int(getattr(context, "authority_revision", 0) or 0),
                permissions,
                bool(getattr(scope, "all_branches", False)),
                branches,
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Authority signature failed", exc_info=True)
            return (0, (), False, ())

    def _schedule_authority_reconciliation(self, delay_ms: int = 120) -> None:
        """Coalesce server authority events into one non-periodic authority refresh."""
        timer = getattr(self, "_authority_reconcile_timer", None)
        if timer is None:
            timer = QTimer(self)
            timer.setSingleShot(True)
            timer.timeout.connect(self._reconcile_authority_from_server)
            self._authority_reconcile_timer = timer
        timer.start(max(0, int(delay_ms)))

    def _reconcile_authority_from_server(self) -> None:
        if not getattr(self.app_state, "session", None):
            return
        before_scope = self._authority_signature()
        self.refresh_cloud_token(
            on_success=lambda: self._on_authority_reconciled(before_scope),
            restart_realtime=False,
        )

    def _on_authority_reconciled(
        self, before_scope: tuple[int, tuple[str, ...], bool, tuple[str, ...]]
    ) -> None:
        """Apply refreshed permissions and repair tracking baseline only on scope change."""
        try:
            self.apply_role_permissions()
            self._safe_update_user_scope_ui()
            self._sync_default_branch_context()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Refreshed authority UI application failed", exc_info=True)

        if not self.cloud_sync_runtime_service.connected():
            return
        after_scope = self._authority_signature()

        try:
            self.cloud_sync_runtime_service.stop_realtime()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Realtime stop for authority reconciliation failed", exc_info=True)

        if after_scope != before_scope:
            # Scope changes invalidate *all* in-flight results created under the
            # previous authority.  Defer to the next event-loop turn so the token
            # refresh worker can finish its own callback, then invalidate old-scope
            # workers and create exactly one fresh authorized baseline.
            if not bool(getattr(self, "_authority_scope_rehydrate_scheduled", False)):
                self._authority_scope_rehydrate_scheduled = True
                self._schedule_runtime_callback(
                    0, self._begin_authority_scope_rehydrate, require_session=True
                )
            return

        self._start_realtime_sync()

    def _begin_authority_scope_rehydrate(self) -> None:
        self._authority_scope_rehydrate_scheduled = False
        if not self.cloud_sync_runtime_service.connected() or not getattr(
            self.app_state, "session", None
        ):
            return
        try:
            # This cancels callback application from any worker that started with
            # the old branch scope.  It also clears operation keys so a new initial
            # hydrate cannot be mistaken for a duplicate of an obsolete worker.
            self._advance_runtime_generation()
            try:
                self.cloud_sync_runtime_service.stop_realtime()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Realtime stop before authority rehydrate failed", exc_info=True)
            self.cloud_sync_runtime_service.reset_cursor()
            self._prefetch_allowed_branches_async()
            self._restart_realtime_after_authority_rehydrate = True
            self._initial_cloud_hydrate_async()
        except SERVICE_OPERATION_EXCEPTIONS:
            self._restart_realtime_after_authority_rehydrate = False
            logger.exception("Authority scope baseline reset failed")
            self._start_realtime_sync()

    def _update_cloud_service_identity(self, profile: Any | None = None):
        if not self.cloud_sync_runtime_service.connected():
            return
        try:
            self.cloud_sync_runtime_service.set_identity_profile(
                profile or self.app_state.current_user
            )
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowCloudMixin._update_cloud_service_identity fallback failed",
                exc_info=True,
            )

    def refresh_cloud_token(self, on_success=None, *, restart_realtime: bool = True):
        """Refresh one session token through the single coalesced refresh worker."""
        waiters = getattr(self, "_token_refresh_success_waiters", None)
        if waiters is None:
            waiters = []
            self._token_refresh_success_waiters = waiters
        if callable(on_success) and on_success not in waiters:
            waiters.append(on_success)

        if getattr(self, "_token_refresh_running", False):
            # The in-flight refresh owns the operation. Callers simply register
            # for its success result; no 250ms retry timer or duplicate network work.
            if restart_realtime:
                self._token_refresh_restart_requested = True
            return
        session = self.app_state.session
        if not session:
            waiters.clear()
            return
        refresh_token_value = str(getattr(session, "refresh_token", "") or "").strip()
        if not refresh_token_value:
            callbacks = list(waiters)
            waiters.clear()
            for callback in callbacks:
                callback()
            return
        self._token_refresh_running = True
        self._token_refresh_restart_requested = bool(restart_realtime)
        self._token_refresh_succeeded = False
        runtime_generation = self._runtime_generation_value()
        authentication_service = self.authentication_service

        def _work(progress_callback=None):
            del progress_callback
            new_session, new_profile = authentication_service.refresh(refresh_token_value)
            if not new_profile:
                return {}
            return {"session": new_session, "profile": new_profile}

        def _on_result(payload):
            if not self._runtime_generation_is_current(runtime_generation):
                return
            data = payload if isinstance(payload, dict) else {}
            new_session = data.get("session")
            new_profile = data.get("profile")
            if not new_session or not new_profile:
                return
            cloud_runtime = self.cloud_sync_runtime_service
            cloud_connected = cloud_runtime.connected()
            restart_requested = bool(getattr(self, "_token_refresh_restart_requested", False))
            if cloud_connected and restart_requested:
                try:
                    cloud_runtime.stop_realtime()
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Realtime stop before token rotation failed", exc_info=True)
            self.app_state.set_session(new_session)
            self.app_state.set_current_user(new_profile)
            self._configure_token_refresh(new_session)
            if cloud_connected:
                try:
                    cloud_runtime.set_id_token(new_session.id_token)
                    self._update_cloud_service_identity(new_profile)
                except STATE_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "MainWindowCloudMixin.refresh_cloud_token service refresh failed",
                        exc_info=True,
                    )
            try:
                if cloud_connected:
                    cloud_runtime.refresh_profile(new_profile)
                self._prefetch_allowed_branches_async()
            except STATE_OPERATION_EXCEPTIONS:
                logger.debug(
                    "MainWindowCloudMixin.refresh_cloud_token application context refresh failed",
                    exc_info=True,
                )
            self._safe_save_persistent_session()
            if cloud_connected and restart_requested:
                self._start_realtime_sync()
            self._token_refresh_succeeded = True
            callbacks = list(getattr(self, "_token_refresh_success_waiters", []) or [])
            self._token_refresh_success_waiters.clear()
            for callback in callbacks:
                try:
                    callback()
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug("Token refresh success callback failed", exc_info=True)

        def _on_finished():
            self._token_refresh_running = False
            self._token_refresh_restart_requested = False
            if not bool(getattr(self, "_token_refresh_succeeded", False)):
                self._token_refresh_success_waiters.clear()
            self._token_refresh_succeeded = False

        worker = self._start_logged_worker(
            _work,
            on_result=_on_result,
            on_finished=_on_finished,
            warning_message="token refresh failed",
            operation_key="token_refresh",
        )
        if worker is None:
            self._token_refresh_running = False
            self._token_refresh_restart_requested = False
            self._token_refresh_succeeded = False
            self._token_refresh_success_waiters.clear()


class CloudPayloadResultControllerMixin:
    def _apply_cloud_payload_result(self, payload, *, event_reason: str, log_context: str) -> None:
        payload = dict(payload or {}) if isinstance(payload, dict) else {}
        domains = self._domains_from_cloud_payload(payload)
        preloaded = payload.get("preloaded") if isinstance(payload, dict) else None
        self._apply_online_payload_state(payload)
        if "admin" in domains:
            # Region/area/branch and authorization events can change the current
            # user's effective server scope.  Reconcile once from the server instead
            # while authority changes arrive through realtime events.
            self._schedule_authority_reconciliation()
        if not domains and (not preloaded):
            return
        applied_delta = isinstance(payload, dict) and any(
            (
                isinstance(payload.get(key), dict) and payload[key].get("applied")
                for key in ("stored_catalog_delta", "tracking_delta", "usage_delta")
            )
        )
        if not applied_delta:
            self._safe_invalidate_cloud_cache()
        try:
            self._emit_app_state_data_changed(
                event_reason, preloaded=preloaded, domains=domains, payload=payload
            )
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("%s app-state emission failed", log_context, exc_info=True)
        if "tracking" in domains:
            tracking_delta = payload.get("tracking_delta") if isinstance(payload, dict) else None
            if (
                event_reason in {"change_driven_pull", "server_push"}
                and isinstance(tracking_delta, dict)
                and bool(tracking_delta.get("applied"))
            ):
                try:
                    self._show_runtime_status_message(_("Tracking data synchronized."), 3000)
                except UI_OPERATION_EXCEPTIONS:
                    logger.debug("%s tracking sync feedback failed", log_context, exc_info=True)
            try:
                self.monitoring.check_now()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("%s expiry refresh failed", log_context, exc_info=True)


class CloudRealtimeControllerMixin:
    # SSE is the low-latency path.  This bounded reconciliation is deliberately
    # a fallback only: it closes any cursor gap caused by a network sleep or a
    # proxy that silently drops an event stream, without asking the operator to
    # navigate away, press Refresh, or restart the client.
    AUTOMATIC_RECONCILE_INTERVAL_MS = 60_000

    def _start_realtime_sync(self) -> None:
        try:
            self.cloud_sync_runtime_service.ensure_realtime(
                hydrate_pending=bool(getattr(self, "_login_hydrate_pending", False)),
                on_changed=self.realtime_change_received.emit,
                on_state=self.realtime_state_received.emit,
            )
            self._start_automatic_reconciliation()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug(
                "MainWindowCloudMixin._start_realtime_sync fallback failed",
                exc_info=True,
            )

    def _start_automatic_reconciliation(self) -> None:
        """Keep the local projection convergent when SSE delivery is interrupted.

        The timer does not touch the network or UI directly.  It enters the
        existing single-flight, debounced sync scheduler, so it cannot create
        parallel pulls or interfere with user edits.
        """
        timer = getattr(self, "_automatic_reconcile_timer", None)
        if timer is None:
            timer = QTimer(self)
            timer.setInterval(self.AUTOMATIC_RECONCILE_INTERVAL_MS)
            timer.timeout.connect(self._run_automatic_reconciliation)
            self._automatic_reconcile_timer = timer
        if not timer.isActive():
            timer.start()

    def _stop_automatic_reconciliation(self) -> None:
        timer = getattr(self, "_automatic_reconcile_timer", None)
        if timer is not None:
            timer.stop()

    def _run_automatic_reconciliation(self) -> None:
        if not getattr(self.app_state, "session", None):
            self._stop_automatic_reconciliation()
            return
        try:
            context = self.cloud_sync_runtime_service.permission_context()
            if not context.is_active or context.must_change_password:
                return
            if not self.cloud_sync_runtime_service.connected():
                return
        except SERVICE_OPERATION_EXCEPTIONS:
            return
        # A delta pull with an unchanged cursor is inexpensive; a changed
        # cursor updates every subscribed page through app-state signals.
        self._schedule_change_driven_pull("automatic_reconciliation", delay_ms=0)

    def _on_application_state_changed(self, state) -> None:
        if state != Qt.ApplicationActive or not self.app_state.session:
            return
        context = self.cloud_sync_runtime_service.permission_context()
        if not context.is_active or context.must_change_password:
            return

        # Re-evaluate tracked-product expiry from local state whenever Windows
        # returns the application to an active session. This covers sleep/resume,
        # clock/date changes while suspended, and long workstation locks without
        # requiring the server or SSE connection to be reachable.
        try:
            self._schedule_runtime_callback(0, self.monitoring.check_now, require_session=True)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Resume local expiry check scheduling failed", exc_info=True)

        # Returning from sleep/inactivity must not churn a healthy SSE connection or
        # trigger a server pull while that stream is still connected.  If the token
        # is due, refresh it once.  Otherwise, only ensure the SSE owner is running;
        # its connected callback performs the single reconnect reconciliation.
        due = float(getattr(self, "_token_refresh_due_monotonic", 0.0) or 0.0)
        if due and time.monotonic() >= due:
            self.refresh_cloud_token(
                on_success=self._resume_authenticated_runtime, restart_realtime=False
            )
            return
        if not bool(getattr(self, "_realtime_transport_connected", False)):
            self._start_realtime_sync()

    def _resume_authenticated_runtime(self) -> None:
        context = self.cloud_sync_runtime_service.permission_context()
        if not self.app_state.session or not context.is_active or context.must_change_password:
            return
        self._start_realtime_sync()

    def _on_realtime_changed(self, cursor: int) -> None:
        if not self.cloud_sync_runtime_service.connected():
            return
        try:
            current_cursor = self.cloud_sync_runtime_service.sync_cursor()
        except SERVICE_OPERATION_EXCEPTIONS:
            current_cursor = 0
        try:
            target_cursor = max(0, int(cursor or 0))
        except (TypeError, ValueError):
            target_cursor = 0
        if target_cursor and target_cursor <= current_cursor:
            return
        # SSE is a coalesced change signal only.  Durable rows are reconciled through
        # /sync/pull on the bounded worker pool; this keeps the UI thread network-free.
        self._schedule_change_driven_pull("realtime", delay_ms=120)

    def _on_realtime_transport_state(self, connected: bool) -> None:
        self._realtime_transport_connected = bool(connected)
        if not bool(connected):
            logger.debug(
                "Realtime transport disconnected; API online state remains unchanged until a request confirms an outage."
            )
            return
        # Reconcile once on every successful reconnect.  The server also sends one
        # coalesced ``changed`` signal when our cursor is behind; both paths feed the
        # same debounced timer and therefore cannot create duplicate pulls.
        self._schedule_change_driven_pull("reconnect", delay_ms=120)
        logger.debug("Realtime transport connected; cursor reconciliation scheduled.")

    def _run_delta_pull_worker(self) -> None:
        scheduler = getattr(self, "_realtime_pull_scheduler", None)
        if scheduler is None:
            return
        if not self.cloud_sync_runtime_service.connected():
            scheduler.finish()
            return
        runtime_generation = self._runtime_generation_value()
        pull_status = {"synchronized": False}

        def _on_delta_payload(payload) -> None:
            data = dict(payload or {}) if isinstance(payload, dict) else {}
            if self._domains_from_cloud_payload(data):
                self._set_automatic_sync_feedback(
                    "applying", operation_key="cloud_snapshot:pull", present=True
                )
            # ``load_change_payload`` intentionally converts transient transport
            # exceptions into an explicit payload so the rest of the runtime can
            # stay responsive.  Treat that result as an incomplete pull, not as
            # a completed reconciliation: schedule the bounded automatic retry.
            pull_status["synchronized"] = bool(data.get("online", True)) and not bool(
                data.get("sync_error")
            )
            if pull_status["synchronized"]:
                logger.info(
                    "SYNC_AUTOMATIC_PULL=PASS next_cursor=%s events=%s",
                    data.get("next_cursor", ""),
                    len(list(data.get("changes") or [])),
                )
            else:
                logger.warning(
                    "SYNC_AUTOMATIC_PULL=RETRY sync_error=%s online=%s",
                    str(data.get("sync_error") or "unknown"),
                    bool(data.get("online", False)),
                )
            self._on_delta_pull_result(data)

        def _guarded_delta_pull_finished() -> None:
            replay_needed = scheduler.finish()
            if not self._runtime_generation_is_current(runtime_generation):
                return
            if not pull_status["synchronized"] and self.cloud_sync_runtime_service.connected():
                # The retry is timer-driven and uses the same single-flight
                # scheduler; it neither blocks the GUI nor requires a manual
                # refresh, navigation, or a new SSE event.
                self._schedule_change_driven_pull("realtime_retry", delay_ms=5_000)
                return
            if replay_needed and self.cloud_sync_runtime_service.connected():
                self._schedule_change_driven_pull("realtime_followup", delay_ms=0)

        worker = self._start_cloud_snapshot_worker(
            on_result=_on_delta_payload,
            on_finished=_guarded_delta_pull_finished,
            warning_message="change-driven server pull failed",
            runtime_generation=runtime_generation,
        )
        if worker is None:
            # Duplicate/closed worker registries can return None.  Finish is
            # idempotent, so this is safe even when the duplicate path already
            # queued the same completion callback.
            _guarded_delta_pull_finished()

    def _on_delta_pull_result(self, payload) -> None:
        self._apply_cloud_payload_result(
            payload,
            event_reason="change_driven_pull",
            log_context="CloudRealtimeControllerMixin._on_delta_pull_result",
        )

    def _schedule_change_driven_pull(self, domain_text: str, delay_ms: int = 650) -> None:
        if not self.cloud_sync_runtime_service.connected():
            return
        try:
            scheduler = getattr(self, "_realtime_pull_scheduler", None)
            if scheduler is None:
                return
            timer = getattr(self, "_change_driven_sync_timer", None)
            if timer is None:
                timer = QTimer(self)
                timer.setSingleShot(True)
                timer.timeout.connect(self._run_change_driven_pull)
                self._change_driven_sync_timer = timer
            now_ms = int(QDateTime.currentMSecsSinceEpoch())
            timer_active = bool(timer.isActive())
            timer_remaining_ms = int(timer.remainingTime()) if timer_active else -1
            decision = scheduler.offer(
                domain_text,
                now_ms=now_ms,
                requested_delay_ms=max(0, int(delay_ms)),
                timer_active=timer_active,
                timer_remaining_ms=timer_remaining_ms,
            )
            # Do not restart an active timer unless the new request would run
            # earlier. This prevents sustained SSE traffic from starving sync.
            if decision.schedule:
                timer.start(decision.delay_ms)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Change-driven server pull scheduling failed", exc_info=True)

    def _run_change_driven_pull(self) -> None:
        scheduler = getattr(self, "_realtime_pull_scheduler", None)
        if scheduler is None:
            return
        if not self.cloud_sync_runtime_service.connected():
            scheduler.reset()
            return
        try:
            now_ms = int(QDateTime.currentMSecsSinceEpoch())
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Change-driven sync clock read failed", exc_info=True)
            return
        if not scheduler.begin(now_ms):
            return
        self._run_delta_pull_worker()

    def _on_runtime_item_mutation(self, domain: str, payload=None) -> None:
        domain_text = str(domain or "").strip().lower()
        if domain_text not in {"tracking", "usage", "admin"}:
            return

        # Expiry monitoring is a device-local responsibility. A tracked-product
        # mutation must be evaluated even while the API is unavailable; the
        # in-process tracking store / persisted cache remains the monitoring
        # source and Windows notifications must not depend on a cloud round trip.
        if domain_text == "tracking":
            try:
                self._schedule_runtime_callback(0, self.monitoring.check_now, require_session=True)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Immediate local expiry check scheduling failed", exc_info=True)

        if not self.cloud_sync_runtime_service.connected():
            return
        try:
            self._safe_invalidate_cloud_cache()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Immediate sync cache invalidation skipped", exc_info=True)
        self._schedule_change_driven_pull(domain_text, delay_ms=650)
