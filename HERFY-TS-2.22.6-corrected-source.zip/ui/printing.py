from __future__ import annotations

import logging
import math
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from datetime import datetime

from PySide6.QtCore import QMarginsF, QRect, Qt
from PySide6.QtGui import QColor, QFont, QPageLayout, QPageSize, QPainter, QPen, QPixmap
from PySide6.QtPrintSupport import QPrinter, QPrintPreviewDialog
from PySide6.QtWidgets import QToolBar, QToolButton

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.models import business_now, format_plain_number
from core.settings import _, resource_path
from ui.dialogs import apply_popup_contract
from ui.widgets import qt_file_image_loading_enabled


@dataclass(frozen=True, slots=True)
class UsagePrintContext:
    title: str
    generated_at_text: str
    branch_text: str
    row_count: int
    headers: tuple[str, ...]
    rows: tuple[tuple[str, ...], ...]
    numeric_columns: tuple[int, ...]
    column_ratios: tuple[int, ...]
    logo_path: str
    prepared_by_text: str = ""


logger = logging.getLogger(__name__)


class UsagePrintPreviewDialog(QPrintPreviewDialog):
    """Print preview that always has a non-printing exit path.

    Qt's stock print-preview chrome differs between Windows versions and printer
    drivers.  HERFY-TS therefore guarantees that Escape and the title-bar close
    action reject the preview instead of requiring the user to print first.
    """

    def keyPressEvent(self, event):  # noqa: N802 - Qt API
        if event is not None and event.key() == Qt.Key_Escape:
            self.reject()
            return
        super().keyPressEvent(event)


class UsagePrintMetricsMixin:
    def _fit_print_fonts(
        self, *, column_widths: Sequence[int], dpi: int
    ) -> tuple[QFont, QFont, QFont, int, int, int, int]:
        # Keep printed headings clearly readable in preview and on paper.
        header_pt = 10
        cell_pt = 8
        if column_widths and min(column_widths) >= int(round(12 * dpi / 25.4)):
            header_pt = 10
            cell_pt = 8
        if column_widths and min(column_widths) < int(round(9 * dpi / 25.4)):
            header_pt = 9
            cell_pt = 7
        meta_font = QFont("Segoe UI", 8)
        header_font = QFont("Segoe UI", header_pt)
        header_font.setBold(True)
        cell_font = QFont("Segoe UI", cell_pt)
        # Printer geometry is expressed in physical units so it scales
        # proportionally at 300/600/1200 DPI without borrowing screen metrics.
        header_h = int(round(16 * dpi / 25.4))
        row_h = int(round(7.0 * dpi / 25.4))
        footer_h = int(round(7 * dpi / 25.4))
        cell_pad_x = max(2, int(round(0.85 * dpi / 25.4)))
        return (
            meta_font,
            header_font,
            cell_font,
            header_h,
            row_h,
            footer_h,
            cell_pad_x,
        )

    def _column_widths_for_a4(
        self,
        usable_width: int,
        ratios: Sequence[int],
        column_count: int,
        headers: Sequence[str],
        dpi: int,
    ) -> tuple[int, ...]:
        """Calculate all Usage columns for A4 portrait without hiding columns."""
        if column_count <= 0:
            return tuple()
        default_ratios = (16, 38, 9, 10, 8, 14, 6, 13)
        if not ratios or len(ratios) != column_count:
            ratios = default_ratios[:column_count] or tuple([1] * column_count)
        ratios = tuple((max(1, int(value)) for value in ratios))
        min_mm = (19, 48, 12, 13, 10, 18, 9, 15)
        min_widths = [int(round(mm * dpi / 25.4)) for mm in min_mm[:column_count]]
        if len(min_widths) < column_count:
            min_widths.extend([int(round(12 * dpi / 25.4))] * (column_count - len(min_widths)))
        min_total = sum(min_widths)
        if min_total >= usable_width:
            scale = usable_width / max(1, min_total)
            widths = [max(1, int(width * scale)) for width in min_widths]
        else:
            remaining = usable_width - min_total
            total_ratio = max(1, sum(ratios))
            widths = [
                min_widths[index] + int(remaining * (ratios[index] / total_ratio))
                for index in range(column_count)
            ]
        drift = usable_width - sum(widths)
        if widths:
            widths[1 if len(widths) > 1 else 0] += drift
        return tuple((max(1, int(width)) for width in widths))

    @staticmethod
    def _column_alignment(column: int) -> int:
        # Printed cells follow the on-screen table: only Product Name is LTR
        # and left aligned; material, quantities, UOM and usage are centered.
        if column == 1:
            return Qt.AlignVCenter | Qt.AlignLeft | Qt.AlignAbsolute
        return Qt.AlignCenter

    @staticmethod
    def _normalize_header(label: str) -> str:
        value = str(label or "").strip()
        lowered = value.lower()
        if lowered == "begining":
            return _("Beginning")
        if lowered == "available stock":
            return _("Available")
        if lowered in {"available qty", "available qty (enter)"}:
            return _("Available Stock")
        if lowered == "actual consumption":
            return _("Actual Usage")
        return value

    @staticmethod
    def _format_cell(*, column: int, display_value, raw_value, numeric_columns: set[int]) -> str:
        if column in numeric_columns:
            if display_value in (None, "") and raw_value in (None, ""):
                return ""
            if raw_value is None and display_value not in (None, ""):
                return str(display_value)
            try:
                return format_plain_number(raw_value if raw_value is not None else 0.0)
            except SERVICE_OPERATION_EXCEPTIONS:
                return str(display_value or "")
        return str(display_value or "")


class UsagePrintPrinterMixin:
    def _configure_a4_portrait_printer(
        self, printer: QPrinter, *, doc_name: str = "", landscape: bool = False
    ) -> None:
        """Configure printing using the Qt6 public page-layout API only.

        The application uses the native PySide6 surface;
        page setup therefore uses QPageLayout/QPageSize exclusively.
        """
        printer.setFullPage(False)
        if int(printer.resolution() or 0) < 300:
            printer.setResolution(300)
        orientation = QPageLayout.Landscape if landscape else QPageLayout.Portrait
        layout = QPageLayout(
            QPageSize(QPageSize.A4),
            orientation,
            QMarginsF(
                self.PAGE_MARGIN_MM,
                self.PAGE_MARGIN_MM,
                self.PAGE_MARGIN_MM,
                self.PAGE_MARGIN_MM,
            ),
            QPageLayout.Millimeter,
        )
        printer.setPageLayout(layout)
        printer.setDocName(str(doc_name or _("Herfy Monthly Usage")))

    @staticmethod
    def _page_rect_pixels(printer: QPrinter):
        """Return the printable page rectangle in device pixels on Qt6/PySide6."""
        resolution = max(72, int(printer.resolution() or 0))
        return printer.pageLayout().paintRectPixels(resolution)

    def _portrait_page_rect(self, printer: QPrinter) -> tuple[int, int, bool]:
        """Use the configured A4 portrait canvas without rotating its text."""
        page_rect = self._page_rect_pixels(printer)
        page_w = int(page_rect.width())
        page_h = int(page_rect.height())
        return (page_w, page_h, False)

    @staticmethod
    def _restore_portrait_painter(painter: QPainter, rotated: bool) -> None:
        if rotated:
            painter.restore()


class UsagePrintRenderMixin:
    @staticmethod
    def _masthead_height(*, page_number: int, dpi: int) -> int:
        """Reserve a full identity block once, then a compact continuation caption."""
        millimetres = 22.0 if int(page_number) == 0 else 10.0
        return int(round(millimetres * max(72, int(dpi)) / 25.4))

    def _should_use_landscape(self, printer, context: UsagePrintContext) -> bool:
        """Use landscape only when portrait would shrink a required column below 9 mm."""
        dpi = max(72, int(printer.resolution() or self.PRINT_DPI_FALLBACK))
        page_width = max(1, int(self._page_rect_pixels(printer).width()))
        margin = int(round(self.PAGE_MARGIN_MM * dpi / 25.4))
        widths = self._column_widths_for_a4(
            max(1, page_width - margin * 2),
            context.column_ratios,
            len(context.headers),
            context.headers,
            dpi,
        )
        minimum_legible_width = int(round(9.0 * dpi / 25.4))
        return bool(widths and min(widths) < minimum_legible_width)

    @staticmethod
    def _format_generated_date(value: datetime | None = None) -> str:
        stamp = value or business_now()
        return stamp.strftime("%d-%m-%Y")

    def build_context(
        self,
        *,
        model,
        headers: Sequence[str],
        numeric_columns: Iterable[int] = (),
        column_ratios: Sequence[int] | None = None,
        title: str | None = None,
        branch_text: str = "",
        logo_path: str | None = None,
        prepared_by_text: str = "",
    ) -> UsagePrintContext:
        numeric_set = {int(value) for value in numeric_columns}
        normalized_headers = tuple((self._normalize_header(label) for label in headers))
        rows: list[tuple[str, ...]] = []
        row_count = int(model.rowCount())
        column_count = int(model.columnCount())
        ratios = tuple((int(value) for value in column_ratios or [1] * max(1, column_count)))
        for row in range(row_count):
            rendered_row: list[str] = []
            for column in range(column_count):
                index = model.index(row, column)
                display_value = model.data(index, Qt.DisplayRole)
                raw_value = model.data(index, Qt.UserRole)
                rendered_row.append(
                    self._format_cell(
                        column=column,
                        display_value=display_value,
                        raw_value=raw_value,
                        numeric_columns=numeric_set,
                    )
                )
            rows.append(tuple(rendered_row))
        return UsagePrintContext(
            title=str(title or "MONTHLY USAGE COUNT TOOLS"),
            generated_at_text=self._format_generated_date(),
            branch_text=str(branch_text or "").strip(),
            row_count=row_count,
            headers=normalized_headers,
            rows=tuple(rows),
            numeric_columns=tuple(sorted(numeric_set)),
            column_ratios=ratios,
            logo_path=str(logo_path or resource_path("resources", "images", "logo.png")),
            prepared_by_text=str(prepared_by_text or "").strip(),
        )

    def show_preview(self, parent, *, context: UsagePrintContext) -> bool:
        if context.row_count <= 0:
            return False
        printer = QPrinter(QPrinter.HighResolution)
        self._configure_a4_portrait_printer(printer, doc_name=context.title)
        use_landscape = self._should_use_landscape(printer, context)
        if use_landscape:
            self._configure_a4_portrait_printer(printer, doc_name=context.title, landscape=True)
        preview = UsagePrintPreviewDialog(printer, parent)
        preview.setLayoutDirection(Qt.LeftToRight)
        try:
            if hasattr(preview, "printer"):
                self._configure_a4_portrait_printer(
                    preview.printer(), doc_name=context.title, landscape=use_landscape
                )
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Usage print: preview printer setup failed", exc_info=True)
        apply_popup_contract(
            preview,
            object_name="UsagePrintPreviewDialog",
            modal=True,
            size_grip=True,
            width_ratio=0.94,
            height_ratio=0.9,
            min_width=640,
            min_height=480,
            max_width=None,
            max_height=None,
        )
        preview.setWindowTitle(_("Herfy Monthly Usage - Print Preview"))
        preview.setWindowFlag(Qt.WindowSystemMenuHint, True)
        preview.setWindowFlag(Qt.WindowCloseButtonHint, True)

        # Keep an explicit, visible close control inside the preview itself.
        # Rejecting the dialog only closes the preview; it never invokes print.
        toolbars = preview.findChildren(QToolBar)
        if toolbars:
            toolbar = toolbars[0]
            toolbar.addSeparator()
            close_button = QToolButton(toolbar)
            close_button.setObjectName("UsagePrintPreviewCloseButton")
            close_button.setText(_("Close Preview"))
            close_button.setToolTip(_("Close preview without printing."))
            close_button.setToolButtonStyle(Qt.ToolButtonTextOnly)
            close_button.setAutoRaise(False)
            close_button.setFocusPolicy(Qt.StrongFocus)
            close_button.clicked.connect(preview.reject)
            toolbar.addWidget(close_button)
            preview._herfy_close_button = close_button

        def _paint_requested(device):
            try:
                self._configure_a4_portrait_printer(
                    device, doc_name=context.title, landscape=use_landscape
                )
                self.render_report(device, context=context)
            except Exception:
                logger.exception("Usage print: paintRequested render failed")

        preview.paintRequested.connect(_paint_requested)
        preview.exec()
        return True

    def render_report(self, printer: QPrinter, *, context: UsagePrintContext) -> None:
        painter = QPainter(printer)
        if not painter.isActive():
            return
        try:
            painter.setRenderHint(QPainter.Antialiasing, True)
            painter.setRenderHint(QPainter.TextAntialiasing, True)
            self._render_document(painter, printer, context)
        finally:
            painter.end()

    def _render_document(
        self, painter: QPainter, printer: QPrinter, context: UsagePrintContext
    ) -> None:
        dpi = max(72, int(printer.resolution() or self.PRINT_DPI_FALLBACK))

        def mm(value: float) -> int:
            return int(round(float(value) * dpi / 25.4))

        page_w, page_h, rotated = self._portrait_page_rect(printer)
        raw_page_h = int(self._page_rect_pixels(printer).height())
        left = mm(self.PAGE_MARGIN_MM)
        top = mm(self.PAGE_MARGIN_MM)
        right = mm(self.PAGE_MARGIN_MM)
        bottom = mm(self.PAGE_MARGIN_MM)
        section_gap = mm(2.5)
        usable_w = max(mm(80), page_w - left - right)
        usable_h = max(mm(80), page_h - top - bottom)
        column_widths = self._column_widths_for_a4(
            usable_w, context.column_ratios, len(context.headers), context.headers, dpi
        )
        meta_font, header_font, cell_font, header_h, row_h, footer_h, cell_pad_x = (
            self._fit_print_fonts(column_widths=column_widths, dpi=dpi)
        )
        small_font = QFont("Segoe UI", max(7, meta_font.pointSize() - 1))
        first_body_h = (
            usable_h - footer_h - self._masthead_height(page_number=0, dpi=dpi) - section_gap
        )
        continuation_body_h = (
            usable_h - footer_h - self._masthead_height(page_number=1, dpi=dpi) - section_gap
        )
        first_rows_per_page = max(1, int((first_body_h - header_h) // row_h))
        continuation_rows_per_page = max(1, int((continuation_body_h - header_h) // row_h))
        remaining_rows = max(0, context.row_count - first_rows_per_page)
        total_pages = 1 + math.ceil(remaining_rows / continuation_rows_per_page)
        current_row = 0
        total_rows = max(1, context.row_count)
        for page_number in range(total_pages):
            if page_number > 0:
                printer.newPage()
            if rotated:
                painter.save()
                painter.translate(raw_page_h, 0)
                painter.rotate(90)
            try:
                y = top
                header_block_h = self._masthead_height(page_number=page_number, dpi=dpi)
                self._draw_top_block(
                    painter,
                    left=left,
                    y=y,
                    width=usable_w,
                    height=header_block_h,
                    title_text=context.title,
                    branch_text=context.branch_text,
                    generated_at_text=context.generated_at_text,
                    prepared_by_text=context.prepared_by_text,
                    logo_path=context.logo_path,
                    meta_font=meta_font,
                    small_font=small_font,
                    compact=page_number > 0,
                )
                y += header_block_h + section_gap
                self._draw_header_row(
                    painter,
                    left=left,
                    y=y,
                    widths=column_widths,
                    height=header_h,
                    headers=context.headers,
                    font=header_font,
                    cell_pad_x=cell_pad_x,
                )
                y += header_h
                body_limit = top + usable_h - footer_h
                page_row_index = 0
                rows_this_page = (
                    first_rows_per_page if page_number == 0 else continuation_rows_per_page
                )
                while (
                    current_row < total_rows
                    and page_row_index < rows_this_page
                    and (y + row_h <= body_limit)
                ):
                    row_values = (
                        context.rows[current_row]
                        if current_row < context.row_count
                        else tuple(("" for _ in context.headers))
                    )
                    self._draw_data_row(
                        painter,
                        left=left,
                        y=y,
                        widths=column_widths,
                        height=row_h,
                        values=row_values,
                        numeric_columns=set(context.numeric_columns),
                        font=cell_font,
                        cell_pad_x=cell_pad_x,
                        shade=page_row_index % 2 == 1,
                    )
                    y += row_h
                    current_row += 1
                    page_row_index += 1
                painter.setPen(self.MUTED_TEXT)
                painter.setFont(meta_font)
                footer_text = _("Page {page} of {total}").format(
                    page=page_number + 1, total=total_pages
                )
                footer_rect = QRect(left, top + usable_h - footer_h, usable_w, footer_h)
                painter.drawText(footer_rect, Qt.AlignRight | Qt.AlignVCenter, footer_text)
            finally:
                self._restore_portrait_painter(painter, rotated)

    def _draw_top_block(
        self,
        painter: QPainter,
        *,
        left: int,
        y: int,
        width: int,
        height: int,
        title_text: str,
        branch_text: str,
        generated_at_text: str,
        prepared_by_text: str,
        logo_path: str,
        meta_font: QFont,
        small_font: QFont,
        compact: bool = False,
    ) -> None:
        """Draw a balanced report masthead: logo, title, store and date."""
        painter.save()
        try:
            gap = max(6, int(height * 0.08))
            if compact:
                continuation_font = QFont("Segoe UI", max(9, meta_font.pointSize() + 2))
                continuation_font.setBold(True)
                painter.setFont(continuation_font)
                painter.setPen(self.TITLE_COLOR)
                painter.drawText(
                    QRect(left, y, width, height - max(2, gap)),
                    Qt.AlignCenter,
                    f"{str(title_text or 'MONTHLY USAGE COUNT TOOLS')} — {generated_at_text}",
                )
                line_y = y + height - 1
                painter.setPen(QPen(self.ACCENT_COLOR, max(1, int(height * 0.04))))
                painter.drawLine(left, line_y, left + width, line_y)
                return
            logo_w = min(int(width * 0.16), max(1, int(height * 1.9)))
            meta_w = min(int(width * 0.34), max(1, int(height * 4.2)))
            title_w = max(1, width - logo_w - meta_w - (gap * 2))

            logo_rect = QRect(left, y, logo_w, height - max(2, gap))
            title_rect = QRect(left + logo_w + gap, y, title_w, height - max(2, gap))
            info_rect = QRect(
                title_rect.right() + gap,
                y,
                meta_w,
                height - max(2, gap),
            )

            if logo_path and qt_file_image_loading_enabled():
                pix = QPixmap(logo_path)
                if not pix.isNull():
                    max_logo_h = max(24, int(logo_rect.height() * 0.82))
                    max_logo_w = max(36, int(logo_rect.width() * 0.92))
                    scaled = pix.scaled(
                        max_logo_w,
                        max_logo_h,
                        Qt.KeepAspectRatio,
                        Qt.SmoothTransformation,
                    )
                    target = QRect(
                        logo_rect.x(),
                        logo_rect.y() + max(0, (logo_rect.height() - scaled.height()) // 2),
                        scaled.width(),
                        scaled.height(),
                    )
                    painter.drawPixmap(target, scaled)

            title_font = QFont("Segoe UI", max(12, meta_font.pointSize() + 5))
            title_font.setBold(True)
            painter.setFont(title_font)
            painter.setPen(self.TITLE_COLOR)
            painter.drawText(
                title_rect,
                Qt.AlignCenter,
                str(title_text or "MONTHLY USAGE COUNT TOOLS"),
            )

            user_font = QFont(meta_font)
            user_font.setBold(True)
            user_name = str(prepared_by_text or "").strip() or _("Unknown user")
            user_line = _("USER : {user}").format(user=user_name)
            line_height = max(1, info_rect.height() // 2)

            painter.setPen(self.ACCENT_COLOR)
            painter.setFont(user_font)
            painter.drawText(
                QRect(info_rect.x(), info_rect.y(), info_rect.width(), line_height),
                Qt.AlignRight | Qt.AlignVCenter,
                user_line,
            )

            painter.setPen(self.MUTED_TEXT)
            painter.setFont(small_font)
            date_line = _("Date: {date}").format(date=generated_at_text)
            painter.drawText(
                QRect(
                    info_rect.x(),
                    info_rect.y() + line_height,
                    info_rect.width(),
                    info_rect.height() - line_height,
                ),
                Qt.AlignRight | Qt.AlignVCenter,
                date_line,
            )

            line_y = y + height - 1
            painter.setPen(QPen(self.ACCENT_COLOR, max(1, int(height * 0.025))))
            painter.drawLine(left, line_y, left + width, line_y)
        finally:
            painter.restore()

    def _draw_header_row(
        self,
        painter: QPainter,
        *,
        left: int,
        y: int,
        widths: Sequence[int],
        height: int,
        headers: Sequence[str],
        font: QFont,
        cell_pad_x: int,
    ) -> None:
        x = left
        painter.save()
        painter.setFont(font)
        for column, (header, width) in enumerate(zip(headers, widths, strict=False)):
            header_text = self._print_header_text(column, str(header or ""))
            header_text = {
                "Material No.": "Material\nNo.",
                "Material Number": "Material\nNo.",
                "Available Stock": "Available\nStock",
                "Actual Usage": "Actual\nUsage",
                "Product Name": "Product Name",
            }.get(header_text, header_text)
            rect = QRect(x, y, width, height)
            painter.fillRect(rect, self.HEADER_BG)
            painter.setPen(QPen(self.GRID_COLOR, 0))
            painter.drawRect(rect)
            painter.setPen(QPen(self.TITLE_COLOR, 1))
            painter.drawLine(rect.bottomLeft(), rect.bottomRight())
            painter.setPen(self.HEADER_TEXT)

            # Let QPainter perform wrapping and baseline placement on the actual
            # printer/preview paint device.  Device-agnostic screen metrics can
            # place high-DPI printer text too
            # low and visually clip the top of every header label.
            vertical_pad = max(4, int(height * 0.08))
            text_rect = rect.adjusted(
                cell_pad_x + 2,
                vertical_pad,
                -cell_pad_x - 2,
                -vertical_pad,
            )
            painter.drawText(
                text_rect,
                Qt.AlignHCenter | Qt.AlignVCenter | Qt.TextWordWrap,
                header_text,
            )
            x += width
        painter.restore()

    def _draw_data_row(
        self,
        painter: QPainter,
        *,
        left: int,
        y: int,
        widths: Sequence[int],
        height: int,
        values: Sequence[str],
        numeric_columns: set[int],
        font: QFont,
        cell_pad_x: int,
        shade: bool,
    ) -> None:
        x = left
        painter.save()
        painter.setFont(font)
        metrics = painter.fontMetrics()
        for column, width in enumerate(widths):
            rect = QRect(x, y, width, height)
            if shade:
                painter.fillRect(rect, self.ALT_ROW_BG)
            painter.setPen(QPen(self.GRID_COLOR, 0))
            painter.drawRect(rect)
            painter.setPen(self.ROW_TEXT)
            text_rect = rect.adjusted(cell_pad_x, 0, -cell_pad_x, 0)
            raw_text = str(values[column] if column < len(values) else "")
            text = metrics.elidedText(raw_text, Qt.ElideRight, max(10, text_rect.width()))
            painter.drawText(text_rect, self._column_alignment(column), text)
            x += width
        painter.restore()

    def _print_header_text(self, column: int, header: str) -> str:
        if 0 <= int(column) < len(self._HEADER_FALLBACKS):
            return _(self._HEADER_FALLBACKS[int(column)])
        return self._normalize_header(header)


class UsagePrintService(UsagePrintPrinterMixin, UsagePrintMetricsMixin, UsagePrintRenderMixin):
    TITLE_COLOR = QColor("#0F172A")
    MUTED_TEXT = QColor("#64748B")
    GRID_COLOR = QColor("#64748B")
    HEADER_BG = QColor("#EFF6FF")
    HEADER_TEXT = QColor("#111827")
    ALT_ROW_BG = QColor("#F8FAFC")
    ROW_TEXT = QColor("#1E293B")
    ACCENT_COLOR = QColor("#2563EB")
    PAGE_MARGIN_MM = 5.0
    PRINT_DPI_FALLBACK = 300
    _HEADER_FALLBACKS = (
        "Material\nNo.",
        "Product Name",
        "Receipts",
        "Opening",
        "Total",
        "Available\nStock",
        "UOM",
        "Actual\nUsage",
    )
