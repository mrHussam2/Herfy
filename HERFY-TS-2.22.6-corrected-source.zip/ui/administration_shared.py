"""Shared Administration presentation contracts."""

from __future__ import annotations


from ui.dialogs import show_question_message
from core.settings import _

# Qt's documented maximum widget extent; PySide6 does not export QT_WIDGET_SIZE_MAX.
QT_WIDGET_SIZE_MAX = 16777215


class _ActiveEditorDirtyMixin:
    """Own the shared dirty-state contract for a section with one editor pane."""

    def is_dirty(self) -> bool:
        return self.workspace_stack.currentWidget() is self.editor and self.editor.is_dirty()

    def _confirm_editor_discard(self, *, dirty: bool, message: str) -> bool:
        if not dirty:
            return True
        answer = show_question_message(
            self,
            _("Unsaved changes"),
            message
        )
        return answer
