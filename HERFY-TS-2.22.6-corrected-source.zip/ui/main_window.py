from __future__ import annotations

import logging

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import QApplication, QLabel, QMainWindow, QProgressBar

from core.errors import STATE_OPERATION_EXCEPTIONS, UI_OPERATION_EXCEPTIONS
from core.i18n import is_rtl
from core.settings import APP_DISPLAY_NAME, _, load_translations
from services.monitoring_coordinator import MonitoringCoordinator
from ui.login import LoginPage
from ui.main_window_access import MainWindowAccessNavigationMixin
from ui.main_window_actions import (
    AppLifecycleControllerMixin,
    MainWindowActionSupportMixin,
    MainWindowDialogActionsMixin,
    MainWindowMenuBuilderMixin,
    MainWindowRouteNavigationMixin,
)
from ui.main_window_cloud import (
    CloudPayloadResultControllerMixin,
    CloudRealtimeControllerMixin,
    CloudSessionControllerMixin,
    CloudSnapshotControllerMixin,
    CloudStatusControllerMixin,
)
from ui.main_window_notifications import MainWindowNotificationsMixin, MainWindowTrayMixin
from ui.main_window_session import (
    MainWindowUpdatesMixin,
    SessionAuthControllerMixin,
    SessionRestoreControllerMixin,
)
from ui.main_window_shell import MainWindowContentPagesMixin, MainWindowShellLayoutMixin
from ui.theme import (
    apply_device_properties,
    apply_initial_window_geometry,
    apply_responsive_shell_metrics,
    apply_window_constraints,
    configure_transition_progress,
    make_scaler,
)
from ui.widgets import apply_window_icon
from version import __version__ as APP_VERSION

logger = logging.getLogger(__name__)


class HerfyMainWindow(
    MainWindowUpdatesMixin,
    CloudSessionControllerMixin,
    CloudPayloadResultControllerMixin,
    CloudRealtimeControllerMixin,
    CloudSnapshotControllerMixin,
    CloudStatusControllerMixin,
    SessionAuthControllerMixin,
    SessionRestoreControllerMixin,
    AppLifecycleControllerMixin,
    MainWindowShellLayoutMixin,
    MainWindowContentPagesMixin,
    MainWindowMenuBuilderMixin,
    MainWindowRouteNavigationMixin,
    MainWindowAccessNavigationMixin,
    MainWindowTrayMixin,
    MainWindowNotificationsMixin,
    MainWindowActionSupportMixin,
    MainWindowDialogActionsMixin,
    QMainWindow,
):
    cloud_changed = Signal()
    cloud_state_changed = Signal(bool)
    realtime_change_received = Signal(int)
    realtime_state_received = Signal(bool)

    @property
    def app_state(self):
        return self.runtime.app_state

    def __init__(self, runtime, *, worker_scopes, presentation_factory):
        super().__init__()
        if runtime is None:
            raise RuntimeError("HerfyMainWindow requires composed UI runtime dependencies.")
        if worker_scopes is None:
            raise RuntimeError("HerfyMainWindow requires composed Qt worker scopes.")
        if presentation_factory is None:
            raise RuntimeError("HerfyMainWindow requires composed Qt presentation factory.")
        self.runtime = runtime
        self.worker_scopes = worker_scopes
        self.presentation_factory = presentation_factory
        self.session_persistence = runtime.session_persistence
        self.authentication_service = runtime.authentication_service
        self.account_security_service = runtime.account_security_service
        self.session_runtime_service = runtime.session_runtime_service
        self.cloud_sync_runtime_service = runtime.cloud_sync_runtime_service
        self.server_runtime_service = runtime.server_runtime_service
        self.update_runtime_service = runtime.update_runtime_service
        self.startup_preferences_service = runtime.startup_preferences_service
        self.preferences = runtime.presentation_preferences
        self.tray_icon = None
        self._tray_menu = None
        self.S = make_scaler(QApplication.instance())
        self._configure_application_feedback()
        self._initialize_window_identity()
        self._initialize_shell()
        self._initialize_status_widgets()
        self._initialize_timers()
        self._initialize_runtime_components()
        self._bind_application_lifecycle()
        self._connect_runtime_signals()
        QTimer.singleShot(1100, self._show_pending_update_success)
        self._defer_startup_flow()

    def _defer_startup_flow(self) -> None:
        self._startup_flow_started = False

        def _run() -> None:
            if bool(getattr(self, "_startup_flow_started", False)):
                return
            self._startup_flow_started = True
            self._start_startup_flow()

        QTimer.singleShot(0, _run)

    def _initialize_window_identity(self) -> None:
        current_language = self.preferences.language()
        load_translations(current_language)
        self.setLayoutDirection(Qt.RightToLeft if is_rtl(current_language) else Qt.LeftToRight)
        self.setWindowTitle(_(APP_DISPLAY_NAME))
        self.setObjectName("MainWindow")
        self.setProperty("uiScope", "main")
        # Preserve a complete desktop hierarchy at the documented workspace
        # boundary.  Pages retain their established visual landmarks while
        # the window is resized; they do not switch to an unrelated compact
        # composition.
        apply_window_constraints(self)
        apply_window_icon(self)
        try:
            apply_device_properties(self, self.width(), QApplication.instance())
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "HerfyMainWindow._initialize_window_identity device-properties setup failed",
                exc_info=True,
            )

    def _initialize_shell(self) -> None:
        self.init_ui()
        apply_initial_window_geometry(self)
        # Geometry restoration/resizing changes the available page width.  Run
        # the responsive pass after that decision so sidebar and content
        # margins are correct before the shell's first paint.
        apply_responsive_shell_metrics(self)
        self.init_menus()
        self.init_tray_icon()
        self.login_page = LoginPage(
            self,
            worker_registry=self._new_worker_registry(),
            authentication_service=self.authentication_service,
            session_persistence=self.session_persistence,
        )
        self.content_stack.insertWidget(0, self.login_page)
        self.content_stack.setCurrentWidget(self.login_page)
        self._apply_logged_out_shell(reset_sidebar=True)

    def _create_network_indicator(self) -> QLabel | None:
        try:
            indicator = QLabel("")
            indicator.setObjectName("NetIndicator")
            indicator.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            # Connection state has one visual home: the signed-in identity card
            # at the bottom of the sidebar.
            self.sidebar_profile_status_layout.addWidget(indicator, 1)
            return indicator
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("HerfyMainWindow._create_network_indicator failed", exc_info=True)
            return None

    def _create_transition_progress(self) -> QProgressBar | None:
        try:
            progress = QProgressBar(self)
            progress.setObjectName("ShellTransitionProgress")
            progress.setRange(0, 0)
            progress.setTextVisible(False)
            progress.setAccessibleName(_("Loading workspace"))
            progress.setAccessibleDescription(_("Background work is in progress."))
            progress.setToolTip(_("Background work is in progress."))
            configure_transition_progress(self, progress)
            progress.hide()
            self.shell_status_widgets_layout.addWidget(progress)
            return progress
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("HerfyMainWindow._create_transition_progress failed", exc_info=True)
            return None

    def _initialize_status_widgets(self) -> None:
        self._cloud_online = False
        self.net_indicator = self._create_network_indicator()
        self.transition_progress = self._create_transition_progress()
        self._set_cloud_state(False)

    def _new_worker_registry(self):
        """Create one scoped worker registry through the Qt async composition adapter."""
        return self.worker_scopes.create()

    def _initialize_timers(self) -> None:
        self._worker_registry = self.worker_scopes.create()
        self.token_refresh_timer = QTimer(self)
        self.token_refresh_timer.setSingleShot(True)
        self.token_refresh_timer.timeout.connect(self.refresh_cloud_token)

    def _initialize_runtime_components(self) -> None:
        self.notifications_list = []
        self.unread_notifications = 0
        self._notifications_popup = None
        self.notifications_service = self.presentation_factory.create_notification_service(
            self, self.runtime.notification_runtime_service
        )
        self.monitoring = MonitoringCoordinator(
            self.runtime.monitoring_service,
            start_worker=self._start_monitoring_worker,
            publish_events=self.notifications_service.publish_alerts,
            reconcile_delivery=self.notifications_service.reconcile_delivery_state,
            parent=self,
        )
        self.runtime_scheduler = self.presentation_factory.create_runtime_scheduler(self)
        self.session_scope = self.runtime.session_scope
        self._closing_completely = False
        self._restore_session_running = False
        self._update_check_running = False
        self._latest_server_update_version = APP_VERSION
        self._update_status_summary = _("Up to date")
        self._cloud_change_running = False
        self._cloud_change_pending = False
        self._cloud_snapshot_pull_pending = False
        self._change_driven_sync_timer = None
        self._realtime_pull_scheduler = self.runtime.realtime_pull_scheduler
        self._ui_transition_depth = 0
        self._ui_transition_message = ""

    def _start_monitoring_worker(self, work, **kwargs):
        error_handler = kwargs.pop("on_error", None)
        return self._start_logged_worker(work, error_handler=error_handler, **kwargs)

    def _start_monitoring(self, *, restart: bool = True) -> None:
        self.monitoring.start(self._runtime_generation_value(), restart=restart)

    def _runtime_generation_value(self) -> int:
        return self.session_scope.generation()

    def _advance_runtime_generation(self) -> int:
        """Invalidate current runtime scope and cancel stale client workers.

        The server remains authoritative.  This client-side cancellation is
        cooperative and prevents old worker results from affecting a new user
        session or the UI after manual logout.
        """
        try:
            self._cancel_active_workers("runtime_generation_changed")
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Runtime scope worker cancellation failed", exc_info=True)
        return self.session_scope.advance()

    def _runtime_generation_is_current(self, token: int) -> bool:
        return self.session_scope.is_current(token)

    def _set_runtime_lifecycle_state(self, state: str) -> None:
        value = self.session_scope.set_state(state)
        logger.info("RUNTIME_LIFECYCLE=%s generation=%s", value, self._runtime_generation_value())

    def _runtime_lifecycle_is(self, *states: str) -> bool:
        return self.session_scope.is_state(*states)

    def _connect_runtime_signals(self) -> None:
        try:
            self.cloud_changed.connect(
                lambda: self.runtime_scheduler.schedule(
                    "cloud_changed", self._on_cloud_changed, 350
                )
            )
            self.cloud_state_changed.connect(self._set_cloud_state)
            self.realtime_change_received.connect(self._on_realtime_changed, Qt.QueuedConnection)
            self.realtime_state_received.connect(
                self._on_realtime_transport_state, Qt.QueuedConnection
            )
            self.app_state.item_updated.connect(self._on_runtime_item_mutation)
            self.app_state.item_deleted.connect(self._on_runtime_item_mutation)
            self.app_state.branch_changed.connect(self.on_current_branch_changed)
            app = QApplication.instance()
            if app is not None:
                app.applicationStateChanged.connect(self._on_application_state_changed)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("HerfyMainWindow._connect_runtime_signals failed", exc_info=True)

    def _apply_startup_preferences(self) -> None:
        startup_preferences_service = self.startup_preferences_service

        def _work(progress_callback=None):
            del progress_callback
            return bool(startup_preferences_service.apply())

        self._start_logged_worker(
            _work,
            warning_message="startup preference synchronization failed",
            operation_key="startup:preferences",
        )

    def _start_startup_flow(self) -> None:

        def _apply_preferences() -> None:
            self._apply_startup_preferences()

        def _apply_cached_contract() -> None:
            self._safe_apply_cached_startup_contract()

        def _refresh_contract() -> None:
            self._safe_refresh_startup_contract_async()

        def _restore_session() -> None:
            try:
                update_dialog = getattr(self, "_update_dialog", None)
                state_model = getattr(update_dialog, "state_model", None)
                state = getattr(state_model, "state", None)
                state_value = str(getattr(state, "value", state) or "").strip().lower()
                if state_value in {"downloading", "verifying", "preparing_install"}:
                    logger.info("SESSION_RESTORE_DEFERRED_FOR_UPDATE=PASS state=%s", state_value)
                    QTimer.singleShot(2500, _restore_session)
                    return
                if state_value == "handoff_to_installer":
                    logger.info("SESSION_RESTORE_SKIPPED_FOR_UPDATE_HANDOFF=PASS")
                    return
                self.try_restore_session_async()
            except STATE_OPERATION_EXCEPTIONS:
                logger.debug("HerfyMainWindow._start_startup_flow failed", exc_info=True)

        def _prelogin_update_check() -> None:
            try:
                # The UI is already visible.  This only checks signed metadata
                # in a worker; downloading begins exclusively after consent.
                self._maybe_check_updates(force=True)
            except STATE_OPERATION_EXCEPTIONS:
                logger.warning("PRELOGIN_UPDATE_CHECK_FAILED", exc_info=True)

        QTimer.singleShot(400, _apply_preferences)
        QTimer.singleShot(900, _prelogin_update_check)
        QTimer.singleShot(1800, _apply_cached_contract)
        QTimer.singleShot(6500, _restore_session)
        QTimer.singleShot(9000, _refresh_contract)


__all__ = ["HerfyMainWindow"]
