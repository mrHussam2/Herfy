from __future__ import annotations

import logging
import threading
import time
from contextlib import suppress

from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QApplication, QMenu, QPushButton, QWidget

from core.errors import UI_OPERATION_EXCEPTIONS
from core.i18n import normalize_language_code
from core.models import call_if_callable
from core.presentation import ShellUserScopePresenter
from core.settings import _, canonical_error_message
from ui.dialogs import show_question_message
from ui.theme import (
    apply_responsive_shell_metrics,
    save_window_placement,
    set_sidebar_administration_expanded,
    set_sidebar_administration_modules,
    set_sidebar_administration_route,
)
from ui.widgets import set_menu_action_icon, set_widget_visible

logger = logging.getLogger(__name__)


class MainWindowActionSupportMixin:
    def _refresh_tracking_page(self) -> None:
        page = getattr(self, "track_page", None)
        if page is not None:
            page.load_tracked_products(show_busy=False)

    def _run_ui_fallback(self, action, label: str) -> None:
        try:
            action()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin.%s fallback failed", label, exc_info=True)

    def _show_inline_status(
        self,
        title: str | None = None,
        message: str | None = None,
        *,
        level: str = "info",
        timeout_ms: int = 5000,
    ) -> None:
        """Show user feedback in the shell status area without a floating popup.

        This is used for routine client feedback such as permissions, missing
        cloud context, failed background actions, and successful maintenance
        operations.  Destructive confirmations still use explicit dialogs.
        """
        parts = [str(part or "").strip() for part in (title, message)]
        text = " — ".join((part for part in parts if part))
        if not text:
            return
        try:
            if hasattr(self, "_show_runtime_status_message"):
                self._show_runtime_status_message(text, int(timeout_ms or 0))
                return
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Inline shell status message failed", exc_info=True)
        log_fn = logger.warning if str(level).lower() in {"warning", "error"} else logger.info
        log_fn("%s", text)

    def _show_inline_error(self, title: str | None, message: str | None) -> None:
        """Show an error in the shell status area without a modal popup."""
        self._show_inline_status(title, message, level="error", timeout_ms=7000)

    def _show_inline_warning(self, title: str | None, message: str | None) -> None:
        """Show a warning in the shell status area without a modal popup."""
        self._show_inline_status(title, message, level="warning", timeout_ms=6500)

    def _show_inline_info(self, title: str | None, message: str | None) -> None:
        """Show an informational message in the shell status area without a modal popup."""
        self._show_inline_status(title, message, level="info", timeout_ms=5000)

    def _schedule_runtime_callback(
        self,
        delay_ms: int,
        callback,
        *,
        require_session: bool = False,
    ) -> bool:
        """Schedule a Qt callback scoped to the current runtime generation.

        QTimer.singleShot cannot be cancelled after creation.  Capturing the
        runtime generation prevents a callback from a previous login/authority
        scope from starting fresh work after logout or scope replacement.
        """
        if not callable(callback):
            return False
        runtime_generation = self._runtime_generation_value()

        def _guarded() -> None:
            if bool(getattr(self, "_closing_completely", False)):
                return
            if not self._runtime_generation_is_current(runtime_generation):
                return
            if require_session and not bool(getattr(self.app_state, "session", None)):
                return
            callback()

        try:
            QTimer.singleShot(max(0, int(delay_ms or 0)), _guarded)
            return True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Deferred runtime callback scheduling failed", exc_info=True)
            return False

    def _reset_async_running_flags(self) -> None:
        for flag_name in (
            "_restore_session_running",
            "_startup_contract_running",
            "_update_check_running",
            "_cloud_change_running",
            "_cloud_snapshot_pull_pending",
            "_token_refresh_running",
        ):
            with suppress(UI_OPERATION_EXCEPTIONS):
                setattr(self, flag_name, False)

    def _cancel_active_workers(self, reason: str = "runtime_generation_changed") -> None:
        """Request cooperative cancellation for shell workers from the old scope."""
        self._reset_async_running_flags()
        stop_reconciliation = getattr(self, "_stop_automatic_reconciliation", None)
        if callable(stop_reconciliation):
            stop_reconciliation()
        scheduler = getattr(self, "_realtime_pull_scheduler", None)
        if scheduler is not None:
            with suppress(UI_OPERATION_EXCEPTIONS):
                scheduler.reset()
        timer = getattr(self, "_change_driven_sync_timer", None)
        self._safe_stop_timer(timer)
        scopes = getattr(self, "worker_scopes", None)
        if scopes is not None:
            try:
                scopes.cancel_all()
                return
            except UI_OPERATION_EXCEPTIONS:
                logger.debug(
                    "Worker scope cancellation failed during %s",
                    reason,
                    exc_info=True,
                )
        registry = getattr(self, "_worker_registry", None)
        if registry is None:
            return
        try:
            registry.cancel_all()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "Worker registry cancellation failed during %s",
                reason,
                exc_info=True,
            )

    def _queue_session_persistence(self, action: str, payload: dict | None = None) -> None:
        """Serialize remembered-session file I/O away from the Qt thread.

        Save and clear share one operation key plus a process-local lock.  A logout
        clear therefore cannot race with an older token save that was already
        running when the runtime generation changed.  The latest intent wins and
        is replayed after the active worker releases the key.
        """
        registry = getattr(self, "_worker_registry", None)
        persistence = getattr(self, "session_persistence", None)
        if registry is None or persistence is None:
            return
        clean_action = str(action or "").strip().lower()
        if clean_action not in {"save", "clear"}:
            return
        intent = (clean_action, dict(payload or {}))
        self._session_persistence_pending = intent
        if registry.has_active_key("session:persistence"):
            return

        current = self._session_persistence_pending
        self._session_persistence_pending = None
        lock = getattr(self, "_session_persistence_lock", None)
        if lock is None:
            lock = threading.Lock()
            self._session_persistence_lock = lock

        def _work(progress_callback=None, cancel_callback=None):
            del progress_callback
            current_action, current_payload = current
            with lock:
                if callable(cancel_callback) and cancel_callback():
                    return None
                if current_action == "clear":
                    persistence.clear_session()
                    return None
                persistence.save_session(**current_payload)
                return None

        def _finished():
            pending = getattr(self, "_session_persistence_pending", None)
            if pending is not None:
                self._queue_session_persistence(pending[0], pending[1])

        worker = self._start_logged_worker(
            _work,
            on_finished=_finished,
            warning_message="Session persistence failed",
            operation_key="session:persistence",
        )
        if worker is None and getattr(self, "_session_persistence_pending", None) is None:
            self._session_persistence_pending = current

    def _clear_persistent_session_safely(self) -> None:
        self._queue_session_persistence("clear")

    def _apply_online_payload_state(
        self, payload: dict | None, *, show_status_feedback: bool = True
    ) -> None:
        try:
            data = payload if isinstance(payload, dict) else {}
            if "online" not in data:
                return
            online = bool(data.get("online"))
            if online:
                catalog_snapshot = (
                    data.get("stored_catalog_snapshot")
                    or data.get("stored_catalog")
                    or data.get("catalog_snapshot")
                )
                if isinstance(catalog_snapshot, dict):
                    self._apply_remote_catalog_to_local(catalog_snapshot)
            self._set_cloud_state(
                online,
                show_status_feedback=bool(show_status_feedback),
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._apply_online_payload_state fallback failed",
                exc_info=True,
            )

    def _safe_apply_cached_startup_contract(self) -> None:
        self._run_ui_fallback(
            self._apply_cached_startup_contract, "_safe_apply_cached_startup_contract"
        )

    def _safe_save_persistent_session(self) -> None:
        try:
            session = getattr(getattr(self, "app_state", None), "session", None)
            profile = getattr(getattr(self, "app_state", None), "current_user", None)
            remember = bool(getattr(self, "_remember_session", False))
            self._queue_session_persistence(
                "save",
                {
                    "session": session,
                    "profile": profile,
                    "remember": remember,
                    "saved_at": int(time.time()),
                },
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Async remembered-session persistence failed to queue", exc_info=True)

    def _safe_show_login(self) -> None:
        self._run_ui_fallback(self.show_login, "_safe_show_login")

    def _safe_accept_event(self, event) -> None:
        try:
            event.accept()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._safe_accept_event fallback failed", exc_info=True)

    def _safe_update_user_scope_ui(self) -> None:
        self._run_ui_fallback(self.update_user_scope_ui, "_safe_update_user_scope_ui")

    def _safe_refresh_startup_contract_async(self) -> None:
        self._run_ui_fallback(
            self.refresh_startup_contract_async, "_safe_refresh_startup_contract_async"
        )

    def _require_session_for_action(self) -> bool:
        if self.app_state.session:
            return True
        self._show_inline_info(_("Info"), _("Sign in required."))
        return False

    def _select_home_page(self) -> None:
        self._set_active_sidebar_route("home")
        self.show_home()

    def _safe_stop_timer(self, timer) -> None:
        try:
            if timer is not None:
                timer.stop()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._safe_stop_timer fallback failed", exc_info=True)

    def _set_top_bar_visible(self, visible: bool) -> None:
        set_widget_visible(getattr(self, "top_bar", None), visible)

    def _set_top_bar_session_actions_visible(self, visible: bool) -> None:
        """Show logged-in top-bar actions without adding hidden update/help controls."""
        for name in ("command_bar",):
            set_widget_visible(getattr(self, name, None), visible)

    def _safe_invalidate_cloud_cache(self) -> None:
        self._run_ui_fallback(
            self.runtime.tracking_service.invalidate_cache, "_safe_invalidate_cloud_cache"
        )

    def _configure_application_feedback(self) -> None:
        """UI feedback stays in the UI; persistence has no callback hooks."""
        return None

    def _start_worker(
        self,
        work,
        *,
        on_result=None,
        on_progress=None,
        on_error=None,
        on_finished=None,
        suppress_worker_traceback: bool = False,
        operation_key: str | None = None,
    ):
        key = str(operation_key or "").strip()
        registry = self._worker_registry
        try:
            runtime_generation = int(self._runtime_generation_value())
        except (AttributeError, RuntimeError, TypeError, ValueError):
            runtime_generation = None

        def _scope_is_current() -> bool:
            if runtime_generation is None:
                return True
            try:
                return bool(self._runtime_generation_is_current(runtime_generation))
            except (AttributeError, RuntimeError, TypeError, ValueError):
                return False

        return registry.start(
            work,
            on_result=on_result,
            on_progress=on_progress,
            on_error=on_error,
            on_finished=on_finished,
            operation_key=key,
            scope_checker=_scope_is_current,
            log_exceptions=not suppress_worker_traceback,
        )

    def _start_logged_worker(
        self,
        work,
        *,
        on_result=None,
        on_progress=None,
        on_finished=None,
        warning_message: str | None = None,
        error_handler=None,
        operation_key: str | None = None,
    ):
        if error_handler is None and warning_message:

            def _default_error_handler(message: str, prefix: str = warning_message):
                logger.warning("%s: %s", prefix, message)

            error_handler = _default_error_handler
        return self._start_worker(
            work,
            on_result=on_result,
            on_progress=on_progress,
            on_error=error_handler,
            on_finished=on_finished,
            suppress_worker_traceback=bool(error_handler or warning_message),
            operation_key=operation_key,
        )

    def _exec_modal_dialog(self, dialog, *, reload_tracked: bool = False) -> int:
        result = dialog.exec()
        if reload_tracked:
            QTimer.singleShot(
                350,
                lambda: (
                    self._refresh_tracking_page()
                    if getattr(getattr(self, "app_state", None), "session", None)
                    else None
                ),
            )
        self._sync_notifications_popup_direction()
        return result

    def _open_dialog(self, dialog_factory, *args, reload_tracked: bool = False, **kwargs) -> int:
        dialog = dialog_factory(*args, **kwargs)
        return self._exec_modal_dialog(dialog, reload_tracked=reload_tracked)

    def _cloud_service_available(self, *, warning: bool = False) -> bool:
        if self.cloud_sync_runtime_service.connected():
            return True
        if warning:
            self._show_inline_warning(_("Error"), _("Cloud service is not configured."))
        else:
            self._show_inline_info(_("Info"), _("Cloud service is not configured."))
        return False

    def _show_not_allowed(self, *, title: str = "Info", warning: bool = False) -> None:
        if warning:
            self._show_inline_warning(_(title), _("Not allowed"))
        else:
            self._show_inline_info(_(title), _("Not allowed"))

    def _require_cloud_action(self, *, warning: bool = False) -> bool:
        return self._cloud_service_available(warning=warning)

    def _can_change_own_password(self) -> bool:
        try:
            return bool(self._shell_access_state().can_change_own_password)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return False


logger = logging.getLogger(__name__)


class MainWindowDialogActionsMixin:
    """Canonical non-legacy secondary-window entry points."""

    # ---------------------------------------------------------------- Settings
    def open_settings(self, *, page: str | None = None):
        try:
            if not self._require_session_for_action():
                return
            self._hide_notifications_popup()
            window = getattr(self, "_settings_dialog", None)
            if window is None:
                from ui.settings import SettingsDialog

                window = SettingsDialog(
                    self.app_state,
                    self.runtime.settings_service,
                    self.runtime.presentation_preferences,
                    self.runtime.cloud_sync_runtime_service,
                    self.runtime.account_security_service,
                    self._new_worker_registry(),
                    self,
                )
                window.setAttribute(Qt.WA_DeleteOnClose, True)
                window.destroyed.connect(self._on_settings_closed)
                window.expiry_runtime_settings_applied.connect(
                    self._on_expiry_runtime_settings_applied
                )
                window.settings_saved.connect(self._on_settings_saved)
                window.password_changed.connect(self._on_optional_password_changed)
                self._settings_dialog = window
            if page:
                window.open_page(page)
            window.setLayoutDirection(self.layoutDirection())
            window.show()
            if window.isMinimized():
                window.showNormal()
            window.raise_()
            window.activateWindow()
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("open_settings failed")
            self._show_runtime_status_message(canonical_error_message("settings_open_failed"), 6000)

    def _on_settings_closed(self, *_args) -> None:
        self._settings_dialog = None

    def _on_settings_saved(self, _result: object = None) -> None:
        window = getattr(self, "_settings_dialog", None)
        try:
            self.apply_role_permissions()
            self.update_user_scope_ui()
            self.refresh_tray_icon()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Applying saved settings to shell failed", exc_info=True)
        if window is not None and bool(getattr(window, "language_restart_required", False)):
            restart_now = show_question_message(
                self,
                _("Restart required"),
                _(
                    "The language change has been saved. Restart HERFY-TS now to apply it everywhere?"
                ),
                default_no=False,
            )
            if restart_now:
                self._restart_after_language_change()

    def open_account_security(self) -> None:
        if not self._require_cloud_action(warning=True):
            return
        if not self._can_change_own_password():
            self._show_not_allowed(title="Permission", warning=True)
            return
        self.open_settings(page="account")

    def _on_optional_password_changed(self, _payload: object = None) -> None:
        # The current token still contains the previous account authority. A
        # clean re-authentication is the only canonical post-change lifecycle.
        QTimer.singleShot(0, self.logout)

    def open_mandatory_password_gate(self) -> None:
        if not self._require_cloud_action(warning=True):
            QTimer.singleShot(0, self.logout)
            return
        try:
            from ui.login import MandatoryPasswordGate

            gate = MandatoryPasswordGate(
                self.runtime.account_security_service, self._new_worker_registry(), self
            )
            gate.logout_requested.connect(lambda: QTimer.singleShot(0, self.logout))
            gate.password_changed.connect(lambda _payload: QTimer.singleShot(0, self.logout))
            self._mandatory_password_gate = gate
            self._exec_modal_dialog(gate)
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Mandatory password gate failed")
            QTimer.singleShot(0, self.logout)
        finally:
            self._mandatory_password_gate = None

    def _restart_after_language_change(self) -> None:
        application_resource_service = self.runtime.application_resource_service

        def _work(progress_callback=None):
            del progress_callback
            application_resource_service.restart_current_process()
            return True

        self._start_logged_worker(
            _work,
            on_result=lambda _ok: self.close_app_completely(),
            warning_message="Application restart launch failed",
            operation_key="application:language-restart",
        )

    def _on_expiry_runtime_settings_applied(self) -> None:
        # Persisted delivery identities survive preference changes. Re-notification
        # is driven only by an actual fixed-policy expiry-stage transition.
        try:
            if getattr(self, "notifications_service", None) is not None:
                self.notifications_service.reset_runtime_state(clear_history=False)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to reset notification runtime state", exc_info=True)
        try:
            page = getattr(self, "track_page", None)
            refresh_projection = getattr(page, "refresh_expiry_projection_async", None)
            if callable(refresh_projection):
                refresh_projection()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to refresh expiry presentation", exc_info=True)
        try:
            self._start_monitoring(restart=bool(self.app_state.session))
            if getattr(self, "app_state", None) is not None and self.app_state.session:
                QTimer.singleShot(0, self.monitoring.check_now)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to re-arm expiry monitoring", exc_info=True)

    # --------------------------------------------------------------- Catalogs
    def _open_catalog_management(self, section: str | None = None) -> None:
        try:
            page = self._ensure_product_catalog_page()
            if page is None:
                return
            if section:
                page.open_section(section)
            self._set_active_sidebar_route("tracking")
            self._show_page(page)
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Catalog management page failed")
            self._show_inline_warning(_("Error"), _("Unable to open catalog management."))

    def manage_stored(self):
        self._open_catalog_management("stored")

    def manage_usage_products(self):
        self._open_catalog_management("usage")

logger = logging.getLogger(__name__)


class MainWindowMenuBuilderMixin:
    def _safe_connect(self, signal, handler_name: str) -> bool:
        try:
            handler = getattr(self, handler_name, None)
            if callable(handler):
                signal.connect(handler)
                return True
            logger.error("Missing handler: %s", handler_name)
        except UI_OPERATION_EXCEPTIONS as exc:
            logger.error("Failed to connect handler %s: %s", handler_name, exc)
        return False

    def init_menus(self) -> None:
        """Build the two visible top-bar command menus without a hidden QMenuBar."""
        file_m = QMenu(_("File"), self)
        tools_m = QMenu(_("Tools"), self)

        self.act_check_updates = QAction(_("Check for Updates"), self)
        set_menu_action_icon(self.act_check_updates, "refresh.png")
        self._safe_connect(self.act_check_updates.triggered, "check_for_updates_now")
        file_m.addAction(self.act_check_updates)

        self.act_exit_application = QAction(_("Exit"), self)
        set_menu_action_icon(self.act_exit_application, "exit.png")
        self._safe_connect(self.act_exit_application.triggered, "close_app_completely")
        file_m.addAction(self.act_exit_application)

        self.act_manage_stored_catalog = QAction(_("Manage food item catalog"), self)
        set_menu_action_icon(self.act_manage_stored_catalog, "products.png")
        self._safe_connect(self.act_manage_stored_catalog.triggered, "manage_stored")
        tools_m.addAction(self.act_manage_stored_catalog)

        self.act_manage_usage_catalog = QAction(_("Manage consumption item catalog"), self)
        set_menu_action_icon(self.act_manage_usage_catalog, "usage.png")
        self._safe_connect(self.act_manage_usage_catalog.triggered, "manage_usage_products")
        tools_m.addAction(self.act_manage_usage_catalog)

        self._file_menu = file_m
        self._tools_menu = tools_m
        self._bind_top_bar_menus(file_m, tools_m)

    def _bind_top_bar_menus(self, file_menu, tools_menu) -> None:
        try:
            primary = getattr(self, "btn_menu_file", None)
            tools_button = getattr(self, "btn_menu_tools", None)
            if primary is not None and tools_button is None:
                combined = QMenu(self)
                for menu in (file_menu, tools_menu):
                    if menu is None:
                        continue
                    if combined.actions():
                        combined.addSeparator()
                    for action in menu.actions():
                        combined.addAction(action)
                self._combined_top_menu = combined
                primary.setMenu(combined)
            else:
                for button, menu in ((primary, file_menu), (tools_button, tools_menu)):
                    if button is not None and menu is not None:
                        button.setMenu(menu)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("MainWindowMenuBuilderMixin._bind_top_bar_menus failed", exc_info=True)


logger = logging.getLogger(__name__)


class MainWindowRouteNavigationMixin:
    def handle_sidebar_click(self, btn: QPushButton, func):
        if getattr(self, "_ui_transition_depth", 0) > 0 or not btn.isEnabled():
            return
        is_page_button = bool(btn.property("pageButton"))
        for b_ in getattr(self, "sidebar_page_buttons", []) or []:
            b_.setChecked(False)
        if is_page_button:
            btn.setChecked(True)
        else:
            btn.setChecked(False)
        func()

    def _set_active_sidebar_route(self, route_name: str | None) -> None:
        wanted = str(route_name or "").strip().lower()
        if wanted != "admin":
            self._set_administration_sidebar_expanded(False)
        for button in getattr(self, "sidebar_page_buttons", []) or []:
            try:
                current = str(button.property("routeName") or "").strip().lower()
                button.setChecked(bool(wanted and current == wanted))
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowRouteNavigationMixin._set_active_sidebar_route failed",
                    exc_info=True,
                )

    def _show_page(self, page: QWidget, *, refresh_callback=None) -> bool:
        self._set_top_bar_visible(True)
        try:
            current = self.content_stack.currentWidget()
            administration_page = getattr(self, "administration_page", None)
            if (
                current is administration_page
                and page is not administration_page
                and administration_page is not None
            ):
                can_leave = getattr(administration_page, "can_leave", None)
                if callable(can_leave) and not bool(can_leave()):
                    self._set_active_sidebar_route("admin")
                    return False
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Page leave guard/reset failed", exc_info=True)
        try:
            usage_page = getattr(self, "usage_page", None)
            if current is usage_page and page is not usage_page and usage_page is not None:
                clear_workspace = getattr(usage_page, "clear_workspace", None)
                if callable(clear_workspace):
                    clear_workspace()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Usage workspace clear-on-leave failed", exc_info=True)

        if callable(refresh_callback):
            try:
                refresh_callback()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("MainWindowUiMixin._show_page fallback failed", exc_info=True)
        self.content_stack.setCurrentWidget(page)
        apply_responsive_shell_metrics(self)
        return True

    def show_home(self):
        self._ensure_home_page()
        if getattr(self, "home_page", None) is None:
            return
        self._set_active_sidebar_route("home")
        self._show_page(
            self.home_page,
            refresh_callback=lambda: self.home_page.refresh_dashboard(
                profile=self.app_state.current_user,
                permission_context=self.cloud_sync_runtime_service.permission_context(),
            ),
        )

    def _on_home_navigation_requested(self, target: str):
        tgt = str(target or "").strip().lower()
        if tgt == "tracking":
            self.show_track()
            return
        if tgt == "usage":
            self.show_usage()
            return
        if tgt == "kpi":
            self.show_kpi()
            return
        if tgt in {"admin", "org"}:
            self.open_administration()
            return

    def _show_authorized_route(self, route: str, page, allowed: bool) -> None:
        if not allowed:
            self._show_not_allowed(title="Permission", warning=False)
            return
        if page is None:
            return
        self._set_active_sidebar_route(route)
        self._show_page(page)

    def show_track(self):
        self._ensure_track_page()
        self._show_authorized_route(
            "tracking",
            getattr(self, "track_page", None),
            self._shell_access_state().can_open_tracking,
        )

    def show_usage(self):
        self._ensure_usage_page()
        self._show_authorized_route(
            "usage",
            getattr(self, "usage_page", None),
            self._shell_access_state().can_open_usage,
        )

    def show_kpi(self):
        self._ensure_kpi_page()
        self._show_authorized_route(
            "kpi",
            getattr(self, "kpi_page", None),
            self._shell_access_state().can_open_kpi,
        )

    def _set_administration_modules(self, modules) -> None:
        set_sidebar_administration_modules(self, modules)

    def _set_administration_sidebar_route(self, route: str) -> None:
        set_sidebar_administration_route(self, route)

    def _set_administration_sidebar_expanded(self, expanded: bool) -> None:
        set_sidebar_administration_expanded(self, expanded)

    def _administration_is_rail_mode(self) -> bool:
        sidebar = getattr(self, "sidebar", None)
        return bool(sidebar is not None and sidebar.property("railMode"))

    def _show_administration_rail_menu(self) -> None:
        """Expose authorized Administration routes from the compact icon rail.

        The persistent administration submenu is intentionally hidden in rail
        mode because its entries are text-only.  A transient menu keeps the
        *main sidebar* as the single navigation authority without creating a
        second Administration navigation surface or blank clickable rows.
        """
        modules = tuple(getattr(self, "_administration_modules", ()) or ())
        button = getattr(self, "btn_org_sidebar", None)
        if not modules or button is None or not button.isVisible():
            return

        menu = QMenu(self)
        menu.setObjectName("AdministrationRailMenu")
        route_buttons = getattr(self, "admin_sidebar_route_buttons", {}) or {}
        page = getattr(self, "administration_page", None)
        controller = getattr(page, "controller", None) if page is not None else None
        state = getattr(controller, "state", None) if controller is not None else None
        current_route = str(getattr(state, "route", "") or "").strip()
        for route in modules:
            route_key = str(route or "").strip()
            if not route_key:
                continue
            route_button = route_buttons.get(route_key)
            label = str(
                (route_button.property("fullText") if route_button is not None else "")
                or (route_button.text() if route_button is not None else "")
                or route_key.replace("_", " ").title()
            )
            action = menu.addAction(label)
            action.setCheckable(True)
            action.setChecked(route_key == current_route)
            action.triggered.connect(
                lambda _checked=False, wanted=route_key: self.open_administration_route(wanted)
            )

        if not menu.actions():
            return
        hint = menu.sizeHint()
        if self.layoutDirection() == Qt.RightToLeft:
            anchor = button.mapToGlobal(QPoint(-hint.width(), 0))
        else:
            anchor = button.mapToGlobal(QPoint(button.width(), 0))
        # Keep the menu alive while it is open. ``popup`` avoids blocking the
        # shell event loop and remains reliable when Windows focus is restricted.
        self._administration_rail_menu = menu
        menu.aboutToHide.connect(lambda: setattr(self, "_administration_rail_menu", None))
        menu.popup(anchor)

    def open_administration(self):
        self._hide_notifications_popup()
        access_state = self._shell_access_state()
        if not access_state.can_open_administration:
            self._show_not_allowed(title="Permission", warning=False)
            return
        page = self._ensure_administration_page()
        if page is None:
            self._show_inline_warning(_("Error"), _("Administration service is not available."))
            return

        current = self.content_stack.currentWidget()
        already_here = current is page
        rail_mode = self._administration_is_rail_mode()
        if (
            already_here
            and not rail_mode
            and bool(getattr(self, "_administration_sidebar_expanded", False))
        ):
            self._set_administration_sidebar_expanded(False)
            return

        self._set_active_sidebar_route("admin")
        self._set_administration_sidebar_expanded(True)
        if not self._show_page(page):
            return
        if not already_here:
            refresh = getattr(page, "refresh_authority", None)
            if callable(refresh):
                refresh()
        if rail_mode:
            self._show_administration_rail_menu()

    def open_administration_route(self, route: str) -> None:
        access_state = self._shell_access_state()
        if not access_state.can_open_administration:
            self._show_not_allowed(title="Permission", warning=False)
            return
        page = self._ensure_administration_page()
        if page is None:
            self._show_inline_warning(_("Error"), _("Administration service is not available."))
            return
        wanted = str(route or "overview").strip()
        modules = tuple(getattr(self, "_administration_modules", ()))
        if modules and wanted not in modules:
            return
        self._set_active_sidebar_route("admin")
        self._set_administration_sidebar_expanded(True)
        if not self._show_page(page):
            return
        navigate = getattr(page, "navigate", None)
        if callable(navigate):
            navigate(wanted)

    def _on_administration_shell_route_requested(self, route: str) -> None:
        target = str(route or "home").strip().lower()
        self._dispose_administration_page()
        self._refresh_navigation_permissions()
        if target == "home":
            self.show_home()
        elif target == "tracking":
            self.show_track()
        elif target == "usage":
            self.show_usage()
        else:
            self.show_home()

    def show_about(self):
        page = self._ensure_about_page()
        if page is None:
            return
        page.set_update_summary(
            getattr(self, "_latest_server_update_version", ""),
            getattr(self, "_update_status_summary", ""),
        )
        page.setLayoutDirection(self.layoutDirection())
        self._set_active_sidebar_route("about")
        self._show_page(page)

    def refresh_current_view(self):
        try:
            current = self.content_stack.currentWidget()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return
        try:
            if current is getattr(self, "home_page", None):
                self.show_home()
                return
            if current is getattr(self, "track_page", None):
                self.track_page.load_tracked_products(show_busy=False)
                return
            if current is getattr(self, "usage_page", None):
                if hasattr(self.usage_page, "compute"):
                    self.usage_page.compute()
                return
            if current is getattr(self, "administration_page", None):
                refresh = getattr(self.administration_page, "refresh_authority", None)
                if callable(refresh):
                    refresh()
                return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowRouteNavigationMixin.refresh_current_view failed",
                exc_info=True,
            )

    def _sync_default_branch_context(self) -> None:
        """Keep shell presentation on the full authorized scope.

        Branch selection is intentionally not a shell-wide navigation control.
        Multi-branch users view their complete authorized scope, while a
        single-branch account naturally resolves to its only branch.  The
        Tracking page owns the explicit branch choice used for creation.
        """
        try:
            service = self.runtime.tracking_service
            state = service.get_branch_filter_state()
            branches = [str(value or "").strip() for value in state.get("branches") or []]
            branches = [value for value in branches if value]
            target = branches[0] if len(branches) == 1 else "all" if branches else ""
            active = service.apply_view_branch_selection(target) if target else ""
            self.app_state.set_current_branch(str(active or target))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Default branch context sync failed", exc_info=True)

    def on_current_branch_changed(self, branch: str) -> None:
        try:
            self.update_user_scope_ui(current_branch=branch)
            track_page = getattr(self, "track_page", None)
            if track_page is not None:
                track_page.refresh_current_branch()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Current branch UI refresh failed", exc_info=True)

    def update_user_scope_ui(self, current_branch: str | None = None):
        lang = normalize_language_code(str(self.preferences.language() or "en"))
        prof = self.app_state.current_user
        ctx = self.cloud_sync_runtime_service.permission_context()
        account_username = str(
            getattr(prof, "username", "") or getattr(ctx, "username", "") or ""
        ).strip()
        display_name = str(
            getattr(prof, "display_name", "")
            or getattr(ctx, "display_name", "")
            or account_username
        ).strip()
        scope_state = ShellUserScopePresenter.build(
            permission_context=ctx,
            username=display_name,
            allowed_branches=self.cloud_sync_runtime_service.allowed_branches(),
            language=lang,
            view_branch=str(
                current_branch
                if current_branch is not None
                else getattr(self.app_state, "current_branch", "")
                or self.cloud_sync_runtime_service.active_branch()
                or ctx.active_branch
                or ""
            ).strip(),
        )
        try:
            if hasattr(self, "home_page") and self.home_page is not None:
                self.home_page.refresh_dashboard(
                    profile=prof,
                    permission_context=ctx,
                    view_branch=scope_state.resolved_view_branch,
                )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin.update_user_scope_ui fallback failed", exc_info=True)
        try:
            if hasattr(self, "lbl_user_info") and self.lbl_user_info is not None:
                # The visible sidebar identity is the person's server-provided
                # display_name, not the login/account username.  This keeps
                # employee numbers such as "2614" out of the primary identity
                # surface while retaining them for diagnostics in the tooltip.
                visible_name = display_name or account_username
                visible_text = visible_name
                if len(visible_text) > 40:
                    visible_text = visible_text[:39].rstrip() + "…"

                tooltip_parts: list[str] = []
                for part in (
                    visible_name,
                    (
                        account_username
                        if account_username
                        and account_username.casefold() != visible_name.casefold()
                        else ""
                    ),
                    str(scope_state.top_info or "").strip(),
                ):
                    clean = str(part or "").strip()
                    if clean and clean not in tooltip_parts:
                        tooltip_parts.append(clean)
                full_text = " · ".join(tooltip_parts)

                self.lbl_user_info.setProperty("fullText", visible_name)
                self.lbl_user_info.setAccessibleName(visible_name)
                self.lbl_user_info.setToolTip(full_text or visible_name)
                self.lbl_user_info.setText(visible_text)

                meta = str(scope_state.top_info or "").strip()
                if account_username and account_username.casefold() != visible_name.casefold():
                    account_label = f"#{account_username}"
                    meta = f"{meta} · {account_label}".strip(" ·")
                if getattr(self, "sidebar_profile_meta", None) is not None:
                    self.sidebar_profile_meta.setText(meta)
                    self.sidebar_profile_meta.setToolTip(full_text or meta)

                if getattr(self, "sidebar_profile_avatar", None) is not None:
                    words = [part for part in visible_name.replace("-", " ").split() if part]
                    initials = "".join(part[0] for part in words[:2]).upper() or "—"
                    self.sidebar_profile_avatar.setText(initials)

                if getattr(self, "sidebar_profile_card", None) is not None:
                    self.sidebar_profile_card.setVisible(bool(self.app_state.session))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin.update_user_scope_ui fallback failed", exc_info=True)


logger = logging.getLogger(__name__)


class AppLifecycleControllerMixin:
    def _bind_application_lifecycle(self) -> None:
        lifecycle = self.runtime.lifecycle
        lifecycle.on_background("window_background", self._enter_background_runtime)
        lifecycle.on_foreground("window_foreground", self._enter_foreground_runtime)
        lifecycle.on_shutdown("runtime_resources", self._shutdown_runtime_resources)
        report = lifecycle.start()
        if not report.successful:
            raise RuntimeError(f"Application lifecycle startup failed: {report.errors}")

    def _enter_background_runtime(self) -> None:
        """Enter the single supported background state.

        The lifecycle callback owns the invariant: the main window is hidden and
        the system-tray affordance is visible before background work continues.
        """
        if not self._show_tray_icon():
            raise RuntimeError("Cannot enter background mode without a system-tray icon")
        self.hide()
        if getattr(self.app_state, "session", None):
            self.monitoring.ensure_started(self._runtime_generation_value())

    def _enter_foreground_runtime(self) -> None:
        self._bring_to_front(show_if_hidden=True)
        tray = getattr(self, "tray_icon", None)
        if tray is not None:
            tray.hide()
        if getattr(self.app_state, "session", None):
            self.monitoring.ensure_started(self._runtime_generation_value())

    def closeEvent(self, event):
        """Hide to the existing background runtime when the window X is used."""
        save_window_placement(self)
        if getattr(self, "_closing_completely", False):
            self._safe_accept_event(event)
            return
        if self.send_to_background(show_message=True):
            event.ignore()
            return
        logger.error("WINDOW_CLOSE_BACKGROUND=FAIL tray/background runtime unavailable")
        # Do not silently make the close button appear broken when Windows has
        # no usable tray.  The app stays open (to preserve monitoring) and
        # explains the next available action to the operator.
        self._bring_to_front(show_if_hidden=True)
        self._show_inline_warning(
            _("Background mode is unavailable."),
            _("Keep the window open or choose Exit to stop monitoring."),
        )
        event.ignore()

    def _persist_runtime_setting_async(self, key: str, value: str) -> bool:
        """Persist a runtime preference without blocking the Qt presentation thread."""
        setting_key = str(key or "").strip()
        if not setting_key:
            return False
        registry = getattr(self, "_worker_registry", None)
        if registry is None:
            logger.debug("Runtime setting worker registry is unavailable: %s", setting_key)
            return False
        operation_key = f"runtime-setting:{setting_key}"
        if registry.has_active_key(operation_key):
            return True
        settings_service = self.runtime.settings_service
        worker = self._worker_registry.start(
            lambda: settings_service.set_runtime_value(setting_key, str(value)),
            on_error=lambda message: logger.debug(
                "Unable to persist runtime setting %s: %s", setting_key, message
            ),
            operation_key=f"runtime-setting:{setting_key}",
            log_exceptions=False,
        )
        return worker is not None

    def send_to_background(self, *, show_message: bool = True) -> bool:
        self._persist_runtime_setting_async("enable_tray_background", "True")
        try:
            return bool(self._minimize_to_tray(show_message=show_message))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Background transition failed", exc_info=True)
            return False

    def _stop_known_runtime_timers(self) -> None:
        monitor = getattr(self, "monitoring", None)
        stop_monitoring = getattr(monitor, "stop", None)
        if callable(stop_monitoring):
            stop_monitoring()
        for timer_name in (
            "token_refresh_timer",
            "_change_driven_sync_timer",
            "_shell_status_clear_timer",
        ):
            self._safe_stop_timer(getattr(self, timer_name, None))

    def _stop_child_timers(self) -> None:
        try:
            for timer in list(self.findChildren(QTimer)):
                self._safe_stop_timer(timer)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Runtime child-timer shutdown failed", exc_info=True)

    def _drain_runtime_thread_pool(self, timeout_ms: int = 2500) -> bool:
        try:
            scopes = getattr(self, "worker_scopes", None)
            if scopes is None:
                return True
            return bool(
                scopes.drain(
                    timeout_ms,
                    bounded_main_thread=threading.current_thread() is threading.main_thread(),
                )
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Thread-pool drain failed", exc_info=True)
            return False

    def _shutdown_runtime_resources(self, *, from_about_to_quit: bool = False) -> None:
        close_updates = getattr(self, "_close_online_update_service", None)
        if callable(close_updates):
            close_updates()
        if getattr(self, "_shutdown_resources_done", False):
            if from_about_to_quit:
                self._drain_runtime_thread_pool(timeout_ms=500)
            return
        self._shutdown_resources_done = True
        self._closing_completely = True

        # 1) Invalidate callbacks and prevent new UI jobs from being accepted.
        try:
            self._cancel_active_workers("application_shutdown")
            scopes = getattr(self, "worker_scopes", None)
            if scopes is not None:
                scopes.close_all()
            else:
                registry = getattr(self, "_worker_registry", None)
                close_registry = getattr(registry, "close", None)
                if callable(close_registry):
                    close_registry()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Active worker shutdown failed", exc_info=True)

        # 2) Stop all schedulers before closing transports, so shutdown cannot
        # enqueue replacement work while sockets are being torn down.
        self._stop_known_runtime_timers()
        self._stop_child_timers()
        try:
            if getattr(self, "runtime_scheduler", None) is not None:
                shutdown = getattr(self.runtime_scheduler, "shutdown", None)
                if callable(shutdown):
                    shutdown()
                else:
                    self.runtime_scheduler.cancel("cloud_changed")
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Sync manager shutdown failed", exc_info=True)
        try:
            monitor = getattr(self, "monitoring", None)
            shutdown_monitor = getattr(monitor, "shutdown", None)
            if callable(shutdown_monitor):
                shutdown_monitor()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Monitoring shutdown failed", exc_info=True)

        # 3) Close network transports before waiting for the pool. This actively
        # unblocks requests/SSE workers instead of waiting for request timeouts.
        try:
            self.cloud_sync_runtime_service.shutdown_transports()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Cloud transport shutdown failed", exc_info=True)

        # 4) Now drain running work. Queued work is cleared; running work has
        # already received cancellation and lost its network transports.
        drained = self._drain_runtime_thread_pool(timeout_ms=12000)
        if not drained:
            logger.warning("Background work did not finish before the bounded shutdown deadline")

        # 5) Tear down UI-local services and persistent storage only after workers
        # can no longer legitimately reach them.
        try:
            notifications = getattr(self, "notifications_service", None)
            close_notifications = getattr(notifications, "close", None)
            if callable(close_notifications):
                call_if_callable(close_notifications)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Notification shutdown failed", exc_info=True)
        try:
            self._destroy_tray_icon()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Tray cleanup during shutdown failed", exc_info=True)
        if drained:
            try:
                self.runtime.application_resource_service.close_storage()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("Database close during shutdown failed", exc_info=True)
        else:
            # Never close SQLite underneath an exceptional still-running worker.
            # Process teardown will release it after Qt has finished outstanding work.
            logger.warning("Database close deferred because background work is still running")

    def close_app_completely(self):
        try:
            save_window_placement(self)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Window geometry save during shutdown failed", exc_info=True)
        if getattr(self, "_closing_completely", False):
            app = QApplication.instance()
            if app is not None:
                QTimer.singleShot(0, app.quit)
            return
        self._closing_completely = True
        report = self.runtime.lifecycle.shutdown()
        if not report.successful:
            logger.error("Application lifecycle shutdown errors: %s", report.errors)
        try:
            self.hide()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Window hide during shutdown failed", exc_info=True)
        app = QApplication.instance()
        if app is not None:
            QTimer.singleShot(0, app.quit)
