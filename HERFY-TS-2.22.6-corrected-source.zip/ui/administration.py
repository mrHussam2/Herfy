from __future__ import annotations

import logging
from typing import Any

from PySide6.QtCore import QSize, QTimer, Signal
from PySide6.QtWidgets import (
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.settings import _
from ui.dialogs import show_info_message, show_question_message
from ui.administration_assignments import AssignmentsSection
from ui.administration_audit import AuditSection
from ui.administration_catalogs import (
    AdministrationCatalogsSection,
    CatalogServiceUnavailableSection,
)
from ui.administration_components import AdministrationWorkspaceHeader
from ui.administration_controller import (
    AdministrationController,
    AdministrationPresenter,
    NavigationEntry,
)
from ui.administration_overview import OverviewSection
from ui.administration_permissions import PermissionsSection
from ui.administration_shared import QT_WIDGET_SIZE_MAX as _QT_WIDGET_SIZE_MAX
from ui.administration_structure import StructureSection
from ui.administration_users import AccountCollectionSection
from ui.designer import load_ui
from ui.responsive_events import responsive_resize_event
from ui.theme import (
    UI_METRICS,
    PageStack,
    apply_profile_properties,
    fade_in,
    operation_pulse,
    profile_for_widget,
    supports_admin_master_detail,
    toolbar_breakpoint_for_width,
)

logger = logging.getLogger(__name__)

# Public compatibility export; the shared module is the sole definition owner.
QT_WIDGET_SIZE_MAX = _QT_WIDGET_SIZE_MAX

# Administration sections


class AdministrationPage(QWidget):
    """Embedded administration workspace driven exclusively by server authority.

    The main application sidebar owns administration section navigation.  This
    page therefore contains one content workspace only; it never renders a
    second navigation rail inside the administration surface.
    """

    shell_route_requested = Signal(str)
    modules_changed = Signal(object)
    route_changed = Signal(str)

    def minimumSizeHint(self) -> QSize:  # noqa: N802 - Qt API
        """Let the compact master/detail layout own narrow-window adaptation."""
        return QSize(0, 0)

    def __init__(
        self,
        admin_service: Any,
        app_state: Any,
        worker_registry,
        parent=None,
        *,
        catalog_service: Any | None = None,
    ):
        super().__init__(parent)
        self.setObjectName("AdministrationPage")
        self.setProperty("uiScope", "administration")
        self.setProperty("nativeWorkspace", True)
        self.app_state = app_state
        self.catalog_service = catalog_service
        self._worker_registry = worker_registry
        self.controller = AdministrationController(
            admin_service, self.app_state, worker_registry, self
        )
        self._closed = False
        self._online = True
        self._busy = False
        self._offline_notice_visible = False
        self._notice_generation = 0
        self._notice_source = ""
        self._modules: tuple[str, ...] = tuple()
        self._route_widgets: dict[str, QWidget] = {}
        self._build_ui()
        self._bind_controller()
        QTimer.singleShot(0, self.apply_responsive_profile)

    def _build_ui(self) -> None:
        controls = load_ui(
            self,
            "administration_page",
            required=(
                "admin_header_host",
                "AdminInlineNotice",
                "admin_stack_host",
                "administration_root",
                "admin_header_layout",
                "admin_content_layout",
                "admin_stack_layout",
            ),
        )
        root: QVBoxLayout = controls["administration_root"]
        # A page stack must be able to enter compact mode before any section's
        # desktop size hint can force the whole main window wider than the
        # available workspace.
        self.setMinimumSize(0, 0)
        controls["admin_stack_host"].setMinimumSize(0, 0)
        root.setSpacing(UI_METRICS.page_section_gap)

        # Own the layout before constructing optional header behavior.  A
        # header integration failure must never leave a half-built page whose
        # resize event then raises a second, unrelated exception.
        self.content_layout: QVBoxLayout = controls["admin_content_layout"]
        margin = UI_METRICS.page_margin
        self.content_layout.setContentsMargins(margin, margin, margin, margin)
        # Keep the workspace header/notice/stack visually distinct without
        # introducing an oversized decorative header or touching navigation.
        self.content_layout.setSpacing(UI_METRICS.page_section_gap)

        self.workspace_header = AdministrationWorkspaceHeader(self)
        self.workspace_header.refresh_requested.connect(self.controller.refresh)
        self._connect_workspace_header_route()
        self.activity_label = self.workspace_header.activity
        self.refresh_button = self.workspace_header.refresh
        self.workspace_header.show()
        controls["admin_header_layout"].addWidget(self.workspace_header)

        self.notice = controls["AdminInlineNotice"]
        self.notice.hide()

        self.stack = PageStack(controls["admin_stack_host"])
        self.stack.setObjectName("AdminStack")
        self.stack.setMinimumSize(0, 0)
        self.stack.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        self.stack.set_compact_minimum(True)
        controls["admin_stack_layout"].addWidget(self.stack, 1)

        self.overview = OverviewSection(self)
        self.employees = AccountCollectionSection(self.controller, self, account_mode="employee")
        self.branch_accounts = AccountCollectionSection(
            self.controller, self, account_mode="branch"
        )
        self.structure = StructureSection(self.controller, self)
        self.assignments = AssignmentsSection(self.controller, self)
        self.permissions = PermissionsSection(self.controller, self)
        self.catalogs = self._create_catalogs_section()
        self.audit = AuditSection(self.controller, self)
        for route, widget in (
            ("overview", self.overview),
            ("employees", self.employees),
            ("branch_accounts", self.branch_accounts),
            ("structure", self.structure),
            ("assignments", self.assignments),
            ("permissions", self.permissions),
            ("catalogs", self.catalogs),
            ("audit", self.audit),
        ):
            widget.setMinimumSize(0, 0)
            widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            self._route_widgets[route] = widget
            self.stack.addWidget(widget)

        self.overview.route_requested.connect(self.navigate)
        self.audit.entity_requested.connect(self._open_entity_reference)
        self.structure.entity_requested.connect(self._open_entity_reference)
        self.employees.scope_entity_requested.connect(
            lambda kind, ident: self.navigate("structure", kind, ident)
        )
        self.branch_accounts.scope_entity_requested.connect(
            lambda kind, ident: self.navigate("structure", kind, ident)
        )
        self.workspace_header.set_route("overview")

    def _connect_workspace_header_route(self) -> None:
        """Bind header navigation without making the page brittle to old UI plugins.

        The packaged header owns ``route_requested``.  The selector fallback
        keeps Administration reachable if a locally loaded legacy UI extension
        exposes the selector but not the signal, and does not add a duplicate
        connection for the supported header.
        """
        route_signal = getattr(self.workspace_header, "route_requested", None)
        connector = getattr(route_signal, "connect", None)
        if callable(connector):
            connector(self.navigate)
            return

        selector = getattr(self.workspace_header, "route_selector", None)
        index_changed = getattr(selector, "currentIndexChanged", None)
        fallback_connector = getattr(index_changed, "connect", None)
        if not callable(fallback_connector):
            raise RuntimeError("Administration header does not expose route navigation")
        logger.warning(
            "Administration header has no route_requested signal; using selector fallback"
        )
        fallback_connector.connect(self._navigate_workspace_header_selector)

    def _navigate_workspace_header_selector(self, index: int) -> None:
        selector = getattr(self.workspace_header, "route_selector", None)
        route = str(selector.itemData(index) or "").strip() if selector is not None else ""
        if route:
            self.navigate(route)

    def _create_catalogs_section(self) -> QWidget:
        """Keep Administration available when its optional catalog surface fails.

        The catalog service is composed independently from the administration
        bootstrap.  A stale session, offline runtime, or an older server
        contract can therefore make its permission projection unavailable.  It
        must not turn the entire Administration page into a blank/non-opening
        route.
        """
        if self.catalog_service is None:
            return CatalogServiceUnavailableSection(self)
        try:
            return AdministrationCatalogsSection(
                self.catalog_service,
                self._worker_registry,
                self,
                app_state=self.app_state,
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.warning("Catalog administration surface is unavailable", exc_info=True)
            return CatalogServiceUnavailableSection(self)

    def _bind_controller(self) -> None:
        self.controller.snapshot_changed.connect(self._apply_snapshot)
        self.controller.audit_changed.connect(self.audit.set_events)
        self.controller.busy_changed.connect(self._on_busy_changed)
        self.controller.success.connect(self._on_operation_success)
        self.controller.error.connect(
            lambda text: self._show_notice(text, "error", source="operation")
        )
        self.controller.conflict.connect(self._on_conflict)
        self.controller.access_revoked.connect(self._on_access_revoked)
        self.controller.online_changed.connect(self._on_online_changed)
        self.controller.temporary_credential_ready.connect(self._show_temporary_credential)

    def _on_operation_success(self, text: str) -> None:
        self._show_notice(text, "success", auto_hide=True, source="operation")
        current = self.stack.currentWidget()
        if current is not None:
            operation_pulse(current, duration=280)
        fade_in(self.notice, duration=150, start=0.25)

    def _on_busy_changed(self, busy: bool, text: str) -> None:
        self._busy = bool(busy)
        self.workspace_header.set_busy(self._busy, str(text or _("Working...")))
        self.workspace_header.set_online(self._online and not self._busy)

    def _on_online_changed(self, online: bool) -> None:
        self._online = bool(online)
        self.workspace_header.set_online(self._online and not self._busy)
        if online:
            # Persistent connection state is shown once beside the sidebar profile.
            # Remove only the administration-specific offline warning here.
            if self._offline_notice_visible and self._notice_source == "offline":
                self._hide_notice()
            self._offline_notice_visible = False
            return
        self._offline_notice_visible = True
        self._show_notice(
            _(
                "Offline: cached administration data is read-only. A server connection is required for changes."
            ),
            "warning",
            source="offline",
        )

    def _hide_notice(self, *, generation: int | None = None) -> None:
        if generation is not None and generation != self._notice_generation:
            return
        self.notice.hide()
        self._notice_source = ""

    def _show_notice(
        self,
        text: str,
        kind: str = "info",
        *,
        auto_hide: bool = False,
        source: str = "",
    ) -> None:
        self._notice_generation += 1
        generation = self._notice_generation
        self._notice_source = str(source or "")
        self.notice.setProperty("noticeKind", str(kind))
        self.notice.setText(str(text or ""))
        self.notice.setVisible(bool(text))
        self.notice.style().unpolish(self.notice)
        self.notice.style().polish(self.notice)
        if auto_hide and text:
            QTimer.singleShot(
                2600,
                lambda token=generation: (
                    None if self._closed else self._hide_notice(generation=token)
                ),
            )

    def _show_temporary_credential(self, username: str, password: str) -> None:
        # Display only the server-issued credential.  The client does not invent
        # or persist bootstrap passwords.
        if self._closed or not password:
            return
        show_info_message(
            self,
            _("Temporary password"),
            _("Username: {username} | Temporary password: {password}").format(
                username=str(username or ""), password=str(password)
            ),
            require_ack=True,
        )

    def _on_conflict(self, text: str) -> None:
        # A revision conflict must never overwrite the editor that produced it.
        # Keep the user's draft in place and require an explicit refresh/discard
        # decision before loading the newer server revision.
        message = str(text or _("The record changed on the server."))
        message += " " + _(
            "Your unsaved edits were kept. Refresh only after reviewing or copying them."
        )
        self._show_notice(message, "warning", source="conflict")

    def _on_access_revoked(self, text: str) -> None:
        """Keep the Administration workspace visible when authority changes.

        A failed or stale bootstrap must not make a sidebar click look like a
        successful navigation followed by an unexplained jump back to Home.
        Sensitive data is still cleared immediately, while the user remains on
        the dedicated page and receives the authoritative reason.
        """
        self._show_notice(text, "warning", source="authority")
        self.controller.state.clear_sensitive()
        if self._modules:
            self._modules = tuple()
            self.modules_changed.emit(tuple())
        self.workspace_header.set_modules((), "")
        self._show_route("overview")

    def _apply_snapshot(self, snapshot: dict[str, Any]) -> None:
        modules = AdministrationPresenter.modules(snapshot)
        module_tuple = tuple(modules)
        if module_tuple != self._modules:
            self._modules = module_tuple
            self.modules_changed.emit(module_tuple)
        self.workspace_header.set_modules(modules, self.controller.state.route)
        self.overview.set_snapshot(snapshot)
        self.employees.set_snapshot(snapshot)
        self.branch_accounts.set_snapshot(snapshot)
        self.structure.set_snapshot(snapshot)
        self.assignments.set_snapshot(snapshot)
        self.permissions.set_snapshot(snapshot)
        events = snapshot.get("audit_events")
        if isinstance(events, list):
            self.audit.set_events(events)
        self.audit.set_has_more(bool(snapshot.get("audit_next_cursor")))
        current = self.controller.state.route
        if current not in modules:
            current = modules[0] if modules else "overview"
            self.controller.state.history = [NavigationEntry(current)]
            self.controller.state.history_index = 0
        self._show_route(current)
        self._render_breadcrumbs(NavigationEntry(current))

    def _editor_dirty(self) -> bool:
        current = self.stack.currentWidget()
        checker = getattr(current, "is_dirty", None)
        return bool(checker()) if callable(checker) else False

    def _confirm_discard_editor(self) -> bool:
        if not self._editor_dirty():
            return True
        answer = show_question_message(
            self,
            _("Unsaved changes"),
            _("There are unsaved administration changes. Discard them?")
        )
        return answer

    def navigate(
        self,
        route: str,
        entity_type: str = "",
        entity_id: str = "",
        *,
        push: bool = True,
    ) -> None:
        route = str(route or "overview")
        modules = AdministrationPresenter.modules(self.controller.state.snapshot)
        if route not in modules:
            self.workspace_header.set_route(self.controller.state.route)
            return
        if push and route != self.controller.state.route and not self._confirm_discard_editor():
            self.workspace_header.set_route(self.controller.state.route)
            return
        entry = NavigationEntry(
            route,
            str(entity_type or ""),
            str(entity_id or ""),
            str(entity_id or ""),
        )
        if push:
            self.controller.state.push_navigation(entry)
        else:
            self.controller.state.route = route
        self._show_route(route)
        self._render_breadcrumbs(entry)
        self._select_deep_link(entry)
        self._update_navigation_controls()

    def _show_route(self, route: str) -> None:
        widget = self._route_widgets.get(route)
        if widget is None:
            return
        self.stack.setCurrentWidget(widget)
        self.controller.state.route = route
        self.workspace_header.set_route(route)
        self.route_changed.emit(route)
        self._update_navigation_controls()

    def _select_deep_link(self, entry: NavigationEntry) -> None:
        if entry.route == "employees" and entry.entity_id:
            self.employees.select_user(entry.entity_id)
        elif entry.route == "branch_accounts" and entry.entity_id:
            self.branch_accounts.select_user(entry.entity_id)
        elif entry.route == "structure" and entry.entity_type and entry.entity_id:
            self.structure.select_entity(entry.entity_type, entry.entity_id)

    def _route_for_user(self, user_id: str) -> str:
        target = str(user_id or "")
        for row in self.controller.state.snapshot.get("users") or []:
            if not isinstance(row, dict):
                continue
            if str(row.get("user_id") or row.get("username") or "") != target:
                continue
            return (
                "branch_accounts" if AdministrationPresenter.is_branch_account(row) else "employees"
            )
        return "employees"

    def _open_entity_reference(self, entity_type: str, entity_id: str) -> None:
        kind = str(entity_type or "").strip().lower()
        ident = str(entity_id or "").strip()
        if not ident:
            return
        if kind in {"user", "users", "employee", "account"}:
            route = self._route_for_user(ident)
            self.navigate(route, "user", ident)
        elif kind in {"organization", "region", "area", "branch"}:
            self.navigate("structure", kind, ident)

    def _go_back(self) -> None:
        if not self._confirm_discard_editor():
            return
        entry = self.controller.state.back()
        if entry is None:
            return
        self._show_route(entry.route)
        self._render_breadcrumbs(entry)
        self._select_deep_link(entry)
        self._update_navigation_controls()

    def _go_forward(self) -> None:
        if not self._confirm_discard_editor():
            return
        entry = self.controller.state.forward()
        if entry is None:
            return
        self._show_route(entry.route)
        self._render_breadcrumbs(entry)
        self._select_deep_link(entry)
        self._update_navigation_controls()

    def _update_navigation_controls(self) -> None:
        # History stays available to controller-driven deep links.  The new
        # workspace exposes direct route commands instead of a second
        # browser-style toolbar.
        return

    def _clear_breadcrumbs(self) -> None:
        return

    def _render_breadcrumbs(self, entry: NavigationEntry) -> None:
        self.workspace_header.set_route(entry.route)

    def apply_responsive_profile(self, profile=None) -> None:
        profile = profile or profile_for_widget(self)
        apply_profile_properties(self, profile)
        compact = not supports_admin_master_detail(
            int(profile.width or self.width() or 0),
            str(profile.orientation or "landscape"),
        )

        root = self.findChild(QVBoxLayout, "administration_root")
        if root is not None:
            margin = max(4, int(profile.page_margin))
            root.setContentsMargins(margin, margin, margin, margin)
            root.setSpacing(max(4, int(profile.gap)))
            content_layout = getattr(self, "content_layout", None)
            if content_layout is not None:
                content_layout.setContentsMargins(margin, margin, margin, margin)

        for section in (
            self.overview,
            self.employees,
            self.branch_accounts,
            self.structure,
            self.assignments,
            self.audit,
        ):
            setter = getattr(section, "set_compact_mode", None)
            if callable(setter):
                setter(compact)

        if hasattr(self.catalogs, "set_compact"):
            self.catalogs.set_compact(compact)
        toolbar_width = int(self.contentsRect().width() or profile.width or 0)
        toolbar_compact = toolbar_breakpoint_for_width(toolbar_width) in {
            "compact",
            "small",
        }
        self.permissions.set_toolbar_width(toolbar_width)
        self.permissions.set_compact_mode(toolbar_compact)
        self.workspace_header.set_compact(toolbar_compact)

    resizeEvent = responsive_resize_event  # noqa: N815 - Qt callback alias

    def can_leave(self) -> bool:
        return self._confirm_discard_editor()

    def refresh_authority(self) -> None:
        if not self._closed:
            self.controller.schedule_refresh(0)

    def dispose(self) -> None:
        if self._closed:
            return
        self._closed = True
        self.controller.state.clear_sensitive()
        if self._modules:
            self._modules = tuple()
            self.modules_changed.emit(tuple())
        try:
            self.controller.close()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Administration controller close failed", exc_info=True)


__all__ = ["AdministrationPage", "QT_WIDGET_SIZE_MAX"]
