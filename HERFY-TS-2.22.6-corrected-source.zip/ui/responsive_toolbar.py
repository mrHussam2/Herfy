from __future__ import annotations

from collections.abc import Callable, Iterable

from PySide6.QtWidgets import QMenu, QPushButton, QToolButton, QWidget

from core.settings import _
from ui.theme_metrics import UI_METRICS


def toolbar_breakpoint_for_width(width: int | None) -> str:
    """Keep desktop commands in their established slots at every width.

    The workspace viewport provides overflow scrolling when space is scarce.
    Window resizing must not move commands into a different row or menu.
    """
    del width
    return "large"


def apply_toolbar_control_metrics(
    container: QWidget,
    controls: Iterable[QWidget],
    width: int | None,
) -> str:
    breakpoint = toolbar_breakpoint_for_width(width)
    container.setProperty("toolbarBreakpoint", breakpoint)
    # A narrow desktop workspace keeps its command bar in the same horizontal
    # structure as the wide view.  Pages place secondary commands in More
    # rather than turning a toolbar into a tall form.
    container.setProperty("toolbarSingleRow", True)
    for control in controls:
        control.setProperty("toolbarControl", True)
        control.setMinimumHeight(UI_METRICS.toolbar_control_height)
    return breakpoint


def configure_more_menu(
    button: QToolButton,
    secondary_buttons: Iterable[QPushButton],
    *,
    before_show: Callable[[], None] | None = None,
) -> QMenu:
    menu = QMenu(button)
    sources = tuple(secondary_buttons)
    for source in sources:
        action_text = source.property("toolbarActionText") or source.text()
        action = menu.addAction(str(action_text))
        action.triggered.connect(source.click)

    def sync_enabled_state() -> None:
        if before_show is not None:
            before_show()
        for action, source in zip(menu.actions(), sources, strict=True):
            action_text = source.property("toolbarActionText") or source.text()
            action.setText(str(action_text))
            action.setVisible(bool(source.property("toolbarActionAvailable")))
            action.setEnabled(source.isEnabled())
        menu.setLayoutDirection(button.layoutDirection())

    menu.aboutToShow.connect(sync_enabled_state)
    button.setText(_("More"))
    button.setAccessibleName(_("More actions"))
    button.setPopupMode(QToolButton.InstantPopup)
    button.setMenu(menu)
    button.setMinimumWidth(UI_METRICS.toolbar_more_min_width)
    button.setProperty("uiRole", "toolbarMore")
    return menu
