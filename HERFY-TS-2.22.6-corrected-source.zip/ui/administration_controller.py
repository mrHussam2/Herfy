from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Any, Callable

from PySide6.QtCore import QObject, QTimer, Signal

from core.presentation import normalize_role, role_labels
from core.settings import _


@dataclass
class NavigationEntry:
    route: str
    entity_type: str = ""
    entity_id: str = ""
    label: str = ""


@dataclass
class AdministrationState:
    snapshot: dict[str, Any] = field(default_factory=dict)
    route: str = "overview"
    history: list[NavigationEntry] = field(default_factory=lambda: [NavigationEntry("overview")])
    history_index: int = 0
    selected_users: list[str] = field(default_factory=list)
    selected_entity: tuple[str, str] | None = None
    online: bool = True
    busy: bool = False
    last_error: str = ""

    def push_navigation(self, entry: NavigationEntry) -> None:
        current = self.history[self.history_index] if self.history else None
        if current == entry:
            self.route = entry.route
            return
        if self.history_index < len(self.history) - 1:
            self.history = self.history[: self.history_index + 1]
        self.history.append(entry)
        self.history_index = len(self.history) - 1
        self.route = entry.route

    def can_back(self) -> bool:
        return self.history_index > 0

    def can_forward(self) -> bool:
        return self.history_index + 1 < len(self.history)

    def back(self) -> NavigationEntry | None:
        if not self.can_back():
            return None
        self.history_index -= 1
        entry = self.history[self.history_index]
        self.route = entry.route
        return entry

    def forward(self) -> NavigationEntry | None:
        if not self.can_forward():
            return None
        self.history_index += 1
        entry = self.history[self.history_index]
        self.route = entry.route
        return entry

    def clear_sensitive(self) -> None:
        self.snapshot.clear()
        self.selected_users.clear()
        self.selected_entity = None
        self.last_error = ""


# Server bootstrap still exposes the canonical "users" administration module.
# The client presents that one authority surface as two views without inventing
# new server permissions or routes: employee identities and branch identities.
MODULE_LABELS = {
    "overview": "Overview",
    "employees": "Employees",
    "branch_accounts": "Branch Accounts",
    "structure": "Structure",
    "assignments": "Assignments",
    "permissions": "Permissions",
    "catalogs": "Product Catalogs",
    "audit": "Audit Log",
}


class AdministrationPresenter:
    @classmethod
    def modules(cls, snapshot: dict[str, Any]) -> list[str]:
        """Return only administration views that can be loaded successfully.

        The server bootstrap is the authority boundary.  Its coarse
        ``available_modules`` may include a module because the actor can mutate
        it even when the corresponding list endpoint still requires a view
        permission.  The client may narrow that server grant, never broaden it.
        """
        raw = (snapshot or {}).get("available_modules")
        server_modules = (
            {str(x).strip() for x in raw or [] if str(x).strip()}
            if isinstance(raw, list)
            else set()
        )
        caps = cls.capabilities(snapshot)
        catalog_access_granted = bool(
            caps.intersection({"catalog.view", "catalog.manage", "usage.view", "usage.manage"})
        )
        if not server_modules and not catalog_access_granted:
            return []
        structure_view_codes = {
            "organizations.view",
            "regions.view",
            "areas.view",
            "branches.view",
        }
        can_view_users = "users" in server_modules and "users.view" in caps
        can_view_structure = "structure" in server_modules and bool(
            caps.intersection(structure_view_codes)
        )

        # Overview is a client presentation of the same server-authorized
        # modules, not an additional server permission. It must be reachable
        # whenever the server has granted at least one administration module.
        result: list[str] = ["overview"] if server_modules else []
        if can_view_users:
            result.extend(("employees", "branch_accounts"))
        if can_view_structure:
            result.append("structure")
        if (
            "assignments" in server_modules
            and "users.scopes.assign" in caps
            and can_view_users
            and can_view_structure
        ):
            result.append("assignments")
        if "permissions" in server_modules and "permissions.view" in caps:
            result.append("permissions")

        # The section may be read-only; edit controls still check their own
        # mutation permission. A catalog view grant must not disappear merely
        # because the actor cannot modify it.
        # Older server releases omitted ``catalogs`` from available_modules
        # while issuing canonical catalog permissions. The explicit capability
        # remains a safe, narrower compatibility source: it cannot expose the
        # section without a server-issued catalog permission, and endpoints
        # continue enforcing that permission and organizational scope.
        if catalog_access_granted:
            result.append("catalogs")

        if "audit" in server_modules and "audit.view" in caps:
            result.append("audit")
        return result

    @staticmethod
    def module_label(route: str) -> str:
        return _(MODULE_LABELS.get(str(route), str(route).replace("_", " ").title()))

    @classmethod
    def capabilities(cls, snapshot: dict[str, Any]) -> set[str]:
        actions = (snapshot or {}).get("allowed_actions")
        if not isinstance(actions, dict):
            return set()
        return {
            str(code).strip()
            for code, allowed in actions.items()
            if isinstance(code, str) and code.strip() and allowed is True
        }

    @classmethod
    def bootstrap_contract_error(cls, snapshot: Any) -> str:
        """Return a safe schema error instead of treating bad data as denial."""
        if not isinstance(snapshot, dict):
            return "bootstrap response is not an object"
        modules = snapshot.get("available_modules")
        if not isinstance(modules, list) or any(
            not isinstance(item, str) or not item.strip() for item in modules
        ):
            return "available_modules is not a string list"
        actions = snapshot.get("allowed_actions")
        if not isinstance(actions, dict):
            return "allowed_actions is not an object"
        if any(
            not isinstance(code, str) or not code.strip() or not isinstance(allowed, bool)
            for code, allowed in actions.items()
        ):
            return "allowed_actions has an invalid entry"
        return ""

    @classmethod
    def has_capability(cls, snapshot: dict[str, Any], *codes: str) -> bool:
        caps = cls.capabilities(snapshot)
        return any(str(c) in caps for c in codes)

    @classmethod
    def scope_model(cls, snapshot: dict[str, Any]) -> dict[str, Any]:
        value = (snapshot or {}).get("scope_policy")
        model = dict(value) if isinstance(value, dict) else {}
        # ``types`` was emitted by earlier server releases. Normalize the
        # documented synonym without changing scope semantics.
        if "allowed_types" not in model and isinstance(model.get("types"), list):
            model["allowed_types"] = list(model["types"])
        return model

    @staticmethod
    def structure_organizations(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
        """Return organizations from the canonical /admin/structure projection."""
        rows = [
            dict(item)
            for item in (snapshot or {}).get("organizations") or []
            if isinstance(item, dict) and str(item.get("organization_id") or "").strip()
        ]
        return sorted(
            rows,
            key=lambda item: str(item.get("organization_id") or "").strip(),
        )

    @classmethod
    def mixed_scope_supported(cls, snapshot: dict[str, Any]) -> bool:
        return bool(cls.scope_model(snapshot).get("allow_mixed_types", False))

    @classmethod
    def parent_inherits_descendants(cls, snapshot: dict[str, Any]) -> bool:
        return (
            cls.scope_model(snapshot).get("inheritance_mode")
            == "parent_expands_effective_scope_only"
        )

    @classmethod
    def allowed_scope_types(cls, snapshot: dict[str, Any]) -> list[str]:
        raw = cls.scope_model(snapshot).get("allowed_types")
        return [str(x) for x in raw or [] if str(x)] if isinstance(raw, list) else []

    @classmethod
    def manageable_roles(cls, snapshot: dict[str, Any]) -> list[str]:
        raw = (snapshot or {}).get("manageable_roles")
        return [str(x) for x in raw or [] if str(x)] if isinstance(raw, list) else []

    @classmethod
    def target_manageable(cls, snapshot: dict[str, Any], user: dict[str, Any] | None) -> bool:
        if not isinstance(user, dict):
            return False
        role = str(user.get("role") or "").strip()
        return bool(role) and role in set(cls.manageable_roles(snapshot))

    @staticmethod
    def user_direct_assignments(user: dict[str, Any]) -> list[dict[str, str]]:
        raw = (user or {}).get("direct_scope")
        if isinstance(raw, list):
            return [
                {
                    "scope_type": str(x.get("scope_type") or ""),
                    "scope_id": str(x.get("scope_id") or ""),
                }
                for x in raw
                if isinstance(x, dict) and x.get("scope_type") and x.get("scope_id")
            ]
        return []

    @staticmethod
    def user_scope_ids(user: dict[str, Any], scope_type: str) -> list[str]:
        return sorted(
            {
                x["scope_id"]
                for x in AdministrationPresenter.user_direct_assignments(user)
                if x["scope_type"] == scope_type
            }
        )

    @staticmethod
    def is_branch_account(user: dict[str, Any]) -> bool:
        return str((user or {}).get("account_type") or "").strip().lower() == "branch"

    @classmethod
    def branch_account_branch(cls, user: dict[str, Any]) -> str:
        """Return the branch only when the server direct-scope contract proves it.

        Never infer branch ownership from the username; doing so would hide a
        malformed or missing branch-scope assignment.
        """
        assignments = cls.user_direct_assignments(user)
        branches = [
            str(item.get("scope_id") or "").strip()
            for item in assignments
            if str(item.get("scope_type") or "").strip() == "branch"
            and str(item.get("scope_id") or "").strip()
        ]
        return branches[0] if len(assignments) == 1 and len(branches) == 1 else ""

    @classmethod
    def branch_account_scope_state(cls, user: dict[str, Any]) -> str:
        """Describe whether a deployed branch identity has one canonical branch.

        This is diagnostic presentation only.  The server remains authoritative
        for the identity/scope invariant and the client never repairs it locally.
        """
        assignments = cls.user_direct_assignments(user)
        branch_ids = [
            str(item.get("scope_id") or "").strip()
            for item in assignments
            if str(item.get("scope_type") or "").strip() == "branch"
            and str(item.get("scope_id") or "").strip()
        ]
        non_branch = [
            item for item in assignments if str(item.get("scope_type") or "").strip() != "branch"
        ]
        if len(branch_ids) == 1 and not non_branch and len(assignments) == 1:
            return "valid"
        if not assignments:
            return "missing"
        if len(branch_ids) > 1:
            return "multiple_branches"
        return "mixed_or_invalid"

    @classmethod
    def branch_account_branch_display(cls, user: dict[str, Any]) -> str:
        branch = cls.branch_account_branch(user)
        if branch and cls.branch_account_scope_state(user) == "valid":
            return branch
        return _("Scope mismatch")

    @staticmethod
    def role_label(role: str, language: str = "en") -> str:
        normalized = normalize_role(role)
        return role_labels(language).get(normalized, normalized.replace("_", " ").title())

    @staticmethod
    def scope_summary(scope: dict[str, Any] | None) -> str:
        data = scope if isinstance(scope, dict) else {}
        parts = []
        for key, label in (
            ("organizations", _("Organizations")),
            ("regions", _("Regions")),
            ("areas", _("Areas")),
            ("branches", _("Branches")),
        ):
            values = [str(v).strip() for v in data.get(key) or [] if str(v).strip()]
            if values:
                parts.append(f"{len(values)} {label}")
        return " • ".join(parts) if parts else _("No effective scope")

    @staticmethod
    def direct_scope_summary(user: dict[str, Any]) -> str:
        counts = defaultdict(int)
        for row in AdministrationPresenter.user_direct_assignments(user):
            counts[row["scope_type"]] += 1
        parts = []
        for kind, label in (
            ("organization", _("Organizations")),
            ("region", _("Regions")),
            ("area", _("Areas")),
            ("branch", _("Branches")),
        ):
            if counts[kind]:
                parts.append(f"{counts[kind]} {label}")
        return " • ".join(parts) if parts else _("No direct scope")

    @staticmethod
    def permission_label(code: str) -> str:
        raw = str(code or "").strip()
        if not raw:
            return ""
        parts = raw.split(".")
        noun = _(parts[0].replace("_", " ").title())
        amap = {
            "view": _("View"),
            "create": _("Create"),
            "update": _("Edit"),
            "delete": _("Delete"),
            "enable": _("Enable"),
            "disable": _("Disable"),
            "assign": _("Assign"),
            "reset": _("Reset"),
            "transfer": _("Transfer"),
            "manage": _("Manage"),
        }
        return " ".join(
            [amap.get(p, _(p.replace("_", " ").title())) for p in parts[1:]] + [noun]
        ).strip()

    @staticmethod
    def permission_groups(catalog: list[Any]) -> dict[str, list[str]]:
        groups: dict[str, list[str]] = defaultdict(list)
        for entry in catalog or []:
            code = (
                str(entry.get("code") or "").strip()
                if isinstance(entry, dict)
                else str(entry or "").strip()
            )
            if code:
                groups[code.split(".", 1)[0]].append(code)
        return {k: sorted(set(v)) for k, v in sorted(groups.items())}

    @staticmethod
    def audit_diff(details: dict[str, Any] | None) -> str:
        data = details if isinstance(details, dict) else {}
        parts = []
        for key, label in (
            ("added_scopes", _("Added")),
            ("removed_scopes", _("Removed")),
        ):
            vals = []
            for item in data.get(key) or []:
                if isinstance(item, dict):
                    vals.append(f"{item.get('scope_type')}:{item.get('scope_id')}")
                else:
                    vals.append(str(item))
            if vals:
                parts.append(label + ": " + ", ".join(vals))
        previous = data.get("previous_role")
        new = data.get("new_role")
        if previous is not None or new is not None:
            parts.append(_("Role") + f": {previous or '—'} → {new or '—'}")
        previous_status = data.get("previous_status")
        new_status = data.get("new_status")
        if previous_status is not None or new_status is not None:
            parts.append(_("Status") + f": {previous_status} → {new_status}")
        return "\n".join(parts)


logger = logging.getLogger(__name__)


class AdministrationController(QObject):
    snapshot_changed = Signal(object)
    audit_changed = Signal(object)
    busy_changed = Signal(bool, str)
    success = Signal(str)
    error = Signal(str)
    conflict = Signal(str)
    operation_failed = Signal(str, object)
    access_revoked = Signal(str)
    online_changed = Signal(bool)
    temporary_credential_ready = Signal(str, str)
    user_saved = Signal(object)
    permissions_saved = Signal(str, object)
    assignments_saved = Signal(str)
    structure_saved = Signal(str, object)

    _LOCAL_MUTATION_PREFIXES = (
        "admin.user.save",
        "admin.user.active:",
        "admin.user.password:",
        "admin.assignment.save:",
        "admin.structure.save:",
        "admin.structure.transfer:",
        "admin.structure.disable:",
        "admin.structure.remove:",
        "admin.permissions:",
    )

    def __init__(
        self, admin_service: Any, app_state: Any = None, worker_registry=None, parent=None
    ):
        super().__init__(parent)
        self.app_state = app_state
        self.admin_service = admin_service
        self.state = AdministrationState()
        if worker_registry is None:
            raise RuntimeError("AdministrationController requires a worker registry")
        self._workers = worker_registry
        self._closed = False
        # Administration operations may chain (for example save -> reload).
        # Track each in-flight worker instead of a single boolean so the UI does
        # not report idle while a follow-up server projection is still loading.
        self._busy_operations: dict[str, str] = {}
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.timeout.connect(self.refresh)
        # A same-revision bootstrap is normally allowed to retain the visible
        # collection while a local action finishes.  External SSE/reconnect
        # reconciliation is different: structure or account rows can change
        # without changing the current user's authority revision, so it must
        # replace the cached projection rather than quietly preserve it.
        self._external_projection_refresh = False
        self._bind_state()

    def _bind_state(self) -> None:
        state = self.app_state
        if state is None:
            return
        for name, handler in (
            ("data_changed", self._on_data_changed),
            ("permissions_changed", self._on_permissions_changed),
            ("connection_changed", self._on_connection_changed),
            ("session_changed", self._on_session_changed),
        ):
            signal = getattr(state, name, None)
            if signal is not None:
                try:
                    signal.connect(handler)
                except Exception:
                    logger.debug("Admin state signal connect failed: %s", name, exc_info=True)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._refresh_timer.stop()
        self._workers.close()
        self._busy_operations.clear()
        self.state.busy = False
        self.busy_changed.emit(False, "")
        self.state.clear_sensitive()

    def _on_session_changed(self, session) -> None:
        if not session:
            self.access_revoked.emit(_("The administration session has ended."))

    def _on_connection_changed(self, online: bool, _message: str = "") -> None:
        was_online = self.state.online
        self.state.online = bool(online)
        self.online_changed.emit(bool(online))
        # A reconnect can leave the visible authority projection stale even
        # when no realtime authorization event follows it. Reconcile once on
        # the offline -> online transition; the timer and worker key prevent
        # repeated connection signals from issuing duplicate bootstraps.
        if self.state.online and not was_online:
            self._external_projection_refresh = True
            self.schedule_refresh(0)

    def _on_permissions_changed(self, _context) -> None:
        self._external_projection_refresh = True
        self.schedule_refresh(0)

    def _on_data_changed(self, domain: str, _payload: Any = None) -> None:
        if str(domain or "").strip().lower() not in {"admin", "authorization"}:
            return
        # Admin services publish one local app-state event after a successful
        # mutation. Those mutations already have an explicit result/reload path
        # below; scheduling a second bootstrap here caused duplicate HTTP reads.
        # External realtime/authorization events arrive while no matching local
        # mutation key is active and still trigger the canonical reconciliation.
        if any(
            key.startswith(prefix)
            for key in self._busy_operations
            for prefix in self._LOCAL_MUTATION_PREFIXES
        ):
            return
        self._external_projection_refresh = True
        self.schedule_refresh(120)

    def schedule_refresh(self, delay_ms: int = 120) -> None:
        if not self._closed:
            self._refresh_timer.start(max(0, int(delay_ms)))

    def _emit_busy_state(self) -> None:
        busy = bool(self._busy_operations)
        self.state.busy = busy
        # Dict insertion order gives the most recently-started operation, which
        # is the action the user is currently waiting on when operations chain.
        text = next(reversed(self._busy_operations.values()), "") if busy else ""
        self.busy_changed.emit(busy, str(text or ""))

    def _begin_busy_operation(self, key: str, text: str = "") -> None:
        self._busy_operations[str(key)] = str(text or "")
        self._emit_busy_state()

    def _finish_busy_operation(self, key: str) -> None:
        self._busy_operations.pop(str(key), None)
        self._emit_busy_state()

    def _handle_failure(self, failure: Any, *, operation_key: str = "") -> None:
        payload = dict(failure or {}) if isinstance(failure, dict) else {}
        text = str(payload.get("message") or _("Administration operation failed."))
        self.state.last_error = text
        self.operation_failed.emit(str(operation_key or ""), dict(payload))
        error_code = str(payload.get("error_code") or "").strip().upper()
        try:
            status_code = int(payload.get("status_code"))
        except (TypeError, ValueError):
            status_code = 0

        exception_type = str(payload.get("exception_type") or "")
        logger.warning(
            "ADMIN_OPERATION_FAILURE operation=%s status=%s code=%s exception=%s",
            str(operation_key or "unknown"),
            status_code or "none",
            error_code or "none",
            exception_type or "none",
        )
        if exception_type == "RemoteRequestError" and status_code in {0, 500, 502, 503, 504}:
            self.state.online = False
            self.online_changed.emit(False)

        if operation_key == "admin.bootstrap" and status_code in {0, 500, 502, 503, 504}:
            self.error.emit(
                _(
                    "Administration could not be loaded because the server is unavailable. "
                    "Your permissions have not changed; retry when the connection is restored."
                )
            )
            return

        # Administration concurrency is a canonical server contract.  Detect it
        # from structured metadata rather than parsing localized HTTP text.
        if error_code == "REVISION_CONFLICT" or (
            status_code == 409 and "REVISION_CONFLICT" in text.upper()
        ):
            details = payload.get("details") if isinstance(payload.get("details"), dict) else {}
            current = details.get("current")
            suffix = (
                _(" Current server revision: {revision}.").format(revision=current)
                if current is not None
                else ""
            )
            self.conflict.emit(_("The record was changed by another user.") + suffix)
            return

        if status_code == 401:
            self.access_revoked.emit(
                _("Your administration session has expired. Sign in again to continue.")
            )
            return

        if status_code == 403 or error_code.startswith("AUTH_"):
            if operation_key == "admin.bootstrap":
                self.access_revoked.emit(
                    _("Your account is not permitted to access Administration.")
                )
            else:
                self.error.emit(
                    _("This action is no longer permitted. Server authority will be refreshed.")
                )
                self.schedule_refresh(0)
            return

        self.error.emit(text)

    def _start(
        self,
        key: str,
        work: Callable,
        on_result: Callable | None = None,
        *,
        busy_text: str = "",
        success_text: str = "",
    ):
        if self._closed:
            return None
        operation_key = str(key or "").strip()
        if not operation_key:
            raise ValueError("Administration worker operation_key is required")
        if not self.state.online and operation_key != "admin.bootstrap":
            self.error.emit(_("A server connection is required to perform this action."))
            return None
        # WorkerRegistry de-duplicates operation keys.  Check before touching busy
        # state so a duplicate click cannot clear the real in-flight operation.
        if self._workers.has_active_key(operation_key):
            return None
        self._begin_busy_operation(operation_key, busy_text)

        def result(value):
            if on_result:
                on_result(value)
            if success_text:
                self.success.emit(success_text)

        def finished():
            self._finish_busy_operation(operation_key)

        worker = self._workers.start(
            work,
            on_result=result,
            on_failure=lambda failure, op=operation_key: self._handle_failure(
                failure, operation_key=op
            ),
            on_finished=finished,
            operation_key=operation_key,
        )
        if worker is None:
            self._finish_busy_operation(operation_key)
        return worker

    # Bootstrap and section loading ------------------------------------
    def refresh(self):
        return self._start(
            "admin.bootstrap",
            self.admin_service.bootstrap,
            self._apply_bootstrap,
            busy_text=_("Synchronizing administration authority..."),
        )

    def _apply_bootstrap(self, bootstrap: Any) -> None:
        contract_error = AdministrationPresenter.bootstrap_contract_error(bootstrap)
        if contract_error:
            logger.error("ADMIN_BOOTSTRAP_CONTRACT_INVALID reason=%s", contract_error)
            self.error.emit(
                _(
                    "Administration returned an incompatible permission response. "
                    "Your permissions have not changed; contact support if this persists."
                )
            )
            return
        data = dict(bootstrap)
        modules = AdministrationPresenter.modules(data)
        if not modules:
            logger.warning(
                "ADMIN_BOOTSTRAP_NO_VISIBLE_MODULES authority_revision=%s module_count=%d action_count=%d",
                str(data.get("authority_revision") or "none"),
                len(data.get("available_modules") or []),
                len(AdministrationPresenter.capabilities(data)),
            )
            self.access_revoked.emit(
                _("Your account has no Administration sections available.")
            )
            return
        # Never carry a projection across an authority revision change.  The
        # bootstrap revision is the server-owned boundary for permissions/scope;
        # preserving rows from an older revision can briefly expose stale users or
        # hierarchy after delegation is narrowed.
        old_revision = self.state.snapshot.get("authority_revision")
        new_revision = data.get("authority_revision")
        preserve_projection = (
            not self._external_projection_refresh
            and old_revision is not None
            and new_revision is not None
            and str(old_revision) == str(new_revision)
        )
        if preserve_projection:
            for key in (
                "users",
                "users_next_cursor",
                "organizations",
                "regions",
                "areas",
                "branches",
                "roles",
                "audit_events",
                "audit_next_cursor",
            ):
                if key in self.state.snapshot:
                    data[key] = self.state.snapshot[key]
        self.state.snapshot = data
        self._external_projection_refresh = False
        self.snapshot_changed.emit(dict(data))
        current = self.state.route if self.state.route in modules else modules[0]
        self.load_section(current)

    def load_section(self, route: str):
        route = str(route or "overview")
        if route == "overview":
            can_read_users = AdministrationPresenter.has_capability(
                self.state.snapshot, "users.view"
            )
            if can_read_users and "users" not in self.state.snapshot:
                return self.load_users()
            return None
        if route == "employees":
            modules = AdministrationPresenter.modules(self.state.snapshot)
            needs_structure_editor_context = AdministrationPresenter.has_capability(
                self.state.snapshot, "users.create", "users.scopes.assign"
            )
            if "structure" in modules and needs_structure_editor_context:
                return self._load_users_and_structure(
                    "admin.employees.load",
                    _("Loading employees..."),
                )
            return self.load_users()
        if route == "branch_accounts":
            # Branch identity rows are user records, but their Region/Area
            # labels come from the canonical structure projection.  Load both
            # when the actor is allowed to view Structure; otherwise the view
            # falls back to server-derived ancestor context in effective_scope.
            if "structure" in AdministrationPresenter.modules(self.state.snapshot):
                return self._load_users_and_structure(
                    "admin.branch_accounts.load",
                    _("Loading branch accounts..."),
                )
            return self.load_users()
        if route == "structure":
            can_read_users = AdministrationPresenter.has_capability(
                self.state.snapshot, "users.view"
            )
            if can_read_users:
                return self._load_users_and_structure(
                    "admin.structure.load",
                    _("Loading structure..."),
                )
            return self.load_structure()
        if route == "assignments":
            return self._load_users_and_structure(
                "admin.assignments.load",
                _("Loading assignments..."),
            )
        if route == "permissions":
            return self.load_permissions()
        if route == "audit":
            return self.load_audit()
        return None

    def _load_users_and_structure(self, operation_key: str, busy_text: str):
        """Fetch one coherent administration projection without double emits."""
        users_service = self.admin_service.users
        structure_service = self.admin_service.structure

        def work():
            return {
                "users": users_service.list_all(limit=250),
                "structure": structure_service.list(),
            }

        def apply(payload):
            users = payload.get("users") or {}
            structure = payload.get("structure") or {}
            self.state.snapshot["users"] = [
                dict(item) for item in users.get("items") or [] if isinstance(item, dict)
            ]
            self.state.snapshot["users_next_cursor"] = users.get("next_cursor")
            for key in ("organizations", "regions", "areas", "branches"):
                self.state.snapshot[key] = [
                    dict(item) for item in structure.get(key) or [] if isinstance(item, dict)
                ]
            self._emit_snapshot()

        return self._start(
            operation_key,
            work,
            apply,
            busy_text=busy_text,
        )

    def _emit_snapshot(self) -> None:
        self.snapshot_changed.emit(dict(self.state.snapshot))

    def _merge_users(self, result: dict[str, Any]) -> None:
        self.state.snapshot["users"] = [
            dict(x) for x in result.get("items") or [] if isinstance(x, dict)
        ]
        self.state.snapshot["users_next_cursor"] = result.get("next_cursor")
        self._emit_snapshot()

    def load_users(self, **filters: Any):
        filters.setdefault("limit", 250)
        users_service = self.admin_service.users
        filters_snapshot = dict(filters)
        return self._start(
            "admin.users.load",
            lambda: users_service.list_all(**filters_snapshot),
            self._merge_users,
            busy_text=_("Loading users..."),
        )

    def _merge_structure(self, result: dict[str, Any]) -> None:
        for key in ("organizations", "regions", "areas", "branches"):
            self.state.snapshot[key] = [
                dict(x) for x in result.get(key) or [] if isinstance(x, dict)
            ]
        self._emit_snapshot()

    def load_structure(self):
        return self._start(
            "admin.structure.load",
            self.admin_service.structure.list,
            self._merge_structure,
            busy_text=_("Loading structure..."),
        )

    def _merge_permissions(self, result: dict[str, Any]) -> None:
        self.state.snapshot["roles"] = [
            dict(x) for x in result.get("roles") or [] if isinstance(x, dict)
        ]
        self._emit_snapshot()

    def load_permissions(self):
        return self._start(
            "admin.permissions.load",
            self.admin_service.permissions.list,
            self._merge_permissions,
            busy_text=_("Loading permissions..."),
        )

    def load_audit(self, **filters: Any):
        filters.setdefault("limit", 250)
        audit_service = self.admin_service.audit
        filters_snapshot = dict(filters)
        return self._start(
            "admin.audit.load",
            lambda: audit_service.list(**filters_snapshot),
            lambda result: self._apply_audit(result, append=False),
            busy_text=_("Loading audit log..."),
        )

    def load_more_audit(self):
        cursor = str(self.state.snapshot.get("audit_next_cursor") or "").strip()
        if not cursor:
            return None
        audit_service = self.admin_service.audit
        return self._start(
            "admin.audit.more",
            lambda: audit_service.list(cursor=cursor, limit=250),
            lambda result: self._apply_audit(result, append=True),
            busy_text=_("Loading more audit events..."),
        )

    def _apply_audit(self, result: Any, *, append: bool) -> None:
        payload = dict(result or {}) if isinstance(result, dict) else {"items": result or []}
        incoming = [dict(row) for row in payload.get("items") or [] if isinstance(row, dict)]
        if append:
            values = [
                dict(row)
                for row in self.state.snapshot.get("audit_events") or []
                if isinstance(row, dict)
            ]
            seen = {str(row.get("id") or "") for row in values}
            values.extend(row for row in incoming if str(row.get("id") or "") not in seen)
        else:
            values = incoming
        self.state.snapshot["audit_events"] = values
        self.state.snapshot["audit_next_cursor"] = payload.get("next_cursor")
        self.audit_changed.emit(values)
        self._emit_snapshot()

    # Mutations ---------------------------------------------------------
    def _patch_snapshot_user(self, user: dict[str, Any]) -> None:
        uid = str(user.get("user_id") or "")
        rows = list(self.state.snapshot.get("users") or [])
        for i, row in enumerate(rows):
            if isinstance(row, dict) and str(row.get("user_id") or "") == uid:
                rows[i] = dict(user)
                break
        else:
            rows.append(dict(user))
        self.state.snapshot["users"] = rows
        self._emit_snapshot()

    def save_user(self, payload: dict[str, Any]):
        users_service = self.admin_service.users

        def applied(result):
            user = result.get("user") if isinstance(result, dict) else result
            if isinstance(user, dict):
                self._patch_snapshot_user(user)
            if isinstance(result, dict):
                temporary_password = str(result.get("temporary_password") or "")
                if temporary_password:
                    username = (
                        str((user or {}).get("username") or "") if isinstance(user, dict) else ""
                    )
                    self.temporary_credential_ready.emit(username, temporary_password)
            if isinstance(user, dict):
                self.user_saved.emit(dict(user))
            self.load_users()

        return self._start(
            "admin.user.save",
            lambda: users_service.save(payload),
            applied,
            busy_text=_("Saving user..."),
            success_text=_("User saved"),
        )

    def set_user_active(self, user: dict[str, Any], active: bool):
        uid = str(user.get("user_id") or "")
        revision = int(user.get("authority_revision") or 0)
        users_service = self.admin_service.users

        def applied(result):
            updated = (
                result.get("user")
                if isinstance(result, dict) and isinstance(result.get("user"), dict)
                else result
            )
            if isinstance(updated, dict):
                self._patch_snapshot_user(updated)
            self.load_users()

        return self._start(
            f"admin.user.active:{uid}",
            lambda: users_service.set_active(uid, active=active, base_authority_revision=revision),
            applied,
            busy_text=_("Saving user status..."),
            success_text=_("User status saved"),
        )

    def reset_password(self, user: dict[str, Any], temporary_password: str | None = None):
        uid = str(user.get("user_id") or "")
        revision = int(user.get("authority_revision") or 0)
        success_text = (
            _("Password reset") if temporary_password else _("Temporary password generated")
        )
        users_service = self.admin_service.users

        def applied(result):
            if not temporary_password and isinstance(result, dict):
                generated = str(result.get("temporary_password") or "")
                if generated:
                    self.temporary_credential_ready.emit(str(user.get("username") or ""), generated)
            self.load_users()

        return self._start(
            f"admin.user.password:{uid}",
            lambda: users_service.reset_password(
                uid, base_authority_revision=revision, password=temporary_password or None
            ),
            applied,
            busy_text=_("Resetting password..."),
            success_text=success_text,
        )

    def apply_assignments(self, targets: list[dict[str, Any]], assignments: list[dict[str, str]]):
        target_rows = [dict(x) for x in targets if isinstance(x, dict)]
        if len(target_rows) != 1:
            self.error.emit(
                _(
                    "Multi-user assignment changes require a server batch contract; no client-side mutation loop is permitted."
                )
            )
            return None
        user = target_rows[0]
        uid = str(user.get("user_id") or "").strip()
        revision = int(user.get("authority_revision") or 0)
        if not uid:
            self.error.emit(_("The selected employee has no server user identifier."))
            return None
        users_service = self.admin_service.users
        assignments_snapshot = [dict(item) for item in assignments if isinstance(item, dict)]

        def applied(_result):
            self.assignments_saved.emit(uid)
            self.load_users()

        return self._start(
            f"admin.assignment.save:{uid}",
            lambda: users_service.replace_scopes(
                uid,
                base_authority_revision=revision,
                assignments=assignments_snapshot,
            ),
            applied,
            busy_text=_("Saving assignments..."),
            success_text=_("Assignments saved"),
        )

    def _merge_structure_mutation(self, kind: str, result: Any) -> dict[str, Any]:
        payload = dict(result or {}) if isinstance(result, dict) else {}
        if self.admin_service.apply_structure_result(self.state.snapshot, kind, payload):
            self._emit_snapshot()
        return payload

    def save_structure(self, kind: str, values: dict[str, Any], *, existing: bool = False):
        entity_kind = str(kind or "").strip()
        structure_service = self.admin_service.structure
        values_snapshot = dict(values or {})

        def applied(result):
            payload = self._merge_structure_mutation(entity_kind, result)
            branch_account = payload.get("branch_account")
            if isinstance(branch_account, dict):
                temporary_password = str(branch_account.get("temporary_password") or "")
                if temporary_password:
                    self.temporary_credential_ready.emit(
                        str(branch_account.get("username") or ""), temporary_password
                    )
            self.structure_saved.emit(entity_kind, payload)
            # Reconcile permissions/scope after giving the UI the exact successful
            # server entity immediately. The follow-up bootstrap remains the final
            # authority boundary.
            self.schedule_refresh(0)

        return self._start(
            f"admin.structure.save:{entity_kind}",
            lambda: structure_service.save(entity_kind, values_snapshot, existing=existing),
            applied,
            busy_text=_("Saving structure..."),
            success_text=_("Structure saved"),
        )

    def transfer_branch(self, branch: dict[str, Any], area_id: str):
        branch_id = str((branch or {}).get("branch_id") or "").strip()
        base_revision = int((branch or {}).get("revision") or 0)
        target_area = str(area_id or "").strip()
        if not branch_id or not target_area:
            return None
        structure_service = self.admin_service.structure

        def applied(result):
            self._merge_structure_mutation("branch", result)
            self.schedule_refresh(0)

        return self._start(
            f"admin.structure.transfer:branch:{branch_id}",
            lambda: structure_service.transfer_branch(
                branch_id, area_id=target_area, base_revision=base_revision
            ),
            applied,
            busy_text=_("Moving branch..."),
            success_text=_("Branch moved"),
        )

    def remove_structure(self, kind: str, ident: str, base_revision: int):
        structure_service = self.admin_service.structure

        def applied(result):
            payload = dict(result or {}) if isinstance(result, dict) else {}
            self._merge_structure_mutation(kind, payload)
            if isinstance(result, dict) and result.get("deleted"):
                self.success.emit(_("Structure deleted"))
            elif isinstance(result, dict) and result.get("disabled"):
                self.success.emit(_("Structure disabled"))
            else:
                self.success.emit(_("Structure updated"))
            self.schedule_refresh(0)

        return self._start(
            f"admin.structure.remove:{kind}:{ident}",
            lambda: structure_service.remove(kind, ident, base_revision=base_revision),
            applied,
            busy_text=_("Removing structure..."),
        )

    def disable_structure(self, kind: str, ident: str, base_revision: int):
        # Compatibility alias for older section callers.
        return self.remove_structure(kind, ident, base_revision)

    def save_permissions(self, role: str, *, base_revision: int, permissions: list[str]):
        role_key = str(role or "").strip()
        permissions_service = self.admin_service.permissions
        permissions_snapshot = list(permissions or [])

        def applied(result):
            self.permissions_saved.emit(
                role_key, dict(result or {}) if isinstance(result, dict) else {}
            )
            self.load_permissions()
            self.schedule_refresh(0)

        return self._start(
            f"admin.permissions:{role_key}",
            lambda: permissions_service.set_role_permissions(
                role_key, base_revision=int(base_revision), permissions=permissions_snapshot
            ),
            applied,
            busy_text=_("Saving permissions..."),
            success_text=_("Permissions saved"),
        )
