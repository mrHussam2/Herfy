from __future__ import annotations

import logging

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from core.presentation import ShellAccessService
from core.settings import _

logger = logging.getLogger(__name__)


"""Main-window navigation and shell-access behavior."""


class MainWindowAccessNavigationMixin:
    def _shell_access_state(self):
        return ShellAccessService.build(
            permission_context=self.cloud_sync_runtime_service.permission_context(),
            has_session=bool(self.app_state.session),
            allowed_branches=self.cloud_sync_runtime_service.allowed_branches(),
            server_connected=bool(self.cloud_sync_runtime_service.connected()),
        )

    def _set_sidebar_locked(
        self, locked: bool, *, allow_exit: bool = True, reset_checks: bool = False
    ):
        buttons = list(getattr(self, "sidebar_buttons", []) or [])
        for button in buttons:
            try:
                button.setEnabled(not locked)
                if reset_checks:
                    button.setChecked(False)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("Sidebar lock update failed", exc_info=True)
        if locked and allow_exit:
            logout = getattr(self, "btn_logout_sidebar", None)
            if logout is not None:
                logout.setEnabled(True)

    def _set_menu_logged_out_state(self):
        for action_name in ("act_manage_stored_catalog", "act_manage_usage_catalog"):
            action = getattr(self, action_name, None)
            if action is not None:
                action.setEnabled(False)
        action = getattr(self, "act_exit_application", None)
        if action is not None:
            action.setEnabled(True)

    def _refresh_navigation_permissions(self):
        page_buttons = list(getattr(self, "sidebar_page_buttons", []) or [])
        access_state = self._shell_access_state()
        route_permissions = {
            "home": access_state.can_open_home,
            "tracking": access_state.can_open_tracking,
            "usage": access_state.can_open_usage,
            "kpi": access_state.can_open_kpi,
            "admin": access_state.can_open_administration,
            "about": access_state.can_open_about,
        }
        try:
            for button in page_buttons:
                route_name = str(button.property("routeName") or "").strip().lower()
                if route_name in route_permissions:
                    button.setEnabled(bool(route_permissions[route_name]))
            if getattr(self, "btn_settings_sidebar", None) is not None:
                # Keep the normal shell navigation visible while logged out;
                # session-gated entries are disabled until authentication.
                self.btn_settings_sidebar.setVisible(True)
                self.btn_settings_sidebar.setEnabled(access_state.can_open_settings)
            if getattr(self, "btn_org_sidebar", None) is not None:
                self.btn_org_sidebar.setEnabled(access_state.can_open_administration)
                # Administration is not decorative navigation: if the authenticated
                # authority has no administration access, the entry does not exist
                # in the visible shell. The server still enforces every request.
                self.btn_org_sidebar.setVisible(access_state.can_open_administration)
                if not access_state.can_open_administration:
                    self._set_administration_modules(tuple())
                    self._set_administration_sidebar_expanded(False)
            if getattr(self, "btn_kpi_sidebar", None) is not None:
                self.btn_kpi_sidebar.setVisible(access_state.can_open_kpi)
                self.btn_kpi_sidebar.setEnabled(access_state.can_open_kpi)
            if getattr(self, "btn_logout_sidebar", None) is not None:
                self.btn_logout_sidebar.setEnabled(access_state.can_logout)
                self.btn_logout_sidebar.setVisible(access_state.can_logout)
            if getattr(self, "sidebar_profile_card", None) is not None:
                self.sidebar_profile_card.setVisible(access_state.has_session)
                self.sidebar_profile_card.setProperty("signedIn", access_state.has_session)
            if getattr(self, "sidebar_footer", None) is not None:
                self.sidebar_footer.setVisible(
                    bool(access_state.has_session or access_state.can_logout)
                )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._refresh_navigation_permissions fallback failed",
                exc_info=True,
            )
        try:
            self.btn_notifications.setEnabled(access_state.can_open_notifications)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._refresh_navigation_permissions fallback failed",
                exc_info=True,
            )

    def _apply_logged_out_shell(self, *, reset_sidebar: bool = False):
        # Authentication is an application state, not a workspace route.  Do
        # not leave the full (disabled) navigation shell around the sign-in
        # form: it looked like an empty page and suggested that the user had
        # been redirected to an unavailable workspace.  The shell returns as
        # one unit immediately after the server authorizes the session.
        for host_name in ("sidebar_host", "top_bar"):
            host = getattr(self, host_name, None)
            if host is not None:
                host.hide()
        try:
            self._set_sidebar_locked(True, allow_exit=True, reset_checks=reset_sidebar)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._apply_logged_out_shell fallback failed",
                exc_info=True,
            )
        try:
            self._set_menu_logged_out_state()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._apply_logged_out_shell fallback failed",
                exc_info=True,
            )
        try:
            self.lbl_user_info.setText("")
            if getattr(self, "sidebar_profile_meta", None) is not None:
                self.sidebar_profile_meta.setText("")
            if getattr(self, "sidebar_profile_avatar", None) is not None:
                self.sidebar_profile_avatar.setText("—")
            if getattr(self, "sidebar_profile_card", None) is not None:
                self.sidebar_profile_card.hide()
            if getattr(self, "sidebar_footer", None) is not None:
                self.sidebar_footer.hide()
            if getattr(self, "btn_logout_sidebar", None) is not None:
                self.btn_logout_sidebar.hide()
            if getattr(self, "btn_org_sidebar", None) is not None:
                self.btn_org_sidebar.hide()
            if getattr(self, "btn_kpi_sidebar", None) is not None:
                self.btn_kpi_sidebar.hide()
            self._set_administration_modules(tuple())
            self._set_administration_sidebar_expanded(False)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._apply_logged_out_shell fallback failed",
                exc_info=True,
            )
        self._set_notifications_enabled(False)
        try:
            self.lbl_notif_count.hide()
            set_count = getattr(getattr(self, "btn_notifications", None), "set_count", None)
            if callable(set_count):
                set_count(0)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._apply_logged_out_shell fallback failed",
                exc_info=True,
            )
        self._safe_show_login()

    def _apply_logged_in_shell(self):
        for host_name in ("sidebar_host", "top_bar"):
            host = getattr(self, host_name, None)
            if host is not None:
                host.show()
        try:
            self._set_top_bar_session_actions_visible(True)
            self._set_sidebar_locked(False, allow_exit=True, reset_checks=False)
            self._refresh_navigation_permissions()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._apply_logged_in_shell fallback failed",
                exc_info=True,
            )

    def _apply_password_change_required_shell(self) -> None:
        """Expose only password change, logout and exit while the server restricts the session."""
        self._set_top_bar_session_actions_visible(True)
        self._set_sidebar_locked(True, allow_exit=True, reset_checks=True)
        self._set_notifications_enabled(False)
        for action_name in ("act_manage_stored_catalog", "act_manage_usage_catalog"):
            action = getattr(self, action_name, None)
            if action is not None:
                action.setEnabled(False)
        exit_action = getattr(self, "act_exit_application", None)
        if exit_action is not None:
            exit_action.setEnabled(True)
        self._show_shell_status_message(
            _("Password change is required before using the application.")
        )

    def _begin_ui_transition(
        self, message: str = "", *, lock_navigation: bool = True, keep_exit: bool = True
    ):
        self._ui_transition_depth = max(0, int(getattr(self, "_ui_transition_depth", 0))) + 1
        self._ui_transition_message = str(message or "").strip()
        try:
            if lock_navigation:
                self._set_sidebar_locked(True, allow_exit=keep_exit, reset_checks=False)
                for act_name in ("act_manage_stored_catalog", "act_manage_usage_catalog"):
                    action = getattr(self, act_name, None)
                    if action is not None:
                        action.setEnabled(False)
                exit_action = getattr(self, "act_exit_application", None)
                if exit_action is not None:
                    exit_action.setEnabled(bool(keep_exit))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._begin_ui_transition fallback failed", exc_info=True)
        self._set_notifications_enabled(False)
        try:
            self._show_shell_status_message(self._ui_transition_message or _("Working"))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._begin_ui_transition fallback failed", exc_info=True)
        try:
            if getattr(self, "transition_progress", None) is not None:
                detail = self._ui_transition_message or _("Working")
                self.transition_progress.setAccessibleDescription(
                    f"{detail} — {_('Background work is in progress.')}"
                )
                self.transition_progress.setToolTip(detail)
                self.transition_progress.show()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._begin_ui_transition fallback failed", exc_info=True)
        try:
            QApplication.setOverrideCursor(Qt.WaitCursor)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._begin_ui_transition fallback failed", exc_info=True)

    def _end_ui_transition(self, *, restore_shell: bool = False):
        depth = max(0, int(getattr(self, "_ui_transition_depth", 0)) - 1)
        self._ui_transition_depth = depth
        if depth > 0:
            return
        self._ui_transition_message = ""
        try:
            QApplication.restoreOverrideCursor()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._end_ui_transition fallback failed", exc_info=True)
        try:
            self._clear_shell_status_message()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._end_ui_transition fallback failed", exc_info=True)
        try:
            if getattr(self, "transition_progress", None) is not None:
                self.transition_progress.hide()
                self.transition_progress.setToolTip(_("Background work is in progress."))
                self.transition_progress.setAccessibleDescription(
                    _("Background work is in progress.")
                )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._end_ui_transition fallback failed", exc_info=True)
        if restore_shell:
            try:
                if self.app_state.session:
                    self._set_top_bar_visible(True)
                    self._apply_logged_in_shell()
                    self.apply_role_permissions()
                else:
                    self._apply_logged_out_shell(reset_sidebar=False)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowUiMixin._end_ui_transition fallback failed",
                    exc_info=True,
                )

    def apply_role_permissions(self):
        self._refresh_navigation_permissions()
        access_state = self._shell_access_state()
        stored = getattr(self, "act_manage_stored_catalog", None)
        if stored is not None:
            stored.setEnabled(access_state.can_manage_stored_products)
        usage = getattr(self, "act_manage_usage_catalog", None)
        if usage is not None:
            usage.setEnabled(access_state.can_manage_usage_products)
        exit_action = getattr(self, "act_exit_application", None)
        if exit_action is not None:
            exit_action.setEnabled(access_state.can_exit)


logger = logging.getLogger(__name__)
