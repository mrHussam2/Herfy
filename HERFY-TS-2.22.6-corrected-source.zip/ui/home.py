from __future__ import annotations

import logging
from typing import Any, ClassVar

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.i18n import is_rtl
from core.presentation import HomeDashboardPresenter
from core.settings import APP_DEVELOPER_NAME, _, existing_asset_path
from ui.designer import load_ui
from ui.theme import (
    UI_METRICS,
    ResponsiveProfile,
    apply_device_properties,
    apply_profile_properties,
    dashboard_lower_stacks,
    fade_in,
    fluid_content_width,
    layout_mode_for_width,
    make_scaler,
    profile_for_widget,
    slide_fade_in,
)
from ui.widgets import (
    ControllerLifecycleMixin,
    ResizeCallbackMixin,
    apply_button_icon,
    disconnect_app_state_callbacks,
    rebind_app_state_callbacks_if_alive,
)

logger = logging.getLogger(__name__)


class DashboardMetricTile(QFrame):
    """A quiet dashboard metric that can expose its relevant workspace."""

    activated = Signal(str)

    def __init__(self, key: str, route: str | None = None, parent=None) -> None:
        super().__init__(parent)
        self.key = str(key)
        self.route = str(route or "").strip()
        self.setObjectName("MetricTile")
        self.setProperty("uiRole", "metricTile")
        self.setProperty("interactive", bool(self.route))
        self.setAttribute(Qt.WA_Hover, bool(self.route))
        self.setFocusPolicy(Qt.StrongFocus if self.route else Qt.NoFocus)
        if self.route:
            self.setCursor(Qt.PointingHandCursor)

    def activate(self) -> bool:
        if not self.route or not self.isEnabled():
            return False
        self.activated.emit(self.route)
        return True

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802 - Qt API
        if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
            if self.activate():
                event.accept()
                return
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event) -> None:  # noqa: N802 - Qt API
        if event.key() in {Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space} and self.activate():
            event.accept()
            return
        super().keyPressEvent(event)


class HomeDashboardComponentsMixin:
    ACTION_ICONS: ClassVar[dict[str, str]] = {
        "tracking": "products.png",
        "usage": "usage.png",
        "admin": "admin.png",
    }
    STAT_ICONS: ClassVar[dict[str, str]] = {
        "branches": "home.png",
        "tracked": "products.png",
        "expiring": "bell.png",
        "expired": "checkmark.png",
        "usage": "usage.png",
        "stored": "admin.png",
    }
    METRIC_ROUTES: ClassVar[dict[str, str]] = {
        "expired": "tracking",
        "expiring": "tracking",
        "tracked": "tracking",
        "stored": "tracking",
        "usage": "usage",
    }

    def _set_icon_label(self, label: QLabel, icon_name: str, size: int) -> None:
        """Apply a resource icon to a dashboard label."""
        path = existing_asset_path("resources", "images", icon_name)
        if not path:
            return
        pixmap = QPixmap(path)
        if pixmap.isNull():
            return
        label.setPixmap(pixmap.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _create_stat_card(self, key: str) -> dict:
        S = self._S
        route = self.METRIC_ROUTES.get(key)
        card = DashboardMetricTile(key, route)
        if route:
            card.activated.connect(self._navigate_from_metric)
        card.setProperty(
            "statusLevel",
            "urgent" if key == "expired" else "warning" if key == "expiring" else "normal",
        )
        controls = load_ui(
            card,
            "metric_tile",
            required=(
                "HomeStatIcon",
                "HomeStatValue",
                "HomeStatLabel",
                "HomeStatNote",
                "HomeStatAccent",
            ),
        )
        card.setMinimumHeight(S(UI_METRICS.dashboard_metric_tile_min_height))
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        lay: QGridLayout = card.layout()
        lay.setContentsMargins(
            S(UI_METRICS.dashboard_metric_tile_margin_horizontal),
            S(UI_METRICS.dashboard_metric_tile_margin_top),
            S(UI_METRICS.dashboard_metric_tile_margin_horizontal),
            S(UI_METRICS.dashboard_metric_tile_margin_bottom),
        )
        lay.setHorizontalSpacing(S(UI_METRICS.dashboard_metric_tile_horizontal_gap))
        lay.setVerticalSpacing(S(UI_METRICS.dashboard_metric_tile_vertical_gap))
        lay.setColumnStretch(0, 0)
        lay.setColumnStretch(1, 1)
        icon: QLabel = controls["HomeStatIcon"]
        icon.setAlignment(Qt.AlignCenter)
        icon_size = S(UI_METRICS.dashboard_metric_icon_size)
        icon_box = S(UI_METRICS.dashboard_metric_icon_box)
        icon.setMinimumSize(icon_box, icon_box)
        icon.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        self._set_icon_label(icon, self.STAT_ICONS.get(key, ""), icon_size)
        value: QLabel = controls["HomeStatValue"]
        value.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        label: QLabel = controls["HomeStatLabel"]
        label.setWordWrap(True)
        label.setMinimumHeight(label.fontMetrics().height())
        note: QLabel = controls["HomeStatNote"]
        note.setWordWrap(False)
        note.setVisible(False)
        accent: QFrame = controls["HomeStatAccent"]
        accent.setMinimumHeight(S(UI_METRICS.dashboard_metric_accent_height))
        accent.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        return {
            "card": card,
            "route": route,
            "icon": icon,
            "value": value,
            "label": label,
            "note": note,
            "accent": accent,
        }

    def _navigate_from_metric(self, route: str) -> None:
        signal = getattr(self, "navigate_requested", None)
        if signal is not None:
            signal.emit(str(route))

    def _clear_layout(self, layout) -> None:
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            child_layout = item.layout()
            if widget is not None:
                widget.deleteLater()
            elif child_layout is not None:
                self._clear_layout(child_layout)

    def _chip(self, text: str, *, active: bool = False) -> QLabel:
        lbl = QLabel(text)
        lbl.setProperty("chipRole", "active" if active else "default")
        lbl.setObjectName("HomeChip")
        lbl.setAlignment(Qt.AlignCenter)
        lbl.setWordWrap(True)
        lbl.setMinimumWidth(0)
        lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        return lbl


class HomeDashboardControllerMixin(ControllerLifecycleMixin):
    def _app_state_callbacks(self):
        return (
            ("data_changed", self._on_app_state_data_changed),
            ("item_updated", self._on_app_state_data_changed),
            ("item_deleted", self._on_app_state_data_changed),
            ("branch_changed", self._on_app_state_generic_changed),
            ("permissions_changed", self._on_app_state_generic_changed),
            ("user_changed", self._on_app_state_generic_changed),
            ("connection_changed", self._on_app_state_generic_changed),
        )

    def _disconnect_app_state(self) -> None:
        disconnect_app_state_callbacks(
            self,
            self._app_state_callbacks(),
            logger_=logger,
            context="HomeDashboardPage._disconnect_app_state",
        )

    def _on_destroyed(self, *_args) -> None:
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            try:
                registry.close()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Home worker registry close failed", exc_info=True)
        self._disconnect_app_state()
        super()._on_destroyed(*_args)

    def bind_app_state(self, app_state) -> None:
        rebind_app_state_callbacks_if_alive(
            self,
            app_state,
            self._app_state_callbacks(),
            logger_=logger,
            disconnect_context="HomeDashboardPage._disconnect_app_state",
            bind_context="HomeDashboardPage.bind_app_state",
        )

    def _on_app_state_data_changed(self, domain, payload=None) -> None:
        del payload
        if not self._is_alive():
            return
        if str(domain or "").strip().lower() not in {"tracking", "usage", "admin"}:
            return
        if not self._should_refresh_now():
            self._deferred_refresh = True
            return
        self.refresh_dashboard()

    def _on_app_state_generic_changed(self, *_args) -> None:
        if not self._is_alive():
            return
        if not self._should_refresh_now():
            self._deferred_refresh = True
            return
        self.refresh_dashboard()

    def _build_dashboard_snapshot(
        self,
        *,
        profile=None,
        permission_context: Any = None,
        view_branch: str | None = None,
    ) -> dict[str, object]:
        service = self.home_dashboard_service
        snapshot = service.build_snapshot(
            profile=profile,
            permission_context=permission_context,
            view_branch=view_branch,
            is_ar=self._is_ar(),
        )
        return snapshot.as_dict()

    def _run_pending_refresh(self) -> None:
        if not self._is_alive():
            return

        registry = self._worker_registry
        if registry.has_active_key("home:dashboard_refresh"):
            # Keep the currently running generation valid.  Only remember that
            # one latest refresh is required when it finishes.
            self._refresh_pending = True
            return

        kwargs = dict(getattr(self, "_pending_refresh_kwargs", {}) or {})
        generation = getattr(self, "_refresh_generation", 0) + 1
        self._refresh_generation = generation
        self._refresh_pending = False
        dashboard_service = self.home_dashboard_service
        is_ar = self._is_ar()

        def _work(progress_callback=None):
            del progress_callback
            snapshot = dashboard_service.build_snapshot(
                profile=kwargs.get("profile"),
                permission_context=kwargs.get("permission_context"),
                view_branch=kwargs.get("view_branch"),
                is_ar=is_ar,
            )
            return snapshot.as_dict()

        def _on_result(snapshot):
            if generation != getattr(self, "_refresh_generation", 0):
                return
            self._apply_dashboard_snapshot(snapshot or {})

        def _on_finished():
            if not self._is_alive():
                return
            if not bool(getattr(self, "_refresh_pending", False)):
                return
            self._refresh_pending = False
            try:
                self._refresh_timer.start(40)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Failed to schedule coalesced dashboard refresh", exc_info=True)

        worker = registry.start(
            _work,
            on_result=_on_result,
            on_error=lambda message: logger.debug("Home dashboard refresh failed: %s", message),
            on_finished=_on_finished,
            operation_key="home:dashboard_refresh",
            scope_checker=lambda: (
                generation == int(getattr(self, "_refresh_generation", -1) or -1)
                and self._is_alive()
            ),
        )
        if worker is None:
            self._refresh_pending = True
            try:
                self._refresh_timer.start(120)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Failed to retry dashboard refresh submission", exc_info=True)

    def refresh_dashboard(
        self,
        *,
        profile=None,
        permission_context: Any = None,
        view_branch: str | None = None,
    ) -> None:
        if not self._is_alive():
            return
        if not self._should_refresh_now():
            self._deferred_refresh = True
            self._pending_refresh_kwargs = {
                "profile": profile,
                "permission_context": permission_context,
                "view_branch": view_branch,
            }
            return
        self._deferred_refresh = False
        self._pending_refresh_kwargs = {
            "profile": profile,
            "permission_context": permission_context,
            "view_branch": view_branch,
        }
        timer = getattr(self, "_refresh_timer", None)
        if timer is None:
            return
        try:
            timer.start(60)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Failed to start dashboard refresh timer", exc_info=True)


class HomeResponsiveLayoutMixin:
    def _target_stat_columns(
        self, profile: ResponsiveProfile | None = None, mode: str | None = None
    ) -> int:
        """Retain the three-column desktop dashboard while resizing."""
        del profile, mode
        total = max(1, len(getattr(self, "_stat_order", []) or [1]))
        available_width = fluid_content_width(self, fallback=self.width())
        columns = 4 if available_width >= 1080 else 2 if available_width >= 560 else 1
        return min(total, columns)

    def _place_action_buttons(self, *, horizontal: bool) -> None:
        buttons = list(getattr(self, "_action_buttons", []))
        for button in buttons:
            try:
                self.actions_grid.removeWidget(button)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug(
                    "HomeDashboardPage._place_action_buttons fallback failed",
                    exc_info=True,
                )
        for col in range(3):
            self.actions_grid.setColumnStretch(col, 0)
        if horizontal:
            for index, button in enumerate(buttons):
                self.actions_grid.addWidget(button, 0, index)
            for col in range(max(1, len(buttons))):
                self.actions_grid.setColumnStretch(col, 1)
        else:
            for index, button in enumerate(buttons):
                self.actions_grid.addWidget(button, index, 0)
            self.actions_grid.setColumnStretch(0, 1)

    def apply_responsive_profile(
        self, profile: ResponsiveProfile | None = None, mode: str | None = None
    ) -> None:
        self._apply_responsive_layout(force=False, profile=profile, mode=mode)

    def _apply_responsive_layout(
        self,
        *,
        force: bool = False,
        profile: ResponsiveProfile | None = None,
        mode: str | None = None,
    ) -> None:
        profile = profile or profile_for_widget(self, app=QApplication.instance())
        width_for_mode = fluid_content_width(
            self, fallback=int(getattr(profile, "width", 0) or self.width() or 0)
        )
        semantic_mode = str(mode or layout_mode_for_width(width_for_mode)).lower()
        apply_profile_properties(self, profile)
        self.setProperty("layoutMode", semantic_mode)
        root = self.layout()
        if root is not None:
            root.setContentsMargins(
                profile.page_margin, profile.page_margin, profile.page_margin, profile.page_margin
            )
            root.setSpacing(profile.gap)
        content_layout = getattr(self, "content_layout", None)
        if content_layout is not None:
            content_layout.setSpacing(profile.gap)
        height_limited = getattr(profile, "visual_breakpoint", "") in {
            "small_terminal",
            "hd_720",
            "laptop_768",
        }
        if hasattr(self, "status_strip"):
            self.status_strip.setMinimumHeight(
                max(
                    UI_METRICS.page_header_min_height,
                    0
                    if height_limited
                    else self._S(UI_METRICS.dashboard_hero_min_height),
                )
            )
            self.status_strip.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        columns = self._target_stat_columns(profile, semantic_mode)
        if force or columns != getattr(self, "_stat_columns", 0):
            self._stat_columns = columns
            for key in getattr(self, "_stat_order", []):
                self.stats_grid.removeWidget(self.stat_cards[key]["card"])
            for index, key in enumerate(getattr(self, "_stat_order", [])):
                row, col = divmod(index, max(1, columns))
                self.stats_grid.addWidget(self.stat_cards[key]["card"], row, col)
            for col in range(6):
                self.stats_grid.setColumnStretch(col, 1 if col < columns else 0)
        stacked_lower = dashboard_lower_stacks(profile.width, semantic_mode)
        if force or stacked_lower != getattr(self, "_lower_stacked", None):
            self.lower_grid.removeWidget(self.branch_card)
            self.lower_grid.removeWidget(self.actions_card)
            self.lower_grid.setRowStretch(0, 0)
            self.lower_grid.setRowStretch(1, 0)
            self.lower_grid.addWidget(
                self.branch_card, 0, 0, 1, 2 if stacked_lower else 1
            )
            if stacked_lower:
                self.lower_grid.addWidget(self.actions_card, 1, 0, 1, 2)
            else:
                self.lower_grid.addWidget(self.actions_card, 0, 1, 1, 1)
            self._place_action_buttons(horizontal=not stacked_lower)
            self._lower_stacked = stacked_lower
        self.actions_card.setMinimumWidth(
            self._S(
                UI_METRICS.dashboard_actions_card_compact_min_width
                if height_limited
                else UI_METRICS.dashboard_actions_card_min_width
            )
        )
        self.branch_card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
        self.actions_card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)
        self.lower_grid.setColumnStretch(0, 3)
        self.lower_grid.setColumnStretch(1, 2 if not stacked_lower else 0)
        self.lower_grid.setRowStretch(0, 0)
        self.lower_grid.setRowStretch(1, 0)
        for button in getattr(self, "_action_buttons", []):
            button.setMinimumHeight(
                profile.touch_target
                if profile.touch_mode
                else UI_METRICS.toolbar_control_height
            )
        height_limited = getattr(profile, "visual_breakpoint", "") in {
            "small_terminal",
            "hd_720",
            "laptop_768",
        }
        stat_min_height = (
            48
            if getattr(profile, "visual_breakpoint", "") == "small_terminal"
            else 46 if height_limited else 50 if profile.touch_mode else 58
        )
        for info in getattr(self, "stat_cards", {}).values():
            info["card"].setMinimumHeight(stat_min_height)
            info["card"].setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)


class HomeUiBuilderMixin(HomeDashboardComponentsMixin):
    def _build_ui(self) -> None:
        S = self._S
        controls = load_ui(
            self,
            "dashboard_page",
            required=(
                "DashboardStatusStrip",
                "HomeLogo",
                "HomeWelcomeTitle",
                "HomeProductIntro",
                "HomeDeveloperInfo",
                "HomeChipsWrap",
                "ContentHost",
                "dashboard_stats_host",
                "dashboard_lower_host",
                "dashboard_branch_card",
                "dashboard_branches_title",
                "dashboard_branches_subtitle",
                "HomeBranchesWrap",
                "dashboard_actions_card",
                "dashboard_actions_title",
                "dashboard_actions_subtitle",
                "dashboard_track_action",
                "dashboard_usage_action",
            ),
        )
        root = self.findChild(QVBoxLayout, "dashboard_root_layout")
        root.setContentsMargins(
            S(UI_METRICS.dashboard_root_spacing),
            S(UI_METRICS.dashboard_root_spacing),
            S(UI_METRICS.dashboard_root_spacing),
            S(UI_METRICS.dashboard_root_spacing),
        )
        root.setSpacing(S(UI_METRICS.dashboard_root_spacing))
        root.setStretch(0, 0)
        root.setStretch(1, 1)
        apply_device_properties(self, self.width(), QApplication.instance())
        self.setProperty("layoutMode", "grid")
        self.status_strip = controls["DashboardStatusStrip"]
        self.status_strip.setProperty("uiRole", "dashboardStatusStrip")
        self.home_logo = controls["HomeLogo"]
        self.home_logo.setAccessibleName(_("HERFY logo"))
        self.home_logo.setProperty("uiRole", "homeLogo")
        self.home_logo.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
        logo_path = existing_asset_path("resources", "images", "logo.png")
        logo = QPixmap(logo_path) if logo_path else QPixmap()
        if logo.isNull():
            self.home_logo.setText(_("HERFY"))
            self.home_logo.setProperty("uiRole", "logoMissing")
        else:
            self.home_logo.setPixmap(
                logo.scaled(
                    S(56),
                    S(44),
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation,
                )
            )
        self.lbl_welcome_title = controls["HomeWelcomeTitle"]
        self.lbl_welcome_title.setText(_("Welcome"))
        self.lbl_product_intro = controls["HomeProductIntro"]
        self.lbl_product_intro.setObjectName("HomeProductIntro")
        self.lbl_product_intro.setText(
            _("Product Expiry Tracking • Monthly Usage • Sales Analysis")
        )
        self.lbl_product_intro.setWordWrap(True)
        self.developer_info = controls["HomeDeveloperInfo"]
        self.developer_info.setText(
            _("Developer: {developer}").format(developer=APP_DEVELOPER_NAME)
        )
        self.developer_info.setWordWrap(True)
        self.developer_info.setProperty("textRole", "homeDeveloperInfo")
        self.chips_wrap = controls["HomeChipsWrap"]
        self.chips_layout = self.findChild(QHBoxLayout, "dashboard_chips_layout")
        self.content_host = controls["ContentHost"]
        self.content_host.setWidgetResizable(True)
        self.content_host.setMinimumSize(0, 0)
        self.content_host.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.content_layout = self.findChild(QVBoxLayout, "dashboard_content_layout")
        self.content_layout.setSpacing(S(UI_METRICS.dashboard_root_spacing))
        self.status_strip.show()
        self.stats_host = controls["dashboard_stats_host"]
        self.stats_grid = self.findChild(QGridLayout, "dashboard_stats_grid")
        self.stat_cards = {
            key: self._create_stat_card(key)
            for key in ("branches", "tracked", "expiring", "expired")
        }
        # The landing workspace must expose the live operational state, not
        # just navigation. Risk indicators lead so an expired product is never
        # visually buried beneath catalog totals.
        self._stat_order = ("expired", "expiring", "tracked", "branches")
        default_labels = {
            "branches": _("Authorized branches"),
            "tracked": _("Tracked items"),
            "expiring": _("Expiring soon"),
            "expired": _("Expired products"),
        }
        for key, info in self.stat_cards.items():
            info["value"].setText("—")
            info["label"].setText(default_labels[key])
            info["card"].show()
        self.stats_host.show()
        self._stat_columns = 0
        self._lower_stacked = None
        self.lower_grid = self.findChild(QGridLayout, "dashboard_lower_grid")
        self.branch_card = controls["dashboard_branch_card"]
        self.branch_card.setProperty("uiRole", "gridPanel")
        self.lbl_branches_title = controls["dashboard_branches_title"]
        self.lbl_branches_title.setProperty("textRole", "homeSectionTitle")
        self.lbl_branches_subtitle = controls["dashboard_branches_subtitle"]
        self.lbl_branches_subtitle.setProperty("textRole", "homeSectionSubtitle")
        self.lbl_branches_subtitle.hide()
        self.branches_wrap = controls["HomeBranchesWrap"]
        self.branches_layout = self.findChild(QGridLayout, "dashboard_branches_grid")
        self.actions_card = controls["dashboard_actions_card"]
        self.actions_card.setProperty("uiRole", "gridPanel")
        self.lbl_actions_title = controls["dashboard_actions_title"]
        self.lbl_actions_title.setProperty("textRole", "homeSectionTitle")
        self.lbl_actions_subtitle = controls["dashboard_actions_subtitle"]
        self.lbl_actions_subtitle.setProperty("textRole", "homeSectionSubtitle")
        self.lbl_actions_subtitle.hide()
        self.actions_grid = self.findChild(QGridLayout, "dashboard_actions_grid")
        self.btn_track = controls["dashboard_track_action"]
        self.btn_usage = controls["dashboard_usage_action"]
        for key, button in (("tracking", self.btn_track), ("usage", self.btn_usage)):
            button.setCursor(Qt.PointingHandCursor)
            # These are the two dashboard calls to action.  They deliberately
            # share the sidebar's branded gradient rather than looking like
            # disconnected white toolbar controls.
            button.setProperty("variant", "primary")
            button.setMinimumHeight(S(UI_METRICS.toolbar_control_height))
            button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            apply_button_icon(
                button, self.ACTION_ICONS[key], size=S(UI_METRICS.dashboard_action_icon_size)
            )
            button.clicked.connect(
                lambda _checked=False, route=key: self.navigate_requested.emit(route)
            )
        self._action_buttons = [self.btn_track, self.btn_usage]
        self._apply_responsive_layout(force=True)


class HomeDashboardPage(
    HomeResponsiveLayoutMixin,
    HomeUiBuilderMixin,
    ResizeCallbackMixin,
    HomeDashboardControllerMixin,
    QWidget,
):
    resize_callback_name = "_apply_responsive_layout"
    navigate_requested = Signal(str)

    def __init__(self, *, dashboard_service, worker_registry):
        super().__init__()
        self._S = make_scaler(QApplication.instance())
        self.setObjectName("HomePage")
        self.setProperty("uiScope", "dashboard")
        self.setProperty("nativeWorkspace", True)
        if dashboard_service is None:
            raise RuntimeError("HomeDashboardPage requires the composed HomeDashboardService")
        self.home_dashboard_service = dashboard_service
        if worker_registry is None:
            raise RuntimeError("HomeDashboardPage requires a composed worker scope")
        self._worker_registry = worker_registry
        self._refresh_generation = 0
        self._refresh_pending = False
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setSingleShot(True)
        self._refresh_timer.timeout.connect(self._run_pending_refresh)
        self._pending_refresh_kwargs = {}
        self._bound_app_state = None
        self._disposed = False
        self._deferred_refresh = False
        self.destroyed.connect(self._on_destroyed)
        self._build_ui()

    def _is_ar(self) -> bool:
        return is_rtl()

    def _apply_dashboard_snapshot(self, snapshot: dict[str, object]) -> None:
        values = dict(snapshot.get("values") or {})
        data_available = dict(snapshot.get("data_available") or {})
        allowed = list(snapshot.get("allowed") or [])
        active_branch = str(snapshot.get("active_branch") or "").strip()
        presenter_state = HomeDashboardPresenter.build_from_payload(snapshot)
        self.lbl_welcome_title.setText(presenter_state.greeting)
        self.lbl_branches_title.setText(presenter_state.branches_title)
        self.lbl_branches_subtitle.setText(presenter_state.branches_subtitle)
        self.lbl_branches_subtitle.setVisible(bool(presenter_state.branches_subtitle))
        self.lbl_actions_title.setText(presenter_state.actions_title)
        self.lbl_actions_subtitle.setText(presenter_state.actions_subtitle)
        self.lbl_actions_subtitle.setVisible(bool(presenter_state.actions_subtitle))
        self.btn_track.setText(presenter_state.track_text)
        self.btn_usage.setText(presenter_state.usage_text)
        self._clear_layout(self.chips_layout)
        visible_chips = list(presenter_state.top_chips)
        for text in visible_chips:
            self.chips_layout.addWidget(self._chip(text, active=False))
        self.chips_layout.addStretch(1)
        for key, info in self.stat_cards.items():
            has_value = key in values
            available = bool(data_available.get(key, has_value))
            if not has_value or not available:
                info["value"].setText("—")
                info["note"].setText(_("Unavailable"))
                info["note"].setVisible(True)
            else:
                info["value"].setText(str(values[key]))
                info["note"].clear()
                info["note"].hide()
            info["label"].setText(presenter_state.stat_labels[key])
            route = str(info.get("route") or "")
            if route:
                action = _("Open tracking") if route == "tracking" else _("Open usage")
                info["card"].setEnabled(
                    presenter_state.can_open_tracking
                    if route == "tracking"
                    else presenter_state.can_open_usage
                )
                info["card"].setToolTip(action)
                info["card"].setAccessibleName(
                    f"{info['value'].text()} {presenter_state.stat_labels[key]}"
                )
                info["card"].setAccessibleDescription(action)
        self._clear_layout(self.branches_layout)
        if allowed:
            self.branches_wrap.show()
            active_norm = active_branch.lower() if active_branch else ""
            column_count = 4 if len(allowed) > 3 else max(1, len(allowed))
            for index, branch in enumerate(allowed):
                row, col = divmod(index, column_count)
                self.branches_layout.addWidget(
                    self._chip(
                        branch,
                        active=branch.lower() == active_norm and bool(active_norm),
                    ),
                    row,
                    col,
                )
            for col in range(column_count):
                self.branches_layout.setColumnStretch(col, 1)
        else:
            # Do not replace an unavailable data region with a large empty
            # message.  The workspace stays focused on its actionable
            # controls and the region returns when the authorized scope does.
            self.branches_wrap.hide()
        self.btn_track.setEnabled(presenter_state.can_open_tracking)
        self.btn_usage.setEnabled(presenter_state.can_open_usage)
        fade_in(self.stats_host, duration=160, start=0.72)

    def showEvent(self, event):
        super().showEvent(event)
        if not bool(getattr(self, "_entrance_animated", False)):
            self._entrance_animated = True
            slide_fade_in(self.status_strip, distance=10, duration=220)
            fade_in(self.stats_host, duration=260, start=0.0)
        if getattr(self, "_deferred_refresh", False):
            self._deferred_refresh = False
            self.refresh_dashboard()


def create_home_page(*, dashboard_service, worker_registry) -> HomeDashboardPage:
    page = HomeDashboardPage(
        dashboard_service=dashboard_service,
        worker_registry=worker_registry,
    )
    try:
        page.refresh_dashboard()
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("create_home_page fallback failed", exc_info=True)
    return page


__all__ = ["HomeDashboardPage", "create_home_page"]
