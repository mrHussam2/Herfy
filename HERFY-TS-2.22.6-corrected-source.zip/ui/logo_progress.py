"""Dynamic HERFY mark progress rendering for the update experience."""

from __future__ import annotations

from PySide6.QtCore import Property, QEasingCurve, QPropertyAnimation, QRect, QSize, Qt
from PySide6.QtGui import QColor, QPainter, QPixmap
from PySide6.QtWidgets import QWidget

from core.settings import resource_path


class HerfyLogoProgress(QWidget):
    """Paint the HERFY mark as a real determinate or indeterminate progress indicator."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("UpdateLogoProgress")
        self.setMinimumSize(104, 104)
        self._progress = 0.0
        self._indeterminate_phase = 0.0
        self._indeterminate = False
        self._source = QPixmap(resource_path("resources", "images", "logo.png"))
        self._tinted_cache: QPixmap | None = None
        self._progress_animation = QPropertyAnimation(self, b"progress", self)
        self._progress_animation.setDuration(280)
        self._progress_animation.setEasingCurve(QEasingCurve.OutCubic)
        self._indeterminate_animation = QPropertyAnimation(self, b"indeterminatePhase", self)
        self._indeterminate_animation.setDuration(1200)
        self._indeterminate_animation.setStartValue(0.0)
        self._indeterminate_animation.setEndValue(1.0)
        self._indeterminate_animation.setLoopCount(-1)
        self._indeterminate_animation.setEasingCurve(QEasingCurve.InOutSine)

    def sizeHint(self) -> QSize:  # noqa: N802 - Qt API
        return QSize(132, 132)

    def _get_progress(self) -> float:
        return self._progress

    def _set_progress(self, value: float) -> None:
        self._progress = max(0.0, min(100.0, float(value)))
        self.update()

    progress = Property(float, _get_progress, _set_progress)

    def _get_indeterminate_phase(self) -> float:
        return self._indeterminate_phase

    def _set_indeterminate_phase(self, value: float) -> None:
        self._indeterminate_phase = max(0.0, min(1.0, float(value)))
        self.update()

    indeterminatePhase = Property(float, _get_indeterminate_phase, _set_indeterminate_phase)

    @property
    def fill_fraction(self) -> float:
        """Expose the exact determinate ratio used by the logo fill."""
        return self._progress / 100.0

    @property
    def is_indeterminate(self) -> bool:
        return self._indeterminate

    def set_progress(self, value: int | float, *, animated: bool = True) -> None:
        self.set_indeterminate(False)
        target = max(0.0, min(100.0, float(value)))
        self._progress_animation.stop()
        if not animated:
            self._set_progress(target)
            return
        self._progress_animation.setStartValue(self._progress)
        self._progress_animation.setEndValue(target)
        self._progress_animation.start()

    def set_indeterminate(self, enabled: bool) -> None:
        enabled = bool(enabled)
        if self._indeterminate == enabled:
            return
        self._indeterminate = enabled
        if enabled:
            self._progress_animation.stop()
            self._indeterminate_animation.start()
        else:
            self._indeterminate_animation.stop()
            self._indeterminate_phase = 0.0
        self.update()

    def _tinted_logo(self) -> QPixmap:
        if self._tinted_cache is not None:
            return self._tinted_cache
        if self._source.isNull():
            return QPixmap()
        tinted = QPixmap(self._source.size())
        tinted.fill(Qt.transparent)
        painter = QPainter(tinted)
        painter.drawPixmap(0, 0, self._source)
        painter.setCompositionMode(QPainter.CompositionMode_SourceIn)
        painter.fillRect(tinted.rect(), QColor("#C92331"))
        painter.end()

        self._tinted_cache = tinted
        return tinted

    def _draw_logo(self, painter: QPainter, logo: QPixmap) -> QRect:
        if logo.isNull():
            return QRect()
        area = self.contentsRect().adjusted(8, 8, -8, -8)
        scaled_size = logo.size().scaled(area.size(), Qt.KeepAspectRatio)
        target = QRect(0, 0, scaled_size.width(), scaled_size.height())
        target.moveCenter(area.center())
        painter.drawPixmap(target, logo)
        return target

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt API
        del event
        if self._source.isNull():
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.SmoothPixmapTransform)
        # The neutral mark is intentionally faint. The coloured mark below is
        # clipped to an exact fraction of the mark bounds, rather than drawing
        # a decorative progress shape beside the logo.
        painter.setOpacity(0.14)
        target = self._draw_logo(painter, self._source)
        painter.setOpacity(1.0)
        if target.isNull():
            painter.end()
            return
        tinted = self._tinted_logo()
        if self._indeterminate:
            wave_height = max(12, int(target.height() * 0.30))
            bottom = target.bottom() - int(
                (target.height() + wave_height) * self._indeterminate_phase
            )
            wave = QRect(target.left(), bottom - wave_height, target.width(), wave_height)
            painter.save()
            painter.setClipRect(wave.intersected(target))
            self._draw_logo(painter, tinted)
            painter.restore()
        else:
            filled_height = int(target.height() * self.fill_fraction)
            fill = QRect(
                target.left(), target.bottom() - filled_height + 1, target.width(), filled_height
            )
            painter.save()
            painter.setClipRect(fill)
            self._draw_logo(painter, tinted)
            painter.restore()
        painter.end()


# Kept as a source-compatible name for existing update surfaces. New code uses
# the domain-specific public name so startup and updater share one renderer.
LogoProgressWidget = HerfyLogoProgress

__all__ = ["HerfyLogoProgress", "LogoProgressWidget"]
