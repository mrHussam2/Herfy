from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QGridLayout,
    QLabel,
    QLineEdit,
    QListView,
    QListWidgetItem,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QWidget,
)

from core.i18n import available_languages, get_language, tr
from core.presentation import SettingsState
from core.settings import _
from ui.designer import load_ui
from ui.dialogs import apply_dialog_basics, show_question_message
from ui.login import PasswordField
from ui.settings_controller import SettingsController
from ui.theme import (
    UI_METRICS,
    ResponsiveResizeMixin,
    apply_profile_properties,
    ensure_layout_mode_controller,
)
from ui.widgets import InlineNoticeMixin


class SettingsDialog(InlineNoticeMixin, ResponsiveResizeMixin, QDialog):
    """Canonical independent settings surface.

    Local presentation/notification preferences stay client-local. Account
    security reads and mutates only through server-authoritative contracts.
    """

    expiry_runtime_settings_applied = Signal()
    settings_saved = Signal(object)
    password_changed = Signal(object)

    _PAGES = (
        ("application", "settings.general.title"),
        ("expiry", "settings.expiry.title"),
        ("notifications", "settings.notifications.title"),
        ("sounds", "settings.sounds.title"),
        ("account", "settings.account_security.title"),
        ("status", "settings.status.title"),
    )

    def __init__(
        self,
        app_state: Any,
        settings_service: Any,
        presentation_preferences: Any,
        cloud_runtime: Any,
        account_security_service: Any,
        worker_registry,
        parent=None,
    ) -> None:
        super().__init__(parent)
        self.app_state = app_state
        if cloud_runtime is None:
            raise RuntimeError("SettingsDialog requires composed cloud runtime")
        self.cloud_runtime = cloud_runtime
        self.controller = SettingsController(
            settings_service,
            presentation_preferences,
            account_security_service,
            worker_registry,
            self,
        )
        self._closed = False
        self._widgets: dict[str, QWidget] = {}
        self._rows: list[tuple[str, QWidget, str]] = []
        self._page_by_key: dict[str, QWidget] = {}
        self._startup_language = str(get_language() or "en")
        self.language_restart_required = False
        self._password_policy_valid = False
        apply_dialog_basics(
            self,
            object_name="SettingsDialog",
            modal=False,
            size_grip=True,
        )
        self.setWindowTitle(tr("settings.title"))
        self.setMinimumSize(0, 0)
        self._build_ui()
        self._desktop_field_max_widths = self._capture_desktop_field_max_widths()
        self._responsive_controller = ensure_layout_mode_controller(self)
        self._responsive_controller.reflowRequested.connect(self._apply_responsive_layout)
        self._responsive_controller.schedule(force=True)
        self._bind_controller()
        self.controller.load()

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        controls = load_ui(
            self,
            "settings_dialog",
            required=(
                "SettingsSearch",
                "SettingsNavigation",
                "SettingsStack",
                "SettingsInlineNotice",
                "settings_discard",
                "settings_save",
                "SettingsNavigationPanel",
                "SettingsContentPanel",
                "settings_footer_layout",
                "settings_workspace_layout",
            ),
        )
        self.search = controls["SettingsSearch"]
        self.search.setPlaceholderText(_("Search settings"))
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._apply_search)
        self.navigation_panel = controls["SettingsNavigationPanel"]
        self.content_panel = controls["SettingsContentPanel"]
        self.workspace_grid: QGridLayout = controls["settings_workspace_layout"]
        self.navigation = controls["SettingsNavigation"]
        self.navigation.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.navigation.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.stack = controls["SettingsStack"]
        self.notice = controls["SettingsInlineNotice"]
        self.notice.setWordWrap(True)
        self.notice.hide()
        self.footer_grid: QGridLayout = controls["settings_footer_layout"]
        self.discard_button = controls["settings_discard"]
        self.discard_button.setText(_("Discard"))
        self.discard_button.setProperty("variant", "secondary")
        self.save_button = controls["settings_save"]
        self.save_button.setText(_("Save"))
        self.save_button.setProperty("variant", "primary")
        self.discard_button.clicked.connect(self._discard)
        self.save_button.clicked.connect(self._save)
        for key, label_key in self._PAGES:
            item = QListWidgetItem(tr(label_key))
            item.setData(Qt.UserRole, key)
            self.navigation.addItem(item)
            page = getattr(self, f"_build_{key}_page")()
            self._page_by_key[key] = page
            self.stack.addWidget(page)
        self.navigation.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.navigation.setCurrentRow(0)

    def _page(self, key: str) -> QScrollArea:
        """Mount each potentially long settings form in a responsive scroll surface."""
        page = QScrollArea(self)
        page.setObjectName(f"SettingsScroll_{key}")
        page.setWidgetResizable(True)
        page.setFrameShape(QScrollArea.NoFrame)
        content = QWidget(page)
        load_ui(
            content,
            "settings_" + key,
            required=("SettingsSection",),
        )
        page.setWidget(content)
        form = content.findChild(QFormLayout, "settings_" + key + "_form")
        if form is None:
            raise RuntimeError(f"Settings page {key} is missing its canonical form layout")
        form.setContentsMargins(14, 12, 14, 12)
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(8)
        form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        form.setRowWrapPolicy(QFormLayout.WrapLongRows)
        for row in range(form.rowCount()):
            item = form.itemAt(row, QFormLayout.LabelRole)
            label = item.widget() if item is not None else None
            if isinstance(label, QLabel):
                label.setProperty("textRole", "fieldLabel")
        form.setLabelAlignment(Qt.AlignLeading | Qt.AlignVCenter)
        return page

    def _register(
        self, page_key: str, key: str, widget: QWidget, label: str, keywords: str = ""
    ) -> None:
        self._widgets[key] = widget
        text = " ".join((label, keywords, key)).casefold()
        self._rows.append((page_key, widget, text))

    def _field(
        self, page: QWidget, page_key: str, key: str, label: str, keywords: str = ""
    ) -> QWidget:
        widget = page.findChild(QWidget, key)
        if widget is None:
            raise RuntimeError(f"Settings page {page_key} is missing {key}")
        caption = page.findChild(QLabel, "label_" + key)
        if caption is not None:
            caption.setText(label)
        elif isinstance(widget, (QCheckBox, QPushButton)):
            widget.setText(label)
        self._register(page_key, key, widget, label, keywords)
        if isinstance(widget, QCheckBox):
            widget.toggled.connect(self._update_dirty_state)
        elif isinstance(widget, QSpinBox):
            widget.valueChanged.connect(self._update_dirty_state)
        elif isinstance(widget, QLineEdit):
            widget.textChanged.connect(self._update_dirty_state)
        elif isinstance(widget, QComboBox):
            widget.currentIndexChanged.connect(self._update_dirty_state)
        return widget

    def _build_application_page(self) -> QWidget:
        page = self._page("application")
        language: QComboBox = self._field(page, "application", "language", _("Language"))
        language.setMaximumWidth(UI_METRICS.settings_select_field_max_width)
        for code in available_languages():
            language.addItem(tr(f"settings.language.{code}"), code)
        language.currentIndexChanged.connect(self._on_language_preview)
        scale: QComboBox = self._field(page, "application", "ui_scale_percent", _("UI scale"))
        scale.setMaximumWidth(UI_METRICS.settings_select_field_max_width)
        for percent in (90, 100, 110, 125):
            scale.addItem(f"{percent}%", percent)
        self._field(page, "application", "start_with_windows", _("Start with Windows"))
        self._field(
            page,
            "application",
            "check_updates_on_startup",
            _("Check for updates on startup"),
        )
        return page

    def _build_expiry_page(self) -> QWidget:
        page = self._page("expiry")
        self._field(page, "expiry", "monitoring_enabled", _("Enable local expiry monitoring"))
        self._field(page, "expiry", "expiry_enable_status_colors", _("Show expiry status colors"))
        self._field(page, "expiry", "expiry_enable_status_icons", _("Show expiry status icons"))
        return page

    def _build_notifications_page(self) -> QWidget:
        page = self._page("notifications")
        self._field(
            page, "notifications", "enable_desktop_notifications", _("Windows notifications")
        )
        self.test_notification_button = page.findChild(QPushButton, "test_notification_button")
        self.test_notification_button.setText(_("Test notification"))
        self.test_notification_button.setProperty("variant", "secondary")
        self.test_notification_button.clicked.connect(self._test_notification)
        self._rows.append(
            ("notifications", self.test_notification_button, "notification windows test")
        )
        return page

    def _test_notification(self) -> None:
        owner = self.parent()
        service = getattr(owner, "notifications_service", None)
        if service is None or not hasattr(service, "test_local_notification"):
            self._show_notice(_("Notification service is unavailable."), "error")
            return

        self.test_notification_button.setEnabled(False)
        self._show_notice(_("Sending Windows notification test..."), "info")

        def _result(delivered: bool, backend: str) -> None:
            try:
                self.test_notification_button.setEnabled(True)
                if delivered and str(backend).upper() in {
                    "WINDOWS_WINRT",
                    "WIN10TOAST",
                    "WINDOWS_NOTIFICATION",
                }:
                    self._show_notice(_("Windows notification delivered."), "success")
                elif delivered:
                    self._show_notice(
                        _("Windows toast was unavailable; tray fallback delivered."), "warning"
                    )
                else:
                    self._show_notice(
                        _("Notification delivery failed. Check Windows notification settings."),
                        "error",
                    )
            except RuntimeError:
                return

        accepted = bool(service.test_local_notification(on_result=_result))
        if not accepted:
            self.test_notification_button.setEnabled(True)
            self._show_notice(
                _("Notification delivery failed. Check Windows notification settings."), "error"
            )

    def _build_sounds_page(self) -> QWidget:
        page = self._page("sounds")
        self._field(page, "sounds", "enable_sounds", _("Enable sounds"))
        for key, label in (
            ("notification_sound_soon", _("Expiring soon")),
            ("notification_sound_approaching", _("Approaching expiry")),
            ("notification_sound_near", _("Near expiry")),
            ("notification_sound_tomorrow", _("Expires tomorrow")),
            ("notification_sound_today", _("Expires today")),
        ):
            edit: QLineEdit = self._field(page, "sounds", key, label, "sound")
            edit.setMaximumWidth(UI_METRICS.settings_text_field_max_width)
        return page

    def _build_account_page(self) -> QWidget:
        page = self._page("account")
        self.account_policy = page.findChild(QLabel, "account_policy")
        self.account_policy.setText(_("Loading password policy..."))
        self.account_policy.setWordWrap(True)
        page.findChild(QLabel, "label_account_policy").setText(_("Password policy"))
        for attribute, host_name, caption in (
            ("current_password", "current_password_host", _("Current Password")),
            ("new_password", "new_password_host", _("New Password")),
            ("confirm_password", "confirm_password_host", _("Confirm New Password")),
        ):
            host = page.findChild(QWidget, host_name)
            field = PasswordField(host)
            field.setMaximumWidth(UI_METRICS.settings_text_field_max_width)
            host.layout().addWidget(field)
            setattr(self, attribute, field)
            page.findChild(QLabel, "label_" + host_name).setText(caption)
        self.change_password_button = page.findChild(QPushButton, "change_password_button")
        self.change_password_button.setText(_("Change Password"))
        self.change_password_button.setProperty("variant", "primary")
        self.change_password_button.clicked.connect(self._change_password)
        self._rows.append(("account", self.change_password_button, "password account security"))
        return page

    def _build_status_page(self) -> QWidget:
        page = self._page("status")
        for attribute, caption in (
            ("status_runtime", _("Session")),
            ("status_server", _("Server")),
            ("status_notifications", _("Windows notifications")),
        ):
            status = page.findChild(QLabel, attribute)
            status.setProperty("settingsStatus", True)
            setattr(self, attribute, status)
            page.findChild(QLabel, "label_" + attribute).setText(caption)
        return page

    # -------------------------------------------------------------- controller
    def _bind_controller(self) -> None:
        self.controller.loaded.connect(self._load_state)
        self.controller.saved.connect(self._on_saved)
        self.controller.policy_loaded.connect(self._on_policy)
        self.controller.password_changed.connect(self._on_password_changed)
        self.controller.error.connect(lambda text: self._show_notice(text, "error"))
        self.controller.busy_changed.connect(self._on_busy)

    def _load_state(self, state: SettingsState) -> None:
        for key, widget in self._widgets.items():
            value = getattr(state, key, None)
            if isinstance(widget, QCheckBox):
                widget.blockSignals(True)
                widget.setChecked(bool(value))
                widget.blockSignals(False)
            elif isinstance(widget, QSpinBox):
                widget.blockSignals(True)
                widget.setValue(int(value or 0))
                widget.blockSignals(False)
            elif isinstance(widget, QComboBox):
                widget.blockSignals(True)
                index = widget.findData(value)
                if index < 0:
                    index = widget.findData(str(value))
                if index >= 0:
                    widget.setCurrentIndex(index)
                widget.blockSignals(False)
            elif isinstance(widget, QLineEdit):
                widget.blockSignals(True)
                widget.setText(str(value or ""))
                widget.blockSignals(False)
        self._refresh_status(state)
        self._update_dirty_state()

    def _collect(self) -> dict[str, Any]:
        values: dict[str, Any] = {}
        for key, widget in self._widgets.items():
            if isinstance(widget, QCheckBox):
                values[key] = widget.isChecked()
            elif isinstance(widget, QSpinBox):
                values[key] = widget.value()
            elif isinstance(widget, QComboBox):
                values[key] = widget.currentData()
            elif isinstance(widget, QLineEdit):
                values[key] = widget.text().strip()
        return values

    def _save(self) -> None:
        self.controller.save(self._collect())

    def _on_saved(self, result: object) -> None:
        changed = bool(getattr(result, "expiry_runtime_settings_changed", False))
        language = str(self._collect().get("language") or "")
        self.language_restart_required = language != self._startup_language
        if changed:
            self.expiry_runtime_settings_applied.emit()
        self.settings_saved.emit(result)
        if self.language_restart_required:
            self._show_notice(
                _("Settings saved. Restart HERFY-TS to apply the language change."),
                "success",
            )
        else:
            self._show_notice(_("Settings saved."), "success")
        self._update_dirty_state()

    def _discard(self) -> None:
        self.controller.load()
        self._show_notice(_("Unsaved changes discarded."), "info")

    def _update_dirty_state(self, *_args) -> None:
        current = self._collect() if self._widgets else {}
        original = self.controller.state.original
        dirty = any(current.get(k) != original.get(k) for k in current)
        self.save_button.setEnabled(dirty)
        self.discard_button.setEnabled(dirty)

    def _on_language_preview(self, *_args) -> None:
        # Language/layout is applied atomically on the next process start.
        # Do not leave a partially translated live window by flipping direction here.
        self._update_dirty_state()
        widget = self._widgets.get("language")
        selected = str(widget.currentData() or "") if isinstance(widget, QComboBox) else ""
        message = _("Language changes apply after restarting HERFY-TS.")
        if selected and selected != self._startup_language:
            self._show_notice(message, "info")
        elif self.notice.text() == message:
            self._show_notice("", "info")

    def _on_policy(self, policy: object) -> None:
        data = dict(policy) if isinstance(policy, dict) else {}
        if not data:
            self.account_policy.setText(
                _("Unable to load password requirements.")
                if self.controller.state.online
                else _("Server connection is required to load password requirements.")
            )
            self._password_policy_valid = False
            self.change_password_button.setEnabled(False)
            return
        valid_lengths = all(
            not isinstance(data.get(key), bool) for key in ("min_length", "max_length")
        )
        try:
            minimum = int(data.get("min_length", 1))
            maximum = int(data.get("max_length", 128))
        except (OverflowError, TypeError, ValueError):
            minimum = maximum = 0
        valid_flags = all(
            isinstance(data.get(key, False), bool)
            for key in ("require_letter", "require_digit")
        )
        if (
            not valid_lengths
            or not valid_flags
            or minimum < 1
            or maximum < minimum
            or maximum > 2_147_483_647
        ):
            self.account_policy.setText(_("Password requirements are unavailable."))
            self._password_policy_valid = False
            self.change_password_button.setEnabled(False)
            return
        self._password_policy_valid = True
        has_complexity_rules = (
            minimum > 1 or bool(data.get("require_letter")) or bool(data.get("require_digit"))
        )
        parts = (
            []
            if not has_complexity_rules
            else [_("Minimum {count} characters").format(count=minimum)]
        )
        if data.get("require_letter"):
            parts.append(_("at least one letter"))
        if data.get("require_digit"):
            parts.append(_("at least one digit"))
        self.account_policy.setText(
            " • ".join(parts) if parts else _("Choose any non-empty password.")
        )
        for field in (self.current_password, self.new_password, self.confirm_password):
            field.edit.setMaxLength(maximum)
        self.change_password_button.setEnabled(True)

    def _change_password(self) -> None:
        current = self.current_password.text()
        new = self.new_password.text()
        confirm = self.confirm_password.text()
        if not current or not new or not confirm:
            self._show_notice(_("All password fields are required."), "warning")
            return
        if new != confirm:
            self._show_notice(_("New password and confirmation do not match."), "warning")
            return
        self.controller.change_password(current, new)

    def _on_password_changed(self, result: object) -> None:
        payload = dict(result) if isinstance(result, dict) else {}
        if payload.get("ok") is not True:
            self._show_notice(_("Failed to change password."), "error")
            return
        for field in (self.current_password, self.new_password, self.confirm_password):
            field.clear()
        self._show_notice(
            _("Password changed. Sign in again to refresh account authority."), "success"
        )
        self.password_changed.emit(payload)

    def _refresh_status(self, state: SettingsState) -> None:
        session = getattr(self.app_state, "session", None)
        online = bool(self.cloud_runtime.connected())
        self.status_runtime.setText(_("Authenticated") if session else _("Signed out"))
        self.status_server.setText(_("Connected") if online else _("Offline"))
        self.status_notifications.setText(
            _("Enabled") if state.enable_desktop_notifications else _("Disabled")
        )

    def _on_busy(self, busy: bool, operation: str) -> None:
        if busy:
            self.save_button.setEnabled(False)
            self.discard_button.setEnabled(False)
            self.change_password_button.setEnabled(False)
            self._show_notice(_("Working..."), "info")
            return
        self._update_dirty_state()
        self.change_password_button.setEnabled(
            self._password_policy_valid and self.controller.state.online
        )

    def _apply_search(self, text: str) -> None:
        query = str(text or "").strip().casefold()
        page_matches: dict[str, int] = {key: 0 for key, _ in self._PAGES}
        page_title_matches: set[str] = set()
        for row in range(self.navigation.count()):
            item = self.navigation.item(row)
            key = str(item.data(Qt.UserRole) or "")
            if query and query in item.text().casefold():
                page_title_matches.add(key)

        for page_key, widget, searchable in self._rows:
            match = (not query) or page_key in page_title_matches or query in searchable
            widget.setVisible(match)
            parent = widget.parentWidget()
            form = parent.layout() if parent is not None else None
            if isinstance(form, QFormLayout):
                label = form.labelForField(widget)
                if label is not None:
                    label.setVisible(match)
            if match:
                page_matches[page_key] += 1

        for row in range(self.navigation.count()):
            item = self.navigation.item(row)
            key = str(item.data(Qt.UserRole) or "")
            item.setHidden(
                bool(query) and page_matches.get(key, 0) == 0 and key not in page_title_matches
            )
        if query:
            for row in range(self.navigation.count()):
                item = self.navigation.item(row)
                if not item.isHidden():
                    self.navigation.setCurrentRow(row)
                    break

    def open_page(self, key: str) -> None:
        wanted = str(key or "")
        for row in range(self.navigation.count()):
            item = self.navigation.item(row)
            if item.data(Qt.UserRole) == wanted:
                self.navigation.setCurrentRow(row)
                break

    def _capture_desktop_field_max_widths(self) -> dict[QWidget, int]:
        widgets = list(self._widgets.values())
        for name in ("current_password", "new_password", "confirm_password"):
            widget = getattr(self, name, None)
            if isinstance(widget, QWidget):
                widgets.append(widget)
        result: dict[QWidget, int] = {}
        for widget in widgets:
            try:
                result[widget] = int(widget.maximumWidth())
            except (RuntimeError, TypeError, ValueError):
                continue
        return result

    def _apply_responsive_field_widths(self, *, fluid: bool) -> None:
        max_widget_extent = 16777215
        for widget, desktop_max in self._desktop_field_max_widths.items():
            try:
                widget.setMaximumWidth(max_widget_extent if fluid else int(desktop_max))
            except (RuntimeError, TypeError, ValueError):
                continue

    def _apply_responsive_layout(self, mode: str, profile) -> None:
        apply_profile_properties(self, profile)
        narrow = False
        compact = False
        fluid_fields = bool(narrow or compact)

        self.workspace_grid.removeWidget(self.navigation_panel)
        self.workspace_grid.removeWidget(self.content_panel)
        self.workspace_grid.setColumnStretch(0, 0)
        self.workspace_grid.setColumnStretch(1, 0)
        self.workspace_grid.setRowStretch(0, 0)
        self.workspace_grid.setRowStretch(1, 0)
        if narrow:
            self.workspace_grid.addWidget(self.navigation_panel, 0, 0)
            self.workspace_grid.addWidget(self.content_panel, 1, 0)
            self.workspace_grid.setRowStretch(1, 1)
            self.navigation.setFlow(QListView.LeftToRight)
            self.navigation.setWrapping(False)
            self.navigation.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
            self.navigation.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        else:
            self.workspace_grid.addWidget(self.navigation_panel, 0, 0)
            self.workspace_grid.addWidget(self.content_panel, 0, 1)
            self.workspace_grid.setColumnStretch(1, 1)
            self.navigation.setFlow(QListView.TopToBottom)
            self.navigation.setWrapping(False)
            self.navigation.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.navigation.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._apply_responsive_field_widths(fluid=fluid_fields)
        self.navigation_panel.setMinimumWidth(0 if narrow else 112 if compact else 146)
        self.navigation_panel.setMaximumWidth(16777215 if narrow else 144 if compact else 172)
        self.navigation_panel.setMaximumHeight(52 if narrow else 16777215)
        self.search.setMaximumWidth(16777215 if narrow else 280 if compact else 320)
        for page in self._page_by_key.values():
            form = page.findChild(QFormLayout)
            if form is not None:
                form.setRowWrapPolicy(
                    QFormLayout.DontWrapRows
                )

        for widget in (self.notice, self.discard_button, self.save_button):
            self.footer_grid.removeWidget(widget)
        for column in range(3):
            self.footer_grid.setColumnStretch(column, 0)
        if narrow:
            self.footer_grid.addWidget(self.notice, 0, 0, 1, 2)
            self.footer_grid.addWidget(self.discard_button, 1, 0)
            self.footer_grid.addWidget(self.save_button, 1, 1)
            self.footer_grid.setColumnStretch(0, 1)
            self.footer_grid.setColumnStretch(1, 1)
        else:
            self.footer_grid.addWidget(self.notice, 0, 0)
            self.footer_grid.addWidget(self.discard_button, 0, 1)
            self.footer_grid.addWidget(self.save_button, 0, 2)
            self.footer_grid.setColumnStretch(0, 1)

    def closeEvent(self, event) -> None:
        if self.save_button.isEnabled():
            answer = show_question_message(
                self,
                _("Unsaved changes"),
                _("Discard unsaved settings changes?")
            )
            if not answer:
                event.ignore()
                return
        self._closed = True
        self.controller.close()
        super().closeEvent(event)
