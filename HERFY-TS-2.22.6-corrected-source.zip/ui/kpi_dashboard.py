from __future__ import annotations

from PySide6 import QtCore, QtGui, QtWidgets
from PySide6.QtCharts import (
    QBarCategoryAxis,
    QBarSeries,
    QBarSet,
    QCategoryAxis,
    QChart,
    QChartView,
    QLineSeries,
    QPieSeries,
    QValueAxis,
)

from services.kpi_analytics import ChannelMetric, DashboardSnapshot
from services.kpi_validation import format_money as _money
from ui.kpi_designer import load_kpi_ui, require_object, require_widget
from ui.kpi_models import TopLevelRowsTableModel
from ui.theme_metrics import UI_METRICS

_MUTED = "#69788a"
_GREEN = "#23835c"
_RED = "#c75146"
_PALETTE = ("#246b91", "#37a187", "#e1a34d", "#8374b8", "#4a91b8", "#9a7655")


class DashboardTableModel(TopLevelRowsTableModel):
    HEADERS = (
        "Branch",
        "Channel",
        "Sales",
        "Compare",
        "Difference",
        "YoY",
        "GC",
        "Compare GC",
        "APC",
        "Compare APC",
    )

    def __init__(self, parent: QtCore.QObject | None = None) -> None:
        super().__init__(parent)
        self._snapshot: DashboardSnapshot | None = None
        self._rows: tuple[ChannelMetric, ...] = ()

    def columnCount(
        self,
        parent: QtCore.QModelIndex | QtCore.QPersistentModelIndex | None = None,
    ) -> int:
        return 0 if parent is not None and parent.isValid() else len(self.HEADERS)

    def headerData(
        self,
        section: int,
        orientation: QtCore.Qt.Orientation,
        role: int = QtCore.Qt.ItemDataRole.DisplayRole,
    ) -> str | None:
        if role != QtCore.Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == QtCore.Qt.Orientation.Horizontal:
            return self.HEADERS[section]
        return str(section + 1)

    def data(
        self,
        index: QtCore.QModelIndex | QtCore.QPersistentModelIndex,
        role: int = QtCore.Qt.ItemDataRole.DisplayRole,
    ) -> object | None:
        if not index.isValid() or self._snapshot is None:
            return None
        metric = self._rows[index.row()]
        difference = metric.sales_difference
        if role == QtCore.Qt.ItemDataRole.ForegroundRole and index.column() == 4:
            if difference is None or difference == 0:
                return QtGui.QBrush(QtGui.QColor(_MUTED))
            color = _GREEN if difference > 0 else _RED
            return QtGui.QBrush(QtGui.QColor(color))
        if (
            role == QtCore.Qt.ItemDataRole.BackgroundRole
            and metric.channel == "Total Net sale & GCs"
        ):
            return QtGui.QBrush(QtGui.QColor("#e5f3ec"))
        if role == QtCore.Qt.ItemDataRole.FontRole and index.column() == 4:
            font = QtGui.QFont()
            font.setWeight(QtGui.QFont.Weight.DemiBold)
            return font
        if role == QtCore.Qt.ItemDataRole.FontRole and metric.channel == "Total Net sale & GCs":
            font = QtGui.QFont()
            font.setBold(True)
            return font
        if role == QtCore.Qt.ItemDataRole.TextAlignmentRole and index.column() >= 2:
            return int(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
        if role != QtCore.Qt.ItemDataRole.DisplayRole:
            return None

        values: tuple[str, ...] = (
            self._snapshot.branch,
            metric.channel,
            _money(metric.current_sales),
            _money(metric.compare_sales),
            _money(difference),
            (f"{metric.sales_growth:.1%}" if metric.sales_growth is not None else "—"),
            "—" if metric.current_gc is None else f"{metric.current_gc:,}",
            "—" if metric.compare_gc is None else f"{metric.compare_gc:,}",
            _money(metric.current_apc),
            _money(metric.compare_apc),
        )
        return values[index.column()]

    def set_snapshot(
        self,
        snapshot: DashboardSnapshot | None,
        channel_filter: str | None = None,
    ) -> None:
        self.beginResetModel()
        self._snapshot = snapshot
        if snapshot is None:
            self._rows = ()
        else:
            self._rows = tuple(
                [
                    metric
                    for metric in snapshot.channels
                    if channel_filter is None or metric.channel == channel_filter
                ]
                + [snapshot.report_total]
            )
        self.endResetModel()

    def channel_at(self, row: int) -> str | None:
        if 0 <= row < len(self._rows):
            channel = self._rows[row].channel
            return channel if channel != "Total Net sale & GCs" else None
        return None


class InteractiveDashboard(QtWidgets.QWidget):
    channelSelected = QtCore.Signal(str)
    channelFilterChanged = QtCore.Signal(str)

    def __init__(self, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self.snapshot: DashboardSnapshot | None = None
        self._bar_channel_names: tuple[str, ...] = ()
        self.table_model = DashboardTableModel(self)
        self.form = QtWidgets.QWidget(self)
        load_kpi_ui(self.form, "kpi_analytics")
        self.analytics_scroll_area = require_widget(
            self.form,
            QtWidgets.QScrollArea,
            "analyticsScrollArea",
        )
        self.analytics_scroll_area.setWidgetResizable(True)
        self.analytics_scroll_area.setHorizontalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.analytics_scroll_area.setVerticalScrollBarPolicy(
            QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.analytics_scroll_area.viewport().installEventFilter(self)
        self._grid_columns = 0
        self._filter_layout_compact: bool | None = None
        self.analytics_hero = require_widget(self.form, QtWidgets.QFrame, "analyticsHero")
        self.analytics_hero.setProperty("uiRole", "analyticsHero")
        self.analytics_summary = require_widget(self.form, QtWidgets.QLabel, "analyticsSummary")
        self.analytics_scope_badge = require_widget(
            self.form, QtWidgets.QLabel, "analyticsScopeBadge"
        )
        self.analytics_scope_badge.setProperty("analyticsState", "empty")
        self.analytics_scope_badge.setSizePolicy(
            QtWidgets.QSizePolicy.Maximum, QtWidgets.QSizePolicy.Fixed
        )
        require_object(self.form, QtWidgets.QGridLayout, "analyticsHeroLayout").setColumnStretch(
            0, 1
        )
        self.analytics_interaction_hint = require_widget(
            self.form, QtWidgets.QLabel, "analyticsInteractionHint"
        )
        self.analytics_eyebrow = require_widget(self.form, QtWidgets.QLabel, "analyticsEyebrow")
        self.analytics_title = require_widget(self.form, QtWidgets.QLabel, "analyticsTitle")
        self.analytics_eyebrow.setText("SALES KPI")
        self.analytics_title.setText("Performance overview")
        self.analytics_interaction_hint.hide()
        require_object(self.form, QtWidgets.QGridLayout, "analyticsHeroLayout").setContentsMargins(
            10, 6, 10, 6
        )
        self.selection_status = require_widget(
            self.form, QtWidgets.QLabel, "channelSelectionStatus"
        )
        self.selection_status.setMinimumWidth(0)
        self.selection_status.setWordWrap(True)
        content_layout = require_object(
            self.form,
            QtWidgets.QVBoxLayout,
            "analyticsContentLayout",
        )
        content_layout.setContentsMargins(
            UI_METRICS.analytics_outer_margin,
            UI_METRICS.analytics_outer_margin,
            UI_METRICS.analytics_outer_margin,
            UI_METRICS.analytics_outer_margin,
        )
        content_layout.setSpacing(UI_METRICS.analytics_section_gap)
        self.dashboard_filter_layout = require_object(
            self.form,
            QtWidgets.QHBoxLayout,
            "dashboardFilterLayout",
        )
        self.dashboard_filter_title = require_widget(self.form, QtWidgets.QLabel, "sectionTitle")
        self.channel_filter_label = require_widget(
            self.form, QtWidgets.QLabel, "channelFilterLabel"
        )
        cards_layout = require_object(self.form, QtWidgets.QGridLayout, "metricCardsLayout")
        charts_layout = require_object(self.form, QtWidgets.QGridLayout, "chartCardsLayout")
        self.cards_layout = cards_layout
        self.charts_layout = charts_layout
        cards_layout.setSpacing(UI_METRICS.analytics_card_gap)
        charts_layout.setSpacing(UI_METRICS.analytics_chart_gap)
        for name, layout_name in (
            ("salesCard", "salesCardLayout"),
            ("growthCard", "growthCardLayout"),
            ("guestsCard", "guestsCardLayout"),
            ("averageCard", "averageCardLayout"),
        ):
            card = require_widget(self.form, QtWidgets.QFrame, name)
            card.setMinimumSize(
                0,
                UI_METRICS.analytics_card_min_height,
            )
            require_object(card, QtWidgets.QVBoxLayout, layout_name).setContentsMargins(
                UI_METRICS.analytics_card_padding,
                UI_METRICS.analytics_card_padding,
                UI_METRICS.analytics_card_padding,
                UI_METRICS.analytics_card_padding,
            )
        for name in ("mixCard", "differenceCard", "trendCard"):
            chart_card = require_widget(self.form, QtWidgets.QFrame, name)
            chart_card.setMinimumSize(
                0,
                UI_METRICS.analytics_chart_min_height,
            )
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.form)
        self.channel_filter = require_widget(
            self.form,
            QtWidgets.QComboBox,
            "channelFilter",
        )
        self.table = require_widget(self.form, QtWidgets.QTableView, "analyticsTable")
        for card_name in (
            "salesCard",
            "growthCard",
            "guestsCard",
            "averageCard",
            "mixCard",
            "differenceCard",
            "trendCard",
        ):
            require_widget(self.form, QtWidgets.QFrame, card_name).setProperty("uiRole", "card")
        for card_name, tone in (
            ("salesCard", "ocean"),
            ("growthCard", "violet"),
            ("guestsCard", "teal"),
            ("averageCard", "gold"),
            ("mixCard", "ocean"),
            ("differenceCard", "violet"),
            ("trendCard", "teal"),
        ):
            require_widget(self.form, QtWidgets.QFrame, card_name).setProperty(
                "analyticsTone", tone
            )
        self.sales_title = require_widget(self.form, QtWidgets.QLabel, "salesTitle")
        self.sales_value = require_widget(self.form, QtWidgets.QLabel, "salesValue")
        self.sales_detail = require_widget(self.form, QtWidgets.QLabel, "salesDetail")
        self.growth_value = require_widget(self.form, QtWidgets.QLabel, "growthValue")
        self.growth_detail = require_widget(self.form, QtWidgets.QLabel, "growthDetail")
        self.guests_value = require_widget(self.form, QtWidgets.QLabel, "guestsValue")
        self.guests_detail = require_widget(self.form, QtWidgets.QLabel, "guestsDetail")
        self.average_value = require_widget(self.form, QtWidgets.QLabel, "averageValue")
        self.average_detail = require_widget(self.form, QtWidgets.QLabel, "averageDetail")
        self.mix_chart = self._install_chart("mixChartHost", "mixChartLayout")
        self.difference_chart = self._install_chart("differenceChartHost", "differenceChartLayout")
        self.trend_chart = self._install_chart("trendChartHost", "trendChartLayout")
        self.table.setModel(self.table_model)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(
            QtWidgets.QHeaderView.ResizeMode.ResizeToContents
        )
        self.table.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.table.verticalHeader().setDefaultSectionSize(30)
        self.channel_filter.addItem("All channels", "")
        self.channel_filter.currentIndexChanged.connect(self._emit_filter_changed)
        self.table.clicked.connect(self._table_row_clicked)
        self._reflow_cards()

    def eventFilter(self, watched, event):  # noqa: N802 - Qt API
        if event.type() == QtCore.QEvent.Type.Resize and hasattr(self, "cards_layout"):
            self._reflow_cards()
        return super().eventFilter(watched, event)

    def _reflow_cards(self) -> None:
        compact_filters = False
        if compact_filters != self._filter_layout_compact:
            self._filter_layout_compact = compact_filters
            self.dashboard_filter_layout.setDirection(
                QtWidgets.QBoxLayout.Direction.TopToBottom
                if compact_filters
                else QtWidgets.QBoxLayout.Direction.LeftToRight
            )
            for label in (self.dashboard_filter_title, self.channel_filter_label):
                label.setWordWrap(compact_filters)
                label.setMinimumWidth(0)
            self.channel_filter.setMinimumWidth(0 if compact_filters else 148)
            spacer = self.dashboard_filter_layout.itemAt(1).spacerItem()
            if spacer is not None:
                spacer.changeSize(0 if compact_filters else 40, 0)
            self.dashboard_filter_layout.invalidate()
        columns = 4
        chart_columns = 2
        signature = (columns, chart_columns)
        if self._grid_columns == signature:
            return
        self._grid_columns = signature
        for layout, names, count in (
            (self.cards_layout, ("salesCard", "growthCard", "guestsCard", "averageCard"), columns),
            (self.charts_layout, ("mixCard", "differenceCard"), chart_columns),
        ):
            for column in range(layout.columnCount()):
                layout.setColumnStretch(column, 0)
            for name in names:
                layout.removeWidget(require_widget(self.form, QtWidgets.QFrame, name))
            for index, name in enumerate(names):
                layout.addWidget(
                    require_widget(self.form, QtWidgets.QFrame, name), index // count, index % count
                )
            for column in range(count):
                layout.setColumnStretch(column, 1)

    def _install_chart(self, host_name: str, layout_name: str) -> QChart:
        host = require_widget(self.form, QtWidgets.QWidget, host_name)
        chart_layout = require_object(
            host,
            QtWidgets.QVBoxLayout,
            layout_name,
        )
        chart = QChart()
        chart.setBackgroundVisible(False)
        chart.setTitle("")
        chart.legend().setVisible(True)
        chart.legend().setAlignment(QtCore.Qt.AlignmentFlag.AlignBottom)
        chart.legend().setLabelColor(QtGui.QColor(_MUTED))
        chart_view = QChartView(chart, host)
        chart_view.setRenderHint(QtGui.QPainter.RenderHint.Antialiasing)
        chart.setMargins(QtCore.QMargins(4, 4, 4, 4))
        chart_view.setMinimumHeight(180)
        chart_view.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        chart_layout.addWidget(chart_view, 1)
        return chart

    @QtCore.Slot()
    def _emit_filter_changed(self) -> None:
        self.channelFilterChanged.emit(str(self.channel_filter.currentData() or ""))

    @QtCore.Slot(QtCore.QModelIndex)
    def _table_row_clicked(self, index: QtCore.QModelIndex) -> None:
        if not index.isValid() or self.snapshot is None:
            return
        channel = self.table_model.channel_at(index.row())
        if channel is not None:
            self.channelSelected.emit(channel)

    def set_channels(self, channels: tuple[str, ...]) -> None:
        selected = str(self.channel_filter.currentData() or "")
        self.channel_filter.blockSignals(True)
        self.channel_filter.clear()
        self.channel_filter.addItem("All channels", "")
        for channel in channels:
            self.channel_filter.addItem(channel, channel)
        self.channel_filter.setCurrentIndex(max(0, self.channel_filter.findData(selected)))
        self.channel_filter.blockSignals(False)

    @QtCore.Slot(object, str)
    def set_snapshot(
        self,
        snapshot: DashboardSnapshot | None,
        channel_filter: str = "",
    ) -> None:
        self.snapshot = snapshot
        self.table_model.set_snapshot(snapshot, channel_filter or None)
        if snapshot is None:
            self._clear_dashboard()
            return
        self._set_context_summary(snapshot, channel_filter)
        self._set_cards(snapshot)
        self._draw_mix(snapshot, channel_filter)
        self._draw_differences(snapshot, channel_filter)
        self._draw_trend(snapshot)

    def _clear_dashboard(self) -> None:
        for widget in (
            self.analytics_summary,
            self.analytics_scope_badge,
            self.selection_status,
        ):
            widget.hide()
        for value_label in (
            self.sales_value,
            self.growth_value,
            self.guests_value,
            self.average_value,
        ):
            value_label.setText("—")
        for detail_label in (
            self.sales_detail,
            self.growth_detail,
            self.guests_detail,
            self.average_detail,
        ):
            detail_label.setText(" ")
        for chart in (self.mix_chart, self.difference_chart, self.trend_chart):
            chart.removeAllSeries()
            for axis in chart.axes():
                chart.removeAxis(axis)

    def _set_context_summary(self, snapshot: DashboardSnapshot, channel_filter: str) -> None:
        for widget in (
            self.analytics_summary,
            self.analytics_scope_badge,
            self.selection_status,
        ):
            widget.show()
        scope = channel_filter or "all channels"
        comparison = (
            f" compared with {snapshot.compare_year}"
            if snapshot.compare_year is not None
            else " without a comparison year"
        )
        self.analytics_summary.setText(
            f"{snapshot.branch} · {snapshot.current_year}{comparison} · focus: {scope}."
        )
        self.analytics_scope_badge.setText("Focused channel" if channel_filter else "All channels")
        self.analytics_scope_badge.setProperty(
            "analyticsState", "focused" if channel_filter else "ready"
        )
        self.selection_status.setText(
            f"Showing {channel_filter}. Click another channel to refocus the analysis."
            if channel_filter
            else "All channels are included. Click a chart segment, bar or table row to focus."
        )
        self.analytics_scope_badge.style().unpolish(self.analytics_scope_badge)
        self.analytics_scope_badge.style().polish(self.analytics_scope_badge)

    def _set_cards(self, snapshot: DashboardSnapshot) -> None:
        self.sales_title.setText(f"Net sales · {snapshot.current_year}")
        self.sales_value.setText(_money(snapshot.current_net_sales))
        self.sales_detail.setText("All report categories · charges included")
        comparison_label = (
            str(snapshot.compare_year) if snapshot.compare_year is not None else "prior year"
        )
        growth = snapshot.sales_growth
        growth_text = "—" if growth is None else f"{growth:+.1%}"
        difference = snapshot.sales_difference
        detail = (
            "No comparison selected"
            if difference is None
            else f"{_money(difference)} vs {comparison_label}"
        )
        self.growth_value.setText(growth_text)
        self.growth_detail.setText(detail)
        current_gc = "—" if snapshot.current_gc is None else f"{snapshot.current_gc:,}"
        compare_gc = "—" if snapshot.compare_gc is None else f"{snapshot.compare_gc:,}"
        self.guests_value.setText(current_gc)
        self.guests_detail.setText(f"{compare_gc} in {comparison_label}")
        self.average_value.setText(_money(snapshot.current_apc))
        self.average_detail.setText(f"Current year average · GC {current_gc}")
        growth_state = "positive" if difference is not None and difference >= 0 else "negative"
        self.growth_value.setProperty("trend", growth_state)
        self.growth_value.style().unpolish(self.growth_value)
        self.growth_value.style().polish(self.growth_value)

    def _draw_mix(self, snapshot: DashboardSnapshot, channel_filter: str) -> None:
        chart = self.mix_chart
        chart.removeAllSeries()
        for axis in chart.axes():
            chart.removeAxis(axis)
        series = QPieSeries()
        series.setHoleSize(0.62)
        metrics = [
            metric
            for metric in snapshot.channels
            if metric.current_sales is not None and metric.current_sales > 0
        ]
        for index, metric in enumerate(metrics):
            pie_slice = series.append(metric.channel, float(metric.current_sales or 0))
            pie_slice.setColor(QtGui.QColor(_PALETTE[index % len(_PALETTE)]))
            if metric.channel == channel_filter:
                pie_slice.setExploded(True)
                pie_slice.setExplodeDistanceFactor(0.08)
            pie_slice.clicked.connect(
                lambda *args, selected=metric.channel: self.channelSelected.emit(selected)
            )
        if metrics:
            chart.addSeries(series)
        chart.legend().setVisible(bool(metrics))

    def _draw_differences(self, snapshot: DashboardSnapshot, channel_filter: str) -> None:
        chart = self.difference_chart
        chart.removeAllSeries()
        for axis in chart.axes():
            chart.removeAxis(axis)
        metrics = [
            metric
            for metric in snapshot.channels
            if metric.sales_difference is not None
            and (not channel_filter or metric.channel == channel_filter)
        ]
        if not metrics:
            chart.legend().setVisible(False)
            return
        categories = [metric.channel for metric in metrics]
        positive_set = QBarSet("Increase")
        negative_set = QBarSet("Decrease")
        positive_set.setColor(QtGui.QColor(_GREEN))
        negative_set.setColor(QtGui.QColor(_RED))
        for metric in metrics:
            delta = float(metric.sales_difference or 0)
            positive_set.append(max(delta, 0.0))
            negative_set.append(min(delta, 0.0))
        series = QBarSeries()
        series.append(positive_set)
        series.append(negative_set)
        positive_set.clicked.connect(lambda index: self._emit_bar_channel(metrics, index))
        negative_set.clicked.connect(lambda index: self._emit_bar_channel(metrics, index))
        chart.addSeries(series)
        axis = QBarCategoryAxis()
        axis.append(categories)
        chart.addAxis(axis, QtCore.Qt.AlignmentFlag.AlignBottom)
        series.attachAxis(axis)
        value_axis = QValueAxis()
        value_axis.setLabelFormat("%.0f")
        value_axis.setTitleText("Sales")
        chart.addAxis(value_axis, QtCore.Qt.AlignmentFlag.AlignLeft)
        series.attachAxis(value_axis)
        chart.legend().setVisible(True)

    def _draw_trend(self, snapshot: DashboardSnapshot) -> None:
        chart = self.trend_chart
        chart.removeAllSeries()
        for axis in chart.axes():
            chart.removeAxis(axis)
        current = QLineSeries()
        current.setName(str(snapshot.current_year))
        current.setColor(QtGui.QColor("#246b91"))
        comparison = QLineSeries()
        comparison.setName(
            str(snapshot.compare_year) if snapshot.compare_year is not None else "Comparison"
        )
        comparison.setColor(QtGui.QColor("#a8b5c2"))
        for point in snapshot.monthly_sales:
            if point.current_sales is not None:
                current.append(point.month, float(point.current_sales))
            if point.compare_sales is not None:
                comparison.append(point.month, float(point.compare_sales))
        chart.addSeries(current)
        if snapshot.compare_year is not None:
            chart.addSeries(comparison)
        month_axis = QCategoryAxis()
        month_axis.setRange(0.5, 12.5)
        month_axis.setLabelsPosition(QCategoryAxis.AxisLabelsPosition.AxisLabelsPositionOnValue)
        for month, label in enumerate(
            ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"),
            start=1,
        ):
            month_axis.append(label, month)
        chart.addAxis(month_axis, QtCore.Qt.AlignmentFlag.AlignBottom)
        current.attachAxis(month_axis)
        if snapshot.compare_year is not None:
            comparison.attachAxis(month_axis)
        values = [
            float(point.current_sales)
            for point in snapshot.monthly_sales
            if point.current_sales is not None
        ] + [
            float(point.compare_sales)
            for point in snapshot.monthly_sales
            if point.compare_sales is not None
        ]
        if not values:
            chart.legend().setVisible(False)
            return
        value_axis = QValueAxis()
        if values:
            low, high = min(values), max(values)
            margin = max((high - low) * 0.12, abs(high) * 0.03, 1.0)
            value_axis.setRange(min(0.0, low - margin), high + margin)
        value_axis.setLabelFormat("%.0f")
        chart.addAxis(value_axis, QtCore.Qt.AlignmentFlag.AlignLeft)
        current.attachAxis(value_axis)
        if snapshot.compare_year is not None:
            comparison.attachAxis(value_axis)
        chart.legend().setVisible(snapshot.compare_year is not None)

    def _emit_bar_channel(self, metrics: list[ChannelMetric], index: int) -> None:
        if 0 <= index < len(metrics):
            self.channelSelected.emit(metrics[index].channel)

    def select_channel(self, channel: str) -> None:
        index = self.channel_filter.findData(channel)
        if index >= 0:
            self.channel_filter.setCurrentIndex(index)
