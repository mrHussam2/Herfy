from __future__ import annotations

import logging

from PySide6.QtWidgets import QSystemTrayIcon

from core.notifications import parse_notification_activation_uri
from core.settings import APP_DISPLAY_NAME, _
from infra.tray import SystemTrayAdapter
from ui.notification_views import NotificationsPopupMenu
from ui.widgets import set_widget_enabled, tray_icon_or_fallback

logger = logging.getLogger(__name__)


"""Main-window notification history, popup, and tray behavior."""


class MainWindowNotificationsMixin:
    def _queue_notification_persist(
        self,
        items: list[dict] | None = None,
        *,
        ledger_ack: dict | None = None,
        ledger_acks: list[dict] | None = None,
    ) -> None:
        """Persist the latest notification snapshot away from the Qt thread.

        Repeated read/ack/clear clicks collapse into one SQLite write while ledger
        acknowledgements are accumulated so no explicit acknowledgement is lost.
        """
        registry = getattr(self, "_worker_registry", None)
        runtime = getattr(getattr(self, "runtime", None), "notification_runtime_service", None)
        if registry is None or runtime is None:
            return
        snapshot = [
            dict(item)
            for item in list(
                items if items is not None else getattr(self, "notifications_list", []) or []
            )
            if isinstance(item, dict)
        ]
        pending = getattr(self, "_notification_persist_pending", None)
        if not isinstance(pending, dict):
            pending = {"items": snapshot, "acks": []}
        else:
            pending["items"] = snapshot
        for ack in list(ledger_acks or []):
            if isinstance(ack, dict):
                pending["acks"].append(dict(ack))
        if isinstance(ledger_ack, dict):
            pending["acks"].append(dict(ledger_ack))
        self._notification_persist_pending = pending
        if registry.has_active_key("notifications:persist"):
            return

        current = self._notification_persist_pending
        self._notification_persist_pending = None
        username = str(
            getattr(getattr(getattr(self, "app_state", None), "current_user", None), "username", "")
            or ""
        ).strip()

        def _work(progress_callback=None, cancel_callback=None):
            del progress_callback
            for ack in list(current.get("acks") or []):
                if callable(cancel_callback) and cancel_callback():
                    return None
                runtime.acknowledge_ledger(ack)
            if callable(cancel_callback) and cancel_callback():
                return None
            runtime.persist_history(username, list(current.get("items") or []))
            return None

        def _finished():
            queued = getattr(self, "_notification_persist_pending", None)
            if isinstance(queued, dict):
                self._queue_notification_persist(
                    list(queued.get("items") or []),
                    ledger_acks=list(queued.get("acks") or []),
                )

        worker = self._start_logged_worker(
            _work,
            on_finished=_finished,
            warning_message="Notification state persistence failed",
            operation_key="notifications:persist",
        )
        if worker is None and getattr(self, "_notification_persist_pending", None) is None:
            self._notification_persist_pending = current

    def _show_notifications_popup_from_memory(self) -> None:
        popup = getattr(self, "_notifications_popup", None)
        if popup is None:
            popup = NotificationsPopupMenu(self)
            popup.panel.mark_all_requested.connect(self.mark_all_notifications_read)
            popup.panel.clear_all_requested.connect(self.clear_notifications)
            popup.panel.mark_one_requested.connect(self.mark_notification_read)
            popup.panel.acknowledge_requested.connect(self.acknowledge_notification)
            popup.dismissed.connect(self._release_notifications_popup)
            self._notifications_popup = popup
        self._sync_notifications_popup_direction()
        if popup.isVisible():
            popup.dismiss()
            return
        popup.set_notifications(list(getattr(self, "notifications_list", []) or []))
        popup.show_near(getattr(self, "notif_wrap", self.btn_notifications))

    def _activate_notification_uri(self, uri: str) -> None:
        """Handle a Windows protocol activation inside the authenticated session.

        URI fields are routing hints only. Branch access is always revalidated
        against the current server-derived PermissionContext before navigation.
        If Windows starts HERFY from a toast while session restore is still in
        progress, keep the activation in memory and consume it only after the
        server-authoritative session has been restored.
        """
        action, payload = parse_notification_activation_uri(uri)
        if not action:
            logger.warning("NOTIFICATION_ACTIVATION_REJECTED reason=invalid_uri")
            return
        logger.info("NOTIFICATION_ACTIVATION_RECEIVED action=%s", action)
        access_state = self._shell_access_state()
        context = self.cloud_sync_runtime_service.permission_context()
        if not access_state.has_session or not context.is_active or context.must_change_password:
            self._pending_notification_activation_uri = str(uri or "").strip()
            logger.info("NOTIFICATION_ACTIVATION_DEFERRED action=%s", action)
            self._restore_from_tray()
            return
        self._pending_notification_activation_uri = ""
        if action == "notifications":
            self._restore_from_tray()
            self.on_show_notifications()
            return
        if action == "notification":
            self._activate_notification_payload(payload)

    def _consume_pending_notification_activation(self) -> None:
        uri = str(getattr(self, "_pending_notification_activation_uri", "") or "").strip()
        if not uri:
            return
        self._activate_notification_uri(uri)

    def _activate_notification_payload(self, payload: dict | None) -> None:
        data = dict(payload or {})
        access_state = self._shell_access_state()
        if not access_state.has_session or not access_state.can_open_tracking:
            return
        context = self.cloud_sync_runtime_service.permission_context()
        if not context.is_active or context.must_change_password:
            return
        branch = str(data.get("branch") or data.get("branch_id") or "").strip()
        material = str(
            data.get("material_number") or data.get("product_id") or data.get("material") or ""
        ).strip()
        if branch and not context.can_view_branch(branch):
            logger.warning("Notification activation rejected for out-of-scope branch: %s", branch)
            return
        self._restore_from_tray()
        self.show_track()
        page = getattr(self, "track_page", None)
        focus = getattr(page, "focus_notification_target", None)
        if callable(focus):
            focus(branch=branch, material_number=material)

    def _release_notifications_popup(self) -> None:
        """Clear the owner reference after the Qt popup has ended its lifecycle."""
        self._notifications_popup = None

    def _hide_notifications_popup(self) -> None:
        popup = getattr(self, "_notifications_popup", None)
        if popup is None:
            return
        try:
            popup.dismiss()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("Unable to dismiss notifications popup", exc_info=True)

    def _refresh_notifications_ui(self, items=None) -> None:
        data = (
            list(getattr(self, "notifications_list", []) or [])
            if items is None
            else list(items or [])
        )
        try:
            if getattr(self, "notifications_service", None) is not None:
                self.notifications_service.update_badge()
            self._update_tray_badge()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._refresh_notifications_ui fallback failed",
                exc_info=True,
            )
        try:
            popup = getattr(self, "_notifications_popup", None)
            if popup is not None:
                popup.set_notifications(data)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._refresh_notifications_ui fallback failed",
                exc_info=True,
            )

    def _sync_notifications_popup_direction(self) -> None:
        try:
            popup = getattr(self, "_notifications_popup", None)
            if popup is not None:
                popup.apply_language_layout()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._sync_notifications_popup_direction fallback failed",
                exc_info=True,
            )

    def _set_notifications_enabled(self, enabled: bool) -> None:
        set_widget_enabled(getattr(self, "btn_notifications", None), enabled)

    def _restore_notification_history_async(self, *, show_panel: bool = False) -> None:
        """Restore persisted notification history off the Qt thread and merge live items."""
        runtime = getattr(getattr(self, "runtime", None), "notification_runtime_service", None)
        registry = getattr(self, "_worker_registry", None)
        username = str(
            getattr(getattr(getattr(self, "app_state", None), "current_user", None), "username", "")
            or ""
        ).strip()
        if runtime is None or registry is None or not username:
            if show_panel:
                self._show_notifications_popup_from_memory()
            return
        if show_panel:
            self._notification_popup_show_after_restore = True
        if registry.has_active_key("notifications:restore"):
            return

        def _work(progress_callback=None, cancel_callback=None):
            del progress_callback
            if callable(cancel_callback) and cancel_callback():
                return []
            return runtime.load_history(username)

        def _apply(restored):
            current_username = str(
                getattr(
                    getattr(getattr(self, "app_state", None), "current_user", None), "username", ""
                )
                or ""
            ).strip()
            if current_username != username:
                return
            persisted = [dict(item) for item in restored or [] if isinstance(item, dict)]
            live = [
                dict(item)
                for item in list(getattr(self, "notifications_list", []) or [])
                if isinstance(item, dict)
            ]
            merged, _changed = runtime.merge_history(persisted, live)
            self.notifications_list = merged
            self.unread_notifications = runtime.unread_count(merged)
            self._refresh_notifications_ui(merged)
            if bool(getattr(self, "_notification_popup_show_after_restore", False)):
                self._notification_popup_show_after_restore = False
                self._show_notifications_popup_from_memory()

        def _finished():
            if bool(getattr(self, "_notification_popup_show_after_restore", False)) and not list(
                getattr(self, "notifications_list", []) or []
            ):
                self._notification_popup_show_after_restore = False
                self._show_notifications_popup_from_memory()

        worker = self._start_logged_worker(
            _work,
            on_result=_apply,
            on_finished=_finished,
            warning_message="Notification history restore failed",
            operation_key="notifications:restore",
        )
        if worker is None and show_panel:
            self._notification_popup_show_after_restore = False
            self._show_notifications_popup_from_memory()

    def on_show_notifications(self):
        try:
            if (
                not getattr(self, "btn_notifications", None)
                or not self.btn_notifications.isEnabled()
            ):
                return
            if list(getattr(self, "notifications_list", []) or []):
                self._show_notifications_popup_from_memory()
                return
            registry = getattr(self, "_worker_registry", None)
            if registry is not None and registry.has_active_key("notifications:restore"):
                self._notification_popup_show_after_restore = True
                return
            self._restore_notification_history_async(show_panel=True)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.exception("Failed to show notifications panel")

    def mark_notification_read(self, index: int):
        try:
            runtime = self.runtime.notification_runtime_service
            items = list(getattr(self, "notifications_list", []) or [])
            updated, changed = runtime.mark_one_seen(items, int(index))
            if changed:
                self.notifications_list = updated
                self.unread_notifications = runtime.unread_count(updated)
                self._queue_notification_persist(updated)
            self._refresh_notifications_ui()
        except (AttributeError, RuntimeError, TypeError, ValueError, IndexError):
            logger.exception("Failed to mark a notification as read")

    def mark_all_notifications_read(self):
        try:
            runtime = self.runtime.notification_runtime_service
            items = list(getattr(self, "notifications_list", []) or [])
            updated, changed = runtime.mark_all_seen(items)
            if changed:
                self.notifications_list = updated
                self.unread_notifications = runtime.unread_count(updated)
                self._queue_notification_persist(updated)
            self._refresh_notifications_ui()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.exception("Failed to mark notifications as read")

    def acknowledge_notification(self, index: int):
        try:
            runtime = self.runtime.notification_runtime_service
            items = list(getattr(self, "notifications_list", []) or [])
            username = str(
                getattr(getattr(self.app_state, "current_user", None), "username", "") or ""
            ).strip()
            updated, ledger_ack, changed = runtime.acknowledge_history_item(
                items, int(index), username=username
            )
            if not changed:
                return
            self.notifications_list = updated
            self.unread_notifications = runtime.unread_count(updated)
            self._queue_notification_persist(updated, ledger_ack=ledger_ack)
            self._refresh_notifications_ui()
            scheduler = getattr(self, "_schedule_next_monitor_wake", None)
            if callable(scheduler):
                scheduler()
        except (AttributeError, RuntimeError, TypeError, ValueError, IndexError):
            logger.exception("Failed to acknowledge notification")

    def clear_notifications(self):
        try:
            runtime = self.runtime.notification_runtime_service
            retained = runtime.retain_unacknowledged(
                list(getattr(self, "notifications_list", []) or [])
            )
            self.notifications_list = retained
            self.unread_notifications = runtime.unread_count(retained)
            self._queue_notification_persist(retained)
            self._refresh_notifications_ui(retained)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.exception("Failed to clear notifications")


class MainWindowTrayMixin:
    def _tray_display_name(self) -> str:
        profile = getattr(getattr(self, "app_state", None), "current_user", None)
        for attribute in ("display_name", "full_name", "name", "username"):
            value = str(getattr(profile, attribute, "") or "").strip()
            if value:
                return value
        return ""

    def _refresh_tray_session_state(self) -> None:
        adapter = getattr(self, "_tray_adapter", None)
        if adapter is None:
            return
        adapter.set_session_state(
            self._tray_display_name() or None,
            monitoring_enabled=self.preferences.get_bool("monitoring_enabled", True),
            notifications_enabled=self.preferences.get_bool("enable_desktop_notifications", True),
        )

    def _is_tray_enabled(self) -> bool:
        try:
            tray_background = self.preferences.get_bool("enable_tray_background", False)
            desktop_alerts = self.preferences.get_bool("enable_desktop_notifications", True)
            return bool(tray_background or desktop_alerts)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return False

    def _destroy_tray_icon(self):
        adapter = getattr(self, "_tray_adapter", None)
        if adapter is not None:
            try:
                adapter.close()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug(
                    "MainWindowTrayMixin._destroy_tray_icon adapter cleanup failed",
                    exc_info=True,
                )
        self._tray_adapter = None
        self._tray_menu = None
        self.tray_icon = None

    def _ensure_tray_icon(self):
        if getattr(self, "tray_icon", None) is None:
            self.init_tray_icon()
        return getattr(self, "tray_icon", None)

    def _show_tray_icon(self) -> bool:
        try:
            tray = self._ensure_tray_icon()
            if tray is None:
                return False
            adapter = getattr(self, "_tray_adapter", None)
            if adapter is not None:
                adapter.show()
            else:
                tray.show()
                tray.setVisible(True)
            return True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._show_tray_icon failed", exc_info=True)
            return False

    def _minimize_to_tray(self, *, show_message: bool = True) -> bool:
        tray = self._ensure_tray_icon()
        if tray is None:
            return False
        try:
            lifecycle = self.runtime.lifecycle
            if lifecycle.state.name == "RUNNING":
                report = lifecycle.enter_background()
                if not report.successful:
                    raise RuntimeError(f"Background transition failed: {report.errors}")
            elif lifecycle.state.name == "BACKGROUND":
                # Reassert the background invariant if a caller repeats the action.
                if not self._show_tray_icon():
                    raise RuntimeError("System tray is unavailable while in background mode")
                self.hide()
            # Closing with the window X is intentionally a background action.
            # Confirm it once per process even if the optional repeated tray
            # notifications are disabled in preferences.
            show_background_hint = bool(show_message) and (
                not bool(getattr(self, "_background_hint_shown", False))
                or self.preferences.get_bool("tray_show_message_on_minimize", False)
            )
            if show_background_hint:
                tray.showMessage(
                    APP_DISPLAY_NAME,
                    _("HERFY-TS continues monitoring in the background. Select the tray icon to return."),
                    QSystemTrayIcon.Information,
                    2500,
                )
                self._background_hint_shown = True
            return True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._minimize_to_tray failed", exc_info=True)
            return False

    def init_tray_icon(self):
        self._destroy_tray_icon()
        if not self._is_tray_enabled():
            return
        try:
            adapter = SystemTrayAdapter(
                parent=self,
                base_icon=tray_icon_or_fallback(self),
                tooltip=APP_DISPLAY_NAME,
                open_window=self._restore_from_tray,
                hide_window=lambda: self._minimize_to_tray(show_message=False),
                show_login=self.show_login,
                logout=self._logout_from_tray,
                open_settings=self.open_settings,
                exit_application=self.close_app_completely,
                activated=self.on_tray_icon_activated,
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.warning("System tray is not available on this environment")
            return

        self._tray_adapter = adapter
        self.tray_icon = adapter.tray_icon
        self._tray_menu = adapter.menu
        self._refresh_tray_session_state()
        self._update_tray_badge()
        try:
            adapter.hide()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowTrayMixin.init_tray_icon hide failed",
                exc_info=True,
            )

    def _update_tray_badge(self) -> None:
        adapter = getattr(self, "_tray_adapter", None)
        if adapter is None:
            return
        unread_count = int(getattr(self, "unread_notifications", 0) or 0)
        update_available = bool(
            getattr(self, "update_available", False)
            or getattr(self, "_update_available", False)
            or getattr(self, "_pending_update_available", False)
        )
        try:
            self._refresh_tray_session_state()
            adapter.set_badge(
                unread_count=unread_count,
                update_available=update_available,
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowTrayMixin._update_tray_badge failed",
                exc_info=True,
            )

    def refresh_tray_icon(self):
        try:
            self.init_tray_icon()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.exception("refresh_tray_icon failed")

    def _bring_to_front(self, *, show_if_hidden: bool = False) -> None:
        try:
            if self.isMinimized():
                self.showNormal()
            elif show_if_hidden and (not self.isVisible()):
                self.show()
            if show_if_hidden and (not self.isVisible()):
                self.setVisible(True)
            self.raise_()
            self.activateWindow()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._bring_to_front fallback failed", exc_info=True)

    def _logout_from_tray(self) -> None:
        """Restore lifecycle consistency before presenting the logged-out shell."""
        self._restore_from_tray()
        self.logout()

    def _restore_from_tray(self):
        try:
            lifecycle = self.runtime.lifecycle
            if lifecycle.state.name == "BACKGROUND":
                report = lifecycle.enter_foreground()
                if not report.successful:
                    raise RuntimeError(f"Foreground transition failed: {report.errors}")
            else:
                self._bring_to_front(show_if_hidden=True)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._restore_from_tray fallback failed", exc_info=True)

    def on_tray_icon_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self._restore_from_tray()


logger = logging.getLogger(__name__)
