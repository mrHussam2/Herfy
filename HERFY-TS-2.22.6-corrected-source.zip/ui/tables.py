from __future__ import annotations

import logging
import math
import re
from collections.abc import Callable
from typing import Any, ClassVar

from PySide6.QtCore import (
    QAbstractTableModel,
    QEvent,
    QModelIndex,
    QRect,
    QSize,
    QSortFilterProxyModel,
    Qt,
    QTimer,
)
from PySide6.QtGui import QColor, QFont, QFontMetrics, QIcon, QPainter, QPen
from PySide6.QtWidgets import (
    QAbstractItemDelegate,
    QAbstractItemView,
    QHeaderView,
    QLineEdit,
    QSizePolicy,
    QStyle,
    QStyledItemDelegate,
    QTableView,
    QTableWidget,
)

from core.errors import (
    PARSE_OPERATION_EXCEPTIONS,
    SERVICE_OPERATION_EXCEPTIONS,
    UI_OPERATION_EXCEPTIONS,
)
from core.models import format_plain_number, normalize_int, parse_bool, parse_plain_number, safe_get
from core.presentation import format_display_date
from core.settings import _
from ui.text_presentation import polish_text_visibility
from ui.theme_metrics import UI_METRICS
from ui.theme_responsive import (
    ResponsiveProfile,
    adaptive_control_height,
    adaptive_dimension,
    apply_profile_properties,
    device_size_class,
    dispatch_reflow_callback,
    ensure_layout_mode_controller,
    profile_for_dimensions,
    profile_for_widget,
)
from ui.widgets import load_asset_icon

TRACKING_HEADER_KEYS = (
    "Branch",
    "Material #",
    "Product Name",
    "Qty",
    "Produced",
    "Expires",
    "Status",
    "Actions",
)


def tracking_headers() -> tuple[str, ...]:
    return tuple((_(key) for key in TRACKING_HEADER_KEYS))


TRACKING_HEADERS = TRACKING_HEADER_KEYS
COL_BRANCH = 0
COL_MATERIAL = 1
COL_NAME = 2
COL_QTY = 3
COL_PRODUCTION = 4
COL_EXPIRY = 5
COL_STATUS = 6
COL_ACTIONS = 7
USAGE_HEADER_KEYS = (
    "Material",
    "Product Name",
    "Receipts",
    "Beginning",
    "Total",
    "Enter Stock",
    "UOM",
    "Actual Usage",
)


def usage_headers() -> tuple[str, ...]:
    return tuple((_(key) for key in USAGE_HEADER_KEYS))


USAGE_PRINT_HEADER_KEYS = (
    "Material No.",
    "Product Name",
    "Receipts",
    "Opening",
    "Total",
    "Available Stock",
    "UOM",
    "Actual Usage",
)


def usage_print_headers() -> tuple[str, ...]:
    return tuple((_(key) for key in USAGE_PRINT_HEADER_KEYS))


def horizontal_header_value(
    labels: tuple[Any, ...] | list[Any],
    section: int,
    orientation: Qt.Orientation,
    role: int,
    *,
    label_index: int = 0,
    translate: bool = False,
) -> tuple[bool, Any]:
    """Return a custom horizontal header value and whether it matched Qt's request."""
    if role != Qt.DisplayRole or orientation != Qt.Horizontal or not 0 <= section < len(labels):
        return False, None
    label = labels[section][label_index]
    return True, _(label) if translate else label


HEADERS_USAGE = USAGE_HEADER_KEYS
COL_R = 2
COL_B = 3
COL_T = 4
COL_H = 5
COL_UOM = 6
COL_U = 7


logger = logging.getLogger(__name__)
TableMetrics = dict[str, int | str | bool]


class RowListTableModel(QAbstractTableModel):
    """Canonical row-count owner for table models backed by ``self._rows``."""

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802 - Qt API
        return 0 if parent.isValid() else len(self._rows)

    def replace_rows(self, rows: list[dict[str, Any]]) -> None:
        """Replace dictionary-backed model rows through one reset transaction."""
        self.beginResetModel()
        self._rows = [dict(row) for row in rows if isinstance(row, dict)]
        self.endResetModel()


def adaptive_table_row_height(window_width: int | None = None, app: Any = None) -> int:
    return adaptive_dimension(
        window_width,
        app,
        compact=UI_METRICS.table_row_height,
        comfortable=UI_METRICS.table_row_height,
        expanded=UI_METRICS.table_row_height,
    )


def adaptive_table_header_height(window_width: int | None = None, app: Any = None) -> int:
    return (
        UI_METRICS.table_header_height
        if adaptive_control_height(window_width, app) <= UI_METRICS.table_header_height
        else adaptive_control_height(window_width, app)
    )


def adaptive_table_icon_size(window_width: int | None = None, app: Any = None) -> int:
    return adaptive_dimension(window_width, app, compact=16, comfortable=16, expanded=18)


def adaptive_table_metrics(window_width: int | None = None, app: Any = None) -> TableMetrics:
    size_class = device_size_class(window_width, app)
    return {
        "device_class": size_class,
        "row_height": adaptive_table_row_height(window_width, app),
        "header_height": adaptive_table_header_height(window_width, app),
        "icon_size": adaptive_table_icon_size(window_width, app),
        "alternating_rows": True,
        "show_grid": False,
    }


def _default_header_alignment() -> Qt.Alignment:
    return Qt.AlignCenter


def _apply_vertical_header_metrics(table: Any, metrics: TableMetrics) -> None:
    try:
        row_height = int(metrics["row_height"])
        vertical_header = table.verticalHeader()
        vertical_header.setDefaultSectionSize(row_height)
        vertical_header.setMinimumSectionSize(max(20, row_height - 5))
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("apply_table_metrics vertical header failed", exc_info=True)


def _apply_horizontal_header_metrics(table: Any, metrics: TableMetrics) -> None:
    try:
        horizontal_header = table.horizontalHeader()
        horizontal_header.setMinimumHeight(int(metrics["header_height"]))
        horizontal_header.setDefaultAlignment(_default_header_alignment())
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("apply_table_metrics horizontal header failed", exc_info=True)


def apply_table_metrics(
    table: Any, window_width: int | None = None, app: Any = None
) -> TableMetrics:
    metrics = adaptive_table_metrics(window_width, app)
    try:
        apply_profile_properties(
            table,
            profile_for_dimensions(window_width, getattr(table, "height", lambda: None)(), app=app),
        )
        table.setProperty(
            "tableDensity",
            "compact" if metrics["device_class"] == "compact" else "regular",
        )
        table.setAlternatingRowColors(bool(metrics["alternating_rows"]))
        table.setShowGrid(bool(metrics["show_grid"]))
        table.setMouseTracking(True)
        table.setWordWrap(False)
        if hasattr(table, "isSortingEnabled"):
            table.setSortingEnabled(table.isSortingEnabled())
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("apply_table_metrics fallback failed", exc_info=True)
    _apply_vertical_header_metrics(table, metrics)
    _apply_horizontal_header_metrics(table, metrics)
    return metrics


def _configure_table_header(table: Any) -> None:
    try:
        table.setLayoutDirection(Qt.LeftToRight)
        table.viewport().setLayoutDirection(Qt.LeftToRight)
        table.horizontalHeader().setLayoutDirection(Qt.LeftToRight)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("stable LTR table direction setup failed", exc_info=True)
    header = table.horizontalHeader()
    header.setHighlightSections(False)
    header.setSectionsMovable(False)
    header.setStretchLastSection(False)
    header.setCascadingSectionResizes(False)
    header.setMinimumSectionSize(28)
    header.setSectionResizeMode(QHeaderView.Interactive)
    header.setDefaultAlignment(_default_header_alignment())


def configure_usage_table_headers(table: Any) -> None:
    """Allocate desktop Usage columns fluidly without suppressing their titles."""
    header = table.horizontalHeader()
    model = table.model()
    column_count = int(model.columnCount()) if model is not None else 0
    header.setMinimumSectionSize(48)
    header.setStretchLastSection(False)
    for column in range(column_count):
        table.setColumnHidden(column, False)
        header.setSectionResizeMode(column, QHeaderView.Stretch)


def _configure_table_scroll_and_size(table: Any, min_height: int | None) -> None:
    table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
    table.setTextElideMode(Qt.ElideRight)
    table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
    table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
    table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    try:
        table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        table.setWordWrap(False)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("table scroll safety setup failed", exc_info=True)
    table.setMinimumWidth(0)
    table.setSizeAdjustPolicy(QAbstractItemView.AdjustIgnored)
    if min_height is not None:
        table.setMinimumHeight(int(min_height))


def configure_responsive_table(
    table: Any,
    *,
    window_width: int | None = None,
    show_grid: bool = True,
    min_height: int | None = None,
) -> TableMetrics:
    metrics = apply_table_metrics(table, window_width)
    try:
        _configure_table_scroll_and_size(table, min_height)
        table.setAlternatingRowColors(True)
        table.setShowGrid(bool(show_grid))
        table.setWordWrap(False)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setSelectionMode(QAbstractItemView.SingleSelection)
        _configure_table_header(table)
        vertical_header = table.verticalHeader()
        vertical_header.setVisible(False)
        vertical_header.setDefaultSectionSize(int(metrics["row_height"]))
        vertical_header.setMinimumSectionSize(max(24, int(metrics["row_height"]) - 6))
        refresh = getattr(table, "updateGeometries", None)
        if callable(refresh):
            refresh()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("configure_responsive_table fallback failed", exc_info=True)
    return metrics


def _normalized_int_list(
    values: list[int] | tuple[int, ...] | None,
    *,
    count: int,
    default: int,
    minimum: int,
) -> list[int]:
    result = [max(minimum, int(value or default)) for value in list(values or [])[:count]]
    if len(result) < count:
        result.extend([max(minimum, int(default))] * (count - len(result)))
    return result


def _available_table_width(table: Any) -> int:
    viewport = table.viewport()
    viewport_width = int(viewport.width() if viewport is not None else table.width())
    try:
        scrollbar_width = table.verticalScrollBar().sizeHint().width()
    except SERVICE_OPERATION_EXCEPTIONS:
        scrollbar_width = 0
    return max(1, viewport_width - max(6, min(18, int(scrollbar_width or 0))))


def _distribute_surplus(widths: list[int], targets: list[int], surplus: int) -> None:
    if not targets:
        return
    index = 0
    while surplus > 0:
        widths[targets[index % len(targets)]] += 1
        surplus -= 1
        index += 1


def _shrink_to_available(widths: list[int], *, targets: list[int], available: int) -> None:
    if not targets:
        return
    index = 0
    count = len(widths)
    while sum(widths) > available:
        column = targets[index % len(targets)]
        if widths[column] > 1:
            widths[column] -= 1
        index += 1
        if index > count * 4 and sum(widths) > available:
            widest = max(range(count), key=lambda idx: widths[idx])
            widths[widest] = max(1, widths[widest] - 1)


def _header_aware_min_widths(table: Any, minimums: list[int]) -> list[int]:
    """Raise column minimums enough to keep table headers readable."""
    try:
        model = table.model()
        font_metrics = table.horizontalHeader().fontMetrics()
        adjusted: list[int] = []
        for column, minimum in enumerate(minimums):
            header_text = ""
            if model is not None:
                value = model.headerData(column, Qt.Horizontal, Qt.DisplayRole)
                header_text = str(value or "")
            text_width = int(font_metrics.horizontalAdvance(header_text)) if header_text else 0
            adjusted.append(max(int(minimum), text_width + 32))
        return adjusted
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("header-aware minimum width fallback failed", exc_info=True)
        return list(minimums)


def _calculate_column_widths(
    *, ratios: list[int], min_widths: list[int], available: int, allow_overflow: bool
) -> tuple[list[int], int]:
    ratio_total = max(1, sum(ratios))
    total_min = sum(min_widths)
    if total_min <= available:
        return (list(min_widths), available - total_min)
    if allow_overflow:
        return (list(min_widths), 0)
    count = len(ratios)
    hard_floor = max(18, min(38, available // max(1, count)))
    floors = [hard_floor] * count
    floor_total = sum(floors)
    if floor_total >= available:
        widths = [max(1, int(available * ratios[index] / ratio_total)) for index in range(count)]
        return (widths, available - sum(widths))
    compressible = available - floor_total
    preferred_extra = [max(0, min_widths[index] - floors[index]) for index in range(count)]
    preferred_extra_total = max(1, sum(preferred_extra))
    widths = [
        floors[index] + int(compressible * preferred_extra[index] / preferred_extra_total)
        for index in range(count)
    ]
    return (widths, available - sum(widths))


def fit_table_height_to_rows(
    table: Any, *, min_rows: int = 8, max_rows: int = 18, extra_pixels: int = 18
) -> None:
    """Fit common row counts inside the current window without fullscreen.

    The contract is visual-acceptance driven: small/medium result sets should be
    fully visible in the default window, while large result sets keep a clean
    vertical scrollbar instead of forcing the whole window taller.
    """
    try:
        model = table.model()
        row_count = int(model.rowCount()) if model is not None else 0
        minimum_rows = max(5, int(min_rows or 5))
        maximum_rows = max(minimum_rows, int(max_rows or minimum_rows))
        rows_to_show = min(max(int(row_count or 0), minimum_rows), maximum_rows)
        header = table.horizontalHeader()
        vertical = table.verticalHeader()
        row_height = max(19, int(vertical.defaultSectionSize() or table.fontMetrics().height() + 7))
        header_height = max(22, int(header.height() or header.defaultSectionSize() or 24))
        target = header_height + rows_to_show * row_height + int(extra_pixels)
        table.setMinimumHeight(min(280, max(160, target)))
        table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        table.setProperty("visualAcceptanceRows", rows_to_show)
        table.setProperty("tableHeightMode", "flexible")
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("fit_table_height_to_rows failed", exc_info=True)


def fit_table_columns(
    table: Any,
    ratios: list[int] | tuple[int, ...],
    *,
    min_widths: list[int] | tuple[int, ...] | None = None,
    stretch_columns: list[int] | tuple[int, ...] | None = None,
    allow_overflow: bool = False,
) -> None:
    try:
        model = table.model()
        count = int(model.columnCount()) if model is not None else len(ratios)
        if count <= 0:
            return
        header = table.horizontalHeader()
        for column in range(count):
            header.setSectionResizeMode(column, QHeaderView.Interactive)
        normalized_ratios = _normalized_int_list(ratios, count=count, default=1, minimum=1)
        normalized_min_widths = _header_aware_min_widths(
            table, _normalized_int_list(min_widths, count=count, default=64, minimum=32)
        )
        for column in range(count):
            try:
                table.setColumnHidden(column, False)
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("table column unhide failed", exc_info=True)
        visible_columns = list(range(count))
        visible_ratios = [normalized_ratios[column] for column in visible_columns]
        visible_minimums = [normalized_min_widths[column] for column in visible_columns]
        available = _available_table_width(table)
        # Preserve header/content minima. If they cannot fit, use controlled
        # horizontal overflow instead of prematurely crushing Product/Material/Date.
        effective_overflow = bool(allow_overflow or sum(visible_minimums) > available)
        visible_widths, surplus = _calculate_column_widths(
            ratios=visible_ratios,
            min_widths=visible_minimums,
            available=available,
            allow_overflow=effective_overflow,
        )
        table.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAsNeeded if effective_overflow else Qt.ScrollBarAlwaysOff
        )
        if effective_overflow and sum(visible_widths) > available:
            table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        else:
            table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        target_columns = [
            int(column) for column in list(stretch_columns or []) if int(column) in visible_columns
        ]
        if not target_columns:
            target_columns = [max(visible_columns, key=lambda column: normalized_ratios[column])]
        target_positions = [visible_columns.index(column) for column in target_columns]
        _distribute_surplus(visible_widths, target_positions, surplus)
        if not effective_overflow:
            _shrink_to_available(visible_widths, targets=target_positions, available=available)
        widths = [1] * count
        for position, column in enumerate(visible_columns):
            if effective_overflow:
                width = max(normalized_min_widths[column], visible_widths[position])
            else:
                width = max(1, visible_widths[position])
            widths[column] = int(width)
        header.setMinimumSectionSize(48 if effective_overflow else 1)
        for column, width in enumerate(widths):
            table.setColumnWidth(column, width)
            # Column widths are calculated by this shared service; users do
            # not resize them manually and accidentally break table layout.
            header.setSectionResizeMode(column, QHeaderView.Fixed)
        header.setStretchLastSection(False)
        table.setProperty("stretchColumns", ",".join((str(column) for column in target_columns)))
        table.setMinimumWidth(0)
        try:
            hbar = table.horizontalScrollBar()
            if effective_overflow:
                hbar.setDisabled(False)
                if sum(visible_widths) <= available:
                    hbar.setValue(0)
            else:
                hbar.setValue(0)
                hbar.setDisabled(True)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("table scrollbar normalization failed", exc_info=True)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("fit_table_columns fallback failed", exc_info=True)


RowNormalizer = Callable[[dict | None], dict[str, Any]]

_NUMERIC_TEXT_RE = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$")


def sortable_value_key(value: Any) -> tuple[int, Any]:
    """Return a stable mixed-type key for desktop table sorting."""
    if value is None:
        return (3, "")
    if isinstance(value, bool):
        return (0, int(value))
    if isinstance(value, (int, float)):
        number = float(value)
        return (3, "") if math.isnan(number) else (0, number)

    text = str(value).strip()
    if not text:
        return (3, "")
    compact = text.replace(",", "")
    if _NUMERIC_TEXT_RE.fullmatch(compact):
        try:
            return (0, float(compact))
        except ValueError:
            pass
    return (1, text.casefold())


class BaseDictTableModel(RowListTableModel):
    headers: tuple[str, ...] = ()

    def __init__(
        self,
        rows: list[dict] | None = None,
        parent=None,
        *,
        normalizer: RowNormalizer | None = None,
    ) -> None:
        super().__init__(parent)
        self._normalizer: RowNormalizer = normalizer or self._default_normalizer
        self._rows: list[dict[str, Any]] = self._normalize_rows(rows)
        self._sort_column = -1
        self._sort_order = Qt.AscendingOrder

    @staticmethod
    def _default_normalizer(row: dict | None) -> dict[str, Any]:
        return dict(row or {})

    def _normalize_rows(self, rows: list[dict] | None) -> list[dict[str, Any]]:
        return [self._normalizer(row) for row in rows or []]

    def replace_rows(self, rows: list[dict] | None) -> None:
        self.beginResetModel()
        self._rows = self._normalize_rows(rows)
        if self._sort_column >= 0:
            self._sort_rows(self._sort_column, self._sort_order)
        self.endResetModel()

    def load_data(self, rows: list[dict] | None) -> None:
        self.replace_rows(rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.headers)

    def _sort_rows(self, column: int, order) -> None:
        if not (0 <= int(column) < self.columnCount()):
            return
        decorated: list[tuple[tuple[int, Any], int, dict[str, Any]]] = []
        for row_index, row in enumerate(self._rows):
            value = self.data(self.index(row_index, column), Qt.UserRole)
            decorated.append((sortable_value_key(value), row_index, row))
        decorated.sort(
            key=lambda item: (item[0], item[1]),
            reverse=order == Qt.DescendingOrder,
        )
        self._rows = [item[2] for item in decorated]

    def sort(self, column: int, order=Qt.AscendingOrder) -> None:
        if not (0 <= int(column) < self.columnCount()):
            return
        self.layoutAboutToBeChanged.emit()
        self._sort_column = int(column)
        self._sort_order = order
        self._sort_rows(self._sort_column, self._sort_order)
        self.layoutChanged.emit()

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole):
        if orientation != Qt.Horizontal:
            return (
                super().headerData(section, orientation, role) if role == Qt.DisplayRole else None
            )
        if 0 <= section < len(self.headers) and role in (
            Qt.DisplayRole,
            Qt.ToolTipRole,
            Qt.AccessibleTextRole,
        ):
            return self.headers[section]
        if role == Qt.TextAlignmentRole:
            return int(Qt.AlignCenter)
        return None


class TrackedProductsTableModel(BaseDictTableModel):
    headers = TRACKING_HEADERS

    def __init__(self, rows: list[dict] | None = None, parent=None):
        self.headers = tracking_headers()
        super().__init__(rows, parent)

    def flags(self, index: QModelIndex):
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable if index.isValid() else Qt.NoItemFlags

    def get_product_id(self, row: int) -> str | None:
        if not 0 <= row < len(self._rows):
            return None
        text = str(safe_get(self._rows[row], "id", "") or "").strip()
        return text or None

    @staticmethod
    def _status_payload(row: dict[str, Any]) -> tuple[str, int, int | None, str]:
        raw_days = row.get("expiry_status_days_left")
        try:
            days_left = None if raw_days in (None, "") else int(raw_days)
        except (TypeError, ValueError):
            days_left = None
        return (
            str(row.get("expiry_status_text") or ""),
            normalize_int(row.get("expiry_status_progress"), 0),
            days_left,
            str(row.get("expiry_status_key") or ""),
        )

    @staticmethod
    def _display_mapping(row: dict[str, Any], status_text: str = "") -> dict[int, Any]:
        return {
            COL_BRANCH: str(safe_get(row, "branch", "") or ""),
            COL_MATERIAL: str(safe_get(row, "material_number", "") or ""),
            COL_NAME: str(safe_get(row, "name", "") or ""),
            COL_QTY: normalize_int(safe_get(row, "quantity", 0), 0),
            COL_PRODUCTION: format_display_date(safe_get(row, "production_date", ""), fallback=""),
            COL_EXPIRY: format_display_date(safe_get(row, "expiry_date", ""), fallback=""),
            COL_STATUS: status_text,
            COL_ACTIONS: "",
        }

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._rows):
            return None
        row = self._rows[index.row()]
        column = index.column()
        status_text = ""
        progress = 0
        days_left = None
        status_key = ""
        if column == COL_STATUS:
            status_text, progress, days_left, status_key = self._status_payload(row)
        mapping = self._display_mapping(row, status_text)
        if role == Qt.DisplayRole:
            value = mapping.get(column, "")
            return str(value) if column == COL_QTY else value
        if role == Qt.UserRole:
            if column == COL_STATUS:
                return days_left
            if column == COL_QTY:
                return normalize_int(safe_get(row, "quantity", 0), 0)
            if column == COL_PRODUCTION:
                return str(safe_get(row, "production_date", "") or "")
            if column == COL_EXPIRY:
                return str(safe_get(row, "expiry_date", "") or "")
            if column == COL_ACTIONS:
                return None
            return mapping.get(column, "")
        if role == Qt.ToolTipRole:
            if column == COL_STATUS:
                parts = [
                    f"{_('Product Name')}: {safe_get(row, 'name', '')}",
                    f"{_('Restaurant branch')}: {safe_get(row, 'branch', '')}",
                    f"{_('Expiry Date')}: {format_display_date(safe_get(row, 'expiry_date', ''), fallback='-')}",
                    str(status_text),
                ]
                return "\n".join((str(part) for part in parts if str(part or "").strip()))
            if column == COL_ACTIONS:
                return _("Edit or delete this food item.")
            return str(mapping.get(column, "") or "")
        if role == Qt.TextAlignmentRole:
            if column in {
                COL_BRANCH,
                COL_MATERIAL,
                COL_QTY,
                COL_PRODUCTION,
                COL_EXPIRY,
                COL_STATUS,
                COL_ACTIONS,
            }:
                return int(Qt.AlignCenter)
            if column == COL_NAME:
                return int(Qt.AlignVCenter | Qt.AlignLeft)
            return int(Qt.AlignCenter)
        if role == Qt.SizeHintRole and column == COL_ACTIONS:
            return QSize(88, 34)
        if role == Qt.UserRole + 1 and column == COL_STATUS:
            return progress
        if role == Qt.UserRole + 2 and column == COL_STATUS:
            return status_key
        return None


class UsageModel(BaseDictTableModel):
    headers = HEADERS_USAGE
    NUMERIC_COLUMNS = (COL_R, COL_B, COL_T, COL_H, COL_U)
    READONLY_NUMERIC_COLUMNS = (COL_R, COL_B, COL_T)
    USER_INPUT_COLUMNS = (COL_H,)
    CHANGE_ROLES: ClassVar[tuple[int, ...]] = (
        Qt.DisplayRole,
        Qt.EditRole,
        Qt.UserRole,
    )

    def __init__(self, rows: list[dict] | None = None, parent=None, *, row_presenter=None):
        if row_presenter is None:
            raise RuntimeError("UsageModel requires a composed row_presenter")
        self.row_presenter = row_presenter
        self.headers = usage_headers()
        super().__init__(rows, parent, normalizer=self.row_presenter.normalize_row)

    def replace_rows_preserving_user_inputs(self, rows: list[dict] | None) -> None:
        prepared = self.row_presenter.replace_rows_preserving_user_inputs(self._rows, rows)
        self.beginResetModel()
        self._rows = prepared
        self.endResetModel()

    def flags(self, index: QModelIndex):
        if not index.isValid():
            return Qt.NoItemFlags
        flags = Qt.ItemIsEnabled | Qt.ItemIsSelectable
        if index.column() == COL_H:
            flags |= Qt.ItemIsEditable
        return flags

    @staticmethod
    def _value(row: dict[str, Any], column: int):
        return {
            0: row.get("material", ""),
            1: row.get("name", ""),
            COL_R: row.get("receipts", 0.0),
            COL_B: row.get("begin", 0.0),
            COL_T: row.get("total", 0.0),
            COL_H: row.get("onhand", 0.0),
            COL_UOM: row.get("uom", ""),
            COL_U: row.get("usage", 0.0),
        }.get(column, "")

    @staticmethod
    def _user_value_visible(row: dict[str, Any]) -> bool:
        return parse_bool(row.get("user_set"), False)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole):
        if not index.isValid() or not 0 <= index.row() < len(self._rows):
            return None
        row = self._rows[index.row()]
        column = index.column()
        value = self._value(row, column)
        user_value_visible = self._user_value_visible(row)
        if role == Qt.DisplayRole:
            if column in self.READONLY_NUMERIC_COLUMNS:
                return format_plain_number(value)
            if column == COL_H:
                return format_plain_number(value) if user_value_visible else ""
            if column == COL_U:
                return format_plain_number(value)
            return str(value or "")
        if role == Qt.EditRole:
            if column == COL_UOM:
                return ""
            if column == COL_H and (not user_value_visible):
                return ""
            return value
        if role == Qt.UserRole:
            if column == COL_H and (not user_value_visible):
                return None
            return value
        if role == Qt.TextAlignmentRole:
            # Every Usage cell is centered except Product Name, which remains
            # explicitly left-to-right and left aligned for readable item names.
            if column == 1:
                return int(Qt.AlignVCenter | Qt.AlignLeft | Qt.AlignAbsolute)
            return int(Qt.AlignCenter)
        if role == Qt.ToolTipRole:
            if column == COL_H:
                return _("Enter the remaining stock. Actual usage is calculated automatically.")
            return None
        return None

    def setData(self, index: QModelIndex, value, role: int = Qt.EditRole) -> bool:
        if role != Qt.EditRole or not index.isValid() or index.column() != COL_H:
            return False
        updated, accepted = self.row_presenter.apply_onhand_edit(self._rows[index.row()], value)
        if not accepted:
            return False
        self._rows[index.row()] = updated
        self._emit_onhand_usage_changed(index.row())
        return True

    def _emit_onhand_usage_changed(self, row: int) -> None:
        self.dataChanged.emit(self.index(row, COL_H), self.index(row, COL_U), self.CHANGE_ROLES)


class UsageProxy(QSortFilterProxyModel):
    SEARCH_COLUMNS = (0, 1, COL_UOM)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._search = ""
        self._hide_total_zero = False
        self.setDynamicSortFilter(True)

    def lessThan(self, left: QModelIndex, right: QModelIndex) -> bool:  # noqa: N802
        model = self.sourceModel()
        if model is None:
            return super().lessThan(left, right)
        left_value = model.data(left, Qt.UserRole)
        right_value = model.data(right, Qt.UserRole)
        return sortable_value_key(left_value) < sortable_value_key(right_value)

    def set_search(self, value: str) -> None:
        self._search = str(value or "").strip().lower()
        self.refresh_filter()

    def set_hide_total_zero(self, enabled: bool) -> None:
        self._hide_total_zero = bool(enabled)
        self.refresh_filter()

    def refresh_filter(self) -> None:
        """Refresh row acceptance through the non-deprecated Qt 6 path."""
        self.beginFilterChange()
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:
        model = self.sourceModel()
        if model is None:
            return True
        if self._hide_total_zero and self._row_total_is_zero(model, source_row, source_parent):
            return False
        return (
            True if not self._search else self._row_matches_search(model, source_row, source_parent)
        )

    @staticmethod
    def _row_total_is_zero(model, source_row: int, source_parent: QModelIndex) -> bool:
        total_index = model.index(source_row, COL_T, source_parent)
        total = parse_plain_number(model.data(total_index, Qt.UserRole))
        return abs(total) < 1e-09

    def _row_matches_search(self, model, source_row: int, source_parent: QModelIndex) -> bool:
        haystack = []
        for column in self.SEARCH_COLUMNS:
            value = model.data(model.index(source_row, column, source_parent), Qt.DisplayRole)
            haystack.append(str(value or "").lower())
        return self._search in " | ".join(haystack)


class OnHandDelegate(QStyledItemDelegate):
    ROW_PROPERTY = "_usage_row"
    COLUMN_PROPERTY = "_usage_column"

    def paint(self, painter: QPainter, option, index: QModelIndex) -> None:
        """Render every Enter Stock cell as an obvious editable input field."""
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)

        if option.state & QStyle.State_Selected:
            painter.fillRect(option.rect, option.palette.highlight())
        else:
            painter.fillRect(option.rect, option.palette.base())

        field = option.rect.adjusted(6, 4, -6, -4)
        painter.setBrush(QColor("#FFFFFF"))
        border = QColor("#2B72EF") if option.state & QStyle.State_HasFocus else QColor("#9FB5D1")
        painter.setPen(QPen(border, 1))
        painter.drawRoundedRect(field, 6, 6)

        text = str(index.data(Qt.DisplayRole) or "").strip()
        if text:
            painter.setPen(QPen(QColor("#172B4D")))
            font = QFont(option.font)
            font.setWeight(QFont.DemiBold)
            painter.setFont(font)
        else:
            text = _("Enter stock")
            painter.setPen(QPen(QColor("#7B8CA5")))

        painter.drawText(field.adjusted(6, 0, -6, 0), Qt.AlignCenter, text)
        painter.restore()

    def createEditor(self, parent, option, index):
        # Use a plain text editor so available stock is direct manual input with no
        # increment/decrement controls. Empty input keeps Actual Usage at zero.
        editor = QLineEdit(parent)
        editor.setObjectName("ManualAvailableStockInput")
        editor.setFrame(True)
        editor.setProperty("usageEntry", True)
        editor.setAlignment(Qt.AlignCenter)
        editor.setPlaceholderText(_("Enter stock"))
        editor.setToolTip(_("Enter the remaining stock. Actual usage is calculated automatically."))
        editor.setStatusTip(_("Enter remaining stock; actual usage is calculated automatically."))
        editor.setWhatsThis(_("Enter remaining stock; actual usage is calculated automatically."))
        editor.installEventFilter(self)
        return editor

    def eventFilter(self, obj, event):
        if (
            isinstance(obj, QLineEdit)
            and event.type() == QEvent.KeyPress
            and (event.key() in (Qt.Key_Return, Qt.Key_Enter))
        ):
            self._commit_and_move_down(obj)
            return True
        return super().eventFilter(obj, event)

    def _commit_and_move_down(self, editor: QLineEdit) -> None:
        row, column = self._editor_position(editor)
        self.commitData.emit(editor)
        self.closeEditor.emit(editor, QAbstractItemDelegate.NoHint)
        if row >= 0 and column >= 0:
            QTimer.singleShot(0, lambda: self._focus_cell(row + 1, column))

    @classmethod
    def _set_editor_position(cls, editor: QLineEdit, row: int, column: int) -> None:
        editor.setProperty(cls.ROW_PROPERTY, int(row))
        editor.setProperty(cls.COLUMN_PROPERTY, int(column))

    @classmethod
    def _editor_position(cls, editor: QLineEdit) -> tuple[int, int]:
        return (
            cls._editor_int_property(editor, cls.ROW_PROPERTY),
            cls._editor_int_property(editor, cls.COLUMN_PROPERTY),
        )

    @staticmethod
    def _editor_int_property(editor: QLineEdit, name: str) -> int:
        try:
            return int(editor.property(name))
        except (TypeError, ValueError):
            return -1

    def _focus_cell(self, row: int, column: int) -> None:
        table = self.parent()
        model = table.model() if table is not None and hasattr(table, "model") else None
        if model is None or row >= model.rowCount():
            return
        index = model.index(row, column)
        if not index.isValid():
            return
        table.setCurrentIndex(index)
        table.setFocus(Qt.TabFocusReason)
        table.scrollTo(index)
        table.edit(index)
        self._focus_existing_editor(table, index, attempts=4)

    @staticmethod
    def _focus_existing_editor(table, index, *, attempts: int) -> None:
        target_rect = table.visualRect(index)
        for editor in table.viewport().findChildren(QLineEdit):
            if target_rect.intersects(editor.geometry()):
                editor.setFocus(Qt.TabFocusReason)
                editor.selectAll()
                return
        if attempts <= 0:
            return
        table.edit(index)
        QTimer.singleShot(
            15,
            lambda: OnHandDelegate._focus_existing_editor(table, index, attempts=attempts - 1),
        )

    def setEditorData(self, editor: QLineEdit, index):
        self._set_editor_position(editor, index.row(), index.column())
        value = index.model().data(index, Qt.EditRole)
        if value in (None, ""):
            editor.clear()
            return
        try:
            editor.setText(format_plain_number(float(value)))
        except PARSE_OPERATION_EXCEPTIONS:
            editor.setText(str(value or ""))

    def setModelData(self, editor: QLineEdit, model, index):
        # Preserve the exact manual text. The model owns locale-aware parsing and
        # validation (including the Available Stock <= Total rule).
        model.setData(index, str(editor.text() or "").strip(), Qt.EditRole)

    def updateEditorGeometry(self, editor: QLineEdit, option, index):
        self._set_editor_position(editor, index.row(), index.column())
        super().updateEditorGeometry(editor, option, index)


class ProgressBarDelegate(QStyledItemDelegate):
    STATUS_COLORS = {
        "valid": "#2E9D68",
        "expiring_soon": "#D49A24",
        "expiring_approaching": "#E17B2F",
        "expiring_near": "#D9513E",
        "expires_tomorrow": "#C43F4C",
        "expires_today": "#A92F3D",
        "expired": "#762431",
        "unknown": "#8793A5",
    }

    def __init__(self, parent=None):
        super().__init__(parent)

    def paint(self, painter: QPainter, option, index: QModelIndex) -> None:
        self._draw_panel(painter, option)
        progress_value = self._clamped_progress(index.data(Qt.UserRole + 1))
        status_key = str(index.data(Qt.UserRole + 2) or "unknown").strip().lower()
        label = str(index.data(Qt.DisplayRole) or "")
        color = self._status_color(option, progress_value, status_key)
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        # The readable state belongs inside the visual indicator.
        bar_rect = QRect(
            option.rect.x() + 5,
            option.rect.y() + max(3, (option.rect.height() - 16) // 2),
            max(1, option.rect.width() - 10),
            min(16, max(10, option.rect.height() - 6)),
        )
        font = QFont(option.font)
        font.setWeight(QFont.DemiBold)
        painter.setFont(font)
        metrics = QFontMetrics(font)
        painter.setPen(Qt.NoPen)
        painter.setBrush(color.lighter(175))
        painter.drawRoundedRect(bar_rect, 4, 4)
        if progress_value > 0:
            fill_rect = QRect(
                bar_rect.x(),
                bar_rect.y(),
                max(5, int(bar_rect.width() * progress_value / 100.0)),
                bar_rect.height(),
            )
            painter.setBrush(color)
            painter.drawRoundedRect(fill_rect, 4, 4)
        text = metrics.elidedText(label, Qt.ElideRight, max(20, bar_rect.width() - 10))
        text_color = QColor("#FFFFFF") if color.lightness() < 155 else QColor("#26364F")
        painter.setPen(QPen(text_color))
        painter.drawText(bar_rect.adjusted(5, 0, -5, 0), Qt.AlignCenter, text)
        painter.restore()

    @staticmethod
    def _draw_panel(painter: QPainter, option) -> None:
        style = option.widget.style() if option.widget is not None else None
        if style is not None:
            style.drawPrimitive(QStyle.PE_PanelItemViewItem, option, painter, option.widget)

    @staticmethod
    def _clamped_progress(value: Any) -> int:
        try:
            return max(0, min(100, int(value)))
        except PARSE_OPERATION_EXCEPTIONS:
            return 0

    @staticmethod
    def _status_color(option, progress_value: int, status_key: str) -> QColor:
        del progress_value
        color = ProgressBarDelegate.STATUS_COLORS.get(status_key)
        return QColor(color) if color else option.palette.mid().color()


class ActionDelegate(QStyledItemDelegate):
    EDIT_FALLBACK_TEXT = "✎"
    DELETE_FALLBACK_TEXT = "×"

    def __init__(self, page, parent=None):
        super().__init__(parent)
        self.page = page
        self._edit_icon = load_asset_icon("resources", "images", "edit.png")
        self._delete_icon = load_asset_icon("resources", "images", "delete.png")

    def paint(self, painter: QPainter, option, index: QModelIndex) -> None:
        ProgressBarDelegate._draw_panel(painter, option)
        edit_rect, delete_rect = self._button_rects(option.rect)
        edit_error = self.page.tracking_action_error(index.row(), action="update")
        delete_error = self.page.tracking_action_error(index.row(), action="delete")
        muted = option.palette.mid().color()
        self._draw_button(
            painter,
            edit_rect,
            self._edit_icon,
            self.EDIT_FALLBACK_TEXT,
            muted if edit_error else option.palette.link().color(),
        )
        self._draw_button(
            painter,
            delete_rect,
            self._delete_icon,
            self.DELETE_FALLBACK_TEXT,
            muted if delete_error else option.palette.text().color(),
        )

    def editorEvent(self, event, model, option, index: QModelIndex):
        if event is None or index.column() != COL_ACTIONS:
            return False
        if getattr(event, "type", lambda: None)() != QEvent.MouseButtonRelease:
            return False
        pos = getattr(event, "pos", lambda: None)()
        if pos is None:
            return False
        edit_rect, delete_rect = self._button_rects(option.rect)
        if edit_rect.contains(pos):
            if self.page.tracking_action_error(index.row(), action="update"):
                self.page.explain_tracking_action_unavailable(index.row(), action="update")
                return True
            self.page.edit_tracked_product(index.row())
            return True
        if delete_rect.contains(pos):
            if self.page.tracking_action_error(index.row(), action="delete"):
                self.page.explain_tracking_action_unavailable(index.row(), action="delete")
                return True
            self.page.delete_tracked_product(index.row())
            return True
        return False

    @staticmethod
    def _button_rects(cell_rect: QRect) -> tuple[QRect, QRect]:
        available = max(34, cell_rect.width() - 8)
        spacing = 6 if available >= 62 else 3
        button_size = min(30, max(18, min(cell_rect.height() - 8, (available - spacing) // 2)))
        total_width = button_size * 2 + spacing
        left = cell_rect.x() + max(4, (cell_rect.width() - total_width) // 2)
        top = cell_rect.y() + max(2, (cell_rect.height() - button_size) // 2)
        return (
            QRect(left, top, button_size, button_size),
            QRect(left + button_size + spacing, top, button_size, button_size),
        )

    @staticmethod
    def _draw_button(
        painter: QPainter, rect: QRect, icon: QIcon, fallback_text: str, color: QColor
    ) -> None:
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)
        if not icon.isNull():
            icon.paint(painter, rect.adjusted(5, 5, -5, -5), Qt.AlignCenter)
        else:
            painter.setPen(QPen(color))
            painter.drawText(rect, Qt.AlignCenter, fallback_text)
        painter.restore()


logger = logging.getLogger(__name__)


def result_count_text(count: int, *, singular: str | None = None, plural: str | None = None) -> str:
    total = int(count or 0)
    if total == 1:
        return singular or _("1 item")
    return (plural or _("{count} items")).format(count=total)


def set_table_count_text(label: Any, text: str) -> None:
    if label is None:
        return
    try:
        label.setText(str(text or ""))
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("set_table_count_text failed", exc_info=True)


def set_status_label_text(label: Any, text: str = "", *, role: str = "muted") -> None:
    if label is None:
        return
    try:
        label.setText(str(text or ""))
        label.setProperty("statusRole", str(role or "muted"))
        refresh_qt_style(label)
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("set_status_label_text failed", exc_info=True)


def refresh_qt_style(widget: Any) -> None:
    if widget is None:
        return
    try:
        style = widget.style()
        if style is not None:
            style.unpolish(widget)
            style.polish(widget)
        update = getattr(widget, "update", None)
        if callable(update):
            update()
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("refresh_qt_style failed", exc_info=True)


def configure_sortable_table(table: Any, *, enabled: bool = True) -> None:
    """Enable click-to-sort headers without making columns movable."""
    if table is None:
        return
    try:
        enabled = bool(enabled)
        table.setProperty("sortableTable", enabled)
        if hasattr(table, "setSortingEnabled"):
            table.setSortingEnabled(enabled)
        header = table.horizontalHeader()
        header.setSectionsClickable(enabled)
        header.setSortIndicatorShown(enabled)
        header.setSectionsMovable(False)
        header.setHighlightSections(False)
        header.setToolTip(
            _("Click a column heading to sort. Click it again to reverse the order.")
            if enabled
            else ""
        )
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("configure_sortable_table failed", exc_info=True)


def polish_tables(root: Any, *, window_width: int | None = None) -> None:
    if root is None or not hasattr(root, "findChildren"):
        return
    try:
        for table in root.findChildren((QTableView, QTableWidget)):
            configure_table_layout(
                table,
                window_width=window_width,
                show_grid=table.showGrid() if hasattr(table, "showGrid") else True,
            )
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("polish_tables failed", exc_info=True)


def apply_responsive_table_resize(
    owner: Any,
    table: Any,
    *,
    width: int,
    min_height: int | None = None,
    size_columns,
    logger_=None,
    context: str = "responsive table resize",
    app=None,
) -> None:
    try:
        profile = profile_for_dimensions(width, getattr(owner, "height", lambda: None)(), app=app)
        apply_profile_properties(owner, profile)
        refresh_qt_style(owner)
    except UI_OPERATION_EXCEPTIONS:
        if logger_ is not None:
            logger_.debug("%s device polish failed", context, exc_info=True)
    if table is None:
        return
    configure_table_layout(table, window_width=width, show_grid=True, min_height=min_height)
    if callable(size_columns):
        size_columns()
    polish_text_visibility(owner)


def configure_table_layout(
    table: Any,
    *,
    window_width: int | None = None,
    show_grid: bool = True,
    min_height: int | None = None,
) -> dict[str, int | str | bool]:
    profile = profile_for_dimensions(window_width, getattr(table, "height", lambda: None)())
    # Desktop data grids use a stable, conventional density independent of
    # window width. Touch mode alone increases the hit target.
    row_height = int(profile.touch_target if profile.touch_mode else UI_METRICS.table_row_height)
    header_height = int(
        profile.touch_target if profile.touch_mode else UI_METRICS.table_header_height
    )
    metrics: dict[str, int | str | bool] = {
        "device_class": (
            "compact" if profile.is_narrow else "comfortable" if profile.is_tablet else "expanded"
        ),
        "row_height": row_height,
        "header_height": header_height,
        "show_grid": bool(show_grid),
        "alternating_rows": True,
    }
    try:
        apply_profile_properties(table, profile)
        # Data grids are a stable LTR surface in both Arabic and English.
        # This preserves column order and numeric/date scanning while the rest
        # of the window can follow the selected language direction.
        table.setLayoutDirection(Qt.LeftToRight)
        viewport = getattr(table, "viewport", lambda: None)()
        if viewport is not None:
            viewport.setLayoutDirection(Qt.LeftToRight)
        table.setAlternatingRowColors(True)
        table.setShowGrid(bool(show_grid))
        table.setMouseTracking(True)
        table.setWordWrap(False)
        if hasattr(table, "setTextElideMode"):
            table.setTextElideMode(Qt.ElideRight)
        if hasattr(table, "setHorizontalScrollMode"):
            table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        if hasattr(table, "setVerticalScrollMode"):
            table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        if hasattr(table, "setHorizontalScrollBarPolicy"):
            table.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        if hasattr(table, "setVerticalScrollBarPolicy"):
            table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        if hasattr(table, "setSizeAdjustPolicy"):
            table.setSizeAdjustPolicy(QAbstractItemView.AdjustIgnored)
        table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        table.setMinimumWidth(0)
        if min_height is not None:
            table.setMinimumHeight(int(min_height))
        header = table.horizontalHeader()
        header.setLayoutDirection(Qt.LeftToRight)
        header.setHighlightSections(False)
        header.setSectionsMovable(False)
        sortable = bool(table.property("sortableTable")) or bool(
            getattr(table, "isSortingEnabled", lambda: False)()
        )
        header.setSectionsClickable(sortable)
        header.setSortIndicatorShown(sortable)
        header.setStretchLastSection(False)
        header.setCascadingSectionResizes(True)
        header.setMinimumSectionSize(48)
        header.setSectionResizeMode(QHeaderView.Interactive)
        header.setMinimumHeight(header_height)
        try:
            header.setDefaultAlignment(Qt.AlignCenter)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("table header alignment fallback failed", exc_info=True)
        vertical = table.verticalHeader()
        vertical.setLayoutDirection(Qt.LeftToRight)
        vertical.setVisible(False)
        vertical.setDefaultSectionSize(row_height)
        vertical.setMinimumSectionSize(max(24, row_height - 6))
        refresh = getattr(table, "updateGeometries", None)
        if callable(refresh):
            refresh()
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("configure_table_layout fallback failed", exc_info=True)
    return metrics


class ResponsiveDataPageResizeMixin:
    responsive_resize_callbacks: tuple[str, ...] = ()
    responsive_table_attr = ""
    responsive_table_size_callback = ""
    responsive_table_min_height = 300
    status_label_attr = ""
    summary_count_label_attr = "lbl_table_count"
    summary_surface_attr = ""
    summary_loading_text = "Loading..."
    summary_state_method = ""

    def _set_page_status(self, text: str = "", *, role: str = "muted") -> None:
        label = getattr(self, str(self.status_label_attr or ""), None)
        set_status_label_text(label, text, role=role)

    def _apply_table_summary_state(
        self,
        *,
        count_label: Any,
        surface: Any,
        count_text: str,
        status_text: str,
        status_role: str,
        loading: bool,
    ) -> None:
        set_table_count_text(count_label, count_text)
        self._set_page_status(status_text, role=status_role)
        if surface is None or not hasattr(surface, "set_state"):
            return
        if loading:
            loading_title = _(str(self.summary_loading_text or "Loading..."))
            detail = str(status_text or "").strip()
            if detail == loading_title:
                detail = ""
            surface.set_state(
                "loading",
                title=loading_title,
                message=detail,
            )
        else:
            surface.set_state("content")

    def _summary_state_kwargs(self, state_kwargs: dict[str, Any]) -> dict[str, Any]:
        return dict(state_kwargs)

    def _set_page_table_summary(
        self, total: int, *, loading: bool = False, **state_kwargs: Any
    ) -> None:
        try:
            state_factory = getattr(
                self.page_visible_state_service, str(self.summary_state_method or "")
            )
            state = state_factory(
                total=int(total or 0),
                loading=bool(loading),
                **self._summary_state_kwargs(state_kwargs),
            )
            count_text = (
                _(str(self.summary_loading_text or "Loading..."))
                if loading
                else result_count_text(total)
            )
            self._apply_table_summary_state(
                count_label=getattr(self, str(self.summary_count_label_attr or ""), None),
                surface=getattr(self, str(self.summary_surface_attr or ""), None),
                count_text=count_text,
                status_text=state.status_text,
                status_role=state.status_role,
                loading=bool(loading),
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "%s._set_page_table_summary failed",
                self.__class__.__name__,
                exc_info=True,
            )

    def _safe_set_page_table_summary(
        self, total: int, *, loading: bool = False, **state_kwargs: Any
    ) -> None:
        setter = getattr(self, "_set_page_table_summary", None)
        if not callable(setter):
            return
        try:
            setter(total, loading=loading, **state_kwargs)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "%s._safe_set_page_table_summary failed",
                self.__class__.__name__,
                exc_info=True,
            )

    def resizeEvent(self, event):
        """Request responsive table/page reflow only when the semantic profile changes."""
        super().resizeEvent(event)
        try:
            controller = ensure_layout_mode_controller(
                self, attr_name="_data_page_layout_mode_controller"
            )
            if not bool(getattr(self, "_data_page_layout_mode_connected", False)):
                controller.reflowRequested.connect(self._on_data_page_reflow_requested)
                self._data_page_layout_mode_connected = True
            controller.schedule()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "%s.resizeEvent responsive fallback failed",
                self.__class__.__name__,
                exc_info=True,
            )
            self._on_data_page_reflow_requested("", profile_for_widget(self))

    def _on_data_page_reflow_requested(self, mode: str, profile: ResponsiveProfile) -> None:
        """Apply deferred page/table reflow after a semantic mode transition.

        Callbacks now receive the resolved semantic mode and profile when their
        signature supports them. Pages that already perform full table sizing in
        their own responsive callback can disable the generic resize pass with
        ``responsive_table_resize_after_callbacks = False``.
        """
        page_logger = logging.getLogger(self.__class__.__module__)
        for callback_name in self.responsive_resize_callbacks:
            try:
                dispatch_reflow_callback(
                    self,
                    str(callback_name or ""),
                    mode=str(mode or ""),
                    profile=profile,
                    force=True,
                )
            except UI_OPERATION_EXCEPTIONS:
                page_logger.debug(
                    "%s responsive callback failed",
                    self.__class__.__name__,
                    exc_info=True,
                )
        if not bool(getattr(self, "responsive_table_resize_after_callbacks", True)):
            return
        apply_responsive_table_resize(
            self,
            getattr(self, str(self.responsive_table_attr or ""), None),
            width=self.width(),
            min_height=None,
            size_columns=getattr(self, str(self.responsive_table_size_callback or ""), None),
            logger_=page_logger,
            context=f"{self.__class__.__name__}.resizeEvent",
        )
