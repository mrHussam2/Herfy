"""Sound playback for confirmed desktop notifications."""

from __future__ import annotations

import importlib
import logging
import time
from pathlib import Path
from typing import Any

from PySide6.QtCore import QUrl
from PySide6.QtMultimedia import QSoundEffect

from core.errors import (
    SERVICE_OPERATION_EXCEPTIONS,
    UI_OPERATION_EXCEPTIONS,
)
from core.settings import IS_WINDOWS, NOTIFICATION_SOUND_DIR_RELATIVE_PATH, resource_path

logger = logging.getLogger(__name__)
NOTIFICATION_SOUND_COOLDOWN_SECONDS = 4.0


class SoundNotifier:
    def __init__(self, notification_runtime: Any) -> None:
        self._runtime = notification_runtime
        self._effect = None
        self._effect_source = ""
        self._last_played_at = 0.0
        try:
            effect = QSoundEffect()
            effect.setLoopCount(1)
            effect.setVolume(0.82)
            self._effect = effect
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.warning("Qt sound effect is unavailable; Windows fallback remains enabled.")

    def setting_key_for_status(self, status: str | dict) -> str:
        """Return the configured sound key using canonical notification status.

        The sound route depends only on canonical notification status data.
        Localized labels are presentation-only and never drive severity.
        """
        try:
            return self._runtime.sound_setting_key(status)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Unable to resolve canonical notification sound route")
            return "notification_sound_default"

    def resolve_sound_path(self, status: str = "") -> str:
        key = self.setting_key_for_status(status)
        selected = str(self._runtime.get_setting(key, "") or "").strip()
        if not selected:
            selected = str(
                self._runtime.get_setting("notification_sound_default", "default.wav")
                or "default.wav"
            ).strip()
        # Path selection is presentation configuration only.  The resolved
        # package resource is used by QSoundEffect and the Windows fallback.
        custom_path = Path(selected).expanduser()
        if custom_path.is_absolute() and custom_path.suffix.lower() in {".wav", ".mp3", ".ogg"}:
            return str(custom_path)
        selected_name = Path(selected).name or "default.wav"
        return resource_path(*NOTIFICATION_SOUND_DIR_RELATIVE_PATH, selected_name)

    def play(self, status: str = "") -> None:
        # Final safety guard: only canonical, monitor-produced alert states may
        # emit sound.  This includes an expired item, which is a critical food
        # safety condition, while valid and unknown states remain silent.
        if not self._runtime.is_notifiable_status(
            status if isinstance(status, dict) else {"status_kind": status}
        ):
            return
        if not self._runtime.get_bool("enable_sounds", True):
            return
        cooldown = NOTIFICATION_SOUND_COOLDOWN_SECONDS
        now = time.monotonic()
        if now - self._last_played_at < cooldown:
            return
        sound_path = self.resolve_sound_path(status)
        if not sound_path:
            return
        self._last_played_at = now
        if self._play_qt_effect(sound_path):
            return
        try:
            if IS_WINDOWS:
                winsound = importlib.import_module("winsound")
                if sound_path.lower().endswith(".wav"):
                    winsound.PlaySound(None, 0)
                    winsound.PlaySound(sound_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
                else:
                    winsound.MessageBeep()
            else:
                logger.warning("Notification sound backend unavailable for: %s", sound_path)
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            logger.error("Sound error: %s", exc)

    def _play_qt_effect(self, sound_path: str) -> bool:
        """Play a bundled WAV through Qt6's supported short-effect API.

        QMediaPlayer/QMediaContent was a Qt5-era route and is absent from
        current PySide6 builds.  QSoundEffect is purpose-built for concise
        notification cues and does not create a media-playback worker per
        alert.
        """
        effect = self._effect
        if not sound_path or effect is None or not Path(sound_path).is_file():
            return False
        try:
            if sound_path != self._effect_source:
                effect.setSource(QUrl.fromLocalFile(sound_path))
                self._effect_source = sound_path
            effect.stop()
            effect.play()
            return True
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Qt sound-effect playback failed")
            return False

    def stop(self) -> None:
        try:
            effect = getattr(self, "_effect", None)
            if effect is not None:
                effect.stop()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Sound notifier shutdown failed", exc_info=True)


logger = logging.getLogger(__name__)
