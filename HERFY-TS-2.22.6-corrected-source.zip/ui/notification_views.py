"""Qt presentation widgets for in-application notification history."""

from __future__ import annotations

import logging
from dataclasses import dataclass as _dataclass
from typing import Any

from PySide6.QtCore import QPoint, QSize, Qt, Signal
from PySide6.QtWidgets import (
    QAbstractScrollArea,
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QPushButton,
    QSizePolicy,
    QWidget,
    QWidgetAction,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.i18n import get_language, is_rtl, normalize_language_code
from core.models import parse_bool
from core.presentation import format_display_date, format_display_datetime
from core.settings import _
from ui.designer import load_ui
from ui.theme import UI_METRICS
from ui.widgets import (
    clear_layout,
    direction_for_rtl,
    leading_alignment,
    repolish_widget_tree,
    set_accessibility,
    set_tab_order,
    trailing_alignment,
)


@_dataclass(frozen=True)
class NotificationViewItem:
    index: int
    title: str
    timestamp: str
    product: str
    material_number: str
    status: str
    qty: str
    branch: str
    days_text: str
    expiry_date: str
    message: str
    read: bool
    acknowledged: bool
    acknowledged_at: str
    level: str


class NotificationsPresenter:
    def language(self) -> str:
        return normalize_language_code(get_language())

    def is_rtl(self) -> bool:
        return is_rtl(self.language())

    def to_view_items(self, notifications: list[dict]) -> list[NotificationViewItem]:
        return [self._to_view_item(index, raw) for index, raw in enumerate(notifications or [])]

    def _to_view_item(self, index: int, raw: Any) -> NotificationViewItem:
        entry = raw if isinstance(raw, dict) else {"message": str(raw)}
        branch = str(
            entry.get("branch_label")
            or entry.get("branch_name")
            or entry.get("branch")
            or entry.get("store_name")
            or entry.get("store")
            or ""
        ).strip()
        quantity = entry.get("qty")
        if quantity in (None, ""):
            quantity = entry.get("quantity")
        return NotificationViewItem(
            index=index,
            title=str(entry.get("title") or _("Notification")),
            timestamp=format_display_datetime(entry.get("timestamp"), fallback=""),
            product=str(
                entry.get("product")
                or entry.get("product_name")
                or entry.get("display_product")
                or ""
            ).strip(),
            material_number=str(entry.get("material_number") or "").strip(),
            status=str(entry.get("status") or entry.get("status_label") or "").strip(),
            qty=str(quantity if quantity not in (None, "") else "").strip(),
            branch=branch,
            days_text=str(entry.get("days_text") or "").strip(),
            expiry_date=format_display_date(entry.get("expiry_date"), fallback=""),
            message=str(entry.get("message") or "").strip(),
            read=parse_bool(entry.get("read"), False),
            acknowledged=bool(str(entry.get("acknowledged_at") or "").strip()),
            acknowledged_at=format_display_datetime(entry.get("acknowledged_at"), fallback=""),
            level=str(
                entry.get("level")
                or entry.get("severity")
                or entry.get("status_kind")
                or entry.get("status")
                or ""
            ).lower(),
        )

    def severity_property(self, item: NotificationViewItem) -> str:
        text = f"{item.level} {item.status}".lower()
        if "expired" in text or "overdue" in text or "منته" in text or "متأخر" in text:
            return "expired"
        if "today" in text or "اليوم" in text:
            return "critical"
        if "critical" in text or "near" in text or "حرج" in text:
            return "critical"
        if "soon" in text or "approach" in text or "قريب" in text:
            return "soon"
        return "normal"

    def severity_icon(self, item: NotificationViewItem) -> str:
        severity = self.severity_property(item)
        if severity == "expired":
            return "×"
        if severity in {"critical", "soon"}:
            return "!"
        return "•"


class _NotificationItemWidget(QFrame):
    clicked = Signal()
    acknowledge_clicked = Signal()

    def __init__(
        self, item: NotificationViewItem, presenter: NotificationsPresenter, parent=None
    ) -> None:
        super().__init__(parent)
        self._item = item
        self._presenter = presenter
        self.setObjectName("NotificationItem")
        self.setProperty("read", bool(item.read))
        self.setProperty("severity", presenter.severity_property(item))
        self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
        self.setMinimumWidth(0)
        self.setToolTip(_("Read") if item.read else _("Click to mark as read"))
        self.setLayoutDirection(direction_for_rtl(presenter.is_rtl()))
        set_accessibility(
            self,
            name=item.product or item.title or _("Notification"),
            description=item.message or item.status,
        )
        self._build()

    def _text_alignment(self) -> Qt.Alignment:
        return leading_alignment(self._presenter.is_rtl())

    def _build(self) -> None:
        controls = load_ui(
            self,
            "notification_item",
            required=(
                "NotificationSeverityIcon",
                "NotificationItemTitle",
                "NotificationDaysBadge",
                "NotificationUnreadDot",
                "NotificationFooterText",
                "NotificationAcknowledgeIconButton",
                "NotificationTimestamp",
            ),
        )
        alignment = self._text_alignment()
        for name in (
            "NotificationSeverityIcon",
            "NotificationItemTitle",
            "NotificationDaysBadge",
            "NotificationUnreadDot",
            "NotificationFooterText",
            "NotificationTimestamp",
        ):
            label: QLabel = controls[name]
            label.setWordWrap(True)
            label.setMinimumWidth(0)
            label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            label.setAlignment(alignment)
            label.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        controls["NotificationSeverityIcon"].setText(self._presenter.severity_icon(self._item))
        controls["NotificationSeverityIcon"].setAlignment(Qt.AlignCenter)
        controls["NotificationItemTitle"].setText(
            self._item.product or self._item.title or _("Notification")
        )
        controls["NotificationItemTitle"].setAlignment(alignment | Qt.AlignVCenter)
        badge: QLabel = controls["NotificationDaysBadge"]
        badge.setText(self._item.days_text)
        badge.setVisible(bool(self._item.days_text))
        badge.setAlignment(Qt.AlignCenter)
        badge.setProperty("severity", self._presenter.severity_property(self._item))
        controls["NotificationUnreadDot"].setVisible(not self._item.read)
        controls["NotificationUnreadDot"].setAlignment(Qt.AlignCenter)
        structured = (
            (_("Product"), self._item.product or self._item.title),
            (_("Quantity"), self._item.qty or "—"),
            (_("Status"), self._item.status or self._item.title),
            (_("Remaining"), self._item.days_text or "—"),
        )
        for index, (label, value) in enumerate(structured):
            name = self.findChild(QLabel, "NotificationFieldLabel" + str(index))
            rendered = self.findChild(QLabel, "NotificationFieldValue" + str(index))
            name.setText(label)
            rendered.setText(value)
            for field in (name, rendered):
                field.setWordWrap(True)
                field.setAlignment(alignment)
                field.setAttribute(Qt.WA_TransparentForMouseEvents, True)
            rendered.setProperty("field", label.lower())
        footer_bits = []
        if self._item.branch:
            footer_bits.append(f"{_('Branch')}: {self._item.branch}")
        if self._item.expiry_date:
            footer_bits.append(f"{_('Exp')}: {self._item.expiry_date}")
        footer_text: QLabel = controls["NotificationFooterText"]
        footer_text.setText("   |   ".join(footer_bits))
        footer_text.setWordWrap(True)
        footer_text.setMinimumWidth(0)
        footer_text.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        acknowledge: QPushButton = controls["NotificationAcknowledgeIconButton"]
        acknowledge.setVisible(not self._item.acknowledged)
        acknowledge.setProperty("variant", "ghost")
        acknowledge.setToolTip(_("Acknowledge"))
        acknowledge.clicked.connect(lambda _checked=False: self.acknowledge_clicked.emit())
        controls["NotificationTimestamp"].setText(self._item.timestamp)
        controls["NotificationTimestamp"].setAlignment(
            trailing_alignment(self._presenter.is_rtl()) | Qt.AlignVCenter
        )

    def mouseReleaseEvent(self, event):
        try:
            if event.button() == Qt.LeftButton and self.rect().contains(event.position().toPoint()):
                self.clicked.emit()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Notification item click handling failed", exc_info=True)
        super().mouseReleaseEvent(event)


class NotificationsPanelUiMixin:
    def _build_ui(self) -> None:
        controls = load_ui(
            self,
            "notifications_panel",
            required=(
                "notification_header_row",
                "NotificationPanelTitle",
                "NotificationUnreadBadge",
                "NotificationMarkAllLink",
                "NotificationsList",
                "NotificationEmptyLabel",
                "NotificationPager",
                "notification_pager_layout",
                "NotificationPreviousPage",
                "NotificationPageLabel",
                "NotificationNextPage",
                "notification_actions_row",
                "NotificationClearButton",
                "NotificationCloseButton",
            ),
        )
        self.header_row: QGridLayout = controls["notification_header_row"]
        self.title_label: QLabel = controls["NotificationPanelTitle"]
        self.unread_badge: QLabel = controls["NotificationUnreadBadge"]
        self.mark_read_button: QPushButton = controls["NotificationMarkAllLink"]
        self.title_label.setText(_("Notifications"))
        self.unread_badge.setAlignment(Qt.AlignCenter)
        self.mark_read_button.setText(_("Mark all as read"))
        self.mark_read_button.setProperty("variant", "ghost")
        self.mark_read_button.clicked.connect(self.mark_all_requested.emit)
        self.list_widget: QListWidget = controls["NotificationsList"]
        self.list_widget.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list_widget.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list_widget.setSizeAdjustPolicy(QAbstractScrollArea.AdjustToContents)
        self.list_widget.setResizeMode(QListWidget.Adjust)
        self.list_widget.setSpacing(7)
        self.list_widget.setSelectionMode(QListWidget.SingleSelection)
        self.list_widget.setFocusPolicy(Qt.NoFocus)
        self.list_widget.setUniformItemSizes(False)
        self.list_widget.setWordWrap(True)
        set_accessibility(
            self.list_widget,
            name=_("Notifications list"),
            description=_("Recent local alerts"),
        )
        self.list_widget.itemClicked.connect(self._on_item_triggered)
        self.list_widget.itemActivated.connect(self._on_item_triggered)
        self.empty_label: QLabel = controls["NotificationEmptyLabel"]
        self.empty_label.hide()
        self.actions_row: QHBoxLayout = controls["notification_actions_row"]
        self.clear_button: QPushButton = controls["NotificationClearButton"]
        self.close_button: QPushButton = controls["NotificationCloseButton"]
        self.clear_button.setText(_("Clear"))
        self.close_button.setText(_("Close"))
        self.clear_button.setProperty("variant", "secondary")
        self.close_button.setProperty("variant", "primary")
        self.clear_button.clicked.connect(self.clear_all_requested.emit)
        self.pager_row: QFrame = controls["NotificationPager"]
        self.pager_layout: QHBoxLayout = controls["notification_pager_layout"]
        self.previous_page_button: QPushButton = controls["NotificationPreviousPage"]
        self.page_label: QLabel = controls["NotificationPageLabel"]
        self.next_page_button: QPushButton = controls["NotificationNextPage"]
        for button in (self.previous_page_button, self.next_page_button):
            button.setProperty("variant", "ghost")
        self.previous_page_button.clicked.connect(self._previous_page)
        self.next_page_button.clicked.connect(self._next_page)
        self.page_label.setAlignment(Qt.AlignCenter)
        self.pager_row.setVisible(False)
        set_tab_order(
            self,
            [self.mark_read_button, self.list_widget, self.clear_button, self.close_button],
        )

    def _apply_language_layout(self) -> None:
        self._presenter = NotificationsPresenter()
        rtl = self._presenter.is_rtl()
        direction = direction_for_rtl(rtl)
        alignment = leading_alignment(rtl)
        self.setLayoutDirection(direction)
        self.list_widget.setLayoutDirection(direction)
        self.title_label.setAlignment(alignment | Qt.AlignVCenter)

        clear_layout(self.header_row)
        for column in range(2):
            self.header_row.setColumnStretch(column, 0)
        if rtl:
            self.header_row.addWidget(self.unread_badge, 0, 0)
            self.header_row.addWidget(self.title_label, 0, 1)
        else:
            self.header_row.addWidget(self.title_label, 0, 0)
            self.header_row.addWidget(self.unread_badge, 0, 1)
        self.header_row.addWidget(self.mark_read_button, 1, 0, 1, 2)
        self.header_row.setColumnStretch(0 if not rtl else 1, 1)

        clear_layout(self.actions_row)
        if rtl:
            self.actions_row.addWidget(self.close_button)
            self.actions_row.addStretch(1)
            self.actions_row.addWidget(self.clear_button)
        else:
            self.actions_row.addWidget(self.clear_button)
            self.actions_row.addStretch(1)
            self.actions_row.addWidget(self.close_button)
        clear_layout(self.pager_layout)
        if rtl:
            self.pager_layout.addWidget(self.next_page_button)
            self.pager_layout.addWidget(self.page_label, 1)
            self.pager_layout.addWidget(self.previous_page_button)
        else:
            self.pager_layout.addWidget(self.previous_page_button)
            self.pager_layout.addWidget(self.page_label, 1)
            self.pager_layout.addWidget(self.next_page_button)
        repolish_widget_tree(self)


class NotificationsPanel(NotificationsPanelUiMixin, QFrame):
    mark_all_requested = Signal()
    clear_all_requested = Signal()
    mark_one_requested = Signal(int)
    acknowledge_requested = Signal(int)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._presenter = NotificationsPresenter()
        self._min_width = max(280, int(UI_METRICS.notifications_min_width))
        self._max_width = max(self._min_width, int(UI_METRICS.notifications_max_width))
        self._items_cache: list[dict] = []
        self._view_items: list[NotificationViewItem] = []
        self._page_index = 0
        self._page_size = 1
        self.setObjectName("NotificationsPanel")
        self.setMinimumWidth(self._min_width)
        self.setMaximumWidth(self._max_width)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFocusPolicy(Qt.StrongFocus)
        self._build_ui()
        self._apply_language_layout()

    def apply_available_width(self, available_width: int) -> None:
        safe_width = max(240, int(available_width or self._max_width))
        target_max = min(self._max_width, safe_width)
        target_min = min(self._min_width, target_max)
        changed = int(self.minimumWidth()) != target_min or int(self.maximumWidth()) != target_max
        self.setMinimumWidth(target_min)
        self.setMaximumWidth(target_max)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        if changed and self._view_items:
            self._render_page()

    def set_notifications(self, notifications: list[dict]) -> None:
        self._items_cache = list(notifications or [])
        self._apply_language_layout()
        self._view_items = self._presenter.to_view_items(self._items_cache)
        unread_count = sum((1 for item in self._view_items if not item.read))
        total_count = len(self._view_items)
        self.unread_badge.setText(str(unread_count))
        self.unread_badge.setVisible(bool(unread_count))
        self.mark_read_button.setEnabled(bool(unread_count))
        self.clear_button.setEnabled(bool(total_count))
        self.empty_label.hide()
        self.list_widget.setVisible(total_count > 0)
        self._page_index = min(self._page_index, max(0, self._page_count() - 1))
        self._render_page()

    def _page_count(self) -> int:
        return max(1, (len(self._view_items) + self._page_size - 1) // self._page_size)

    def _render_page(self) -> None:
        self.list_widget.clear()
        start = self._page_index * self._page_size
        for view_item in self._view_items[start : start + self._page_size]:
            self._add_notification_item(view_item)
        page_count = self._page_count()
        self.pager_row.setVisible(len(self._view_items) > self._page_size)
        self.page_label.setText(f"{self._page_index + 1} / {page_count}")
        self.previous_page_button.setEnabled(self._page_index > 0)
        self.next_page_button.setEnabled(self._page_index + 1 < page_count)
        content_height = sum(
            self.list_widget.item(row).sizeHint().height()
            for row in range(self.list_widget.count())
        )
        if self.list_widget.count() > 1:
            content_height += self.list_widget.spacing() * (self.list_widget.count() - 1)
        screen = self.screen()
        available_height = int(screen.availableGeometry().height()) if screen is not None else 720
        list_height = min(content_height, max(160, int(available_height * 0.55)))
        self.list_widget.setMinimumHeight(min(content_height, list_height))
        self.list_widget.setMaximumHeight(list_height)
        self.adjustSize()

    def _previous_page(self) -> None:
        if self._page_index > 0:
            self._page_index -= 1
            self._render_page()

    def _next_page(self) -> None:
        if self._page_index + 1 < self._page_count():
            self._page_index += 1
            self._render_page()

    def _add_notification_item(self, view_item: NotificationViewItem) -> None:
        widget = _NotificationItemWidget(view_item, self._presenter, self.list_widget)
        widget.clicked.connect(lambda idx=view_item.index: self.mark_one_requested.emit(int(idx)))
        widget.acknowledge_clicked.connect(
            lambda idx=view_item.index: self.acknowledge_requested.emit(int(idx))
        )
        item = QListWidgetItem(self.list_widget)
        item.setData(Qt.UserRole, int(view_item.index))
        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        self.list_widget.addItem(item)
        self.list_widget.setItemWidget(item, widget)
        available_width = max(
            1,
            int(self.list_widget.viewport().width() or self.width() or self._max_width),
        )
        item.setSizeHint(QSize(0, widget.layout().totalHeightForWidth(available_width)))

    def _on_item_triggered(self, item: QListWidgetItem) -> None:
        try:
            if item is not None:
                index = item.data(Qt.UserRole)
                if index is not None:
                    self.mark_one_requested.emit(int(index))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Notification item activation failed", exc_info=True)


class NotificationsPopupMenu(QMenu):
    """Screen-aware anchored host for the notification centre.

    Qt owns the transient popup position through ``QMenu.popup``.  The actual
    centre remains a reusable frame embedded with ``QWidgetAction`` so its
    layout, state and behaviour stay separate from application navigation.
    """

    dismissed = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._dismissed = False
        self.setObjectName("NotificationsPopup")
        self.setSeparatorsCollapsible(False)
        self.panel = NotificationsPanel(self)
        self.panel.close_button.clicked.connect(self.dismiss)
        self.aboutToHide.connect(self._finalize_dismissal)
        self.setMaximumWidth(self.panel.maximumWidth())

        action = QWidgetAction(self)
        action.setDefaultWidget(self.panel)
        self.addAction(action)

    def dismiss(self) -> None:
        """End the popup lifecycle instead of retaining a hidden menu instance."""
        if self._dismissed:
            return
        self._dismissed = True
        self.close()
        self.dismissed.emit()
        self.deleteLater()

    def _finalize_dismissal(self) -> None:
        """Dispose menus dismissed by Escape, a click-away, or Qt itself."""
        if self._dismissed:
            return
        self._dismissed = True
        self.dismissed.emit()
        self.deleteLater()

    def apply_language_layout(self) -> None:
        self.panel._apply_language_layout()

    def set_notifications(self, notifications: list[dict]) -> None:
        self.panel.set_notifications(notifications)

    def show_near(self, anchor: QWidget) -> None:
        if anchor is None:
            return
        self.apply_language_layout()
        anchor_bottom = anchor.mapToGlobal(QPoint(0, anchor.height()))
        screen = (
            QApplication.screenAt(anchor_bottom) or anchor.screen() or QApplication.primaryScreen()
        )
        available = screen.availableGeometry() if screen is not None else None
        if available is not None:
            self.panel.apply_available_width(max(240, int(available.width()) - 16))
        self.ensurePolished()
        self.adjustSize()
        width = max(self.panel.minimumWidth(), self.sizeHint().width())
        if available is not None:
            width = min(width, max(240, int(available.width()) - 16))
            self.setMaximumWidth(width)
        if self.panel._presenter.is_rtl():
            x = anchor_bottom.x()
        else:
            x = anchor_bottom.x() + anchor.width() - width
        popup_height = self.sizeHint().height()
        y = anchor_bottom.y() + 8
        if available is not None:
            x = max(available.left(), min(x, available.right() - width + 1))
            if y + popup_height > available.bottom() + 1:
                y = max(available.top(), anchor.mapToGlobal(QPoint(0, 0)).y() - popup_height - 8)
        self.popup(QPoint(x, y))


logger = logging.getLogger(__name__)
