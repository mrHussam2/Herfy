"""Tracking page mixin composition and Designer UI mounting."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGridLayout, QSizePolicy, QVBoxLayout

from ui.designer import load_ui
from ui.theme import UI_METRICS, configure_page_layout
from ui.tracking_data import TrackingDataControllerMixin
from ui.tracking_form import TrackingFormBuilderMixin
from ui.tracking_form_controller import TrackingFormControllerMixin
from ui.tracking_table import TrackingTableBuilderMixin
from ui.widgets import ControllerLifecycleMixin, DomainAppStateBindingMixin


class TrackingControllerMixin(
    TrackingDataControllerMixin,
    TrackingFormControllerMixin,
    DomainAppStateBindingMixin,
    ControllerLifecycleMixin,
):
    _load_token = 0
    app_state_page_name = "TrackingPage"
    app_state_callback_name = "_on_app_state_tracking_changed"


class TrackingUiBuilderMixin(TrackingFormBuilderMixin, TrackingTableBuilderMixin):
    def _build_ui(self) -> None:
        self._designer_controls = load_ui(
            self,
            "tracking_page",
            required=(
                "TrackingContentHost",
                "TrackingContentSurface",
                "tracking_content_layout",
                "TrackingControlsCard",
                "TrackingToolbarCard",
                "tracking_status",
                "tracking_branch",
                "tracking_product",
                "tracking_quantity",
                "tracking_production",
                "tracking_expiry",
                "tracking_branch_label",
                "tracking_product_label",
                "tracking_production_label",
                "tracking_expiry_label",
                "tracking_quantity_label",
                "tracking_save",
                "TrackingTableCard",
                "TrackingProductsTable",
                "TrackingTableTitle",
                "tracking_table_header_layout",
                "tracking_branch_field",
                "tracking_product_field",
                "tracking_production_field",
                "tracking_expiry_field",
                "tracking_quantity_field",
            ),
        )
        self.setObjectName("TrackingPage")
        self.setProperty("uiScope", "tracking")
        self.setProperty("layoutMode", "grid")
        self.main_layout = configure_page_layout(
            self, self.findChild(QVBoxLayout, "tracking_root_layout")
        )
        self.content_host = self._designer_controls["TrackingContentHost"]
        self.content_surface = self._designer_controls["TrackingContentSurface"]
        self.content_host_layout = self._designer_controls["tracking_content_layout"]
        self.content_host.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.content_host.setWidgetResizable(True)
        # The Tracking form and table share the workspace height.  A page-level
        # scroll area makes the toolbar disappear above the fold and duplicates
        # the table's own vertical scrolling; rows belong to QTableView only.
        self.content_host.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        # The shell enforces the desktop workspace minimum.  Keep this page
        # free of a second scrollbar; only the records table scrolls vertically.
        self.content_host.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.content_surface.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
        self.content_surface.setMinimumWidth(self._S(UI_METRICS.tracking_workspace_min_width))
        self.content_surface.setMinimumHeight(0)
        self.content_host_layout.setContentsMargins(0, 0, 0, 0)
        self.content_host_layout.setSpacing(self._S(UI_METRICS.page_section_gap))
        self.content_host_layout.setStretch(0, 0)
        self.content_host_layout.setStretch(1, 1)
        self.controls_card = self._designer_controls["TrackingControlsCard"]
        self.controls_card.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Minimum)
        self.toolbar_frame = self._designer_controls["TrackingToolbarCard"]
        self.toolbar_lay = self.findChild(QGridLayout, "tracking_toolbar_layout")
        self.tracking_controls_layout = self.findChild(QGridLayout, "tracking_controls_layout")
        self.tracking_table_host_layout = self.findChild(QVBoxLayout, "tracking_table_host_layout")
        self._build_controls_card()
        self._build_table_card()
