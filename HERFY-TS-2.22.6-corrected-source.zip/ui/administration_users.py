"""Server-authoritative employee and branch-account presentation."""

from __future__ import annotations

from typing import Any

from PySide6.QtCore import QSortFilterProxyModel, Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QScrollArea,
    QStackedWidget,
    QToolButton,
    QWidget,
)

from ui.dialogs import show_question_message
from core.settings import _
from ui.administration_components import (
    AdminTableModel,
    AdminTableView,
    AssignmentEditorDialog,
    DetailsPanel,
    FilterBar,
    SplitWorkspace,
    UserEditorDialog,
    submit_reviewed_assignments,
)
from ui.administration_controller import AdministrationPresenter
from ui.designer import load_ui
from ui.theme import UI_METRICS
from ui.widgets import DataSurface

_SCOPE_KEY = {
    "organization": "organizations",
    "region": "regions",
    "area": "areas",
    "branch": "branches",
}


class UserFilterProxy(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.needle = ""
        self.role = ""
        self.status = ""
        self.scope_kind = ""
        self.scope_id = ""
        self.revision_column = 5
        self.setDynamicSortFilter(True)
        self.setSortCaseSensitivity(Qt.CaseInsensitive)

    def set_filters(self, needle="", role="", status="", scope_data=None):
        self.needle = str(needle or "").casefold()
        self.role = str(role or "")
        self.status = str(status or "")
        kind, ident = (
            scope_data
            if isinstance(scope_data, (tuple, list)) and len(scope_data) == 2
            else ("", "")
        )
        self.scope_kind = str(kind or "")
        self.scope_id = str(ident or "")
        self.beginFilterChange()
        self.endFilterChange(QSortFilterProxyModel.Direction.Rows)

    def filterAcceptsRow(self, row, parent):
        index = self.sourceModel().index(row, 0, parent)
        data = self.sourceModel().data(index, Qt.UserRole) or {}
        if self.role and str(data.get("role") or "") != self.role:
            return False
        active = bool(data.get("is_active", False))
        if self.status == "active" and not active:
            return False
        if self.status == "disabled" and active:
            return False
        if self.scope_kind and self.scope_id:
            scope = data.get("scope") if isinstance(data.get("scope"), dict) else {}
            key = _SCOPE_KEY.get(self.scope_kind, "")
            if key and self.scope_id not in {str(value) for value in scope.get(key) or []}:
                return False
        if self.needle:
            scope_text = AdministrationPresenter.scope_summary(data.get("scope"))
            haystack = (
                " ".join(str(data.get(key) or "") for key in ("username", "display_name", "role"))
                + " "
                + scope_text
            )
            if self.needle not in haystack.casefold():
                return False
        return True

    def lessThan(self, left, right):
        left_payload = (
            self.sourceModel().data(self.sourceModel().index(left.row(), 0), Qt.UserRole) or {}
        )
        right_payload = (
            self.sourceModel().data(self.sourceModel().index(right.row(), 0), Qt.UserRole) or {}
        )
        if left.column() == self.revision_column:
            return int(left_payload.get("authority_revision") or 0) < int(
                right_payload.get("authority_revision") or 0
            )
        return super().lessThan(left, right)


class AccountCollectionSection(QWidget):
    """Employees or branch identities in one responsive workspace.

    Employee and branch identities are separated by the canonical server
    account_type field. Branch identity/scope remains server-owned.
    """

    scope_entity_requested = Signal(str, str)

    def __init__(self, controller, parent=None, *, account_mode: str = "employee"):
        super().__init__(parent)
        self.controller = controller
        self._snapshot: dict[str, Any] = {}
        self._account_mode = (
            "branch" if str(account_mode).strip().lower() == "branch" else "employee"
        )
        self._pending_save_identity = ""
        self._pending_assignment_uid = ""

        controls = load_ui(
            self,
            "admin_account_collection",
            required=(
                "AdminCountBadge",
                "admin_account_back",
                "admin_account_add",
                "admin_account_view",
                "admin_account_edit",
                "admin_account_assign",
                "admin_account_toggle",
                "admin_account_reset",
                "admin_account_scope",
                "admin_account_filter_host",
                "admin_account_table_host",
                "admin_account_collection",
                "AdminEditorScrollArea",
                "AdminWorkspacePanel",
                "admin_account_master_grid",
                "admin_account_actions",
            ),
        )
        self.count_badge: QLabel = controls["AdminCountBadge"]
        self.count_badge.setMinimumWidth(UI_METRICS.admin_collection_count_badge_min_width)
        self.count_badge.setMaximumWidth(UI_METRICS.admin_collection_count_badge_max_width)
        self.count_badge.setAlignment(Qt.AlignCenter)
        self.back: QPushButton = controls["admin_account_back"]
        self.back.setText(_("Back to list"))
        self.back.setProperty("variant", "secondary")
        self.back.hide()
        self.add: QPushButton = controls["admin_account_add"]
        self.add.setText(_("Add Employee"))
        self.filters = FilterBar(
            controls["admin_account_filter_host"],
            show_role=self._account_mode == "employee",
            show_scope=True,
            show_refresh=False,
        )
        controls["admin_account_filter_host"].layout().addWidget(self.filters)
        self.collection: QWidget = controls["admin_account_collection"]

        if self._account_mode == "branch":
            columns = [
                (
                    _("Branch"),
                    lambda row: AdministrationPresenter.branch_account_branch_display(row),
                ),
                (_("Username"), "username"),
                (_("Area"), lambda row: self._branch_hierarchy_value(row, "area")),
                (_("Region"), lambda row: self._branch_hierarchy_value(row, "region")),
                (
                    _("Status"),
                    lambda row: _("Active") if row.get("is_active") else _("Disabled"),
                ),
                (
                    _("Password"),
                    lambda row: (
                        _("Must change") if row.get("must_change_password") else _("Changed")
                    ),
                ),
                (_("Revision"), "authority_revision"),
            ]
        else:
            columns = [
                (_("Username"), "username"),
                (_("Name"), "display_name"),
                (
                    _("Role"),
                    lambda row: AdministrationPresenter.role_label(str(row.get("role") or "")),
                ),
                (
                    _("Status"),
                    lambda row: _("Active") if row.get("is_active") else _("Disabled"),
                ),
                (
                    _("Scope"),
                    lambda row: AdministrationPresenter.direct_scope_summary(row),
                ),
                (_("Revision"), "authority_revision"),
            ]

        self.model = AdminTableModel(columns, self)
        self.proxy = UserFilterProxy(self)
        self.proxy.revision_column = 6 if self._account_mode == "branch" else 5
        self.proxy.setSourceModel(self.model)
        # Bulk user mutation is intentionally disabled until a transactional server contract exists.
        self.table = AdminTableView(self.collection, multi_select=False)
        self.table.setModel(self.proxy)
        self.table.sortByColumn(0, Qt.AscendingOrder)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setCascadingSectionResizes(False)
        for column in range(len(columns)):
            header.setSectionResizeMode(column, QHeaderView.Interactive)
        if self._account_mode == "branch":
            for column in (0, 2, 3):
                header.setSectionResizeMode(column, QHeaderView.Stretch)
        else:
            # Username, display name and scope are the decision-making fields
            # in the employee list; do not squeeze the primary identity into a
            # content-width column.
            for column in (0, 1, 4):
                header.setSectionResizeMode(column, QHeaderView.Stretch)

        self.table_surface = DataSurface(self.table, self.collection)

        controls["admin_account_table_host"].layout().addWidget(self.table_surface)
        self.view_details: QPushButton = controls["admin_account_view"]
        self.edit: QPushButton = controls["admin_account_edit"]
        self.assign: QPushButton = controls["admin_account_assign"]
        self.toggle: QPushButton = controls["admin_account_toggle"]
        self.reset: QPushButton = controls["admin_account_reset"]
        self.open_scope: QPushButton = controls["admin_account_scope"]
        self.actions_grid: QGridLayout = controls["admin_account_actions"]
        self._account_action_buttons = [
            self.add,
            self.view_details,
            self.edit,
            self.assign,
            self.toggle,
            self.reset,
            self.open_scope,
        ]
        self._hidden_account_actions: set[QPushButton] = {self.view_details}
        for button, caption in (
            (self.add, _("Add Employee")),
            (self.view_details, _("View details")),
            (self.edit, _("Edit")),
            (self.assign, _("Edit assignments")),
            (self.toggle, _("Enable / Disable")),
            (self.reset, _("Reset password")),
            (self.open_scope, _("Open scope")),
        ):
            button.setText(caption)
            button.setProperty("variant", "secondary")
        self.view_details.hide()
        self.action_more = QToolButton(self.collection)
        self.action_more.setText(_("More"))
        self.action_more.setAccessibleName(_("More account actions"))
        self.action_more.setPopupMode(QToolButton.InstantPopup)
        self.action_more.setProperty("uiRole", "toolbarMore")
        self.action_more.setMinimumWidth(UI_METRICS.toolbar_more_min_width)
        self._action_more_menu = QMenu(self.action_more)
        self._action_more_menu.aboutToShow.connect(self._sync_action_more_menu)
        self.action_more.setMenu(self._action_more_menu)
        self.details = DetailsPanel(self)
        self.editor = UserEditorDialog(self)
        self.editor_scroll: QScrollArea = controls["AdminEditorScrollArea"]
        self.editor_scroll.setFrameShape(QFrame.NoFrame)
        self.editor_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.editor_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.editor_scroll.setWidget(self.editor)
        self.assignment = AssignmentEditorDialog(self)
        self.workspace_stack: QStackedWidget = controls["AdminWorkspacePanel"]
        self.workspace_panel = self.workspace_stack
        self.workspace_stack.addWidget(self.details)
        self.workspace_stack.addWidget(self.assignment)
        self.workspace_stack.setCurrentWidget(self.details)
        self._show_empty_details()
        self.master_detail_layout: QGridLayout = controls["admin_account_master_grid"]
        self.master_detail_layout.removeWidget(self.collection)
        self.master_detail_layout.removeWidget(self.workspace_panel)
        self.master_detail_split = SplitWorkspace(self.collection, self.workspace_panel, self)
        self.master_detail_layout.addWidget(self.master_detail_split, 0, 0, 1, 2)
        self.master_detail_split.compactChanged.connect(self.set_compact_mode)
        self.set_compact_mode(False)

        self.filters.changed.connect(self._apply_filters)
        self.filters.refresh_requested.connect(self.controller.refresh)
        if self._account_mode == "employee":
            self.controller.user_saved.connect(self._on_user_saved)
            self.controller.operation_failed.connect(self._on_operation_failed)
        self.add.clicked.connect(lambda: self._open_editor(None))
        self.view_details.clicked.connect(self._view_selected)
        self.edit.clicked.connect(self._edit_selected)
        self.assign.clicked.connect(self._assignment_selected)
        self.toggle.clicked.connect(self._toggle_selected)
        self.reset.clicked.connect(self._reset_selected)
        self.open_scope.clicked.connect(self._open_scope)
        self.editor.cancel_requested.connect(self._request_close_editor)
        self.editor.save_requested.connect(self._save_user)
        self.assignment.cancel_requested.connect(self._request_close_assignment)
        self.assignment.apply_requested.connect(self._submit_assignments)
        if self._account_mode == "employee":
            self.controller.assignments_saved.connect(self._on_assignments_saved)
        self.table.selectionModel().selectionChanged.connect(self._selection_changed)
        self.table.doubleClicked.connect(lambda _index: self._view_selected())
        self.table.customContextMenuRequested.connect(self._context_menu)

        if self._account_mode == "branch":
            self._hidden_account_actions.update((self.add, self.edit, self.assign))
            self.add.hide()
            self.edit.hide()
            self.assign.hide()
            # The branch-account workspace deliberately exposes fewer
            # mutating commands.  Reflow the real action strip after hiding
            # those controls so its table is not preceded by empty columns.
            self._layout_action_buttons(False)

    def _layout_action_buttons(self, compact: bool) -> None:
        """Lay out only commands that belong to the current account mode.

        The Designer form supplies every possible command so the employee and
        branch-account modes can share one authoritative layout.  A hidden
        command must not retain a grid cell: on branch accounts that made the
        action strip look sparse and pushed the useful controls away from the
        table.
        """
        while self.actions_grid.count():
            self.actions_grid.takeAt(0)
        for column in range(max(10, self.actions_grid.columnCount())):
            self.actions_grid.setColumnStretch(column, 0)
        visible_buttons = [
            button for button in self._account_action_buttons if button not in self._hidden_account_actions
        ]
        if compact:
            # Keep the same horizontal action strip at every supported width.
            # Secondary commands remain functional in More instead of being
            # rearranged into the tall two-column grid used by the legacy UI.
            primary = [button for button in (self.add, self.edit) if button in visible_buttons]
            if not primary:
                primary = visible_buttons[:1]
            row_buttons = primary + [self.action_more]
        else:
            row_buttons = visible_buttons
        for column, button in enumerate(row_buttons):
            self.actions_grid.addWidget(button, 0, column)
            self.actions_grid.setColumnStretch(column, 1 if button is not self.action_more else 0)
        count_column = len(row_buttons)
        self.actions_grid.addWidget(self.count_badge, 0, count_column)
        if not self.back.isHidden():
            self.actions_grid.addWidget(self.back, 0, count_column + 1)
        self.action_more.setVisible(
            compact and bool(self._secondary_actions(visible_buttons, row_buttons))
        )
        self._sync_action_more_menu()

    def _secondary_actions(
        self, visible_buttons: list[QPushButton], row_buttons: list[QPushButton | QToolButton]
    ) -> list[QPushButton]:
        return [
            button
            for button in visible_buttons
            if button not in row_buttons and button not in self._hidden_account_actions
        ]

    def _sync_action_more_menu(self) -> None:
        menu = self._action_more_menu
        menu.clear()
        visible_buttons = [
            button for button in self._account_action_buttons if button not in self._hidden_account_actions
        ]
        primary = [button for button in (self.add, self.edit) if button in visible_buttons]
        if not primary:
            primary = visible_buttons[:1]
        for source in self._secondary_actions(visible_buttons, primary + [self.action_more]):
            action = menu.addAction(source.text())
            action.setEnabled(source.isEnabled())
            action.triggered.connect(source.click)
        menu.setLayoutDirection(self.layoutDirection())

    def set_compact_mode(self, compact: bool) -> None:
        compact = bool(compact)
        self._layout_action_buttons(compact)
        # Compact mode changes composition, not the available business data.
        # Keep every table column accessible; the table owns horizontal overflow.
        for column in range(self.model.columnCount()):
            self.table.setColumnHidden(column, False)

        if getattr(self, "_master_detail_compact", None) == compact:
            return
        self._master_detail_compact = compact
        self.master_detail_split.setProperty("compactUi", compact)
        self.master_detail_split.set_compact(compact)

    def _branch_hierarchy_value(self, user: dict[str, Any], level: str) -> str:
        branch_id = AdministrationPresenter.branch_account_branch(user)
        if not branch_id:
            return "—"
        branch = next(
            (
                item
                for item in self._snapshot.get("branches") or []
                if isinstance(item, dict) and str(item.get("branch_id") or "") == branch_id
            ),
            None,
        )
        area_id = str(branch.get("area_id") or "").strip() if isinstance(branch, dict) else ""
        # The server's effective scope includes ancestors as context.  When
        # Structure itself is not viewable, that server-derived context is a
        # safe read-only fallback for a canonical one-branch account; never
        # infer hierarchy from username text.
        scope = user.get("scope") if isinstance(user.get("scope"), dict) else {}
        if not area_id:
            areas = [str(value).strip() for value in scope.get("areas") or [] if str(value).strip()]
            if len(areas) == 1:
                area_id = areas[0]
        if level == "area":
            return area_id or "—"
        area = next(
            (
                item
                for item in self._snapshot.get("areas") or []
                if isinstance(item, dict) and str(item.get("area_id") or "") == area_id
            ),
            None,
        )
        if level == "region":
            if isinstance(area, dict):
                region_id = str(area.get("region_id") or "").strip()
                if region_id:
                    return region_id
            regions = [
                str(value).strip() for value in scope.get("regions") or [] if str(value).strip()
            ]
            if len(regions) == 1:
                return regions[0]
        return "—"

    @staticmethod
    def _scope_options(snapshot: dict[str, Any]) -> list[tuple[str, str, str]]:
        # Build filter choices from server-visible structure when available, and
        # supplement them from the users' canonical direct-scope assignments.
        # Employees can be viewable even when Structure is not; the scope filter
        # must not silently become useless in that authority combination.
        options: dict[tuple[str, str], str] = {}
        for kind, key, ident_key in (
            ("organization", "organizations", "organization_id"),
            ("region", "regions", "region_id"),
            ("area", "areas", "area_id"),
            ("branch", "branches", "branch_id"),
        ):
            for item in snapshot.get(key) or []:
                if not isinstance(item, dict):
                    continue
                ident = str(item.get(ident_key) or "").strip()
                if ident:
                    options[(kind, ident)] = str(item.get("name") or ident)
        for user in snapshot.get("users") or []:
            if not isinstance(user, dict):
                continue
            for assignment in AdministrationPresenter.user_direct_assignments(user):
                kind = str(assignment.get("scope_type") or "").strip()
                ident = str(assignment.get("scope_id") or "").strip()
                if kind and ident:
                    options.setdefault((kind, ident), ident)
        return [(kind, ident, options[(kind, ident)]) for kind, ident in sorted(options)]

    def set_snapshot(self, snapshot: dict[str, Any]) -> None:
        self._snapshot = dict(snapshot or {})
        all_rows = [dict(item) for item in snapshot.get("users") or [] if isinstance(item, dict)]
        if self._account_mode == "branch":
            rows = [item for item in all_rows if AdministrationPresenter.is_branch_account(item)]
        else:
            rows = [
                item for item in all_rows if not AdministrationPresenter.is_branch_account(item)
            ]

        old = {str(item.get("username") or ""): item for item in self.model.rows()}
        new = {str(item.get("username") or ""): item for item in rows}
        if list(old) == list(new):
            for username, row in new.items():
                if old.get(username) != row:
                    self.model.replace_row(
                        lambda item, value=username: str(item.get("username") or "") == value,
                        row,
                    )
        else:
            self.model.replace_rows(rows)

        self.count_badge.setText(str(len(rows)))
        current_role = str(self.filters.role.currentData() or "")
        self.filters.role.blockSignals(True)
        self.filters.role.clear()
        self.filters.role.addItem(_("All roles"), "")
        roles = list(AdministrationPresenter.manageable_roles(snapshot))
        roles.extend(str(item.get("role") or "") for item in rows)
        roles = [
            role
            for role in roles
            if bool(role)
            and ((role != "store") if self._account_mode == "employee" else (role == "store"))
        ]
        for role in sorted(set(roles)):
            self.filters.role.addItem(AdministrationPresenter.role_label(role), role)
        index = self.filters.role.findData(current_role)
        self.filters.role.setCurrentIndex(index if index >= 0 else 0)
        self.filters.role.blockSignals(False)
        self.filters.set_scope_options(self._scope_options(snapshot))
        self._apply_filters()
        self._apply_capabilities()
        self._selection_changed()

    def _apply_capabilities(self) -> None:
        snapshot = self._snapshot
        is_employee = self._account_mode == "employee"
        self.add.setVisible(
            is_employee
            and AdministrationPresenter.has_capability(snapshot, "users.create")
            and self.workspace_stack.currentWidget() is self.details
        )
        self.edit.setVisible(
            is_employee and AdministrationPresenter.has_capability(snapshot, "users.update")
        )
        # Account state is a server-authorized user mutation.  The same client
        # control is available for branch identities only when the server has
        # granted the capability; it never changes branch structure locally.
        self.toggle.setVisible(
            AdministrationPresenter.has_capability(snapshot, "users.enable", "users.disable")
        )
        self.reset.setVisible(
            AdministrationPresenter.has_capability(snapshot, "users.password.reset")
        )
        self.assign.setVisible(
            is_employee and AdministrationPresenter.has_capability(snapshot, "users.scopes.assign")
        )

    def _apply_filters(self, *_args) -> None:
        self.proxy.set_filters(
            self.filters.search.text(),
            self.filters.role.currentData(),
            self.filters.status.currentData(),
            self.filters.scope.currentData(),
        )
        shown = self.proxy.rowCount()
        total = self.model.rowCount()
        self.filters.set_result_count(shown, total)
        self.table_surface.set_state("content")

    def selected_users(self) -> list[dict[str, Any]]:
        selected = self.table.selectionModel().selectedRows()
        if not selected:
            return []
        source = self.proxy.mapToSource(selected[0])
        row = self.model.row_payload(source.row())
        return [row] if row else []

    def _show_empty_details(self) -> None:
        """Keep a visible embedded inspector before the first selection."""
        self.details.set_details(
            _("Details"),
            [(_("Account"), _("Select an account to inspect its identity, role, scope and security."))],
        )

    def _selection_changed(self, *_args) -> None:
        users = self.selected_users()
        selected = len(users) == 1
        target = users[0] if selected else None
        if selected and self.workspace_stack.currentWidget() is not self.details:
            self._show_details(target)
            return
        if selected:
            self._show_details(target)
        else:
            self._show_empty_details()
        manageable = bool(
            selected and AdministrationPresenter.target_manageable(self._snapshot, target)
        )
        has_direct_scope = bool(
            selected and AdministrationPresenter.user_direct_assignments(target or {})
        )
        self.view_details.setEnabled(selected)
        self.edit.setEnabled(self.edit.isVisible() and manageable)
        next_status_permission = (
            "users.disable" if target and bool(target.get("is_active")) else "users.enable"
        )
        self.toggle.setEnabled(
            self.toggle.isVisible()
            and manageable
            and AdministrationPresenter.has_capability(self._snapshot, next_status_permission)
        )
        if self.toggle.isVisible():
            self.toggle.setText(
                _("Disable") if target and bool(target.get("is_active")) else _("Enable")
            )
        self.reset.setEnabled(self.reset.isVisible() and manageable)
        self.open_scope.setEnabled(has_direct_scope)
        self.assign.setEnabled(self.assign.isVisible() and manageable)

    def _show_details(self, user: dict[str, Any]) -> None:
        identity_fields: list[tuple[str, str]] = [
            (_("Username"), str(user.get("username") or "")),
        ]
        display_name = str(user.get("display_name") or "").strip()
        if self._account_mode == "employee" and display_name:
            identity_fields.append((_("Name"), display_name))

        if self._account_mode == "branch":
            branch_scope_state = AdministrationPresenter.branch_account_scope_state(user)
            branch_id = AdministrationPresenter.branch_account_branch(user)
            scope_state_label = {
                "valid": _("Valid branch link"),
                "missing": _("Missing direct branch scope"),
                "multiple_branches": _("Multiple direct branch scopes"),
                "mixed_or_invalid": _("Invalid mixed direct scope"),
            }.get(branch_scope_state, _("Invalid direct scope"))
            identity_fields.extend(
                [
                    (_("Branch"), branch_id or _("Scope mismatch")),
                    (_("Branch link"), scope_state_label),
                    (_("Area"), self._branch_hierarchy_value(user, "area")),
                    (_("Region"), self._branch_hierarchy_value(user, "region")),
                    (
                        _("Password state"),
                        _("Must change") if user.get("must_change_password") else _("Changed"),
                    ),
                ]
            )
        identity_fields.append(
            (_("Status"), _("Active") if user.get("is_active") else _("Disabled"))
        )

        authority_fields = [
            (
                _("Role"),
                AdministrationPresenter.role_label(str(user.get("role") or "")),
            ),
            (_("Authority revision"), str(user.get("authority_revision") or 0)),
        ]
        assignments = AdministrationPresenter.user_direct_assignments(user)
        permission_values = user.get("permissions")
        permission_count = (
            len(permission_values) if isinstance(permission_values, (list, tuple, set, dict)) else 0
        )
        permission_fields = [
            (_("Direct scope"), AdministrationPresenter.direct_scope_summary(user)),
            (_("Effective scope"), AdministrationPresenter.scope_summary(user.get("scope"))),
            (_("Direct assignments"), str(len(assignments))),
            (
                _("Granted permissions"),
                str(permission_count) if permission_count else _("Role-based"),
            ),
        ]
        security_fields = [
            (
                _("Password state"),
                _("Must change") if user.get("must_change_password") else _("Current"),
            ),
            (
                _("Account type"),
                _("Branch Account") if self._account_mode == "branch" else _("Employee"),
            ),
        ]
        title = (
            AdministrationPresenter.branch_account_branch(user)
            if self._account_mode == "branch"
            else display_name
        ) or str(user.get("username") or _("Account"))
        subtitle = (
            _("Branch Account")
            if self._account_mode == "branch"
            else AdministrationPresenter.role_label(str(user.get("role") or ""))
        )
        self.details.set_grouped_details(
            title,
            [
                (_("Identity"), identity_fields),
                (_("Authority & Role"), authority_fields),
                (_("Permissions & Scope"), permission_fields),
                (_("Security"), security_fields),
            ],
            subtitle=subtitle,
        )
        self.details.show()
        self.workspace_stack.setCurrentWidget(self.details)
        self._sync_workspace_controls()

    def _view_selected(self) -> None:
        users = self.selected_users()
        if len(users) == 1:
            self._show_details(users[0])

    def _open_editor(self, user) -> None:
        if self._account_mode != "employee":
            return
        allowed_roles = [
            role
            for role in AdministrationPresenter.manageable_roles(self._snapshot)
            if str(role) != "store"
        ]
        self.editor.configure(self._snapshot, user, allowed_roles=allowed_roles)
        self.editor.setMinimumHeight(0)
        self._restore_master_detail_layout()
        self.collection.show()
        self.workspace_panel.show()
        self.workspace_stack.setCurrentWidget(self.editor_scroll)
        self.editor.show()
        self._sync_workspace_controls()

    def _edit_selected(self) -> None:
        users = self.selected_users()
        if len(users) == 1 and AdministrationPresenter.target_manageable(self._snapshot, users[0]):
            self._open_editor(users[0])

    def _assignment_selected(self) -> None:
        if self._account_mode != "employee":
            return
        users = self.selected_users()
        if len(users) == 1 and AdministrationPresenter.target_manageable(self._snapshot, users[0]):
            self.assignment.configure(self._snapshot, users)
            self.workspace_stack.setCurrentWidget(self.assignment)
            self.assignment.show()
            self._sync_workspace_controls()

    def _submit_assignments(self, targets, ids) -> None:
        if self._account_mode != "employee":
            return
        uid = submit_reviewed_assignments(self, self.controller, targets, ids)
        if uid:
            self._pending_assignment_uid = uid

    def _on_operation_failed(self, operation_key: str, _failure: object) -> None:
        if self._account_mode != "employee":
            return
        key = str(operation_key or "")
        if key == "admin.user.save":
            self._pending_save_identity = ""
        elif key.startswith("admin.assignment.save:"):
            self._pending_assignment_uid = ""

    def _on_assignments_saved(self, user_id: str) -> None:
        if self._account_mode != "employee":
            return
        if str(user_id or "") != self._pending_assignment_uid:
            return
        self._pending_assignment_uid = ""
        self.assignment.hide()
        self._show_collection()

    def _save_user(self, payload: dict[str, Any]) -> None:
        identity = str(payload.get("user_id") or payload.get("username") or "").strip()
        started = self.controller.save_user(payload)
        if started is not None:
            self._pending_save_identity = identity

    def _on_user_saved(self, user: dict[str, Any]) -> None:
        if self._account_mode != "employee" or not self._pending_save_identity:
            return
        saved_ids = {
            str(user.get("user_id") or "").strip(),
            str(user.get("username") or "").strip(),
        }
        if self._pending_save_identity not in saved_ids:
            return
        self._pending_save_identity = ""
        self.editor.hide()
        self._show_collection()

    def _request_close_assignment(self) -> None:
        if self.assignment.isVisible() and self.assignment.is_dirty():
            answer = show_question_message(
                self,
                _("Unsaved changes"),
                _("Discard the unsaved assignment changes?")
            )
            if not answer:
                return
        self.assignment.hide()
        self._selection_changed()

    def _request_show_collection(self) -> None:
        """Return from the read-only details pane to the retained table."""
        self._show_collection()

    def _request_close_editor(self) -> None:
        if self.is_dirty():
            answer = show_question_message(
                self,
                _("Unsaved changes"),
                _("Discard the unsaved account changes?")
            )
            if not answer:
                return
        self.editor.hide()
        self._show_collection()

    def _show_collection(self) -> None:
        self.workspace_stack.setCurrentWidget(self.details)
        self._restore_master_detail_layout()
        self.collection.show()
        self.workspace_panel.show()
        self.editor.hide()
        self.assignment.hide()
        self._sync_workspace_controls()
        self._selection_changed()

    def _restore_master_detail_layout(self) -> None:
        """Restore the single canonical master/detail composition.

        SplitWorkspace owns both child widgets. Never pull those widgets back into
        the outer grid during resize; doing so causes parent/layout conflicts and
        the floating/overlapping editor composition seen at runtime.
        """
        if self.master_detail_layout.indexOf(self.master_detail_split) < 0:
            self.master_detail_layout.addWidget(self.master_detail_split, 0, 0, 1, 2)
        self.master_detail_split.show()
        self.master_detail_split.set_compact(bool(getattr(self, "_master_detail_compact", False)))
        self.master_detail_layout.setColumnStretch(0, 1)
        self.master_detail_layout.setColumnStretch(1, 0)
        self.master_detail_layout.setRowStretch(0, 1)
        self.master_detail_layout.setRowStretch(1, 0)

    def _sync_workspace_controls(self) -> None:
        self.filters.setVisible(True)
        self.back.setVisible(False)
        self.add.setVisible(
            self._account_mode == "employee"
            and AdministrationPresenter.has_capability(self._snapshot, "users.create")
            and self.workspace_stack.currentWidget() is self.details
        )

    def _toggle_selected(self) -> None:
        users = self.selected_users()
        if len(users) == 1 and AdministrationPresenter.target_manageable(self._snapshot, users[0]):
            user = users[0]
            target_active = not bool(user.get("is_active"))
            username = str(user.get("username") or user.get("user_id") or "").strip()
            verb = _("Enable") if target_active else _("Disable")
            answer = show_question_message(
                self,
                _("Confirm account status"),
                _("{action} employee account {username}?").format(
                    action=verb, username=username or "—"
                )
            )
            if answer:
                self.controller.set_user_active(user, target_active)

    def _reset_selected(self) -> None:
        users = self.selected_users()
        if len(users) != 1 or not AdministrationPresenter.target_manageable(
            self._snapshot, users[0]
        ):
            return
        value, ok = QInputDialog.getText(
            self,
            _("Reset password"),
            _("Temporary password"),
            QLineEdit.Password,
        )
        if ok:
            self.controller.reset_password(users[0], value or None)

    def _open_scope(self) -> None:
        users = self.selected_users()
        if len(users) != 1:
            return
        assignments = AdministrationPresenter.user_direct_assignments(users[0])
        if not assignments:
            return

        selected = assignments[0]
        if len(assignments) > 1:
            # Multi/mixed scope is a first-class server contract.  Never jump to
            # an arbitrary first assignment when more than one direct scope is
            # present; let the administrator choose the exact structure node.
            labels = [
                f"{_(str(item.get('scope_type') or '').replace('_', ' ').title())} — "
                f"{str(item.get('scope_id') or '')}"
                for item in assignments
            ]
            label, accepted = QInputDialog.getItem(
                self,
                _("Open direct scope"),
                _("Select the direct scope to open"),
                labels,
                0,
                False,
            )
            if not accepted or label not in labels:
                return
            selected = assignments[labels.index(label)]

        self.scope_entity_requested.emit(
            str(selected.get("scope_type") or ""),
            str(selected.get("scope_id") or ""),
        )

    def _context_menu(self, pos) -> None:
        index = self.table.indexAt(pos)
        if index.isValid() and not self.table.selectionModel().isSelected(index):
            self.table.selectRow(index.row())
        users = self.selected_users()
        if len(users) != 1:
            return
        menu = QMenu(self)
        menu.addAction(_("View details"), self._view_selected)
        if self.edit.isVisible() and self.edit.isEnabled():
            menu.addAction(_("Edit"), self._edit_selected)
        if self.assign.isVisible() and self.assign.isEnabled():
            menu.addAction(_("Edit assignments"), self._assignment_selected)
        if self.toggle.isVisible() and self.toggle.isEnabled():
            menu.addAction(self.toggle.text(), self._toggle_selected)
        if self.reset.isVisible() and self.reset.isEnabled():
            menu.addAction(_("Reset password"), self._reset_selected)
        if AdministrationPresenter.user_direct_assignments(users[0]):
            menu.addAction(_("Open scope"), self._open_scope)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def select_user(self, ident: str) -> bool:
        target = str(ident or "").strip().casefold()
        if not target:
            return False
        self._show_collection()
        self.filters.search.clear()
        self.filters.role.setCurrentIndex(0)
        self.filters.status.setCurrentIndex(0)
        self.filters.scope.setCurrentIndex(0)
        for source_row, row in enumerate(self.model.rows()):
            if target in {
                str(row.get("username") or "").casefold(),
                str(row.get("user_id") or "").casefold(),
            }:
                source = self.model.index(source_row, 0)
                proxy_index = self.proxy.mapFromSource(source)
                if proxy_index.isValid():
                    self.table_surface.set_state("content")
                    self.table.selectRow(proxy_index.row())
                    self.table.scrollTo(proxy_index)
                    self._show_details(row)
                    return True
        return False

    def is_dirty(self) -> bool:
        if self.workspace_stack.currentWidget() is self.editor:
            return bool(self.editor.is_dirty())
        if self.workspace_stack.currentWidget() is self.assignment:
            return bool(self.assignment.is_dirty())
        return False
