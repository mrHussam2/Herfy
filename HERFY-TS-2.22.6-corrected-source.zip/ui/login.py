from __future__ import annotations

import logging
from typing import Any

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QApplication,
    QBoxLayout,
    QDialog,
    QFormLayout,
    QFrame,
    QLabel,
    QLineEdit,
    QMenu,
    QPushButton,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.i18n import available_languages, get_language, tr
from core.settings import _, canonical_error_message, user_error_message
from ui.designer import load_ui
from ui.dialogs import apply_popup_contract
from ui.theme import (
    UI_METRICS,
    ResponsiveProfile,
    apply_profile_properties,
    ensure_layout_mode_controller,
    make_scaler,
    polish_interface,
    profile_for_widget,
)
from ui.widgets import polish_button, polish_form_layout, polish_line_edits, widget_alive


class PasswordField(QFrame):
    """Canonical password input used by Settings and the mandatory password gate."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        controls = load_ui(
            self, "password_field", required=("PasswordInput", "PasswordVisibilityButton")
        )
        self.edit = controls["PasswordInput"]
        self.edit.setEchoMode(QLineEdit.Password)
        self.edit.setClearButtonEnabled(False)
        self.toggle = controls["PasswordVisibilityButton"]
        self.toggle.setText(_("Show"))
        self.toggle.setCheckable(True)
        self.toggle.setAutoRaise(True)
        self.toggle.setToolTip(_("Show"))
        self.toggle.toggled.connect(self._toggle)

    def _toggle(self, checked: bool) -> None:
        self.edit.setEchoMode(QLineEdit.Normal if checked else QLineEdit.Password)
        text = _("Hide") if checked else _("Show")
        self.toggle.setText(text)
        self.toggle.setToolTip(text)

    def text(self) -> str:
        return self.edit.text()

    def clear(self) -> None:
        self.edit.clear()
        if self.toggle.isChecked():
            self.toggle.setChecked(False)

    def setEnabled(self, enabled: bool) -> None:  # noqa: N802 - Qt API compatibility
        super().setEnabled(enabled)
        self.edit.setEnabled(enabled)
        self.toggle.setEnabled(enabled)


class MandatoryPasswordGate(QDialog):
    """Application-modal server-authoritative first-login password gate."""

    password_changed = Signal(object)
    logout_requested = Signal()

    def __init__(self, account_security: Any, worker_registry, parent=None) -> None:
        super().__init__(parent)
        self.account_security = account_security
        if worker_registry is None:
            raise RuntimeError("MandatoryPasswordGate requires a worker registry")
        self.workers = worker_registry
        self.password_policy: dict[str, Any] = {}
        self._completed = False
        self._logout_emitted = False

        self.setWindowTitle("HERFY-TS")
        apply_popup_contract(
            self,
            object_name="MandatoryPasswordGate",
            modal=True,
            size_grip=False,
            width_ratio=0.34,
            height_ratio=0.38,
            min_width=440,
            min_height=350,
            max_width=560,
            max_height=460,
        )
        self.setWindowModality(Qt.ApplicationModal)
        self._build_ui()
        self._load_policy()
        QTimer.singleShot(0, self.new_password.edit.setFocus)

    def _build_ui(self) -> None:
        controls = load_ui(
            self,
            "mandatory_password_gate",
            required=(
                "MandatoryPasswordIntro",
                "MandatoryPasswordFieldsCard",
                "MandatoryPasswordActions",
                "MandatoryPasswordPolicy",
                "PasswordDialogStatus",
                "mandatory_new_host",
                "mandatory_confirm_host",
                "mandatory_logout",
                "mandatory_change",
            ),
        )
        self.policy_label: QLabel = controls["MandatoryPasswordPolicy"]
        self.status: QLabel = controls["PasswordDialogStatus"]
        self.status.hide()
        fields = (
            ("new_password", "mandatory_new_host", _("New Password")),
            ("confirm_password", "mandatory_confirm_host", _("Confirm New Password")),
        )
        for attribute, host_name, caption in fields:
            host = controls[host_name]
            field = PasswordField(host)
            host.layout().addWidget(field)
            field.edit.setPlaceholderText(caption)
            setattr(self, attribute, field)
            self.findChild(QLabel, host_name + "_label").setText(caption)
        self.logout_button: QPushButton = controls["mandatory_logout"]
        self.change_button: QPushButton = controls["mandatory_change"]
        self.logout_button.setText(_("Logout"))
        self.change_button.setText(_("Change Password"))
        self.logout_button.setProperty("variant", "secondary")
        self.change_button.setProperty("variant", "primary")
        self.findChild(QLabel, "PasswordDialogTitle").setText(_("Change your password"))
        self.findChild(QLabel, "PasswordDialogHint").setText(_("Set a new password to continue."))
        self.policy_label.setText(_("Loading password requirements..."))
        # Keep Qt signal dispatch on a Python callable boundary. Direct bound
        # method connections can crash in the PySide6
        # adapter on Windows while this required dialog is being constructed.
        self.change_button.clicked.connect(lambda *_: self._submit())
        self.logout_button.clicked.connect(lambda *_: self._logout())
        self.confirm_password.edit.returnPressed.connect(lambda: self._submit())

    def _set_status(self, text: str, kind: str = "info") -> None:
        self.status.setText(str(text or ""))
        self.status.setProperty("statusKind", str(kind))
        self.status.setVisible(bool(text))
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)

    def _load_policy(self) -> None:
        self._set_status(_("Loading password requirements..."), "busy")
        self.workers.start(
            self.account_security.password_policy,
            on_result=self._on_policy,
            on_error=lambda msg: self._set_status(str(msg), "error"),
            operation_key="mandatory-password:policy",
            log_exceptions=False,
        )

    def _on_policy(self, payload: object) -> None:
        self.password_policy = dict(payload) if isinstance(payload, dict) else {}
        minimum = int(self.password_policy.get("min_length") or 1)
        maximum = int(self.password_policy.get("max_length") or 512)
        has_complexity_rules = (
            minimum > 1
            or bool(self.password_policy.get("require_letter"))
            or bool(self.password_policy.get("require_digit"))
        )
        requirements = (
            []
            if not has_complexity_rules
            else [_("Minimum {count} characters").format(count=minimum)]
        )
        if self.password_policy.get("require_letter"):
            requirements.append(_("at least one letter"))
        if self.password_policy.get("require_digit"):
            requirements.append(_("at least one digit"))
        self.policy_label.setText(
            " • ".join(requirements) if requirements else _("Choose any non-empty password.")
        )
        for field in (self.new_password, self.confirm_password):
            field.edit.setMaxLength(maximum)
        self._set_status("")

    def _set_busy(self, busy: bool, text: str = "") -> None:
        for widget in (
            self.new_password,
            self.confirm_password,
            self.change_button,
            self.logout_button,
        ):
            widget.setEnabled(not busy)
        self._set_status(text, "busy" if busy else "error" if text else "info")

    def _submit(self) -> None:
        new = self.new_password.text()
        confirm = self.confirm_password.text()
        if not new or not confirm:
            self._set_status(_("All password fields are required."), "warning")
            return
        if new != confirm:
            self._set_status(_("New password and confirmation do not match."), "warning")
            return

        self._set_busy(True, _("Changing password..."))
        account_security = self.account_security
        self.workers.start(
            lambda: account_security.change_password(None, new),
            on_result=self._on_changed,
            on_error=lambda msg: self._set_busy(False, str(msg)),
            on_finished=lambda: None,
            operation_key="mandatory-password:change",
            log_exceptions=False,
        )

    def _on_changed(self, result: object) -> None:
        payload = dict(result) if isinstance(result, dict) else {}
        if payload.get("ok") is not True:
            self._set_busy(False, _("Failed to change password."))
            return
        self._completed = True
        for field in (self.new_password, self.confirm_password):
            field.clear()
        self.password_changed.emit(payload)
        self.accept()

    def _request_logout_once(self) -> None:
        if self._completed or self._logout_emitted:
            return
        self._logout_emitted = True
        self.logout_requested.emit()

    def _logout(self) -> None:
        self._request_logout_once()
        super().reject()

    def reject(self) -> None:
        self._request_logout_once()
        super().reject()

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt API
        self._request_logout_once()
        self.workers.close()
        super().closeEvent(event)


logger = logging.getLogger(__name__)


class LoginControllerMixin:
    def _close_login_workers(self, *_args) -> None:
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            try:
                registry.close()
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Login worker registry close failed", exc_info=True)

    def is_runtime_ready(self) -> bool:
        widgets = (
            getattr(self, "btn_login", None),
            getattr(self, "ed_user", None),
            getattr(self, "ed_pass", None),
            getattr(self, "chk_remember", None),
            getattr(self, "progress", None),
            getattr(self, "lbl_status", None),
        )
        return all((widget_alive(widget) for widget in widgets))

    def _schedule_login_draft_save(self, *_args):
        if not self.is_runtime_ready():
            return
        try:
            self._draft_save_timer.start()
        except UI_OPERATION_EXCEPTIONS:
            self._flush_login_draft()

    def _queue_login_draft_save(self, username: str, remember: bool) -> None:
        registry = getattr(self, "_worker_registry", None)
        persistence = getattr(self, "_session_persistence", None)
        if registry is None or persistence is None:
            return
        snapshot = (str(username or "").strip(), bool(remember))
        self._login_draft_pending = snapshot
        if registry.has_active_key("login:draft-persist"):
            return
        current = self._login_draft_pending
        self._login_draft_pending = None

        def _work(progress_callback=None):
            del progress_callback
            persistence.save_login_form_state(username=current[0], remember=current[1])
            return None

        def _finished():
            pending = getattr(self, "_login_draft_pending", None)
            if pending is not None and pending != current and self.is_runtime_ready():
                self._queue_login_draft_save(pending[0], pending[1])

        worker = registry.start(
            _work,
            on_finished=_finished,
            operation_key="login:draft-persist",
            log_exceptions=False,
        )
        if worker is None and getattr(self, "_login_draft_pending", None) is None:
            self._login_draft_pending = current

    def _flush_login_draft(self):
        if not self.is_runtime_ready():
            return
        self._queue_login_draft_save(
            self.ed_user.text().strip(),
            bool(self.chk_remember.isChecked()),
        )

    def _apply_login_form_state(self, state, *, clear_password: bool = False) -> None:
        if not self.is_runtime_ready():
            return
        username = str(getattr(state, "username", "") or "").strip()
        if username and (not self.ed_user.text().strip()):
            self.ed_user.setText(username)
        try:
            self.chk_remember.setChecked(bool(getattr(state, "remember", False)))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("LoginPage.restore_cached_input fallback failed", exc_info=True)
        if clear_password:
            self.ed_pass.clear()
        if self.ed_user.text().strip():
            self.ed_pass.setFocus()
        else:
            self.ed_user.setFocus()

    def restore_cached_input(self, *, clear_password: bool = False):
        if not self.is_runtime_ready():
            return
        if clear_password:
            self.ed_pass.clear()
        registry = getattr(self, "_worker_registry", None)
        persistence = getattr(self, "_session_persistence", None)
        if registry is None or persistence is None:
            return
        restore_token = int(getattr(self, "_login_form_restore_token", 0) or 0) + 1
        self._login_form_restore_token = restore_token

        def _work(progress_callback=None):
            del progress_callback
            return persistence.load_login_form_state()

        def _apply(state):
            if restore_token != int(getattr(self, "_login_form_restore_token", -1) or -1):
                return
            self._apply_login_form_state(state, clear_password=clear_password)

        registry.start(
            _work,
            on_result=_apply,
            operation_key="login:form-restore",
            scope_checker=self.is_runtime_ready,
            log_exceptions=False,
        )

    def prepare_for_logout(self):
        if not self.is_runtime_ready():
            return
        self._login_token = int(getattr(self, "_login_token", 0) or 0) + 1
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            registry.cancel_all()
        # cancel_all() invalidates callbacks from the previous worker generation,
        # so that worker's on_finished callback cannot clear this page-owned
        # reference. Reset it explicitly so logout -> login works immediately.
        self._login_worker = None
        self._set_busy(False, "")
        self.lbl_status.clear()
        self.restore_cached_input(clear_password=True)

    def set_transition_busy(self, busy: bool, text: str = ""):
        self._set_busy(busy, text)

    def _set_busy(self, busy: bool, text: str = ""):
        if not self.is_runtime_ready():
            return
        self.btn_login.setEnabled(not busy)
        self.ed_user.setEnabled(not busy)
        self.ed_pass.setEnabled(not busy)
        self.chk_remember.setEnabled(not busy)
        for control in tuple(getattr(self, "_auxiliary_controls", ()) or ()):
            try:
                control.setEnabled(not busy)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Login auxiliary control state update failed", exc_info=True)
        self.progress.setVisible(bool(busy))
        self.lbl_status.setText(text)

    def do_login(self):
        if not self.is_runtime_ready():
            return
        if self._login_worker is not None:
            return
        u = self.ed_user.text().strip()
        p = self.ed_pass.text()
        if not u or not p:
            self.lbl_status.setText(canonical_error_message("missing_credentials"))
            return
        self._flush_login_draft()
        try:
            marker = getattr(self.main_window, "_advance_runtime_generation", None)
            if callable(marker):
                marker()
            setattr(self.main_window, "_restore_session_running", False)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("LoginPage.do_login restore cancellation failed", exc_info=True)
        self._set_busy(True, _("Signing in..."))
        authentication_service = self._authentication_service

        def _work(progress_callback=None):
            del progress_callback
            return authentication_service.sign_in(u, p)

        self._login_token = int(getattr(self, "_login_token", 0) or 0) + 1
        login_token = self._login_token

        def _is_current_login() -> bool:
            return login_token == int(getattr(self, "_login_token", -1) or -1)

        worker = self._worker_registry.start(
            _work,
            on_result=self._on_login_result,
            on_error=self._on_login_error,
            on_finished=self._on_login_finished,
            operation_key="login:submit",
            scope_checker=_is_current_login,
            log_exceptions=False,
        )
        self._login_worker = worker
        if worker is None:
            self._on_login_finished()

    def _on_login_finished(self):
        self._login_worker = None
        try:
            if hasattr(self.main_window, "_end_ui_transition"):
                self.main_window._end_ui_transition()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("LoginPage._on_login_finished fallback failed", exc_info=True)

    def _on_login_result(self, result):
        try:
            sess, prof = result
        except UI_OPERATION_EXCEPTIONS:
            self._on_login_error(canonical_error_message("invalid_response"))
            return

        # Authentication has completed.  Do not leave the login form in a
        # permanent "Signing in..." state while the shell performs its UI
        # transition or opens the mandatory password-change dialog.
        self._set_busy(False, "")
        self._flush_login_draft()

        try:
            self.main_window.on_login_success(
                sess,
                prof,
                remember=bool(self.chk_remember.isChecked()),
            )
            self.ed_pass.clear()
            logger.info(
                "LOGIN_UI_TRANSITION=PASS username=%s must_change_password=%s",
                str(getattr(prof, "username", "") or ""),
                bool(getattr(prof, "must_change_password", False)),
            )
        except Exception:
            # A successful HTTP login must never leave a half-authenticated,
            # unusable shell.  Fail closed, log the real UI exception and
            # return the user to a clean login state.
            logger.exception("Post-login UI transition failed")
            try:
                logout = getattr(self.main_window, "logout", None)
                if callable(logout):
                    logout()
            except Exception:
                logger.exception("Post-login rollback failed")
            self._on_login_error(canonical_error_message("operation_failed"))

    def _on_login_error(self, error):
        if isinstance(error, tuple) and len(error) >= 2:
            message = str(error[1])
        else:
            message = str(error)
        self._set_busy(False, "")
        self.lbl_status.setText(user_error_message(message, context="login"))
        self.ed_pass.selectAll()
        self.ed_pass.setFocus()


logger = logging.getLogger(__name__)


class LoginPage(LoginControllerMixin, QWidget):
    def __init__(
        self,
        main_window,
        *,
        worker_registry,
        authentication_service,
        session_persistence,
        parent=None,
    ):
        super().__init__(parent)
        self.main_window = main_window
        self.setProperty("uiScope", "login")
        if worker_registry is None:
            raise RuntimeError("LoginPage requires a composed worker scope")
        self._worker_registry = worker_registry
        self._login_worker = None
        self._login_token = 0
        if authentication_service is None:
            raise RuntimeError("LoginPage requires AuthenticationService")
        if session_persistence is None:
            raise RuntimeError("LoginPage requires SessionPersistenceService")
        self._authentication_service = authentication_service
        self._session_persistence = session_persistence
        self._draft_save_timer = QTimer(self)
        self._draft_save_timer.setSingleShot(True)
        self._draft_save_timer.setInterval(250)
        # Use Python callables at the Qt boundary.  Directly connecting the
        # inherited bound methods can crash under the PySide6 binding
        # during page construction on Windows.
        self._draft_save_timer.timeout.connect(lambda: self._flush_login_draft())
        self.destroyed.connect(lambda *_: self._close_login_workers())
        S = make_scaler(QApplication.instance())
        controls = load_ui(
            self,
            "login_page",
            required=(
                "login_username",
                "login_password",
                "login_submit",
                "LoginRememberCheck",
                "LoginProgress",
                "LoginStatusLabel",
                "LoginBody",
                "LoginFormCard",
                "LoginInfoText",
                "login_password_toggle",
                "login_forgot",
                "login_help",
                "login_language",
            ),
        )
        self._shell_layout = self.findChild(QVBoxLayout, "login_shell_layout")
        self._body = controls["LoginBody"]
        self._form_card = controls["LoginFormCard"]
        self.lbl_scope = controls["LoginInfoText"]
        self.ed_user = controls["login_username"]
        self.ed_user.setPlaceholderText(_("Username or email"))
        self.ed_pass = controls["login_password"]
        self.ed_pass.setPlaceholderText(_("Password"))
        self.ed_pass.setEchoMode(QLineEdit.Password)
        self.btn_password_toggle = controls["login_password_toggle"]
        self.btn_password_toggle.setText(_("Show"))
        self.btn_password_toggle.setToolTip(_("Show password"))
        self.btn_password_toggle.setCursor(Qt.PointingHandCursor)
        self.btn_password_toggle.setCheckable(True)
        self.btn_password_toggle.toggled.connect(
            lambda checked: self._toggle_password_visibility(checked)
        )

        self.btn_forgot: QToolButton = controls["login_forgot"]
        self.btn_forgot.setText(_("Forgot Password?"))
        self.btn_forgot.setToolTip(_("Contact your administrator to reset your password."))
        self.btn_forgot.setCursor(Qt.PointingHandCursor)
        self.btn_forgot.clicked.connect(lambda: self._show_account_recovery_help())

        self.btn_help: QToolButton = controls["login_help"]
        self.btn_help.setText(_("Need Help?"))
        self.btn_help.setToolTip(_("Contact your administrator for account assistance."))
        self.btn_help.setCursor(Qt.PointingHandCursor)
        self.btn_help.clicked.connect(lambda: self._show_login_help())

        self.btn_language: QToolButton = controls["login_language"]
        self.btn_language.setText(_("Language Options"))
        self.btn_language.setToolTip(_("Choose the application language."))
        self.btn_language.setCursor(Qt.PointingHandCursor)
        self._configure_language_menu()

        self._auxiliary_controls = (
            self.btn_password_toggle,
            self.btn_forgot,
            self.btn_help,
            self.btn_language,
        )
        self._credential_inputs = (self.ed_user, self.ed_pass)
        polish_line_edits((self.ed_user, self.ed_pass), min_height=S(UI_METRICS.control_min_height))
        self._credentials_form = self.findChild(QFormLayout, "login_credentials_form")
        polish_form_layout(self._credentials_form, horizontal_spacing=S(6), vertical_spacing=S(6))
        self.chk_remember = controls["LoginRememberCheck"]
        self.chk_remember.setText(_("Remember me"))
        self.chk_remember.setToolTip(_("Keep this account signed in on this device."))
        self.progress = controls["LoginProgress"]
        self.progress.setRange(0, 0)
        self.progress.setTextVisible(False)
        self.progress.setVisible(False)
        self.progress.setMinimumHeight(S(UI_METRICS.progress_thin_height))
        self.lbl_status = controls["LoginStatusLabel"]
        self.lbl_status.setWordWrap(True)
        self.btn_login = controls["login_submit"]
        self.btn_login.setText(_("Sign in"))
        polish_button(
            self.btn_login,
            role="primary",
            min_width=S(UI_METRICS.action_button_min_width),
            min_height=S(UI_METRICS.action_button_min_height),
            cursor=Qt.PointingHandCursor,
        )
        self.btn_login.clicked.connect(lambda *_: self.do_login())
        self._form_card.setProperty("uiRole", "loginCard")
        form_layout = self.findChild(QVBoxLayout, "login_form_layout")
        if form_layout is not None:
            form_layout.setContentsMargins(S(20), S(20), S(20), S(18))
            form_layout.setSpacing(S(8))
        self._form_card.setMinimumWidth(S(UI_METRICS.login_card_min_width))
        self._form_card.setMaximumWidth(S(UI_METRICS.login_card_max_width))
        self._body.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self._set_designer_copy()
        self.ed_pass.returnPressed.connect(lambda: self.do_login())
        self.ed_user.returnPressed.connect(lambda: self.ed_pass.setFocus())
        self.ed_user.textChanged.connect(lambda *_: self._schedule_login_draft_save())
        self.chk_remember.toggled.connect(lambda *_: self._flush_login_draft())
        self.restore_cached_input(clear_password=True)
        self._apply_login_layout()
        polish_interface(self, window_width=self.width())

    def _toggle_password_visibility(self, visible: bool) -> None:
        self.ed_pass.setEchoMode(QLineEdit.Normal if visible else QLineEdit.Password)
        self.btn_password_toggle.setText(_("Hide") if visible else _("Show"))
        self.btn_password_toggle.setToolTip(_("Hide password") if visible else _("Show password"))
        self.ed_pass.setFocus()

    def _show_account_recovery_help(self) -> None:
        """Expose the supported recovery path without inventing a public reset API."""
        self.lbl_status.setText(_("Contact your administrator to reset your password."))

    def _show_login_help(self) -> None:
        self.lbl_status.setText(_("Contact your administrator for account assistance."))

    def _configure_language_menu(self) -> None:
        menu = QMenu(self.btn_language)
        current = str(get_language() or "en")
        for code in available_languages():
            action = menu.addAction(tr(f"settings.language.{code}"))
            action.setCheckable(True)
            action.setChecked(code == current)
            action.triggered.connect(
                lambda _checked=False, language_code=code: self._request_language_change(
                    language_code
                )
            )
        self.btn_language.setMenu(menu)
        self.btn_language.setPopupMode(QToolButton.InstantPopup)

    def _request_language_change(self, language_code: str) -> None:
        wanted = str(language_code or "").strip().lower()
        if not wanted or wanted == str(get_language() or "").strip().lower():
            return

        runtime = getattr(self.main_window, "runtime", None)
        settings_service = getattr(runtime, "settings_service", None)
        registry = getattr(self, "_worker_registry", None)
        if settings_service is None or registry is None:
            self.lbl_status.setText(_("Unable to save the language preference."))
            return

        self._set_busy(True, _("Saving language preference..."))

        def _work(progress_callback=None):
            del progress_callback
            settings_service.set_runtime_value("language", wanted)
            return wanted

        def _saved(_result):
            self.lbl_status.setText(_("Restarting HERFY-TS to apply the language change..."))
            restart = getattr(self.main_window, "_restart_after_language_change", None)
            if callable(restart):
                restart()
            else:
                self._set_busy(False, _("Restart HERFY-TS to apply the language change."))

        def _error(_message):
            self._set_busy(False, _("Unable to save the language preference."))

        worker = registry.start(
            _work,
            on_result=_saved,
            on_error=_error,
            operation_key="login:language",
            scope_checker=self.is_runtime_ready,
            log_exceptions=False,
        )
        if worker is None:
            self._set_busy(False, _("Unable to save the language preference."))

    def _set_designer_copy(self) -> None:
        """Translate text that lives in the Designer hierarchy."""
        copy = {
            "login_form_title": (_("Sign in"), "pageTitle"),
            "login_username_label": (_("Username or email"), None),
            "login_password_label": (_("Password"), None),
        }
        for name, (text, role) in copy.items():
            label = self.findChild(QLabel, name)
            if label is not None:
                label.setText(text)
                if role:
                    label.setProperty("uiRole", role)

    def apply_responsive_profile(self, profile: ResponsiveProfile | None = None) -> None:
        self._apply_login_layout(profile=profile)

    def _apply_login_layout(self, profile: ResponsiveProfile | None = None):
        try:
            profile = profile or profile_for_widget(self, app=QApplication.instance())
            apply_profile_properties(self, profile)
            body = getattr(self, "_body", None)
            form = getattr(self, "_form_card", None)
            if body is None or form is None:
                return
            layout = body.layout()
            if not isinstance(layout, QBoxLayout):
                return
            layout.setDirection(QBoxLayout.LeftToRight)
            layout.setSpacing(0)
            form.setMinimumWidth(UI_METRICS.login_card_min_width)
            form.setMaximumWidth(UI_METRICS.login_card_max_width)
            form.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
            body.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
            body.setMinimumWidth(0)
            body.setMaximumWidth(UI_METRICS.login_card_max_width)
            shell_layout = getattr(self, "_shell_layout", None)
            if shell_layout is not None:
                margin = max(6, int(profile.page_margin))
                shell_layout.setContentsMargins(margin, margin, margin, margin)
            for field in getattr(self, "_credential_inputs", ()):
                field.setMinimumHeight(profile.control_height)
                field.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self.btn_login.setMinimumHeight(
                profile.touch_target if profile.touch_mode else UI_METRICS.action_button_min_height
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("LoginPage responsive layout failed", exc_info=True)

    def resizeEvent(self, event):
        """Reflow login only when the semantic layout/profile changes."""
        super().resizeEvent(event)
        try:
            controller = ensure_layout_mode_controller(
                self, attr_name="_login_layout_mode_controller"
            )
            if not bool(getattr(self, "_login_layout_mode_connected", False)):
                controller.reflowRequested.connect(self._on_login_layout_reflow_requested)
                self._login_layout_mode_connected = True
            controller.schedule()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("LoginPage responsive resize failed", exc_info=True)
            self._on_login_layout_reflow_requested("", None)

    def _on_login_layout_reflow_requested(self, _mode=None, _profile=None) -> None:
        """Apply the login layout after a semantic profile transition."""
        self._apply_login_layout()
        polish_interface(self, window_width=self.width())


__all__ = ["LoginPage"]
