from __future__ import annotations

import logging

from PySide6.QtCore import QPoint, QRectF, QSize, Qt, Signal
from PySide6.QtGui import (
    QColor,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.settings import _
from ui.administration_controller import AdministrationPresenter
from ui.designer import load_ui
from ui.theme_metrics import UI_METRICS
from ui.theme_responsive import (
    apply_profile_properties,
    apply_screen_device_properties,
    profile_for_dimensions,
    profile_for_widget,
    screen_device_profile,
)
from ui.widgets import (
    NotificationBadgeButton,
    apply_button_icon,
    build_logo_label,
)

logger = logging.getLogger(__name__)


class SidebarDrawerPopup(QFrame):
    """Popup host for the existing Sidebar widget in small-window mode."""

    dismissed = Signal()

    def hideEvent(self, event) -> None:  # noqa: N802 - Qt API
        super().hideEvent(event)
        self.dismissed.emit()


def _restore_sidebar_from_drawer(window) -> None:
    sidebar = getattr(window, "sidebar", None)
    popup = getattr(window, "sidebar_drawer_popup", None)
    host = getattr(window, "sidebar_host", None)
    host_layout = getattr(window, "sidebar_host_layout", None)
    if sidebar is None or popup is None or host is None or host_layout is None:
        return

    popup_layout = popup.layout()
    if sidebar.parentWidget() is popup:
        if popup_layout is not None:
            popup_layout.removeWidget(sidebar)
        sidebar.setParent(host)
        host_layout.addWidget(sidebar)
    if getattr(window, "_sidebar_mode", "desktop") == "small":
        sidebar.hide()
    else:
        sidebar.show()
    toggle = getattr(window, "sidebar_drawer_toggle", None)
    if toggle is not None:
        toggle.setChecked(False)


def close_sidebar_drawer(window) -> None:
    popup = getattr(window, "sidebar_drawer_popup", None)
    if isinstance(popup, SidebarDrawerPopup) and popup.isVisible():
        popup.close()


def _show_sidebar_drawer(window) -> None:
    popup = getattr(window, "sidebar_drawer_popup", None)
    sidebar = getattr(window, "sidebar", None)
    host = getattr(window, "sidebar_host", None)
    host_layout = getattr(window, "sidebar_host_layout", None)
    toggle = getattr(window, "sidebar_drawer_toggle", None)
    if (
        not isinstance(popup, SidebarDrawerPopup)
        or not isinstance(sidebar, QWidget)
        or not isinstance(host, QWidget)
        or host_layout is None
        or not isinstance(toggle, QToolButton)
    ):
        return

    if popup.isVisible():
        popup.close()
        return

    host_layout.removeWidget(sidebar)
    sidebar.setParent(popup)
    popup.layout().addWidget(sidebar)
    sidebar.show()
    popup.setLayoutDirection(window.layoutDirection())
    width = window._scaled(UI_METRICS.sidebar_drawer_width)
    popup.setMinimumWidth(width)
    popup.setMaximumWidth(width)
    screen = window.screen() or QApplication.primaryScreen()
    available = screen.availableGeometry() if screen is not None else window.geometry()
    popup.setMaximumHeight(max(1, min(window.height(), available.height())))
    popup.adjustSize()
    popup_height = min(max(popup.sizeHint().height(), 1), popup.maximumHeight())
    popup.resize(width, popup_height)

    anchor = toggle.mapToGlobal(QPoint(0, 0))
    window_top = window.mapToGlobal(QPoint(0, 0))
    if window.layoutDirection() == Qt.RightToLeft:
        anchor.setX(anchor.x() + toggle.width() - width)
    x = min(max(anchor.x(), available.left()), available.right() - width + 1)
    y = min(max(window_top.y(), available.top()), available.bottom() - popup_height + 1)
    # A single placement is appropriate for this transient overlay; no resize
    # event moves or sizes widgets in the shell layout.
    popup.move(x, y)
    toggle.setChecked(True)
    popup.show()


def _apply_sidebar_button_mode(button: QPushButton, *, compact: bool) -> None:
    text = str(button.property("fullText") or button.text())
    tooltip = str(button.property("fullToolTip") or button.toolTip() or text)
    button.setProperty("fullText", text)
    button.setProperty("fullToolTip", tooltip)
    button.setProperty("railMode", compact)
    button.setText("" if compact else text)
    button.setToolTip(tooltip)
    button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    button.setIconSize(QSize(20, 20))


def _apply_sidebar_responsive_mode(window, profile, rtl: bool) -> str:
    mode = "desktop"
    state = (mode, bool(rtl))
    if state == getattr(window, "_sidebar_responsive_state", None):
        return mode

    previous_mode = getattr(window, "_sidebar_mode", None)
    window._sidebar_mode = mode
    window._sidebar_responsive_state = state
    popup = getattr(window, "sidebar_drawer_popup", None)
    if previous_mode == "small" and mode != "small":
        close_sidebar_drawer(window)

    sidebar = getattr(window, "sidebar", None)
    host = getattr(window, "sidebar_host", None)
    toggle = getattr(window, "sidebar_drawer_toggle", None)
    scale = getattr(window, "_scaled", lambda value: value)
    compact = mode == "compact"
    sidebar_width = scale(
        UI_METRICS.sidebar_compact_width if compact else UI_METRICS.sidebar_width
    )
    host_width = scale(
        UI_METRICS.sidebar_rail_width if mode == "small" else sidebar_width
    )

    if sidebar is not None:
        sidebar.setProperty("railMode", compact)
        sidebar.setProperty("drawerMode", mode == "small")
        sidebar.setProperty("rtlUi", bool(rtl))
        sidebar.setLayoutDirection(Qt.RightToLeft if rtl else Qt.LeftToRight)
        layout = sidebar.layout()
        if layout is not None:
            inset = scale(4 if compact else 8)
            layout.setContentsMargins(inset, inset, inset, inset)
        sidebar.setMinimumWidth(sidebar_width)
        sidebar.setMaximumWidth(sidebar_width)
        sidebar.setBaseSize(sidebar_width, 0)

        if mode == "small":
            if sidebar.parentWidget() is not popup:
                sidebar.hide()
        else:
            sidebar.show()

        for name in (
            "sidebar_brand_title",
            "sidebar_brand_subtitle",
            "sidebar_profile_identity",
        ):
            widget = getattr(window, name, None)
            if widget is not None:
                widget.setVisible(not compact)

        for label in getattr(window, "sidebar_section_labels", []):
            label.setVisible(not compact)

        card = getattr(window, "sidebar_profile_card", None)
        if card is not None and card.layout() is not None:
            card.layout().setContentsMargins(
                scale(4 if compact else 10),
                scale(6 if compact else 8),
                scale(4 if compact else 10),
                scale(6 if compact else 8),
            )

        for button in getattr(window, "sidebar_buttons", []):
            _apply_sidebar_button_mode(button, compact=compact)

        style = sidebar.style()
        if style is not None:
            style.unpolish(sidebar)
            style.polish(sidebar)

    if host is not None:
        host.setMinimumWidth(host_width)
        host.setMaximumWidth(host_width)
        host.setBaseSize(host_width, 0)

    if toggle is not None:
        toggle.setVisible(mode == "small")
        toggle.setLayoutDirection(Qt.RightToLeft if rtl else Qt.LeftToRight)
        toggle.setToolTip(_("Open navigation"))
        toggle.setAccessibleName(_("Open navigation"))
        toggle.setCheckable(True)
        toggle.setMinimumSize(host_width, host_width)
        toggle.setMaximumSize(host_width, host_width)
        toggle.setIconSize(QSize(20, 20))
        toggle.setIcon(QIcon())
        toggle.setText("≡")
        toggle.setToolButtonStyle(Qt.ToolButtonTextOnly)
        if popup is not None:
            popup.setLayoutDirection(Qt.RightToLeft if rtl else Qt.LeftToRight)
    return mode


def apply_device_properties(widget, window_width=None, app=None, window_height=None):
    profile = profile_for_dimensions(window_width, window_height, app=app)
    apply_profile_properties(widget, profile)
    return "compact" if profile.is_narrow else "comfortable" if profile.is_tablet else "expanded"


def apply_responsive_shell_metrics(window) -> None:
    """Apply HERFY shell metrics from the current client-area profile."""
    profile = profile_for_widget(window)
    apply_screen_device_properties(window, screen_device_profile(window))
    apply_profile_properties(window, profile)
    rtl = window.layoutDirection() == Qt.RightToLeft
    sidebar_mode = _apply_sidebar_responsive_mode(window, profile, rtl)
    rail_mode = sidebar_mode == "compact"

    transition_progress = getattr(window, "transition_progress", None)
    if transition_progress is not None:
        # Status work must never steal a fixed slice of a narrow command bar.
        # The progress widget can use the remaining width or collapse naturally
        # alongside the status message.
        transition_progress.setMinimumWidth(0)
        transition_progress.setMaximumWidth(UI_METRICS.widget_maximum_extent)
        transition_progress.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)

    shell_status = getattr(window, "shell_status_message", None)
    if shell_status is not None:
        shell_status.setMinimumWidth(0)
        shell_status.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)

    net = getattr(window, "net_indicator", None)
    if net is not None:
        text = str(net.property("fullText") or net.text())
        net.setProperty("fullText", text)
        net.setToolTip(text)
        net.setText(text)

    submenu = getattr(window, "admin_sidebar_submenu", None)
    if submenu is not None:
        parent = getattr(window, "btn_org_sidebar", None)
        submenu.setVisible(
            not rail_mode
            and bool(parent and not parent.isHidden())
            and bool(getattr(window, "_administration_sidebar_expanded", False))
            and bool(getattr(window, "_administration_modules", ()))
        )

    content = getattr(window, "content_layout", None)
    if content is not None:
        margin = max(4, int(profile.page_margin))
        content.setContentsMargins(margin, margin, margin, margin)

    stack = getattr(window, "content_stack", None)
    page = stack.currentWidget() if stack is not None else None
    if page is not None:
        local_profile = profile_for_widget(page)
        apply_profile_properties(page, local_profile)
        callback = getattr(page, "apply_responsive_profile", None)
        if callable(callback):
            callback(local_profile)


def configure_transition_progress(window, progress: QProgressBar) -> None:
    """Keep the shell busy indicator fluid at every window width."""
    del window
    progress.setMinimumWidth(0)
    progress.setMaximumWidth(UI_METRICS.widget_maximum_extent)
    progress.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)


logger = logging.getLogger(__name__)


class SidebarFrame(QFrame):
    """Paint the canonical HERFY navigation backdrop without image assets.

    The visual treatment follows the desktop shell reference: a deep navy-to-blue
    base, layered diagonal facets, a restrained lower radial glow and thin curved
    light traces.  Painting is local to the sidebar so page/card backgrounds and
    business widgets remain untouched.
    """

    def paintEvent(self, event) -> None:
        del event
        rect = self.rect()
        if rect.isEmpty():
            return

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        width = float(rect.width())
        height = float(rect.height())

        base = QLinearGradient(0.0, 0.0, width, height)
        base.setColorAt(0.00, QColor(4, 22, 64))
        base.setColorAt(0.42, QColor(5, 45, 111))
        base.setColorAt(0.76, QColor(4, 52, 132))
        base.setColorAt(1.00, QColor(3, 31, 82))
        painter.fillRect(rect, base)

        # Upper angular light plane.  It gives the rail depth while keeping the
        # logo and navigation text on an uncluttered dark field.
        upper = QPainterPath()
        upper.moveTo(0.0, 0.0)
        upper.lineTo(width * 0.66, 0.0)
        upper.lineTo(width * 1.03, height * 0.29)
        upper.lineTo(width * 0.54, height * 0.20)
        upper.closeSubpath()
        upper_gradient = QLinearGradient(0.0, 0.0, width, height * 0.30)
        upper_gradient.setColorAt(0.0, QColor(21, 87, 190, 34))
        upper_gradient.setColorAt(0.58, QColor(14, 102, 235, 70))
        upper_gradient.setColorAt(1.0, QColor(45, 132, 255, 16))
        painter.fillPath(upper, upper_gradient)

        # Mid-rail diagonal facets reproduce the subtle layered blue geometry in
        # the reference without a bitmap that could scale poorly at high DPI.
        middle = QPainterPath()
        middle.moveTo(0.0, height * 0.16)
        middle.lineTo(width * 0.38, height * 0.25)
        middle.lineTo(width, height * 0.48)
        middle.lineTo(width, height * 0.66)
        middle.lineTo(width * 0.62, height * 0.53)
        middle.lineTo(0.0, height * 0.38)
        middle.closeSubpath()
        middle_gradient = QLinearGradient(0.0, height * 0.18, width, height * 0.62)
        middle_gradient.setColorAt(0.0, QColor(6, 40, 99, 22))
        middle_gradient.setColorAt(0.54, QColor(8, 87, 208, 50))
        middle_gradient.setColorAt(1.0, QColor(0, 121, 255, 22))
        painter.fillPath(middle, middle_gradient)

        lower = QPainterPath()
        lower.moveTo(0.0, height * 0.72)
        lower.lineTo(width * 0.48, height * 0.78)
        lower.lineTo(width, height * 0.98)
        lower.lineTo(width, height)
        lower.lineTo(0.0, height)
        lower.closeSubpath()
        lower_gradient = QLinearGradient(0.0, height * 0.72, width, height)
        lower_gradient.setColorAt(0.0, QColor(0, 86, 223, 28))
        lower_gradient.setColorAt(0.62, QColor(9, 98, 231, 50))
        lower_gradient.setColorAt(1.0, QColor(11, 60, 141, 10))
        painter.fillPath(lower, lower_gradient)

        glow = QRadialGradient(width * 0.02, height * 0.86, width * 1.15)
        glow.setColorAt(0.0, QColor(0, 123, 255, 66))
        glow.setColorAt(0.40, QColor(0, 93, 224, 24))
        glow.setColorAt(1.0, QColor(0, 55, 145, 0))
        painter.fillRect(rect, glow)

        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(QColor(33, 129, 255, 78), 1.15))
        painter.drawEllipse(QRectF(-width * 1.13, height * 0.73, width * 2.02, width * 2.02))
        painter.setPen(QPen(QColor(82, 159, 255, 38), 0.8))
        painter.drawEllipse(QRectF(-width * 1.00, height * 0.78, width * 1.74, width * 1.74))

        # Crisp illuminated edge separates the navigation rail from light page
        # surfaces without introducing a heavyweight shadow effect.
        edge_glow = QLinearGradient(width - 8.0, 0.0, width, 0.0)
        edge_glow.setColorAt(0.0, QColor(50, 132, 255, 0))
        edge_glow.setColorAt(1.0, QColor(104, 174, 255, 34))
        painter.fillRect(QRectF(width - 8.0, 0.0, 8.0, height), edge_glow)
        painter.setPen(QPen(QColor(122, 181, 255, 58), 1.0))
        painter.drawLine(rect.topRight(), rect.bottomRight())
        painter.end()


def show_runtime_notice(owner, notice, *, logger_: logging.Logger, context: str) -> None:
    if not getattr(notice, "text", ""):
        return
    try:
        owner._show_runtime_status_message(notice.text, notice.timeout_ms)
    except UI_OPERATION_EXCEPTIONS:
        logger_.debug("%s status fallback failed", context, exc_info=True)


def create_sidebar_button(
    window,
    text: str,
    icon_name: str,
    handler,
    *,
    page_button: bool = False,
    route_name: str | None = None,
    button: QPushButton | None = None,
) -> QPushButton:
    button = button or QPushButton(text)
    button.setText(text)
    button.setProperty("variant", "navigation")
    button.setProperty("navigationArea", "sidebar")
    button.setProperty("fullText", text)
    button.setCursor(Qt.PointingHandCursor)
    button.setProperty("pageButton", bool(page_button))
    if route_name:
        button.setProperty("routeName", str(route_name))
    icon_px = window._scaled(UI_METRICS.icon_size)
    # Navigation assets are part of the product's visual language.  Preserve
    # their packaged colours instead of flattening every section into the same
    # monochrome glyph on the sidebar.
    apply_button_icon(button, icon_name, size=QSize(icon_px, icon_px))
    button.setAccessibleName(text)
    button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
    button.setCheckable(True)
    button.clicked.connect(
        lambda checked, btn=button, fn=handler: window.handle_sidebar_click(btn, fn)
    )
    button.clicked.connect(lambda _checked=False: close_sidebar_drawer(window))
    return button


def _administration_child_button(window, route: str) -> QPushButton:
    label = AdministrationPresenter.module_label(route)
    button = QPushButton(label)
    button.setObjectName("SidebarAdministrationChild")
    button.setProperty("variant", "subnavigation")
    button.setProperty("adminRoute", str(route))
    button.setProperty("fullText", label)
    button.setCursor(Qt.PointingHandCursor)
    button.setCheckable(True)
    button.setAccessibleName(label)
    button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
    button.clicked.connect(
        lambda _checked=False, current=str(route): window.open_administration_route(current)
    )
    button.clicked.connect(lambda _checked=False: close_sidebar_drawer(window))
    return button


def set_sidebar_administration_modules(window, modules) -> None:
    wanted = [str(route).strip() for route in modules or [] if str(route).strip()]
    buttons = getattr(window, "admin_sidebar_route_buttons", None)
    layout = getattr(window, "admin_sidebar_submenu_layout", None)
    if not isinstance(buttons, dict) or layout is None:
        return

    for route, button in list(buttons.items()):
        if route in wanted:
            continue
        try:
            layout.removeWidget(button)
            if button in getattr(window, "sidebar_buttons", []):
                window.sidebar_buttons.remove(button)
            button.deleteLater()
        finally:
            buttons.pop(route, None)

    for route in wanted:
        if route in buttons:
            continue
        button = _administration_child_button(window, route)
        _apply_sidebar_button_mode(
            button,
            compact=getattr(window, "_sidebar_mode", "desktop") == "compact",
        )
        layout.addWidget(button)
        buttons[route] = button
        window.sidebar_buttons.append(button)

    # Keep server order deterministic even after an authority refresh.
    for index, route in enumerate(wanted):
        button = buttons.get(route)
        if button is not None:
            layout.insertWidget(index, button)

    window._administration_modules = tuple(wanted)
    expanded = bool(getattr(window, "_administration_sidebar_expanded", False))
    parent_visible = bool(
        getattr(window, "btn_org_sidebar", None) and window.btn_org_sidebar.isVisible()
    )
    window.admin_sidebar_submenu.setVisible(bool(wanted) and expanded and parent_visible)


def set_sidebar_administration_route(window, route: str) -> None:
    current = str(route or "").strip()
    for key, button in getattr(window, "admin_sidebar_route_buttons", {}).items():
        button.setChecked(key == current)


def set_sidebar_administration_expanded(window, expanded: bool) -> None:
    value = bool(expanded)
    window._administration_sidebar_expanded = value
    button = getattr(window, "btn_org_sidebar", None)
    if button is not None:
        label = _("Administration")
        rail_mode = bool(getattr(window, "sidebar", None) and window.sidebar.property("railMode"))
        button.setText("" if rail_mode else f"{label}  {'▾' if value else '▸'}")
        button.setProperty("fullText", label)
        button.setAccessibleName(label)
        button.setToolTip(label)
    submenu = getattr(window, "admin_sidebar_submenu", None)
    if submenu is not None:
        modules = tuple(getattr(window, "_administration_modules", ()))
        parent_visible = bool(button and button.isVisible())
        rail_mode = bool(getattr(window, "sidebar", None) and window.sidebar.property("railMode"))
        submenu.setVisible(value and bool(modules) and parent_visible and not rail_mode)


def build_sidebar(window) -> QFrame:
    window.sidebar = SidebarFrame()
    controls = load_ui(
        window.sidebar,
        "sidebar",
        required=(
            "SidebarLogo",
            "SidebarBrandTitle",
            "SidebarBrandSubtitle",
            "SidebarNavigationHost",
            "SidebarNavigationScroll",
            "sidebar_navigation_layout",
            "SidebarSectionLabelWorkspace",
            "SidebarSectionLabelManagement",
            "SidebarHomeButton",
            "SidebarTrackingButton",
            "SidebarUsageButton",
            "SidebarKpiButton",
            "SidebarAdministrationButton",
            "SidebarAdminSubmenu",
            "sidebar_admin_submenu_layout",
            "SidebarSettingsButton",
            "SidebarAboutButton",
            "SidebarFooter",
            "SidebarProfileCard",
            "SidebarProfileAvatar",
            "SidebarProfileIdentity",
            "SidebarProfileName",
            "SidebarProfileMeta",
            "SidebarProfileStatusHost",
            "sidebar_profile_status_layout",
            "SidebarLogoutButton",
        ),
    )
    window.sidebar.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
    sidebar_width = window._scaled(UI_METRICS.sidebar_width)
    window.sidebar.setMinimumWidth(0)
    window.sidebar.setBaseSize(sidebar_width, 0)
    side_layout: QVBoxLayout = window.sidebar.layout()
    side_layout.setSizeConstraint(QLayout.SetDefaultConstraint)
    side_layout.setContentsMargins(
        window._scaled(6),
        window._scaled(8),
        window._scaled(6),
        window._scaled(6),
    )
    side_layout.setSpacing(window._scaled(6))
    side_layout.setStretch(0, 0)
    side_layout.setStretch(1, 1)
    side_layout.setStretch(2, 0)
    logo = controls["SidebarLogo"]
    source_logo = build_logo_label(
        width=window._scaled(58),
        object_name="SidebarLogo",
        ui_role="logoMissingSidebar",
    )
    logo.setPixmap(source_logo.pixmap())
    logo.setText(source_logo.text())
    logo.setProperty("uiRole", source_logo.property("uiRole"))
    logo.setAlignment(Qt.AlignCenter)
    logo.setContentsMargins(2, 2, 2, 2)
    logo.setAttribute(Qt.WA_StyledBackground, True)
    window.sidebar_logo = logo
    window.sidebar_brand_title = controls["SidebarBrandTitle"]
    window.sidebar_brand_title.setText("HERFY")
    window.sidebar_brand_title.setAlignment(Qt.AlignCenter)
    window.sidebar_brand_subtitle = controls["SidebarBrandSubtitle"]
    window.sidebar_brand_subtitle.setText(_("Food Safety Tracking Products"))
    window.sidebar_brand_subtitle.setAlignment(Qt.AlignCenter)
    window.sidebar_brand_subtitle.setWordWrap(True)
    window.sidebar_navigation_host = controls["SidebarNavigationHost"]
    window.sidebar_navigation_scroll = controls["SidebarNavigationScroll"]
    window.sidebar_navigation_scroll.setFrameShape(QFrame.NoFrame)
    window.sidebar_navigation_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    window.sidebar_navigation_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
    navigation_layout: QVBoxLayout = controls["sidebar_navigation_layout"]
    navigation_layout.setContentsMargins(0, 0, 0, 0)
    navigation_layout.setSpacing(3)
    navigation_layout.setSizeConstraint(QLayout.SetDefaultConstraint)
    navigation_layout.setAlignment(Qt.AlignTop)
    window.sidebar_buttons = []
    window.sidebar_page_buttons = []
    window.sidebar_section_labels = [
        controls["SidebarSectionLabelWorkspace"],
        controls["SidebarSectionLabelManagement"],
    ]
    for label, caption in zip(window.sidebar_section_labels, (_("Workspace"), _("Management"))):
        label.setText(caption)
        label.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
    for key, caption, icon, handler, route, shortcut in (
        ("SidebarHomeButton", _("Home"), "home.png", window.show_home, "home", "Alt+1"),
        (
            "SidebarTrackingButton",
            _("Tracking Products"),
            "products.png",
            window.show_track,
            "tracking",
            "Alt+2",
        ),
        ("SidebarUsageButton", _("Usage"), "usage.png", window.show_usage, "usage", "Alt+3"),
        ("SidebarKpiButton", _("Sales KPI"), "usage.png", window.show_kpi, "kpi", "Alt+4"),
    ):
        button = create_sidebar_button(
            window,
            caption,
            icon,
            handler,
            page_button=True,
            route_name=route,
            button=controls[key],
        )
        button.setShortcut(shortcut)
        button.setToolTip(f"{caption} ({shortcut})")
        window.sidebar_page_buttons.append(button)
        window.sidebar_buttons.append(button)
        if route == "kpi":
            window.btn_kpi_sidebar = button
    window.btn_org_sidebar = create_sidebar_button(
        window,
        _("Administration"),
        "admin.png",
        window.open_administration,
        page_button=True,
        route_name="admin",
        button=controls["SidebarAdministrationButton"],
    )
    window.btn_org_sidebar.hide()
    window.sidebar_page_buttons.append(window.btn_org_sidebar)
    window.sidebar_buttons.append(window.btn_org_sidebar)
    window.admin_sidebar_submenu = controls["SidebarAdminSubmenu"]
    window.admin_sidebar_submenu_layout = controls["sidebar_admin_submenu_layout"]
    window.admin_sidebar_submenu_layout.setContentsMargins(
        window._scaled(6),
        0,
        window._scaled(2),
        window._scaled(1),
    )
    window.admin_sidebar_submenu_layout.setSpacing(window._scaled(2))
    window.admin_sidebar_route_buttons = {}
    window._administration_modules = tuple()
    window._administration_sidebar_expanded = False
    window.admin_sidebar_submenu.hide()
    set_sidebar_administration_expanded(window, False)
    window.btn_settings_sidebar = create_sidebar_button(
        window,
        _("Settings"),
        "settings.png",
        window.open_settings,
        route_name="settings",
        button=controls["SidebarSettingsButton"],
    )
    window.sidebar_buttons.append(window.btn_settings_sidebar)
    window.btn_about_sidebar = create_sidebar_button(
        window,
        _("About"),
        "about.png",
        window.show_about,
        route_name="about",
        button=controls["SidebarAboutButton"],
    )
    window.sidebar_buttons.append(window.btn_about_sidebar)
    window.sidebar_footer = controls["SidebarFooter"]
    window.sidebar_footer.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
    window.sidebar_profile_card = controls["SidebarProfileCard"]
    window.sidebar_profile_card.setProperty("signedIn", False)
    window.sidebar_profile_avatar = controls["SidebarProfileAvatar"]
    window.sidebar_profile_avatar.setAlignment(Qt.AlignCenter)
    window.sidebar_profile_identity = controls["SidebarProfileIdentity"]
    window.lbl_user_info = controls["SidebarProfileName"]
    window.lbl_user_info.setWordWrap(True)
    window.lbl_user_info.setTextInteractionFlags(Qt.NoTextInteraction)
    window.lbl_user_info.setProperty("uiRole", "signedInIdentity")
    window.sidebar_profile_meta = controls["SidebarProfileMeta"]
    window.sidebar_profile_meta.setWordWrap(True)
    window.sidebar_profile_meta.setTextInteractionFlags(Qt.NoTextInteraction)
    window.sidebar_profile_status_host = controls["SidebarProfileStatusHost"]
    window.sidebar_profile_status_layout = controls["sidebar_profile_status_layout"]
    window.sidebar_profile_status_layout.setContentsMargins(0, 0, 0, 0)
    window.sidebar_profile_status_layout.setSpacing(4)
    window.sidebar_profile_card.hide()
    window.btn_logout_sidebar = create_sidebar_button(
        window,
        _("Logout"),
        "exit.png",
        window.logout,
        route_name="logout",
        button=controls["SidebarLogoutButton"],
    )
    window.btn_logout_sidebar.hide()
    window.sidebar_buttons.append(window.btn_logout_sidebar)
    window.sidebar_footer.hide()
    if isinstance(window, QWidget):
        popup = SidebarDrawerPopup(window)
        popup.setObjectName("SidebarDrawerPopup")
        popup.setWindowFlags(Qt.Popup | Qt.FramelessWindowHint)
        popup.setProperty("uiRole", "sidebarDrawer")
        popup_layout = QVBoxLayout(popup)
        popup_layout.setContentsMargins(0, 0, 0, 0)
        popup_layout.setSpacing(0)
        popup.dismissed.connect(lambda: _restore_sidebar_from_drawer(window))
        window.sidebar_drawer_popup = popup
        toggle = getattr(window, "sidebar_drawer_toggle", None)
        if isinstance(toggle, QToolButton):
            toggle.setObjectName("SidebarDrawerToggle")
            toggle.setAutoRaise(True)
            toggle.setToolButtonStyle(Qt.ToolButtonTextOnly)
            toggle.clicked.connect(lambda _checked=False: _show_sidebar_drawer(window))
    return window.sidebar


def _make_top_menu_button(
    window, text: str, icon_name: str | None = None, *, button: QToolButton | None = None
) -> QToolButton:
    button = button or QToolButton()
    button.setCursor(Qt.PointingHandCursor)
    button.setText(text)
    button.setProperty("fullText", text)
    button.setPopupMode(QToolButton.InstantPopup)
    button.setToolButtonStyle(Qt.ToolButtonTextOnly)
    button.setAccessibleName(text)
    button.setToolTip(text)
    if icon_name:
        icon_px = window._scaled(max(UI_METRICS.icon_size, 18))
        apply_button_icon(button, icon_name, size=QSize(icon_px, icon_px))
        button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
    button.setMinimumHeight(UI_METRICS.control_min_height)
    button.setMinimumWidth(UI_METRICS.control_min_height)
    return button


def build_top_bar(window) -> QWidget:
    top_bar = QWidget()
    controls = load_ui(
        top_bar,
        "top_bar",
        required=(
            "TopFileMenu",
            "TopToolsMenu",
            "NotificationsButton",
            "NotifBadge",
            "NotifWrap",
            "CommandBar",
            "ShellStatusMessage",
            "ShellStatusWidgetsHost",
            "shell_status_widgets_layout",
        ),
    )
    top_bar.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
    top_bar.setFixedHeight(window._scaled(UI_METRICS.top_bar_height))
    top_bar.setLayoutDirection(window.layoutDirection())
    top_layout: QHBoxLayout = top_bar.layout()
    top_layout.setContentsMargins(
        window._scaled(10),
        window._scaled(5),
        window._scaled(10),
        window._scaled(5),
    )
    top_layout.setSpacing(window._scaled(6))
    top_layout.setStretch(0, 0)
    top_layout.setStretch(1, 0)
    top_layout.setStretch(2, 1)
    top_layout.setStretch(3, 0)
    window.btn_menu_file = _make_top_menu_button(
        window,
        _("File"),
        button=controls["TopFileMenu"],
    )
    window.btn_menu_tools = _make_top_menu_button(
        window,
        _("Tools"),
        button=controls["TopToolsMenu"],
    )
    window.btn_menu_file.setProperty("uiRole", "topMainMenuButton")
    window.btn_menu_tools.setProperty("uiRole", "topMainMenuButton")
    old_notifications_button: QToolButton = controls["NotificationsButton"]
    window.notif_wrap: QFrame = controls["NotifWrap"]
    notif_layout: QGridLayout = controls["NotifWrap"].layout()
    notif_layout.setContentsMargins(0, 0, 0, 0)
    notif_layout.setSpacing(0)
    notif_layout.removeWidget(old_notifications_button)
    old_notifications_button.hide()
    old_notifications_button.setParent(None)
    old_notifications_button.deleteLater()
    window.btn_notifications = NotificationBadgeButton(window.notif_wrap)
    window.btn_notifications.setObjectName("NotificationsButton")
    notif_layout.addWidget(window.btn_notifications, 0, 0)
    window.btn_notifications.setCursor(Qt.PointingHandCursor)
    window.btn_notifications.setText("")
    notif_icon = window._scaled(max(UI_METRICS.icon_size, 21))
    apply_button_icon(window.btn_notifications, "bell.png", size=QSize(notif_icon, notif_icon))
    window.btn_notifications.setMinimumSize(
        UI_METRICS.control_min_height, UI_METRICS.control_min_height
    )
    window.btn_notifications.clicked.connect(window.on_show_notifications)
    window.btn_notifications.setToolTip(_("Notifications"))
    window.notif_wrap.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Minimum)
    window.notif_wrap.setMinimumSize(
        window.btn_notifications.sizeHint().expandedTo(
            QSize(UI_METRICS.control_min_height, UI_METRICS.control_min_height)
        )
    )
    window.lbl_notif_count: QLabel = controls["NotifBadge"]
    window.lbl_notif_count.setAlignment(Qt.AlignCenter)
    window.lbl_notif_count.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    window.lbl_notif_count.hide()
    window.command_bar: QFrame = controls["CommandBar"]
    window.command_bar.setSizePolicy(QSizePolicy.Minimum, QSizePolicy.Fixed)
    window.shell_status_message: QLabel = controls["ShellStatusMessage"]
    window.shell_status_message.setMinimumWidth(0)
    window.shell_status_message.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
    window.shell_status_message.hide()
    window.shell_status_widgets_host: QWidget = controls["ShellStatusWidgetsHost"]
    window.shell_status_widgets_layout: QHBoxLayout = controls["shell_status_widgets_layout"]
    window.shell_status_widgets_layout.setContentsMargins(0, 0, 0, 0)
    window.shell_status_widgets_layout.setSpacing(4)
    window.top_bar = top_bar
    return top_bar
