from __future__ import annotations

import logging
from typing import Any, Callable, ClassVar

from PySide6.QtCore import QEvent, QSize, Qt, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView,
    QFrame,
    QGridLayout,
    QSizePolicy,
    QStyle,
    QTableView,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from core.errors import UI_OPERATION_EXCEPTIONS
from core.presentation import PageVisibleStateService
from core.settings import _
from ui.designer import load_ui
from ui.printing import UsagePrintService
from ui.responsive_toolbar import apply_toolbar_control_metrics, configure_more_menu
from ui.tables import (
    COL_H,
    OnHandDelegate,
    ResponsiveDataPageResizeMixin,
    UsageModel,
    UsageProxy,
    configure_responsive_table,
    configure_sortable_table,
    configure_usage_table_headers,
    fit_table_columns,
)
from ui.theme import (
    UI_METRICS,
    ResponsiveProfile,
    apply_device_properties,
    apply_profile_properties,
    configure_page_layout,
    make_scaler,
    polish_interface,
    profile_for_widget,
)
from ui.usage_controller import UsageControllerMixin
from ui.widgets import (
    DataSurface,
    apply_button_icon,
    polish_button,
    polish_status_label,
    refresh_widget_style,
)

logger = logging.getLogger(__name__)


class UsageResponsiveLayoutMixin:
    def apply_responsive_profile(self, profile: ResponsiveProfile | None = None) -> None:
        profile = profile or profile_for_widget(self)
        apply_profile_properties(self, profile)
        self._apply_responsive_usage_controls(profile=profile)
        self._size_columns()

    def _apply_responsive_usage_controls(
        self, *, force: bool = False, profile: ResponsiveProfile | None = None
    ) -> None:
        try:
            profile = profile or profile_for_widget(self)
            available_width = int(self.usage_controls_panel.contentsRect().width())
            page_width = int(self.contentsRect().width() or profile.width or 1)
            if available_width <= 1 or available_width < page_width * 0.75:
                available_width = page_width
            available_width = max(1, available_width)
            mode = apply_toolbar_control_metrics(
                self.usage_controls_panel,
                (self.btn_r, self.btn_b, self.btn_recalculate, self.btn_print, self.btn_more),
                available_width,
            )
            compact_actions = mode in {"compact", "small"}
            self.btn_r.setVisible(mode != "small")
            self.btn_b.setVisible(mode != "small")
            self.btn_recalculate.setVisible(True)
            self.btn_print.setVisible(not compact_actions)
            self.btn_more.setVisible(compact_actions)
            if not force and mode == getattr(self, "_usage_controls_mode", ""):
                return
            self._usage_controls_mode = mode
            self.setProperty("toolbarMode", mode)
            apply_profile_properties(self, profile)
            refresh_widget_style(self)

            self.search.setMinimumWidth(
                0 if mode == "small" else UI_METRICS.toolbar_search_min_width
            )
            self.lbl_status.setMinimumWidth(0)
            self.search.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            self.lbl_status.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

            grid = self.usage_controls_grid
            for widget in self._usage_controls_widgets:
                grid.removeWidget(widget)
            for column in range(max(8, grid.columnCount())):
                grid.setColumnStretch(column, 0)
                grid.setColumnMinimumWidth(column, 0)

            if mode != "small":
                grid.addWidget(self.btn_r, 0, 0)
                grid.addWidget(self.btn_b, 0, 1)
                grid.addWidget(self.btn_recalculate, 0, 2)
                grid.addWidget(self.search, 0, 3)
                grid.addWidget(self.chk_hide_total_zero, 0, 4)
                if mode == "compact":
                    grid.addWidget(self.btn_more, 0, 5)
                else:
                    grid.addWidget(self.btn_print, 0, 5)
                grid.setColumnStretch(3, 1)
            else:
                # Preserve every operation without a second toolbar row. The
                # file imports and print preview remain available from More;
                # recalculate and search stay immediately reachable.
                grid.addWidget(self.btn_recalculate, 0, 0)
                grid.addWidget(self.search, 0, 1)
                grid.addWidget(self.chk_hide_total_zero, 0, 2)
                grid.addWidget(self.btn_more, 0, 3)
                grid.setColumnStretch(1, 1)

            self.lbl_search.hide()
            self.lbl_status.hide()
            self.search.setToolTip(_("Search products and enter remaining stock in the table."))
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage responsive controls failed", exc_info=True)

    def _print_icon_size(self):
        size = max(
            UI_METRICS.usage_print_icon_min_size,
            self._S(UI_METRICS.usage_print_icon_size),
        )
        return QSize(size, size)

    def _size_columns(self):
        for column in range(
            self.proxy.columnCount()
            if getattr(self, "proxy", None) is not None
            else len(self.COL_RATIOS)
        ):
            self.table.setColumnHidden(column, False)
        compact = profile_for_widget(self.table).is_narrow
        self.table.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAsNeeded if compact else Qt.ScrollBarAlwaysOff
        )
        self.table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        if compact:
            fit_table_columns(
                self.table,
                self.COL_RATIOS,
                min_widths=[self._S(value) for value in self.COL_MIN_WIDTHS],
                stretch_columns=(1,),
            )
        else:
            configure_usage_table_headers(self.table)


class UsagePage(
    UsageResponsiveLayoutMixin,
    ResponsiveDataPageResizeMixin,
    UsageControllerMixin,
    QWidget,
):
    responsive_resize_callbacks = ("apply_responsive_profile",)
    responsive_table_attr = "table"
    responsive_table_size_callback = "_size_columns"
    responsive_table_min_height = None
    responsive_table_resize_after_callbacks = False
    status_label_attr = "lbl_status"
    summary_surface_attr = "usage_surface"
    summary_loading_text = "Calculating usage…"
    summary_state_method = "usage_state"
    COL_RATIOS: ClassVar[tuple[int, ...]] = (8, 36, 8, 10, 7, 19, 5, 7)
    COL_MIN_WIDTHS: ClassVar[tuple[int, ...]] = (64, 180, 58, 78, 48, 130, 36, 54)

    def _build_controls_panel(self) -> QFrame:
        S = self._S
        controls_panel = self.usage_controls_panel
        controls_panel.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
        controls_grid = self.usage_controls_grid
        self.import_grid = controls_grid
        self.usage_toolbar_grid = controls_grid
        controls_grid.setContentsMargins(
            S(UI_METRICS.toolbar_horizontal_padding),
            S(UI_METRICS.toolbar_vertical_padding),
            S(UI_METRICS.toolbar_horizontal_padding),
            S(UI_METRICS.toolbar_vertical_padding),
        )
        controls_grid.setHorizontalSpacing(S(UI_METRICS.toolbar_horizontal_gap))
        controls_grid.setVerticalSpacing(S(UI_METRICS.toolbar_horizontal_gap))
        self.btn_r = self._designer_controls["usage_receipts"]
        self.btn_r.setText(_("Receipts"))
        polish_button(
            self.btn_r,
            role="ghost",
            cursor=Qt.PointingHandCursor,
            min_width=S(UI_METRICS.usage_receipts_button_min_width),
            tooltip=_("Import receipts file"),
        )
        self.btn_r.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_b = self._designer_controls["usage_opening"]
        self.btn_b.setText(_("Opening"))
        polish_button(
            self.btn_b,
            role="ghost",
            cursor=Qt.PointingHandCursor,
            min_width=S(UI_METRICS.usage_opening_button_min_width),
            tooltip=_("Import opening stock file"),
        )
        self.btn_b.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_recalculate = self._designer_controls["usage_recalculate"]
        self.btn_recalculate.setText(_("Recalculate"))
        polish_button(
            self.btn_recalculate,
            role="secondary",
            cursor=Qt.PointingHandCursor,
            min_width=S(UI_METRICS.usage_recalculate_button_min_width),
            tooltip=_("Recalculate usage from the currently selected files."),
        )
        apply_button_icon(
            self.btn_recalculate,
            "refresh.png",
            size=QSize(
                S(UI_METRICS.usage_recalculate_icon_size),
                S(UI_METRICS.usage_recalculate_icon_size),
            ),
            fallback_standard_icon=QStyle.SP_BrowserReload,
        )
        self.btn_recalculate.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.lbl_search = self._designer_controls["usage_search_label"]
        self.lbl_search.setObjectName("FlatFieldLabel")
        self.lbl_search.setWordWrap(False)
        self.search = self._designer_controls["usage_search"]
        self.search.setAccessibleName(_("Search usage rows"))
        self.search.setClearButtonEnabled(True)
        self.search.setPlaceholderText(_("Search server-selected products"))
        self.search.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.lbl_status = self._designer_controls["usage_status"]
        self.lbl_status.setWordWrap(False)
        self.lbl_status.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.lbl_status.setTextInteractionFlags(Qt.TextSelectableByMouse)
        polish_status_label(self.lbl_status, role="muted")
        self.lbl_status.setText("Enter remaining stock; actual usage is calculated automatically.")
        self.chk_hide_total_zero = self._designer_controls["usage_hide_zero"]
        self.chk_hide_total_zero.setText(_("Hide zero total"))
        self.chk_hide_total_zero.setObjectName("UsageHideZeroTotalCheckBox")
        self.chk_hide_total_zero.setCursor(Qt.PointingHandCursor)
        self.chk_hide_total_zero.setToolTip(
            _("Hide rows whose total usage is zero without recalculating the worksheet.")
        )
        self.chk_hide_total_zero.setAccessibleName(_("Hide zero total usage rows"))
        self.chk_hide_total_zero.setChecked(self.usage_workspace_service.hide_total_zero_enabled())
        self.chk_hide_total_zero.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        self.btn_print = self._designer_controls["usage_print"]
        self.btn_print.setObjectName("IconToolButton")
        self.btn_print.setCursor(Qt.PointingHandCursor)
        self.btn_print.setToolTip(_("Print Preview"))
        self.btn_print.setAccessibleName(_("Print Preview"))
        self.btn_print.setShortcut("Ctrl+P")
        self.btn_print.setAutoRaise(True)
        self._configure_print_button()
        self.btn_print.setProperty("toolbarActionText", _("Print preview"))
        self.btn_print.setProperty("toolbarActionAvailable", True)
        self.btn_more: QToolButton = self._designer_controls["usage_more"]
        self.btn_print.setProperty(
            "toolbarActionAvailable",
            self._usage_print_available(),
        )
        configure_more_menu(
            self.btn_more,
            (self.btn_r, self.btn_b, self.btn_print),
            before_show=self._refresh_toolbar_action_availability,
        )
        for button in (self.btn_r, self.btn_b, self.btn_print):
            button.setProperty("toolbarActionAvailable", True)
        self._usage_controls_widgets = [
            self.btn_r,
            self.btn_b,
            self.btn_recalculate,
            self.btn_more,
            self.lbl_search,
            self.search,
            self.lbl_status,
            self.chk_hide_total_zero,
            self.btn_print,
        ]
        self._usage_controls_mode = ""
        self._apply_responsive_usage_controls(force=True)
        return controls_panel

    def _usage_print_available(self) -> bool:
        access_allowed = bool(self._access_allowed)
        if self._access_provider is not None:
            access_allowed = access_allowed and bool(self._access_provider())
        return access_allowed

    def _refresh_toolbar_action_availability(self) -> None:
        available = self._usage_print_available()
        self.btn_print.setProperty(
            "toolbarActionAvailable",
            available,
        )
        self.btn_print.setEnabled(available and not self._compute_is_running())

    def _configure_print_button(self):
        self.btn_print.setText("")
        self.btn_print.setMinimumWidth(self._S(UI_METRICS.control_min_height))
        self.btn_print.setMinimumHeight(self._S(UI_METRICS.control_min_height))
        apply_button_icon(
            self.btn_print,
            "print.png",
            size=self._print_icon_size(),
            fallback_standard_icon=QStyle.SP_DialogApplyButton,
        )
        if self.btn_print.icon().isNull():
            self.btn_print.setText("🖨")

    def _apply_theme(self):
        # Typography is application-owned by the global theme.  Page-level font
        # overrides create inconsistent scaling between Usage and the other main
        # workspaces, so this hook only refreshes icon metrics.
        self.btn_print.setIconSize(self._print_icon_size())

    def _build_table_card(self) -> QFrame:
        S = self._S
        table_card = self.usage_table_card
        table_layout = self.usage_table_layout
        table_layout.setContentsMargins(
            S(UI_METRICS.usage_table_margin_horizontal),
            S(UI_METRICS.usage_table_margin_top),
            S(UI_METRICS.usage_table_margin_horizontal),
            S(UI_METRICS.usage_table_margin_bottom),
        )
        table_layout.setSpacing(S(UI_METRICS.usage_table_gap))
        self.lbl_usage_hint = None
        self.table = self._designer_controls["UsageTable"]
        # This is the sole intentional inline editor: remaining stock drives
        # the automatically calculated usage value.
        self.table.setProperty("allowInlineEdit", True)
        self.table.setToolTip("")
        self.table.setWhatsThis("")
        try:
            self.table.viewport().setToolTip("")
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Usage table viewport tooltip cleanup failed", exc_info=True)
        configure_responsive_table(self.table, window_width=self.width(), show_grid=True)
        self.table.setLayoutDirection(Qt.LeftToRight)
        self.table.horizontalHeader().setLayoutDirection(Qt.LeftToRight)
        self.table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.table.setMinimumHeight(0)
        self.table.setSelectionBehavior(QTableView.SelectRows)
        self.table.setSelectionMode(QTableView.SingleSelection)
        self.table.setEditTriggers(
            QAbstractItemView.DoubleClicked
            | QAbstractItemView.SelectedClicked
            | QAbstractItemView.EditKeyPressed
            | QAbstractItemView.AnyKeyPressed
        )
        head = self.table.horizontalHeader()
        try:
            head.setToolTip("")
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Usage table header tooltip cleanup failed", exc_info=True)
        head.setMinimumSectionSize(self._S(UI_METRICS.usage_table_min_section_width))
        self.model = UsageModel([], row_presenter=self.usage_row_presenter)
        self._usage_workspace_active = False
        self._usage_input_dirty = False
        self._usage_server_refresh_pending = False
        self._model_replace_in_progress = False
        self.proxy = UsageProxy()
        self.proxy.setSourceModel(self.model)
        self.proxy.set_hide_total_zero(self.usage_workspace_service.hide_total_zero_enabled())
        self.proxy.setSortRole(Qt.UserRole)
        self.table.setModel(self.proxy)
        configure_sortable_table(self.table, enabled=True)
        configure_usage_table_headers(self.table)
        self.delegate = OnHandDelegate(self.table)
        self.table.setItemDelegateForColumn(COL_H, self.delegate)
        self.usage_surface = DataSurface(self.table, table_card)
        table_layout.addWidget(self.usage_surface, 1)
        return table_card

    def _build_usage_ui(self) -> None:
        self._designer_controls = load_ui(
            self,
            "usage_page",
            required=(
                "UsageControlPanel",
                "usage_controls_grid",
                "usage_receipts",
                "usage_opening",
                "usage_recalculate",
                "usage_search_label",
                "usage_search",
                "usage_status",
                "usage_hide_zero",
                "usage_print",
                "usage_more",
                "GridPanel",
                "usage_table_host",
                "usage_root_layout",
                "UsageTable",
            ),
        )
        self.usage_controls_panel = self.findChild(QFrame, "UsageControlPanel")
        self.usage_controls_panel.setProperty("uiRole", "standardToolbar")
        self.usage_controls_grid = self.findChild(QGridLayout, "usage_controls_grid")
        self.usage_table_card = self._designer_controls["GridPanel"]
        self.usage_table_layout = self.findChild(QVBoxLayout, "usage_table_host_layout")
        apply_device_properties(self, self.width())
        self._receipts_path = ""
        self._beginning_path = ""
        self._build_controls_panel()
        self._build_table_card()
        configure_page_layout(self, self.findChild(QVBoxLayout, "usage_root_layout"))
        self.setProperty("layoutMode", "grid")

    def __init__(
        self,
        usage_service=None,
        usage_print_service: UsagePrintService | None = None,
        usage_workspace_service: Any = None,
        usage_row_presenter: Any = None,
        page_visible_state_service: PageVisibleStateService | None = None,
        usage_compute_service=None,
        access_provider: Callable[[], bool] | None = None,
    ):
        super().__init__()
        self.setObjectName("UsagePage")
        self.setProperty("uiScope", "usage")
        self.setProperty("nativeWorkspace", True)
        self.usage_service = usage_service
        if (
            usage_print_service is None
            or usage_workspace_service is None
            or usage_row_presenter is None
            or page_visible_state_service is None
            or usage_compute_service is None
        ):
            raise RuntimeError("UsagePage requires composed presentation/application services")
        self.usage_print_service = usage_print_service
        self.usage_workspace_service = usage_workspace_service
        self.usage_row_presenter = usage_row_presenter
        self.usage_compute_service = usage_compute_service
        self._access_provider = access_provider
        self._access_allowed = True
        self._access_reason = ""
        self.page_visible_state_service = page_visible_state_service
        self._S = make_scaler()
        self._receipts_path = ""
        self._beginning_path = ""
        self._build_usage_ui()
        self._connect_usage_signals()
        self._initialize_usage_lifecycle()
        self._finish_usage_ui()

    def _connect_usage_signals(self) -> None:
        self.btn_r.clicked.connect(self._pick_r)
        self.btn_b.clicked.connect(self._pick_b)
        self.btn_recalculate.clicked.connect(self.compute)
        self.search.textChanged.connect(self.proxy.set_search)
        self.chk_hide_total_zero.toggled.connect(self._on_hide_total_zero_toggled)
        self.btn_print.clicked.connect(self._print_table)
        self.proxy.modelReset.connect(self._open_persistent_editors)
        self.proxy.rowsInserted.connect(lambda *_: self._open_persistent_editors())
        self.usage_compute_service.busy_changed.connect(self._on_compute_busy_changed)
        self.usage_compute_service.status_changed.connect(self._on_compute_status_changed)
        self.usage_compute_service.result_ready.connect(self._on_compute_result_ready)
        self.usage_compute_service.error_raised.connect(self._on_compute_error_raised)
        self.model.dataChanged.connect(self._on_usage_model_data_changed)

    def _initialize_usage_lifecycle(self) -> None:
        self._usage_state_refresh_timer = QTimer(self)
        self._usage_state_refresh_timer.setSingleShot(True)
        self._usage_state_refresh_timer.timeout.connect(self._run_app_state_usage_refresh)
        self._bound_app_state = None
        self._disposed = False
        self._deferred_usage_refresh = False
        self.destroyed.connect(self._cancel_usage_compute)
        self.destroyed.connect(self._on_destroyed)

    def _finish_usage_ui(self) -> None:
        self._apply_theme()
        self._size_columns()
        self.table.viewport().installEventFilter(self)
        self.table.installEventFilter(self)
        self._set_page_table_summary(0, loading=False)
        polish_interface(self, window_width=self.width())

    def _cancel_usage_compute(self, *_args) -> None:
        try:
            close = getattr(self.usage_compute_service, "close", None)
            if callable(close):
                close()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("Usage compute shutdown failed", exc_info=True)

    def _summary_state_kwargs(self, state_kwargs: dict) -> dict:
        payload = dict(state_kwargs)
        payload.setdefault("access_allowed", bool(self._access_allowed))
        payload.setdefault("access_reason", self._access_reason)
        return payload

    def eventFilter(self, obj, event):
        if obj is self.table.viewport() and event.type() == QEvent.Resize:
            if not getattr(self, "_fitting_table_columns", False):
                self._fitting_table_columns = True
                try:
                    self._size_columns()
                finally:
                    self._fitting_table_columns = False
        if (
            obj is self.table
            and event.type() == QEvent.KeyPress
            and (event.key() in (Qt.Key_Return, Qt.Key_Enter))
        ):
            current = self.table.currentIndex()
            row = current.row() if current.isValid() else 0
            column = current.column() if current.isValid() else COL_H
            if column != COL_H:
                column = COL_H
            next_row = min(row + 1, self.proxy.rowCount() - 1)
            target = self.proxy.index(next_row, column)
            if target.isValid():
                self.table.setCurrentIndex(target)
                self.table.edit(target)
                return True
        return super().eventFilter(obj, event)

    def showEvent(self, event):
        super().showEvent(event)
        if getattr(self, "_deferred_usage_refresh", False):
            self._deferred_usage_refresh = False
            try:
                self._usage_state_refresh_timer.start(120)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("UsagePage.showEvent fallback failed", exc_info=True)
