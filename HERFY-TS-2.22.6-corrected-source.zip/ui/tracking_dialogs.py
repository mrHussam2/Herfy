"""Designer-backed edit and confirmation surfaces for Tracking actions."""

from __future__ import annotations

from PySide6.QtCore import QDate, Qt
from PySide6.QtWidgets import QDateEdit, QDialog, QLabel, QLineEdit, QPushButton

from core.i18n import get_language, is_rtl
from core.models import ISO_DATE_FORMAT
from core.presentation import format_display_date
from core.settings import _
from ui.designer import load_ui
from ui.dialogs import apply_popup_contract, text_value
from ui.theme import polish_interface
from ui.widgets import polish_button


class EditTrackedProductDialog(QDialog):
    """Edit mutable tracking fields without repurposing the create toolbar."""

    def __init__(self, product: dict, parent=None):
        super().__init__(parent)
        self.product = dict(product or {})
        self.setWindowTitle(_("Edit monitored food item"))
        self.setLayoutDirection(Qt.RightToLeft if is_rtl(get_language()) else Qt.LeftToRight)
        apply_popup_contract(
            self,
            object_name="EditTrackedProductDialog",
            modal=True,
            size_grip=False,
            width_ratio=0.38,
            height_ratio=0.50,
            min_width=520,
            min_height=410,
            max_width=700,
            max_height=620,
        )
        self._build()
        polish_interface(self, window_width=self.width())

    def _build(self) -> None:
        controls = load_ui(
            self,
            "tracking_edit_dialog",
            required=(
                "tracking_edit_title",
                "tracking_edit_hint",
                "tracking_edit_branch",
                "tracking_edit_material",
                "tracking_edit_name",
                "tracking_edit_quantity",
                "tracking_edit_production",
                "tracking_edit_expiry",
                "tracking_edit_confirm",
                "tracking_edit_cancel",
            ),
        )
        controls["tracking_edit_title"].setText(_("Edit monitored food item"))
        controls["tracking_edit_hint"].setText(
            _("Update the quantity or dates. The authorized branch and material cannot be changed.")
        )
        labels = (
            ("tracking_edit_branch", text_value(self.product, "branch")),
            ("tracking_edit_material", text_value(self.product, "material_number")),
            ("tracking_edit_name", text_value(self.product, "name", "product_name", "display_product")),
        )
        for name, value in labels:
            control: QLabel = controls[name]
            control.setText(value)
            control.setWordWrap(True)
            control.setProperty("textRole", "SettingsCardText")

        quantity: QLineEdit = controls["tracking_edit_quantity"]
        quantity.setText(str(self.product.get("quantity") or ""))
        quantity.setFocus()
        for name, field in (
            ("tracking_edit_production", "production_date"),
            ("tracking_edit_expiry", "expiry_date"),
        ):
            editor: QDateEdit = controls[name]
            value = QDate.fromString(str(self.product.get(field) or ""), ISO_DATE_FORMAT)
            editor.setDate(value if value.isValid() else QDate.currentDate())

        cancel: QPushButton = controls["tracking_edit_cancel"]
        confirm: QPushButton = controls["tracking_edit_confirm"]
        cancel.setText(_("Cancel"))
        confirm.setText(_("Save changes"))
        polish_button(cancel, role="ghost")
        polish_button(confirm, role="primary")
        cancel.clicked.connect(self.reject)
        confirm.clicked.connect(self.accept)

    def values(self) -> dict[str, str]:
        quantity = self.findChild(QLineEdit, "tracking_edit_quantity")
        production = self.findChild(QDateEdit, "tracking_edit_production")
        expiry = self.findChild(QDateEdit, "tracking_edit_expiry")
        return {
            "quantity_text": str(quantity.text() if quantity else ""),
            "production_date": production.date().toString(ISO_DATE_FORMAT)
            if production is not None
            else "",
            "expiry_date": expiry.date().toString(ISO_DATE_FORMAT) if expiry is not None else "",
        }


class ConfirmTrackedProductDeleteDialog(QDialog):
    """Explicit confirmation for a server-backed destructive mutation."""

    def __init__(self, product: dict, parent=None):
        super().__init__(parent)
        self.product = product or {}
        self.setWindowTitle(_("Delete monitored food item"))
        self.setLayoutDirection(Qt.RightToLeft if is_rtl(get_language()) else Qt.LeftToRight)
        apply_popup_contract(
            self,
            object_name="ConfirmTrackedProductDeleteDialog",
            modal=True,
            size_grip=False,
            width_ratio=0.36,
            height_ratio=0.42,
            min_width=540,
            min_height=380,
            max_width=720,
            max_height=560,
        )
        self._build()
        polish_interface(self, window_width=self.width())

    def _build(self) -> None:
        controls = load_ui(
            self,
            "tracking_delete_dialog",
            required=(
                "tracking_delete_branch",
                "tracking_delete_material",
                "tracking_delete_name",
                "tracking_delete_quantity",
                "tracking_delete_production",
                "tracking_delete_expiry",
                "tracking_delete_confirm",
                "tracking_delete_cancel",
            ),
        )
        values = (
            ("tracking_delete_branch", _("Restaurant branch"), text_value(self.product, "branch")),
            ("tracking_delete_material", _("Material number"), text_value(self.product, "material_number")),
            ("tracking_delete_name", _("Product Name"), text_value(self.product, "name", "product_name", "display_product")),
            ("tracking_delete_quantity", _("On-hand quantity"), text_value(self.product, "quantity")),
            ("tracking_delete_production", _("Production date"), format_display_date(text_value(self.product, "production_date"))),
            ("tracking_delete_expiry", _("Expiry date"), format_display_date(text_value(self.product, "expiry_date"))),
        )
        for name, caption, value in values:
            label: QLabel = controls[name]
            label.setText(str(value or "-"))
            label.setWordWrap(True)
            label.setProperty("textRole", "SettingsCardText")
            self.findChild(QLabel, "label_" + name).setText(caption)
        self.findChild(QLabel, "tracking_delete_title").setText(_("Delete monitored food item"))
        self.findChild(QLabel, "tracking_delete_hint").setText(
            _("This action removes only this monitored record. Review all details before deleting.")
        )
        for name, role, slot, caption in (
            ("tracking_delete_cancel", "ghost", self.reject, _("Cancel")),
            ("tracking_delete_confirm", "danger", self.accept, _("Delete")),
        ):
            button: QPushButton = controls[name]
            button.setText(caption)
            polish_button(button, role=role)
            button.clicked.connect(slot)


def confirm_tracked_product_delete(product: dict, parent=None) -> bool:
    return bool(ConfirmTrackedProductDeleteDialog(product, parent).exec())
