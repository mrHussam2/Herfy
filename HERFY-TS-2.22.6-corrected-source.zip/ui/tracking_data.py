from __future__ import annotations

import logging
import time
from collections.abc import Callable

from PySide6.QtWidgets import QApplication, QLineEdit

from core.errors import UI_OPERATION_EXCEPTIONS
from core.settings import _
from ui.dialogs import show_info_message, show_warning_message
from ui.tables import fit_table_height_to_rows
from ui.widgets import set_input_state

logger = logging.getLogger(__name__)


"""Tracking data loading and asynchronous state controller."""


class TrackingDataControllerMixin:
    _load_token = 0

    def _on_app_state_tracking_changed(self, domain, payload=None) -> None:
        if not self._is_alive():
            return
        if str(domain or "").strip().lower() != "tracking":
            return
        if time.monotonic() < float(getattr(self, "_suppress_state_refresh_until", 0.0) or 0.0):
            return
        self._pending_state_payload = payload
        try:
            data = payload if isinstance(payload, dict) else {}
            catalog_delta = data.get("stored_catalog_delta")
            catalog_changed = bool(data.get("catalog_changed")) or bool(
                isinstance(catalog_delta, dict) and catalog_delta.get("applied")
            )
            if catalog_changed:
                if self.isVisible():
                    # The mutation wakes SyncCoordinator, which applies the
                    # server delta to the local stored-products projection.
                    # Read that projection here; a page event must never turn
                    # into a second catalog request.
                    self.load_product_catalog(force_network=False)
                # A full recovery can contain a catalog delta together with a
                # tracking baseline.  Refresh the completer first, but never
                # discard the accompanying tracking payload: doing so left a
                # visible monitoring table stale until the operator navigated
                # away and back.
            if not self.isVisible():
                return
            self._state_refresh_timer.start(120)
        except RuntimeError:
            logger.debug("TrackingPage._on_app_state_tracking_changed skipped: timer unavailable")
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._on_app_state_tracking_changed failed", exc_info=True)

    def _run_state_refresh(self) -> None:
        if not self._is_alive():
            return
        payload = self._pending_state_payload
        payload = payload if isinstance(payload, dict) else {}
        try:
            preloaded = payload.get("preloaded")
            delta = payload.get("tracking_delta")
            if preloaded is not None:
                self._tracking_controller.publish_baseline(preloaded, source="app_state")
                self.load_tracked_products(show_busy=False)
                return
            if isinstance(delta, dict) and delta.get("applied"):
                if not self._tracking_controller.baseline_ready():
                    self._pending_tracking_delta = dict(delta)
                    return
                self._apply_tracking_delta(delta)
                return
            self.load_tracked_products(show_busy=False)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._run_state_refresh failed", exc_info=True)

    def _apply_tracking_delta(self, delta: dict) -> None:
        """Project realtime deltas off the Qt thread; the model receives ready rows only."""
        payload = dict(delta or {})
        current_rows = [dict(row) for row in list(getattr(self, "tracked_products", []) or [])]
        catalog_rows = [dict(row) for row in list(getattr(self, "_product_catalog_rows", []) or [])]
        if self._worker_registry.has_active_key("tracking:delta-projection"):
            self._pending_tracking_delta = payload
            return

        def _project():
            return self._tracking_controller.project_delta_rows(
                current_rows,
                payload,
                catalog_rows,
            )

        def _apply(rows):
            if not self._is_alive():
                return
            self._apply_rows(list(rows or []))

        def _finished():
            pending = getattr(self, "_pending_tracking_delta", None)
            if isinstance(pending, dict):
                self._pending_tracking_delta = None
                self._apply_tracking_delta(pending)

        worker = self._worker_registry.start(
            _project,
            on_result=_apply,
            on_error=lambda message: logger.debug("Tracking delta projection skipped: %s", message),
            on_finished=_finished,
            operation_key="tracking:delta-projection",
            log_exceptions=False,
        )
        if worker is None:
            self._pending_tracking_delta = payload

    def refresh_expiry_projection_async(self) -> None:
        """Recompute expiry presentation off-thread after local threshold changes."""
        if not self._is_alive():
            return
        source_rows = self._tracking_controller.baseline_rows() or list(
            getattr(self, "tracked_products", []) or []
        )
        self._load_token += 1
        token = self._load_token
        self._schedule_cached_projection(
            token,
            source_rows,
            list(getattr(self, "_product_catalog_rows", []) or []),
        )

    def _is_user_editing(self) -> bool:
        try:
            focus_widget = QApplication.focusWidget()
            return isinstance(focus_widget, QLineEdit) and focus_widget in {
                getattr(self, "product_entry", None),
                getattr(self, "qty_entry", None),
            }
        except UI_OPERATION_EXCEPTIONS:
            return False

    def _is_current_load_token(self, token: int) -> bool:
        return (
            int(token) == int(getattr(self, "_load_token", -1))
            and self._is_alive()
            and (not bool(getattr(self, "_disposed", False)))
        )

    def _set_table_enabled(self, enabled: bool) -> None:
        try:
            self.table_view.setEnabled(enabled)
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._set_table_enabled failed", exc_info=True)

    def _begin_async_action(self, *, label: str, disable_add: bool = False) -> None:
        self._set_page_status(label, role="muted")
        self._set_table_enabled(False)
        if disable_add:
            self.btn_add.setEnabled(False)

    def _finish_async_action(self, *, restore_add_button: bool = True) -> None:
        self._action_running = False
        self._set_table_enabled(True)
        self._set_page_status("", role="muted")
        if restore_add_button:
            self._update_branch_ui_state()

    def _handle_async_success(
        self, *, message: str, refresh: bool = True, reset_form: bool = False
    ) -> None:
        self._suppress_state_refresh_until = time.monotonic() + 0.8
        self._finish_async_action()
        show_info_message(self, _("Success"), message)
        if refresh:
            self.load_tracked_products(show_busy=False)
        if reset_form:
            self._reset_tracking_form()

    def _handle_async_error(self, message: str) -> None:
        self._finish_async_action()
        text = message or _("Operation failed.")
        # Keep an actionable failure visible in the page itself as well as in
        # the dialog.  A modal can be obscured behind an operator's window,
        # whereas the inline status makes a rejected save unambiguous.
        self._set_page_status(text, role="error")
        show_warning_message(self, _("Error"), text)

    def _run_tracking_action(
        self,
        *,
        label: str,
        worker_fn: Callable,
        success_message: str,
        failure_message: str,
        reset_form: bool = False,
    ) -> None:
        if not self._is_alive():
            return
        if getattr(self, "_action_running", False):
            self._set_page_status(
                _("Please wait for the current operation to finish."), role="muted"
            )
            return
        self._action_running = True
        self._action_token = int(getattr(self, "_action_token", 0) or 0) + 1
        action_token = self._action_token
        self._begin_async_action(label=label, disable_add=True)

        def _is_current_action() -> bool:
            return self._is_alive() and action_token == int(
                getattr(self, "_action_token", -1) or -1
            )

        def _done(result):
            if not _is_current_action():
                return
            ok, message, error = self._normalize_action_result(result)
            if ok:
                self._handle_async_success(
                    message=message or success_message, reset_form=reset_form
                )
                return
            self._handle_async_error(error or failure_message)

        def _error(message: str):
            if not _is_current_action():
                return
            self._handle_async_error(message or failure_message)

        worker = self._worker_registry.start(
            worker_fn,
            on_result=_done,
            on_error=_error,
            on_finished=lambda: setattr(self, "_action_running", False),
            operation_key="tracking:action",
            scope_checker=_is_current_action,
        )
        if worker is None:
            self._action_running = False
            self._finish_async_action()
            self._set_page_status(
                _("Please wait for the current operation to finish."), role="muted"
            )

    @staticmethod
    def _normalize_action_result(result) -> tuple[bool, str, str]:
        if isinstance(result, list | tuple) and len(result) == 3:
            ok, message, error = result
            return (bool(ok), str(message or ""), str(error or ""))
        return (False, "", "")

    def load_tracked_products(self, preloaded: list | None = None, show_busy: bool = True) -> None:
        if preloaded is not None:
            self._tracking_controller.publish_baseline(preloaded, source="page_preload")
        baseline_rows = self._tracking_controller.baseline_rows()
        if self._tracking_controller.baseline_ready() and not show_busy:
            self._load_token += 1
            token = self._load_token
            self._schedule_cached_projection(
                token,
                baseline_rows,
                list(getattr(self, "_product_catalog_rows", []) or []),
            )
            return
        if getattr(self, "_loading", False):
            self._load_pending = True
            self._load_pending_show_busy = bool(
                getattr(self, "_load_pending_show_busy", False) or show_busy
            )
            self._set_page_status(_("Updating..."), role="muted")
            return
        if not show_busy and self._is_user_editing():
            return
        self._load_token += 1
        token = self._load_token
        self._loading = True
        self._last_load_show_busy = bool(show_busy)
        self._begin_load_ui(show_busy=show_busy)

        def _load_tracking_payload():
            return self._tracking_controller.load_payload(force_network=bool(show_busy))

        worker = self._worker_registry.start(
            _load_tracking_payload,
            on_result=lambda result: self._on_load_result(token, result),
            on_error=lambda message: self._on_load_error(token, message),
            on_finished=lambda: self._on_load_finished(token),
            operation_key="tracking:load",
            scope_checker=lambda: self._is_current_load_token(token),
        )
        if worker is None:
            self._loading = False
            self._finish_load_ui()
            self._load_pending = True
            self._load_pending_show_busy = bool(
                getattr(self, "_load_pending_show_busy", False) or show_busy
            )
            self._schedule_session_callback(
                120, lambda: self.load_tracked_products(show_busy=show_busy)
            )

    def _schedule_cached_projection(self, token: int, rows: list, catalog_rows: list) -> None:
        """Coalesce cached projection work so branch filtering/enrichment never blocks Qt."""
        self._pending_cached_projection = (int(token), list(rows or []), list(catalog_rows or []))
        if self._worker_registry.has_active_key("tracking:cached-projection"):
            return
        self._start_cached_projection()

    def _start_cached_projection(self) -> None:
        request = getattr(self, "_pending_cached_projection", None)
        if request is None or not self._is_alive():
            return
        self._pending_cached_projection = None
        token, rows, catalog_rows = request

        def _project():
            return self._tracking_controller.project_cached_rows(rows, catalog_rows)

        def _result(projected):
            if not self._is_current_load_token(token):
                return
            self._apply_rows(list(projected or []))
            pending_delta = getattr(self, "_pending_tracking_delta", None)
            if isinstance(pending_delta, dict):
                self._pending_tracking_delta = None
                self._apply_tracking_delta(pending_delta)

        def _finished():
            if getattr(self, "_pending_cached_projection", None) is not None and self._is_alive():
                self._schedule_session_callback(0, self._start_cached_projection)

        worker = self._worker_registry.start(
            _project,
            on_result=_result,
            on_error=lambda message: logger.debug(
                "Cached tracking projection skipped: %s", message
            ),
            on_finished=_finished,
            operation_key="tracking:cached-projection",
            log_exceptions=False,
        )
        if worker is None and getattr(self, "_pending_cached_projection", None) is None:
            self._pending_cached_projection = request

    def _begin_load_ui(self, *, show_busy: bool) -> None:
        self._set_table_enabled(False)
        self._update_table_summary(loading=True)
        if show_busy:
            self._set_page_status(_("Loading..."), role="muted")
            return
        self._set_page_status(_("Updating..."), role="muted")

    def _finish_load_ui(self) -> None:
        if not self._is_alive():
            return
        self._set_table_enabled(True)
        self._loading = False

    def _on_load_result(self, token: int, result) -> None:
        if not self._is_current_load_token(token):
            return
        payload = result if isinstance(result, dict) else {"rows": result or []}
        catalog = payload.get("catalog")
        if catalog is not None:
            self.update_completer(list(catalog or []))
        self._apply_rows(list(payload.get("rows") or []))
        pending_delta = getattr(self, "_pending_tracking_delta", None)
        if isinstance(pending_delta, dict):
            self._pending_tracking_delta = None
            self._apply_tracking_delta(pending_delta)

    def _on_load_error(self, token: int, message: str) -> None:
        if not self._is_current_load_token(token):
            return
        error_message = message or _("Failed to load data.")
        self._set_page_status(error_message, role="error")
        self._update_table_summary(loading=False, error_message=error_message)
        self._finish_load_ui()
        if getattr(self, "_last_load_show_busy", True):
            show_warning_message(self, _("Error"), error_message)

    def _on_load_finished(self, token: int) -> None:
        if not self._is_current_load_token(token):
            return
        self._finish_load_ui()
        self._update_table_summary(
            loading=False, truncated=self._tracking_controller.items_truncated()
        )
        if not self._tracking_controller.items_truncated() and self.tracked_products:
            self._set_page_status("", role="muted")
        if getattr(self, "_load_pending", False):
            pending_show_busy = bool(getattr(self, "_load_pending_show_busy", False))
            self._load_pending = False
            self._load_pending_show_busy = False
            self._schedule_session_callback(
                120, lambda: self.load_tracked_products(show_busy=pending_show_busy)
            )

    def _reconcile_visible_rows_with_catalog(self, catalog_rows: list | None = None) -> None:
        rows = list(getattr(self, "tracked_products", []) or [])
        if not rows:
            return
        enriched = self._tracking_controller.enrich_rows_for_display(rows, list(catalog_rows or []))
        if enriched != rows:
            self._apply_rows(enriched)

    def _apply_rows(self, rows: list) -> None:
        if not self._is_alive():
            return
        self.tracked_products = [dict(row) for row in list(rows or []) if isinstance(row, dict)]
        self._apply_tracking_filters()

    def _apply_tracking_filters(self, *_args) -> None:
        """Filter the visible table locally without another server request."""
        rows = list(getattr(self, "tracked_products", []) or [])
        search = str(getattr(self, "search_input", None).text() if getattr(self, "search_input", None) else "").strip().casefold()
        status = str(getattr(self, "status_filter", None).currentData() if getattr(self, "status_filter", None) else "").strip().casefold()

        def matches(row: dict) -> bool:
            haystack = " ".join(
                str(row.get(key) or "")
                for key in ("branch", "material_number", "material", "name", "product_name")
            ).casefold()
            if search and search not in haystack:
                return False
            if not status:
                return True
            key = str(row.get("expiry_status_key") or "").strip().casefold()
            text = str(row.get("expiry_status_text") or "").strip().casefold()
            return status in key or status in text

        visible = [row for row in rows if matches(row)]
        self.model.load_data(visible)
        fit_table_height_to_rows(self.table_view, min_rows=5, max_rows=18)
        self._size_tracking_columns()
        self._update_table_summary(
            loading=False, truncated=self._tracking_controller.items_truncated()
        )
        self._refresh_completer_if_needed()

    def load_product_catalog(self, *, force_network: bool = False) -> None:
        if not self._is_alive():
            return
        if getattr(self, "_catalog_loading", False):
            self._catalog_load_pending_force_network = bool(
                getattr(self, "_catalog_load_pending_force_network", False) or force_network
            )
            return
        self._catalog_loading = True
        self._catalog_load_token = int(getattr(self, "_catalog_load_token", 0) or 0) + 1
        token = self._catalog_load_token
        worker = self._worker_registry.start(
            lambda: self._tracking_controller.catalog_products(force_network=bool(force_network)),
            on_result=lambda products: self._on_catalog_loaded(token, products),
            on_error=lambda message: self._on_catalog_load_failed(token, message),
            on_finished=lambda: self._on_catalog_load_finished(token),
            operation_key="tracking:catalog",
            scope_checker=lambda: (
                self._is_alive() and token == int(getattr(self, "_catalog_load_token", -1) or -1)
            ),
        )
        if worker is None:
            self._catalog_loading = False
            self._catalog_load_pending_force_network = bool(
                getattr(self, "_catalog_load_pending_force_network", False) or force_network
            )
            self._schedule_session_callback(
                120, lambda: self.load_product_catalog(force_network=force_network)
            )

    def _on_catalog_load_finished(self, token: int) -> None:
        """Release catalog-load gate and run one coalesced pending request."""
        if token != int(getattr(self, "_catalog_load_token", -1) or -1):
            return
        self._catalog_loading = False
        if getattr(self, "_catalog_load_pending_force_network", False):
            self._catalog_load_pending_force_network = False
            self._schedule_session_callback(
                120, lambda: self.load_product_catalog(force_network=True)
            )

    def _on_catalog_loaded(self, token: int, products) -> None:
        if not self._is_alive() or token != int(getattr(self, "_catalog_load_token", -1) or -1):
            return
        self.update_completer(list(products or []))

    def _on_catalog_load_failed(self, token: int, detail: str) -> None:
        """Make a failed authoritative catalog fetch actionable to the operator."""
        if not self._is_alive() or token != int(getattr(self, "_catalog_load_token", -1) or -1):
            return
        message = _("Product catalog could not be loaded. Check the connection and try again.")
        self._set_page_status(message, role="warning")
        set_input_state(getattr(self, "product_entry", None), "warning", tooltip=message)
        logger.warning("TRACKING_CATALOG_LOAD=FAIL detail=%s", str(detail or "")[:400])

    def _update_table_summary(
        self, *, loading: bool, truncated: bool = False, error_message: str = ""
    ) -> None:
        self._safe_set_page_table_summary(
            self.model.rowCount() if hasattr(self, "model") else len(getattr(self, "tracked_products", []) or []),
            loading=loading,
            truncated=truncated,
            error_message=error_message,
        )

    def _refresh_completer_if_needed(self) -> None:
        try:
            cache_size = self._tracking_controller.name_cache_size()
            if cache_size == getattr(self, "_completer_cache_size", -1):
                return
            self._completer_cache_size = cache_size
            self.update_completer()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("TrackingPage._refresh_completer_if_needed failed", exc_info=True)


logger = logging.getLogger(__name__)
