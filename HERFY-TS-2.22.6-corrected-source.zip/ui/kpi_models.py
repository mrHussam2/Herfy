"""Reusable Qt model behavior for the embedded KPI workspace."""

from __future__ import annotations

from PySide6 import QtCore


class TopLevelRowsTableModel(QtCore.QAbstractTableModel):
    """Base model for flat KPI tables that have no child indexes."""

    def rowCount(
        self,
        parent: QtCore.QModelIndex | QtCore.QPersistentModelIndex | None = None,
    ) -> int:
        return 0 if parent is not None and parent.isValid() else len(self._rows)
