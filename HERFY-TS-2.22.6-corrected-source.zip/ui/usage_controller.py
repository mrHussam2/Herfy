from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtWidgets import QFileDialog

from core.errors import UI_OPERATION_EXCEPTIONS
from core.settings import _
from ui.tables import COL_B, COL_H, COL_R, COL_T, COL_U, usage_print_headers
from ui.widgets import ControllerLifecycleMixin, DomainAppStateBindingMixin, refresh_widget_style


@dataclass(frozen=True)
class UsageComputePayload:
    rows: list[dict]
    status_text: str


class UsageComputeService(QObject):
    busy_changed = Signal(bool)
    status_changed = Signal(str)
    result_ready = Signal(object)
    error_raised = Signal(str)

    def __init__(
        self,
        *,
        usage_service: Any,
        workspace_service: Any,
        worker_registry,
        parent: QObject | None = None,
    ):
        super().__init__(parent)
        self.usage_service = usage_service
        if workspace_service is None:
            raise RuntimeError("UsageComputeService requires a composed workspace service")
        self.workspace_service = workspace_service
        if worker_registry is None:
            raise RuntimeError("UsageComputeService requires a worker registry")
        self._worker_registry = worker_registry
        self._debounce = QTimer(self)
        self._debounce.setSingleShot(True)
        self._debounce.timeout.connect(self._run_pending_request)
        self._compute_running = False
        self._compute_pending = False
        self._compute_token = 0
        self._current_worker = None
        self._last_request: dict[str, object] = {
            "access_allowed": True,
            "access_reason": "",
            "receipts_path": "",
            "beginning_path": "",
        }

    @property
    def is_busy(self) -> bool:
        return bool(self._compute_running)

    def close(self) -> None:
        self.cancel()
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            registry.close()

    def cancel(self) -> None:
        self._compute_token = int(getattr(self, "_compute_token", 0) or 0) + 1
        self._compute_pending = False
        self._debounce.stop()
        registry = getattr(self, "_worker_registry", None)
        if registry is not None:
            registry.cancel_all()
        self._current_worker = None
        if self._compute_running:
            self._emit_busy(False)

    def request_auto_compute(
        self,
        *,
        access_allowed: bool,
        access_reason: str,
        receipts_path: str,
        beginning_path: str,
        delay_ms: int = 400,
    ) -> bool:
        self._last_request = {
            "access_allowed": bool(access_allowed),
            "access_reason": str(access_reason or ""),
            "receipts_path": str(receipts_path or "").strip(),
            "beginning_path": str(beginning_path or "").strip(),
        }
        if not self.workspace_service.auto_compute_ready(receipts_path, beginning_path):
            return False
        if self._compute_running:
            self._compute_pending = True
        self.status_changed.emit(_("Preparing…"))
        self._debounce.start(max(150, int(delay_ms or 0)))
        return True

    def persist_hide_total_zero_preference(self, enabled: bool) -> None:
        value = bool(enabled)
        workspace_service = self.workspace_service

        def _work():
            workspace_service.persist_hide_total_zero_enabled(value)
            return value

        self._worker_registry.start(
            _work,
            on_error=lambda message: self.error_raised.emit(
                str(message or _("Failed to save setting."))
            ),
            operation_key="usage:hide-total-zero",
        )

    def request_compute(
        self,
        *,
        access_allowed: bool,
        access_reason: str,
        receipts_path: str,
        beginning_path: str,
    ) -> None:
        self._last_request = {
            "access_allowed": bool(access_allowed),
            "access_reason": str(access_reason or ""),
            "receipts_path": str(receipts_path or "").strip(),
            "beginning_path": str(beginning_path or "").strip(),
        }
        if self._compute_running:
            self._compute_pending = True
            self.status_changed.emit(_("Calculation already running; queued latest request…"))
            return
        self._run_pending_request()

    def _emit_busy(self, busy: bool) -> None:
        busy = bool(busy)
        self._compute_running = busy
        self.busy_changed.emit(busy)

    def _evaluate_request(self) -> Any:
        return self.workspace_service.evaluate_compute_request(
            access_allowed=bool(self._last_request.get("access_allowed", True)),
            access_reason=str(self._last_request.get("access_reason") or ""),
            usage_service=self.usage_service,
            receipts_path=str(self._last_request.get("receipts_path") or ""),
            beginning_path=str(self._last_request.get("beginning_path") or ""),
        )

    def _run_pending_request(self) -> None:
        if self._compute_running:
            return
        decision = self._evaluate_request()
        if not decision.allowed:
            self.error_raised.emit(decision.message)
            return
        receipts_path = str(self._last_request.get("receipts_path") or "")
        beginning_path = str(self._last_request.get("beginning_path") or "")
        self._compute_token = int(getattr(self, "_compute_token", 0) or 0) + 1
        compute_token = self._compute_token
        self._emit_busy(True)
        self.status_changed.emit(_("Preparing…"))
        usage_service = self.usage_service

        def _is_current_compute() -> bool:
            return compute_token == int(getattr(self, "_compute_token", -1) or -1)

        def _work(progress_callback=None):
            return usage_service.compute_rows(
                receipts_path, beginning_path, progress_callback=progress_callback
            )

        worker = self._worker_registry.start(
            _work,
            on_progress=self._on_worker_progress,
            on_result=self._on_worker_result,
            on_error=self._on_worker_error,
            on_finished=lambda: self._on_worker_finished(compute_token),
            operation_key="usage:compute",
            scope_checker=_is_current_compute,
        )
        self._current_worker = worker
        if worker is None:
            self._emit_busy(False)
            self._compute_pending = True
            self._debounce.start(400)

    def _on_worker_progress(self, message) -> None:
        if message:
            self.status_changed.emit(str(message))

    def _on_worker_result(self, rows) -> None:
        rows = list(rows or [])
        status_text = self.workspace_service.build_result_status(rows, self.usage_service)
        self.result_ready.emit(UsageComputePayload(rows=rows, status_text=status_text))
        self.status_changed.emit(status_text)

    def _on_worker_error(self, message: str) -> None:
        self.error_raised.emit(str(message or _("Usage calculation failed.")))

    def _on_worker_finished(self, compute_token: int) -> None:
        if int(compute_token) != int(getattr(self, "_compute_token", 0) or 0):
            return
        self._current_worker = None
        self._emit_busy(False)
        if self._compute_pending:
            self._compute_pending = False
            self._debounce.start(400)


__all__ = ["UsageComputePayload", "UsageComputeService"]


logger = logging.getLogger(__name__)


class UsageControllerMixin(DomainAppStateBindingMixin, ControllerLifecycleMixin):
    app_state_page_name = "UsagePage"
    app_state_callback_name = "_on_app_state_usage_changed"

    def _on_app_state_usage_changed(self, domain, payload=None):
        if not self._is_alive():
            return
        if str(domain or "").strip().lower() != "usage":
            return
        if self._usage_workspace_has_active_input():
            self._mark_usage_server_refresh_pending(payload)
            return
        if not self._should_refresh_now():
            self._deferred_usage_refresh = True
            return
        try:
            self._usage_state_refresh_timer.start(120)
        except RuntimeError:
            logger.debug("UsagePage._on_app_state_usage_changed skipped: timer no longer available")

    def _run_app_state_usage_refresh(self):
        if not self._is_alive():
            return
        try:
            if self._usage_workspace_has_active_input():
                self._mark_usage_server_refresh_pending({"reason": "deferred_usage_refresh"})
                return
            if self._receipts_path or self._beginning_path or self.model.rowCount() > 0:
                self._auto_compute()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage._run_app_state_usage_refresh fallback failed", exc_info=True)

    def _usage_workspace_has_active_input(self) -> bool:
        return bool(
            getattr(self, "_usage_workspace_active", False)
            or getattr(self, "_usage_input_dirty", False)
            or str(getattr(self, "_receipts_path", "") or "").strip()
            or str(getattr(self, "_beginning_path", "") or "").strip()
            or (hasattr(self, "model") and self.model.rowCount() > 0)
        )

    def _mark_usage_server_refresh_pending(self, payload=None) -> None:
        self._usage_server_refresh_pending = True
        try:
            self._set_page_table_summary(
                self.proxy.rowCount(),
                loading=False,
                status_text=_("Server catalog changed. Worksheet preserved."),
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "UsagePage._mark_usage_server_refresh_pending fallback failed",
                exc_info=True,
            )

    def _apply_access_state(self):
        enabled = bool(self._access_allowed and (not self._compute_is_running()))
        for widget in (
            self.btn_r,
            self.btn_b,
            getattr(self, "btn_recalculate", None),
            getattr(self, "chk_hide_total_zero", None),
            self.btn_print,
            self.search,
            self.table,
        ):
            if widget is None:
                continue
            try:
                widget.setEnabled(enabled)
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("UsagePage._apply_access_state fallback failed", exc_info=True)
        refresh_availability = getattr(
            self, "_refresh_toolbar_action_availability", None
        )
        if callable(refresh_availability):
            refresh_availability()
        if not self._access_allowed or not self._compute_is_running():
            self._set_page_table_summary(self.proxy.rowCount(), loading=False)

    def clear_workspace(self) -> None:
        """Discard the transient Usage worksheet whenever the user leaves the page."""
        try:
            cancel = getattr(self.usage_compute_service, "cancel", None)
            if callable(cancel):
                cancel()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage clear: compute cancellation failed", exc_info=True)

        timer = getattr(self, "_usage_state_refresh_timer", None)
        try:
            if timer is not None:
                timer.stop()
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage clear: refresh timer stop failed", exc_info=True)

        self._receipts_path = ""
        self._beginning_path = ""
        self._usage_workspace_active = False
        self._usage_input_dirty = False
        self._usage_server_refresh_pending = False
        self._deferred_usage_refresh = False

        try:
            self.model.replace_rows([])
            self.search.clear()
            self.proxy.refresh_filter()

            self.btn_r.setText(_("Receipts"))
            self.btn_r.setToolTip(_("Import receipts file"))
            self.btn_r.setProperty("fileSelected", False)
            refresh_widget_style(self.btn_r)

            self.btn_b.setText(_("Opening"))
            self.btn_b.setToolTip(_("Import opening stock file"))
            self.btn_b.setProperty("fileSelected", False)
            refresh_widget_style(self.btn_b)

            self._safe_set_page_table_summary(
                0,
                loading=False,
                status_text=_("Select Receipts and Opening Stock files to calculate usage."),
            )
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage clear: visual reset failed", exc_info=True)

    def _select_excel_file(self, title: str) -> str:
        dialog = QFileDialog(self, title)
        dialog.setObjectName("AppFileDialog")
        dialog.setWindowModality(Qt.WindowModal)
        dialog.setFileMode(QFileDialog.ExistingFile)
        all_files_filter = _("All files (*.*)")
        dialog.setNameFilters(
            [
                all_files_filter,
                _("Supported data files (*.xlsx *.xls *.xlsm *.csv *.txt *.tsv)"),
            ]
        )
        dialog.selectNameFilter(all_files_filter)
        dialog.setViewMode(QFileDialog.Detail)
        dialog.setOption(QFileDialog.DontUseNativeDialog, False)
        try:
            dialog.setLayoutDirection(self.layoutDirection())
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage._select_excel_file fallback failed", exc_info=True)
        if dialog.exec() != QFileDialog.Accepted:
            return ""
        files = dialog.selectedFiles() or []
        return str(files[0] or "") if files else ""

    def _apply_file_selection(self, path: str, *, target: str):
        self._usage_workspace_active = True
        self._usage_server_refresh_pending = False
        present = self.usage_workspace_service.format_selected_file(path)
        if target == "receipts":
            self._receipts_path = str(path or "")
            self.btn_r.setToolTip(present.tooltip or _("Import receipts file"))
            self.btn_r.setText(_("Receipts") + " ✓")
            self.btn_r.setProperty("fileSelected", True)
            refresh_widget_style(self.btn_r)
            return
        self._beginning_path = str(path or "")
        self.btn_b.setToolTip(present.tooltip or _("Import opening stock file"))
        self.btn_b.setText(_("Opening stock") + " ✓")
        self.btn_b.setProperty("fileSelected", True)
        refresh_widget_style(self.btn_b)

    def _pick_usage_file(self, title: str, *, target: str):
        path = self._select_excel_file(title)
        if not path:
            return
        self._apply_file_selection(path, target=target)
        self._auto_compute()

    def _pick_r(self):
        self._pick_usage_file(_("Receipts"), target="receipts")

    def _pick_b(self):
        self._pick_usage_file(_("Opening stock"), target="beginning")

    def _compute_is_running(self) -> bool:
        return bool(self.usage_compute_service.is_busy)

    def _auto_compute(self):
        self._usage_workspace_active = True
        started = self.usage_compute_service.request_auto_compute(
            access_allowed=self._access_allowed,
            access_reason=self._access_reason,
            receipts_path=self._receipts_path,
            beginning_path=self._beginning_path,
        )
        if started:
            self._set_page_status(_("Preparing…"), role="muted")

    def compute(self):
        self._usage_workspace_active = True
        self._usage_server_refresh_pending = False
        self.usage_compute_service.request_compute(
            access_allowed=self._access_allowed,
            access_reason=self._access_reason,
            receipts_path=self._receipts_path,
            beginning_path=self._beginning_path,
        )

    def _on_compute_busy_changed(self, busy: bool):
        self._apply_access_state()
        current_rows = self.model.rowCount() if hasattr(self, "model") else 0
        self._safe_set_page_table_summary(
            current_rows, loading=bool(busy), status_text=self.lbl_status.text()
        )

    def _on_compute_status_changed(self, message):
        if message:
            self._set_page_table_summary(
                self.proxy.rowCount(),
                loading=self._compute_is_running(),
                status_text=str(message),
            )

    def _on_compute_result_ready(self, payload):
        if isinstance(payload, UsageComputePayload):
            rows = payload.rows
            status_text = payload.status_text
        else:
            rows = list(getattr(payload, "rows", []) or [])
            status_text = str(getattr(payload, "status_text", "") or "")
        try:
            self._model_replace_in_progress = True
            self.model.replace_rows_preserving_user_inputs(rows)
        finally:
            self._model_replace_in_progress = False
        self._usage_workspace_active = bool(
            self._receipts_path or self._beginning_path or self.model.rowCount() > 0
        )
        self.proxy.set_hide_total_zero(self.usage_workspace_service.hide_total_zero_enabled())
        self._open_persistent_editors()
        self._size_columns()
        self._safe_set_page_table_summary(
            self.proxy.rowCount(), loading=False, status_text=status_text
        )

    def _on_compute_error_raised(self, message: str):
        self._usage_server_refresh_pending = False
        self.model.replace_rows([])
        self._safe_set_page_table_summary(
            0,
            loading=False,
            error_message=str(message or _("Usage calculation failed.")),
        )

    def _on_hide_total_zero_toggled(self, checked: bool) -> None:
        self.usage_compute_service.persist_hide_total_zero_preference(bool(checked))
        self.proxy.set_hide_total_zero(bool(checked))
        self._open_persistent_editors()
        self._size_columns()
        status = _("Zero-total rows are hidden.") if checked else _("Zero-total rows are visible.")
        self._safe_set_page_table_summary(
            self.proxy.rowCount(),
            loading=self._compute_is_running(),
            status_text=status,
        )

    def _on_usage_model_data_changed(self, top_left, bottom_right, _roles=None):
        if getattr(self, "_model_replace_in_progress", False):
            return
        try:
            if top_left.column() <= COL_H <= bottom_right.column():
                self._usage_workspace_active = True
                self._usage_input_dirty = True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug("UsagePage._on_usage_model_data_changed fallback failed", exc_info=True)

    def _open_persistent_editors(self):
        # The Available Stock editor is intentionally opened only for the active
        # cell; persistent editors caused button-like fields and focus issues.
        self.table.setItemDelegateForColumn(COL_H, self.delegate)

    def _print_table(self):
        decision = self.usage_workspace_service.evaluate_preview_request(
            access_allowed=self._access_allowed,
            access_reason=self._access_reason,
            row_count=self.proxy.rowCount(),
        )
        if not decision.allowed:
            self._set_page_status(decision.message, role="warning")
            return
        # Snapshot the already-computed proxy model. Printing must never trigger a
        # second Usage calculation; preview/render remains on the GUI thread.
        try:
            context = self.usage_workspace_service.build_print_context(
                usage_print_service=self.usage_print_service,
                model=self.proxy,
                headers=usage_print_headers(),
                numeric_columns=(COL_R, COL_B, COL_T, COL_H, COL_U),
                column_ratios=self.COL_RATIOS,
            )
            shown = self.usage_print_service.show_preview(self, context=context)
        except Exception as exc:
            logger.exception("Usage print preview failed")
            self._set_page_status(
                _("Print preview failed: {error}").format(error=str(exc)),
                role="error",
            )
            return
        if not shown:
            self._set_page_status(_("No usage rows to preview."), role="warning")


UsageController = UsageControllerMixin
__all__ = ["UsageControllerMixin", "UsageController"]
