"""Shared native Qt event hooks for responsive embedded pages."""

from PySide6.QtWidgets import QWidget


def responsive_resize_event(widget: QWidget, event) -> None:
    """Dispatch QWidget's resize event, then refresh responsive state."""
    QWidget.resizeEvent(widget, event)
    widget.apply_responsive_profile()
