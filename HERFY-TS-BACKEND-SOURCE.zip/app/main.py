from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import JSONResponse

from app.api.auth import router as auth_router
from app.api.admin import router as admin_router
from app.api.sync import router as sync_router
from app.api.catalogs import router as catalog_router
from app.api.tracking import router as tracking_router
from app.api.meta import router as meta_router
from app.api.realtime import router as realtime_router
from app.core.errors import install_error_handlers
from app.core.request_context import new_request_id, reset_request_id, set_request_id
from app.db.session import database_is_ready


def create_app() -> FastAPI:
    app = FastAPI(title="HERFY API", version="0.1.0", docs_url=None, redoc_url=None)
    install_error_handlers(app)

    @app.middleware("http")
    async def request_id_middleware(request, call_next):
        supplied = request.headers.get("X-Request-ID", "").strip()
        request_id = (
            supplied
            if 1 <= len(supplied) <= 128 and supplied.isascii()
            else new_request_id()
        )
        context_token = set_request_id(request_id)
        try:
            response = await call_next(request)
            response.headers["X-Request-ID"] = request_id
            return response
        finally:
            reset_request_id(context_token)

    app.include_router(auth_router)
    app.include_router(admin_router)
    app.include_router(sync_router)
    app.include_router(catalog_router)
    app.include_router(tracking_router)
    app.include_router(meta_router)
    app.include_router(realtime_router)

    @app.get("/api/health")
    def health() -> dict[str, bool | str]:
        return {"ok": True, "status": "live"}

    @app.get("/api/ready", response_model=None)
    def ready() -> dict[str, bool | str] | JSONResponse:
        if database_is_ready():
            return {"ok": True, "status": "ready"}
        return JSONResponse(status_code=503, content={"ok": False, "status": "unready"})

    return app


app = create_app()
