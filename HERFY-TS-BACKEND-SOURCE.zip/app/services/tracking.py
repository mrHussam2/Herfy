from __future__ import annotations

from datetime import date, datetime, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.errors import ApiError
from app.models.entities import StoredProduct, SyncChange, TrackingItem, User
from app.services.audit import record_audit
from app.services.authorization import authority_payload, require_permissions


def _timestamp(value: datetime | None) -> str | None:
    return value.astimezone(timezone.utc).isoformat() if value else None


def tracking_payload(item: TrackingItem) -> dict:
    return {
        "id": item.id,
        "branch_id": item.branch_id,
        "material_number": item.material_number,
        "material_name": item.material_name,
        "quantity": item.quantity,
        "production_date": item.production_date,
        "expiry_date": item.expiry_date,
        "notes": item.notes,
        "responsible_user_id": item.responsible_user_id,
        "revision": item.revision,
        "is_deleted": item.is_deleted,
        "created_at": _timestamp(item.created_at),
        "updated_at": _timestamp(item.updated_at),
        "deleted_at": _timestamp(item.deleted_at),
        "deleted_by": item.deleted_by,
        "created_by": item.created_by,
        "updated_by": item.updated_by,
    }


def _require_branch_write(
    session: Session, actor: User, branch_id: str, permission: str
) -> None:
    try:
        require_permissions(session, actor, permission)
    except PermissionError as exc:
        raise ApiError(403, str(exc), "This operation is not permitted.") from exc
    scope = authority_payload(session, actor)["scope"]
    if not scope["all_branches"] and branch_id not in scope["branches"]:
        raise ApiError(
            403,
            "scope_denied",
            "The requested branch is outside the current actor scope.",
        )


def _validate_dates(production_date: str, expiry_date: str) -> None:
    try:
        production = date.fromisoformat(production_date)
        expiry = date.fromisoformat(expiry_date)
    except ValueError as exc:
        raise ApiError(
            422, "invalid_date", "Production and expiry dates must use ISO format."
        ) from exc
    if expiry < production:
        raise ApiError(
            422, "invalid_expiry", "Expiry date cannot precede production date."
        )


def _record_change(
    session: Session, *, item: TrackingItem, operation: str
) -> SyncChange:
    change = SyncChange(
        entity_type="tracking_item",
        entity_id=item.id,
        operation=operation,
        revision=item.revision,
        scope_type="branch",
        scope_id=item.branch_id,
        payload=tracking_payload(item),
    )
    session.add(change)
    session.flush()
    return change


def create_tracking_item(
    session: Session, actor: User, payload: dict
) -> tuple[TrackingItem, SyncChange]:
    branch_id = str(payload.get("branch_id") or "").strip()
    material_number = str(payload.get("material_number") or "").strip()
    item_id = str(payload.get("id") or "").strip()
    if not branch_id or not material_number or not item_id:
        raise ApiError(
            422, "invalid_tracking_item", "Tracking item identity is required."
        )
    if int(payload.get("base_revision") or 0) != 0:
        raise ApiError(
            409, "revision_conflict", "A new tracking item must start at revision zero."
        )
    _require_branch_write(session, actor, branch_id, "tracking.create")
    product = session.get(StoredProduct, material_number)
    if product is None or not product.is_active:
        raise ApiError(
            422, "unknown_material", "The material is not an active stored product."
        )
    quantity = int(payload.get("quantity") or 0)
    if quantity < 0:
        raise ApiError(422, "invalid_quantity", "Quantity cannot be negative.")
    production_date = str(payload.get("production_date") or "")
    expiry_date = str(payload.get("expiry_date") or "")
    _validate_dates(production_date, expiry_date)
    if session.get(TrackingItem, item_id) is not None:
        raise ApiError(409, "tracking_exists", "This tracking item already exists.")
    item = TrackingItem(
        id=item_id,
        branch_id=branch_id,
        material_number=material_number,
        material_name=product.name,
        quantity=quantity,
        production_date=production_date,
        expiry_date=expiry_date,
        notes=str(payload.get("notes") or ""),
        responsible_user_id=actor.id,
        created_by=actor.id,
        updated_by=actor.id,
    )
    session.add(item)
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action="tracking_create",
        entity_type="tracking_item",
        entity_id=item.id,
    )
    return item, _record_change(session, item=item, operation="create")


def update_tracking_item(
    session: Session, actor: User, payload: dict
) -> tuple[TrackingItem, SyncChange]:
    item_id = str(payload.get("id") or "").strip()
    item = session.get(TrackingItem, item_id)
    if item is None or item.is_deleted:
        raise ApiError(
            404, "tracking_not_found", "The requested tracking item does not exist."
        )
    if int(payload.get("base_revision") or 0) != item.revision:
        raise ApiError(
            409, "revision_conflict", "The tracking item has changed; reload and retry."
        )
    requested_branch = str(payload.get("branch_id") or "").strip()
    if requested_branch != item.branch_id:
        raise ApiError(
            422, "branch_immutable", "A tracking item cannot be moved between branches."
        )
    _require_branch_write(session, actor, item.branch_id, "tracking.update")
    material_number = str(payload.get("material_number") or "").strip()
    product = session.get(StoredProduct, material_number)
    if product is None or not product.is_active:
        raise ApiError(
            422, "unknown_material", "The material is not an active stored product."
        )
    quantity = int(payload.get("quantity") or 0)
    if quantity < 0:
        raise ApiError(422, "invalid_quantity", "Quantity cannot be negative.")
    production_date = str(payload.get("production_date") or "")
    expiry_date = str(payload.get("expiry_date") or "")
    _validate_dates(production_date, expiry_date)
    item.material_number = material_number
    item.material_name = product.name
    item.quantity = quantity
    item.production_date = production_date
    item.expiry_date = expiry_date
    item.notes = str(payload.get("notes") or "")
    item.revision += 1
    item.updated_by = actor.id
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action="tracking_update",
        entity_type="tracking_item",
        entity_id=item.id,
    )
    return item, _record_change(session, item=item, operation="update")


def delete_tracking_item(
    session: Session, actor: User, payload: dict
) -> tuple[TrackingItem, SyncChange]:
    item_id = str(payload.get("id") or "").strip()
    item = session.get(TrackingItem, item_id)
    if item is None or item.is_deleted:
        raise ApiError(
            404, "tracking_not_found", "The requested tracking item does not exist."
        )
    if int(payload.get("base_revision") or 0) != item.revision:
        raise ApiError(
            409, "revision_conflict", "The tracking item has changed; reload and retry."
        )
    _require_branch_write(session, actor, item.branch_id, "tracking.delete")
    item.is_deleted = True
    item.deleted_at = datetime.now(timezone.utc)
    item.deleted_by = actor.id
    item.updated_by = actor.id
    item.revision += 1
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action="tracking_delete",
        entity_type="tracking_item",
        entity_id=item.id,
    )
    return item, _record_change(session, item=item, operation="delete")


def visible_tracking_items(
    session: Session, actor: User, *, include_deleted: bool = False
) -> list[TrackingItem]:
    scope = authority_payload(session, actor)["scope"]
    statement = select(TrackingItem)
    if not include_deleted:
        statement = statement.where(TrackingItem.is_deleted.is_(False))
    if not scope["all_branches"]:
        statement = statement.where(TrackingItem.branch_id.in_(scope["branches"]))
    return list(session.scalars(statement.order_by(TrackingItem.id)).all())
