from __future__ import annotations


# Passwords may be a single character.  The server only rejects an empty value
# so every client, including first-login flows, applies the same policy.
MIN_LENGTH = 1
MAX_LENGTH = 128


def validate_password(password: str) -> None:
    if not password:
        raise ValueError("password_policy")


def policy_payload() -> dict[str, int | bool]:
    return {
        "min_length": MIN_LENGTH,
        "max_length": MAX_LENGTH,
        "require_letter": False,
        "require_digit": False,
    }
