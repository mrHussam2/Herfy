from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.entities import Area, Branch, Organization, Region


def create_organization(session: Session, *, id: str, name: str) -> Organization:
    entity = Organization(id=id.strip(), name=name.strip())
    session.add(entity)
    return entity


def create_region(
    session: Session, *, id: str, code: str, name: str, organization_id: str
) -> Region:
    entity = Region(
        id=id.strip(),
        code=code.strip(),
        name=name.strip(),
        organization_id=organization_id.strip(),
    )
    session.add(entity)
    return entity


def create_area(
    session: Session, *, id: str, code: str, name: str, region_id: str
) -> Area:
    entity = Area(
        id=id.strip(), code=code.strip(), name=name.strip(), region_id=region_id.strip()
    )
    session.add(entity)
    return entity


def create_branch(
    session: Session, *, id: str, code: str, name: str, area_id: str
) -> Branch:
    entity = Branch(
        id=id.strip(), code=code.strip(), name=name.strip(), area_id=area_id.strip()
    )
    session.add(entity)
    return entity
