from __future__ import annotations

from sqlalchemy import and_, exists, false, not_, or_, select
from sqlalchemy.orm import Session

from app.models.entities import (
    Area,
    Branch,
    Organization,
    Region,
    RolePermission,
    User,
    UserAreaScope,
    UserBranchScope,
    UserOrganizationScope,
    UserRegionScope,
)
from app.services.users import account_type, public_role


ALL_PERMISSIONS = {
    "users.view",
    "users.create",
    "users.update",
    "users.enable",
    "users.disable",
    "users.password.reset",
    "users.scopes.assign",
    "organizations.view",
    "regions.view",
    "regions.create",
    "regions.update",
    "regions.delete",
    "areas.view",
    "areas.create",
    "areas.update",
    "areas.delete",
    "branches.view",
    "branches.create",
    "branches.update",
    "branches.delete",
    "branches.transfer",
    "catalog.view",
    "catalog.manage",
    "usage.view",
    "usage.manage",
    "kpi.view",
    "permissions.view",
    "permissions.assign",
    "roles.view",
    "roles.assign",
    "audit.view",
    "tracking.view",
    "tracking.create",
    "tracking.update",
    "tracking.delete",
}

DELEGATION = {
    "system": {
        "operations_director",
        "operations_manager",
        "operations_consultant",
        "store_manager",
        "store_account",
    },
    "operations_director": {"operations_manager"},
    "operations_manager": {"operations_consultant"},
    "operations_consultant": {"store_manager"},
    "store_manager": set(),
    "store_account": set(),
}


def role_permissions(session: Session, role: str) -> list[str]:
    if role == "system":
        return sorted(ALL_PERMISSIONS)
    return sorted(
        session.scalars(
            select(RolePermission.permission).where(RolePermission.role == role)
        ).all()
    )


def _direct_ids(session: Session, model, column, user_id: str) -> set[str]:
    return set(session.scalars(select(column).where(model.user_id == user_id)).all())


def authority_payload(session: Session, user: User) -> dict:
    organization_ids = _direct_ids(
        session, UserOrganizationScope, UserOrganizationScope.organization_id, user.id
    )
    region_ids = _direct_ids(
        session, UserRegionScope, UserRegionScope.region_id, user.id
    )
    area_ids = _direct_ids(session, UserAreaScope, UserAreaScope.area_id, user.id)
    branch_ids = _direct_ids(
        session, UserBranchScope, UserBranchScope.branch_id, user.id
    )
    direct_scope = (
        [
            {"scope_type": "organization", "scope_id": value}
            for value in sorted(organization_ids)
        ]
        + [{"scope_type": "region", "scope_id": value} for value in sorted(region_ids)]
        + [{"scope_type": "area", "scope_id": value} for value in sorted(area_ids)]
        + [{"scope_type": "branch", "scope_id": value} for value in sorted(branch_ids)]
    )

    if user.role == "system":
        organization_ids = set(session.scalars(select(Region.organization_id)).all())
    if organization_ids:
        region_ids.update(
            session.scalars(
                select(Region.id).where(Region.organization_id.in_(organization_ids))
            ).all()
        )
    if region_ids:
        area_ids.update(
            session.scalars(select(Area.id).where(Area.region_id.in_(region_ids))).all()
        )
    if area_ids:
        branch_ids.update(
            session.scalars(select(Branch.id).where(Branch.area_id.in_(area_ids))).all()
        )

    all_organizations = user.role == "system" or bool(organization_ids)
    all_regions = user.role == "system"
    all_areas = user.role == "system"
    all_branches = user.role == "system"
    scope = {
        "organizations": sorted(organization_ids),
        "regions": sorted(region_ids),
        "areas": sorted(area_ids),
        "branches": sorted(branch_ids),
        "all_organizations": all_organizations,
        "all_regions": all_regions,
        "all_areas": all_areas,
        "all_branches": all_branches,
    }
    permissions = role_permissions(session, user.role)
    return {
        "user_id": user.id,
        "username": user.username,
        "display_name": user.display_name,
        "role": public_role(user.role),
        "account_type": account_type(user.role),
        "permissions": permissions,
        "capabilities": permissions,
        "direct_scope": direct_scope,
        "scope": scope,
        "active_branch": scope["branches"][0] if len(scope["branches"]) == 1 else "",
        "is_active": user.is_active,
        "must_change_password": user.must_change_password,
        "permission_source": "postgresql.role_permissions",
        "scope_source": "postgresql.user_scope_assignments",
        "authority_revision": user.authority_revision,
    }


def bump_authority_revision(session: Session, user: User) -> int:
    user.authority_revision += 1
    session.flush()
    return user.authority_revision


def require_permissions(session: Session, user: User, *required: str) -> None:
    granted = set(role_permissions(session, user.role))
    if user.must_change_password:
        raise PermissionError("password_change_required")
    if not all(permission in granted for permission in required):
        raise PermissionError("permission_denied")


def can_delegate(actor: User, target_role: str) -> bool:
    return target_role in DELEGATION.get(actor.role, set())


def scopes_are_within_actor(
    session: Session, actor: User, scopes: dict[str, list[str]]
) -> bool:
    if actor.role == "system":
        return True
    effective = authority_payload(session, actor)["scope"]
    return all(
        set(scopes.get(kind, [])) <= set(effective.get(kind, []))
        for kind in ("organizations", "regions", "areas", "branches")
    )


def visible_hierarchy(
    session: Session, actor: User
) -> dict[str, list[Organization | Region | Area | Branch]]:
    """Read the organization hierarchy through the actor's effective branch scope only."""
    scope = authority_payload(session, actor)["scope"]
    branch_statement = select(Branch).where(Branch.is_active.is_(True))
    if not scope["all_branches"]:
        branch_statement = branch_statement.where(Branch.id.in_(scope["branches"]))
    branches = list(session.scalars(branch_statement.order_by(Branch.id)).all())
    area_ids = {branch.area_id for branch in branches}
    areas = (
        list(
            session.scalars(
                select(Area).where(Area.id.in_(area_ids)).order_by(Area.id)
            ).all()
        )
        if area_ids
        else []
    )
    region_ids = {area.region_id for area in areas}
    regions = (
        list(
            session.scalars(
                select(Region).where(Region.id.in_(region_ids)).order_by(Region.id)
            ).all()
        )
        if region_ids
        else []
    )
    organization_ids = {region.organization_id for region in regions}
    organizations = (
        list(
            session.scalars(
                select(Organization)
                .where(Organization.id.in_(organization_ids))
                .order_by(Organization.id)
            ).all()
        )
        if organization_ids
        else []
    )
    return {
        "organizations": organizations,
        "regions": regions,
        "areas": areas,
        "branches": branches,
    }


def visible_managed_users_statement(session: Session, actor: User):
    """Build a SQL-only user visibility boundary for scoped administrators."""
    if actor.role == "system":
        return select(User)
    manageable_roles = DELEGATION.get(actor.role, set())
    if not manageable_roles:
        return select(User).where(false())
    effective = authority_payload(session, actor)["scope"]
    scope_models = (
        (
            UserOrganizationScope,
            UserOrganizationScope.organization_id,
            effective["organizations"],
        ),
        (UserRegionScope, UserRegionScope.region_id, effective["regions"]),
        (UserAreaScope, UserAreaScope.area_id, effective["areas"]),
        (UserBranchScope, UserBranchScope.branch_id, effective["branches"]),
    )
    overlap_conditions = []
    containment_conditions = []
    for model, column, allowed_ids in scope_models:
        if allowed_ids:
            overlap_conditions.append(
                exists(
                    select(model.id).where(
                        and_(model.user_id == User.id, column.in_(allowed_ids))
                    )
                )
            )
            containment_conditions.append(
                not_(
                    exists(
                        select(model.id).where(
                            and_(model.user_id == User.id, column.not_in(allowed_ids))
                        )
                    )
                )
            )
        else:
            containment_conditions.append(
                not_(exists(select(model.id).where(model.user_id == User.id)))
            )
    return select(User).where(
        User.role.in_(manageable_roles),
        or_(*overlap_conditions) if overlap_conditions else false(),
        *containment_conditions,
    )
