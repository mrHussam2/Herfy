from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from app.models.entities import (
    Area,
    Branch,
    Organization,
    Region,
    StoredProduct,
    SyncChange,
    UsageProduct,
    User,
)
from app.services.authorization import (
    authority_payload,
    role_permissions,
    visible_hierarchy,
)
from app.services.tracking import tracking_payload, visible_tracking_items


def _time() -> str:
    return datetime.now(timezone.utc).isoformat()


def _change_payload(change: SyncChange) -> dict:
    return {
        "event_id": change.event_id,
        "cursor": change.event_id,
        "entity_type": change.entity_type,
        "entity_id": change.entity_id,
        "operation": change.operation,
        "revision": change.revision,
        "server_timestamp": change.server_timestamp.astimezone(
            timezone.utc
        ).isoformat(),
        "scope": {"type": change.scope_type, "id": change.scope_id},
        "payload": change.payload,
    }


def full_snapshot(
    session: Session, actor: User, *, from_cursor: int, recovery_reason: str
) -> dict:
    cursor = int(session.scalar(select(func.max(SyncChange.event_id))) or 0)
    hierarchy = visible_hierarchy(session, actor)
    return {
        "mode": "full",
        "recovery_reason": recovery_reason,
        "min_retained_cursor": 0,
        "tracking_items": [
            tracking_payload(item)
            for item in visible_tracking_items(session, actor, include_deleted=True)
        ],
        "stored_products": [
            {"material_number": row.material_number, "name": row.name}
            for row in session.scalars(
                select(StoredProduct).where(StoredProduct.is_active.is_(True))
            ).all()
        ],
        "usage_products": [
            {"material_number": row.material_number, "name": row.name, "uom": row.uom}
            for row in session.scalars(
                select(UsageProduct).where(UsageProduct.is_active.is_(True))
            ).all()
        ],
        "organizations": [
            {"id": row.id, "name": row.name} for row in hierarchy["organizations"]
        ],
        "regions": [
            {
                "id": row.id,
                "code": row.code,
                "name": row.name,
                "organization_id": row.organization_id,
            }
            for row in hierarchy["regions"]
        ],
        "areas": [
            {
                "id": row.id,
                "code": row.code,
                "name": row.name,
                "region_id": row.region_id,
            }
            for row in hierarchy["areas"]
        ],
        "branches": [
            {"id": row.id, "code": row.code, "name": row.name, "area_id": row.area_id}
            for row in hierarchy["branches"]
        ],
        "authority_revision": actor.authority_revision,
        "authority": authority_payload(session, actor),
        "changes": [],
        "next_cursor": cursor,
        "high_watermark": cursor,
        "has_more": False,
        "server_time": _time(),
        "from_cursor": from_cursor,
    }


def incremental_changes(
    session: Session, actor: User, *, from_cursor: int, limit: int
) -> dict:
    scope = authority_payload(session, actor)["scope"]
    statement = select(SyncChange).where(SyncChange.event_id > from_cursor)
    if not scope["all_branches"]:
        permissions = set(role_permissions(session, actor.role))
        catalog_entity_types = []
        if "catalog.view" in permissions:
            catalog_entity_types.append("stored_product")
        if "usage.view" in permissions:
            catalog_entity_types.append("usage_product")
        visible_conditions = [
            and_(
                SyncChange.scope_type == "branch",
                SyncChange.scope_id.in_(scope["branches"]),
            )
        ]
        if catalog_entity_types:
            visible_conditions.append(SyncChange.entity_type.in_(catalog_entity_types))
        # Only allow a content-free invalidation event to reach scoped actors
        # who can read some administration projection. Never expose the global
        # structure event payloads (which may reference out-of-scope branches).
        admin_read_permissions = {
            "users.view", "organizations.view", "regions.view", "areas.view",
            "branches.view", "permissions.view", "roles.view", "audit.view",
        }
        if permissions.intersection(admin_read_permissions):
            visible_conditions.append(SyncChange.entity_type == "administration")
        statement = statement.where(or_(*visible_conditions))
    changes = list(
        session.scalars(statement.order_by(SyncChange.event_id).limit(limit + 1)).all()
    )
    has_more = len(changes) > limit
    changes = changes[:limit]
    high_watermark = int(session.scalar(select(func.max(SyncChange.event_id))) or 0)
    # The SSE stream carries a global high-watermark.  A scoped user may have
    # no visible rows after that cursor; retaining ``from_cursor`` in that case
    # made every keepalive rediscover the same unrelated change forever.  It
    # consumed a worker on each client and looked like a stalled live refresh.
    # Advancing to the already-disclosed high-watermark is safe (the stream
    # itself exposes it) and lets the next authorized change wake the client.
    next_cursor = changes[-1].event_id if changes else high_watermark
    return {
        "mode": "incremental",
        "changes": [_change_payload(change) for change in changes],
        "next_cursor": next_cursor,
        "has_more": has_more,
        "min_retained_cursor": 0,
        "authority_revision": actor.authority_revision,
        "authority": authority_payload(session, actor),
        "server_time": _time(),
        "from_cursor": from_cursor,
        "high_watermark": high_watermark,
    }
