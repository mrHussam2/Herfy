from __future__ import annotations

from sqlalchemy import delete
from sqlalchemy.orm import Session

from app.models.entities import (
    User,
    UserAreaScope,
    UserBranchScope,
    UserOrganizationScope,
    UserRegionScope,
)
from app.services.authorization import bump_authority_revision


def _normalized(values: list[str] | None) -> list[str]:
    return sorted({value.strip() for value in values or [] if value and value.strip()})


def replace_direct_scopes(
    session: Session,
    user: User,
    *,
    organizations: list[str] | None = None,
    regions: list[str] | None = None,
    areas: list[str] | None = None,
    branches: list[str] | None = None,
) -> None:
    """Replace all direct scope assignments through the sole scope owner."""
    for model in (
        UserOrganizationScope,
        UserRegionScope,
        UserAreaScope,
        UserBranchScope,
    ):
        session.execute(delete(model).where(model.user_id == user.id))
    session.add_all(
        [
            UserOrganizationScope(user_id=user.id, organization_id=value)
            for value in _normalized(organizations)
        ]
        + [
            UserRegionScope(user_id=user.id, region_id=value)
            for value in _normalized(regions)
        ]
        + [
            UserAreaScope(user_id=user.id, area_id=value)
            for value in _normalized(areas)
        ]
        + [
            UserBranchScope(user_id=user.id, branch_id=value)
            for value in _normalized(branches)
        ]
    )
    bump_authority_revision(session, user)
