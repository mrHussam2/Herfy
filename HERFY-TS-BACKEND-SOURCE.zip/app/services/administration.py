from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.core.errors import ApiError
from app.core.config import settings
from app.core.security import hash_password
from app.models.entities import (
    Area,
    Branch,
    Organization,
    Region,
    RolePermission,
    RolePolicy,
    StoredProduct,
    SyncChange,
    UsageProduct,
    User,
)
from app.services.audit import record_audit
from app.services.authorization import ALL_PERMISSIONS, bump_authority_revision
from app.services.catalogs import create_stored_product, create_usage_product
from app.services.password_policy import validate_password
from app.services.scopes import replace_direct_scopes
from app.services.users import ROLES, create_user


def _global_change(
    session: Session,
    *,
    entity_type: str,
    entity_id: str,
    operation: str,
    revision: int,
    payload: dict,
) -> None:
    session.add(
        SyncChange(
            entity_type=entity_type,
            entity_id=entity_id,
            operation=operation,
            revision=revision,
            scope_type="global",
            scope_id="catalog" if "product" in entity_type else "structure",
            payload=payload,
        )
    )


def structure_payload(entity: Organization | Region | Area | Branch) -> dict:
    if isinstance(entity, Organization):
        return {
            "organization_id": entity.id,
            "name": entity.name,
            "is_active": entity.is_active,
            "revision": entity.revision,
        }
    if isinstance(entity, Region):
        return {
            "region_id": entity.id,
            "organization_id": entity.organization_id,
            "name": entity.name,
            "is_active": entity.is_active,
            "revision": entity.revision,
        }
    if isinstance(entity, Area):
        return {
            "area_id": entity.id,
            "region_id": entity.region_id,
            "name": entity.name,
            "is_active": entity.is_active,
            "revision": entity.revision,
        }
    return {
        "branch_id": entity.id,
        "area_id": entity.area_id,
        "name": entity.name,
        "is_active": entity.is_active,
        "revision": entity.revision,
    }


def product_payload(entity: StoredProduct | UsageProduct) -> dict:
    return {
        "material_number": entity.material_number,
        "name": entity.name,
        "category": entity.category,
        "shelf_life_days": entity.shelf_life_days,
        "uom": entity.uom,
        "is_active": entity.is_active,
        "revision": entity.revision,
    }


def _expect_revision(current: int, supplied: object, *, code: str) -> None:
    try:
        expected = int(supplied)
    except (TypeError, ValueError) as exc:
        raise ApiError(
            422, "base_revision_required", "A valid base revision is required."
        ) from exc
    if expected != current:
        raise ApiError(409, code, "The resource has changed; reload and retry.")


def create_region(session: Session, actor: User, payload: dict) -> Region:
    region_id = str(payload.get("region_id") or "").strip()
    name = str(payload.get("name") or "").strip()
    organization_id = str(payload.get("organization_id") or "HERFY").strip()
    if not region_id or not name or session.get(Organization, organization_id) is None:
        raise ApiError(
            422, "invalid_region", "A valid region and organization are required."
        )
    region = Region(
        id=region_id,
        code=str(payload.get("code") or region_id).strip(),
        name=name,
        organization_id=organization_id,
    )
    session.add(region)
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action="region_create",
        entity_type="region",
        entity_id=region.id,
    )
    _global_change(
        session,
        entity_type="region",
        entity_id=region.id,
        operation="create",
        revision=region.revision,
        payload=structure_payload(region),
    )
    return region


def create_area(session: Session, actor: User, payload: dict) -> Area:
    area_id = str(payload.get("area_id") or "").strip()
    name = str(payload.get("name") or "").strip()
    region_id = str(payload.get("region_id") or "").strip()
    if not area_id or not name or session.get(Region, region_id) is None:
        raise ApiError(422, "invalid_area", "A valid area and region are required.")
    area = Area(
        id=area_id,
        code=str(payload.get("code") or area_id).strip(),
        name=name,
        region_id=region_id,
    )
    session.add(area)
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action="area_create",
        entity_type="area",
        entity_id=area.id,
    )
    _global_change(
        session,
        entity_type="area",
        entity_id=area.id,
        operation="create",
        revision=area.revision,
        payload=structure_payload(area),
    )
    return area


def create_branch(session: Session, actor: User, payload: dict) -> Branch:
    branch_id = str(payload.get("branch_id") or "").strip()
    name = str(payload.get("name") or "").strip()
    area_id = str(payload.get("area_id") or "").strip()
    if not branch_id or not name or session.get(Area, area_id) is None:
        raise ApiError(422, "invalid_branch", "A valid branch and area are required.")
    branch = Branch(
        id=branch_id,
        code=str(payload.get("code") or branch_id).strip(),
        name=name,
        area_id=area_id,
    )
    session.add(branch)
    session.flush()
    store_password = settings.store_account_initial_password
    if not store_password:
        raise ApiError(
            500,
            "store_account_password_missing",
            "Branch account provisioning is unavailable.",
        )
    try:
        validate_password(store_password)
    except ValueError:
        force_password_change = True
    else:
        force_password_change = settings.store_account_force_change
    store_account = create_user(
        session,
        username=branch.code,
        display_name=f"Store account {branch.code}",
        role="store_account",
        password=store_password,
        must_change_password=force_password_change,
    )
    replace_direct_scopes(session, store_account, branches=[branch.id])
    record_audit(
        session,
        actor_id=actor.id,
        action="branch_create",
        entity_type="branch",
        entity_id=branch.id,
    )
    record_audit(
        session,
        actor_id=actor.id,
        action="store_account_create",
        entity_type="user",
        entity_id=store_account.id,
    )
    _global_change(
        session,
        entity_type="branch",
        entity_id=branch.id,
        operation="create",
        revision=branch.revision,
        payload=structure_payload(branch),
    )
    return branch


def update_structure(
    session: Session,
    actor: User,
    entity: Region | Area | Branch,
    payload: dict,
    entity_type: str,
) -> dict:
    _expect_revision(
        entity.revision, payload.get("base_revision"), code="revision_conflict"
    )
    if "name" in payload:
        name = str(payload["name"] or "").strip()
        if not name:
            raise ApiError(422, "invalid_name", "A name is required.")
        entity.name = name
    if "is_active" in payload:
        entity.is_active = bool(payload["is_active"])
    entity.revision += 1
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action=f"{entity_type}_update",
        entity_type=entity_type,
        entity_id=entity.id,
    )
    result = structure_payload(entity)
    _global_change(
        session,
        entity_type=entity_type,
        entity_id=entity.id,
        operation="update",
        revision=entity.revision,
        payload=result,
    )
    return result


def remove_structure(
    session: Session, actor: User, entity: Region | Area | Branch, entity_type: str
) -> dict:
    entity.is_active = False
    entity.revision += 1
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action=f"{entity_type}_disable",
        entity_type=entity_type,
        entity_id=entity.id,
    )
    result = structure_payload(entity)
    _global_change(
        session,
        entity_type=entity_type,
        entity_id=entity.id,
        operation="status_change",
        revision=entity.revision,
        payload=result,
    )
    return {"disabled": True, **result}


def transfer_branch(
    session: Session,
    actor: User,
    branch: Branch,
    *,
    area_id: str,
    base_revision: object,
) -> dict:
    _expect_revision(branch.revision, base_revision, code="revision_conflict")
    if session.get(Area, area_id) is None:
        raise ApiError(422, "invalid_area", "The destination area does not exist.")
    branch.area_id = area_id
    branch.revision += 1
    session.flush()
    record_audit(
        session,
        actor_id=actor.id,
        action="branch_transfer",
        entity_type="branch",
        entity_id=branch.id,
    )
    result = structure_payload(branch)
    _global_change(
        session,
        entity_type="branch",
        entity_id=branch.id,
        operation="update",
        revision=branch.revision,
        payload=result,
    )
    return result


def create_catalog_product(
    session: Session, actor: User, *, kind: str, payload: dict
) -> dict:
    common = {
        "material_number": str(payload.get("material_number") or ""),
        "name": str(payload.get("name") or ""),
        "category": str(payload.get("category") or ""),
        "shelf_life_days": payload.get("shelf_life_days"),
        "uom": payload.get("uom"),
    }
    if not common["name"].strip():
        raise ApiError(422, "invalid_product", "A product name is required.")
    try:
        entity = (
            create_stored_product(session, **common)
            if kind == "stored"
            else create_usage_product(session, **common)
        )
        session.flush()
    except ValueError as exc:
        raise ApiError(
            422, "invalid_product", "A valid unique material number is required."
        ) from exc
    entity_type = f"{kind}_product"
    record_audit(
        session,
        actor_id=actor.id,
        action=f"{kind}_product_create",
        entity_type=entity_type,
        entity_id=entity.material_number,
    )
    result = product_payload(entity)
    _global_change(
        session,
        entity_type=entity_type,
        entity_id=entity.material_number,
        operation="create",
        revision=entity.revision,
        payload=result,
    )
    return result


def update_catalog_product(
    session: Session,
    actor: User,
    entity: StoredProduct | UsageProduct,
    *,
    kind: str,
    payload: dict,
) -> dict:
    _expect_revision(
        entity.revision, payload.get("base_revision"), code="revision_conflict"
    )
    for field in ("name", "category", "shelf_life_days", "uom", "is_active"):
        if field in payload:
            value = payload[field]
            if field in {"name", "category", "uom"} and value is not None:
                value = str(value).strip()
            setattr(entity, field, value)
    if not entity.name:
        raise ApiError(422, "invalid_product", "A product name is required.")
    entity.revision += 1
    session.flush()
    entity_type = f"{kind}_product"
    record_audit(
        session,
        actor_id=actor.id,
        action=f"{kind}_product_update",
        entity_type=entity_type,
        entity_id=entity.material_number,
    )
    result = product_payload(entity)
    _global_change(
        session,
        entity_type=entity_type,
        entity_id=entity.material_number,
        operation="update",
        revision=entity.revision,
        payload=result,
    )
    return result


def remove_catalog_product(
    session: Session,
    actor: User,
    entity: StoredProduct | UsageProduct,
    *,
    kind: str,
    base_revision: object,
) -> dict:
    _expect_revision(entity.revision, base_revision, code="revision_conflict")
    entity.is_active = False
    entity.revision += 1
    session.flush()
    entity_type = f"{kind}_product"
    record_audit(
        session,
        actor_id=actor.id,
        action=f"{kind}_product_disable",
        entity_type=entity_type,
        entity_id=entity.material_number,
    )
    result = product_payload(entity)
    _global_change(
        session,
        entity_type=entity_type,
        entity_id=entity.material_number,
        operation="delete",
        revision=entity.revision,
        payload=result,
    )
    return {"disabled": True, **result}


def replace_role_permissions(
    session: Session,
    actor: User,
    *,
    role: str,
    base_revision: object,
    permissions: list[str],
) -> dict:
    if role not in ROLES or role == "system":
        raise ApiError(422, "invalid_role", "The requested role cannot be changed.")
    policy = session.get(RolePolicy, role)
    if policy is None:
        policy = RolePolicy(role=role, revision=1)
        session.add(policy)
        session.flush()
    _expect_revision(policy.revision, base_revision, code="role_revision_conflict")
    normalized = sorted(
        {str(value).strip() for value in permissions if str(value).strip()}
    )
    if any(value not in ALL_PERMISSIONS for value in normalized):
        raise ApiError(
            422, "invalid_permission", "One or more permissions are not recognized."
        )
    session.execute(delete(RolePermission).where(RolePermission.role == role))
    session.add_all(
        [RolePermission(role=role, permission=value) for value in normalized]
    )
    policy.revision += 1
    record_audit(
        session,
        actor_id=actor.id,
        action="role_permissions_replace",
        entity_type="role",
        entity_id=role,
    )
    _global_change(
        session,
        entity_type="authorization",
        entity_id=role,
        operation="permission_change",
        revision=policy.revision,
        payload={"role": role, "permissions": normalized, "revision": policy.revision},
    )
    return {"role": role, "permissions": normalized, "revision": policy.revision}


def audit_payloads(session: Session, *, limit: int) -> list[dict]:
    from app.models.entities import AuditLog

    rows = session.scalars(
        select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)
    ).all()
    return [
        {
            "id": row.id,
            "actor_id": row.actor_id,
            "action": row.action,
            "entity_type": row.entity_type,
            "entity_id": row.entity_id,
            "details": row.details,
            "created_at": row.created_at.astimezone(timezone.utc).isoformat(),
        }
        for row in rows
    ]
