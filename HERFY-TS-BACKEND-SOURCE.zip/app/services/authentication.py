from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.errors import ApiError
from app.core.security import decode_token, hash_password, issue_token, verify_password
from app.models.entities import SessionRevocation, User
from app.services.authorization import authority_payload
from app.services.authorization import bump_authority_revision
from app.services.password_policy import validate_password


def authenticate(session: Session, *, username: str, password: str) -> User:
    user = session.scalar(select(User).where(User.username == username.strip()))
    now = datetime.now(timezone.utc)
    if user is not None and user.locked_until is not None:
        locked_until = user.locked_until
        if locked_until.tzinfo is None:
            locked_until = locked_until.replace(tzinfo=timezone.utc)
        if locked_until > now:
            raise ApiError(
                429,
                "account_locked",
                "Too many failed sign-in attempts. Try again later.",
            )
    if user is None or not verify_password(password, user.password_hash):
        if user is not None:
            user.failed_login_attempts += 1
            if user.failed_login_attempts >= settings.login_failure_limit:
                user.locked_until = now + timedelta(seconds=settings.login_lock_seconds)
            session.flush()
        raise ApiError(401, "invalid_credentials", "Invalid credentials.")
    if not user.is_active:
        raise ApiError(403, "account_inactive", "This account is inactive.")
    if user.failed_login_attempts or user.locked_until is not None:
        user.failed_login_attempts = 0
        user.locked_until = None
        session.flush()
    return user


def token_response(session: Session, user: User) -> dict:
    return {
        "access_token": issue_token(
            user_id=user.id,
            authority_revision=user.authority_revision,
            token_type="access",
            lifetime_seconds=settings.access_token_seconds,
        ),
        "refresh_token": issue_token(
            user_id=user.id,
            authority_revision=user.authority_revision,
            token_type="refresh",
            lifetime_seconds=settings.refresh_token_seconds,
        ),
        "token_type": "bearer",
        "expires_in": settings.access_token_seconds,
        "user": authority_payload(session, user),
    }


def current_user(session: Session, token: str, *, token_type: str = "access") -> User:
    try:
        claims = decode_token(token)
    except ValueError as exc:
        raise ApiError(401, "invalid_token", "Invalid session token.") from exc
    if claims.get("typ") != token_type:
        raise ApiError(401, "invalid_token", "Invalid session token.")
    token_id = str(claims.get("jti") or "")
    if not token_id or session.get(SessionRevocation, token_id) is not None:
        raise ApiError(401, "session_revoked", "This session has been revoked.")
    user = session.get(User, str(claims.get("sub") or ""))
    if user is None or not user.is_active:
        raise ApiError(401, "session_invalid", "This session is no longer valid.")
    if int(claims.get("ar") or 0) != user.authority_revision:
        raise ApiError(401, "session_stale", "This session is no longer valid.")
    return user


def revoke_token(session: Session, token: str) -> None:
    claims = decode_token(token)
    expires_at = datetime.fromtimestamp(int(claims["exp"]), tz=timezone.utc)
    session.merge(
        SessionRevocation(
            token_id=str(claims["jti"]),
            user_id=str(claims["sub"]),
            expires_at=expires_at,
        )
    )


def change_password(
    session: Session,
    user: User,
    *,
    current_password: str | None,
    new_password: str,
) -> None:
    # A first-login user is already authenticated by a restricted server
    # session, so the temporary password is not entered a second time. Any
    # later self-service change must still prove the current password.
    if not user.must_change_password and (
        not current_password
        or not verify_password(current_password, user.password_hash)
    ):
        raise ApiError(401, "invalid_credentials", "Invalid credentials.")
    try:
        validate_password(new_password)
    except ValueError as exc:
        raise ApiError(
            422,
            "password_policy",
            "The new password does not meet the password policy.",
        ) from exc
    user.password_hash = hash_password(new_password)
    user.must_change_password = False
    bump_authority_revision(session, user)
