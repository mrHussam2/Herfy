from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.request_context import current_request_id
from app.models.entities import AuditLog, SyncChange


def record_audit(
    session: Session,
    *,
    actor_id: str | None,
    action: str,
    entity_type: str,
    entity_id: str,
    details: dict | None = None,
) -> AuditLog:
    record = AuditLog(
        actor_id=actor_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        request_id=current_request_id(),
        details=details or {},
    )
    session.add(record)
    # An administrative write must invalidate other clients' administration
    # projections, even if the edited user's *own* revision did not change.
    # Use a content-free hint: neither user IDs nor password/role data is
    # broadcast. Each authorized client re-reads its own scoped projection.
    if action in {
        "user_create", "user_update", "user_disable", "user_scope_replace",
        "user_password_reset", "password_change", "store_account_create",
        "role_permissions_replace", "region_create", "area_create",
        "branch_create", "branch_transfer", "region_update", "area_update",
        "branch_update", "region_disable", "area_disable", "branch_disable",
        "region_delete", "area_delete", "branch_delete",
    } or (entity_type in {"organization", "region", "area", "branch"} and action != "read"):
        session.add(
            SyncChange(
                entity_type="administration",
                entity_id="projection",
                operation="invalidate",
                revision=1,
                scope_type="global",
                scope_id="administration",
                payload={"domain": "administration"},
            )
        )
    return record
