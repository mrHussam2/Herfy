from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.models.entities import User


ROLES = {
    "system",
    "operations_director",
    "operations_manager",
    "operations_consultant",
    "store_manager",
    "store_account",
}

# The database owns one branch-account role.  The released desktop contract
# calls that role "store", so translation happens only at the API boundary.
_INTERNAL_ROLE_BY_INPUT = {"store": "store_account"}
_PUBLIC_ROLE_BY_INTERNAL = {"store_account": "store"}


def normalize_role(role: str) -> str:
    return _INTERNAL_ROLE_BY_INPUT.get(role.strip().lower(), role.strip().lower())


def public_role(role: str) -> str:
    return _PUBLIC_ROLE_BY_INTERNAL.get(role, role)


def account_type(role: str) -> str:
    return "branch" if role == "store_account" else "employee"


def create_user(
    session: Session,
    *,
    username: str,
    display_name: str,
    role: str,
    password: str,
    must_change_password: bool = False,
    is_active: bool = True,
) -> User:
    normalized_role = normalize_role(role)
    if normalized_role not in ROLES:
        raise ValueError("invalid_role")
    normalized_username = username.strip()
    if not normalized_username or session.scalar(
        select(User.id).where(User.username == normalized_username)
    ):
        raise ValueError("username_unavailable")
    user = User(
        username=normalized_username,
        display_name=display_name.strip(),
        role=normalized_role,
        password_hash=hash_password(password),
        must_change_password=must_change_password,
        is_active=is_active,
    )
    session.add(user)
    session.flush()
    return user
