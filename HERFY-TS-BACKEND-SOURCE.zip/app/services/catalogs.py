from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.entities import StoredProduct, UsageProduct


def _material_number(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError("material_number_required")
    return normalized


def create_stored_product(
    session: Session,
    *,
    material_number: str,
    name: str,
    category: str = "",
    shelf_life_days: int | None = None,
    uom: str | None = None,
) -> StoredProduct:
    product = StoredProduct(
        material_number=_material_number(material_number),
        name=name.strip(),
        category=category.strip(),
        shelf_life_days=shelf_life_days,
        uom=uom.strip() if uom and uom.strip() else None,
    )
    session.add(product)
    return product


def create_usage_product(
    session: Session,
    *,
    material_number: str,
    name: str,
    uom: str | None,
    category: str = "",
    shelf_life_days: int | None = None,
) -> UsageProduct:
    product = UsageProduct(
        material_number=_material_number(material_number),
        name=name.strip(),
        category=category.strip(),
        shelf_life_days=shelf_life_days,
        uom=uom.strip() if uom and uom.strip() else None,
    )
    session.add(product)
    return product
