"""Database session ownership."""
