from __future__ import annotations

from sqlalchemy import create_engine, event, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy.pool import StaticPool

from app.core.config import settings


engine_options = {
    "pool_pre_ping": True,
    "pool_size": settings.database_pool_size,
    "max_overflow": settings.database_max_overflow,
    "pool_timeout": settings.database_pool_timeout_seconds,
}
if settings.database_url.endswith(":memory:"):
    engine_options.update(
        {"connect_args": {"check_same_thread": False}, "poolclass": StaticPool}
    )
    for option in ("pool_size", "max_overflow", "pool_timeout"):
        engine_options.pop(option)
engine = create_engine(settings.database_url, **engine_options)
SessionLocal = sessionmaker(
    bind=engine, autocommit=False, autoflush=False, class_=Session
)


if settings.database_url.startswith("sqlite"):

    @event.listens_for(engine, "connect")
    def enable_sqlite_foreign_keys(dbapi_connection, _) -> None:
        dbapi_connection.execute("PRAGMA foreign_keys=ON")


def database_is_ready() -> bool:
    """Probe database and, in production, the required migration revision."""
    try:
        with engine.connect() as connection:
            connection.execute(text("SELECT 1"))
            if settings.environment == "production":
                revision = connection.scalar(
                    text("SELECT version_num FROM alembic_version")
                )
                if revision != settings.migration_revision:
                    return False
    except SQLAlchemyError:
        return False
    return True
