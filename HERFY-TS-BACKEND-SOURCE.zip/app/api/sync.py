from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_session, require_user
from app.core.errors import ApiError
from app.models.entities import SyncOperation, User
from app.services.sync import full_snapshot, incremental_changes
from app.services.tracking import (
    create_tracking_item,
    delete_tracking_item,
    tracking_payload,
    update_tracking_item,
)


router = APIRouter(prefix="/api", tags=["sync"])


class TrackingMutation(BaseModel):
    operation: str = Field(pattern="^(create|update|delete)$")
    item: dict


class SyncPushRequest(BaseModel):
    operation_id: str = Field(min_length=1, max_length=128)
    device_id: str = Field(min_length=1, max_length=128)
    operations: list[TrackingMutation] = Field(min_length=1)


@router.post("/sync/push")
def push(
    payload: SyncPushRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    prior = session.scalar(
        select(SyncOperation).where(
            SyncOperation.user_id == actor.id,
            SyncOperation.device_id == payload.device_id,
            SyncOperation.operation_id == payload.operation_id,
        )
    )
    if prior is not None:
        return prior.response
    accepted = []
    try:
        for mutation in payload.operations:
            if mutation.operation == "create":
                item, change = create_tracking_item(session, actor, mutation.item)
            elif mutation.operation == "update":
                item, change = update_tracking_item(session, actor, mutation.item)
            else:
                item, change = delete_tracking_item(session, actor, mutation.item)
            accepted.append(
                {"operation": mutation.operation, "item": tracking_payload(item)}
            )
        result = {
            "ok": True,
            "operation_id": payload.operation_id,
            "accepted": accepted,
            "conflicts": [],
            "rejected": [],
            "server_cursor": change.event_id,
            "server_time": datetime.now(timezone.utc).isoformat(),
        }
        session.add(
            SyncOperation(
                user_id=actor.id,
                device_id=payload.device_id,
                operation_id=payload.operation_id,
                response=result,
            )
        )
        session.commit()
        return result
    except Exception:
        session.rollback()
        raise


@router.get("/sync/pull")
def pull(
    from_cursor: int = Query(default=0, ge=0),
    authority_revision: int = Query(default=0, ge=0),
    limit: int = Query(default=200, ge=1, le=500),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    if from_cursor == 0 or authority_revision != actor.authority_revision:
        return full_snapshot(
            session,
            actor,
            from_cursor=from_cursor,
            recovery_reason="initial" if from_cursor == 0 else "authority_changed",
        )
    return incremental_changes(session, actor, from_cursor=from_cursor, limit=limit)
