from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
import re

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_session, require_user
from app.core.config import settings
from app.core.errors import ApiError
from app.models.entities import (
    Area,
    Branch,
    Organization,
    Region,
    StoredProduct,
    UsageProduct,
    User,
)
from app.services.authorization import authority_payload


router = APIRouter(prefix="/api/meta", tags=["meta"])

_SEMANTIC_VERSION = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


def client_version_is_supported(client_version: str, minimum_version: str) -> bool:
    """Accept a semantic client version at or above the configured floor.

    The configured value is a minimum compatibility policy, not a single
    pinned build. Invalid values fail closed so malformed client headers cannot
    bypass the server's compatibility boundary.
    """
    client_match = _SEMANTIC_VERSION.fullmatch(str(client_version or "").strip())
    minimum_match = _SEMANTIC_VERSION.fullmatch(str(minimum_version or "").strip())
    if client_match is None or minimum_match is None:
        return False
    client = tuple(int(part) for part in client_match.groups())
    minimum = tuple(int(part) for part in minimum_match.groups())
    return client >= minimum


def published_client_version() -> str:
    """Read the atomically published client identity independently of the API build."""
    try:
        manifest = json.loads(
            Path("/opt/server/updates/updates/manifest").read_text(encoding="utf-8")
        )
        if not isinstance(manifest, dict):
            return settings.server_version
        candidate = manifest.get("version")
        if (
            isinstance(candidate, str)
            and _SEMANTIC_VERSION.fullmatch(candidate)
            and manifest.get("contract_sha256") == settings.api_contract_sha256
            and client_version_is_supported(candidate, settings.minimum_client_version)
        ):
            return candidate
    except (OSError, ValueError):
        pass
    return settings.server_version


@router.get("/version")
def version() -> dict[str, str]:
    """Return the public release identity and update compatibility policy."""
    return {
        "server_version": settings.server_version,
        "api_contract_sha256": settings.api_contract_sha256,
        "minimum_supported_client_version": settings.minimum_client_version,
        "latest_client_version": published_client_version(),
    }


def _current_user_scope(session: Session, user: User) -> dict:
    if user.must_change_password:
        raise ApiError(
            403,
            "password_change_required",
            "A password change is required before continuing.",
        )
    return authority_payload(session, user)["scope"]


def _visible_branches(session: Session, user: User) -> list[tuple[Branch, Area]]:
    scope = _current_user_scope(session, user)
    statement = (
        select(Branch, Area)
        .join(Area, Branch.area_id == Area.id)
        .where(Branch.is_active.is_(True))
    )
    if not scope["all_branches"]:
        statement = statement.where(Branch.id.in_(scope["branches"]))
    return list(session.execute(statement.order_by(Branch.id)).all())


def _product_payload(product: StoredProduct | UsageProduct) -> dict:
    return {
        "material_number": product.material_number,
        "name": product.name,
        "category": product.category,
        "shelf_life_days": product.shelf_life_days,
        "uom": product.uom,
        "is_active": product.is_active,
        "revision": product.revision,
    }


@router.get("/branches")
def branches(
    user: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    return {
        "items": [
            {
                "branch_id": branch.id,
                "region_id": area.region_id,
                "area_id": branch.area_id,
                "name": branch.name,
                "is_active": branch.is_active,
                "revision": branch.revision,
            }
            for branch, area in _visible_branches(session, user)
        ]
    }


@router.get("/client-bootstrap")
def client_bootstrap(
    client_version: str = Query(min_length=1, max_length=64),
    user: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    if not client_version_is_supported(client_version, settings.minimum_client_version):
        raise ApiError(
            426, "client_upgrade_required", "This client version is not supported."
        )
    branch_rows = _visible_branches(session, user)
    branch_ids = {branch.id for branch, _ in branch_rows}
    area_ids = {branch.area_id for branch, _ in branch_rows}
    region_ids = {area.region_id for _, area in branch_rows}
    regions = (
        session.scalars(
            select(Region).where(Region.id.in_(region_ids)).order_by(Region.id)
        ).all()
        if region_ids
        else []
    )
    organization_ids = {region.organization_id for region in regions}
    areas = (
        session.scalars(
            select(Area).where(Area.id.in_(area_ids)).order_by(Area.id)
        ).all()
        if area_ids
        else []
    )
    organizations = (
        session.scalars(
            select(Organization)
            .where(Organization.id.in_(organization_ids))
            .order_by(Organization.id)
        ).all()
        if organization_ids
        else []
    )
    stored = session.scalars(
        select(StoredProduct)
        .where(StoredProduct.is_active.is_(True))
        .order_by(StoredProduct.material_number)
    ).all()
    usage = session.scalars(
        select(UsageProduct)
        .where(UsageProduct.is_active.is_(True))
        .order_by(UsageProduct.material_number)
    ).all()
    return {
        "contract_version": settings.contract_version,
        "server_version": settings.server_version,
        "minimum_client_version": settings.minimum_client_version,
        "server_time": datetime.now(timezone.utc).isoformat(),
        "authority_revision": user.authority_revision,
        "organizations": [
            {
                "organization_id": row.id,
                "name": row.name,
                "is_active": row.is_active,
                "revision": row.revision,
            }
            for row in organizations
        ],
        "regions": [
            {
                "region_id": row.id,
                "organization_id": row.organization_id,
                "name": row.name,
                "is_active": row.is_active,
                "revision": row.revision,
            }
            for row in regions
        ],
        "areas": [
            {
                "area_id": row.id,
                "region_id": row.region_id,
                "name": row.name,
                "is_active": row.is_active,
                "revision": row.revision,
            }
            for row in areas
        ],
        "branches": [
            {
                "branch_id": branch.id,
                "area_id": branch.area_id,
                "name": branch.name,
                "is_active": branch.is_active,
                "revision": branch.revision,
            }
            for branch, _ in branch_rows
        ],
        "stored_products": [_product_payload(row) for row in stored],
        "usage_products": [_product_payload(row) for row in usage],
        "authority": authority_payload(session, user),
    }
