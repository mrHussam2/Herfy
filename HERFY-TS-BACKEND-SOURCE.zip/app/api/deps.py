from __future__ import annotations

from collections.abc import Generator

from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.errors import ApiError
from app.db.session import SessionLocal
from app.models.entities import User
from app.services.authentication import current_user


bearer = HTTPBearer(auto_error=False)
BOOTSTRAP_ONLY_PATHS = {
    "/api/auth/authority",
    "/api/auth/password-policy",
    "/api/auth/change-password",
    "/api/auth/logout",
}


def get_session() -> Generator[Session, None, None]:
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()


def require_user(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
    session: Session = Depends(get_session),
) -> User:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise ApiError(401, "authentication_required", "Authentication is required.")
    user = current_user(session, credentials.credentials)
    if user.must_change_password and request.url.path not in BOOTSTRAP_ONLY_PATHS:
        raise ApiError(
            403,
            "password_change_required",
            "A password change is required before continuing.",
        )
    return user
