from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class ContractModel(BaseModel):
    """One strict Pydantic boundary for the released desktop contract."""

    model_config = ConfigDict(extra="forbid")


class ScopeAssignment(ContractModel):
    scope_type: Literal["organization", "region", "area", "branch"]
    scope_id: str = Field(min_length=1, max_length=64)


class Scope(ContractModel):
    organizations: list[str]
    regions: list[str]
    areas: list[str]
    branches: list[str]
    all_organizations: bool
    all_regions: bool
    all_areas: bool
    all_branches: bool


class Authority(ContractModel):
    user_id: str
    username: str
    display_name: str
    role: Literal[
        "system",
        "operations_director",
        "operations_manager",
        "operations_consultant",
        "store_manager",
        "store",
    ]
    account_type: Literal["employee", "branch"]
    permissions: list[str]
    capabilities: list[str]
    direct_scope: list[ScopeAssignment]
    scope: Scope
    active_branch: str
    is_active: bool
    must_change_password: bool
    permission_source: str
    scope_source: str
    authority_revision: int = Field(ge=0)


class TokenResponse(ContractModel):
    access_token: str
    refresh_token: str
    token_type: Literal["bearer"]
    expires_in: int = Field(ge=1)
    user: Authority


class UserCreateRequest(ContractModel):
    username: str = Field(min_length=1, max_length=128)
    display_name: str = Field(min_length=1, max_length=256)
    role: str = Field(min_length=1, max_length=64)
    password: str | None = Field(default=None, max_length=128)
    is_active: bool = True
    assignments: list[ScopeAssignment] = Field(default_factory=list)


class UserUpdateRequest(ContractModel):
    base_authority_revision: int
    display_name: str | None = None
    role: str | None = None
    is_active: bool | None = None


class PasswordResetRequest(ContractModel):
    base_authority_revision: int
    password: str | None = Field(default=None, max_length=128)


class ReplaceScopesRequest(ContractModel):
    base_authority_revision: int
    assignments: list[ScopeAssignment]


class RegionCreateRequest(ContractModel):
    region_id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    is_active: bool = True


class RegionUpdateRequest(ContractModel):
    base_revision: int
    name: str | None = None
    is_active: bool | None = None


class AreaCreateRequest(ContractModel):
    area_id: str = Field(min_length=1, max_length=64)
    region_id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    is_active: bool = True


class AreaUpdateRequest(ContractModel):
    base_revision: int
    name: str | None = None
    is_active: bool | None = None


class BranchCreateRequest(ContractModel):
    branch_id: str = Field(min_length=1, max_length=64)
    area_id: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    is_active: bool = True


class BranchBatchRequest(ContractModel):
    items: list[BranchCreateRequest] = Field(min_length=1)


class BranchUpdateRequest(ContractModel):
    base_revision: int
    name: str | None = None
    is_active: bool | None = None


class BranchTransferRequest(ContractModel):
    base_revision: int
    area_id: str = Field(min_length=1, max_length=64)


class RolePermissionsRequest(ContractModel):
    base_revision: int
    permissions: list[str]


class ProductCreateRequest(ContractModel):
    material_number: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=256)
    category: str = ""
    shelf_life_days: int = 0
    uom: str = ""
    is_active: bool = True


class ProductUpdateRequest(ContractModel):
    base_revision: int
    name: str | None = None
    category: str | None = None
    shelf_life_days: int | None = None
    uom: str | None = None
    is_active: bool | None = None
