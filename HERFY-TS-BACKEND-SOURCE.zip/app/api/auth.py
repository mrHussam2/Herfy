from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.api.deps import bearer, get_session, require_user
from app.api.schemas import Authority, TokenResponse
from app.core.errors import ApiError
from app.models.entities import User
from app.services.audit import record_audit
from app.services.authentication import (
    authenticate,
    change_password,
    current_user,
    revoke_token,
    token_response,
)
from app.services.authorization import authority_payload, bump_authority_revision
from app.services.password_policy import policy_payload


router = APIRouter(prefix="/api/auth", tags=["auth"])


class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=128)
    password: str = Field(min_length=1, max_length=128)


class RefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=1)


class ChangePasswordRequest(BaseModel):
    current_password: str | None = Field(default=None, min_length=1, max_length=128)
    new_password: str = Field(min_length=1, max_length=128)


@router.post("/login", response_model=TokenResponse)
def login(payload: LoginRequest, session: Session = Depends(get_session)) -> dict:
    try:
        user = authenticate(
            session, username=payload.username, password=payload.password
        )
    except ApiError:
        session.commit()
        raise
    result = token_response(session, user)
    record_audit(
        session, actor_id=user.id, action="login", entity_type="user", entity_id=user.id
    )
    session.commit()
    return result


@router.post("/refresh", response_model=TokenResponse)
def refresh(payload: RefreshRequest, session: Session = Depends(get_session)) -> dict:
    user = current_user(session, payload.refresh_token, token_type="refresh")
    result = token_response(session, user)
    revoke_token(session, payload.refresh_token)
    record_audit(
        session,
        actor_id=user.id,
        action="session_refresh",
        entity_type="user",
        entity_id=user.id,
    )
    session.commit()
    return result


@router.post("/logout")
def logout(
    credentials: HTTPAuthorizationCredentials = Depends(bearer),
    user: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    revoke_token(session, credentials.credentials)
    bump_authority_revision(session, user)
    record_audit(
        session,
        actor_id=user.id,
        action="logout",
        entity_type="user",
        entity_id=user.id,
    )
    session.commit()
    return {"ok": True}


@router.get("/authority", response_model=Authority)
def authority(
    user: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    return authority_payload(session, user)


@router.get("/password-policy")
def password_policy(_: User = Depends(require_user)) -> dict:
    return policy_payload()


@router.post("/change-password")
def change_own_password(
    payload: ChangePasswordRequest,
    user: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    change_password(
        session,
        user,
        current_password=payload.current_password,
        new_password=payload.new_password,
    )
    record_audit(
        session,
        actor_id=user.id,
        action="password_change",
        entity_type="user",
        entity_id=user.id,
    )
    session.commit()
    return {"ok": True}
