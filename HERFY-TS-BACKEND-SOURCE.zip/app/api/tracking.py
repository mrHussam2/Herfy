from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.api.deps import get_session, require_user
from app.core.errors import ApiError
from app.models.entities import User
from app.services.authorization import authority_payload, require_permissions
from app.services.tracking import tracking_payload, visible_tracking_items


router = APIRouter(prefix="/api/tracking", tags=["tracking"])


@router.get("/items")
def list_items(
    branch_id: str | None = Query(default=None),
    user: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    try:
        require_permissions(session, user, "tracking.view")
    except PermissionError as exc:
        raise ApiError(403, str(exc), "This operation is not permitted.") from exc
    scope = authority_payload(session, user)["scope"]
    if branch_id and not scope["all_branches"] and branch_id not in scope["branches"]:
        raise ApiError(
            403,
            "scope_denied",
            "The requested branch is outside the current actor scope.",
        )
    rows = visible_tracking_items(session, user)
    if branch_id:
        rows = [row for row in rows if row.branch_id == branch_id]
    return {"items": [tracking_payload(row) for row in rows], "next_cursor": None}
