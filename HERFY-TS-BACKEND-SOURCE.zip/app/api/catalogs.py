from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_session, require_user
from app.core.errors import ApiError
from app.models.entities import StoredProduct, UsageProduct, User
from app.services.authorization import require_permissions


router = APIRouter(prefix="/api/catalog", tags=["catalog"])


def _require(session: Session, user: User, permission: str) -> None:
    try:
        require_permissions(session, user, permission)
    except PermissionError as exc:
        raise ApiError(403, str(exc), "This operation is not permitted.") from exc


@router.get("/stored-products")
def stored_products(
    user: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    _require(session, user, "catalog.view")
    rows = session.scalars(
        select(StoredProduct)
        .where(StoredProduct.is_active.is_(True))
        .order_by(StoredProduct.material_number)
    ).all()
    return {
        "items": [
            {"material_number": row.material_number, "name": row.name} for row in rows
        ]
    }


@router.get("/usage-products")
def usage_products(
    user: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    _require(session, user, "usage.view")
    rows = session.scalars(
        select(UsageProduct)
        .where(UsageProduct.is_active.is_(True))
        .order_by(UsageProduct.material_number)
    ).all()
    return {
        "items": [
            {"material_number": row.material_number, "name": row.name, "uom": row.uom}
            for row in rows
        ]
    }
