from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, Depends, Header, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import func, select

from app.api.deps import require_user
from app.db.session import SessionLocal
from app.models.entities import SyncChange, User


router = APIRouter(prefix="/api", tags=["realtime"])


def _cursor(value: str | int | None) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError):
        return 0


@router.get("/events")
async def events(
    cursor: int = Query(default=0, ge=0),
    last_event_id: str | None = Header(default=None),
    actor: User = Depends(require_user),
) -> StreamingResponse:
    """Provide wake-up hints; clients always reconcile through durable sync pull."""
    initial_cursor = max(_cursor(cursor), _cursor(last_event_id))
    actor_id = actor.id
    authority_revision = actor.authority_revision

    async def stream():
        observed = initial_cursor
        while True:
            with SessionLocal() as session:
                current = session.get(User, actor_id)
                if (
                    current is None
                    or not current.is_active
                    or current.authority_revision != authority_revision
                ):
                    return
                high_watermark = int(
                    session.scalar(select(func.max(SyncChange.event_id))) or 0
                )
            if high_watermark > observed:
                observed = high_watermark
                yield f"id: {observed}\nevent: changed\ndata: {json.dumps({'cursor': observed})}\n\n"
            else:
                yield ": keepalive\n\n"
            # Existing SSE transport: bounded low-latency hints, no new broker.
            await asyncio.sleep(3)

    return StreamingResponse(
        stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
