from __future__ import annotations

import secrets
from typing import Any

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.sql.functions import count

from app.api.deps import get_session, require_user
from app.api.schemas import (
    AreaCreateRequest,
    AreaUpdateRequest,
    BranchBatchRequest,
    BranchCreateRequest,
    BranchTransferRequest,
    BranchUpdateRequest,
    PasswordResetRequest,
    ProductCreateRequest,
    ProductUpdateRequest,
    RegionCreateRequest,
    RegionUpdateRequest,
    ReplaceScopesRequest,
    RolePermissionsRequest,
    ScopeAssignment,
    UserCreateRequest,
    UserUpdateRequest,
)
from app.core.errors import ApiError
from app.models.entities import (
    Area,
    Branch,
    Organization,
    Region,
    RolePolicy,
    StoredProduct,
    UsageProduct,
    User,
)
from app.services.administration import (
    audit_payloads,
    create_area,
    create_branch,
    create_catalog_product,
    create_region,
    product_payload,
    remove_catalog_product,
    remove_structure,
    replace_role_permissions,
    structure_payload,
    transfer_branch,
    update_catalog_product,
    update_structure,
)
from app.services.audit import record_audit
from app.services.authorization import (
    authority_payload,
    ALL_PERMISSIONS,
    bump_authority_revision,
    can_delegate,
    require_permissions,
    role_permissions,
    scopes_are_within_actor,
    visible_hierarchy,
    visible_managed_users_statement,
)


def _entity_count(session: Session, entity: type[Any]) -> int:
    """Return an entity count with SQLAlchemy's dedicated count expression."""
    count_expression = count()
    return int(session.scalar(select(count_expression).select_from(entity)) or 0)


from app.services.password_policy import validate_password
from app.services.scopes import replace_direct_scopes
from app.services.users import ROLES, create_user, normalize_role
from app.core.security import hash_password


router = APIRouter(prefix="/api/admin", tags=["administration"])


# These are the permission gates for the five server-owned administration
# modules. They deliberately use read permissions where a module is shown:
# mutation permissions alone never make a section visible. Scope restrictions
# are still applied by the individual read/mutation endpoints.
_ADMIN_MODULE_PERMISSIONS: dict[str, frozenset[str]] = {
    "users": frozenset({"users.view"}),
    "structure": frozenset(
        {"organizations.view", "regions.view", "areas.view", "branches.view"}
    ),
    "catalogs": frozenset({"catalog.view", "catalog.manage", "usage.view", "usage.manage"}),
    "permissions": frozenset({"permissions.view"}),
    "audit": frozenset({"audit.view"}),
}
_ADMINISTRATION_ACCESS_PERMISSIONS = frozenset().union(*_ADMIN_MODULE_PERMISSIONS.values())


def _administration_bootstrap_permissions(session: Session, actor: User) -> dict[str, bool]:
    """Return the public bootstrap capability contract.

    ``role_permissions`` is intentionally a list in the authorization layer.
    The HTTP administration bootstrap contract is different: it is a map from
    a permission code to an explicit boolean. Keeping this conversion next to
    the route makes the boundary auditable and prevents a client from inferring
    grants from an untyped JSON array.
    """
    return {code: True for code in sorted(set(role_permissions(session, actor.role)))}


def _administration_modules(granted: set[str]) -> list[str]:
    """Return only modules with an explicitly granted server permission."""
    return [
        module
        for module, required in _ADMIN_MODULE_PERMISSIONS.items()
        if granted.intersection(required)
    ]


def _require(session: Session, actor: User, *permissions: str) -> None:
    try:
        require_permissions(session, actor, *permissions)
    except PermissionError as exc:
        raise ApiError(403, str(exc), "This operation is not permitted.") from exc


def _require_any(session: Session, actor: User, *permissions: str) -> None:
    if actor.must_change_password or not set(
        role_permissions(session, actor.role)
    ).intersection(permissions):
        raise ApiError(403, "permission_denied", "This operation is not permitted.")


def _managed_user_or_404(session: Session, actor: User, user_id: str) -> User:
    user = session.scalar(
        visible_managed_users_statement(session, actor).where(User.id == user_id)
    )
    if user is None:
        raise ApiError(404, "user_not_found", "The requested user does not exist.")
    return user


def _commit(session: Session) -> None:
    try:
        session.commit()
    except Exception:
        session.rollback()
        raise


def _assignment_scopes(assignments: list[ScopeAssignment]) -> dict[str, list[str]]:
    scopes = {"organizations": [], "regions": [], "areas": [], "branches": []}
    for assignment in assignments:
        scopes[f"{assignment.scope_type}s"].append(assignment.scope_id)
    return scopes


def _enforce_user_creation(
    session: Session, actor: User, payload: UserCreateRequest
) -> None:
    _require(session, actor, "users.create", "roles.assign")
    if not payload.password:
        raise ApiError(
            422, "initial_password_required", "An initial password is required."
        )
    normalized_role = normalize_role(payload.role)
    if not can_delegate(actor, normalized_role):
        raise ApiError(
            403,
            "delegation_denied",
            "This role cannot be delegated by the current actor.",
        )
    requested_scopes = _assignment_scopes(payload.assignments)
    if not scopes_are_within_actor(session, actor, requested_scopes):
        raise ApiError(
            403,
            "scope_denied",
            "The requested scope is outside the current actor scope.",
        )


@router.post("/users", status_code=201)
def create_administrative_user(
    payload: UserCreateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _enforce_user_creation(session, actor, payload)
    user = create_user(
        session,
        username=payload.username,
        display_name=payload.display_name,
        role=payload.role,
        password=payload.password,
        is_active=payload.is_active,
    )
    direct_scopes = _assignment_scopes(payload.assignments)
    if any(direct_scopes.values()):
        replace_direct_scopes(session, user, **direct_scopes)
    record_audit(
        session,
        actor_id=actor.id,
        action="user_create",
        entity_type="user",
        entity_id=user.id,
    )
    _commit(session)
    return authority_payload(session, user)


@router.get("/users")
def list_users(
    actor: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    _require(session, actor, "users.view")
    statement = visible_managed_users_statement(session, actor).order_by(User.username)
    items = [
        authority_payload(session, user) for user in session.scalars(statement).all()
    ]
    return {"items": items, "next_cursor": None}


@router.put("/users/{user_id}/scopes")
def replace_user_scopes(
    user_id: str,
    payload: ReplaceScopesRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "users.scopes.assign")
    target = _managed_user_or_404(session, actor, user_id)
    if target.authority_revision != payload.base_authority_revision:
        raise ApiError(
            409,
            "authority_conflict",
            "The user authority has changed; reload and retry.",
        )
    scopes = _assignment_scopes(payload.assignments)
    if not scopes_are_within_actor(session, actor, scopes):
        raise ApiError(
            403,
            "scope_denied",
            "The requested scope is outside the current actor scope.",
        )
    replace_direct_scopes(session, target, **scopes)
    record_audit(
        session,
        actor_id=actor.id,
        action="user_scope_replace",
        entity_type="user",
        entity_id=target.id,
    )
    _commit(session)
    return authority_payload(session, target)


@router.patch("/users/{user_id}")
def update_administrative_user(
    user_id: str,
    payload: UserUpdateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    target = _managed_user_or_404(session, actor, user_id)
    values = payload.model_dump(exclude_unset=True)
    if values.get("base_authority_revision") != target.authority_revision:
        raise ApiError(
            409,
            "authority_conflict",
            "The user authority has changed; reload and retry.",
        )
    changed = False
    if "display_name" in values:
        _require(session, actor, "users.update")
        display_name = str(values["display_name"] or "").strip()
        if not display_name:
            raise ApiError(422, "invalid_display_name", "A display name is required.")
        target.display_name = display_name
        changed = True
    if "is_active" in values:
        _require(
            session,
            actor,
            "users.enable" if bool(values["is_active"]) else "users.disable",
        )
        if target.id == actor.id and not bool(values["is_active"]):
            raise ApiError(
                422, "self_disable_denied", "You cannot disable your own account."
            )
        target.is_active = bool(values["is_active"])
        changed = True
    if "role" in values:
        _require(session, actor, "roles.assign")
        role = normalize_role(str(values["role"] or ""))
        if role not in ROLES or not can_delegate(actor, role):
            raise ApiError(
                403,
                "delegation_denied",
                "This role cannot be delegated by the current actor.",
            )
        target.role = role
        changed = True
    if not changed:
        raise ApiError(
            422, "no_user_changes", "No supported user changes were provided."
        )
    bump_authority_revision(session, target)
    record_audit(
        session,
        actor_id=actor.id,
        action="user_update",
        entity_type="user",
        entity_id=target.id,
    )
    _commit(session)
    return authority_payload(session, target)


@router.delete("/users/{user_id}")
def disable_administrative_user(
    user_id: str,
    base_authority_revision: int = Query(ge=1),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "users.disable")
    target = _managed_user_or_404(session, actor, user_id)
    if target.authority_revision != base_authority_revision:
        raise ApiError(
            409,
            "authority_conflict",
            "The user authority has changed; reload and retry.",
        )
    if target.id == actor.id:
        raise ApiError(
            422, "self_disable_denied", "You cannot disable your own account."
        )
    target.is_active = False
    bump_authority_revision(session, target)
    record_audit(
        session,
        actor_id=actor.id,
        action="user_disable",
        entity_type="user",
        entity_id=target.id,
    )
    _commit(session)
    return authority_payload(session, target)


@router.post("/users/{user_id}/reset-password")
def reset_administrative_password(
    user_id: str,
    payload: PasswordResetRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "users.password.reset")
    target = _managed_user_or_404(session, actor, user_id)
    values = payload.model_dump()
    if values.get("base_authority_revision") != target.authority_revision:
        raise ApiError(
            409,
            "authority_conflict",
            "The user authority has changed; reload and retry.",
        )
    password = str(values.get("password") or "").strip() or secrets.token_urlsafe(18)
    try:
        validate_password(password)
    except ValueError as exc:
        raise ApiError(
            422, "password_policy", "The password does not meet the password policy."
        ) from exc
    target.password_hash = hash_password(password)
    target.must_change_password = True
    bump_authority_revision(session, target)
    record_audit(
        session,
        actor_id=actor.id,
        action="user_password_reset",
        entity_type="user",
        entity_id=target.id,
    )
    _commit(session)
    result = {"ok": True, "user": authority_payload(session, target)}
    if not values.get("password"):
        result["temporary_password"] = password
    return result


@router.get("/bootstrap")
def administrative_bootstrap(
    actor: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    # A tracking/KPI-only account must not obtain an administration bootstrap
    # projection merely because it has some unrelated permission.
    _require_any(session, actor, *_ADMINISTRATION_ACCESS_PERMISSIONS)
    allowed_actions = _administration_bootstrap_permissions(session, actor)
    return {
        "authority_revision": actor.authority_revision,
        "available_modules": _administration_modules(set(allowed_actions)),
        "allowed_actions": allowed_actions,
        "scope_policy": {
            "types": ["organization", "region", "area", "branch"],
            "allow_multiple": True,
            "allow_mixed_types": True,
        },
        "manageable_roles": sorted(role for role in ROLES if can_delegate(actor, role)),
        "permission_catalog": sorted(ALL_PERMISSIONS),
        "summary": {
            "users": _entity_count(session, User),
            "regions": _entity_count(session, Region),
            "areas": _entity_count(session, Area),
            "branches": _entity_count(session, Branch),
        },
    }


@router.get("/structure")
def administrative_structure(
    actor: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    _require_any(
        session,
        actor,
        "organizations.view",
        "regions.view",
        "areas.view",
        "branches.view",
    )
    hierarchy = visible_hierarchy(session, actor)
    return {
        "organizations": [structure_payload(row) for row in hierarchy["organizations"]],
        "regions": [structure_payload(row) for row in hierarchy["regions"]],
        "areas": [structure_payload(row) for row in hierarchy["areas"]],
        "branches": [structure_payload(row) for row in hierarchy["branches"]],
    }


@router.post("/regions", status_code=201)
def administrative_region_create(
    payload: RegionCreateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "regions.create")
    result = structure_payload(create_region(session, actor, payload.model_dump()))
    _commit(session)
    return result


@router.patch("/regions/{region_id}")
def administrative_region_update(
    region_id: str,
    payload: RegionUpdateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "regions.update")
    region = session.get(Region, region_id)
    if region is None:
        raise ApiError(404, "region_not_found", "The requested region does not exist.")
    result = update_structure(
        session, actor, region, payload.model_dump(exclude_unset=True), "region"
    )
    _commit(session)
    return result


@router.delete("/regions/{region_id}")
def administrative_region_delete(
    region_id: str,
    base_revision: int = Query(ge=1),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "regions.delete")
    region = session.get(Region, region_id)
    if region is None:
        raise ApiError(404, "region_not_found", "The requested region does not exist.")
    if region.revision != base_revision:
        raise ApiError(
            409, "revision_conflict", "The resource has changed; reload and retry."
        )
    result = remove_structure(session, actor, region, "region")
    _commit(session)
    return result


@router.post("/areas", status_code=201)
def administrative_area_create(
    payload: AreaCreateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "areas.create")
    result = structure_payload(create_area(session, actor, payload.model_dump()))
    _commit(session)
    return result


@router.patch("/areas/{area_id}")
def administrative_area_update(
    area_id: str,
    payload: AreaUpdateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "areas.update")
    area = session.get(Area, area_id)
    if area is None:
        raise ApiError(404, "area_not_found", "The requested area does not exist.")
    result = update_structure(
        session, actor, area, payload.model_dump(exclude_unset=True), "area"
    )
    _commit(session)
    return result


@router.delete("/areas/{area_id}")
def administrative_area_delete(
    area_id: str,
    base_revision: int = Query(ge=1),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "areas.delete")
    area = session.get(Area, area_id)
    if area is None:
        raise ApiError(404, "area_not_found", "The requested area does not exist.")
    if area.revision != base_revision:
        raise ApiError(
            409, "revision_conflict", "The resource has changed; reload and retry."
        )
    result = remove_structure(session, actor, area, "area")
    _commit(session)
    return result


@router.post("/branches", status_code=201)
def administrative_branch_create(
    payload: BranchCreateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "branches.create")
    result = structure_payload(create_branch(session, actor, payload.model_dump()))
    _commit(session)
    return result


@router.post("/branches/batch", status_code=201)
def administrative_branch_batch(
    payload: BranchBatchRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "branches.create")
    result = [
        structure_payload(create_branch(session, actor, item.model_dump()))
        for item in payload.items
    ]
    _commit(session)
    return {"items": result}


@router.patch("/branches/{branch_id}")
def administrative_branch_update(
    branch_id: str,
    payload: BranchUpdateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "branches.update")
    branch = session.get(Branch, branch_id)
    if branch is None:
        raise ApiError(404, "branch_not_found", "The requested branch does not exist.")
    result = update_structure(
        session, actor, branch, payload.model_dump(exclude_unset=True), "branch"
    )
    _commit(session)
    return result


@router.post("/branches/{branch_id}/transfer")
def administrative_branch_transfer(
    branch_id: str,
    payload: BranchTransferRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "branches.transfer")
    branch = session.get(Branch, branch_id)
    if branch is None:
        raise ApiError(404, "branch_not_found", "The requested branch does not exist.")
    result = transfer_branch(
        session,
        actor,
        branch,
        area_id=payload.area_id,
        base_revision=payload.base_revision,
    )
    _commit(session)
    return result


@router.delete("/branches/{branch_id}")
def administrative_branch_delete(
    branch_id: str,
    base_revision: int = Query(ge=1),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "branches.delete")
    branch = session.get(Branch, branch_id)
    if branch is None:
        raise ApiError(404, "branch_not_found", "The requested branch does not exist.")
    if branch.revision != base_revision:
        raise ApiError(
            409, "revision_conflict", "The resource has changed; reload and retry."
        )
    result = remove_structure(session, actor, branch, "branch")
    _commit(session)
    return result


@router.get("/permissions")
def administrative_permissions(
    actor: User = Depends(require_user), session: Session = Depends(get_session)
) -> dict:
    _require(session, actor, "permissions.view")
    roles = []
    for role in sorted(ROLES):
        policy = session.get(RolePolicy, role)
        roles.append(
            {
                "role": role,
                "permissions": role_permissions(session, role),
                "revision": policy.revision if policy else 1,
            }
        )
    return {"permission_catalog": sorted(ALL_PERMISSIONS), "roles": roles}


@router.put("/roles/{role_key}/permissions")
def administrative_permissions_replace(
    role_key: str,
    payload: RolePermissionsRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "permissions.assign")
    result = replace_role_permissions(
        session,
        actor,
        role=role_key,
        base_revision=payload.base_revision,
        permissions=payload.permissions,
    )
    _commit(session)
    return result


def _catalog_rows(session: Session, model, include_inactive: bool) -> list:
    statement = select(model).order_by(model.material_number)
    if not include_inactive:
        statement = statement.where(model.is_active.is_(True))
    return list(session.scalars(statement).all())


@router.get("/catalogs/stored-products")
def administrative_stored_list(
    include_inactive: bool = True,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> list[dict]:
    _require(session, actor, "catalog.manage")
    return [
        product_payload(row)
        for row in _catalog_rows(session, StoredProduct, include_inactive)
    ]


@router.post("/catalogs/stored-products", status_code=201)
def administrative_stored_create(
    payload: ProductCreateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "catalog.manage")
    result = create_catalog_product(
        session, actor, kind="stored", payload=payload.model_dump()
    )
    _commit(session)
    return result


@router.patch("/catalogs/stored-products/{material_number}")
def administrative_stored_update(
    material_number: str,
    payload: ProductUpdateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "catalog.manage")
    product = session.get(StoredProduct, material_number)
    if product is None:
        raise ApiError(
            404, "product_not_found", "The requested product does not exist."
        )
    result = update_catalog_product(
        session,
        actor,
        product,
        kind="stored",
        payload=payload.model_dump(exclude_unset=True),
    )
    _commit(session)
    return result


@router.delete("/catalogs/stored-products/{material_number}")
def administrative_stored_delete(
    material_number: str,
    base_revision: int = Query(ge=1),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "catalog.manage")
    product = session.get(StoredProduct, material_number)
    if product is None:
        raise ApiError(
            404, "product_not_found", "The requested product does not exist."
        )
    result = remove_catalog_product(
        session, actor, product, kind="stored", base_revision=base_revision
    )
    _commit(session)
    return result


@router.get("/catalogs/usage-products")
def administrative_usage_list(
    include_inactive: bool = True,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> list[dict]:
    _require(session, actor, "usage.manage")
    return [
        product_payload(row)
        for row in _catalog_rows(session, UsageProduct, include_inactive)
    ]


@router.post("/catalogs/usage-products", status_code=201)
def administrative_usage_create(
    payload: ProductCreateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "usage.manage")
    result = create_catalog_product(
        session, actor, kind="usage", payload=payload.model_dump()
    )
    _commit(session)
    return result


@router.patch("/catalogs/usage-products/{material_number}")
def administrative_usage_update(
    material_number: str,
    payload: ProductUpdateRequest,
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "usage.manage")
    product = session.get(UsageProduct, material_number)
    if product is None:
        raise ApiError(
            404, "product_not_found", "The requested product does not exist."
        )
    result = update_catalog_product(
        session,
        actor,
        product,
        kind="usage",
        payload=payload.model_dump(exclude_unset=True),
    )
    _commit(session)
    return result


@router.delete("/catalogs/usage-products/{material_number}")
def administrative_usage_delete(
    material_number: str,
    base_revision: int = Query(ge=1),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "usage.manage")
    product = session.get(UsageProduct, material_number)
    if product is None:
        raise ApiError(
            404, "product_not_found", "The requested product does not exist."
        )
    result = remove_catalog_product(
        session, actor, product, kind="usage", base_revision=base_revision
    )
    _commit(session)
    return result


@router.get("/audit")
def administrative_audit(
    limit: int = Query(default=100, ge=1, le=500),
    actor: User = Depends(require_user),
    session: Session = Depends(get_session),
) -> dict:
    _require(session, actor, "audit.view")
    return {"items": audit_payloads(session, limit=limit), "next_cursor": None}
