"""Authoritative server data models."""
