from __future__ import annotations

from dataclasses import dataclass
import os
import secrets
from uuid import UUID


@dataclass(frozen=True, slots=True)
class Settings:
    environment: str
    database_url: str
    jwt_secret: str
    server_version: str
    api_contract_sha256: str
    contract_version: str
    minimum_client_version: str
    store_account_initial_password: str
    store_account_force_change: bool
    access_token_seconds: int
    refresh_token_seconds: int
    server_identity: str
    database_pool_size: int
    database_max_overflow: int
    database_pool_timeout_seconds: int
    migration_revision: str
    login_failure_limit: int
    login_lock_seconds: int


def load_settings() -> Settings:
    """Load external runtime configuration without embedding production secrets."""
    environment = os.environ.get("HERFY_ENV", "development").strip().lower()
    database_url = os.environ.get("DATABASE_URL", "sqlite+pysqlite:///:memory:").strip()
    jwt_secret = os.environ.get("JWT_SECRET", secrets.token_urlsafe(48))
    server_identity = os.environ.get("HERFY_SERVER_ID", "development-local").strip()
    if environment == "production":
        if not database_url.startswith("postgresql+"):
            raise ValueError(
                "DATABASE_URL must use the supported PostgreSQL driver in production."
            )
        if len(jwt_secret) < 32:
            raise ValueError("JWT_SECRET must be at least 32 characters in production.")
        try:
            UUID(server_identity)
        except ValueError as exc:
            raise ValueError("HERFY_SERVER_ID must be a UUID in production.") from exc
    force_change = (
        os.environ.get("HERFY_STORE_ACCOUNT_FORCE_CHANGE", "true").strip().lower()
    )
    return Settings(
        environment=environment,
        database_url=database_url,
        jwt_secret=jwt_secret,
        server_version=os.environ.get("HERFY_SERVER_VERSION", "2.21.6").strip(),
        api_contract_sha256=os.environ.get(
            "HERFY_API_CONTRACT_SHA256",
            "61b06a1af6eca3ea715308adb04ce3e9e0915bdcd73a726cfb1cb534cf82bf45",
        ).strip(),
        contract_version=os.environ.get("HERFY_CONTRACT_VERSION", "4").strip(),
        minimum_client_version=os.environ.get(
            "HERFY_MINIMUM_CLIENT_VERSION", "2.21.6"
        ).strip(),
        store_account_initial_password=os.environ.get(
            "HERFY_STORE_ACCOUNT_INITIAL_PASSWORD", "123456"
        ),
        store_account_force_change=force_change in {"1", "true", "yes", "on"},
        access_token_seconds=int(os.environ.get("ACCESS_TOKEN_SECONDS", "900")),
        refresh_token_seconds=int(os.environ.get("REFRESH_TOKEN_SECONDS", "2592000")),
        server_identity=server_identity,
        database_pool_size=int(os.environ.get("DATABASE_POOL_SIZE", "4")),
        database_max_overflow=int(os.environ.get("DATABASE_MAX_OVERFLOW", "2")),
        database_pool_timeout_seconds=int(
            os.environ.get("DATABASE_POOL_TIMEOUT_SECONDS", "30")
        ),
        migration_revision=os.environ.get(
            "HERFY_ALEMBIC_HEAD", "0004_kpi_permission"
        ).strip(),
        login_failure_limit=int(os.environ.get("HERFY_LOGIN_FAILURE_LIMIT", "5")),
        login_lock_seconds=int(os.environ.get("HERFY_LOGIN_LOCK_SECONDS", "900")),
    )


settings = load_settings()
