from __future__ import annotations

from datetime import datetime, timedelta, timezone
import uuid

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
import jwt

from app.core.config import settings


_PASSWORD_HASHER = PasswordHasher()


def hash_password(password: str) -> str:
    return _PASSWORD_HASHER.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _PASSWORD_HASHER.verify(password_hash, password)
    except VerifyMismatchError:
        return False


def issue_token(
    *, user_id: str, authority_revision: int, token_type: str, lifetime_seconds: int
) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode(
        {
            "sub": user_id,
            "ar": authority_revision,
            "typ": token_type,
            "jti": str(uuid.uuid4()),
            "iss": settings.server_identity,
            "iat": now,
            "exp": now + timedelta(seconds=lifetime_seconds),
        },
        settings.jwt_secret,
        algorithm="HS256",
    )


def decode_token(token: str) -> dict:
    try:
        return jwt.decode(
            token,
            settings.jwt_secret,
            algorithms=["HS256"],
            issuer=settings.server_identity,
        )
    except jwt.PyJWTError as exc:
        raise ValueError("invalid_token") from exc
