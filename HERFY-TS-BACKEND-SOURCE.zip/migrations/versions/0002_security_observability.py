"""Add request correlation to immutable audit events.

Revision ID: 0002_security_observability
Revises: 0001_initial
Create Date: 2026-10-01
"""

from alembic import op
import sqlalchemy as sa


revision = "0002_security_observability"
down_revision = "0001_initial"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "audit_log", sa.Column("request_id", sa.String(length=128), nullable=True)
    )
    op.create_index("ix_audit_log_created_at", "audit_log", ["created_at"])
    op.create_index(
        "ix_session_revocations_expires_at", "session_revocations", ["expires_at"]
    )
    op.create_index(
        "ix_tracking_items_branch_deleted",
        "tracking_items",
        ["branch_id", "is_deleted"],
    )


def downgrade() -> None:
    op.drop_index("ix_tracking_items_branch_deleted", table_name="tracking_items")
    op.drop_index("ix_session_revocations_expires_at", table_name="session_revocations")
    op.drop_index("ix_audit_log_created_at", table_name="audit_log")
    op.drop_column("audit_log", "request_id")
