"""Persist failed-login protection state.

Revision ID: 0003_authentication_hardening
Revises: 0002_security_observability
Create Date: 2026-10-01
"""

from alembic import op
import sqlalchemy as sa


revision = "0003_authentication_hardening"
down_revision = "0002_security_observability"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "users",
        sa.Column(
            "failed_login_attempts", sa.Integer(), nullable=False, server_default="0"
        ),
    )
    op.add_column(
        "users", sa.Column("locked_until", sa.DateTime(timezone=True), nullable=True)
    )
    op.create_index("ix_users_locked_until", "users", ["locked_until"])


def downgrade() -> None:
    op.drop_index("ix_users_locked_until", table_name="users")
    op.drop_column("users", "locked_until")
    op.drop_column("users", "failed_login_attempts")
