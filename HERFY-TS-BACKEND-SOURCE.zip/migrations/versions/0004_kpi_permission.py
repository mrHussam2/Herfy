"""Grant existing roles the local KPI capability.

Revision ID: 0004_kpi_permission
Revises: 0003_authentication_hardening
Create Date: 2026-10-07
"""

from alembic import op
import sqlalchemy as sa


revision = "0004_kpi_permission"
down_revision = "0003_authentication_hardening"
branch_labels = None
depends_on = None


_ROLES = (
    "operations_director",
    "operations_manager",
    "operations_consultant",
    "store_manager",
    "store_account",
)


def upgrade() -> None:
    connection = op.get_bind()
    for role in _ROLES:
        connection.execute(
            sa.text(
                "INSERT INTO role_permissions (role, permission) "
                "SELECT CAST(:role AS varchar), CAST(:permission AS varchar) "
                "WHERE NOT EXISTS ("
                "SELECT 1 FROM role_permissions "
                "WHERE role = CAST(:role AS varchar) "
                "AND permission = CAST(:permission AS varchar))"
            ),
            {"role": role, "permission": "kpi.view"},
        )
    connection.execute(
        sa.text(
            "UPDATE users SET authority_revision = authority_revision + 1 "
            "WHERE role IN ('operations_director', 'operations_manager', "
            "'operations_consultant', 'store_manager', 'store_account')"
        )
    )


def downgrade() -> None:
    connection = op.get_bind()
    for role in _ROLES:
        connection.execute(
            sa.text(
                "DELETE FROM role_permissions WHERE role = :role AND permission = :permission"
            ),
            {"role": role, "permission": "kpi.view"},
        )
    connection.execute(
        sa.text(
            "UPDATE users SET authority_revision = authority_revision + 1 "
            "WHERE role IN ('operations_director', 'operations_manager', "
            "'operations_consultant', 'store_manager', 'store_account')"
        )
    )
