from __future__ import annotations

import hashlib
import json
import os
import platform
import re
from dataclasses import dataclass
from functools import lru_cache
from importlib.resources import files
from typing import Any
from urllib.parse import urlsplit

from version import get_version

_SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")


def _json_resource(name: str) -> dict[str, Any]:
    resource = files("contracts").joinpath(name)
    with resource.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise RuntimeError(f"{name} must contain a JSON object")
    return value


def _canonical_permissions() -> dict[str, Any]:
    permissions = _json_resource("authority.json").get("permissions")
    if not isinstance(permissions, dict):
        raise RuntimeError("authority.json permissions must be an object")
    return permissions


def _permission_catalog_entries() -> list[Any]:
    entries = _canonical_permissions().get("catalog")
    if not isinstance(entries, list):
        raise RuntimeError("authority.json permissions.catalog must be an array")
    return entries


def policy_allows(
    policy_name: str, granted_permissions: set[str] | list[str] | tuple[str, ...]
) -> bool:
    """Evaluate a server-issued authority snapshot against its shared contract policy."""
    policies = _canonical_permissions().get("policies")
    if not isinstance(policies, dict):
        raise RuntimeError("authority.json permissions.policies must be an object")
    policy = policies.get(str(policy_name or "").strip())
    if not isinstance(policy, dict):
        return False
    granted = {str(code or "").strip().lower() for code in granted_permissions}
    if "*" in granted:
        return True
    all_of = {str(code or "").strip().lower() for code in policy.get("all_of") or []}
    any_of = {str(code or "").strip().lower() for code in policy.get("any_of") or []}
    return (not all_of or all_of.issubset(granted)) and (
        not any_of or bool(any_of & granted)
    )


def _contract_sha256() -> str:
    """Return the stable API compatibility identity, not release metadata."""
    root = files("contracts")
    manifest = _json_resource("CONTRACTS.json")
    entries = manifest.get("contracts")
    if not isinstance(entries, list):
        raise RuntimeError("CONTRACTS.json contracts must be an array")
    by_name: dict[str, dict[str, Any]] = {}
    full = hashlib.sha256()
    for entry in sorted(entries, key=lambda item: str(item["filename"])):
        name = str(entry["filename"])
        raw = root.joinpath(name).read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        if actual != str(entry["sha256"]).lower():
            raise RuntimeError(f"Contract checksum mismatch: {name}")
        by_name[name] = entry
        full.update(name.encode("utf-8"))
        full.update(b"\0")
        full.update(raw)
        full.update(b"\0")
    expected_full = (
        str(manifest.get("actual_local_aggregate_sha256") or "").strip().lower()
    )
    if expected_full != full.hexdigest():
        raise RuntimeError(
            "Packaged full contract aggregate does not match contract bytes"
        )
    api_names = manifest.get("api_compatibility_contracts")
    if not isinstance(api_names, list) or not api_names:
        raise RuntimeError(
            "CONTRACTS.json api_compatibility_contracts must be a non-empty array"
        )
    names = [str(name).strip() for name in api_names]
    if any(not name for name in names) or len(set(names)) != len(names):
        raise RuntimeError(
            "api_compatibility_contracts contains empty or duplicate filenames"
        )
    unknown = sorted(set(names).difference(by_name))
    if unknown:
        raise RuntimeError(f"Unknown API compatibility contract files: {unknown}")
    api = hashlib.sha256()
    for name in sorted(names):
        raw = root.joinpath(name).read_bytes()
        api.update(name.encode("utf-8"))
        api.update(b"\0")
        api.update(raw)
        api.update(b"\0")
    actual_aggregate = api.hexdigest()
    manifest_aggregate = (
        str(manifest.get("server_compatible_api_contract_sha256") or "").strip().lower()
    )
    if manifest_aggregate != actual_aggregate:
        raise RuntimeError(
            "Packaged contract manifest aggregate does not match contract bytes"
        )
    advertised = (
        str(os.environ.get("HERFY_API_CONTRACT_SHA256") or manifest_aggregate)
        .strip()
        .lower()
    )
    if advertised != actual_aggregate:
        raise RuntimeError("API contract override does not match packaged contracts")
    if not _SHA256_PATTERN.fullmatch(advertised):
        raise RuntimeError("API contract sha256 is invalid")
    return advertised


def _runtime_architecture() -> str:
    machine = platform.machine().strip().lower()
    mapping = {
        "amd64": "x64",
        "x86_64": "x64",
        "i386": "x86",
        "i686": "x86",
        "x86": "x86",
        "arm64": "arm64",
        "aarch64": "arm64",
    }
    return mapping.get(machine, machine or "unknown")


@dataclass(frozen=True)
class UpdateTrust:
    schema_version: int
    algorithm: str
    origin: str
    public_key_url: str
    manifest_url: str
    public_key_pem_sha256: str
    key_id: str


@dataclass(frozen=True)
class ServerBinding:
    schema_version: int
    environment: str
    client_version: str
    client_architecture: str
    server_version: str
    api_prefix: str
    api_base_url: str
    updates_base_url: str
    health_ready_route: str
    api_contract_sha256: str
    request_verify_ssl: bool
    http_timeout_seconds: float
    realtime_enabled: bool
    sync_pull_limit: int
    cache_ttl_seconds: dict[str, int]


@lru_cache(maxsize=1)
def get_server_binding() -> ServerBinding:
    api = _json_resource("api.json")
    update = _json_resource("update.json")
    origin = str(api["api_origin"]).rstrip("/")
    updates_origin = str(update["origin"]).rstrip("/")
    parsed = urlsplit(origin)
    if parsed.scheme != "https" or parsed.path.rstrip("/") != "/api":
        raise RuntimeError("Canonical API origin must be HTTPS /api")
    runtime_version = get_version()
    version_contract = _json_resource("version.json")
    server_version = str(version_contract.get("server_version") or runtime_version)
    client_version = str(runtime_version)
    return ServerBinding(
        schema_version=2,
        environment="production",
        client_version=client_version,
        client_architecture=_runtime_architecture(),
        server_version=server_version,
        api_prefix="/api",
        api_base_url=origin,
        updates_base_url=updates_origin,
        health_ready_route="/ready",
        api_contract_sha256=_contract_sha256(),
        request_verify_ssl=True,
        http_timeout_seconds=10.0,
        realtime_enabled=True,
        sync_pull_limit=200,
        cache_ttl_seconds={"metadata": 15, "catalog": 120},
    )


@lru_cache(maxsize=1)
def get_update_trust() -> UpdateTrust:
    payload = _json_resource("update.json")
    if payload.get("algorithm") != "Ed25519":
        raise RuntimeError("Update trust algorithm must be Ed25519")
    pem_sha256 = str(payload.get("public_key_pem_sha256", "")).lower()
    key_id = str(payload.get("key_id", "")).lower()
    if not _SHA256_PATTERN.fullmatch(pem_sha256) or not _SHA256_PATTERN.fullmatch(
        key_id
    ):
        raise RuntimeError("Update key identity is invalid")

    origin = str(payload.get("origin") or "").rstrip("/")
    parsed_origin = urlsplit(origin)
    if (
        parsed_origin.scheme != "https"
        or not parsed_origin.netloc
        or parsed_origin.path not in ("", "/")
    ):
        raise RuntimeError(
            "Canonical update origin must be an HTTPS origin without a path"
        )

    def canonical_url(field: str) -> str:
        value = str(payload.get(field) or "").strip()
        parsed = urlsplit(value)
        if (parsed.scheme, parsed.netloc) != (
            parsed_origin.scheme,
            parsed_origin.netloc,
        ):
            raise RuntimeError(f"{field} must belong to the canonical update origin")
        if not parsed.path.startswith("/updates/") or parsed.query or parsed.fragment:
            raise RuntimeError(f"Invalid canonical update URL: {field}")
        return value

    public_key_url = canonical_url("public_key_url")
    manifest_url = canonical_url("manifest_url")
    return UpdateTrust(
        schema_version=int(payload["schema_version"]),
        algorithm=str(payload["algorithm"]),
        origin=origin,
        public_key_url=public_key_url,
        manifest_url=manifest_url,
        public_key_pem_sha256=pem_sha256,
        key_id=key_id,
    )


def canonical_organization_root() -> tuple[str, str]:
    payload = _json_resource("authority.json").get("scopes") or {}
    root = payload.get("organization_root")
    if not isinstance(root, dict) or bool(root.get("mutable", True)):
        raise RuntimeError("authority.json scopes fixed organization root is invalid")
    ident = str(root.get("id") or "").strip()
    name = str(root.get("name") or "").strip()
    if not ident or not name:
        raise RuntimeError(
            "authority.json scopes organization root identity is missing"
        )
    return ident, name


def canonical_scope_contract() -> tuple[tuple[str, ...], dict[str, object]]:
    payload = _json_resource("authority.json").get("scopes") or {}
    hierarchy = payload.get("hierarchy")
    policy = payload.get("policy")
    if not isinstance(hierarchy, list) or not hierarchy:
        raise RuntimeError("authority.json scopes hierarchy must be a non-empty array")
    scope_types = tuple(str(value).strip() for value in hierarchy)
    if len(set(scope_types)) != len(scope_types) or any(
        not value for value in scope_types
    ):
        raise RuntimeError(
            "authority.json scopes hierarchy contains empty or duplicate scope types"
        )
    if not isinstance(policy, dict):
        raise RuntimeError("authority.json scopes policy must be an object")
    allowed = tuple(str(value).strip() for value in policy.get("allowed_types") or [])
    if allowed != scope_types:
        raise RuntimeError(
            "authority.json scopes policy.allowed_types must match hierarchy order"
        )
    normalized = {
        "allowed_types": list(scope_types),
        "allow_multiple": bool(policy.get("allow_multiple")),
        "allow_mixed_types": bool(policy.get("allow_mixed_types")),
        "inheritance_mode": str(policy.get("inheritance_mode") or "").strip(),
        "overlap_normalization": str(policy.get("overlap_normalization") or "").strip(),
    }
    if normalized["inheritance_mode"] != "parent_expands_effective_scope_only":
        raise RuntimeError("Unsupported canonical scope inheritance mode")
    return scope_types, normalized


def canonical_role_policy() -> tuple[tuple[str, ...], str, dict[str, tuple[str, ...]]]:
    payload = _json_resource("authority.json").get("roles") or {}
    canonical_roles = canonical_role_keys()
    role_set = set(canonical_roles)
    employees = tuple(
        str(value).strip() for value in payload.get("employee_roles") or []
    )
    if not employees or any(value not in role_set for value in employees):
        raise RuntimeError("authority.json roles employee_roles is invalid")
    if len(set(employees)) != len(employees):
        raise RuntimeError("authority.json roles employee_roles contains duplicates")
    branch_role = str(payload.get("branch_identity_role") or "").strip()
    if branch_role not in role_set or branch_role in employees:
        raise RuntimeError("authority.json roles branch_identity_role is invalid")
    raw = payload.get("delegation")
    if not isinstance(raw, dict) or set(raw) != role_set:
        raise RuntimeError(
            "authority.json roles delegation must define every canonical role"
        )
    delegation: dict[str, tuple[str, ...]] = {}
    employee_set = set(employees)
    for actor in canonical_roles:
        values = raw.get(actor)
        if not isinstance(values, list):
            raise RuntimeError(
                f"authority.json roles delegation for {actor} must be an array"
            )
        targets = tuple(str(value).strip() for value in values)
        if any(value not in employee_set for value in targets) or len(
            set(targets)
        ) != len(targets):
            raise RuntimeError(
                f"authority.json roles delegation for {actor} is invalid"
            )
        if actor in targets:
            raise RuntimeError(
                f"authority.json roles delegation for {actor} cannot grant peer management"
            )
        delegation[actor] = targets
    return employees, branch_role, delegation


def canonical_permission_catalog() -> tuple[tuple[str, str], ...]:
    result: list[tuple[str, str]] = []
    seen: set[str] = set()
    for entry in _permission_catalog_entries():
        if not isinstance(entry, dict):
            raise RuntimeError("authority.json entries must be objects")
        code = str(entry.get("code") or "").strip()
        group = str(entry.get("group") or "").strip()
        if not code or not group or code in seen:
            raise RuntimeError("authority.json contains invalid permission metadata")
        seen.add(code)
        result.append((code, group))
    return tuple(result)


def canonical_initial_role_permissions() -> dict[str, tuple[str, ...]]:
    raw = _canonical_permissions().get("initial_role_permissions")
    if not isinstance(raw, dict):
        raise RuntimeError(
            "authority.json permissions.initial_role_permissions must be an object"
        )
    expected = (set(CANONICAL_EMPLOYEE_ROLES) - {"system"}) | {
        CANONICAL_BRANCH_IDENTITY_ROLE
    }
    if set(raw) != expected:
        raise RuntimeError(
            "authority.json initial_role_permissions does not match non-system roles"
        )
    canonical = set(CANONICAL_PERMISSION_CODES)
    result: dict[str, tuple[str, ...]] = {}
    for role in sorted(expected):
        values = tuple(str(value).strip() for value in raw[role])
        if len(set(values)) != len(values) or any(
            value not in canonical for value in values
        ):
            raise RuntimeError(
                f"authority.json initial permissions for {role} are invalid"
            )
        result[role] = values
    return result


def canonical_role_keys() -> tuple[str, ...]:
    payload = _json_resource("authority.json").get("roles") or {}
    values = payload.get("hierarchy")
    if not isinstance(values, list) or not all(isinstance(v, str) for v in values):
        raise RuntimeError("authority.json roles hierarchy is invalid")

    api = _json_resource("api.json")
    authority_enum = (
        api.get("definitions", {})
        .get("Authority", {})
        .get("properties", {})
        .get("role", {})
        .get("enum", [])
    )
    if not isinstance(authority_enum, list):
        raise RuntimeError("api.json canonical authority role enum is invalid")
    allowed = {str(value).strip() for value in authority_enum if str(value).strip()}
    roles = tuple(value for value in values if value in allowed)
    if not roles:
        raise RuntimeError("No canonical API roles are available")
    return roles


def canonical_permission_codes() -> tuple[str, ...]:
    values: list[str] = []
    seen: set[str] = set()
    for entry in _permission_catalog_entries():
        if not isinstance(entry, dict):
            raise RuntimeError("authority.json entries must be objects")
        code = str(entry.get("code") or "").strip()
        if not code or code in seen:
            raise RuntimeError(
                "authority.json contains an empty or duplicate permission"
            )
        if any(token in code for token in (" if ", " else ", "'", '"')):
            raise RuntimeError(f"authority.json contains malformed permission: {code}")
        if "." not in code:
            raise RuntimeError(f"authority.json contains invalid permission: {code}")
        seen.add(code)
        values.append(code)
    return tuple(values)


CANONICAL_ORGANIZATION_ID, CANONICAL_ORGANIZATION_NAME = canonical_organization_root()
CANONICAL_ROLE_KEYS = canonical_role_keys()
(
    CANONICAL_EMPLOYEE_ROLES,
    CANONICAL_BRANCH_IDENTITY_ROLE,
    CANONICAL_ROLE_DELEGATION,
) = canonical_role_policy()
CANONICAL_SCOPE_TYPES, CANONICAL_SCOPE_POLICY = canonical_scope_contract()
CANONICAL_PERMISSION_CATALOG = canonical_permission_catalog()
CANONICAL_PERMISSION_CODES = canonical_permission_codes()
CANONICAL_INITIAL_ROLE_PERMISSIONS = canonical_initial_role_permissions()
