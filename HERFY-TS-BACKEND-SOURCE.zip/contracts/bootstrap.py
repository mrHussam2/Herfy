from __future__ import annotations

from typing import Any

from contracts.routes import Routes

_BOOTSTRAP_KEYS = {
    "contract_version",
    "server_version",
    "minimum_client_version",
    "server_time",
    "authority_revision",
    "organizations",
    "regions",
    "areas",
    "branches",
    "stored_products",
    "usage_products",
}
_ORGANIZATION_KEYS = {"organization_id", "name", "is_active", "revision"}
_REGION_KEYS = {"region_id", "organization_id", "name", "is_active", "revision"}
_AREA_KEYS = {"area_id", "region_id", "name", "is_active", "revision"}
_BRANCH_KEYS = {"branch_id", "area_id", "name", "is_active", "revision"}
_PRODUCT_KEYS = {
    "material_number",
    "name",
    "category",
    "shelf_life_days",
    "uom",
    "is_active",
    "revision",
}


def _require_exact_object(
    value: Any,
    *,
    keys: set[str],
    context: str,
    optional: set[str] | None = None,
) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise RuntimeError(f"{context} must be a JSON object")
    allowed = set(keys).union(optional or set())
    missing = keys.difference(value)
    unexpected = set(value).difference(allowed)
    if missing or unexpected:
        raise RuntimeError(
            f"{context} contract mismatch: missing={sorted(missing)} "
            f"unexpected={sorted(unexpected)}"
        )
    return dict(value)


def _require_object_list(
    value: Any, *, keys: set[str], context: str
) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        raise RuntimeError(f"{context} must be a JSON array")
    return [
        _require_exact_object(item, keys=keys, context=f"{context}[{index}]")
        for index, item in enumerate(value)
    ]


def validate_client_bootstrap(payload: Any) -> dict[str, Any]:
    """Validate runtime policy/projection data returned by ``/meta/client-bootstrap``.

    Update packages, hashes, installer metadata and published-version discovery are
    intentionally absent. Those belong exclusively to the signed update manifest.
    """
    data = _require_exact_object(
        payload,
        keys=_BOOTSTRAP_KEYS,
        optional={"authority"},
        context=Routes.META_CLIENT_BOOTSTRAP,
    )
    data["organizations"] = _require_object_list(
        data["organizations"],
        keys=_ORGANIZATION_KEYS,
        context="bootstrap.organizations",
    )
    data["regions"] = _require_object_list(
        data["regions"], keys=_REGION_KEYS, context="bootstrap.regions"
    )
    data["areas"] = _require_object_list(
        data["areas"], keys=_AREA_KEYS, context="bootstrap.areas"
    )
    data["branches"] = _require_object_list(
        data["branches"], keys=_BRANCH_KEYS, context="bootstrap.branches"
    )
    data["stored_products"] = _require_object_list(
        data["stored_products"], keys=_PRODUCT_KEYS, context="bootstrap.stored_products"
    )
    data["usage_products"] = _require_object_list(
        data["usage_products"], keys=_PRODUCT_KEYS, context="bootstrap.usage_products"
    )
    if "authority" in data and not isinstance(data["authority"], dict):
        raise RuntimeError("bootstrap authority must be a JSON object")
    if not str(data["server_version"] or "").strip():
        raise RuntimeError("bootstrap server_version is missing")
    if not str(data["minimum_client_version"] or "").strip():
        raise RuntimeError("bootstrap minimum_client_version is missing")
    return data
