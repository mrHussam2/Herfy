from __future__ import annotations

import pytest

from app.core.config import load_settings


def test_production_requires_explicit_postgresql_jwt_secret_and_server_identity(
    monkeypatch,
) -> None:
    monkeypatch.setenv("HERFY_ENV", "production")
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.delenv("JWT_SECRET", raising=False)
    monkeypatch.delenv("HERFY_SERVER_ID", raising=False)

    with pytest.raises(ValueError, match="DATABASE_URL"):
        load_settings()


def test_production_settings_reject_short_jwt_secret(monkeypatch) -> None:
    monkeypatch.setenv("HERFY_ENV", "production")
    monkeypatch.setenv(
        "DATABASE_URL", "postgresql+psycopg://herfy:password@127.0.0.1/herfy"
    )
    monkeypatch.setenv("JWT_SECRET", "too-short")
    monkeypatch.setenv("HERFY_SERVER_ID", "c2bb7f28-7e38-4f8d-92ae-57714caee7ea")

    with pytest.raises(ValueError, match="JWT_SECRET"):
        load_settings()


def test_production_settings_accept_explicit_secure_runtime_values(monkeypatch) -> None:
    monkeypatch.setenv("HERFY_ENV", "production")
    monkeypatch.setenv(
        "DATABASE_URL", "postgresql+psycopg://herfy:password@127.0.0.1/herfy"
    )
    monkeypatch.setenv("JWT_SECRET", "a" * 48)
    monkeypatch.setenv("HERFY_SERVER_ID", "c2bb7f28-7e38-4f8d-92ae-57714caee7ea")

    loaded = load_settings()

    assert loaded.database_url.startswith("postgresql+")
    assert loaded.server_identity == "c2bb7f28-7e38-4f8d-92ae-57714caee7ea"
