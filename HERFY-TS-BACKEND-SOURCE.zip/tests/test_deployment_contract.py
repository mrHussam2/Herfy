from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).parents[1]


def test_deployment_files_keep_runtime_unprivileged_and_routes_isolated() -> None:
    service = (ROOT / "deploy" / "herfy-api.service").read_text(encoding="utf-8")
    nginx = (ROOT / "deploy" / "nginx-herfy.conf").read_text(encoding="utf-8")
    bootstrap = (ROOT / "deploy" / "bootstrap.sh").read_text(encoding="utf-8")

    assert "User=herfy" in service
    assert "Group=herfy" in service
    assert "WorkingDirectory=/opt/server/backend/current" in service
    assert "EnvironmentFile=/opt/server/backend/shared/config/api.env" in service
    assert "/opt/server/backend/shared/venv/bin/uvicorn" in service
    assert "--host 127.0.0.1 --port 8000" in service
    assert "ReadWritePaths=/opt/server/backend/shared/logs" in service
    assert "location = /api/events" in nginx
    assert "proxy_buffering off" in nginx
    assert "location /api/" in nginx
    assert "root /opt/server/website" in nginx
    assert "root /opt/server/updates" in nginx
    assert (
        "useradd --system --user-group --home-dir /nonexistent --shell /usr/sbin/nologin herfy"
        in bootstrap
    )
    assert "readonly CONFIG_FILE=${SHARED_ROOT}/config/api.env" in bootstrap
    assert "alembic upgrade head" in bootstrap
    assert "python deploy/seed.py" in bootstrap
    assert "${BACKEND_ROOT}/releases" in bootstrap
    assert "ln -sfn" in bootstrap
    assert "nginx -t" in bootstrap
