from __future__ import annotations

from starlette.testclient import TestClient

from app.main import create_app


def test_application_exposes_liveness_and_readiness_routes() -> None:
    app = create_app()

    routes = {route.path for route in app.routes}

    assert "/api/health" in routes
    assert "/api/ready" in routes


def test_liveness_and_readiness_use_safe_public_envelopes() -> None:
    client = TestClient(create_app())

    liveness = client.get("/api/health")
    readiness = client.get("/api/ready")

    assert liveness.status_code == 200
    assert liveness.json() == {"ok": True, "status": "live"}
    assert readiness.status_code == 200
    assert readiness.json() == {"ok": True, "status": "ready"}
