from __future__ import annotations

import pytest
from sqlalchemy import select

from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.models.entities import AuditLog, StoredProduct, UsageProduct
from app.services.audit import record_audit
from app.services.catalogs import create_stored_product, create_usage_product
from app.services.password_policy import validate_password
from app.services.structure import (
    create_area,
    create_branch,
    create_organization,
    create_region,
)


@pytest.fixture(autouse=True)
def database() -> None:
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


def test_structure_catalog_and_audit_services_persist_authoritative_records() -> None:
    with SessionLocal() as session:
        create_organization(session, id="HERFY", name="HERFY")
        create_region(
            session,
            id="riyadh2",
            code="RIYADH2",
            name="RIYADH2",
            organization_id="HERFY",
        )
        create_area(
            session,
            id="aziziyah",
            code="AL_AZIZIYAH",
            name="AL_AZIZIYAH",
            region_id="riyadh2",
        )
        create_branch(
            session, id="H1074", code="H1074", name="H1074", area_id="aziziyah"
        )
        create_stored_product(session, material_number="100", name="Stored item")
        create_usage_product(
            session, material_number="200", name="Usage item", uom=None
        )
        record_audit(
            session,
            actor_id=None,
            action="seed",
            entity_type="branch",
            entity_id="H1074",
        )
        session.commit()

        assert session.get(StoredProduct, "100").is_active is True
        assert session.get(UsageProduct, "200").uom is None
        assert session.scalar(select(AuditLog.action)) == "seed"


def test_password_policy_allows_every_non_empty_password() -> None:
    for password in ("A@1", "Aa1", "A1", "1"):
        assert validate_password(password) is None
    with pytest.raises(ValueError, match="password_policy"):
        validate_password("")
