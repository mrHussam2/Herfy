from __future__ import annotations

from starlette.testclient import TestClient

from app.api.meta import client_version_is_supported
from app.main import create_app


def test_client_compatibility_policy_accepts_newer_semantic_versions() -> None:
    assert client_version_is_supported("2.21.6", "2.21.6")
    assert client_version_is_supported("2.21.9", "2.21.6")
    assert not client_version_is_supported("2.21.5", "2.21.6")
    assert not client_version_is_supported("invalid", "2.21.6")
    assert not client_version_is_supported("2.21.9", "invalid")


def test_meta_version_exposes_the_client_pinned_contract_identity() -> None:
    response = TestClient(create_app()).get("/api/meta/version")

    assert response.status_code == 200
    assert response.json() == {
        "server_version": "2.21.6",
        "api_contract_sha256": "61b06a1af6eca3ea715308adb04ce3e9e0915bdcd73a726cfb1cb534cf82bf45",
        "minimum_supported_client_version": "2.21.6",
        "latest_client_version": "2.21.6",
    }
