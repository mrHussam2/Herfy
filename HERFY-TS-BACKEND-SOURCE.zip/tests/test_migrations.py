from __future__ import annotations

from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text


def test_alembic_upgrade_creates_authoritative_schema(
    tmp_path: Path, monkeypatch
) -> None:
    database_url = f"sqlite+pysqlite:///{tmp_path / 'herfy.db'}"
    monkeypatch.setenv("DATABASE_URL", database_url)
    config = Config(str(Path(__file__).parents[1] / "alembic.ini"))

    command.upgrade(config, "head")

    inspector = inspect(create_engine(database_url))
    assert {
        "organizations",
        "users",
        "role_permissions",
        "user_branch_scope",
        "tracking_items",
        "sync_changes",
    } <= set(inspector.get_table_names())
    assert {"request_id"} <= {
        column["name"] for column in inspector.get_columns("audit_log")
    }
    assert {"failed_login_attempts", "locked_until"} <= {
        column["name"] for column in inspector.get_columns("users")
    }


def test_previous_supported_schema_upgrades_without_losing_existing_rows(
    tmp_path: Path, monkeypatch
) -> None:
    database_url = f"sqlite+pysqlite:///{tmp_path / 'upgrade.db'}"
    monkeypatch.setenv("DATABASE_URL", database_url)
    config = Config(str(Path(__file__).parents[1] / "alembic.ini"))
    connection = create_engine(database_url)

    command.upgrade(config, "0001_initial")
    with connection.begin() as transaction:
        transaction.execute(
            text(
                "INSERT INTO organizations (id, name, is_active, revision) VALUES ('HERFY', 'HERFY', 1, 1)"
            )
        )
    command.upgrade(config, "head")

    with connection.connect() as transaction:
        assert (
            transaction.scalar(
                text("SELECT name FROM organizations WHERE id = 'HERFY'")
            )
            == "HERFY"
        )
        assert (
            transaction.scalar(text("SELECT version_num FROM alembic_version"))
            == "0004_kpi_permission"
        )
