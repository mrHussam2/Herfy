from __future__ import annotations

from starlette.testclient import TestClient

from app.main import create_app


def test_framework_validation_errors_use_the_safe_public_error_envelope() -> None:
    response = TestClient(create_app()).post(
        "/api/auth/login", json={"username": "", "password": ""}
    )

    assert response.status_code == 422
    assert set(response.json()) == {"code", "message", "request_id"}
    assert response.json()["code"] == "validation_error"
