from __future__ import annotations

from app.main import create_app


def test_server_exposes_every_client_declared_api_route() -> None:
    routes = {
        (route.path, method)
        for route in create_app().routes
        for method in route.methods or set()
    }
    expected = {
        ("/api/health", "GET"),
        ("/api/ready", "GET"),
        ("/api/meta/version", "GET"),
        ("/api/auth/login", "POST"),
        ("/api/auth/refresh", "POST"),
        ("/api/auth/logout", "POST"),
        ("/api/auth/authority", "GET"),
        ("/api/auth/password-policy", "GET"),
        ("/api/auth/change-password", "POST"),
        ("/api/meta/client-bootstrap", "GET"),
        ("/api/meta/branches", "GET"),
        ("/api/catalog/stored-products", "GET"),
        ("/api/catalog/usage-products", "GET"),
        ("/api/tracking/items", "GET"),
        ("/api/sync/pull", "GET"),
        ("/api/sync/push", "POST"),
        ("/api/events", "GET"),
        ("/api/admin/bootstrap", "GET"),
        ("/api/admin/users", "GET"),
        ("/api/admin/users", "POST"),
        ("/api/admin/users/{user_id}", "PATCH"),
        ("/api/admin/users/{user_id}", "DELETE"),
        ("/api/admin/users/{user_id}/reset-password", "POST"),
        ("/api/admin/users/{user_id}/scopes", "PUT"),
        ("/api/admin/structure", "GET"),
        ("/api/admin/regions", "POST"),
        ("/api/admin/regions/{region_id}", "PATCH"),
        ("/api/admin/regions/{region_id}", "DELETE"),
        ("/api/admin/areas", "POST"),
        ("/api/admin/areas/{area_id}", "PATCH"),
        ("/api/admin/areas/{area_id}", "DELETE"),
        ("/api/admin/branches", "POST"),
        ("/api/admin/branches/batch", "POST"),
        ("/api/admin/branches/{branch_id}", "PATCH"),
        ("/api/admin/branches/{branch_id}/transfer", "POST"),
        ("/api/admin/branches/{branch_id}", "DELETE"),
        ("/api/admin/permissions", "GET"),
        ("/api/admin/roles/{role_key}/permissions", "PUT"),
        ("/api/admin/catalogs/stored-products", "GET"),
        ("/api/admin/catalogs/stored-products", "POST"),
        ("/api/admin/catalogs/stored-products/{material_number}", "PATCH"),
        ("/api/admin/catalogs/stored-products/{material_number}", "DELETE"),
        ("/api/admin/catalogs/usage-products", "GET"),
        ("/api/admin/catalogs/usage-products", "POST"),
        ("/api/admin/catalogs/usage-products/{material_number}", "PATCH"),
        ("/api/admin/catalogs/usage-products/{material_number}", "DELETE"),
        ("/api/admin/audit", "GET"),
    }

    assert expected <= routes
