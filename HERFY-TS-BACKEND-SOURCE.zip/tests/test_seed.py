from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, text


ROOT = Path(__file__).parents[1]


@pytest.mark.parametrize(
    ("system_password", "must_change_password"),
    [("System2026", False), ("low6x", False)],
)
def test_seed_creates_the_hierarchy_and_enables_only_configured_privileged_accounts(
    tmp_path: Path, system_password: str, must_change_password: bool
) -> None:
    database_url = f"sqlite+pysqlite:///{tmp_path / 'seed.db'}"
    environment = os.environ.copy()
    environment.update(
        {
            "DATABASE_URL": database_url,
            "HERFY_SYSTEM_USERNAME": "18016",
            "HERFY_SYSTEM_INITIAL_PASSWORD": system_password,
            "HERFY_DIRECTOR_USERNAME": "112",
            "HERFY_DIRECTOR_INITIAL_PASSWORD": "dir6x",
            "HERFY_MANAGER_USERNAME": "1121",
            "HERFY_MANAGER_INITIAL_PASSWORD": "mgr6x",
            "HERFY_CONSULTANT_USERNAME": "2614",
            "HERFY_CONSULTANT_INITIAL_PASSWORD": "con6x",
            "HERFY_STORE_MANAGER_USERNAME": "29429",
            "HERFY_STORE_MANAGER_INITIAL_PASSWORD": "",
        }
    )
    config = Config(str(ROOT / "alembic.ini"))
    previous_database_url = os.environ.get("DATABASE_URL")
    os.environ["DATABASE_URL"] = database_url
    try:
        command.upgrade(config, "head")
    finally:
        if previous_database_url is None:
            os.environ.pop("DATABASE_URL", None)
        else:
            os.environ["DATABASE_URL"] = previous_database_url

    result = subprocess.run(
        [sys.executable, "deploy/seed.py"],
        cwd=ROOT,
        env=environment,
        text=True,
        capture_output=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    rerun_environment = environment.copy()
    for key in tuple(rerun_environment):
        if key.startswith("HERFY_") and (
            key.endswith("_INITIAL_PASSWORD") or key.endswith("_USERNAME")
        ):
            rerun_environment.pop(key)
    rerun = subprocess.run(
        [sys.executable, "deploy/seed.py"],
        cwd=ROOT,
        env=rerun_environment,
        text=True,
        capture_output=True,
        check=False,
    )
    assert rerun.returncode == 0, rerun.stderr
    engine = create_engine(database_url)
    with engine.connect() as connection:
        assert connection.scalar(text("SELECT count(*) FROM branches")) == 18
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM users WHERE username = '18016' AND is_active = 1"
                )
            )
            == 1
        )
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM users WHERE username = '18016' AND must_change_password = :expected"
                ),
                {"expected": int(must_change_password)},
            )
            == 1
        )
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM users WHERE role IN ('operations_director', 'operations_manager', 'operations_consultant') AND is_active = 1 AND must_change_password = 1"
                )
            )
            == 3
        )
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM users WHERE role = 'store_account' AND is_active = 1 AND must_change_password = 1"
                )
            )
            == 18
        )
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM users WHERE username != '18016' AND role != 'store_account' AND is_active = 1"
                )
            )
            == 3
        )
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM users WHERE username = '29429' AND is_active = 0"
                )
            )
            == 1
        )
        assert (
            connection.scalar(
                text(
                    "SELECT count(*) FROM role_permissions WHERE permission = 'kpi.view'"
                )
            )
            == 5
        )
