from __future__ import annotations

import json
import hashlib
from pathlib import Path

from app.main import create_app


ROOT = Path(__file__).parents[1]


def _schema_name(schema: dict) -> str | None:
    reference = schema.get("$ref")
    return reference.rsplit("/", 1)[-1] if isinstance(reference, str) else None


def test_openapi_request_components_match_the_canonical_client_contract() -> None:
    """Fails if a typed request boundary becomes an unvalidated dict again."""
    contract = json.loads((ROOT / "contracts" / "api.json").read_text(encoding="utf-8"))
    openapi = create_app().openapi()

    mismatches: list[str] = []
    for route in contract["routes"]:
        expected = route["request_schema"]
        if expected is None:
            continue
        path = "/api" + route["path"]
        operation = openapi["paths"][path][route["method"].lower()]
        schema = (
            operation.get("requestBody", {})
            .get("content", {})
            .get("application/json", {})
            .get("schema", {})
        )
        actual = _schema_name(schema)
        if actual != expected:
            mismatches.append(
                f"{route['method']} {route['path']}: {actual!r} != {expected!r}"
            )

    assert mismatches == []


def test_openapi_auth_responses_are_typed_to_the_canonical_contract() -> None:
    """Fails if authentication responses regress to unconstrained objects."""
    openapi = create_app().openapi()
    expected = {
        ("post", "/api/auth/login"): "TokenResponse",
        ("post", "/api/auth/refresh"): "TokenResponse",
        ("get", "/api/auth/authority"): "Authority",
    }

    actual = {
        (method, path): _schema_name(
            openapi["paths"][path][method]["responses"]["200"]["content"][
                "application/json"
            ]["schema"]
        )
        for method, path in expected
    }

    assert actual == expected


def test_copied_canonical_contracts_are_hash_verified_and_match_the_expected_api_compatibility_pin() -> (
    None
):
    manifest = json.loads(
        (ROOT / "contracts" / "CONTRACTS.json").read_text(encoding="utf-8")
    )

    for contract in manifest["contracts"]:
        contents = (ROOT / "contracts" / contract["filename"]).read_bytes()
        assert hashlib.sha256(contents).hexdigest() == contract["sha256"]
    assert (
        manifest["server_compatible_api_contract_sha256"]
        == "61b06a1af6eca3ea715308adb04ce3e9e0915bdcd73a726cfb1cb534cf82bf45"
    )
