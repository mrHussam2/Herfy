from __future__ import annotations

import pytest
from sqlalchemy.exc import IntegrityError

from app.db.base import Base
from app.db.session import SessionLocal, engine
from app.models.entities import Area, Branch, Organization, Region, User, UserAreaScope
from app.services.authorization import authority_payload, bump_authority_revision


@pytest.fixture(autouse=True)
def database() -> None:
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    yield
    Base.metadata.drop_all(engine)


def test_branch_requires_an_existing_area() -> None:
    with SessionLocal() as session:
        session.add(Branch(id="H1074", code="H1074", name="H1074", area_id="missing"))

        with pytest.raises(IntegrityError):
            session.commit()


def test_authority_expands_assigned_area_and_bumps_revision() -> None:
    with SessionLocal() as session:
        session.add(Organization(id="HERFY", name="HERFY"))
        session.add(
            Region(
                id="riyadh2", code="RIYADH2", name="RIYADH2", organization_id="HERFY"
            )
        )
        session.add(
            Area(
                id="aziziyah",
                code="AL_AZIZIYAH",
                name="AL_AZIZIYAH",
                region_id="riyadh2",
            )
        )
        session.add(Branch(id="H1074", code="H1074", name="H1074", area_id="aziziyah"))
        user = User(
            id="consultant-1",
            username="2614",
            display_name="Khaled ALFAIFI",
            role="operations_consultant",
            password_hash="test-only",
            authority_revision=4,
        )
        session.add(user)
        session.add(UserAreaScope(user_id=user.id, area_id="aziziyah"))
        session.commit()

        authority = authority_payload(session, user)

        assert authority["scope"]["areas"] == ["aziziyah"]
        assert authority["scope"]["branches"] == ["H1074"]
        assert authority["direct_scope"] == [
            {"scope_type": "area", "scope_id": "aziziyah"}
        ]
        assert authority["authority_revision"] == 4
        assert bump_authority_revision(session, user) == 5


def test_branch_account_has_one_internal_role_and_the_client_contract_role() -> None:
    with SessionLocal() as session:
        session.add(Organization(id="HERFY", name="HERFY"))
        session.add(
            Region(
                id="riyadh2", code="RIYADH2", name="RIYADH2", organization_id="HERFY"
            )
        )
        session.add(
            Area(
                id="aziziyah",
                code="AL_AZIZIYAH",
                name="AL_AZIZIYAH",
                region_id="riyadh2",
            )
        )
        session.add(Branch(id="H1074", code="H1074", name="H1074", area_id="aziziyah"))
        account = User(
            id="branch-account",
            username="H1074",
            display_name="Store account H1074",
            role="store_account",
            password_hash="test-only",
        )
        session.add(account)
        session.add(UserAreaScope(user_id=account.id, area_id="aziziyah"))
        session.commit()

        authority = authority_payload(session, account)

        assert authority["role"] == "store"
        assert authority["account_type"] == "branch"
