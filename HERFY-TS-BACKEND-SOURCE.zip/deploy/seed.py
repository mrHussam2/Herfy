from __future__ import annotations

import os
import secrets
from pathlib import Path
import sys


SERVER_ROOT = Path(__file__).resolve().parents[1]
if str(SERVER_ROOT) not in sys.path:
    sys.path.insert(0, str(SERVER_ROOT))

import yaml
from sqlalchemy import select

from app.db.session import SessionLocal
from app.models.entities import Area, Branch, Organization, Region, RolePermission, User
from app.services.administration import create_branch
from app.services.scopes import replace_direct_scopes
from app.services.structure import create_area, create_organization, create_region
from app.services.password_policy import validate_password
from app.services.users import create_user


ROLE_PERMISSIONS = {
    "operations_director": {
        "areas.view",
        "branches.view",
        "catalog.view",
        "kpi.view",
        "organizations.view",
        "regions.view",
        "roles.assign",
        "roles.view",
        "tracking.create",
        "tracking.delete",
        "tracking.update",
        "tracking.view",
        "usage.view",
        "users.create",
        "users.disable",
        "users.enable",
        "users.password.reset",
        "users.scopes.assign",
        "users.update",
        "users.view",
    },
    "operations_manager": {
        "areas.view",
        "branches.view",
        "catalog.view",
        "kpi.view",
        "organizations.view",
        "regions.view",
        "roles.assign",
        "roles.view",
        "tracking.create",
        "tracking.delete",
        "tracking.update",
        "tracking.view",
        "usage.view",
        "users.create",
        "users.disable",
        "users.enable",
        "users.password.reset",
        "users.scopes.assign",
        "users.update",
        "users.view",
    },
    "operations_consultant": {
        "areas.view",
        "branches.view",
        "catalog.view",
        "kpi.view",
        "organizations.view",
        "regions.view",
        "roles.assign",
        "roles.view",
        "tracking.create",
        "tracking.delete",
        "tracking.update",
        "tracking.view",
        "usage.view",
        "users.create",
        "users.disable",
        "users.enable",
        "users.password.reset",
        "users.scopes.assign",
        "users.update",
        "users.view",
    },
    "store_manager": {
        "catalog.view",
        "kpi.view",
        "tracking.create",
        "tracking.delete",
        "tracking.update",
        "tracking.view",
        "usage.view",
    },
    "store_account": {
        "catalog.view",
        "kpi.view",
        "tracking.create",
        "tracking.delete",
        "tracking.update",
        "tracking.view",
        "usage.view",
    },
}

ROLE_CREDENTIAL_ENV = {
    "system": ("HERFY_SYSTEM_USERNAME", "HERFY_SYSTEM_INITIAL_PASSWORD"),
    "operations_director": (
        "HERFY_DIRECTOR_USERNAME",
        "HERFY_DIRECTOR_INITIAL_PASSWORD",
    ),
    "operations_manager": ("HERFY_MANAGER_USERNAME", "HERFY_MANAGER_INITIAL_PASSWORD"),
    "operations_consultant": (
        "HERFY_CONSULTANT_USERNAME",
        "HERFY_CONSULTANT_INITIAL_PASSWORD",
    ),
    "store_manager": (
        "HERFY_STORE_MANAGER_USERNAME",
        "HERFY_STORE_MANAGER_INITIAL_PASSWORD",
    ),
}


def _load_data() -> dict:
    with (Path(__file__).with_name("seed_data.yaml")).open(encoding="utf-8") as source:
        return yaml.safe_load(source) or {}


def _seed_permissions(session) -> None:
    if session.scalar(select(RolePermission.id).limit(1)) is not None:
        return
    session.add_all(
        [
            RolePermission(role=role, permission=permission)
            for role, permissions in ROLE_PERMISSIONS.items()
            for permission in sorted(permissions)
        ]
    )


def _seed_user(
    session,
    record: dict,
    *,
    system_password: str,
    system_password_requires_change: bool,
) -> None:
    username_env, password_env = ROLE_CREDENTIAL_ENV[str(record["role"])]
    username = os.environ.get(username_env, str(record["username"])).strip() or str(
        record["username"]
    )
    if session.scalar(select(User).where(User.username == username)) is not None:
        return
    is_system = str(record["role"]) == "system"
    configured_password = (
        system_password if is_system else os.environ.get(password_env, "")
    )
    forced_disabled = str(record.get("state") or "") == "FORCE_RESET_OR_DISABLED"
    # Bootstrap credentials are temporary: every non-system account must set
    # its own password at first login, even when the protected deployment
    # input supplied a policy-compliant initial value.
    password_requires_change = system_password_requires_change if is_system else True
    if configured_password and not is_system:
        try:
            validate_password(configured_password)
        except ValueError:
            password_requires_change = True
    user = create_user(
        session,
        username=username,
        display_name=str(record["full_name"]),
        role=str(record["role"]),
        password=configured_password or secrets.token_urlsafe(24),
        is_active=is_system or (bool(configured_password) and not forced_disabled),
        must_change_password=password_requires_change or forced_disabled,
    )
    replace_direct_scopes(
        session,
        user,
        regions=list(record.get("regions") or []),
        areas=list(record.get("areas") or []),
        branches=list(record.get("branches") or []),
    )


def main() -> None:
    data = _load_data()
    system_username_env, _ = ROLE_CREDENTIAL_ENV["system"]
    system_username = os.environ.get(
        system_username_env, str(data["users"][0]["username"])
    ).strip()
    with SessionLocal() as session:
        if session.get(Organization, "HERFY") is None:
            create_organization(
                session, id="HERFY", name=str(data["organization"]["name"])
            )
        session.flush()
        for region_data in data.get("regions") or []:
            region_code = str(region_data["code"])
            if session.get(Region, region_code) is None:
                create_region(
                    session,
                    id=region_code,
                    code=region_code,
                    name=region_code,
                    organization_id="HERFY",
                )
            for area_data in region_data.get("areas") or []:
                area_code = str(area_data["code"])
                if session.get(Area, area_code) is None:
                    create_area(
                        session,
                        id=area_code,
                        code=area_code,
                        name=area_code,
                        region_id=region_code,
                    )
        session.flush()
        system = session.scalar(select(User).where(User.username == system_username))
        if system is None:
            system_password = os.environ.get("HERFY_SYSTEM_INITIAL_PASSWORD", "")
            if not system_password:
                raise RuntimeError(
                    "HERFY_SYSTEM_INITIAL_PASSWORD must be provided through the protected runtime environment."
                )
            try:
                validate_password(system_password)
            except ValueError:
                system_password_requires_change = True
            else:
                system_password_requires_change = False
            _seed_user(
                session,
                data["users"][0],
                system_password=system_password,
                system_password_requires_change=system_password_requires_change,
            )
            session.flush()
            system = session.scalar(
                select(User).where(User.username == system_username)
            )
        else:
            system_password = ""
            system_password_requires_change = False
        for region_data in data.get("regions") or []:
            for area_data in region_data.get("areas") or []:
                for branch_code in area_data.get("branches") or []:
                    if session.get(Branch, str(branch_code)) is None:
                        create_branch(
                            session,
                            system,
                            {
                                "branch_id": str(branch_code),
                                "name": str(branch_code),
                                "area_id": str(area_data["code"]),
                            },
                        )
        for user_data in data.get("users") or []:
            _seed_user(
                session,
                user_data,
                system_password=system_password,
                system_password_requires_change=system_password_requires_change,
            )
        _seed_permissions(session)
        session.commit()


if __name__ == "__main__":
    main()
