"""Install the contract-aware manifest route on the production update host."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--nginx-config", required=True, type=Path)
    parser.add_argument("--legacy-contract-sha256", required=True)
    parser.add_argument("--legacy-manifest", required=True, type=Path)
    args = parser.parse_args()
    contract = args.legacy_contract_sha256.lower()
    if len(contract) != 64 or any(
        character not in "0123456789abcdef" for character in contract
    ):
        raise SystemExit("legacy contract must be a SHA-256 digest")
    if not args.legacy_manifest.is_file():
        raise SystemExit("legacy manifest is missing")
    path = args.nginx_config
    original = path.read_text(encoding="utf-8")
    marker = "    location = /updates/manifest {\n"
    start = original.find(marker)
    if start < 0:
        raise SystemExit("updates manifest location was not found")
    end = original.find("    location / {\n", start)
    if end < 0:
        raise SystemExit("updates fallback location was not found")
    bridge = f"""    location = /updates/manifest {{
        if ($http_x_api_contract_sha256 = {contract}) {{
            rewrite ^ /updates/manifests/{contract}/manifest last;
        }}
        try_files $uri =404;
        default_type application/json;
        add_header X-Content-Type-Options nosniff always;
        add_header Cache-Control "no-cache" always;
        add_header Access-Control-Allow-Origin "https://herfy.online" always;
        add_header Vary "Origin, X-API-Contract-SHA256" always;
    }}
"""
    if original[start:end] == bridge:
        print("LEGACY_MANIFEST_ROUTE=ALREADY_CONFIGURED")
        return 0
    backup = path.with_suffix(path.suffix + ".before-legacy-update-bridge")
    shutil.copy2(path, backup)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(original[:start] + bridge + original[end:], encoding="utf-8")
    temporary.replace(path)
    print(f"LEGACY_MANIFEST_ROUTE=CONFIGURED backup={backup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
