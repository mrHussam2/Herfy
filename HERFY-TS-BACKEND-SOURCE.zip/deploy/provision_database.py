from __future__ import annotations

import os

import psycopg2
from psycopg2 import sql


database = os.environ["HERFY_DB_NAME"]
username = os.environ["HERFY_DB_USER"]
password = os.environ["HERFY_DB_PASSWORD"]

connection = psycopg2.connect("dbname=postgres")
connection.autocommit = True
try:
    with connection.cursor() as cursor:
        cursor.execute("SELECT 1 FROM pg_roles WHERE rolname = %s", (username,))
        if cursor.fetchone() is None:
            cursor.execute(
                sql.SQL(
                    "CREATE ROLE {} LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD %s"
                ).format(sql.Identifier(username)),
                (password,),
            )
        else:
            cursor.execute(
                sql.SQL(
                    "ALTER ROLE {} LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT PASSWORD %s"
                ).format(sql.Identifier(username)),
                (password,),
            )
        cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (database,))
        if cursor.fetchone() is None:
            cursor.execute(
                sql.SQL(
                    "CREATE DATABASE {} OWNER {} ENCODING 'UTF8' TEMPLATE template0"
                ).format(sql.Identifier(database), sql.Identifier(username))
            )
finally:
    connection.close()
